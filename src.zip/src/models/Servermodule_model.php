<?php
class Servermodule_model extends CI_Model{

	function __construct(){
		parent::__construct();
		$this->load->database();
	}

	function loadAllData() {
		$sql = "SELECT * FROM server_modules ORDER BY id";
		$data = $this->db->query($sql)->result_array();

		return $data;
 	}

	function toggleStatus($id) {
		if (!is_numeric($id) || $id <= 0) {
			return false;
		}
		$sql = "UPDATE server_modules SET status = IF(status=1, 0, 1), updated_on = NOW(), updated_by = ? WHERE id = ?";
		return $this->db->query($sql, array(getAdminId(), intval($id)));
	}

	function getDetail($id) {
		if (!is_numeric($id) || $id <= 0) {
			return array();
		}

		$sql = "SELECT * FROM server_modules WHERE id=? AND status=1";
		$data = $this->db->query($sql, array(intval($id)))->result_array();

		return !empty($data) ? $data[0] : array();
	}

	function saveData($data) {
		$return = array();

		if ($this->db->replace('server_modules', $data)) {
			$return['success'] = 1;
		} else {
			$return['success'] = 0;
		}
		return $return;
 	}
}
?>

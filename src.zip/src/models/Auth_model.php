<?php
class Auth_model extends CI_Model{

	function __construct(){
		parent::__construct();
		$this->load->database();
		$this->load->model('Loginattempt_model');
	}

	/**
	 * Check if login is allowed (rate limiting)
	 *
	 * @param string $email User email
	 * @return array ['allowed' => bool, 'message' => string]
	 */
	function checkRateLimit($email) {
		$ip = $this->input->ip_address();
		return $this->Loginattempt_model->checkLoginAllowed($email, $ip);
	}

	function doLogin($email, $password) {
		$return = array();
		$ip = $this->input->ip_address();
		$user_agent = $this->input->user_agent();

		try {
			// SECURITY: Check rate limiting before processing login
			$rate_check = $this->Loginattempt_model->checkLoginAllowed($email, $ip);
			if (!$rate_check['allowed']) {
				$return['status_code'] = -100; // Rate limited
				$return['message'] = $rate_check['message'];
				$return['minutes_remaining'] = $rate_check['minutes_remaining'];
				return $return;
			}

			// SECURITY FIX: Use prepared statement to prevent SQL injection
			$sql = "SELECT * FROM `users` WHERE users.email = ?";
			$query = $this->db->query($sql, array($email));
			if ($query->num_rows() == 0){
				// Record failed attempt
				$this->Loginattempt_model->recordFailedAttempt($email, $ip, $user_agent);
				$return['status_code'] = -2;
				$return['remaining_attempts'] = $rate_check['remaining_attempts'] - 1;
				return $return;
			}

			// SECURITY FIX: Use prepared statement to prevent SQL injection
			$sql = "SELECT u.*, c.name company, c.address, c.city, c.state, c.zip_code, c.country FROM users u join companies c on u.company_id=c.id WHERE u.email = ? and u.status = 1 and c.status=1";
			$query = $this->db->query($sql, array($email));
			if ($query->num_rows() == 0){
				// Record failed attempt
				$this->Loginattempt_model->recordFailedAttempt($email, $ip, $user_agent);
				$return['status_code'] = -1;
				$return['remaining_attempts'] = $rate_check['remaining_attempts'] - 1;
				return $return;
			}

			$userdata = $query->row();

			$passwordOk = password_verify($password, $userdata->password);

			// LEGACY: registrations before the xss_cleaner fix stored the hash of the
			// CLEANED password. Accept it once, then re-hash to the raw password so the
			// account matches reset / change-password from here on.
			if (!$passwordOk) {
				$legacy = xss_cleaner($password);
				if ($legacy !== $password && $legacy !== '' && password_verify($legacy, $userdata->password)) {
					$passwordOk = true;
					$this->db->query(
						"UPDATE users SET password = ? WHERE id = ?",
						array(password_hash($password, PASSWORD_DEFAULT), $userdata->id)
					);
				}
			}

			if ($passwordOk) {
				$this->Loginattempt_model->clearAllAttempts($email, $ip);

				$resp = array();
				$resp['id'] = $userdata->id;
				$resp['first_name'] = $userdata->first_name;
				$resp['last_name'] = $userdata->last_name;
				$resp['email'] = $userdata->email;
				$resp['mobile'] = $userdata->mobile;
				$resp['phone'] = $userdata->phone;
				$resp['address'] = $userdata->address;
				$resp['zip_code'] = $userdata->zip_code;
				$resp['city'] = $userdata->city;
				$resp['state'] = $userdata->state;
				$resp['country'] = $userdata->country;
				$resp['company'] = $userdata->company;
				$resp['designation'] = $userdata->designation;
				$resp['user_type'] = $userdata->user_type;
				$resp['company_id'] = $userdata->company_id;
				$resp['profile_pic'] = $userdata->profile_pic;
				$resp['terminal'] = getClientIp();

				$logins = array();
				$logins['user_id'] = $userdata->id;
				$logins['login_time'] = getDateTime();
				$logins['session_val'] = 0;
				$logins['terminal'] = $resp['terminal'];
				$this->saveUserLogins($logins);
				$return['status_code'] = 1;
				$return['data'] = $resp;
				return $return;
			}

			// SECURITY: Record failed attempt for wrong password
			$this->Loginattempt_model->recordFailedAttempt($email, $ip, $user_agent);
			$return['status_code'] = 0;
			$return['remaining_attempts'] = $rate_check['remaining_attempts'] - 1;
			return $return;
		} catch (Exception $e) {
			// SECURITY: Log database error
			ErrorHandler::log_database_error('doLogin', $this->db->last_query(), $e->getMessage());
			$return['status_code'] = -99; // Error code for database failure
			return $return;
		}
 	}

 	function saveUserLogins($data){
 		try {
			$data['active'] = 1;
			if ($this->db->insert('user_logins', $data)) {
			}
		} catch (Exception $e) {
			// SECURITY: Log database error
			ErrorHandler::log_database_error('saveUserLogins', $this->db->last_query(), $e->getMessage());
		}
 	}

	/**
	 * Get user session data by user_id
	 * Used to restore session after payment gateway callback
	 *
	 * @param int $userId The user ID
	 * @return array|null User session data or null if not found
	 */
	function getUserSessionData($userId) {
		try {
			$sql = "SELECT u.*, c.name company, c.address, c.city, c.state, c.zip_code, c.country
					FROM users u
					JOIN companies c ON u.company_id = c.id
					WHERE u.id = ? AND u.status = 1 AND c.status = 1";
			$query = $this->db->query($sql, array((int)$userId));

			if ($query->num_rows() == 0) {
				return null;
			}

			$userdata = $query->row();

			$resp = array();
			$resp['id'] = $userdata->id;
			$resp['first_name'] = $userdata->first_name;
			$resp['last_name'] = $userdata->last_name;
			$resp['email'] = $userdata->email;
			$resp['mobile'] = $userdata->mobile;
			$resp['phone'] = $userdata->phone;
			$resp['address'] = $userdata->address;
			$resp['zip_code'] = $userdata->zip_code;
			$resp['city'] = $userdata->city;
			$resp['state'] = $userdata->state;
			$resp['country'] = $userdata->country;
			$resp['company'] = $userdata->company;
			$resp['designation'] = $userdata->designation;
			$resp['user_type'] = $userdata->user_type;
			$resp['company_id'] = $userdata->company_id;
			$resp['profile_pic'] = $userdata->profile_pic;
			$resp['terminal'] = getClientIp();

			return $resp;
		} catch (Exception $e) {
			ErrorHandler::log_database_error('getUserSessionData', $this->db->last_query(), $e->getMessage());
			return null;
		}
	}

	function newRegistration($data) {
		$return = array();

		try {
			// Validate password confirmation
			if (!isset($data['confirm_password']) || $data['password'] !== $data['confirm_password']) {
				$return['success'] = 0;
				$return['error'] = 'Passwords do not match';
				return $return;
			}

			// Validate required address fields
			$requiredFields = array(
				'address' => 'Street Address',
				'city' => 'City',
				'zip_code' => 'ZIP / Postal Code',
				'state' => 'State / Province',
				'country' => 'Country'
			);

			foreach ($requiredFields as $field => $label) {
				if (empty($data[$field])) {
					$return['success'] = 0;
					$return['error'] = $label . ' is required';
					return $return;
				}
			}

			// Validate zip code is numeric
			if (!preg_match('/^[0-9]+$/', $data['zip_code'])) {
				$return['success'] = 0;
				$return['error'] = 'ZIP / Postal Code must contain only numbers';
				return $return;
			}

			// Remove confirm_password as it's not a database column
			unset($data['confirm_password']);

			// Create company record first (address fields belong to companies table)
			$companyData = array(
				'name' => trim($data['first_name'] . ' ' . $data['last_name']),
				'first_name' => $data['first_name'],
				'last_name' => $data['last_name'],
				'email' => $data['email'],
				'mobile' => $data['mobile'],
				'phone' => $data['mobile'],
				'address' => $data['address'],
				'city' => $data['city'],
				'state' => $data['state'],
				'zip_code' => $data['zip_code'],
				'country' => $data['country'],
				'kam_id' => 0,
				'kam_name' => '',
				'status' => 1,
				'inserted_on' => getDateTime()
			);

			if (!$this->db->insert('companies', $companyData)) {
				$return['success'] = 0;
				$return['error'] = 'Failed to create company record';
				return $return;
			}

			$companyId = $this->db->insert_id();

			// Prepare user data (only fields that exist in users table)
			$userData = array(
				'first_name' => $data['first_name'],
				'last_name' => $data['last_name'],
				'email' => $data['email'],
				'mobile' => $data['mobile'],
				'phone' => $data['mobile'],
				'password' => password_hash($data['password'], PASSWORD_DEFAULT),
				'company_id' => $companyId,
				'designation' => 'Company Owner',
				'user_type' => 0,
				'status' => 2,
				'inserted_on' => getDateTime()
			);

			$uniqueVarificationCode = uniqid() . $data['email'] . uniqid() . time();
			$verification_code = hash('sha256', 'TB' . $uniqueVarificationCode);
			$userData['verify_hash'] = $verification_code;

			if ($this->db->insert('users', $userData)) {
				$return['success'] = 1;
				$return['email'] = $data['email'];
				$return['verification_code'] = $verification_code;
			} else {
				// Rollback: delete the company if user creation fails
				$this->db->delete('companies', array('id' => $companyId));
				$return['success'] = 0;
				$return['error'] = 'Failed to create user record';
			}
			return $return;
		} catch (Exception $e) {
			// SECURITY: Log database error
			ErrorHandler::log_database_error('newRegistration', $this->db->last_query(), $e->getMessage());
			$return['success'] = 0;
			$return['error'] = 'Registration failed. Please try again.';
			return $return;
		}
 	}


	public function forgetpaswrd($email)
	{
		try {
			$sql = "SELECT id, first_name, email FROM users WHERE email = ? AND status = 1";
			$query = $this->db->query($sql, array($email));

			if ($query->num_rows() > 0) {
				$user = $query->row();
				$text = trim(gen_uuid().'whmaz'.gen_uuid());
				$token = preg_replace('/[^a-z0-9]/i', '', $text);

				$sql = "UPDATE users SET pass_reset_key = ?, pass_reset_expiry = NOW() + INTERVAL 1 HOUR WHERE id = ?";
				$this->db->query($sql, array($token, $user->id));

				// The controller always reports success (so the form cannot be used to
				// enumerate accounts), which means a failed send is otherwise invisible.
				// Log at 'error' level so it shows up under the production log threshold.
				if (!$this->sendResetLinkEmail($user, $token)) {
					log_message('error', 'forgetpaswrd: reset email FAILED to send to ' . $email . ' (see preceding sendHtmlEmail error)');
				}
			} else {
				// No active user matched. Self-registered accounts sit at status=2 until
				// the address is verified, so an unverified user gets no reset mail.
				log_message('error', 'forgetpaswrd: no active (status=1) user for ' . $email . ' - no reset email sent');
			}

			return 1;
		} catch (Exception $e) {
			ErrorHandler::log_database_error('forgetpaswrd', $this->db->last_query(), $e->getMessage());
			return 0;
		}
	}

	function sendResetLinkEmail($user, $token)
	{
		$appSettings = getAppSettings();

		$resetLink = base_url('auth/resetpassword/' . $token);
		$userName = !empty($user->first_name) ? htmlspecialchars($user->first_name) : 'User';

		// Try to use email template from database
		$this->load->model('Emailtemplate_model');
		$template = $this->Emailtemplate_model->getByKey('password_reset');

		if (!empty($template)) {
			$placeholders = array(
				'{client_name}' => $userName,
				'{site_name}' => $appSettings->company_name,
				'{site_url}' => base_url(),
				'{reset_link}' => $resetLink
			);

			$subject = str_replace(array_keys($placeholders), array_values($placeholders), $template['subject']);
			$body = str_replace(array_keys($placeholders), array_values($placeholders), $template['body']);
		} else {
			// Fallback to hardcoded content
			$body = 'Dear ' . $userName . ',<br><br>';
			$body .= 'We received a request to reset your password.<br><br>';
			$body .= 'Click the link below to set a new password:<br>';
			$body .= '<a href="' . $resetLink . '">Reset Your Password</a><br><br>';
			$body .= 'This link will expire in 1 hour.<br><br>';
			$body .= 'If you did not request this, please ignore this email.<br><br>';
			$body .= 'Thanks & Regards<br>';
			$body .= $appSettings->company_name . ' Support';

			$subject = "Password Reset - " . $appSettings->company_name;
		}

		return sendHtmlEmail($user->email, $subject, $body);
	}

	function sendVerificationEmail($email, $firstName, $verificationCode)
	{
		$appSettings = getAppSettings();
		$verifyLink = base_url('auth/verify/' . $verificationCode);
		$userName = !empty($firstName) ? htmlspecialchars($firstName) : 'User';

		// Use the dedicated email-verification template. (Previously this used
		// 'welcome_email', which has no {verification_link} placeholder, so the
		// verify link never appeared in the email.) If the template is missing,
		// getByKey() returns empty and the hardcoded fallback below — which does
		// contain the verify link — is used instead.
		$this->load->model('Emailtemplate_model');
		$template = $this->Emailtemplate_model->getByKey('email_verification');

		if (!empty($template)) {
			$placeholders = array(
				'{client_name}' => $userName,
				'{site_name}' => $appSettings->company_name,
				'{site_url}' => base_url(),
				'{verification_link}' => $verifyLink
			);

			$subject = str_replace(array_keys($placeholders), array_values($placeholders), $template['subject']);
			$body = str_replace(array_keys($placeholders), array_values($placeholders), $template['body']);
		} else {
			// Fallback to hardcoded content
			$body = 'Dear ' . $userName . ',<br><br>';
			$body .= 'Thank you for registering with us.<br><br>';
			$body .= 'Please click the link below to verify your email address and activate your account:<br>';
			$body .= '<a href="' . $verifyLink . '">Verify My Email</a><br><br>';
			$body .= 'If you did not create this account, please ignore this email.<br><br>';
			$body .= 'Thanks & Regards<br>';
			$body .= $appSettings->company_name . ' Support';

			$subject = "Email Verification - " . $appSettings->company_name;
		}

		return sendHtmlEmail($email, $subject, $body);
	}

	public function validateResetToken($token)
	{
		$sql = "SELECT id, email, first_name FROM users WHERE pass_reset_key = ? AND pass_reset_expiry > NOW() AND status = 1";
		$query = $this->db->query($sql, array($token));

		if ($query->num_rows() == 0) {
			return false;
		}
		return $query->row();
	}

	public function resetPassword($user, $newPassword)
	{
		try {

			$hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
			$sql = "UPDATE users SET password = ?, pass_reset_key = NULL, pass_reset_expiry = NULL WHERE id = ?";
			$this->db->query($sql, array($hashedPassword, $user->id));

			return true;
		} catch (Exception $e) {
			ErrorHandler::log_database_error('resetPassword', $this->db->last_query(), $e->getMessage());
			return false;
		}
	}

 	function verifyUser($verificationCode){
 		$return = 0;

		try {
			$this->db->select('id');
			$this->db->from('users');
			$this->db->where(array(
				'verify_hash'=>$verificationCode,
				'status'=>'2'
			));
			$num_results = $this->db->count_all_results();
			if ($num_results == 1) {
				$data['status'] = '1';
				$this->db->where('verify_hash', $verificationCode);
				if($this->db->update('users', $data)) {
					$return = 1;
				}
			}
			return $return;
		} catch (Exception $e) {
			// SECURITY: Log database error
			ErrorHandler::log_database_error('verifyUser', $this->db->last_query(), $e->getMessage());
			return 0;
		}
 	}

 	function countDbSession($user_id){
		try {
			$this->db->select('id');
			$this->db->from('user_logins');
			$this->db->where(array(
				'user_id'=>$user_id,
				'active'=>1
			));
			$num_results = $this->db->count_all_results();

			return $num_results;
		} catch (Exception $e) {
			// SECURITY: Log database error
			ErrorHandler::log_database_error('countDbSession', $this->db->last_query(), $e->getMessage());
			return 0;
		}
	}

	function isEmailExists($email){
		try {
			$this->db->select('id');
			$this->db->from('users');
			$this->db->where(array(
				'email'=>$email
			));
			$num_results = $this->db->count_all_results();

			return $num_results;
		} catch (Exception $e) {
			// SECURITY: Log database error
			ErrorHandler::log_database_error('isEmailExists', $this->db->last_query(), $e->getMessage());
			return 0;
		}
	}
}
?>

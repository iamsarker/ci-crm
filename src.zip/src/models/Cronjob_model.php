<?php
/**
 * Cronjob Model
 *
 * Handles automated tasks like renewal invoice generation, dunning, etc.
 * Following WHMCS best practices for billing automation.
 */
class Cronjob_model extends CI_Model
{
	// Days before expiry to generate renewal invoice
	const RENEWAL_INVOICE_DAYS_BEFORE = 15;

	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	/**
	 * Get services expiring within specified days that need renewal invoices
	 * Excludes: one-time services, already invoiced renewals, inactive services
	 *
	 * @param int $daysBeforeExpiry Days before expiry to look for
	 * @return array List of expiring services
	 */
	function getExpiringServices($daysBeforeExpiry = 15)
	{
		$targetDate = date('Y-m-d', strtotime("+{$daysBeforeExpiry} days"));
		$today = date('Y-m-d');

		$sql = "SELECT os.*,
					o.currency_id, o.currency_code,
					c.id as company_id, c.name as company_name, c.email as company_email,
					c.first_name, c.last_name,
					ps.product_name,
					bc.cycle_key, bc.cycle_name, bc.cycle_days
				FROM order_services os
				JOIN orders o ON os.order_id = o.id
				JOIN companies c ON os.company_id = c.id
				JOIN product_services ps ON os.product_service_id = ps.id
				JOIN billing_cycle bc ON os.billing_cycle_id = bc.id
				WHERE os.status = 1
				AND os.next_renewal_date <= ?
				AND os.next_renewal_date >= ?
				AND bc.cycle_days > 0
				AND os.auto_renew = 1
				AND os.deleted_on IS NULL
				AND NOT EXISTS (
					SELECT 1 FROM invoice_items ii
					JOIN invoices i ON ii.invoice_id = i.id
					WHERE ii.ref_id = os.id
					AND ii.item_type = 2
					AND i.status = 1
					AND ii.billing_period_start = os.next_renewal_date
				)
				ORDER BY os.next_renewal_date ASC";

		return $this->db->query($sql, array($targetDate, $today))->result_array();
	}

	/**
	 * Get software licenses expiring within specified days that need renewal
	 * invoices. Excludes perpetual (cycle_days=0), already-invoiced renewals,
	 * and non-active/non-auto-renew licenses.
	 *
	 * @param int $daysBeforeExpiry
	 * @return array List of expiring licenses (item_type=3)
	 */
	function getExpiringLicenses($daysBeforeExpiry = 15)
	{
		$targetDate = date('Y-m-d', strtotime("+{$daysBeforeExpiry} days"));
		$today = date('Y-m-d');

		$sql = "SELECT ol.*,
					c.name as company_name, c.email as company_email,
					c.first_name, c.last_name,
					p.name as product_name,
					bc.cycle_key, bc.cycle_name, bc.cycle_days
				FROM order_licenses ol
				JOIN companies c ON ol.company_id = c.id
				JOIN plans p ON ol.plan_id = p.id
				JOIN billing_cycle bc ON ol.billing_cycle_id = bc.id
				WHERE ol.status = 1
				AND ol.next_renewal_date <= ?
				AND ol.next_renewal_date >= ?
				AND bc.cycle_days > 0
				AND ol.auto_renew = 1
				AND ol.deleted_on IS NULL
				AND NOT EXISTS (
					SELECT 1 FROM invoice_items ii
					JOIN invoices i ON ii.invoice_id = i.id
					WHERE ii.ref_id = ol.id
					AND ii.item_type = 3
					AND i.status = 1
					AND ii.billing_period_start = ol.next_renewal_date
				)
				ORDER BY ol.next_renewal_date ASC";

		return $this->db->query($sql, array($targetDate, $today))->result_array();
	}

	/**
	 * Get domains expiring within specified days that need renewal invoices
	 * Excludes: already invoiced renewals, inactive domains
	 *
	 * @param int $daysBeforeExpiry Days before expiry to look for
	 * @return array List of expiring domains
	 */
	function getExpiringDomains($daysBeforeExpiry = 15)
	{
		$targetDate = date('Y-m-d', strtotime("+{$daysBeforeExpiry} days"));
		$today = date('Y-m-d');

		$sql = "SELECT od.*,
					od.linked_service_id,
					o.currency_id, o.currency_code,
					c.id as company_id, c.name as company_name, c.email as company_email,
					c.first_name, c.last_name,
					dp.renewal as renewal_price, de.extension
				FROM order_domains od
				JOIN orders o ON od.order_id = o.id
				JOIN companies c ON od.company_id = c.id
				JOIN dom_pricing dp ON od.dom_pricing_id = dp.id AND dp.currency_id = o.currency_id
				JOIN dom_extensions de ON dp.dom_extension_id = de.id
				WHERE od.status = 1
				AND od.next_renewal_date <= ?
				AND od.next_renewal_date >= ?
				AND od.auto_renew = 1
				AND od.deleted_on IS NULL
				AND NOT EXISTS (
					SELECT 1 FROM invoice_items ii
					JOIN invoices i ON ii.invoice_id = i.id
					WHERE ii.ref_id = od.id
					AND ii.item_type = 1
					AND i.status = 1
					AND ii.billing_period_start = od.next_renewal_date
				)
				ORDER BY od.next_renewal_date ASC";

		$rows = $this->db->query($sql, array($targetDate, $today))->result_array();

		// ---------------------------------------------------------------
		// LIVE pricing for domain renewals (v2.0.0 Phase 2).
		//
		// dp.renewal above is the PLATFORM's renewal price. Billing a
		// reseller's customer from it is a straight revenue leak the moment
		// resellers exist -- the reseller sets the price, the platform must
		// not quietly bill the customer its own.
		//
		// The join stays as a FILTER (it is what requires a price row in the
		// order's currency, and it supplies de.extension); only the price it
		// produced is replaced. Ripping the join out would silently change
		// which domains get invoiced at all.
		//
		// Domains are priced LIVE, unlike hosting and software which renew
		// from their frozen recurring_amount -- registrar wholesale moves have
		// to pass through, and both parties expect a price change to apply at
		// the next renewal rather than a year later.
		// ---------------------------------------------------------------
		$this->load->model('Pricing_model');
		foreach ($rows as &$row) {
			$r = $this->Pricing_model->resolve(1, $row['dom_pricing_id'], $row['company_id']);
			if (empty($r)) continue;
			$row['renewal_price'] = $r['renewal'];
			$row['renewal_cost']  = $r['cost_renewal'];
		}
		unset($row);

		return $rows;
	}

	/**
	 * Get linked service data for a domain if it has the same renewal date
	 * Used to combine domain+service into a single renewal invoice
	 *
	 * @param int $serviceId The linked order_services.id
	 * @param string $renewalDate The domain's next_renewal_date (Y-m-d)
	 * @return array|null Service data or null if not eligible
	 */
	function getLinkedExpiringService($serviceId, $renewalDate)
	{
		$sql = "SELECT os.*,
					o.currency_id, o.currency_code,
					c.id as company_id, c.name as company_name, c.email as company_email,
					c.first_name, c.last_name,
					ps.product_name,
					bc.cycle_key, bc.cycle_name, bc.cycle_days
				FROM order_services os
				JOIN orders o ON os.order_id = o.id
				JOIN companies c ON os.company_id = c.id
				JOIN product_services ps ON os.product_service_id = ps.id
				JOIN billing_cycle bc ON os.billing_cycle_id = bc.id
				WHERE os.id = ?
				AND os.status = 1
				AND os.next_renewal_date = ?
				AND bc.cycle_days > 0
				AND os.auto_renew = 1
				AND os.deleted_on IS NULL
				AND NOT EXISTS (
					SELECT 1 FROM invoice_items ii
					JOIN invoices i ON ii.invoice_id = i.id
					WHERE ii.ref_id = os.id
					AND ii.item_type = 2
					AND i.status = 1
					AND ii.billing_period_start = os.next_renewal_date
				)";

		$result = $this->db->query($sql, array($serviceId, $renewalDate))->row_array();
		return !empty($result) ? $result : null;
	}

	/**
	 * Create a combined renewal invoice for a linked domain + service
	 *
	 * @param array $domain Domain data from getExpiringDomains()
	 * @param array $service Service data from getLinkedExpiringService()
	 * @return array Invoice data with success status
	 */
	function createCombinedRenewalInvoice($domain, $service)
	{
		$this->db->trans_start();

		try {
			// === Domain billing period ===
			$domainBillingStart = $domain['next_renewal_date'];
			$yearsToRenew = !empty($domain['reg_period']) ? intval($domain['reg_period']) : 1;
			$domainBillingEnd = date('Y-m-d', strtotime($domainBillingStart . " +{$yearsToRenew} years"));
			$domainAmount = floatval($domain['renewal_price']) * $yearsToRenew;

			// === Service billing period ===
			$serviceBillingStart = $service['next_renewal_date'];
			$serviceBillingEnd = date('Y-m-d', strtotime($serviceBillingStart . " +{$service['cycle_days']} days"));
			$serviceAmount = floatval($service['recurring_amount']);

			$totalAmount = $domainAmount + $serviceAmount;

			// Invoice due_date: next_renewal_date + 7 days
			$invoiceDueDate = date('Y-m-d', strtotime($domainBillingStart . " +7 days"));

			// Create invoice
			$invoice = array(
				'invoice_uuid' => gen_uuid(),
				'company_id' => $domain['company_id'],
				'order_id' => $domain['order_id'],
				'currency_id' => $domain['currency_id'],
				'currency_code' => $domain['currency_code'],
				'invoice_no' => $this->generateNumber('INVOICE'),
				'sub_total' => $totalAmount,
				'tax' => 0.00,
				'vat' => 0.00,
				'total' => $totalAmount,
				'order_date' => date('Y-m-d'),
				'due_date' => $invoiceDueDate,
				'status' => 1,
				'pay_status' => 'DUE',
				'remarks' => 'Auto-generated combined renewal invoice',
				'inserted_on' => date('Y-m-d H:i:s'),
				'inserted_by' => 0
			);

			$this->db->insert('invoices', $invoice);
			$invoiceId = $this->db->insert_id();

			// === Domain invoice item ===
			$domainItemDesc = "Domain Renewal - {$domain['domain']} - {$yearsToRenew} Year(s)";
			$domainItemDesc .= " ({$domainBillingStart} to {$domainBillingEnd})";

			$this->db->insert('invoice_items', array(
				'invoice_id' => $invoiceId,
				'item' => 'Domain Renewal',
				'item_desc' => $domainItemDesc,
				'item_type' => 1,
				'is_renewal' => 1,
				'ref_id' => $domain['id'],
				'billing_cycle_id' => $this->getYearlyBillingCycleId(),
				'quantity' => $yearsToRenew,
				'unit_price' => floatval($domain['renewal_price']),
				'discount' => 0.00,
				'sub_total' => $domainAmount,
				'tax' => 0.00,
				'vat' => 0.00,
				'total' => $domainAmount,
				'billing_period_start' => $domainBillingStart,
				'billing_period_end' => $domainBillingEnd,
				'inserted_on' => date('Y-m-d H:i:s'),
				'inserted_by' => 0
			));

			// === Service invoice item ===
			$serviceItemDesc = "Renewal - {$service['product_name']}";
			if (!empty($service['hosting_domain'])) {
				$serviceItemDesc .= " ({$service['hosting_domain']})";
			}
			$serviceItemDesc .= " - {$service['cycle_name']}";
			$serviceItemDesc .= " ({$serviceBillingStart} to {$serviceBillingEnd})";

			$this->db->insert('invoice_items', array(
				'invoice_id' => $invoiceId,
				'item' => 'Service Renewal',
				'item_desc' => $serviceItemDesc,
				'item_type' => 2,
				'is_renewal' => 1,
				'ref_id' => $service['id'],
				'billing_cycle_id' => $service['billing_cycle_id'],
				'quantity' => 1,
				'unit_price' => $serviceAmount,
				'discount' => 0.00,
				'sub_total' => $serviceAmount,
				'tax' => 0.00,
				'vat' => 0.00,
				'total' => $serviceAmount,
				'billing_period_start' => $serviceBillingStart,
				'billing_period_end' => $serviceBillingEnd,
				'inserted_on' => date('Y-m-d H:i:s'),
				'inserted_by' => 0
			));

			// Only the DOMAIN line re-freezes its cost: domains renew live
			// through the resolver, while the service renews from its frozen
			// recurring_amount and its checkout-time cost still stands.
			$renewalCost = round(floatval(isset($domain['renewal_cost']) ? $domain['renewal_cost'] : 0) * $yearsToRenew, 2);
			$this->db->where('id', $domain['id'])->update('order_domains', array('cost_amount' => $renewalCost));

			$this->db->trans_complete();

			if ($this->db->trans_status() === FALSE) {
				return array('success' => false, 'error' => 'Database transaction failed');
			}

			$invoice['id'] = $invoiceId;
			return array(
				'success' => true,
				'invoice' => $invoice,
				'domain' => $domain,
				'service' => $service,
				'combined' => true
			);

		} catch (Exception $e) {
			$this->db->trans_rollback();
			log_message('error', 'createCombinedRenewalInvoice error: ' . $e->getMessage());
			return array('success' => false, 'error' => $e->getMessage());
		}
	}

	/**
	 * Create renewal invoice for a service
	 *
	 * @param array $service Service data from getExpiringServices()
	 * @return array Invoice data with success status
	 */
	function createServiceRenewalInvoice($service)
	{
		$this->db->trans_start();

		try {
			// Calculate new billing period
			$billingPeriodStart = $service['next_renewal_date'];
			$billingPeriodEnd = date('Y-m-d', strtotime($billingPeriodStart . " +{$service['cycle_days']} days"));
			$renewalAmount = floatval($service['recurring_amount']);

			// Invoice due_date: next_renewal_date + 7 days
			$invoiceDueDate = date('Y-m-d', strtotime($billingPeriodStart . " +7 days"));

			// Create invoice
			$invoice = array(
				'invoice_uuid' => gen_uuid(),
				'company_id' => $service['company_id'],
				'order_id' => $service['order_id'],
				'currency_id' => $service['currency_id'],
				'currency_code' => $service['currency_code'],
				'invoice_no' => $this->generateNumber('INVOICE'),
				'sub_total' => $renewalAmount,
				'tax' => 0.00,
				'vat' => 0.00,
				'total' => $renewalAmount,
				'order_date' => date('Y-m-d'),
				'due_date' => $invoiceDueDate,
				'status' => 1,
				'pay_status' => 'DUE',
				'remarks' => 'Auto-generated renewal invoice',
				'inserted_on' => date('Y-m-d H:i:s'),
				'inserted_by' => 0 // System generated
			);

			$this->db->insert('invoices', $invoice);
			$invoiceId = $this->db->insert_id();

			// Create invoice item
			$itemDesc = "Renewal - {$service['product_name']}";
			if (!empty($service['hosting_domain'])) {
				$itemDesc .= " ({$service['hosting_domain']})";
			}
			$itemDesc .= " - {$service['cycle_name']}";
			$itemDesc .= " ({$billingPeriodStart} to {$billingPeriodEnd})";

			$invoiceItem = array(
				'invoice_id' => $invoiceId,
				'item' => 'Service Renewal',
				'item_desc' => $itemDesc,
				'item_type' => 2, // 2 = service
				'is_renewal' => 1,
				'ref_id' => $service['id'],
				'billing_cycle_id' => $service['billing_cycle_id'],
				'quantity' => 1,
				'unit_price' => $renewalAmount,
				'discount' => 0.00,
				'sub_total' => $renewalAmount,
				'tax' => 0.00,
				'vat' => 0.00,
				'total' => $renewalAmount,
				'billing_period_start' => $billingPeriodStart,
				'billing_period_end' => $billingPeriodEnd,
				'inserted_on' => date('Y-m-d H:i:s'),
				'inserted_by' => 0
			);

			$this->db->insert('invoice_items', $invoiceItem);

			$this->db->trans_complete();

			if ($this->db->trans_status() === FALSE) {
				return array('success' => false, 'error' => 'Database transaction failed');
			}

			$invoice['id'] = $invoiceId;
			return array(
				'success' => true,
				'invoice' => $invoice,
				'service' => $service
			);

		} catch (Exception $e) {
			$this->db->trans_rollback();
			log_message('error', 'createServiceRenewalInvoice error: ' . $e->getMessage());
			return array('success' => false, 'error' => $e->getMessage());
		}
	}

	/**
	 * Create renewal invoice for a software license (item_type=3). When paid,
	 * provisioning detects it as a renewal and extends the license via
	 * Orderlicense_model::activateLicense(isRenewal=true).
	 *
	 * @param array $license Data from getExpiringLicenses()
	 * @return array Invoice data with success status
	 */
	function createLicenseRenewalInvoice($license)
	{
		$this->db->trans_start();

		try {
			$billingPeriodStart = $license['next_renewal_date'];
			$billingPeriodEnd = date('Y-m-d', strtotime($billingPeriodStart . " +{$license['cycle_days']} days"));
			$renewalAmount = floatval($license['recurring_amount']);

			$invoiceDueDate = date('Y-m-d', strtotime($billingPeriodStart . " +7 days"));

			$invoice = array(
				'invoice_uuid' => gen_uuid(),
				'company_id' => $license['company_id'],
				'order_id' => $license['order_id'],
				'currency_id' => $license['currency_id'],
				'currency_code' => $license['currency_code'],
				'invoice_no' => $this->generateNumber('INVOICE'),
				'sub_total' => $renewalAmount,
				'tax' => 0.00,
				'vat' => 0.00,
				'total' => $renewalAmount,
				'order_date' => date('Y-m-d'),
				'due_date' => $invoiceDueDate,
				'status' => 1,
				'pay_status' => 'DUE',
				'remarks' => 'Auto-generated license renewal invoice',
				'inserted_on' => date('Y-m-d H:i:s'),
				'inserted_by' => 0
			);

			$this->db->insert('invoices', $invoice);
			$invoiceId = $this->db->insert_id();

			$itemDesc = "Renewal - {$license['product_name']}";
			$itemDesc .= " - {$license['cycle_name']}";
			$itemDesc .= " ({$billingPeriodStart} to {$billingPeriodEnd})";

			$invoiceItem = array(
				'invoice_id' => $invoiceId,
				'item' => 'Software Renewal',
				'item_desc' => $itemDesc,
				'item_type' => 3, // 3 = license/software
				'is_renewal' => 1,
				'ref_id' => $license['id'],
				'billing_cycle_id' => $license['billing_cycle_id'],
				'quantity' => 1,
				'unit_price' => $renewalAmount,
				'discount' => 0.00,
				'sub_total' => $renewalAmount,
				'tax' => 0.00,
				'vat' => 0.00,
				'total' => $renewalAmount,
				'billing_period_start' => $billingPeriodStart,
				'billing_period_end' => $billingPeriodEnd,
				'inserted_on' => date('Y-m-d H:i:s'),
				'inserted_by' => 0
			);

			$this->db->insert('invoice_items', $invoiceItem);

			$this->db->trans_complete();

			if ($this->db->trans_status() === FALSE) {
				return array('success' => false, 'error' => 'Database transaction failed');
			}

			$invoice['id'] = $invoiceId;
			return array(
				'success' => true,
				'invoice' => $invoice,
				'license' => $license
			);

		} catch (Exception $e) {
			$this->db->trans_rollback();
			log_message('error', 'createLicenseRenewalInvoice error: ' . $e->getMessage());
			return array('success' => false, 'error' => $e->getMessage());
		}
	}

	/**
	 * Create renewal invoice for a domain
	 *
	 * @param array $domain Domain data from getExpiringDomains()
	 * @return array Invoice data with success status
	 */
	function createDomainRenewalInvoice($domain)
	{
		$this->db->trans_start();

		try {
			// Calculate new billing period (domains are always yearly based on reg_period)
			$billingPeriodStart = $domain['next_renewal_date'];
			$yearsToRenew = !empty($domain['reg_period']) ? intval($domain['reg_period']) : 1;
			$billingPeriodEnd = date('Y-m-d', strtotime($billingPeriodStart . " +{$yearsToRenew} years"));
			$renewalAmount = floatval($domain['renewal_price']) * $yearsToRenew;

			// Invoice due_date: next_renewal_date + 7 days
			$invoiceDueDate = date('Y-m-d', strtotime($billingPeriodStart . " +7 days"));

			// Create invoice
			$invoice = array(
				'invoice_uuid' => gen_uuid(),
				'company_id' => $domain['company_id'],
				'order_id' => $domain['order_id'],
				'currency_id' => $domain['currency_id'],
				'currency_code' => $domain['currency_code'],
				'invoice_no' => $this->generateNumber('INVOICE'),
				'sub_total' => $renewalAmount,
				'tax' => 0.00,
				'vat' => 0.00,
				'total' => $renewalAmount,
				'order_date' => date('Y-m-d'),
				'due_date' => $invoiceDueDate,
				'status' => 1,
				'pay_status' => 'DUE',
				'remarks' => 'Auto-generated domain renewal invoice',
				'inserted_on' => date('Y-m-d H:i:s'),
				'inserted_by' => 0
			);

			$this->db->insert('invoices', $invoice);
			$invoiceId = $this->db->insert_id();

			// Create invoice item
			$itemDesc = "Domain Renewal - {$domain['domain']} - {$yearsToRenew} Year(s)";
			$itemDesc .= " ({$billingPeriodStart} to {$billingPeriodEnd})";

			$invoiceItem = array(
				'invoice_id' => $invoiceId,
				'item' => 'Domain Renewal',
				'item_desc' => $itemDesc,
				'item_type' => 1, // 1 = domain
				'is_renewal' => 1,
				'ref_id' => $domain['id'],
				'billing_cycle_id' => $this->getYearlyBillingCycleId(),
				'quantity' => $yearsToRenew,
				'unit_price' => floatval($domain['renewal_price']),
				'discount' => 0.00,
				'sub_total' => $renewalAmount,
				'tax' => 0.00,
				'vat' => 0.00,
				'total' => $renewalAmount,
				'billing_period_start' => $billingPeriodStart,
				'billing_period_end' => $billingPeriodEnd,
				'inserted_on' => date('Y-m-d H:i:s'),
				'inserted_by' => 0
			);

			$this->db->insert('invoice_items', $invoiceItem);

			// Re-freeze the cost basis for the term now being billed. Phase 3
			// debits the reseller's wallet from order_domains.cost_amount, and
			// a renewal does not cost what the registration cost -- leaving the
			// original snapshot in place would debit a first-year price on
			// every renewal for the life of the domain.
			$renewalCost = round(floatval(isset($domain['renewal_cost']) ? $domain['renewal_cost'] : 0) * $yearsToRenew, 2);
			$this->db->where('id', $domain['id'])->update('order_domains', array('cost_amount' => $renewalCost));


			$this->db->trans_complete();

			if ($this->db->trans_status() === FALSE) {
				return array('success' => false, 'error' => 'Database transaction failed');
			}

			$invoice['id'] = $invoiceId;
			return array(
				'success' => true,
				'invoice' => $invoice,
				'domain' => $domain
			);

		} catch (Exception $e) {
			$this->db->trans_rollback();
			log_message('error', 'createDomainRenewalInvoice error: ' . $e->getMessage());
			return array('success' => false, 'error' => $e->getMessage());
		}
	}

	/**
	 * Generate sequential number for invoices/orders
	 *
	 * @param string $noType Type: ORDER, INVOICE
	 * @return int Generated number
	 */
	function generateNumber($noType)
	{
		$this->db->select('id, last_no');
		$this->db->from('gen_numbers');
		$this->db->where('no_type', strtoupper($noType));
		$data = $this->db->get();

		$lastNo = 100;
		$id = 0;

		if ($data && $data->num_rows() > 0) {
			$res = $data->row();
			$id = $res->id;
			$lastNo = $res->last_no + 1;
		} else {
			$lastNo = 101;
		}

		$this->db->where('id', $id);
		$this->db->update('gen_numbers', array(
			'no_type' => strtoupper($noType),
			'last_no' => $lastNo
		));

		return $lastNo;
	}

	/**
	 * Get hosting services that should be suspended due to overdue invoices.
	 *
	 * A service is a candidate when it is still Active, has been successfully provisioned
	 * on a real control panel, and has at least one unpaid invoice whose due_date was at
	 * least $daysAfterDue days ago.
	 *
	 * Returned rows may contain multiple entries per service (one per qualifying invoice).
	 * The caller should dedupe by service_id and treat the first (oldest) row as the
	 * triggering invoice.
	 *
	 * @param int $daysAfterDue How many days past due_date before suspension
	 * @return array
	 */
	function getServicesOverdueForSuspension($daysAfterDue)
	{
		$daysAfterDue = max(0, intval($daysAfterDue));

		$sql = "SELECT os.id AS service_id,
					os.company_id, os.order_id, os.product_service_id,
					os.cp_username, os.hosting_domain,
					sm.module_name,
					ps.product_name,
					c.email AS customer_email,
					c.first_name, c.last_name,
					c.name AS company_name_customer,
					i.id AS invoice_id,
					i.invoice_uuid, i.invoice_no, i.total, i.due_date,
					i.currency_code, i.currency_id,
					cu.symbol AS currency_symbol,
					DATEDIFF(CURDATE(), i.due_date) AS days_overdue
				FROM order_services os
				JOIN invoice_items ii ON ii.ref_id = os.id AND ii.item_type = 2
				JOIN invoices i ON ii.invoice_id = i.id
				JOIN product_services ps ON os.product_service_id = ps.id
				JOIN servers s ON ps.server_id = s.id
				JOIN server_modules sm ON s.product_service_module_id = sm.id
				JOIN companies c ON os.company_id = c.id
				LEFT JOIN currencies cu ON i.currency_id = cu.id
				WHERE os.status = 1
				  AND os.is_synced = 1
				  AND os.cp_username IS NOT NULL
				  AND os.cp_username != ''
				  AND os.deleted_on IS NULL
				  AND i.status = 1
				  AND i.pay_status = 'DUE'
				  AND DATE_ADD(i.due_date, INTERVAL ? DAY) <= CURDATE()
				  AND LOWER(sm.module_name) IN ('cpanel', 'plesk', 'directadmin')
				ORDER BY os.id ASC, i.due_date ASC";

		return $this->db->query($sql, array($daysAfterDue))->result_array();
	}

	/**
	 * Get suspended hosting services that should be terminated because they have
	 * remained suspended (status=3) for at least $daysAfterSuspension days while
	 * their invoice is still unpaid.
	 *
	 * Grace model (WHMCS-style): Active --(suspension_days_after_due)--> Suspended
	 * --(cancellation_days_after_suspension)--> Terminated. The grace window is
	 * measured from order_services.suspension_date (set when the service was
	 * suspended), not from the invoice due_date.
	 *
	 * Only services on a real control panel are candidates; the still-DUE invoice
	 * requirement guards against terminating a service whose invoice was paid but
	 * which was never unsuspended. Rows may repeat per qualifying invoice; the
	 * caller should dedupe by service_id and treat the first (oldest) as the trigger.
	 *
	 * @param int $daysAfterSuspension How many days past suspension_date before terminating
	 * @return array
	 */
	function getServicesOverdueForTermination($daysAfterSuspension)
	{
		$daysAfterSuspension = max(0, intval($daysAfterSuspension));

		$sql = "SELECT os.id AS service_id,
					os.company_id, os.order_id, os.product_service_id,
					os.cp_username, os.hosting_domain, os.suspension_date,
					sm.module_name,
					ps.product_name,
					c.email AS customer_email,
					c.first_name, c.last_name,
					c.name AS company_name_customer,
					i.id AS invoice_id,
					i.invoice_uuid, i.invoice_no, i.total, i.due_date,
					i.currency_code, i.currency_id,
					cu.symbol AS currency_symbol,
					DATEDIFF(CURDATE(), i.due_date) AS days_overdue,
					DATEDIFF(CURDATE(), os.suspension_date) AS days_suspended
				FROM order_services os
				JOIN invoice_items ii ON ii.ref_id = os.id AND ii.item_type = 2
				JOIN invoices i ON ii.invoice_id = i.id
				JOIN product_services ps ON os.product_service_id = ps.id
				JOIN servers s ON ps.server_id = s.id
				JOIN server_modules sm ON s.product_service_module_id = sm.id
				JOIN companies c ON os.company_id = c.id
				LEFT JOIN currencies cu ON i.currency_id = cu.id
				WHERE os.status = 3
				  AND os.suspension_date IS NOT NULL
				  AND os.is_synced = 1
				  AND os.cp_username IS NOT NULL
				  AND os.cp_username != ''
				  AND os.deleted_on IS NULL
				  AND i.status = 1
				  AND i.pay_status = 'DUE'
				  AND DATE_ADD(os.suspension_date, INTERVAL ? DAY) <= CURDATE()
				  AND LOWER(sm.module_name) IN ('cpanel', 'plesk', 'directadmin')
				ORDER BY os.id ASC, i.due_date ASC";

		return $this->db->query($sql, array($daysAfterSuspension))->result_array();
	}

	/**
	 * Get active licenses whose invoice is overdue by >= $daysAfterDue days.
	 *
	 * Self-hosted: there's no server module to join — suspension is soft (status
	 * only), enforced when the install phones home. Mirrors
	 * getServicesOverdueForSuspension() otherwise. Sorted so the oldest overdue
	 * invoice per license is the trigger row.
	 *
	 * @param int $daysAfterDue
	 * @return array
	 */
	function getLicensesOverdueForSuspension($daysAfterDue)
	{
		$daysAfterDue = max(0, intval($daysAfterDue));

		$sql = "SELECT ol.id AS license_id,
					ol.company_id, ol.order_id, ol.plan_id, ol.license_domain,
					p.plan_key, p.name AS plan_name,
					c.email AS customer_email,
					c.first_name, c.last_name,
					c.name AS company_name_customer,
					i.id AS invoice_id,
					i.invoice_uuid, i.invoice_no, i.total, i.due_date,
					i.currency_code, i.currency_id,
					cu.symbol AS currency_symbol,
					DATEDIFF(CURDATE(), i.due_date) AS days_overdue
				FROM order_licenses ol
				JOIN invoice_items ii ON ii.ref_id = ol.id AND ii.item_type = 3
				JOIN invoices i ON ii.invoice_id = i.id
				JOIN plans p ON ol.plan_id = p.id
				JOIN companies c ON ol.company_id = c.id
				LEFT JOIN currencies cu ON i.currency_id = cu.id
				WHERE ol.status = 1
				  AND ol.deleted_on IS NULL
				  AND i.status = 1
				  AND i.pay_status = 'DUE'
				  AND DATE_ADD(i.due_date, INTERVAL ? DAY) <= CURDATE()
				ORDER BY ol.id ASC, i.due_date ASC";

		return $this->db->query($sql, array($daysAfterDue))->result_array();
	}

	/**
	 * Get email template by key
	 *
	 * @param string $templateKey Template key
	 * @return array Template data
	 */
	function getEmailTemplate($templateKey)
	{
		$this->db->select('*');
		$this->db->from('email_templates');
		$this->db->where('template_key', $templateKey);
		$this->db->where('status', 1);
		$data = $this->db->get();

		if ($data && $data->num_rows() > 0) {
			return $data->row_array();
		}
		return array();
	}

	/**
	 * Get app settings from app_settings table
	 *
	 * @return array Settings row as associative array
	 */
	function getAppSettings()
	{
		$this->db->select('*');
		$this->db->from('app_settings');
		$this->db->limit(1);
		$data = $this->db->get()->row_array();

		return !empty($data) ? $data : array();
	}

	/**
	 * Get a single system configuration value from sys_cnf table
	 *
	 * @param string $key Configuration key
	 * @param mixed $default Default value if not found
	 * @return mixed Configuration value
	 */
	function getSysConfig($key, $default = null)
	{
		$this->db->select('cnf_val');
		$this->db->from('sys_cnf');
		$this->db->where('cnf_key', $key);
		$data = $this->db->get()->row();

		return $data ? $data->cnf_val : $default;
	}

	/**
	 * Log cronjob execution
	 *
	 * @param string $jobType Type of job
	 * @param string $status Status (success/failed)
	 * @param string $details Details/message
	 * @param int $itemsProcessed Number of items processed
	 */
	function logCronjobExecution($jobType, $status, $details = '', $itemsProcessed = 0)
	{
		$this->db->insert('cron_jobs', array(
			'job_type' => $jobType,
			'status' => $status,
			'details' => $details,
			'items_processed' => $itemsProcessed,
			'executed_on' => date('Y-m-d H:i:s')
		));
	}

	/**
	 * Update service/domain renewal dates after payment
	 * This should be called when invoice is marked as paid
	 *
	 * @param int $invoiceId Invoice ID
	 * @return bool Success status
	 */
	function updateNextDueDateAfterPayment($invoiceId)
	{
		// Get invoice items
		$this->db->select('*');
		$this->db->from('invoice_items');
		$this->db->where('invoice_id', $invoiceId);
		$items = $this->db->get()->result_array();

		foreach ($items as $item) {
			if (empty($item['ref_id']) || empty($item['billing_period_end'])) {
				continue;
			}

			// Calculate new due_date: next_renewal_date + 7 days
			$newDueDate = date('Y-m-d', strtotime($item['billing_period_end'] . " +7 days"));

			if ($item['item_type'] == 1) {
				// Domain
				$this->db->where('id', $item['ref_id']);
				$this->db->update('order_domains', array(
					'next_renewal_date' => $item['billing_period_end'],
					'due_date' => $newDueDate,
					'exp_date' => $item['billing_period_end'],
					'suspension_date' => null,
					'suspension_reason' => null,
					'termination_date' => null,
					'updated_on' => date('Y-m-d H:i:s')
				));
			} elseif ($item['item_type'] == 2) {
				// Service
				$this->db->where('id', $item['ref_id']);
				$this->db->update('order_services', array(
					'next_renewal_date' => $item['billing_period_end'],
					'due_date' => $newDueDate,
					'exp_date' => $item['billing_period_end'],
					'suspension_date' => null,
					'suspension_reason' => null,
					'termination_date' => null,
					'updated_on' => date('Y-m-d H:i:s')
				));
			}
		}

		return true;
	}

	/**
	 * Get billing_cycle ID for YEARLY cycle_key
	 * @return int
	 */
	function getYearlyBillingCycleId()
	{
		$row = $this->db->query("SELECT id FROM billing_cycle WHERE cycle_key = 'YEARLY' AND status = 1 LIMIT 1")->row();
		return $row ? intval($row->id) : 4;
	}
}
?>

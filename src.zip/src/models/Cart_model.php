<?php

class Cart_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
		$this->load->database();
		// Two-tier pricing (v2.0.0 Phase 2). Every price this model hands out
		// goes through the resolver so a reseller's sub-customer sees the
		// reseller's price, not the platform's. For a buyer with no reseller
		// above them the resolver short-circuits to the native table, so the
		// direct-customer path is unchanged.
		$this->load->model('Pricing_model');
	}

	function getServiceTypes()
	{

		$sql = "SELECT id, servce_type_name FROM product_service_types WHERE status=1 order by sort_order ";
		$data = $this->db->query($sql)->result_array();
		return $data;
	}

	function getServiceGroups()
	{

		$sql = "SELECT id, group_name, group_headline, tags FROM product_service_groups WHERE status=1 ";
		$data = $this->db->query($sql)->result_array();
		return $data;
	}

	function getProductServiceItemsDetails()
	{
		$sql = "SELECT ps.id, ps.product_name, ps.product_desc, ps.payment_type, psp.price FROM product_services ps WHERE ps.id = 1 ";
		$data = $this->db->query($sql)->result_array();
		return $data;
	}

	function getProductServiceItems($stype, $companyId = null)
	{
		$cId = getCurrencyId();
		// SQL Injection Fix: Cast to integer and use parameterized query
		$stype = (int)$stype;
		$cId = (int)$cId;

		$sql = "SELECT ps.id, ps.product_name, ps.product_desc, CONCAT(CONCAT('[', GROUP_CONCAT(JSON_OBJECT('service_pricing_id', psp.id, 'price', psp.price, 'cycle_name', bc.cycle_name, 'currency', c.code))), ']') billing
				FROM product_services ps
				JOIN product_service_pricing psp on psp.product_service_id=ps.id
				JOIN billing_cycle bc on psp.billing_cycle_id=bc.id
				JOIN currencies c on psp.currency_id=c.id
				WHERE ps.product_service_group_id=? and psp.currency_id=? AND psp.status=1  and ps.is_hidden=0 and ps.status=1
				GROUP BY ps.id ";
		$data = $this->db->query($sql, array($stype, $cId))->result_array();

		// The billing blob is built by GROUP_CONCAT in SQL, so the resolver
		// cannot reach it there -- rewrite each embedded price after the fact.
		foreach ($data as &$row) {
			$plans = json_decode($row['billing'], true);
			if (!is_array($plans)) continue;
			foreach ($plans as &$plan) {
				if (empty($plan['service_pricing_id'])) continue;
				$r = $this->Pricing_model->resolve(2, $plan['service_pricing_id'], $companyId);
				if (!empty($r)) $plan['price'] = $r['price'];
			}
			unset($plan);
			$row['billing'] = json_encode($plans);
		}
		unset($row);

		return $data;
	}

	function getCurrencies()
	{

		$sql = "SELECT id, symbol, code, is_default FROM currencies WHERE status=1 ";
		$data = $this->db->query($sql)->result_array();
		return $data;
	}

	function deleteAllCarts($userId, $sessionId)
	{
		// SQL Injection Fix: Cast to integer and use parameterized query
		$userId = (int)$userId;
		$sessionId = (int)$sessionId;

		if( $userId > 0 ){
			$sql = " DELETE FROM add_to_carts where user_id=? ";
			$this->db->query($sql, array($userId));
		}

		if( $sessionId > 0 ){
			$sql = " DELETE FROM add_to_carts where customer_session_id=? ";
			$this->db->query($sql, array($sessionId));
		}
	}

	function getCartListData()
	{
		// SQL Injection Fix: Cast to integer and use parameterized query
		$customerId = (int)getCustomerId();
		$customerSessionId = (int)getCustomerSessionId();

		$sql = "SELECT * FROM add_to_carts where user_id=? or customer_session_id=?";
		$data = $this->db->query($sql, array($customerId, $customerSessionId))->result_array();
		return $data;
	}


	function getDomPricing($companyId = null)
	{
		// SQL Injection Fix: Cast to integer and use parameterized query
		$cId = (int)getCurrencyId();

		$sql = " SELECT dp.id, dp.currency_id, dp.price, dp.transfer, dp.renewal, de.extension
			FROM dom_pricing dp
			JOIN dom_extensions de on dp.dom_extension_id=de.id
			WHERE dp.status=1 AND dp.reg_period=1 AND dp.currency_id=? AND de.status=1 ";

		$data = $this->db->query($sql, array($cId))->result_array();

		// This is the TLD grid: every extension the platform sells, on the
		// storefront's first paint. resolveMany() collapses the override
		// lookups into one query per audience -- resolving row by row here
		// would be a visible regression, not a micro-optimisation.
		$resolved = $this->Pricing_model->resolveMany(1, $data, $companyId);
		foreach ($data as &$row) {
			$r = isset($resolved[(int)$row['id']]) ? $resolved[(int)$row['id']] : null;
			if (empty($r)) continue;
			$row['price']    = $r['price'];
			$row['transfer'] = $r['transfer'];
			$row['renewal']  = $r['renewal'];
		}
		unset($row);

		return $data;
	}

	function getDomRegister($extension)
	{
		$sql = "SELECT id, name, platform, api_base_url, domain_check_api, suggestion_api, domain_reg_api, whitelisted_ip, auth_userid, auth_apikey, def_ns1, def_ns2, def_ns3, def_ns4 FROM dom_registers WHERE status=1 and is_selected = 1 ";
		$data = $this->db->query($sql)->result_array();
		return !empty($data) ? $data[0] : array();
	}

	function getCartServicePrice($id, $companyId = null)
	{
		// SQL Injection Fix: Cast to integer and use parameterized query
		$id = (int)$id;

		$sql = "SELECT psp.price as item_price, psp.currency_id, psp.product_service_id, bc.id billing_cycle_id, bc.cycle_name
			FROM product_service_pricing psp
			JOIN billing_cycle bc on psp.billing_cycle_id=bc.id
			WHERE psp.id=? and psp.status=1 ";
		$data = $this->db->query($sql, array($id))->result_array();
		if (empty($data)) return array();

		$row = $data[0];
		// item_price is overwritten in place and cost_amount is added: the
		// return shape every caller already destructures stays the same, and
		// checkout gets the cost basis it must freeze onto order_services.
		$r = $this->Pricing_model->resolve(2, $id, $companyId);
		if (!empty($r)) {
			$row['item_price']  = $r['price'];
			$row['cost_amount'] = $r['cost_price'];
		}
		return $row;
	}

	/**
	 * Software plan pricing for the cart (item_type=3). Mirrors getCartServicePrice.
	 * item_price = first_pay_amount (what the first invoice bills).
	 */
	function getCartSoftwarePrice($id, $companyId = null)
	{
		$id = (int) $id;

		$sql = "SELECT sp.first_pay_amount AS item_price, sp.first_pay_amount, sp.recurring_amount,
					sp.currency_id, sp.product_id, p.name AS product_name,
					bc.id AS billing_cycle_id, bc.cycle_name
				FROM software_pricing sp
				JOIN plans p ON sp.product_id = p.id
				JOIN billing_cycle bc ON sp.billing_cycle_id = bc.id
				WHERE sp.id=? AND sp.status=1 AND p.is_active=1";
		$data = $this->db->query($sql, array($id))->result_array();
		if (empty($data)) return array();

		$row = $data[0];
		// Software has no transfer/renewal split: the resolver maps first_pay
		// onto price and recurring onto renewal, so both stay in step here.
		$r = $this->Pricing_model->resolve(3, $id, $companyId);
		if (!empty($r)) {
			$row['item_price']       = $r['price'];
			$row['first_pay_amount'] = $r['price'];
			$row['recurring_amount'] = $r['renewal'];
			$row['cost_amount']      = $r['cost_price'];
		}
		return $row;
	}

	function getCartDomainPrice($id, $companyId = null)
	{
		// SQL Injection Fix: Cast to integer and use parameterized query
		$id = (int)$id;

		$sql = "SELECT dp.price as item_price, dp.transfer, dp.renewal, dp.currency_id, dp.reg_period FROM dom_pricing dp WHERE dp.id=? and dp.status=1 ";
		$data = $this->db->query($sql, array($id))->result_array();
		if (empty($data)) return array();

		$row = $data[0];
		// All three components resolve independently -- a reseller may price
		// registration above cost and still be underwater on renewal, and the
		// renewal is the one that repeats for the life of the domain.
		$r = $this->Pricing_model->resolve(1, $id, $companyId);
		if (!empty($r)) {
			$row['item_price']    = $r['price'];
			$row['transfer']      = $r['transfer'];
			$row['renewal']       = $r['renewal'];
			$row['cost_amount']   = $r['cost_price'];
			$row['cost_transfer'] = $r['cost_transfer'];
			$row['cost_renewal']  = $r['cost_renewal'];
		}
		return $row;
	}

	function saveCart($data)
	{
		if ($this->db->insert('add_to_carts', $data)) {
			return $this->db->insert_id();
		}
		return false;
	}

	/**
	 * Get cart list with linked items (parent-child relationship)
	 * Returns hierarchical structure for display
	 */
	function getCartListWithChildren()
	{
		$customerId = (int)getCustomerId();
		$customerSessionId = (int)getCustomerSessionId();

		// Get all parent items (no parent_cart_id)
		$sql = "SELECT * FROM add_to_carts
				WHERE (user_id=? OR customer_session_id=?) AND parent_cart_id IS NULL
				ORDER BY id ASC";
		$parents = $this->db->query($sql, array($customerId, $customerSessionId))->result_array();

		// Get all child items
		$sql = "SELECT * FROM add_to_carts
				WHERE (user_id=? OR customer_session_id=?) AND parent_cart_id IS NOT NULL
				ORDER BY id ASC";
		$children = $this->db->query($sql, array($customerId, $customerSessionId))->result_array();

		// Attach children to parents
		foreach ($parents as &$parent) {
			$parent['children'] = array();
			foreach ($children as $child) {
				if ($child['parent_cart_id'] == $parent['id']) {
					$parent['children'][] = $child;
				}
			}
		}

		return $parents;
	}

	/**
	 * Delete cart item and its linked children
	 */
	function deleteCartWithChildren($cartId)
	{
		$cartId = (int)$cartId;
		$customerId = (int)getCustomerId();
		$customerSessionId = (int)getCustomerSessionId();

		// Raw parameterized deletes scoped to the owner (user_id OR session).
		// This CI build's query builder has no where_group_start/where_group_end,
		// so the OR group is written inline instead of via the builder.
		$owner = '(user_id = ? OR customer_session_id = ?)';

		// First delete children, then the parent item.
		$this->db->query(
			"DELETE FROM add_to_carts WHERE parent_cart_id = ? AND {$owner}",
			array($cartId, $customerId, $customerSessionId)
		);
		$this->db->query(
			"DELETE FROM add_to_carts WHERE id = ? AND {$owner}",
			array($cartId, $customerId, $customerSessionId)
		);

		return true;
	}

	/**
	 * Get cart item by ID
	 */
	function getCartById($cartId)
	{
		$cartId = (int)$cartId;
		return $this->db->get_where('add_to_carts', array('id' => $cartId))->row_array();
	}

	/**
	 * Get children of a cart item
	 */
	function getCartChildren($parentCartId)
	{
		$parentCartId = (int)$parentCartId;
		return $this->db->get_where('add_to_carts', array('parent_cart_id' => $parentCartId))->result_array();
	}

	/**
	 * Update cart item
	 */
	function updateCart($cartId, $data)
	{
		$this->db->where('id', (int)$cartId);
		return $this->db->update('add_to_carts', $data);
	}

	/**
	 * Get domain pricing by ID
	 */
	function getDomPricingById($domPricingId, $companyId = null)
	{
		$domPricingId = (int)$domPricingId;
		$sql = "SELECT dp.*, de.extension, bc.cycle_name, bc.cycle_days
				FROM dom_pricing dp
				JOIN dom_extensions de ON dp.dom_extension_id = de.id
				LEFT JOIN billing_cycle bc ON bc.id = 1
				WHERE dp.id = ?";
		$row = $this->db->query($sql, array($domPricingId))->row_array();
		if (empty($row)) return $row;

		// dp.* means price/transfer/renewal arrive under their native names;
		// overwrite those same keys so callers reading $row['price'] get the
		// buyer's price rather than platform retail.
		$r = $this->Pricing_model->resolve(1, $domPricingId, $companyId);
		if (!empty($r)) {
			$row['price']       = $r['price'];
			$row['transfer']    = $r['transfer'];
			$row['renewal']     = $r['renewal'];
			$row['cost_amount'] = $r['cost_price'];
		}
		return $row;
	}

	/**
	 * Get product service pricing by ID with details
	 */
	function getProductServicePricingById($pricingId, $companyId = null)
	{
		$pricingId = (int)$pricingId;
		$sql = "SELECT psp.*, ps.product_name, ps.product_desc,
				pst.servce_type_name, pst.key_name as service_type_key,
				bc.cycle_name, bc.cycle_days
				FROM product_service_pricing psp
				JOIN product_services ps ON psp.product_service_id = ps.id
				JOIN product_service_types pst ON ps.product_service_type_id = pst.id
				JOIN billing_cycle bc ON psp.billing_cycle_id = bc.id
				WHERE psp.id = ?";
		$row = $this->db->query($sql, array($pricingId))->row_array();
		if (empty($row)) return $row;

		$r = $this->Pricing_model->resolve(2, $pricingId, $companyId);
		if (!empty($r)) {
			$row['price']       = $r['price'];
			$row['cost_amount'] = $r['cost_price'];
		}
		return $row;
	}

}

?>

<div class="card card-widget card-contacts mt-3">
  <div class="card-header">
    <h6 class="card-title mg-b-0"><i class="fa fa-globe"></i> &nbsp;Shortcut</h6>
    <nav class="nav">

    </nav>
  </div><!-- card-header -->
  <ul class="list-group list-group-flush">
	  <li class="list-group-item">
		  <a href="<?=base_url()?>invoicing/invoices" class="nav-sub-link"><i class="fas fa-file-alt"></i>&nbsp;Invoices</a>
	  </li>
	  <li class="list-group-item">
		  <a href="<?=base_url()?>clientarea/services" class="nav-sub-link"><i class="fas fa-list"></i>&nbsp;Services</a>
	  </li>
	  <li class="list-group-item">
		  <a href="<?=base_url()?>clientarea/domains" class="nav-sub-link"><i class="fas fa-globe"></i>&nbsp;Domains</a>
	  </li>
	  <li class="list-group-item">
		  <a href="<?=base_url()?>tickets/index" class="nav-sub-link"><i class="fas fa-ticket-alt"></i>&nbsp;Tickets</a>
	  </li>
  </ul>
</div>

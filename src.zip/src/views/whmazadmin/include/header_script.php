<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<!-- Twitter -->
<meta name="twitter:site" content="@whmaz">
<meta name="twitter:creator" content="@whmaz">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="WHMAZ Admin">
<meta name="twitter:description" content="WHMAZ Admin - Web Host Manager A to Z solutions. Lightweight Domain Hosting Management System.">
<meta name="twitter:image" content="<?=base_url()?>resources/assets/img/whmaz-social.png">

<!-- Facebook -->
<meta property="og:url" content="https://whmaz.com/">
<meta property="og:title" content="WHMAZ Admin">
<meta property="og:description" content="WHMAZ Admin - Web Host Manager A to Z solutions. Lightweight Domain Hosting Management System.">

<meta property="og:image" content="<?=base_url()?>resources/assets/img/whmaz-social.png">
<meta property="og:image:secure_url" content="<?=base_url()?>resources/assets/img/whmaz-social.png">
<meta property="og:image:type" content="image/png">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="600">

<!-- Meta -->
<meta name="description" content="WHMAZ Admin - Web Host Manager A to Z solutions. Lightweight Domain Hosting Management System.">
<meta name="author" content="WHMAZ">

<!-- CSRF Token for AJAX requests -->
<?=csrf_meta()?>

<!-- Favicon -->
<link rel="shortcut icon" type="image/x-icon" href="<?=base_url()?>resources/assets/img/favicon.ico">
<link rel="icon" type="image/png" href="<?=base_url()?>resources/assets/img/favicon.png">

<title>WHMAZ Admin - Web Host Manager A to Z</title>

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Roboto+Mono" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Rubik:300,400" rel="stylesheet" type="text/css">

<!-- Bootstrap Icons (required by AdminLTE 4) -->
<link href="<?=base_url()?>resources/lib/bootstrap-icons-1.13.1/bootstrap-icons.min.css" rel="stylesheet">

<!-- Font Awesome -->
<link href="<?=base_url()?>resources/lib/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet">

<!-- Vendor CSS -->
<link href="<?=base_url()?>resources/lib/prismjs/themes/prism-vs.css" rel="stylesheet">
<link href="<?=base_url()?>resources/lib/quill/quill.core.css" rel="stylesheet">
<link href="<?=base_url()?>resources/lib/quill/quill.snow.css" rel="stylesheet">
<link href="<?=base_url()?>resources/lib/quill/quill.bubble.css" rel="stylesheet">

<!-- AdminLTE 4 CSS -->
<link rel="stylesheet" href="<?=base_url()?>resources/adminlte4/dist/css/adminlte.min.css">

<!-- AdminLTE Compatibility Layer -->
<link rel="stylesheet" href="<?=base_url()?>resources/assets/css/adminlte-compat.css">

<!-- DataTables & Select2 -->
<link href="<?=base_url()?>resources/lib/datatables.net-dt/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="<?=base_url()?>resources/lib/datatables.net-responsive-dt/css/responsive.dataTables.min.css" rel="stylesheet">
<link href="<?=base_url()?>resources/lib/select2/css/select2.min.css" rel="stylesheet">

<!-- Angular Material & Dialogs -->
<link rel="stylesheet" href="<?=base_url()?>resources/angular/angular-material.min.css">
<link rel="stylesheet" href="<?=base_url()?>resources/angular/ngDialog.css">
<link rel="stylesheet" href="<?=base_url()?>resources/angular/ngDialog-theme-default.css">
<link rel="stylesheet" href="<?=base_url()?>resources/angular/ngToast.css">
<link rel="stylesheet" href="<?=base_url()?>resources/angular/ngToast-animations.css">

<!-- Toast & SweetAlert -->
<link rel="stylesheet" href="<?=base_url()?>resources/assets/css/jquery.toast.css">
<link rel="stylesheet" href="<?=base_url()?>resources/lib/sweetalert2/sweetalert2.min.css">

<!-- Custom Admin CSS (loaded after AdminLTE to override styles) -->
<link rel="stylesheet" href="<?=base_url()?>resources/assets/css/admin.custom.css">

<script type="text/javascript">
	var BASE_URL="<?=base_url()?>"; var isLoadingShown = false;
	function safe_encode(val){
		return encodeURIComponent(btoa(val));
	}

	function escapeXSS(str){

		if(!str){
			return "";}
		str = str+"";
		return str.replace(/\</g, '&lt;')
			.replace(/\>/g, '&gt;')
			.replace(/\"/g, '&quot;')
			.replace(/\'/g, '&#x27;')
			.replace(/\//g, '&#x2F;')
			//.replace(/\&/g, '&amp;')
			;

	}

	// SECURITY: Clickjacking protection - Frame busting script
	// This provides defense-in-depth in addition to X-Frame-Options header
	(function() {
		if (self !== top) {
			// Page is in an iframe - attempt to break out
			try {
				top.location.href = self.location.href;
			} catch (e) {
				// Cross-origin iframe - can't redirect, hide content instead
				document.documentElement.style.display = 'none';
				document.body.innerHTML = '<h1 style="color:red;text-align:center;margin-top:50px;">This page cannot be displayed in a frame for security reasons.</h1>';
			}
		}
	})();
</script>

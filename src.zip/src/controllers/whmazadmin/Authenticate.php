<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Authenticate extends WHMAZADMIN_Controller
{

	function __construct()
	{
		parent::__construct();
		$this->load->model('Adminauth_model');
		$this->load->model('Appsetting_model');
	}

	public function index()
	{
		redirect('/whmazadmin/authenticate/login', 'refresh');
	}

	public function login()
	{
		$redirectUrl = isset($_GET["redirect-url"]) ? $_GET["redirect-url"] : "";

		// Get app settings for reCAPTCHA keys
		$app_settings = $this->Appsetting_model->getSettings();
		$captcha_site_key = !empty($app_settings['captcha_site_key']) ? $app_settings['captcha_site_key'] : '';
		$captcha_secret_key = !empty($app_settings['captcha_secret_key']) ? $app_settings['captcha_secret_key'] : '';

		if ($this->input->post()) {

			// LICENSE GATE: verify this install is authorized BEFORE any
			// credential check. A cracked/unlicensed copy is blocked here even
			// with valid admin credentials.
			$this->load->library('license_client');
			if ( ! $this->license_client->admin_authorized()) {
				// Dedicated key -> rendered as a SweetAlert modal in the login
				// view (not the generic admin_error toast).
				$this->session->set_flashdata('license_error', 'This installation is not authorized. Please verify your license key or contact support.');
				$data['captcha_site_key'] = $captcha_site_key;
				$this->load->view('whmazadmin/admin_login', $data);
				return;
			}

			// Verify reCAPTCHA only if keys are configured
			if (!empty($captcha_site_key) && !empty($captcha_secret_key)) {
				$recaptcha_response = $this->input->post('g-recaptcha-response');
				if (empty($recaptcha_response)) {
					$this->session->set_flashdata('admin_error', 'Please complete the reCAPTCHA verification.');
					$data['captcha_site_key'] = $captcha_site_key;
					$this->load->view('whmazadmin/admin_login', $data);
					return;
				}

				$verify_url = RECAPTCHA_VERIFY_URL;
				$post_data = array(
					'secret' => $captcha_secret_key,
					'response' => $recaptcha_response,
					'remoteip' => $this->input->ip_address()
				);

				$options = array(
					'http' => array(
						'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
						'method'  => 'POST',
						'content' => http_build_query($post_data)
					)
				);

				$context  = stream_context_create($options);
				$result = file_get_contents($verify_url, false, $context);
				$recaptcha_result = json_decode($result, true);

				if (!$recaptcha_result['success']) {
					$this->session->set_flashdata('admin_error', 'reCAPTCHA verification failed. Please try again.');
					$data['captcha_site_key'] = $captcha_site_key;
					$this->load->view('whmazadmin/admin_login', $data);
					return;
				}
			}

			$username = xssCleaner($this->input->post('username'));
			$password = $this->input->post('password');

			$resp = $this->Adminauth_model->doLogin($username, $password);
			if ($resp['status_code'] == 1) {
				$this->session->set_userdata("ADMIN", $resp['data']);

				// Carry any license grace window into the session so the admin
				// layout can show a persistent warning banner until it clears.
				if ($this->license_client->admin_in_grace()) {
					$this->session->set_userdata('LICENSE_GRACE_UNTIL', $this->license_client->admin_grace_until());
				} else {
					$this->session->unset_userdata('LICENSE_GRACE_UNTIL');
				}

				// SECURITY FIX: Validate redirect URL to prevent open redirect vulnerability
				if( !empty($redirectUrl) ){
					// Only allow internal redirects (relative URLs starting with /)
					if (strpos($redirectUrl, '/') === 0 && strpos($redirectUrl, '//') !== 0) {
						redirect($redirectUrl, 'refresh');
					} else {
						redirect('/whmazadmin/dashboard/index', 'refresh');
					}
				} else{
					redirect('/whmazadmin/dashboard/index', 'refresh');
				}

			} else if ($resp['status_code'] == -100) {
				// SECURITY: Rate limiting - too many failed attempts
				$this->session->set_flashdata('admin_error', $resp['message']);
			} else if ($resp['status_code'] == -1) {
				$remaining = isset($resp['remaining_attempts']) ? $resp['remaining_attempts'] : '';
				$msg = 'Invalid username or account not active.';
				if ($remaining > 0 && $remaining <= 3) {
					$msg .= " ({$remaining} attempts remaining)";
				}
				$this->session->set_flashdata('admin_error', $msg);
			} else if ($resp['status_code'] == -2) {
				$remaining = isset($resp['remaining_attempts']) ? $resp['remaining_attempts'] : '';
				$msg = 'Please Enter your current email address !!!';
				if ($remaining > 0 && $remaining <= 3) {
					$msg .= " ({$remaining} attempts remaining)";
				}
				$this->session->set_flashdata('admin_error', $msg);
			} else {
				$remaining = isset($resp['remaining_attempts']) ? $resp['remaining_attempts'] : '';
				$msg = 'Invalid username/password. Try Again';
				if ($remaining > 0 && $remaining <= 3) {
					$msg .= " ({$remaining} attempts remaining)";
				}
				$this->session->set_flashdata('admin_error', $msg);
			}

		}
		$data['captcha_site_key'] = $captcha_site_key;
		$this->load->view('whmazadmin/admin_login', $data);
	}


	public function logout()
	{
		$resp = array('id' => 0, 'email' => '');
		$this->session->unset_userdata('ADMIN', $resp);
		$this->session->unset_userdata('ADMIN');
		$this->session->sess_destroy();
		$this->session->set_flashdata('admin_error', 'Logout success !!!');
		redirect('/whmazadmin/authenticate/login', 'refresh');
	}

	public function forgetpaswrd()
	{
		if ($this->input->post()) {
			$username = xssCleaner($this->input->post('username'));
			$this->Adminauth_model->forgetpaswrd($username);
			$this->session->set_flashdata('admin_success', 'If that email exists in our system, a password reset link has been sent.');
		}
		$this->load->view('whmazadmin/admin_forgetpass');
	}

	public function resetpassword($token = null)
	{
		if (empty($token)) {
			redirect('/whmazadmin/authenticate/login', 'refresh');
			return;
		}

		$token = str_replace(' ', '', urldecode($token));
		$user = $this->Adminauth_model->validateResetToken($token);

		if (!$user) {
			$this->session->set_flashdata('admin_error', 'This reset link is invalid or has expired.');
			redirect('/whmazadmin/authenticate/login', 'refresh');
			return;
		}

		if ($this->input->post()) {
			$password = $this->input->post('password');
			$confirm  = $this->input->post('confirm_password');

			if (strlen($password) < 8) {
				$this->session->set_flashdata('admin_error', 'Password must be at least 8 characters.');
				$data['token'] = $token;
				$this->load->view('whmazadmin/admin_resetpassword', $data);
				return;
			}

			if ($password !== $confirm) {
				$this->session->set_flashdata('admin_error', 'Passwords do not match.');
				$data['token'] = $token;
				$this->load->view('whmazadmin/admin_resetpassword', $data);
				return;
			}

			$result = $this->Adminauth_model->resetPassword($user, $password);

			if ($result) {
				$appSettings = getAppSettings();
				$userName = !empty($user->first_name) ? htmlspecialchars($user->first_name) : 'Admin';

				$body = 'Dear ' . $userName . ',<br><br>';
				$body .= 'Your admin password has been reset successfully.<br><br>';
				$body .= 'If you did not make this change, please contact us immediately.<br><br>';
				$body .= '<b>Thanks & Regards</b><br>';
				$body .= $appSettings->company_name . ' Support';

				$subject = "Admin Password Reset Successful - " . $appSettings->company_name;
				sendHtmlEmail($user->email, $subject, $body);

				$this->session->set_flashdata('admin_success', 'Your password has been reset successfully. Please login.');
			} else {
				$this->session->set_flashdata('admin_error', 'This reset link is invalid or has expired.');
			}
			redirect('/whmazadmin/authenticate/login', 'refresh');
			return;
		} else {
			$data['token'] = $token;
			$this->load->view('whmazadmin/admin_resetpassword', $data);
		}
	}

}

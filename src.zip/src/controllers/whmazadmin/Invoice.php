<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Invoice extends WHMAZADMIN_Controller
{
	var $img_path;
	var $upload_dir;

	function __construct()
	{
		parent::__construct();
		$this->load->model('Billing_model');
		$this->load->model('Common_model');
		$this->load->model('Invoice_model');
		$this->load->model('Appsetting_model');

		if (!$this->isLogin()) {
			redirect('/whmazadmin/authenticate/login', 'refresh');
		}
		$this->img_path = realpath(APPPATH . '../uploadedfiles/billing/');
		$this->upload_dir = realpath(APPPATH . '../uploadedfiles/');
	}

	public function index()
	{
		$data['summary'] = array();
		$data['results'] = array();

		$this->load->view('whmazadmin/invoice_list', $data);
	}

	/**
	 * Resolve the logo shown on invoices (view + PDF) as a base64 data URI.
	 * Prefers the logo uploaded in Settings -> General; falls back to the
	 * bundled resources/assets/img/logo.png so invoices are never logo-less.
	 *
	 * @param  array  $companyInfo app_settings row
	 * @return string data URI, or '' when no readable logo exists
	 */
	private function _invoiceLogoBase64($companyInfo)
	{
		// Use basename() to prevent path traversal attacks
		$logoFilename = !empty($companyInfo['logo']) ? basename($companyInfo['logo']) : '';
		$logoPath = !empty($logoFilename) ? $this->upload_dir . '/mics/' . $logoFilename : '';

		if (empty($logoPath) || !file_exists($logoPath)) {
			$logoPath = realpath(APPPATH . '../resources/assets/img/logo.png');
		}

		return (!empty($logoPath) && file_exists($logoPath)) ? convertImageToBase65($logoPath) : '';
	}


	public function view_invoice($companyId, $invoice_uuid)
	{
		// SECURITY: both ids come from the URL. getInvoiceByUuid() pairs them,
		// so guarding the company is what actually protects the record.
		$this->guardCompany($companyId);

		$data['companyInfo'] = $this->Appsetting_model->getSettings();
		$data['summary'] = $this->Billing_model->invoiceSummary($companyId)[0];
		$data['invoice'] = $this->Billing_model->getInvoiceByUuid($invoice_uuid, $companyId);
		$data['invoiceItems'] = $this->Billing_model->getInvoiceItems($data['invoice']['id']);
		$data['logoBase64'] = $this->_invoiceLogoBase64($data['companyInfo']);
		$data['txnHistory'] = array();
		$data['viewMode'] = "HTML";

		$htmlData = $this->load->view('whmazadmin/invoice_pdf_html', $data, TRUE);
		$data['htmlData'] = $htmlData;
		$data['company_id'] = $companyId;
		$data['invoice_uuid'] = $invoice_uuid;

		$this->load->view('whmazadmin/invoice_view', $data);
	}

	public function download_invoice($companyId, $invoice_uuid)
	{
		// SECURITY: same exposure as view_invoice(), as a PDF.
		$this->guardCompany($companyId);

		$this->load->library('Pdf');

		$data['companyInfo'] = $this->Appsetting_model->getSettings();
		$data['summary'] = $this->Billing_model->invoiceSummary($companyId)[0];
		$data['invoice'] = $this->Billing_model->getInvoiceByUuid($invoice_uuid, $companyId);
		$data['invoiceItems'] = $this->Billing_model->getInvoiceItems($data['invoice']['id']);
		$data['logoBase64'] = $this->_invoiceLogoBase64($data['companyInfo']);
		$data['txnHistory'] = array();
		$data['viewMode'] = "PDF";

		$this->pdf->download_view('whmazadmin/invoice_pdf_html', $data, "Invoice-".$data['invoice']['invoice_no'].".pdf");
	}

	public function ssp_list_api($tmpCompanyId=null)
	{
		$this->processRestCall();

		// Set proper JSON headers
		header('Content-Type: application/json');

		try {
			$params = $this->input->get();

			$companyId = !empty($tmpCompanyId) ? safe_decode($tmpCompanyId) : 0;

			if( $companyId > 0 ){
				for ( $i=0 ; $i<count($params["columns"]) ; $i++){
					if( $params["columns"][$i]['data'] == "company_id" ){
						$params["columns"][$i]["search"]["value"] = $companyId;
						break;
					}
				}
			}

			$bindings = array();
			$where = '';

			$sqlQuery = ssp_sql_query($params, "invoice_view", $bindings, $where);

			$data = $this->Invoice_model->getDataTableRecords($sqlQuery, $bindings);

			// Get invoice stats for dashboard cards
			$stats = $this->Invoice_model->getInvoiceStats();

			$response = array(
				"draw"            => !empty( $params['draw'] ) ? intval($params['draw']) : 0,
				"recordsTotal"    => intval( $this->Invoice_model->countDataTableTotalRecords() ),
				"recordsFiltered" => intval( $this->Invoice_model->countDataTableFilterRecords($where, $bindings) ),
				"data"            => $data,
				"stats"           => $stats
			);

			echo json_encode($response);
			exit;

		} catch (Exception $e) {
			// Return error in DataTables format
			echo json_encode(array(
				"draw"            => 0,
				"recordsTotal"    => 0,
				"recordsFiltered" => 0,
				"data"            => array(),
				"error"           => $e->getMessage()
			));
			exit;
		}
	}


	public function recent_list_api()
	{
		$this->processRestCall();
		$rqData = $this->input->post();
		echo json_encode($this->Billing_model->loadInvoiceList(-1, $rqData['limit']));
	}

	public function mark_as_paid()
	{
		$this->processRestCall();

		// Set proper JSON headers
		header('Content-Type: application/json');

		try {
			$invoice_uuid = $this->input->post('invoice_uuid');

			// Validate input
			if (empty($invoice_uuid)) {
				echo json_encode(array(
					'success' => false,
					'message' => 'Invoice UUID is required'
				));
				exit;
			}

			// SECURITY: addressed by uuid, not id. Marking another tenant's
			// invoice paid triggers provisioning — registrar spend and live
			// hosting accounts — so guard before it reaches the model.
			$this->guardRecordBy('invoices', 'invoice_uuid', $invoice_uuid);

			// Update invoice status to PAID
			$updated = $this->Invoice_model->updateInvoiceStatus($invoice_uuid, 'PAID', getAdminId());

			if ($updated) {
				echo json_encode(array(
					'success' => true,
					'message' => 'Invoice marked as paid successfully'
				));
			} else {
				echo json_encode(array(
					'success' => false,
					'message' => 'Failed to update invoice or invoice not found'
				));
			}
			exit;

		} catch (Exception $e) {
			echo json_encode(array(
				'success' => false,
				'message' => 'Error: ' . $e->getMessage()
			));
			exit;
		}
	}


}

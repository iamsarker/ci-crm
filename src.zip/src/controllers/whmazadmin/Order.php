<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Order extends WHMAZADMIN_Controller
{
	var $img_path;
	var $upload_dir;

	function __construct()
	{
		parent::__construct();
		if (!$this->isLogin()) {
			redirect('/whmazadmin/authenticate/login', 'refresh');
		}

		$this->load->model('Order_model');
		$this->load->model('Common_model');
		$this->load->model('Currency_model');

		$this->img_path = realpath(APPPATH . '../uploadedfiles/billing/');
		$this->upload_dir = realpath(APPPATH . '../uploadedfiles/');
	}

	public function index()
	{
		$data['summary'] = array();
		$data['results'] = array();

		$this->load->view('whmazadmin/order_list', $data);
	}

	public function new_order($id_val = null)
	{
		if( $this->input->post() ){
			$this->form_validation->set_rules('company_id', 'Company/customer', 'required|trim');
			$this->form_validation->set_message('company_id', 'Company/customer is required');

			$this->form_validation->set_rules('currency_id', 'currency', 'required|trim');
			$this->form_validation->set_message('currency_id', 'currency is required');

			$this->form_validation->set_rules('payment_gateway_id', 'payment gateway', 'required|trim');
			$this->form_validation->set_message('payment_gateway_id', 'Payment gateway is required');

			$hasHosting = ($this->input->post('module_id') > 0 && $this->input->post('server_id') > 0);
			$hasDomain = ($this->input->post('domain') != "");

			if( $hasHosting ){
				$this->form_validation->set_rules('billing_cycle_id', 'billing cycle', 'required|trim');
				$this->form_validation->set_message('billing_cycle_id', 'billing cycle is required');

				$this->form_validation->set_rules('product_service_id', 'package', 'required|trim');
				$this->form_validation->set_message('product_service_id', 'package is required');
			}

			if( $this->input->post('dom_register_id') > 0 ){
				$this->form_validation->set_rules('domain', 'domain', 'required|trim');
				$this->form_validation->set_message('domain', 'domain is required');
			}

			// At least domain or hosting must be provided
			if( !$hasHosting && !$hasDomain ){
				$this->form_validation->set_rules('domain', 'domain', 'required|trim');
				$this->form_validation->set_message('domain', 'Domain or hosting is required');
			}

			if ($this->form_validation->run() == true){

				$form_data = array(
					'id'					=> safe_decode($this->input->post('id')),
					'company_id'			=> $this->input->post('company_id'),
					'currency_id'			=> $this->input->post('currency_id'),
					'billing_cycle_id'		=> $this->input->post('billing_cycle_id'),
					'module_id'				=> $this->input->post('module_id'),
					'server_id'				=> $this->input->post('server_id'),
					'payment_gateway_id'	=> $this->input->post('payment_gateway_id'),
					'product_service_group_id'	=> $this->input->post('product_service_group_id'),
					'product_service_id'	=> $this->input->post('product_service_id'),
					'dom_register_id'		=> $this->input->post('dom_register_id'),
					'order_type'			=> $this->input->post('order_type'),
					'domain'				=> $this->input->post('domain'),
					'epp_code'				=> $this->input->post('epp_code'),
					'remarks'				=> $this->input->post('remarks'),
					'package_amount'		=> $this->input->post('package_amount'),
					'domain_amount'			=> $this->input->post('domain_amount'),
					'sub_total'				=> $this->input->post('sub_total'),
					'coupon_code'			=> $this->input->post('coupon_code'),
					'coupon_amount'			=> $this->input->post('coupon_amount'),
					'discount_amount'		=> $this->input->post('discount_amount'),
					'total_amount'			=> $this->input->post('total_amount'),
					'reg_period'			=> $this->input->post('reg_period'),
					'reg_date'				=> $this->input->post('reg_date') ? $this->input->post('reg_date') : date('Y-m-d'),
					'has_notification'		=> $this->input->post('has_notification') ? 1 : 0,
					'need_api_call'			=> $this->input->post('need_api_call') ? 1 : 0,
					'mark_as_paid'			=> $this->input->post('mark_as_paid') ? 1 : 0,
					'hosting_already_exists'=> $this->input->post('hosting_already_exists') ? 1 : 0,
					'cp_username'			=> $this->input->post('cp_username'),
					'domain_reg_date'		=> $this->input->post('domain_reg_date'),
					'domain_exp_date'		=> $this->input->post('domain_exp_date'),
					'domain_cust_id'		=> $this->input->post('domain_cust_id'),
					'domain_order_id'		=> $this->input->post('domain_order_id'),
					'hosting_reg_date'		=> $this->input->post('hosting_reg_date'),
					'hosting_exp_date'		=> $this->input->post('hosting_exp_date'),
				);

				// SECURITY: company_id is a POST field. The picker is scoped by
				// Common_model::generate_dropdown(), but a reseller can still
				// post any id by hand — which would raise an order (and later a
				// wallet debit) against another tenant's customer.
				$this->guardCompany($form_data['company_id']);

				$order = $this->saveOrderTable($form_data);
				$savedItemIds = $this->saveOrderItemTable($order, $form_data);

				if( !empty($form_data['billing_cycle_id']) && $form_data['billing_cycle_id'] > 0 ){
					$billingCycle = $this->Common_model->get_data_by_id("billing_cycle", $form_data['billing_cycle_id']);
				} else {
					$billingCycle = array();
				}

				$invoice = $this->saveInvoiceTable($order, $billingCycle, $form_data);
				$this->saveInvoiceItemTable($invoice, $form_data, $billingCycle, $savedItemIds);

				if( $order['id'] > 0 && $invoice['id'] > 0 ){
					$this->session->set_flashdata('admin_success', 'Order has been saved successfully.');
					redirect("whmazadmin/order/index");
				} else {
					$this->session->set_flashdata('admin_error', 'Something went wrong. Try again');
				}
			}

		}

		if( !empty($id_val) && safe_decode($id_val) > 0 ){
			$data['detail'] = $this->Order_model->getDetail(safe_decode($id_val));
		} else {
			$data['detail'] = array();
		}

		$data['companies'] = $this->Common_model->generate_dropdown('companies', 'id', "name", "first_name", "last_name");
		$data['currencies'] = $this->Common_model->generate_dropdown('currencies', 'id', "code");
		$data['billing_cycles'] = $this->Common_model->generate_dropdown('billing_cycle', 'id', "cycle_name");
		// SECURITY: requirement 8 ("reseller cannot manage servers") is a
		// disclosure rule as well as a CRUD one — a reseller has no business
		// knowing the fleet's hostnames. They still need to pick a server so a
		// package can be resolved, so show the friendly name only.
		$data['servers'] = isResellerAdmin()
			? $this->Common_model->generate_dropdown('servers', 'id', "name")
			: $this->Common_model->generate_dropdown('servers', 'id', "name", "hostname");
		$data['modules'] = $this->Common_model->generate_dropdown('server_modules', 'id', "module_name");
		$data['service_groups'] = $this->Common_model->generate_dropdown('product_service_groups', 'id', "group_name");
		$data['payment_gateways'] = $this->Common_model->generate_dropdown('payment_gateway', 'id', "name");

		$data['dom_registers'] = $this->Common_model->generate_dropdown('dom_registers', 'id', "name");

		$this->load->view('whmazadmin/order_new', $data);
	}

	public function saveOrderTable($form_data){
		$order = array();

		if( intval($form_data['id']) > 0 ){
			$order = $this->Order_model->getDetail($form_data['id']);
			$order['updated_on'] = getDateTime();
			$order['updated_by'] = getAdminId();

			$order['inserted_on'] = $order['inserted_on'];
			$order['inserted_by'] = $order['inserted_by'];
		} else {
			$order['inserted_on'] = getDateTime();
			$order['inserted_by'] = getAdminId();
			$order['status'] = 1;
		}

		$currency =$this->Currency_model->getDetail($form_data['currency_id']);

		$order['order_uuid'] = gen_uuid();
		$order['order_no'] = $this->Order_model->generateNumber('ORDER');
		$order['company_id'] = $form_data['company_id'];
		$order['currency_id'] = $form_data['currency_id'];
		$order['currency_code'] = $currency['code'];
		$order['payment_gateway_id'] = !empty($form_data['payment_gateway_id']) ? $form_data['payment_gateway_id'] : 0;
		$order['order_date'] = !empty($form_data['reg_date']) ? $form_data['reg_date'] : date('Y-m-d');
		$order['amount'] = empty($form_data['sub_total']) ? 0 : $form_data['sub_total'];
		$order['vat_amount'] = 0.0;
		$order['tax_amount'] = 0.0;
		$order['coupon_code'] = $form_data['coupon_code'];
		$order['coupon_amount'] = empty($form_data['coupon_amount']) ? 0 : $form_data['coupon_amount'];
		$order['discount_amount'] = empty($form_data['discount_amount']) ? 0 : $form_data['discount_amount'];
		$order['total_amount'] = empty($form_data['total_amount']) ? 0 : $form_data['total_amount'];
		$order['remarks'] = $form_data['remarks'];
		$order['has_notification'] = $form_data['has_notification'];
		$order['need_api_call'] = $form_data['need_api_call'];
		$order['instructions'] = '';

		$orderId = $this->Order_model->saveOrder($order);
		$order['id'] = $orderId;

		return $order;
	}

	public function saveOrderItemTable($order, $form_data){

		$savedIds = array('domain_id' => 0, 'service_id' => 0);

		$isExistingDomain = ($form_data['order_type'] == 4);
		$isExistingHosting = !empty($form_data['hosting_already_exists']);

		// Use posted reg_date or default to today
		$regDate = !empty($form_data['reg_date']) ? $form_data['reg_date'] : date('Y-m-d');
		$regPeriod = !empty($form_data['reg_period']) ? intval($form_data['reg_period']) : 1;
		$dueDate = date('Y-m-d', strtotime($regDate . " +7 days"));

		// --- Domain dates ---
		if ($isExistingDomain && !empty($form_data['domain_reg_date'])) {
			$domainRegDate = $form_data['domain_reg_date'];
			$domainExpDate = !empty($form_data['domain_exp_date']) ? $form_data['domain_exp_date'] : date('Y-m-d', strtotime($domainRegDate . " +{$regPeriod} years"));
		} else {
			$domainRegDate = $regDate;
			$domainExpDate = date('Y-m-d', strtotime($regDate . " +{$regPeriod} years"));
		}

		// --- Hosting dates ---
		if ($isExistingHosting && !empty($form_data['hosting_reg_date'])) {
			$hostingRegDate = $form_data['hosting_reg_date'];
			$hostingExpDate = !empty($form_data['hosting_exp_date']) ? $form_data['hosting_exp_date'] : date('Y-m-d', strtotime($hostingRegDate . " +1 year"));
		} else {
			$hostingRegDate = $regDate;
			// Calculate from billing cycle days
			if (!empty($form_data['billing_cycle_id'])) {
				$billingCycleRow = $this->Common_model->get_data_by_id("billing_cycle", $form_data['billing_cycle_id']);
				$cycleDays = !empty($billingCycleRow->cycle_days) ? intval($billingCycleRow->cycle_days) : 365;
			} else {
				$cycleDays = 365;
			}
			$hostingExpDate = date('Y-m-d', strtotime($hostingRegDate . " +{$cycleDays} days"));
		}

		// Common base for items
		$item['order_id'] = $order['id'];
		$item['company_id'] = $order['company_id'];
		$item['is_synced'] = 0;
		$item['remarks'] = "";
		$item['suspension_date'] = null;
		$item['suspension_reason'] = null;
		$item['termination_date'] = null;
		$item['auto_renew'] = 1;
		$item['inserted_on'] = getDateTime();
		$item['inserted_by'] = getAdminId();

		// Domain price lookup
		$domain_name = !empty($form_data['domain']) ? $form_data['domain'] : '';
		$domain_array = explode(".", $domain_name);
		if ( count($domain_array) == 3 ){
			$extension = '.'.$domain_array[1].'.'.$domain_array[2];
		} else if ( count($domain_array) == 2 ){
			$extension = '.'.$domain_array[1];
		} else {
			$extension = "";
		}

		// Price for the CUSTOMER the order is being raised for, not for the
		// admin placing it: a reseller's sub-customer must be quoted the
		// reseller's price even when a platform admin keys the order in.
		$buyerCompanyId = (int) $order['company_id'];
		$domain_prices = !empty($domain_name) ? $this->Common_model->getDomainPrices($form_data['currency_id'], $form_data['reg_period'], $extension, $buyerCompanyId) : array();

		if( !empty($form_data['domain']) && $form_data['order_type'] != 3 ){ // order_domain (skip for "No Domain")
			$domain_arr = $item;
			$domain_arr['reg_date'] = $domainRegDate;
			$domain_arr['exp_date'] = $domainExpDate;
			$domain_arr['due_date'] = $dueDate;
			$domain_arr['next_renewal_date'] = $domainExpDate;
			$domain_arr['domain'] = $form_data['domain'];
			$domain_arr['epp_code'] = !empty($form_data['epp_code']) ? $form_data['epp_code'] : '';
			$domain_arr['reg_period'] = $form_data['reg_period'];
			$domain_arr['dom_register_id'] = $form_data['dom_register_id'];
			$domain_arr['dom_pricing_id'] = !empty($domain_prices) ? $domain_prices['id'] : 0;
			$domain_arr['recurring_amount'] = !empty($domain_prices) ? $domain_prices['renewal'] : 0;
			$domain_arr['first_pay_amount'] = $form_data['domain_amount'];
			// Cost basis frozen with the sell price -- same rule as the
			// storefront (Cart::_resolveCostAmount): transfers cost the
			// transfer price, and order_type 3 (DNS only) / 4 (import) never
			// touch the registrar, so they cost nothing.
			if (in_array((int) $form_data['order_type'], array(3, 4), true)) {
				$domain_arr['cost_amount'] = 0.00;
			} else if ((int) $form_data['order_type'] === 2) {
				$domain_arr['cost_amount'] = !empty($domain_prices['cost_transfer']) ? $domain_prices['cost_transfer'] : (!empty($domain_prices['cost_amount']) ? $domain_prices['cost_amount'] : 0.00);
			} else {
				$domain_arr['cost_amount'] = !empty($domain_prices['cost_amount']) ? $domain_prices['cost_amount'] : 0.00;
			}

			 // domain status; 0=pending reg, 1=active, 2=expired, 3=grace, 4=cancelled, 5=pending transfer

			if( $form_data['order_type'] == 4 ){
				// Already registered - import as active, use admin-entered dates
				$domain_arr['status'] = 1;
				$domain_arr['reg_date'] = $domainRegDate;
				$domain_arr['exp_date'] = $domainExpDate;
				$domain_arr['next_renewal_date'] = $domainExpDate;
				$domain_arr['is_synced'] = 1;
				$domain_arr['domain_cust_id'] = !empty($form_data['domain_cust_id']) ? $form_data['domain_cust_id'] : null;
				$domain_arr['domain_order_id'] = !empty($form_data['domain_order_id']) ? $form_data['domain_order_id'] : null;

			} else if( $form_data['order_type'] == 3 ){
				$domain_arr['reg_period'] = 1;
				$domain_arr['status'] = 1;

			} else if( $form_data['order_type'] == 2 ){
				$domain_arr['status'] = 5;

			} else if( $form_data['order_type'] == 1 ){
				$domain_arr['status'] = 0;

			}

			$savedIds['domain_id'] = $this->Order_model->saveOrderDomain($domain_arr);

		}

		if ( !empty($form_data['product_service_id']) ){
			$service_arr = $item;

			$hostingPrices = $this->Common_model->getHostingPrices($form_data['currency_id'], $form_data['product_service_id'], $form_data['billing_cycle_id'], $buyerCompanyId);

			$service_arr['reg_date'] = $hostingRegDate;
			$service_arr['exp_date'] = $hostingExpDate;
			$service_arr['due_date'] = $dueDate;
			$service_arr['next_renewal_date'] = $hostingExpDate;
			$service_arr['billing_cycle_id'] = $form_data['billing_cycle_id'];
			$service_arr['hosting_domain'] = $form_data['domain'];
			$service_arr['first_pay_amount'] = $form_data['package_amount'];
			$service_arr['recurring_amount'] = !empty($hostingPrices['price']) ? $hostingPrices['price'] : $form_data['package_amount'];
			$service_arr['description'] = '';
			$service_arr['product_service_pricing_id'] = !empty($hostingPrices['id']) ? $hostingPrices['id'] : 0;
			$service_arr['product_service_id'] = $form_data['product_service_id'];
			$service_arr['product_service_type_key'] = $this->Common_model->getProductServiceTypeKeyByPricingId(!empty($hostingPrices['id']) ? $hostingPrices['id'] : 0);
			// An imported service was already provisioned elsewhere, so the
			// platform incurs no cost for it.
			$service_arr['cost_amount'] = ($isExistingHosting || empty($hostingPrices['cost_amount'])) ? 0.00 : $hostingPrices['cost_amount'];

			if ($isExistingHosting) {
				// Already configured - import as active
				$service_arr['status'] = 1;
				$service_arr['is_synced'] = 1;
				$service_arr['cp_username'] = !empty($form_data['cp_username']) ? $form_data['cp_username'] : null;
			} else {
				$service_arr['status'] = 0; // 0=pending, 1=active, 2=expired, 3=suspended, 4=terminated
			}

			$savedIds['service_id'] = $this->Order_model->saveOrderService($service_arr);
		}

		// Bi-directional linking: domain ↔ service
		if (!empty($savedIds['domain_id']) && !empty($savedIds['service_id'])) {
			$this->db->where('id', $savedIds['domain_id'])->update('order_domains', array('linked_service_id' => $savedIds['service_id']));
			$this->db->where('id', $savedIds['service_id'])->update('order_services', array('linked_domain_id' => $savedIds['domain_id']));
		}

		return $savedIds;
	}

	public function saveInvoiceTable($order, $billing_cycle, $form_data = array()){
		// Calculate invoice due_date: order_date (reg_date) + 7 days
		$invoiceDueDate = date('Y-m-d', strtotime($order['order_date'] . ' +7 days'));

		$markAsPaid = !empty($form_data['mark_as_paid']);

		$invoice['invoice_uuid'] = gen_uuid();
		$invoice['company_id'] = $order['company_id'];
		$invoice['order_id'] = $order['id'];
		$invoice['currency_id'] = $order['currency_id'];
		$invoice['currency_code'] = $order['currency_code'];
		$invoice['invoice_no'] = $this->Order_model->generateNumber('INVOICE');
		$invoice['sub_total'] = $order['amount'];
		$invoice['tax'] = 0.0;
		$invoice['vat'] = 0.0;
		$invoice['discount'] = empty($order['discount_amount']) ? 0.0 : $order['discount_amount'];
		$invoice['coupon_code'] = empty($order['coupon_code']) ? null : $order['coupon_code'];
		$invoice['total'] = $order['total_amount'];
		$invoice['order_date'] = $order['order_date'];
		$invoice['due_date'] = $invoiceDueDate;
		$invoice['status'] = 1;
		$invoice['pay_status'] = $markAsPaid ? 'PAID' : 'DUE';
		$invoice['need_api_call'] = $order['need_api_call'];
		$invoice['inserted_on'] = $order['inserted_on'];
		$invoice['inserted_by'] = $order['inserted_by'];

		$invoiceId = $this->Order_model->saveInvoice($invoice);
		$invoice['id'] = $invoiceId;

		return $invoice;
	}

	public function saveInvoiceItemTable($invoice, $form_data, $billingCycle, $savedItemIds = array()){

		$invoiceItem['invoice_id'] = $invoice['id'];

		$cycleDays = !empty($billingCycle) && isset($billingCycle->cycle_days) ? $billingCycle->cycle_days : 0;

		if( !empty($form_data['domain']) && $form_data['domain'] != "" && $form_data['order_type'] != 3 ) {
			$invoiceItem['item'] = 'Domain registration';
			$invoiceItem['item_desc'] = $form_data['domain'] . ' - ' . $form_data['reg_period'] . ' year(s)';

			$invoiceItem['tax'] = 0.0;
			$invoiceItem['vat'] = 0.0;
			$invoiceItem['sub_total'] = $form_data['domain_amount'];
			$invoiceItem['total'] = $form_data['domain_amount'];
			$invoiceItem['item_type'] = 1; // domain
			$invoiceItem['ref_id'] = !empty($savedItemIds['domain_id']) ? $savedItemIds['domain_id'] : null;
			$yearlyCycle = $this->db->where('cycle_key', 'YEARLY')->where('status', 1)->get('billing_cycle')->row();
			$invoiceItem['billing_cycle_id'] = !empty($yearlyCycle) ? $yearlyCycle->id : null;
			$invoiceItem['quantity'] = 1;
			$invoiceItem['unit_price'] = $form_data['domain_amount'];
			$invoiceItem['discount'] = 0;
			$invoiceItem['billing_period_start'] = getDateAddDay(0);
			$invoiceItem['billing_period_end'] = getDateAddYear($form_data['reg_period']);
			$invoiceItem['inserted_on'] = getDateTime();
			$invoiceItem['inserted_by'] = $invoice['inserted_by'];

			$this->Order_model->saveInvoiceItem($invoiceItem);
		}

		if( !empty($form_data['product_service_id']) && $form_data['product_service_id'] > 0 ) {
			$package = $this->Common_model->get_data_by_id("product_services", $form_data['product_service_id']);

			$invoiceItem['item'] = 'Hosting package';
			$cycleName = !empty($billingCycle) && isset($billingCycle->cycle_name) ? $billingCycle->cycle_name : '';
			$domainLabel = !empty($form_data['domain']) ? ' for ' . $form_data['domain'] . ' domain' : '';
			$invoiceItem['item_desc'] = trim($cycleName . ' ' . $package->product_name . $domainLabel);

			$invoiceItem['tax'] = 0.0;
			$invoiceItem['vat'] = 0.0;
			$invoiceItem['sub_total'] = $form_data['package_amount'];
			$invoiceItem['total'] = $form_data['package_amount'];
			$invoiceItem['item_type'] = 2; // product service or hosting
			$invoiceItem['ref_id'] = !empty($savedItemIds['service_id']) ? $savedItemIds['service_id'] : null;
			$invoiceItem['billing_cycle_id'] = !empty($form_data['billing_cycle_id']) ? $form_data['billing_cycle_id'] : null;
			$invoiceItem['quantity'] = 1;
			$invoiceItem['unit_price'] = $form_data['package_amount'];
			$invoiceItem['discount'] = 0;
			$invoiceItem['billing_period_start'] = getDateAddDay(0);
			$invoiceItem['billing_period_end'] = ($cycleDays > 0) ? getDateAddDay($cycleDays) : null;
			$invoiceItem['inserted_on'] = getDateTime();

			$this->Order_model->saveInvoiceItem($invoiceItem);
		}
	}

	/**
	 * Orders are never hard/soft deleted - they are cancelled via cancel_order_api(),
	 * which also cancels the order's domains, services and unpaid invoices.
	 * The old delete_records() acted on the expense_types table (copy-paste) and
	 * never touched the order, so it has been removed.
	 */

	public function ssp_list_api($tmpCompanyId=null)
	{
		$this->processRestCall();

		// Set proper JSON headers
		header('Content-Type: application/json');

		try {
			$params = $this->input->get();

			$companyId = !empty($tmpCompanyId) ? safe_decode($tmpCompanyId) : 0;

			if( $companyId > 0 ){
				for ( $i=0 ; $i<count($params["columns"]) ; $i++){
					if( $params["columns"][$i]['data'] == "company_id" ){
						$params["columns"][$i]["search"]["value"] = $companyId;
						break;
					}
				}
			}

			$bindings = array();
			$where = '';
			$statusCond = " `status` IN (0,1,2,3,4,5,6) ";

			$sqlQuery = ssp_sql_query($params, "order_view", $bindings, $where, '', $statusCond);

			$data = $this->Order_model->getDataTableRecords($sqlQuery, $bindings);

			// Get order stats for dashboard cards
			$stats = $this->Order_model->getOrderStats();

			$response = array(
				"draw"            => !empty( $params['draw'] ) ? intval($params['draw']) : 0,
				"recordsTotal"    => intval( $this->Order_model->countDataTableTotalRecords() ),
				"recordsFiltered" => intval( $this->Order_model->countDataTableFilterRecords($where, $bindings) ),
				"data"            => $data,
				"stats"           => $stats
			);

			echo json_encode($response);
			exit;

		} catch (Exception $e) {
			// Return error in DataTables format
			echo json_encode(array(
				"draw"            => 0,
				"recordsTotal"    => 0,
				"recordsFiltered" => 0,
				"data"            => array(),
				"error"           => $e->getMessage()
			));
			exit;
		}
	}


	public function recent_list_api()
	{
		$this->processRestCall();
		$rqData = $this->input->post();
		echo json_encode($this->Order_model->loadOrderList(-1, $rqData['limit']));
	}

	// =========================================
	// Order Management
	// =========================================

	/**
	 * Order management page
	 * @param string $id_val Encoded order ID
	 */
	public function manage($id_val = null)
	{
		if (empty($id_val)) {
			$this->session->set_flashdata('admin_error', 'Order ID is required');
			redirect('whmazadmin/order/index');
		}

		$orderId = safe_decode($id_val);
		if (!$orderId || $orderId <= 0) {
			$this->session->set_flashdata('admin_error', 'Invalid order ID');
			redirect('whmazadmin/order/index');
		}

		// SECURITY: the order id arrives in the URL. Without this a reseller
		// can open any tenant's order management page by guessing an id.
		$this->guardRecord('orders', $orderId);

		$data['order'] = $this->Order_model->getOrderWithItems($orderId);
		if (empty($data['order'])) {
			$this->session->set_flashdata('admin_error', 'Order not found');
			redirect('whmazadmin/order/index');
		}

		// Get dropdown data
		$data['registrars'] = $this->Order_model->getActiveRegistrars();
		$data['servers'] = $this->Order_model->getActiveServers();
		$data['packages'] = $this->Order_model->getPackagesByServer();
		$data['billing_cycles'] = $this->Common_model->generate_dropdown('billing_cycle', 'id', "cycle_name");

		// Status labels
		$data['domain_statuses'] = array(
			0 => array('label' => 'Pending Registration', 'class' => 'warning'),
			1 => array('label' => 'Active', 'class' => 'success'),
			2 => array('label' => 'Expired', 'class' => 'danger'),
			3 => array('label' => 'Grace Period', 'class' => 'warning'),
			4 => array('label' => 'Cancelled', 'class' => 'secondary'),
			5 => array('label' => 'Pending Transfer', 'class' => 'info')
		);

		$data['service_statuses'] = array(
			0 => array('label' => 'Pending', 'class' => 'warning'),
			1 => array('label' => 'Active', 'class' => 'success'),
			2 => array('label' => 'Expired', 'class' => 'danger'),
			3 => array('label' => 'Suspended', 'class' => 'warning'),
			4 => array('label' => 'Terminated', 'class' => 'secondary')
		);

		$data['order_types'] = array(
			1 => 'Registration',
			2 => 'Transfer',
			3 => 'DNS Only'
		);

		$this->load->view('whmazadmin/order_manage', $data);
	}

	/**
	 * API: Get order details
	 * @param string $id_val Encoded order ID
	 */
	public function get_order_details_api($id_val = null)
	{
		header('Content-Type: application/json');

		if (empty($id_val)) {
			echo json_encode(array('success' => false, 'message' => 'Order ID required'));
			return;
		}

		$orderId = safe_decode($id_val);

		// SECURITY: same exposure as manage(), via AJAX.
		$this->guardRecord('orders', $orderId);

		$order = $this->Order_model->getOrderWithItems($orderId);

		if (empty($order)) {
			echo json_encode(array('success' => false, 'message' => 'Order not found'));
			return;
		}

		echo json_encode(array('success' => true, 'data' => $order));
	}

	/**
	 * API: Update domain registrar
	 */
	public function update_domain_api()
	{
		header('Content-Type: application/json');

		$domainId = $this->input->post('domain_id');
		$registrarId = $this->input->post('registrar_id');
		$triggerTransfer = $this->input->post('trigger_transfer') == '1';

		if (empty($domainId) || empty($registrarId)) {
			echo json_encode(array('success' => false, 'message' => 'Domain ID and Registrar ID are required'));
			return;
		}

		// SECURITY: domain_id is a POST field naming another tenant's row if guessed.
		$this->guardRecord('order_domains', safe_decode($domainId));

		$result = $this->Order_model->updateDomainRegistrar(safe_decode($domainId), $registrarId);

		// If transfer is needed and requested, trigger the API call
		if ($result['success'] && $result['needs_transfer'] && $triggerTransfer) {
			$this->load->helper('domain');
			$domain = $this->Order_model->getDomainItem(safe_decode($domainId));
			// Note: Domain transfer API call would go here
			// For now, just log the action
			log_message('info', 'Domain transfer initiated for: ' . $domain['domain'] . ' to registrar ID: ' . $registrarId);
			$result['message'] = 'Registrar updated. Domain transfer initiated.';
		}

		echo json_encode($result);
	}

	/**
	 * API: Update service package/server
	 */
	public function update_service_api()
	{
		header('Content-Type: application/json');

		$serviceId = $this->input->post('service_id');
		$packageId = $this->input->post('package_id');
		$pricingId = $this->input->post('pricing_id');
		$migrateServer = $this->input->post('migrate_server') == '1';
		$upgradeCpanel = $this->input->post('upgrade_cpanel') == '1';

		if (empty($serviceId)) {
			echo json_encode(array('success' => false, 'message' => 'Service ID is required'));
			return;
		}

		// SECURITY: service_id is a POST field naming another tenant's row if guessed.
		$this->guardRecord('order_services', safe_decode($serviceId));

		// A package without its pricing row leaves recurring_amount and billing_cycle_id
		// on the old package, so renewal invoices keep billing the old price.
		if (!empty($packageId) && empty($pricingId)) {
			echo json_encode(array('success' => false, 'message' => 'A billing cycle must be selected so the recurring amount matches the new package'));
			return;
		}

		$updateData = array();
		if (!empty($packageId)) {
			$updateData['product_service_id'] = $packageId;
		}
		if (!empty($pricingId)) {
			$updateData['product_service_pricing_id'] = $pricingId;
		}

		if (empty($updateData)) {
			echo json_encode(array('success' => false, 'message' => 'No changes provided'));
			return;
		}

		$panelMessage = '';

		// Push the package change to the control panel FIRST — if the panel rejects it,
		// the local record is left untouched so the CRM never drifts from the server.
		if ($upgradeCpanel && !empty($packageId)) {
			$service = $this->Order_model->getServiceItem(safe_decode($serviceId));
			if (empty($service)) {
				echo json_encode(array('success' => false, 'message' => 'Service not found'));
				return;
			}

			$this->load->model('Provisioning_model');
			$panelResult = $this->Provisioning_model->changeServicePackage($service, $packageId);

			if (empty($panelResult['success'])) {
				echo json_encode(array(
					'success' => false,
					'message' => 'Control panel package change failed: ' . $panelResult['error'] . '. Nothing was changed.'
				));
				return;
			}

			$panelMessage = ($panelResult['module'] === 'none')
				? ' (no server module — local change only)'
				: ' Package changed on ' . $panelResult['module'] . ' server to "' . $panelResult['package'] . '".';
		}

		$result = $this->Order_model->updateServicePackage(safe_decode($serviceId), $updateData);

		if ($result['success'] && $panelMessage !== '') {
			$result['message'] .= $panelMessage;
		}

		// Handle server migration if requested
		if ($result['success'] && $migrateServer) {
			$service = $this->Order_model->getServiceItem(safe_decode($serviceId));
			// Note: Server migration logic would go here
			log_message('info', 'Server migration requested for service ID: ' . safe_decode($serviceId));
			$result['message'] .= ' Server migration marked for manual processing.';
		}

		echo json_encode($result);
	}

	/**
	 * API: Cancel domain
	 */
	public function cancel_domain_api()
	{
		header('Content-Type: application/json');

		$domainId = $this->input->post('domain_id');
		$cancelType = $this->input->post('cancel_type'); // 'immediate' or 'end_of_period'
		$reason = $this->input->post('reason');

		if (empty($domainId)) {
			echo json_encode(array('success' => false, 'message' => 'Domain ID is required'));
			return;
		}

		if (!in_array($cancelType, array('immediate', 'end_of_period'))) {
			$cancelType = 'immediate';
		}

		// SECURITY: cancelling another tenant's domain is irreversible.
		$this->guardRecord('order_domains', safe_decode($domainId));

		$result = $this->Order_model->cancelDomain(safe_decode($domainId), $cancelType, $reason);

		echo json_encode(array(
			'success' => $result,
			'message' => $result ? 'Domain cancelled successfully' : 'Failed to cancel domain'
		));
	}

	/**
	 * API: Cancel service
	 */
	public function cancel_service_api()
	{
		header('Content-Type: application/json');

		$serviceId = $this->input->post('service_id');
		$cancelType = $this->input->post('cancel_type'); // 'immediate' or 'end_of_period'
		$reason = $this->input->post('reason');
		$deleteCpanel = $this->input->post('delete_cpanel') == '1';

		if (empty($serviceId)) {
			echo json_encode(array('success' => false, 'message' => 'Service ID is required'));
			return;
		}

		// SECURITY: irreversible — with delete_cpanel this removes the remote
		// hosting account, not just the local record.
		$this->guardRecord('order_services', safe_decode($serviceId));

		if (!in_array($cancelType, array('immediate', 'end_of_period'))) {
			$cancelType = 'immediate';
		}

		// If immediate cancellation and delete cPanel requested
		if ($cancelType === 'immediate' && $deleteCpanel) {
			$service = $this->Order_model->getServiceItem(safe_decode($serviceId));
			if (!empty($service['cp_username'])) {
				$this->load->helper('cpanel');
				// Note: WHM API call to terminate account would go here
				log_message('info', 'cPanel account deletion requested for: ' . $service['cp_username']);
			}
		}

		$result = $this->Order_model->cancelService(safe_decode($serviceId), $cancelType, $reason);

		echo json_encode(array(
			'success' => $result,
			'message' => $result ? 'Service cancelled successfully' : 'Failed to cancel service'
		));
	}

	/**
	 * API: Cancel entire order
	 */
	public function cancel_order_api()
	{
		header('Content-Type: application/json');

		$orderId = $this->input->post('order_id');
		$cancelType = $this->input->post('cancel_type'); // 'immediate' or 'end_of_period'
		$reason = $this->input->post('reason');

		if (empty($orderId)) {
			echo json_encode(array('success' => false, 'message' => 'Order ID is required'));
			return;
		}

		// SECURITY: cancels every item on the order AND its unpaid invoices.
		$this->guardRecord('orders', safe_decode($orderId));

		if (!in_array($cancelType, array('immediate', 'end_of_period'))) {
			$cancelType = 'immediate';
		}

		// Get order details before cancellation for invoice count
		$order = $this->Order_model->getOrderWithItems(safe_decode($orderId));

		// Count unpaid invoices before cancellation
		$this->db->where('order_id', safe_decode($orderId));
		$this->db->where_in('pay_status', array('DUE', 'PARTIAL'));
		$this->db->where('status', 1);
		$unpaidInvoiceCount = $this->db->count_all_results('invoices');

		$result = $this->Order_model->cancelOrder(safe_decode($orderId), $cancelType, $reason);

		$message = 'Order cancelled successfully';
		if ($result && $unpaidInvoiceCount > 0) {
			$message .= '. ' . $unpaidInvoiceCount . ' unpaid invoice(s) also cancelled.';
		}

		echo json_encode(array(
			'success' => $result,
			'message' => $result ? $message : 'Failed to cancel order',
			'invoices_cancelled' => $result ? $unpaidInvoiceCount : 0
		));
	}

	/**
	 * API: Get packages by server (for dynamic dropdown)
	 */
	public function get_packages_api()
	{
		header('Content-Type: application/json');

		$serverId = $this->input->get('server_id');
		$packages = $this->Order_model->getPackagesByServer($serverId);

		echo json_encode(array('success' => true, 'data' => $packages));
	}

	/**
	 * API: Get package pricing
	 */
	public function get_pricing_api()
	{
		header('Content-Type: application/json');

		$packageId = $this->input->get('package_id');
		$currencyId = $this->input->get('currency_id');

		if (empty($packageId)) {
			echo json_encode(array('success' => false, 'message' => 'Package ID required'));
			return;
		}

		$this->db->select('psp.*, bc.cycle_name');
		$this->db->from('product_service_pricing psp');
		$this->db->join('billing_cycle bc', 'psp.billing_cycle_id = bc.id', 'left');
		$this->db->where('psp.product_service_id', $packageId);
		$this->db->where('psp.status', 1);

		if (!empty($currencyId)) {
			$this->db->where('psp.currency_id', $currencyId);
		}

		$this->db->order_by('bc.cycle_days', 'ASC');
		$pricing = $this->db->get()->result_array();

		echo json_encode(array('success' => true, 'data' => $pricing));
	}

}

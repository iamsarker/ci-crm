<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Company extends WHMAZADMIN_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('Company_model');
		$this->load->model('Common_model');
		if (!$this->isLogin()) {
			redirect('/whmazadmin/authenticate/login', 'refresh');
		}
	}

	public function index()
	{
		$data['results'] = array();
		$this->load->view('whmazadmin/company_list', $data);
	}

	public function manage($id_val = null)
	{
		if( $this->input->post() ){
			$this->form_validation->set_rules('name', 'Name', 'required|trim');
			$this->form_validation->set_message('name', 'Name is required');

			$this->form_validation->set_rules('mobile', 'mobile', 'required|trim');
			$this->form_validation->set_message('mobile', 'mobile is required');

			$this->form_validation->set_rules('email', 'email', 'required|trim');
			$this->form_validation->set_message('email', 'email is required');

			$this->form_validation->set_rules('zip_code', 'zip code', 'required|trim');
			$this->form_validation->set_message('zip_code', 'zip code is required');

			$this->form_validation->set_rules('city', 'city', 'required|trim');
			$this->form_validation->set_message('city', 'city is required');

			$this->form_validation->set_rules('state', 'state', 'required|trim');
			$this->form_validation->set_message('state', 'state is required');

			$this->form_validation->set_rules('address', 'address', 'required|trim');
			$this->form_validation->set_message('address', 'address is required');

			$this->form_validation->set_rules('country', 'country', 'required|trim');
			$this->form_validation->set_message('country', 'country is required');

			if ($this->form_validation->run() == true){

				$form_data = array(
					'id'			=> safe_decode($this->input->post('id')),
					'name'			=> $this->input->post('name'),
					'first_name'	=> $this->input->post('first_name'),
					'last_name'		=> $this->input->post('last_name'),
					'mobile'		=> $this->input->post('mobile'),
					'email'			=> $this->input->post('email'),
					'phone'			=> $this->input->post('phone'),
					'city'			=> $this->input->post('city'),
					'state'			=> $this->input->post('state'),
					'zip_code'		=> $this->input->post('zip_code'),
					'address'		=> $this->input->post('address'),
					'country'		=> $this->input->post('country'),
					'status'       	=> 1
				);

				if( strlen($form_data['id']) > 0 ){
					// SECURITY: the id comes from a POST field, so guard it —
					// otherwise a reseller can overwrite any tenant's customer
					// record by editing the hidden input.
					$this->guardCompany($form_data['id']);

					$oldEntity = $this->Company_model->getDetail(safe_decode($id_val));
					$form_data['updated_on'] = getDateTime();
					$form_data['updated_by'] = getAdminId();

					$form_data['inserted_on'] = $oldEntity['inserted_on'] ?? getDateTime();
					$form_data['inserted_by'] = $oldEntity['inserted_by'] ?? getAdminId();
				} else {
					$form_data['inserted_on'] = getDateTime();
					$form_data['inserted_by'] = getAdminId();

					// A customer created by a reseller belongs to that reseller.
					// Without this the new company lands with parent_company_id = 0
					// (platform-direct) and immediately falls outside its own
					// creator's scope — invisible the moment the page reloads.
					if( isResellerAdmin() ){
						$form_data['parent_company_id'] = adminCompanyId();
						$form_data['is_reseller']       = 0;   // req. 6: no sub-resellers
					}
				}

				$resp = $this->Company_model->saveData($form_data);
				if($resp){

					if( $form_data['id'] == 0 ){
						// SECURITY FIX: Generate secure random password instead of hardcoded password
						$temp_password = generate_secure_password(12, true); // Generate 12-character random password

						$user['first_name'] = $form_data['first_name'];
						$user['last_name'] = $form_data['last_name'];
						$user['email'] = $form_data['email'];
						$user['mobile'] = $form_data['mobile'];
						$user['phone'] = $form_data['phone'];
						$user['designation'] = 'Company Owner';
						$user['password'] = password_hash($temp_password, PASSWORD_DEFAULT);
						$user['company_id'] = $resp['id'];
						$user['user_type'] = '0'; // owner
						$user['status'] = '1'; // active
						$user['login_try'] = '0';
						$user['inserted_on'] = getDateTime();
						$user['inserted_by'] = $form_data['inserted_by'];
						$this->Common_model->save("users", $user);

						// SECURITY: Store temporary password in session to display to admin
						$this->session->set_flashdata('new_user_credentials', array(
							'email' => $form_data['email'],
							'password' => $temp_password,
							'company_name' => $form_data['name']
						));
					}

					$this->session->set_flashdata('admin_success', 'Customer has been saved successfully.');
					redirect("whmazadmin/company/index");
				}else {
					$this->session->set_flashdata('admin_error', 'Something went wrong. Try again');
				}
			}

		}

		if( !empty($id_val) ){
			// SECURITY: guard the edit form itself, not just the save — the
			// form renders the customer's full contact record.
			$this->guardCompany(safe_decode($id_val));
			$data['detail'] = $this->Company_model->getDetail(safe_decode($id_val));
		} else {
			$data['detail'] = array();
		}

		$data['countries'] = $this->Common_model->generate_dropdown('countries','country_name','country_name');

		$this->load->view('whmazadmin/company_manage', $data);
	}

	public function delete_records($id_val)
	{
		// SECURITY: a customer's own id IS the scope key here (companies.id),
		// so guard before loading. Without it a reseller could soft-delete any
		// tenant's customer by id.
		$this->guardCompany(safe_decode($id_val));

		$entity = $this->Company_model->getDetail(safe_decode($id_val));
		$entity["status"] = 0;
		$entity["deleted_on"] = getDateTime();
		$entity["deleted_by"] = getAdminId();

		$this->Company_model->saveData($entity);
		$this->session->set_flashdata('admin_success', 'Customer has been deleted successfully.');

		redirect('whmazadmin/company/index');
	}

	/**
	 * Transfer a customer between resellers (v2.0.0 req. 9).
	 *
	 * POST: company_id, reseller_company_id (0 = back to platform-direct), notes
	 *
	 * PLATFORM ADMINS ONLY. A reseller must not be able to pull another
	 * tenant's customer into their own scope — which is exactly what this
	 * endpoint would let them do, since it rewrites parent_company_id.
	 * RequestGuard allows the `company` controller for resellers, so the
	 * restriction has to be stated here.
	 */
	public function transfer_reseller()
	{
		header('Content-Type: application/json');

		if (isResellerAdmin()) {
			tenant_deny('Only platform staff can transfer customers between resellers.');
		}

		$companyId  = intval($this->input->post('company_id'));
		$resellerId = intval($this->input->post('reseller_company_id'));
		$notes      = (string) $this->input->post('notes');

		if ($companyId <= 0) {
			echo json_encode(array('success' => false, 'message' => 'Customer is required'));
			return;
		}

		$result = $this->Company_model->transferToReseller($companyId, $resellerId, $notes);
		echo json_encode($result);
	}

	public function ssp_list_api()
	{
		$this->processRestCall();

		// Set proper JSON headers
		header('Content-Type: application/json');

		try {
			$params = $this->input->get();

			$bindings = array();
			$where = '';

			$sqlQuery = ssp_sql_query($params, "companies", $bindings, $where);

			$data = $this->Company_model->getDataTableRecords($sqlQuery, $bindings);

			// Get company stats for dashboard cards
			$stats = $this->Company_model->getCompanyStats();

			$response = array(
				"draw"            => !empty( $params['draw'] ) ? intval($params['draw']) : 0,
				"recordsTotal"    => intval( $this->Company_model->countDataTableTotalRecords() ),
				"recordsFiltered" => intval( $this->Company_model->countDataTableFilterRecords($where, $bindings) ),
				"data"            => $data,
				"stats"           => $stats
			);

			echo json_encode($response);
			exit;

		} catch (Exception $e) {
			// SECURITY: Log database error
			ErrorHandler::log_database_error('ssp_list_api', 'DataTables API', $e->getMessage());

			// Return error in DataTables format
			echo json_encode(array(
				"draw"            => 0,
				"recordsTotal"    => 0,
				"recordsFiltered" => 0,
				"data"            => array(),
				"error"           => $e->getMessage()
			));
			exit;
		}
	}

	/**
	 * Server-side DataTable API for Services (order_services)
	 */
	public function ssp_services_api($tmpCompanyId = null)
	{
		$this->processRestCall();

		header('Content-Type: application/json');

		try {
			$params = $this->input->get();
			$companyId = !empty($tmpCompanyId) ? safe_decode($tmpCompanyId) : 0;

			// SECURITY: defence in depth. ssp_tenant_scope() inside
			// ssp_sql_query() already restricts the rows, so an out-of-scope id
			// would simply return nothing — but refuse outright so probing for
			// other tenants' company ids is a 403 rather than a silent empty
			// list. The injection below is a convenience filter, NOT a security
			// boundary: it writes into columns[i][search][value], which
			// ssp_filter() reads straight from the query string and the client
			// can overwrite at will.
			if ($companyId > 0) {
				$this->guardCompany($companyId);
			}

			// Inject company_id filter
			if ($companyId > 0) {
				for ($i = 0; $i < count($params["columns"]); $i++) {
					if ($params["columns"][$i]['data'] == "company_id") {
						$params["columns"][$i]["search"]["value"] = intval($companyId);
						break;
					}
				}
			}

			$bindings = array();
			$where = '';
			$statusCond = " `status` IN (0,1,2,3,4) ";

			$sqlQuery = ssp_sql_query($params, "order_services", $bindings, $where, '', $statusCond);

			$data = $this->Company_model->getServicesDataTableRecords($sqlQuery, $bindings);

			$response = array(
				"draw"            => !empty($params['draw']) ? intval($params['draw']) : 0,
				"recordsTotal"    => intval($this->Company_model->countServicesDataTableTotalRecords($companyId)),
				"recordsFiltered" => intval($this->Company_model->countServicesDataTableFilterRecords($where, $bindings)),
				"data"            => $data
			);

			echo json_encode($response);
			exit;

		} catch (Exception $e) {
			ErrorHandler::log_database_error('ssp_services_api', 'DataTables API', $e->getMessage());

			echo json_encode(array(
				"draw"            => 0,
				"recordsTotal"    => 0,
				"recordsFiltered" => 0,
				"data"            => array(),
				"error"           => $e->getMessage()
			));
			exit;
		}
	}

	/**
	 * Server-side DataTable API for Domains (order_domains)
	 */
	public function ssp_domains_api($tmpCompanyId = null)
	{
		$this->processRestCall();

		header('Content-Type: application/json');

		try {
			$params = $this->input->get();
			$companyId = !empty($tmpCompanyId) ? safe_decode($tmpCompanyId) : 0;

			// SECURITY: defence in depth. ssp_tenant_scope() inside
			// ssp_sql_query() already restricts the rows, so an out-of-scope id
			// would simply return nothing — but refuse outright so probing for
			// other tenants' company ids is a 403 rather than a silent empty
			// list. The injection below is a convenience filter, NOT a security
			// boundary: it writes into columns[i][search][value], which
			// ssp_filter() reads straight from the query string and the client
			// can overwrite at will.
			if ($companyId > 0) {
				$this->guardCompany($companyId);
			}

			// Inject company_id filter
			if ($companyId > 0) {
				for ($i = 0; $i < count($params["columns"]); $i++) {
					if ($params["columns"][$i]['data'] == "company_id") {
						$params["columns"][$i]["search"]["value"] = $companyId;
						break;
					}
				}
			}

			$bindings = array();
			$where = '';
			$statusCond = " `status` IN (0,1,2,3,4,5,6) ";

			$sqlQuery = ssp_sql_query($params, "order_domains", $bindings, $where, '', $statusCond);

			$data = $this->Company_model->getDomainsDataTableRecords($sqlQuery, $bindings);

			$response = array(
				"draw"            => !empty($params['draw']) ? intval($params['draw']) : 0,
				"recordsTotal"    => intval($this->Company_model->countDomainsDataTableTotalRecords($companyId)),
				"recordsFiltered" => intval($this->Company_model->countDomainsDataTableFilterRecords($where, $bindings)),
				"data"            => $data
			);

			echo json_encode($response);
			exit;

		} catch (Exception $e) {
			ErrorHandler::log_database_error('ssp_domains_api', 'DataTables API', $e->getMessage());

			echo json_encode(array(
				"draw"            => 0,
				"recordsTotal"    => 0,
				"recordsFiltered" => 0,
				"data"            => array(),
				"error"           => $e->getMessage()
			));
			exit;
		}
	}

	/**
	 * Get service detail for management modal
	 * @param int $serviceId Service ID
	 * @param int $companyId Company ID for security validation
	 */
	public function get_service_detail($serviceId = null, $companyId = null)
	{
		$this->processRestCall();
		header('Content-Type: application/json');

		if (empty($serviceId) || !is_numeric($serviceId) || empty($companyId) || !is_numeric($companyId)) {
			echo json_encode(array('success' => false, 'message' => 'Invalid parameters'));
			exit;
		}

		// SECURITY: guard BOTH ids. getServiceDetail() matches the service to
		// the company, so guarding the company alone would be enough today —
		// but guarding the service too keeps this correct if that model method
		// ever loosens.
		$this->guardCompany($companyId);
		$this->guardRecord('order_services', $serviceId);

		try {
			$service = $this->Company_model->getServiceDetail($serviceId, $companyId);

			if (empty($service)) {
				echo json_encode(array('success' => false, 'message' => 'Service not found'));
				exit;
			}

			echo json_encode(array('success' => true, 'data' => $service));
		} catch (Exception $e) {
			ErrorHandler::log_database_error('get_service_detail', 'Service detail fetch', $e->getMessage());
			echo json_encode(array('success' => false, 'message' => 'Failed to load service details'));
		}
		exit;
	}

	/**
	 * Update service details (cp_username, status)
	 * @param int $serviceId Service ID
	 */
	public function update_service($serviceId = null)
	{
		$this->processRestCall();
		header('Content-Type: application/json');

		if (empty($serviceId) || !is_numeric($serviceId)) {
			echo json_encode(array('success' => false, 'message' => 'Invalid service ID'));
			exit;
		}

		// SECURITY: the RequestGuard hook lets resellers into this controller,
		// but it cannot know whose service $serviceId names. Without this a
		// reseller could suspend or TERMINATE another tenant's hosting account
		// just by guessing an integer. Never returns if out of scope.
		$this->guardRecord('order_services', $serviceId);

		$cpUsername = $this->input->post('cp_username');
		$status = $this->input->post('status');

		// Validate cPanel username format if provided
		if (!empty($cpUsername) && !preg_match('/^[a-z][a-z0-9]{0,7}$/', $cpUsername)) {
			echo json_encode(array('success' => false, 'message' => 'Invalid cPanel username format'));
			exit;
		}

		// Validate status
		$validStatuses = array(0, 1, 2, 3, 4);
		if (!in_array((int)$status, $validStatuses)) {
			echo json_encode(array('success' => false, 'message' => 'Invalid status'));
			exit;
		}

		try {
			$updateData = array(
				'cp_username' => $cpUsername,
				'status' => (int)$status,
				'updated_on' => getDateTime(),
				'updated_by' => getAdminId()
			);

			$result = $this->Company_model->updateService($serviceId, $updateData);

			if ($result) {
				echo json_encode(array('success' => true, 'message' => 'Service updated successfully'));
			} else {
				echo json_encode(array('success' => false, 'message' => 'Failed to update service'));
			}
		} catch (Exception $e) {
			ErrorHandler::log_database_error('update_service', 'Service update', $e->getMessage());
			echo json_encode(array('success' => false, 'message' => 'Error updating service'));
		}
		exit;
	}

	/**
	 * Create cPanel account for a service
	 * @param int $serviceId Service ID
	 */
	public function create_cpanel_account($serviceId = null)
	{
		$this->processRestCall();
		header('Content-Type: application/json');

		if (empty($serviceId) || !is_numeric($serviceId)) {
			echo json_encode(array('success' => false, 'message' => 'Invalid service ID'));
			exit;
		}

		// SECURITY: the RequestGuard hook lets resellers into this controller,
		// but it cannot know whose service $serviceId names. Without this a
		// reseller could suspend or TERMINATE another tenant's hosting account
		// just by guessing an integer. Never returns if out of scope.
		$this->guardRecord('order_services', $serviceId);

		$cpUsername = $this->input->post('cp_username');

		if (empty($cpUsername)) {
			echo json_encode(array('success' => false, 'message' => 'cPanel username is required'));
			exit;
		}

		// Validate cPanel username format
		if (!preg_match('/^[a-z][a-z0-9]{0,7}$/', $cpUsername)) {
			echo json_encode(array('success' => false, 'message' => 'Invalid cPanel username format'));
			exit;
		}

		try {
			// Get service details
			$service = $this->Company_model->getServiceDetailForCpanel($serviceId);

			if (empty($service)) {
				echo json_encode(array('success' => false, 'message' => 'Service not found'));
				exit;
			}

			// Check if hosting domain is set
			if (empty($service['hosting_domain'])) {
				echo json_encode(array('success' => false, 'message' => 'Hosting domain is not configured for this service'));
				exit;
			}

			// Get server info
			$serverInfo = $this->Common_model->getServerInfoByOrderServiceId($serviceId, $service['company_id']);

			if (empty($serverInfo)) {
				echo json_encode(array('success' => false, 'message' => 'Server information not found for this service'));
				exit;
			}

			// Get customer info for email
			$company = $this->Company_model->getDetail($service['company_id']);

			// Generate secure password
			$password = generate_secure_password(16, true);

			// Get package name
			$package = !empty($service['cp_package']) ? $service['cp_package'] : 'default';

			// Determine module from server
			$moduleName = strtolower(trim($serverInfo['module_name'] ?? ''));

			$customerName = trim($company['first_name'] . ' ' . $company['last_name']);
			if (empty($customerName)) {
				$customerName = $company['name'];
			}

			// Dispatch based on module
			if ($moduleName === 'cpanel') {
				$result = whm_create_account($serverInfo, $service['hosting_domain'], $cpUsername, $password, $package, $company['email']);
			} elseif ($moduleName === 'plesk') {
				$result = plesk_create_account($serverInfo, $service['hosting_domain'], $cpUsername, $password, $package, $company['email']);
			} elseif ($moduleName === 'directadmin') {
				$result = da_create_account($serverInfo, $service['hosting_domain'], $cpUsername, $password, $package, $company['email']);
			} else {
				echo json_encode(array('success' => false, 'message' => 'Server has no provisioning module configured'));
				exit;
			}

			if ($result['success']) {
				$updateData = array(
					'cp_username' => $cpUsername,
					'is_synced' => 1,
					'status' => 1,
					'updated_on' => getDateTime(),
					'updated_by' => getAdminId()
				);
				$this->Company_model->updateService($serviceId, $updateData);

				// Send welcome email based on module
				if ($moduleName === 'cpanel') {
					send_cpanel_welcome_email($company['email'], $customerName, $service['hosting_domain'], $cpUsername, $password, $serverInfo['hostname']);
				} elseif ($moduleName === 'plesk') {
					send_plesk_welcome_email($company['email'], $customerName, $service['hosting_domain'], $cpUsername, $password, $serverInfo['hostname']);
				} elseif ($moduleName === 'directadmin') {
					send_da_welcome_email($company['email'], $customerName, $service['hosting_domain'], $cpUsername, $password, $serverInfo['hostname']);
				}

				echo json_encode(array('success' => true, 'message' => 'Hosting account created successfully. Welcome email sent.'));
			} else {
				echo json_encode(array('success' => false, 'message' => 'Failed to create account: ' . $result['error']));
			}
		} catch (Exception $e) {
			ErrorHandler::log_database_error('create_cpanel_account', 'cPanel account creation', $e->getMessage());
			echo json_encode(array('success' => false, 'message' => 'Error creating cPanel account'));
		}
		exit;
	}

	/**
	 * Sync cPanel account usage stats from WHM server
	 * @param int $serviceId Service ID
	 */
	public function sync_cpanel_account($serviceId = null)
	{
		$this->processRestCall();
		header('Content-Type: application/json');

		if (empty($serviceId) || !is_numeric($serviceId)) {
			echo json_encode(array('success' => false, 'message' => 'Invalid service ID'));
			exit;
		}

		// SECURITY: the RequestGuard hook lets resellers into this controller,
		// but it cannot know whose service $serviceId names. Without this a
		// reseller could suspend or TERMINATE another tenant's hosting account
		// just by guessing an integer. Never returns if out of scope.
		$this->guardRecord('order_services', $serviceId);

		try {
			// Get service details
			$service = $this->Company_model->getServiceDetailForCpanel($serviceId);

			if (empty($service)) {
				echo json_encode(array('success' => false, 'message' => 'Service not found'));
				exit;
			}

			if (empty($service['cp_username'])) {
				echo json_encode(array('success' => false, 'message' => 'No cPanel username configured'));
				exit;
			}

			// Get server info
			$serverInfo = $this->Common_model->getServerInfoByOrderServiceId($serviceId, $service['company_id']);

			if (empty($serverInfo)) {
				echo json_encode(array('success' => false, 'message' => 'Server information not found'));
				exit;
			}

			// Load cPanel helper
			$this->load->helper('cpanel');

			// Get usage stats from cPanel (like client portal)
			$statsResult = whm_get_account_stats($serverInfo, $service['cp_username']);

			if ($statsResult['success']) {
				// Update sync status
				$updateData = array(
					'is_synced' => 1,
					'updated_on' => getDateTime(),
					'updated_by' => getAdminId()
				);
				$this->Company_model->updateService($serviceId, $updateData);

				// Save stats to database if model method exists
				if (method_exists($this->Company_model, 'saveCpanelUsageStats')) {
					$this->Company_model->saveCpanelUsageStats($serviceId, $service['company_id'], $statsResult['stats']);
				}

				echo json_encode(array(
					'success' => true,
					'message' => 'cPanel usage stats synced successfully',
					'stats' => $statsResult['stats']
				));
			} else {
				// Mark as not synced if account not found
				$updateData = array(
					'is_synced' => 0,
					'updated_on' => getDateTime(),
					'updated_by' => getAdminId()
				);
				$this->Company_model->updateService($serviceId, $updateData);

				echo json_encode(array(
					'success' => false,
					'message' => 'Failed to fetch cPanel stats: ' . ($statsResult['error'] ?? 'Unknown error')
				));
			}
		} catch (Exception $e) {
			ErrorHandler::log_database_error('sync_cpanel_account', 'cPanel sync', $e->getMessage());
			echo json_encode(array('success' => false, 'message' => 'Error syncing cPanel account'));
		}
		exit;
	}

	/**
	 * Suspend cPanel account
	 * @param int $serviceId Service ID
	 */
	public function suspend_cpanel_account($serviceId = null)
	{
		$this->processRestCall();
		header('Content-Type: application/json');

		if (empty($serviceId) || !is_numeric($serviceId)) {
			echo json_encode(array('success' => false, 'message' => 'Invalid service ID'));
			exit;
		}

		// SECURITY: the RequestGuard hook lets resellers into this controller,
		// but it cannot know whose service $serviceId names. Without this a
		// reseller could suspend or TERMINATE another tenant's hosting account
		// just by guessing an integer. Never returns if out of scope.
		$this->guardRecord('order_services', $serviceId);

		try {
			$service = $this->Company_model->getServiceDetailForCpanel($serviceId);

			if (empty($service) || empty($service['cp_username'])) {
				echo json_encode(array('success' => false, 'message' => 'Service or username not found'));
				exit;
			}

			$serverInfo = $this->Common_model->getServerInfoByOrderServiceId($serviceId, $service['company_id']);

			if (empty($serverInfo)) {
				echo json_encode(array('success' => false, 'message' => 'Server information not found'));
				exit;
			}

			$moduleName = strtolower(trim($serverInfo['module_name'] ?? ''));

			if ($moduleName === 'cpanel') {
				$result = whm_suspend_account($serverInfo, $service['cp_username'], 'Suspended by administrator');
			} elseif ($moduleName === 'plesk') {
				$result = plesk_suspend_account($serverInfo, $service['hosting_domain'], 'Suspended by administrator');
			} elseif ($moduleName === 'directadmin') {
				$result = da_suspend_account($serverInfo, $service['cp_username'], 'Suspended by administrator');
			} else {
				$result = array('success' => true);
			}

			if ($result['success']) {
				$updateData = array('status' => 3, 'updated_on' => getDateTime(), 'updated_by' => getAdminId());
				$this->Company_model->updateService($serviceId, $updateData);
				echo json_encode(array('success' => true, 'message' => 'Account suspended successfully'));
			} else {
				echo json_encode(array('success' => false, 'message' => 'Failed to suspend: ' . $result['error']));
			}
		} catch (Exception $e) {
			ErrorHandler::log_database_error('suspend_account', 'Account suspend', $e->getMessage());
			echo json_encode(array('success' => false, 'message' => 'Error suspending account'));
		}
		exit;
	}

	/**
	 * Unsuspend cPanel account
	 * @param int $serviceId Service ID
	 */
	public function unsuspend_cpanel_account($serviceId = null)
	{
		$this->processRestCall();
		header('Content-Type: application/json');

		if (empty($serviceId) || !is_numeric($serviceId)) {
			echo json_encode(array('success' => false, 'message' => 'Invalid service ID'));
			exit;
		}

		// SECURITY: the RequestGuard hook lets resellers into this controller,
		// but it cannot know whose service $serviceId names. Without this a
		// reseller could suspend or TERMINATE another tenant's hosting account
		// just by guessing an integer. Never returns if out of scope.
		$this->guardRecord('order_services', $serviceId);

		try {
			$service = $this->Company_model->getServiceDetailForCpanel($serviceId);

			if (empty($service) || empty($service['cp_username'])) {
				echo json_encode(array('success' => false, 'message' => 'Service or username not found'));
				exit;
			}

			$serverInfo = $this->Common_model->getServerInfoByOrderServiceId($serviceId, $service['company_id']);

			if (empty($serverInfo)) {
				echo json_encode(array('success' => false, 'message' => 'Server information not found'));
				exit;
			}

			$moduleName = strtolower(trim($serverInfo['module_name'] ?? ''));

			if ($moduleName === 'cpanel') {
				$result = whm_unsuspend_account($serverInfo, $service['cp_username']);
			} elseif ($moduleName === 'plesk') {
				$result = plesk_unsuspend_account($serverInfo, $service['hosting_domain']);
			} elseif ($moduleName === 'directadmin') {
				$result = da_unsuspend_account($serverInfo, $service['cp_username']);
			} else {
				$result = array('success' => true);
			}

			if ($result['success']) {
				$updateData = array('status' => 1, 'updated_on' => getDateTime(), 'updated_by' => getAdminId());
				$this->Company_model->updateService($serviceId, $updateData);
				echo json_encode(array('success' => true, 'message' => 'Account unsuspended successfully'));
			} else {
				echo json_encode(array('success' => false, 'message' => 'Failed to unsuspend: ' . $result['error']));
			}
		} catch (Exception $e) {
			ErrorHandler::log_database_error('unsuspend_account', 'Account unsuspend', $e->getMessage());
			echo json_encode(array('success' => false, 'message' => 'Error unsuspending account'));
		}
		exit;
	}

	/**
	 * Terminate cPanel account
	 * @param int $serviceId Service ID
	 */
	public function terminate_cpanel_account($serviceId = null)
	{
		$this->processRestCall();
		header('Content-Type: application/json');

		if (empty($serviceId) || !is_numeric($serviceId)) {
			echo json_encode(array('success' => false, 'message' => 'Invalid service ID'));
			exit;
		}

		// SECURITY: the RequestGuard hook lets resellers into this controller,
		// but it cannot know whose service $serviceId names. Without this a
		// reseller could suspend or TERMINATE another tenant's hosting account
		// just by guessing an integer. Never returns if out of scope.
		$this->guardRecord('order_services', $serviceId);

		try {
			$service = $this->Company_model->getServiceDetailForCpanel($serviceId);

			if (empty($service) || empty($service['cp_username'])) {
				echo json_encode(array('success' => false, 'message' => 'Service or username not found'));
				exit;
			}

			$serverInfo = $this->Common_model->getServerInfoByOrderServiceId($serviceId, $service['company_id']);

			if (empty($serverInfo)) {
				echo json_encode(array('success' => false, 'message' => 'Server information not found'));
				exit;
			}

			$moduleName = strtolower(trim($serverInfo['module_name'] ?? ''));

			if ($moduleName === 'cpanel') {
				$result = whm_terminate_account($serverInfo, $service['cp_username']);
			} elseif ($moduleName === 'plesk') {
				$result = plesk_terminate_account($serverInfo, $service['hosting_domain']);
			} elseif ($moduleName === 'directadmin') {
				$result = da_terminate_account($serverInfo, $service['cp_username']);
			} else {
				$result = array('success' => true);
			}

			if ($result['success']) {
				$updateData = array(
					'status' => 4,
					'cp_username' => null,
					'is_synced' => 0,
					'updated_on' => getDateTime(),
					'updated_by' => getAdminId()
				);
				$this->Company_model->updateService($serviceId, $updateData);
				echo json_encode(array('success' => true, 'message' => 'Account terminated successfully'));
			} else {
				echo json_encode(array('success' => false, 'message' => 'Failed to terminate: ' . $result['error']));
			}
		} catch (Exception $e) {
			ErrorHandler::log_database_error('terminate_account', 'Account terminate', $e->getMessage());
			echo json_encode(array('success' => false, 'message' => 'Error terminating account'));
		}
		exit;
	}

}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * ApiDomains — availability check + the reseller's registered domains.
 *
 *   GET /api/v1/domains/check?domain=example.com   availability     [domains:read]
 *   GET /api/v1/domains                            list domains     [domains:read]
 *   GET /api/v1/domains/view/{id}                  single domain    [domains:read]
 *
 * Domain registration/renewal happens by placing an order (POST /orders) and
 * paying its invoice (POST /invoices/pay), which triggers provisioning.
 */
class ApiDomains extends API_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('domain');
		$this->load->model('Cart_model');
	}

	public function check()
	{
		$this->requireScope('domains:read');
		$domain = trim((string) $this->param('domain'));
		if ($domain === '' || strpos($domain, '.') === false) {
			$this->fail(422, 'A valid domain (e.g. example.com) is required.', 'validation_error');
		}

		$registrar = $this->db->query(
			"SELECT * FROM dom_registers WHERE status = 1 AND is_selected = 1 LIMIT 1"
		)->row_array();
		if (empty($registrar)) {
			$this->fail(503, 'No default domain registrar configured.', 'registrar_unavailable');
		}

		$parts      = explode('.', $domain);
		$sld        = $parts[0];
		$extension  = count($parts) > 1 ? end($parts) : 'com';   // last label (mirrors storefront)
		$currencyId = intval($this->param('currency_id')) ?: 1;
		$price      = $this->_priceFor($this->_domPricing($currencyId), '.' . $extension, $currencyId);

		$platform  = strtolower($registrar['platform']);
		$available = false;
		$premium   = false;

		if ($platform === 'namecheap') {
			$result = namecheap_check_domain($registrar, $domain);
			if (empty($result['success'])) {
				$this->fail(502, !empty($result['error']) ? $result['error'] : 'Registrar lookup failed.', 'registrar_error');
			}
			$available = !empty($result['available']);
			$premium   = !empty($result['premium']);
		} else {
			// STARGATE / ResellerClub / Resell.biz — httpapi.com-style check.
			// Uses domain_api_get() (WHMAZ/1.0 User-Agent + 403/429 retry), the
			// same hardened path as the rest of the registrar integration.
			if (empty($registrar['domain_check_api'])) {
				$this->fail(503, 'Domain check API is not configured for the registrar.', 'registrar_unavailable');
			}
			$url = $registrar['domain_check_api']
				. 'auth-userid=' . rawurlencode($registrar['auth_userid'])
				. '&api-key=' . rawurlencode($registrar['auth_apikey'])
				. '&domain-name=' . rawurlencode($sld)
				. '&tlds=' . rawurlencode($extension);

			$resp = domain_api_get($url);
			if (empty($resp['success']) || !is_array($resp['data']) || empty($resp['data'])) {
				// A 403/empty here is usually the server IP not being whitelisted
				// at the registrar (ResellerClub/Resell.biz API → Allowed IPs).
				$code = !empty($resp['http_code']) ? $resp['http_code'] : 0;
				$this->fail(502,
					'No usable response from the domain registrar (HTTP ' . $code . '). '
					. 'Ensure this server\'s outbound IP is whitelisted in the registrar API settings.',
					'registrar_error');
			}
			foreach ($resp['data'] as $dName => $info) {
				if (!is_array($info)) continue;
				$available = isset($info['status']) && $info['status'] === 'available';
				$premium   = isset($info['classkey']) && stripos($info['classkey'], 'premium') !== false;
				break;   // single domain queried → first row is ours
			}
		}

		$this->ok(array(
			'domain'         => $domain,
			'available'      => $available,
			'premium'        => $premium,
			'registrar'      => $registrar['platform'],
			'price'          => !empty($price['price']) ? (float) $price['price'] : null,
			'dom_pricing_id' => !empty($price['id']) ? intval($price['id']) : 0,  // -> cart/add_domain
		));
	}

	/**
	 * Domain name suggestions for a keyword, with pricing.
	 *   GET /api/v1/domains/suggest?keyword=example[&currency_id=1]
	 * Mirrors the storefront's cart/get_domain_suggestions (Namecheap → common
	 * TLD availability; ResellerClub/Resell.biz → registrar suggestion API).
	 */
	public function suggest()
	{
		$this->requireScope('domains:read');
		$keyword = trim((string) ($this->param('keyword') ?: $this->param('domkeyword') ?: $this->param('domain')));
		if ($keyword === '') {
			$this->fail(422, 'A keyword is required.', 'validation_error');
		}
		$currencyId = intval($this->param('currency_id')) ?: 1;

		$parts     = explode('.', $keyword);
		$sld       = $parts[0];
		$extension = count($parts) > 1 ? end($parts) : 'com';

		$registrar = $this->Cart_model->getDomRegister('.' . $extension);
		if (empty($registrar)) {
			$this->fail(503, 'No default domain registrar configured.', 'registrar_unavailable');
		}
		$priceList = $this->_domPricing($currencyId);
		$platform  = strtolower($registrar['platform'] ?? 'resellerclub');
		$out = array();

		if ($platform === 'namecheap') {
			foreach (array('com', 'net', 'org', 'io', 'co') as $tld) {
				$full  = $sld . '.' . $tld;
				$check = namecheap_check_domain($registrar, $full);
				if (!empty($check['success']) && !empty($check['available'])) {
					$price = $this->_priceFor($priceList, '.' . $tld, $currencyId);
					if (!empty($price)) $out[] = $this->_suggestionRow($full, $price);
				}
			}
		} else {
			// ResellerClub / Resell.biz suggestion API
			if (!empty($registrar['suggestion_api'])) {
				$url = $registrar['suggestion_api']
					. 'auth-userid=' . $registrar['auth_userid']
					. '&api-key=' . $registrar['auth_apikey']
					. '&keyword=' . rawurlencode($sld)
					. '&tld-only=' . rawurlencode($extension);
				$r = domain_api_get($url);   // WHMAZ/1.0 UA + 403/429 retry
				$list = (!empty($r['success']) && is_array($r['data'])) ? $r['data'] : null;
				if (is_array($list)) {
					foreach ($list as $domainName => $info) {
						if (isset($info['status']) && $info['status'] === 'available') {
							$eparts = explode('.', $domainName);
							$price  = $this->_priceFor($priceList, '.' . end($eparts), $currencyId);
							if (!empty($price)) $out[] = $this->_suggestionRow($domainName, $price);
						}
					}
				}
			}
		}

		$this->ok(array('keyword' => $keyword, 'suggestions' => $out));
	}

	/**
	 * Transfer/renewal price for a domain extension.
	 *   GET /api/v1/domains/transfer_price?domain=example.com[&currency_id=1]
	 */
	public function transfer_price()
	{
		$this->requireScope('domains:read');
		$domain = strtolower(trim((string) $this->param('domain')));
		$domain = preg_replace('/^(https?:\/\/)?(www\.)?/i', '', $domain);
		$parts  = explode('.', $domain);
		if ($domain === '' || count($parts) < 2) {
			$this->fail(422, 'A valid domain (e.g. example.com) is required.', 'validation_error');
		}
		$currencyId = intval($this->param('currency_id')) ?: 1;
		$ext   = '.' . end($parts);
		$price = $this->_priceFor($this->_domPricing($currencyId), $ext, $currencyId);

		if (empty($price) || empty($price['transfer'])) {
			$this->fail(404, "Transfer is not available for {$ext}.", 'not_found');
		}
		$this->ok(array(
			'domain'         => $domain,
			'extension'      => $ext,
			'transfer_price' => (float) $price['transfer'],
			'renewal_price'  => !empty($price['renewal']) ? (float) $price['renewal'] : 0,
			'dom_pricing_id' => !empty($price['id']) ? intval($price['id']) : 0,
		));
	}

	/**
	 * Domain pricing for a specific currency (reg_period = 1). Unlike
	 * Cart_model::getDomPricing(), which filters by the *session* currency
	 * (getCurrencyId, default 1/USD), this honours the API's currency_id param
	 * so BDT (2) etc. resolve correctly on stateless requests.
	 */
	private function _domPricing($currencyId)
	{
		$rows = $this->db->query(
			"SELECT dp.id, dp.currency_id, dp.price, dp.transfer, dp.renewal, de.extension
			 FROM dom_pricing dp
			 JOIN dom_extensions de ON dp.dom_extension_id = de.id
			 WHERE dp.status = 1 AND dp.reg_period = 1 AND dp.currency_id = ? AND de.status = 1",
			array(intval($currencyId))
		)->result_array();

		// Two-tier pricing: quote pricingCompanyId() -- the reseller's cost by
		// default, or a named customer_id's price. resolveMany() keeps this to
		// one extra query for the whole TLD list.
		$this->load->model('Pricing_model');
		$resolved = $this->Pricing_model->resolveMany(1, $rows, $this->pricingCompanyId());
		foreach ($rows as &$row) {
			$r = isset($resolved[(int) $row['id']]) ? $resolved[(int) $row['id']] : null;
			if (empty($r)) continue;
			$row['price']    = $r['price'];
			$row['transfer'] = $r['transfer'];
			$row['renewal']  = $r['renewal'];
		}
		unset($row);

		return $rows;
	}

	private function _priceFor($priceList, $ext, $currencyId)
	{
		foreach ((array) $priceList as $row) {
			if ($row['extension'] === $ext && intval($row['currency_id']) === intval($currencyId)) {
				return $row;
			}
		}
		return array();
	}

	private function _suggestionRow($name, $price)
	{
		return array(
			'domain'         => $name,
			'price'          => !empty($price['price']) ? (float) $price['price'] : 0.0,
			'transfer'       => !empty($price['transfer']) ? (float) $price['transfer'] : 0.0,
			'renewal'        => !empty($price['renewal']) ? (float) $price['renewal'] : 0.0,
			'dom_pricing_id' => !empty($price['id']) ? intval($price['id']) : 0,
		);
	}

	public function index()
	{
		$this->requireScope('domains:read');
		list($limit, $offset, $page) = $this->pagination();
		$ids = $this->scopedCompanyIds();
		$in  = implode(',', array_fill(0, count($ids), '?'));

		$rows = $this->db->query(
			"SELECT od.id, od.company_id, od.domain, od.status, od.order_type,
			        od.reg_date, od.exp_date, od.next_renewal_date, od.recurring_amount,
			        dr.name AS registrar_name
			 FROM order_domains od
			 LEFT JOIN dom_registers dr ON dr.id = od.dom_register_id
			 WHERE od.company_id IN ($in)
			 ORDER BY od.id DESC LIMIT ?, ?",
			array_merge($ids, array($offset, $limit))
		)->result_array();

		$total = $this->db->query("SELECT COUNT(*) AS cnt FROM order_domains WHERE company_id IN ($in)", $ids)->row_array();

		$this->ok(array(
			'domains'    => array_map(array($this, 'shapeDomain'), $rows),
			'pagination' => array('page' => $page, 'per_page' => $limit, 'total' => intval($total['cnt'])),
		));
	}

	public function view($id = 0)
	{
		$this->requireScope('domains:read');
		$ids = $this->scopedCompanyIds();
		$in  = implode(',', array_fill(0, count($ids), '?'));

		$row = $this->db->query(
			"SELECT od.*, dr.name AS registrar_name FROM order_domains od
			 LEFT JOIN dom_registers dr ON dr.id = od.dom_register_id
			 WHERE od.id = ? AND od.company_id IN ($in) LIMIT 1",
			array_merge(array(intval($id)), $ids)
		)->row_array();

		if (empty($row)) {
			$this->fail(404, 'Domain not found.', 'not_found');
		}
		$this->ok(array('domain' => $this->shapeDomain($row)));
	}

	private function shapeDomain($row)
	{
		$statusMap = array(0 => 'pending_registration', 1 => 'active', 2 => 'expired', 3 => 'grace_period', 4 => 'cancelled', 5 => 'pending_transfer');
		return array(
			'id'                => intval($row['id']),
			'company_id'        => intval($row['company_id']),
			'domain'            => $row['domain'],
			'status'            => $statusMap[intval($row['status'])] ?? 'unknown',
			'status_code'       => intval($row['status']),
			'registrar'         => $row['registrar_name'] ?? null,
			'reg_date'          => $row['reg_date'] ?? null,
			'exp_date'          => $row['exp_date'] ?? null,
			'next_renewal_date' => $row['next_renewal_date'] ?? null,
			'recurring_amount'  => isset($row['recurring_amount']) ? (float) $row['recurring_amount'] : null,
		);
	}
}

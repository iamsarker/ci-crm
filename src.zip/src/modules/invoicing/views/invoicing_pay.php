<?php $this->load->view('templates/customer/header'); ?>

<div class="payment-page">
    <div class="payment-header">
        <h2><i class="fas fa-file-invoice-dollar"></i> Pay Invoice</h2>
        <div>Invoice #<?php echo htmlspecialchars($invoice['invoice_no']); ?></div>
        <div class="amount"><?php echo $invoice['currency_code']; ?> <?php echo number_format($amount_due, 2); ?></div>
        <?php if ($paid_amount > 0): ?>
        <div class="invoice-subtitle">
            Previously paid: <?php echo $invoice['currency_code']; ?> <?php echo number_format($paid_amount, 2); ?>
        </div>
        <?php endif; ?>
    </div>

    <div class="payment-body">
        <!-- Invoice Summary -->
        <div class="invoice-summary">
            <h5><i class="fas fa-receipt"></i> Invoice Summary</h5>
            <table>
                <?php foreach ($invoice_items as $item): ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['item']); ?></td>
                    <td><?php echo $invoice['currency_code']; ?> <?php echo number_format($item['total'], 2); ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if ($invoice['tax'] > 0): ?>
                <tr>
                    <td>Tax</td>
                    <td><?php echo $invoice['currency_code']; ?> <?php echo number_format($invoice['tax'], 2); ?></td>
                </tr>
                <?php endif; ?>
                <?php if (!empty($invoice['discount']) && $invoice['discount'] > 0): ?>
                <tr>
                    <td>Discount <?php echo !empty($invoice['coupon_code']) ? '(<code>' . htmlspecialchars($invoice['coupon_code']) . '</code>)' : ''; ?></td>
                    <td class="text-success">-<?php echo $invoice['currency_code']; ?> <?php echo number_format($invoice['discount'], 2); ?></td>
                </tr>
                <?php endif; ?>
                <tr>
                    <td>Total Due</td>
                    <td><?php echo $invoice['currency_code']; ?> <?php echo number_format($amount_due, 2); ?></td>
                </tr>
            </table>
        </div>

        <!-- Error Message -->
        <div class="payment-error" id="payment-error"></div>

        <!-- Processing Overlay -->
        <div class="payment-processing" id="payment-processing">
            <div class="spinner"></div>
            <h4>Processing Payment...</h4>
            <p>Please wait while we process your payment. Do not close this page.</p>
        </div>

        <!-- Payment Methods -->
        <div class="payment-methods" id="payment-methods">
            <h5><i class="fas fa-credit-card"></i> Select Payment Method</h5>

            <?php foreach ($gateways as $gateway): ?>
            <div class="payment-method-card" data-gateway="<?php echo $gateway['gateway_code']; ?>" data-gateway-id="<?php echo $gateway['id']; ?>">
                <div class="method-header">
                    <div class="method-radio"></div>
                    <div class="method-icon">
                        <?php
                        $iconMap = array(
                            'stripe' => 'fa-credit-card',
                            'paypal' => 'fa-paypal',
                            'razorpay' => 'fa-rupee-sign',
                            'sslcommerz' => 'fa-mobile-alt',
                            'bkash' => 'fa-mobile-alt',
                            'payhere' => 'fa-money-check-alt',
                            'paddle' => 'fa-credit-card',
                            'paystack' => 'fa-credit-card',
                            'bank_transfer' => 'fa-university',
                            'manual' => 'fa-hand-holding-usd',
                        );
                        $icon = isset($iconMap[$gateway['gateway_code']]) ? $iconMap[$gateway['gateway_code']] : 'fa-money-bill';
                        ?>
                        <i class="fas <?php echo $icon; ?>"></i>
                    </div>
                    <div class="method-info">
                        <h6><?php echo htmlspecialchars($gateway['display_name'] ?: $gateway['name']); ?></h6>
                        <p><?php echo htmlspecialchars($gateway['description'] ?? ''); ?></p>
                    </div>
                    <?php if ($gateway['fee_type'] !== 'none' && $gateway['fee_bearer'] === 'customer'): ?>
                    <div class="method-fee">
                        +<?php
                        if ($gateway['fee_type'] === 'fixed') {
                            echo $invoice['currency_code'] . ' ' . number_format($gateway['fee_fixed'], 2);
                        } elseif ($gateway['fee_type'] === 'percentage') {
                            echo $gateway['fee_percent'] . '%';
                        } else {
                            echo $invoice['currency_code'] . ' ' . number_format($gateway['fee_fixed'], 2) . ' + ' . $gateway['fee_percent'] . '%';
                        }
                        ?> fee
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>

            <!-- Proceed Button -->
            <div class="proceed-section" id="proceed-section">
                <button type="button" class="btn-pay" id="proceed-btn">
                    <i class="fas fa-arrow-right"></i> Proceed to Payment
                </button>
            </div>
        </div>

        <!-- Payment Details Section (appears after clicking Proceed) -->
        <div class="payment-details-section" id="payment-details-section">
            <!-- Stripe Payment Form -->
            <div class="payment-form" id="stripe-form" class="payment-form-section">
                <h5 class="payment-form-title"><i class="fas fa-credit-card"></i> Enter Card Details</h5>
                <label>Card Details</label>
                <div id="stripe-card-element"></div>
                <div id="stripe-card-errors" class="payment-error-text"></div>
                <button type="button" class="btn-pay" id="stripe-pay-btn">
                    <i class="fas fa-lock"></i> Pay <?php echo $invoice['currency_code']; ?> <?php echo number_format($amount_due, 2); ?>
                </button>
            </div>

            <!-- PayPal Button -->
            <div class="payment-form" id="paypal-form" class="payment-form-section">
                <h5 class="payment-form-title"><i class="fab fa-paypal"></i> Pay with PayPal</h5>
                <div id="paypal-button-container"></div>
            </div>

            <!-- SSLCommerz -->
            <div class="payment-form" id="sslcommerz-form" class="payment-form-section">
                <h5 class="payment-form-title"><i class="fas fa-mobile-alt"></i> Pay with SSLCommerz</h5>
                <p class="payment-form-description">
                    <i class="fas fa-info-circle"></i> You will be redirected to SSLCommerz secure payment page to complete your payment using bKash, Nagad, Cards, or Mobile Banking.
                </p>
                <button type="button" class="btn-pay" id="sslcommerz-pay-btn">
                    <i class="fas fa-lock"></i> Pay <?php echo $invoice['currency_code']; ?> <?php echo number_format($amount_due, 2); ?>
                </button>
            </div>

            <!-- bKash -->
            <div class="payment-form" id="bkash-form" class="payment-form-section">
                <h5 class="payment-form-title"><i class="fas fa-mobile-alt"></i> Pay with bKash</h5>
                <p class="payment-form-description">
                    <i class="fas fa-info-circle"></i> You will be redirected to the bKash secure payment page to complete your payment.
                </p>
                <button type="button" class="btn-pay" id="bkash-pay-btn">
                    <i class="fas fa-lock"></i> Pay <?php echo $invoice['currency_code']; ?> <?php echo number_format($amount_due, 2); ?>
                </button>
            </div>

            <!-- Paddle -->
            <div class="payment-form" id="paddle-form" class="payment-form-section">
                <h5 class="payment-form-title"><i class="fas fa-credit-card"></i> Pay with Paddle</h5>
                <p class="payment-form-description">
                    <i class="fas fa-info-circle"></i> A secure Paddle checkout will open on this page to complete your card payment.
                </p>
                <button type="button" class="btn-pay" id="paddle-pay-btn">
                    <i class="fas fa-lock"></i> Pay <?php echo $invoice['currency_code']; ?> <?php echo number_format($amount_due, 2); ?>
                </button>
            </div>

            <!-- PayHere -->
            <div class="payment-form" id="payhere-form" class="payment-form-section">
                <h5 class="payment-form-title"><i class="fas fa-money-check-alt"></i> Pay with PayHere</h5>
                <p class="payment-form-description">
                    <i class="fas fa-info-circle"></i> You will be redirected to the PayHere secure payment page to pay using Visa, Mastercard, or mobile wallets.
                </p>
                <button type="button" class="btn-pay" id="payhere-pay-btn">
                    <i class="fas fa-lock"></i> Pay <?php echo $invoice['currency_code']; ?> <?php echo number_format($amount_due, 2); ?>
                </button>
            </div>

            <!-- Razorpay -->
            <div class="payment-form" id="razorpay-form" class="payment-form-section">
                <h5 class="payment-form-title"><i class="fas fa-rupee-sign"></i> Pay with Razorpay</h5>
                <p class="payment-form-description">
                    <i class="fas fa-info-circle"></i> Pay securely using UPI, Cards, Net Banking, or Wallets.
                </p>
                <button type="button" class="btn-pay" id="razorpay-pay-btn">
                    <i class="fas fa-lock"></i> Pay <?php echo $invoice['currency_code']; ?> <?php echo number_format($amount_due, 2); ?>
                </button>
            </div>

            <!-- Paystack -->
            <div class="payment-form" id="paystack-form" class="payment-form-section">
                <h5 class="payment-form-title"><i class="fas fa-credit-card"></i> Pay with Paystack</h5>
                <p class="payment-form-description">
                    <i class="fas fa-info-circle"></i> Pay securely using Cards, Bank Transfer, or Mobile Money.
                </p>
                <button type="button" class="btn-pay" id="paystack-pay-btn">
                    <i class="fas fa-lock"></i> Pay <?php echo $invoice['currency_code']; ?> <?php echo number_format($amount_due, 2); ?>
                </button>
            </div>

            <!-- Bank Transfer -->
            <div class="payment-form" id="bank_transfer-form" class="payment-form-section">
                <h5 class="payment-form-title"><i class="fas fa-university"></i> Bank Transfer Details</h5>
                <div class="bank-transfer-details">
                    <table>
                        <?php
                        $bankGateway = null;
                        foreach ($gateways as $gw) {
                            if ($gw['gateway_code'] === 'bank_transfer') {
                                $bankGateway = $gw;
                                break;
                            }
                        }
                        if ($bankGateway):
                        ?>
                        <?php if (!empty($bankGateway['bank_name'])): ?>
                        <tr><td>Bank Name:</td><td><?php echo htmlspecialchars($bankGateway['bank_name']); ?></td></tr>
                        <?php endif; ?>
                        <?php if (!empty($bankGateway['account_name'])): ?>
                        <tr><td>Account Name:</td><td><?php echo htmlspecialchars($bankGateway['account_name']); ?></td></tr>
                        <?php endif; ?>
                        <?php if (!empty($bankGateway['account_number'])): ?>
                        <tr><td>Account Number:</td><td><?php echo htmlspecialchars($bankGateway['account_number']); ?></td></tr>
                        <?php endif; ?>
                        <?php if (!empty($bankGateway['routing_number'])): ?>
                        <tr><td>Routing Number:</td><td><?php echo htmlspecialchars($bankGateway['routing_number']); ?></td></tr>
                        <?php endif; ?>
                        <?php if (!empty($bankGateway['swift_code'])): ?>
                        <tr><td>SWIFT Code:</td><td><?php echo htmlspecialchars($bankGateway['swift_code']); ?></td></tr>
                        <?php endif; ?>
                        <?php if (!empty($bankGateway['iban'])): ?>
                        <tr><td>IBAN:</td><td><?php echo htmlspecialchars($bankGateway['iban']); ?></td></tr>
                        <?php endif; ?>
                        <?php endif; ?>
                        <tr><td>Reference:</td><td><strong><?php echo $invoice['invoice_no']; ?></strong></td></tr>
                    </table>
                    <p class="payment-instructions-text">
                        <i class="fas fa-exclamation-triangle"></i>
                        Please include the invoice number as payment reference. Your order will be processed once payment is confirmed.
                    </p>
                </div>
                <button type="button" class="btn-pay btn-offline-pay" data-gateway="bank_transfer">
                    <i class="fas fa-check"></i> Confirm & Mark as Pending
                </button>
            </div>

            <!-- Manual Payment -->
            <div class="payment-form" id="manual-form" class="payment-form-section">
                <h5 class="payment-form-title"><i class="fas fa-hand-holding-usd"></i> Manual Payment</h5>
                <div class="bank-transfer-details">
                    <?php
                    $manualGateway = null;
                    foreach ($gateways as $gw) {
                        if ($gw['gateway_code'] === 'manual') {
                            $manualGateway = $gw;
                            break;
                        }
                    }
                    ?>
                    <?php if ($manualGateway && !empty($manualGateway['instructions'])): ?>
                    <p><?php echo nl2br(htmlspecialchars($manualGateway['instructions'])); ?></p>
                    <?php else: ?>
                    <p>Please contact our support team for payment instructions. Include your invoice number: <strong><?php echo $invoice['invoice_no']; ?></strong></p>
                    <?php endif; ?>
                </div>
                <button type="button" class="btn-pay btn-offline-pay" data-gateway="manual">
                    <i class="fas fa-check"></i> Confirm & Mark as Pending
                </button>
            </div>

            <button type="button" class="btn btn-secondary mt-3" id="back-to-methods" class="btn-full-width">
                <i class="fas fa-arrow-left"></i> Back to Payment Methods
            </button>
        </div>

        <div class="footer-center">
            <a href="<?php echo base_url(); ?>invoicing/view_invoice/<?php echo $invoice['invoice_uuid']; ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Invoice
            </a>
        </div>
    </div>
</div>
<?php $this->load->view('templates/customer/footer_script'); ?>

<!-- Stripe JS -->
<?php if (!empty($stripe_publishable_key)): ?>
<script src="https://js.stripe.com/v3/"></script>
<?php endif; ?>

<!-- PayPal JS -->
<?php if (!empty($paypal_client_id)): ?>
<script src="https://www.paypal.com/sdk/js?client-id=<?php echo $paypal_client_id; ?>&currency=<?php echo $invoice['currency_code']; ?>"></script>
<?php endif; ?>

<!-- Paddle JS -->
<?php if (!empty($paddle_client_token)): ?>
<script src="https://cdn.paddle.com/paddle/v2/paddle.js"></script>
<?php endif; ?>

<script>
var invoiceUuid = '<?php echo $invoice['invoice_uuid']; ?>';
var amountDue = <?php echo $amount_due; ?>;
var currencyCode = '<?php echo $invoice['currency_code']; ?>';

var selectedGateway = null;

document.addEventListener('DOMContentLoaded', function() {
    // Payment method selection
    document.querySelectorAll('.payment-method-card').forEach(function(card) {
        card.addEventListener('click', function() {
            // Remove selected from all
            document.querySelectorAll('.payment-method-card').forEach(function(c) {
                c.classList.remove('selected');
            });

            // Select this one
            this.classList.add('selected');
            selectedGateway = this.getAttribute('data-gateway');

            // Show proceed button
            document.getElementById('proceed-section').classList.add('active');
        });
    });

    // Proceed button click
    document.getElementById('proceed-btn').addEventListener('click', function() {
        if (!selectedGateway) {
            showError('Please select a payment method');
            return;
        }

        // Hide payment methods, show payment details section
        document.getElementById('payment-methods').style.display = 'none';
        document.getElementById('payment-details-section').classList.add('active');

        // Hide all payment forms
        document.querySelectorAll('#payment-details-section .payment-form').forEach(function(form) {
            form.style.display = 'none';
        });

        // Show the selected payment form
        var formId = selectedGateway + '-form';
        var form = document.getElementById(formId);
        if (form) {
            form.style.display = 'block';
            form.style.width = '100%';
        }

        // Initialize gateway-specific components when visible
        if (selectedGateway === 'stripe' && typeof initStripeCard === 'function') {
            // Ensure stripe container has proper width before initializing
            var stripeContainer = document.getElementById('stripe-card-element');
            if (stripeContainer) {
                stripeContainer.style.width = '100%';
            }
            initStripeCard();
        }
        if (selectedGateway === 'paypal' && typeof initPayPalButtons === 'function') {
            initPayPalButtons();
        }
    });

    // Back to payment methods
    document.getElementById('back-to-methods').addEventListener('click', function() {
        document.getElementById('payment-methods').style.display = 'block';
        document.getElementById('payment-details-section').classList.remove('active');
    });
}); // End DOMContentLoaded

function showError(message) {
    var errorDiv = document.getElementById('payment-error');
    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
}

function hideError() {
    document.getElementById('payment-error').style.display = 'none';
}

function showProcessing() {
    document.getElementById('payment-methods').style.display = 'none';
    document.getElementById('payment-processing').style.display = 'block';
}

function hideProcessing() {
    document.getElementById('payment-methods').style.display = 'block';
    document.getElementById('payment-processing').style.display = 'none';
}

<?php if (!empty($stripe_publishable_key)): ?>
// Stripe Setup
var stripe = null;
var elements = null;
var cardElement = null;
var stripeMounted = false;
var stripeInitError = null;

try {
    stripe = Stripe('<?php echo htmlspecialchars($stripe_publishable_key, ENT_QUOTES); ?>');
    if (stripe) {
        elements = stripe.elements();
    }
} catch(e) {
    console.error('Failed to initialize Stripe:', e);
    stripeInitError = e.message;
}

function initStripeCard() {
    if (!elements) {
        showError('Stripe could not be initialized. Please check the payment gateway configuration.' + (stripeInitError ? ' Error: ' + stripeInitError : ''));
        return;
    }
    if (stripeMounted) return;

    // Small delay to ensure container has proper dimensions after display change
    setTimeout(function() {
        try {
            cardElement = elements.create('card', {
                style: {
                    base: {
                        fontSize: '16px',
                        color: '#333',
                        lineHeight: '24px',
                        '::placeholder': { color: '#aab7c4' }
                    }
                }
            });
            cardElement.mount('#stripe-card-element');
            stripeMounted = true;

            cardElement.on('change', function(event) {
                var displayError = document.getElementById('stripe-card-errors');
                if (event.error) {
                    displayError.textContent = event.error.message;
                } else {
                    displayError.textContent = '';
                }
            });
        } catch(e) {
            console.error('Failed to create Stripe card element:', e);
            showError('Failed to load card form: ' + e.message);
        }
    }, 100);
}

document.getElementById('stripe-pay-btn').addEventListener('click', function() {
    var btn = this;
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
    hideError();

    // First, create PaymentIntent
    fetch('<?php echo base_url(); ?>invoicing/pay/stripe_init', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'invoice_uuid=' + encodeURIComponent(invoiceUuid) + '&<?php echo $this->security->get_csrf_token_name(); ?>=<?php echo $this->security->get_csrf_hash(); ?>'
    })
    .then(function(response) { return response.json(); })
    .then(function(data) {
        if (!data.success) {
            throw new Error(data.error);
        }

        // Confirm payment with Stripe
        return stripe.confirmCardPayment(data.client_secret, {
            payment_method: {
                card: cardElement
            }
        }).then(function(result) {
            return { result: result, transactionUuid: data.transaction_uuid };
        });
    })
    .then(function(data) {
        if (data.result.error) {
            throw new Error(data.result.error.message);
        }

        // Payment succeeded
        showProcessing();
        window.location.href = '<?php echo base_url(); ?>invoicing/pay/stripe_success/' + data.transactionUuid;
    })
    .catch(function(error) {
        showError(error.message);
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-lock"></i> Pay <?php echo $invoice['currency_code']; ?> <?php echo number_format($amount_due, 2); ?>';
    });
});
<?php endif; ?>

// Offline Payment (Bank Transfer / Manual)
document.querySelectorAll('.btn-offline-pay').forEach(function(btn) {
    btn.addEventListener('click', function() {
        var gateway = this.getAttribute('data-gateway');
        var originalHtml = this.innerHTML;
        this.disabled = true;
        this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
        hideError();

        fetch('<?php echo base_url(); ?>invoicing/pay/offline_confirm', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'invoice_uuid=' + encodeURIComponent(invoiceUuid) + '&gateway=' + encodeURIComponent(gateway) + '&<?php echo $this->security->get_csrf_token_name(); ?>=<?php echo $this->security->get_csrf_hash(); ?>'
        })
        .then(function(response) { return response.json(); })
        .then(function(data) {
            if (!data.success) {
                throw new Error(data.error || 'Failed to process request');
            }
            window.location.href = '<?php echo base_url(); ?>invoicing/pay/pending/' + data.transaction_uuid;
        })
        .catch(function(error) {
            showError(error.message);
            btn.disabled = false;
            btn.innerHTML = originalHtml;
        });
    });
});

// SSLCommerz Payment
var sslcommerzBtn = document.getElementById('sslcommerz-pay-btn');
if (sslcommerzBtn) {
    sslcommerzBtn.addEventListener('click', function() {
        var btn = this;
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Redirecting...';
        hideError();

        fetch('<?php echo base_url(); ?>invoicing/pay/sslcommerz_init', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'invoice_uuid=' + encodeURIComponent(invoiceUuid) + '&<?php echo $this->security->get_csrf_token_name(); ?>=<?php echo $this->security->get_csrf_hash(); ?>'
        })
        .then(function(response) { return response.json(); })
        .then(function(data) {
            if (!data.success) {
                throw new Error(data.error || 'Failed to initialize payment');
            }
            // Redirect to SSLCommerz payment page
            window.location.href = data.gateway_url;
        })
        .catch(function(error) {
            showError(error.message);
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-lock"></i> Pay <?php echo $invoice['currency_code']; ?> <?php echo number_format($amount_due, 2); ?>';
        });
    });
}

// bKash Payment
var bkashBtn = document.getElementById('bkash-pay-btn');
if (bkashBtn) {
    bkashBtn.addEventListener('click', function() {
        var btn = this;
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Redirecting...';
        hideError();

        fetch('<?php echo base_url(); ?>invoicing/pay/bkash_init', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'invoice_uuid=' + encodeURIComponent(invoiceUuid) + '&<?php echo $this->security->get_csrf_token_name(); ?>=<?php echo $this->security->get_csrf_hash(); ?>'
        })
        .then(function(response) { return response.json(); })
        .then(function(data) {
            if (!data.success) {
                throw new Error(data.error || 'Failed to initialize payment');
            }
            // Redirect to bKash payment page
            window.location.href = data.gateway_url;
        })
        .catch(function(error) {
            showError(error.message);
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-lock"></i> Pay <?php echo $invoice['currency_code']; ?> <?php echo number_format($amount_due, 2); ?>';
        });
    });
}

// Paddle Payment (overlay checkout)
// Handler always attaches so a misconfigured/blocked Paddle surfaces an error
// instead of a silently dead button; paddle.js only loads when a token is set.
var paddleInitialized = false;
function initPaddle() {
    if (paddleInitialized || typeof Paddle === 'undefined') return;
    if ('<?php echo $paddle_environment; ?>' === 'sandbox') {
        Paddle.Environment.set('sandbox');
    }
    Paddle.Initialize({
        token: '<?php echo htmlspecialchars($paddle_client_token, ENT_QUOTES); ?>',
        eventCallback: function(ev) {
            if (ev && ev.name === 'checkout.completed') {
                showProcessing();
                // Confirmation is finalized by the webhook; land on the invoice
                window.location.href = '<?php echo base_url(); ?>invoicing/view_invoice/' + invoiceUuid + '?paid=1';
            }
        }
    });
    paddleInitialized = true;
}

// csrf_regenerate rotates the token on every POST; the overlay can be reopened
// in place, so keep a live hash refreshed from each response for the next attempt.
var paddleCsrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';
var paddleCsrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

var paddleBtn = document.getElementById('paddle-pay-btn');
if (paddleBtn) {
    paddleBtn.addEventListener('click', function() {
        var btn = this;
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Opening checkout...';
        hideError();

        fetch('<?php echo base_url(); ?>invoicing/pay/paddle_init', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'invoice_uuid=' + encodeURIComponent(invoiceUuid) + '&' + paddleCsrfName + '=' + encodeURIComponent(paddleCsrfHash)
        })
        .then(function(response) { return response.json(); })
        .then(function(data) {
            if (data.csrf_hash) { paddleCsrfHash = data.csrf_hash; }
            if (!data.success) {
                throw new Error(data.error || 'Failed to initialize payment');
            }
            initPaddle();
            if (typeof Paddle === 'undefined') {
                throw new Error('Paddle checkout could not load. Please try another payment method or contact support.');
            }
            Paddle.Checkout.open({ transactionId: data.paddle_transaction_id });
            // Restore the button so the customer can retry if they close the overlay
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-lock"></i> Pay <?php echo $invoice['currency_code']; ?> <?php echo number_format($amount_due, 2); ?>';
        })
        .catch(function(error) {
            showError(error.message);
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-lock"></i> Pay <?php echo $invoice['currency_code']; ?> <?php echo number_format($amount_due, 2); ?>';
        });
    });
}

// PayHere Payment (redirect via signed form POST)
var payhereBtn = document.getElementById('payhere-pay-btn');
if (payhereBtn) {
    payhereBtn.addEventListener('click', function() {
        var btn = this;
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Redirecting...';
        hideError();

        fetch('<?php echo base_url(); ?>invoicing/pay/payhere_init', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'invoice_uuid=' + encodeURIComponent(invoiceUuid) + '&<?php echo $this->security->get_csrf_token_name(); ?>=<?php echo $this->security->get_csrf_hash(); ?>'
        })
        .then(function(response) { return response.json(); })
        .then(function(data) {
            if (!data.success) {
                throw new Error(data.error || 'Failed to initialize payment');
            }
            // Build a hidden form and POST to PayHere's checkout page
            var form = document.createElement('form');
            form.method = 'POST';
            form.action = data.checkout_url;
            Object.keys(data.params).forEach(function(key) {
                var input = document.createElement('input');
                input.type = 'hidden';
                input.name = key;
                input.value = data.params[key];
                form.appendChild(input);
            });
            document.body.appendChild(form);
            form.submit();
        })
        .catch(function(error) {
            showError(error.message);
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-lock"></i> Pay <?php echo $invoice['currency_code']; ?> <?php echo number_format($amount_due, 2); ?>';
        });
    });
}

// Razorpay Payment
var razorpayBtn = document.getElementById('razorpay-pay-btn');
if (razorpayBtn) {
    razorpayBtn.addEventListener('click', function() {
        var btn = this;
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
        hideError();

        fetch('<?php echo base_url(); ?>invoicing/pay/razorpay_init', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'invoice_uuid=' + encodeURIComponent(invoiceUuid) + '&<?php echo $this->security->get_csrf_token_name(); ?>=<?php echo $this->security->get_csrf_hash(); ?>'
        })
        .then(function(response) { return response.json(); })
        .then(function(data) {
            if (!data.success) {
                throw new Error(data.error || 'Failed to initialize payment');
            }
            // Open Razorpay checkout
            var options = {
                key: data.key_id,
                amount: data.amount,
                currency: data.currency,
                name: 'Invoice Payment',
                description: 'Invoice #<?php echo $invoice['invoice_no']; ?>',
                order_id: data.order_id,
                handler: function(response) {
                    showProcessing();
                    window.location.href = '<?php echo base_url(); ?>invoicing/pay/razorpay_success?payment_id=' + response.razorpay_payment_id + '&order_id=' + response.razorpay_order_id + '&signature=' + response.razorpay_signature + '&transaction_uuid=' + data.transaction_uuid;
                },
                prefill: {
                    email: '<?php echo addslashes($invoice['email'] ?? ''); ?>',
                    contact: '<?php echo addslashes($invoice['phone'] ?? ''); ?>'
                },
                theme: {
                    color: '#0168fa'
                },
                modal: {
                    ondismiss: function() {
                        btn.disabled = false;
                        btn.innerHTML = '<i class="fas fa-lock"></i> Pay <?php echo $invoice['currency_code']; ?> <?php echo number_format($amount_due, 2); ?>';
                    }
                }
            };
            var rzp = new Razorpay(options);
            rzp.open();
        })
        .catch(function(error) {
            showError(error.message);
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-lock"></i> Pay <?php echo $invoice['currency_code']; ?> <?php echo number_format($amount_due, 2); ?>';
        });
    });
}

// Paystack Payment
var paystackBtn = document.getElementById('paystack-pay-btn');
if (paystackBtn) {
    paystackBtn.addEventListener('click', function() {
        var btn = this;
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
        hideError();

        fetch('<?php echo base_url(); ?>invoicing/pay/paystack_init', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'invoice_uuid=' + encodeURIComponent(invoiceUuid) + '&<?php echo $this->security->get_csrf_token_name(); ?>=<?php echo $this->security->get_csrf_hash(); ?>'
        })
        .then(function(response) { return response.json(); })
        .then(function(data) {
            if (!data.success) {
                throw new Error(data.error || 'Failed to initialize payment');
            }
            // Redirect to Paystack payment page
            window.location.href = data.authorization_url;
        })
        .catch(function(error) {
            showError(error.message);
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-lock"></i> Pay <?php echo $invoice['currency_code']; ?> <?php echo number_format($amount_due, 2); ?>';
        });
    });
}

<?php if (!empty($paypal_client_id)): ?>
// PayPal Setup
var transactionUuid = null;
var paypalRendered = false;

function initPayPalButtons() {
    if (paypalRendered) return;
    paypalRendered = true;

    paypal.Buttons({
        createOrder: function(data, actions) {
            return fetch('<?php echo base_url(); ?>invoicing/pay/paypal_init', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'invoice_uuid=' + encodeURIComponent(invoiceUuid) + '&<?php echo $this->security->get_csrf_token_name(); ?>=<?php echo $this->security->get_csrf_hash(); ?>'
            })
            .then(function(response) { return response.json(); })
            .then(function(data) {
                if (!data.success) {
                    throw new Error(data.error);
                }
                transactionUuid = data.transaction_uuid;
                return data.order_id;
            });
        },
        onApprove: function(data, actions) {
            showProcessing();

            return fetch('<?php echo base_url(); ?>invoicing/pay/paypal_capture', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'order_id=' + encodeURIComponent(data.orderID) + '&transaction_uuid=' + encodeURIComponent(transactionUuid) + '&<?php echo $this->security->get_csrf_token_name(); ?>=<?php echo $this->security->get_csrf_hash(); ?>'
            })
            .then(function(response) { return response.json(); })
            .then(function(captureData) {
                if (!captureData.success) {
                    throw new Error(captureData.error);
                }
                window.location.href = '<?php echo base_url(); ?>invoicing/pay/stripe_success/' + transactionUuid;
            })
            .catch(function(error) {
                hideProcessing();
                showError(error.message);
            });
        },
        onCancel: function(data) {
            if (transactionUuid) {
                window.location.href = '<?php echo base_url(); ?>invoicing/pay/paypal_cancel/' + transactionUuid;
            }
        },
        onError: function(err) {
            hideProcessing();
            showError('Payment failed. Please try again.');
            console.error(err);
        }
    }).render('#paypal-button-container');
}
<?php endif; ?>
</script>

<?php $this->load->view('templates/customer/footer'); ?>

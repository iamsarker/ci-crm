<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Cart extends WHMAZ_Controller
{

	function __construct()
	{
		parent::__construct();
		$this->load->model('Common_model');
		$this->load->model('Cart_model');
		$this->load->model('Order_model');
		$this->load->model('Appsetting_model');
		$this->load->model('PaymentGateway_model');
		$this->load->model('Promocode_model');
		$this->load->model('Orderlicense_model');
		$this->load->model('Plan_model');
	}

	/**
	 * Customer software catalog — browse plans like hosting, add to cart.
	 */
	public function software()
	{
		// License gate: this install may only offer software if licensed to sell it.
		require_feature('software_license_selling', '');
		$data['products']      = $this->Plan_model->getCatalogForCustomer(getCurrencyId());
		$data['currency_code'] = getCurrencyCode();
		$data['cart_count']    = getCartCount();
		$this->load->view('cart_software', $data);
	}

	public function view()
	{
		$type = NULL;
		$data['currency'] = $this->Cart_model->getCurrencies();
		$data['dom_prices'] = $this->Cart_model->getDomPricing();
		$data['services'] = $this->Cart_model->getServiceGroups();
		$data['currency'] = $this->Cart_model->getCurrencies();
		$data['cart_list'] = $this->Cart_model->getCartListWithChildren(); // Hierarchical cart data
		$data['payment_gateway_list'] = $this->PaymentGateway_model->getActiveGateways(getCurrencyCode());
		$data['type'] = $type;
		$this->load->view('view_card', $data);

	}

	function delete($id)
	{
		// Delete cart item and its linked children
		$this->Cart_model->deleteCartWithChildren($id);
		echo json_encode("OK");
	}

	function delete_all()
	{
		$userId = getCustomerId();
		$sessionId = getCustomerSessionId();

		$this->Cart_model->deleteAllCarts($userId, $sessionId);

		echo json_encode("OK");
	}

	function getCount()
	{
		$count = getCartCount();
		echo json_encode(array('count' => $count));
	}

	/**
	 * Get available hosting packages for Flow-2 (Domain → Hosting)
	 * Returns list of hosting packages with billing options
	 */
	public function getHostingPackages()
	{
		$packages = array();

		// Get all service groups that have hosting packages
		$groups = $this->Cart_model->getServiceGroups();

		foreach ($groups as $group) {
			$items = $this->Cart_model->getProductServiceItems($group['id']);
			foreach ($items as $item) {
				$billing = is_array($item['billing']) ? $item['billing'] : json_decode($item['billing'], true);
				if (!empty($billing)) {
					$packages[] = array(
						'id' => $item['id'],
						'product_name' => $item['product_name'],
						'product_desc' => strip_tags($item['product_desc']),
						'group_name' => $group['group_name'],
						'billing' => $billing
					);
				}
			}
		}

		echo json_encode(buildSuccessResponse($packages, "Hosting packages loaded"));
	}


	function checkout()
	{
		$userId = getCustomerId();
		if( $userId > 0 ){

			$type = NULL;
			$data['currency'] = $this->Cart_model->getCurrencies();
			$data['dom_prices'] = $this->Cart_model->getDomPricing();
			$data['services'] = $this->Cart_model->getServiceGroups();
			$data['currency'] = $this->Cart_model->getCurrencies();
			$data['cart_list'] = $this->Cart_model->getCartListData();
			$data['type'] = $type;
			$this->load->view('view_checkout', $data);

		} else{
			redirect( base_url()."auth/login?redirect-url=".base_url()."cart/checkout");
		}
	}


	function checkoutSubmit()
	{
		$userId = getCustomerId();
		$companyId = getCompanyId();
		$sessionId = getCustomerSessionId();

		if( $userId > 0 ){
			$this->processRestCall();
			$postData = $this->input->post();

			// Get hierarchical cart data (parents with children)
			$cartList = $this->Cart_model->getCartListWithChildren();

			if( !empty($cartList) ){

				$vatAmount = 0.0;
				$taxAmount = 0.0;
				$totalAmount = 0.0;

				// Calculate totals including children
				foreach ($cartList as $key => $row) {
					$vatAmount += $row['tax'];
					$taxAmount += $row['vat'];
					$totalAmount += $row['total'];

					// Add children totals
					if (!empty($row['children'])) {
						foreach ($row['children'] as $child) {
							$vatAmount += $child['tax'];
							$taxAmount += $child['vat'];
							$totalAmount += $child['total'];
						}
					}
				}

				$grandTotal = $totalAmount + $vatAmount + $taxAmount;

				// ─── Promo Code Handling ─────────────────────────
				$promoDiscount = 0.0;
				$promoCode = '';
				$promoId = 0;
				$appliedPromo = $this->session->userdata('applied_promo');

				if (!empty($appliedPromo) && !empty($appliedPromo['code'])) {
					// Re-validate to prevent stale session abuse
					$cartProductIds = array();
					foreach ($cartList as $r) {
						if ($r['item_type'] == 2 && !empty($r['product_service_id'])) {
							$cartProductIds[] = $r['product_service_id'];
						}
						if (!empty($r['children'])) {
							foreach ($r['children'] as $ch) {
								if ($ch['item_type'] == 2 && !empty($ch['product_service_id'])) {
									$cartProductIds[] = $ch['product_service_id'];
								}
							}
						}
					}

					$promoResult = $this->Promocode_model->validatePromoCode(
						$appliedPromo['code'], $companyId, $grandTotal, getCurrencyId(), $cartProductIds
					);

					if ($promoResult['valid']) {
						$promoDiscount = $promoResult['discount_amount'];
						$promoCode = $promoResult['promo']['code'];
						$promoId = $promoResult['promo']['id'];
					}
					// If invalid now, silently skip (no discount applied)
				}

				$grandTotal = $grandTotal - $promoDiscount;
				if ($grandTotal < 0) $grandTotal = 0;
				// ─── End Promo Code ──────────────────────────────

				$order['order_uuid'] = gen_uuid();
				$order['order_no'] = $this->Order_model->generateNumber('ORDER');
				$order['company_id'] = $companyId;
				$order['currency_id'] = getCurrencyId();
				$order['currency_code'] = getCurrencyCode();
				$order['order_date'] = getDateAddDay(0);
				$order['amount'] = $totalAmount;
				$order['vat_amount'] = $vatAmount;
				$order['tax_amount'] = $taxAmount;
				$order['coupon_code'] = $promoCode;
				$order['coupon_amount'] = $promoDiscount;
				$order['discount_amount'] = $promoDiscount;
				$order['total_amount'] = $grandTotal;
				$order['payment_gateway_id'] = $postData['payment_gateway'];
				$order['remarks'] = '';
				$order['instructions'] = $postData['instructions'];
				$order['inserted_on'] = getDateTime();
				$order['inserted_by'] = $userId;

				$orderId = $this->Order_model->saveOrder($order);

				$invoice['invoice_uuid'] = gen_uuid();
				$invoice['company_id'] = $companyId;
				$invoice['order_id'] = $orderId;
				$invoice['currency_id'] = $order['currency_id'];
				$invoice['currency_code'] = $order['currency_code'];
				$invoice['invoice_no'] = $this->Order_model->generateNumber('INVOICE');
				$invoice['sub_total'] = $totalAmount;
				$invoice['tax'] = $taxAmount;
				$invoice['vat'] = $vatAmount;
				$invoice['discount'] = $promoDiscount;
				$invoice['coupon_code'] = $promoCode;
				$invoice['total'] = $grandTotal;
				$invoice['order_date'] = getDateAddDay(0);
				$invoice['due_date'] = getDateAddDay(0);
				$invoice['status'] = 1;
				$invoice['pay_status'] = 'DUE';
				$invoice['inserted_on'] = getDateTime();
				$invoice['inserted_by'] = $userId;

				$invoiceId = $this->Order_model->saveInvoice($invoice);
				$invoice['id'] = $invoiceId;

				// Process each parent item and its children
				foreach ($cartList as $key => $row) {
					// Process parent item
					$parentRefId = $this->_processCartItem($row, $orderId, $invoiceId, $companyId, $userId);

					// Process children (linked items) if any
					if (!empty($row['children'])) {
						foreach ($row['children'] as $child) {
							$childRefId = $this->_processCartItem($child, $orderId, $invoiceId, $companyId, $userId);

							// Link parent and child together
							if ($parentRefId > 0 && $childRefId > 0) {
								$this->_linkOrderItems($row, $parentRefId, $child, $childRefId);
							}
						}
					}
				}

				// Record promo code usage
				if ($promoId > 0 && $promoDiscount > 0) {
					$this->Promocode_model->recordUsage($promoId, $companyId, $orderId, $promoDiscount);
				}

				// Clear promo session and cart
				$this->session->unset_userdata('applied_promo');
				$this->Cart_model->deleteAllCarts($userId, $sessionId);

				// Send order confirmation emails to customer and admin
				$this->Order_model->sendOrderConfirmationEmails($orderId, $invoiceId);

				// Return invoice data with UUID for redirect to payment page
				$responseData = array(
					'invoice_id' => $invoiceId,
					'invoice_uuid' => $invoice['invoice_uuid'],
					'invoice_no' => $invoice['invoice_no'],
					'total' => $grandTotal
				);
				echo json_encode(buildSuccessResponse($responseData, "Order has been placed successfully"));

			} else {
				echo json_encode(buildFailedResponse("Cart data is not available!"));
			}

		} else{
			// User not logged in - return 401 code
			echo json_encode(array(
				'code' => 401,
				'msg' => 'Please login first to proceed the checkout!',
				'data' => null
			));
		}
	}

	/**
	 * Process a single cart item (domain or hosting service)
	 * @return int The saved order item ID (order_domains.id or order_services.id)
	 */
	/**
	 * Per-line reseller cost for one cart row, at checkout-time prices.
	 *
	 * Mirrors how the sell price was computed: the same resolver, the same
	 * component (a transfer is costed at transfer, not registration), times the
	 * same quantity. Returns 0.00 whenever no reseller sits above the buyer.
	 */
	private function _resolveCostAmount($row, $companyId)
	{
		$this->load->model('Pricing_model');
		$qty = !empty($row['quantity']) ? intval($row['quantity']) : 1;

		if ($row['item_type'] == 1) {
			if (empty($row['dom_pricing_id'])) return 0.00;
			$r = $this->Pricing_model->resolve(1, $row['dom_pricing_id'], $companyId);
			if (empty($r)) return 0.00;
			// dns_update registers nothing at the registrar, so it costs nothing.
			$action = !empty($row['domain_action']) ? $row['domain_action'] : 'register';
			if ($action == 'dns_update') return 0.00;
			$unit = ($action == 'transfer') ? $r['cost_transfer'] : $r['cost_price'];
		} elseif ($row['item_type'] == 3) {
			if (empty($row['product_service_pricing_id'])) return 0.00;
			$r = $this->Pricing_model->resolve(3, $row['product_service_pricing_id'], $companyId);
			$unit = empty($r) ? 0.00 : $r['cost_price'];
		} else {
			if (empty($row['product_service_pricing_id'])) return 0.00;
			$r = $this->Pricing_model->resolve(2, $row['product_service_pricing_id'], $companyId);
			$unit = empty($r) ? 0.00 : $r['cost_price'];
		}

		return round((float) $unit * $qty, 2);
	}

	private function _processCartItem($row, $orderId, $invoiceId, $companyId, $userId)
	{
		$billingCycle = $this->Common_model->get_data_by_id("billing_cycle", $row['billing_cycle_id']);
		$cycleDays = !empty($billingCycle->cycle_days) ? $billingCycle->cycle_days : 365;

		$item = array();
		$item['order_id'] = $orderId;
		$item['company_id'] = $companyId;
		$item['first_pay_amount'] = $row['total'];
		$item['recurring_amount'] = $row['total'];

		// FREEZE THE COST BASIS alongside the sell price (v2.0.0 Phase 2).
		//
		// Phase 3 debits the reseller's wallet at cost when provisioning fires,
		// which can be days after checkout. Recomputing cost then would let a
		// price change in between silently rewrite what the reseller is billed
		// for an order they already quoted, so it is snapshotted here in the
		// same INSERT as the sell price. 0.00 for direct customers -- they have
		// no reseller above them and therefore no cost basis.
		$item['cost_amount'] = $this->_resolveCostAmount($row, $companyId);
		$item['is_synced'] = 1;
		$item['remarks'] = "";
		$item['reg_date'] = getDateAddDay(0);
		$item['exp_date'] = getDateAddDay($cycleDays);
		$item['due_date'] = getDateAddDay(7);
		$item['next_renewal_date'] = getDateAddDay($cycleDays);
		$item['suspension_date'] = null;
		$item['suspension_reason'] = null;
		$item['termination_date'] = null;
		$item['auto_renew'] = 1;
		$item['inserted_on'] = getDateTime();
		$item['inserted_by'] = $userId;

		$refId = 0;

		// Invoice item data
		$invoiceItem = array();
		$invoiceItem['invoice_id'] = $invoiceId;
		$invoiceItem['item'] = $row['note'];
		$invoiceItem['item_desc'] = $row['note'] . (!empty($row['hosting_domain']) ? ' - ' . $row['hosting_domain'] : '');
		$invoiceItem['tax'] = $row['tax'];
		$invoiceItem['vat'] = $row['vat'];
		$invoiceItem['sub_total'] = $row['sub_total'];
		$invoiceItem['total'] = $row['total'];
		$invoiceItem['item_type'] = $row['item_type'];
		$invoiceItem['inserted_on'] = getDateTime();
		$invoiceItem['inserted_by'] = $userId;

		if ($row['item_type'] == 1) {
			// Domain item
			$item['dom_pricing_id'] = $row['dom_pricing_id'];

			// Get registration period from dom_pricing (in years)
			$domPricing = $this->Cart_model->getCartDomainPrice($row['dom_pricing_id']);
			$regPeriod = !empty($domPricing['reg_period']) ? intval($domPricing['reg_period']) : 1;
			$item['reg_period'] = $regPeriod;

			// Calculate domain expiry based on registration period (years)
			$domainDays = $regPeriod * 365;
			$item['exp_date'] = getDateAddDay($domainDays);
			$item['next_renewal_date'] = getDateAddDay($domainDays);

			$item['domain'] = $row['hosting_domain'];
			$item['epp_code'] = !empty($row['epp_code']) ? $row['epp_code'] : null;

			// Get dom_register_id from dom_extensions via dom_pricing
			$domRegId = $this->Common_model->getDomRegisterIdByPricingId($row['dom_pricing_id']);
			$item['dom_register_id'] = $domRegId;

			// Set order_type based on domain_action
			// 1=register, 2=transfer, 3=dns_update (nothing to register)
			$domainAction = !empty($row['domain_action']) ? $row['domain_action'] : 'register';
			if ($domainAction == 'register') {
				$item['order_type'] = 1;
				$item['status'] = 0; // 0=pending registration
			} elseif ($domainAction == 'transfer') {
				$item['order_type'] = 2;
				$item['status'] = 5; // 5=pending transfer
			} else {
				// dns_update - no domain registration needed
				$item['order_type'] = 3;
				$item['status'] = 1; // 1=active (just DNS update)
				$item['is_synced'] = 1;
			}

			$refId = $this->Order_model->saveOrderDomain($item);

		} elseif ($row['item_type'] == 3) {
			// Software license item -> order_licenses (activated on payment).
			// The base $item fields all map cleanly onto order_licenses columns.
			$item['plan_id'] = !empty($row['product_service_id']) ? (int) $row['product_service_id'] : 0;
			$item['billing_cycle_id'] = $row['billing_cycle_id'];
			$item['currency_id'] = $row['currency_id'];
			$item['currency_code'] = $row['currency_code'];
			$item['status'] = 0; // 0=pending until paid
			$item['is_synced'] = 0; // activateLicense() sets 1 on payment

			$refId = $this->Orderlicense_model->saveLicense($item);

		} else {
			// Hosting/Service item
			$item['billing_cycle_id'] = $row['billing_cycle_id'];
			$item['status'] = 0; // 0=pending
			$item['hosting_domain'] = $row['hosting_domain'];
			$item['description'] = $row['note'];
			$item['product_service_id'] = !empty($row['product_service_id']) ? $row['product_service_id'] : 0;
			$item['product_service_pricing_id'] = $row['product_service_pricing_id'];
			$item['product_service_type_key'] = $this->Common_model->getProductServiceTypeKeyByPricingId($row['product_service_pricing_id']);
			$item['is_synced'] = 0; // Will be set to 1 after provisioning

			$refId = $this->Order_model->saveOrderService($item);
		}

		// Save invoice item
		$qty = !empty($row['quantity']) ? intval($row['quantity']) : 1;
		$invoiceItem['ref_id'] = ($refId > 0) ? $refId : null;
		$invoiceItem['billing_cycle_id'] = $row['billing_cycle_id'];
		$invoiceItem['quantity'] = $qty;
		$invoiceItem['unit_price'] = ($qty > 0) ? ($row['sub_total'] / $qty) : $row['sub_total'];
		$invoiceItem['discount'] = 0;
		$invoiceItem['billing_period_start'] = getDateAddDay(0);
		$invoiceItem['billing_period_end'] = ($cycleDays > 0) ? getDateAddDay($cycleDays) : null;

		$this->Order_model->saveInvoiceItem($invoiceItem);

		return $refId;
	}

	/**
	 * Link parent and child order items together
	 */
	private function _linkOrderItems($parent, $parentRefId, $child, $childRefId)
	{
		// Determine which is hosting and which is domain
		if ($parent['item_type'] == 1) {
			// Parent is domain, child is hosting
			$domainId = $parentRefId;
			$serviceId = $childRefId;
		} else {
			// Parent is hosting, child is domain
			$domainId = $childRefId;
			$serviceId = $parentRefId;
		}

		// Update order_services with linked_domain_id
		if ($serviceId > 0 && $domainId > 0) {
			$this->Order_model->updateOrderService($serviceId, array('linked_domain_id' => $domainId));
			$this->Order_model->updateOrderDomain($domainId, array('linked_service_id' => $serviceId));
		}
	}


	public function domain($type = 'register') // type = register, transfer
	{
		$domkeyword = $this->input->get('domkeyword');

		// Get app settings for reCAPTCHA keys
		$app_settings = $this->Appsetting_model->getSettings();
		$data['captcha_site_key'] = !empty($app_settings['captcha_site_key']) ? $app_settings['captcha_site_key'] : '';

		$data['services'] = $this->Cart_model->getServiceGroups();
		$data['dom_prices'] = $this->Cart_model->getDomPricing();
		$data['currency'] = $this->Cart_model->getCurrencies();
		$data['domkeyword'] = $domkeyword;
		$data['type'] = $type;

		// Load appropriate view based on type
		if ($type == 'transfer') {
			$this->load->view('cart_transferdomain', $data);
		} else {
			$this->load->view('cart_regnewdomain', $data);
		}
	}

	public function domain_search() // type = register, transfer
	{
		$type       = $this->input->get('type');
		$domkeyword = $this->input->get('domkeyword');
		$recaptcha_token = $this->input->get('recaptcha_token');

		$resp_data = array();
		$resp_data['status'] = 0;
		$resp_data['info'] = array();

		// Get app settings for reCAPTCHA keys
		$app_settings = $this->Appsetting_model->getSettings();
		$captcha_site_key = !empty($app_settings['captcha_site_key']) ? $app_settings['captcha_site_key'] : '';
		$captcha_secret_key = !empty($app_settings['captcha_secret_key']) ? $app_settings['captcha_secret_key'] : '';

		// Verify reCAPTCHA if keys are configured
		if (!empty($captcha_site_key) && !empty($captcha_secret_key)) {
			if (empty($recaptcha_token)) {
				$resp_data['error'] = 'Please complete the reCAPTCHA verification.';
				echo json_encode($resp_data);
				return;
			}

			$verify_url = RECAPTCHA_VERIFY_URL;
			$verify_data = array(
				'secret' => $captcha_secret_key,
				'response' => $recaptcha_token,
				'remoteip' => $this->input->ip_address()
			);

			$options = array(
				'http' => array(
					'header' => "Content-type: application/x-www-form-urlencoded\r\n",
					'method' => 'POST',
					'content' => http_build_query($verify_data)
				)
			);
			$context = stream_context_create($options);
			$verify_response = file_get_contents($verify_url, false, $context);
			$response_data = json_decode($verify_response, true);

			if (empty($response_data['success']) || $response_data['success'] !== true) {
				$resp_data['error'] = 'reCAPTCHA verification failed. Please try again.';
				echo json_encode($resp_data);
				return;
			}
		}

		try {
			if (!empty($domkeyword)) {
				$domArr = explode(".", $domkeyword);

				$keywrd = $domArr[0];
				$extension = "com";
				$len = count($domArr);
				if ($len > 1) {
					$extension = $domArr[$len - 1];
				}

				// BUGFIX: Use actual extension instead of hardcoded ".com"
				$regVendor = $this->Cart_model->getDomRegister("." . $extension);

				// Validate registrar configuration
				if (empty($regVendor)) {
					$resp_data['error'] = 'Domain registrar not configured';
					echo json_encode($resp_data);
					return;
				}

				$priceList = $this->Cart_model->getDomPricing();
				$tmp = array();
				$platform = strtolower($regVendor['platform'] ?? 'resellerclub');

				// Route to appropriate registrar API
				if ($platform === 'namecheap') {
					// Namecheap domain check
					$this->load->helper('domain_helper');
					$fullDomain = $keywrd . '.' . $extension;
					$checkResult = namecheap_check_domain($regVendor, $fullDomain);

					if (!$checkResult['success']) {
						$resp_data['error'] = 'Domain check failed: ' . $checkResult['error'];
						log_message('error', 'Namecheap domain search failed: ' . $checkResult['error']);
						echo json_encode($resp_data);
						return;
					}

					if ($checkResult['available']) {
						$domPriceObject = $this->getDomainPrice($priceList, "." . $extension);
						if (!empty($domPriceObject)) {
							$tmp[] = array(
								"name" => $fullDomain,
								"price" => !empty($domPriceObject["price"]) ? $domPriceObject["price"] : 0.0,
								"domPriceId" => !empty($domPriceObject["id"]) ? $domPriceObject["id"] : 0
							);
						}
					}
				} else {
					// ResellerClub / Resell.biz domain check
					if (empty($regVendor['domain_check_api'])) {
						$resp_data['error'] = 'Domain check API not configured';
						echo json_encode($resp_data);
						return;
					}

					$url = $regVendor['domain_check_api'] . 'auth-userid=' . $regVendor['auth_userid'] . '&api-key=' . $regVendor['auth_apikey'];
					$checkUrl = $url . '&domain-name=' . $keywrd . '&tlds=' . $extension;

					$resp = $this->curlGetRequest($checkUrl);

					// BUGFIX: Don't return early, continue to echo JSON
					if (is_null($resp) || empty($resp)) {
						$curlError = $this->getLastCurlError();
						$resp_data['error'] = 'No response from domain registrar API' . ($curlError ? ': ' . $curlError : '');
						// Log full details for debugging (mask API key)
						$maskedUrl = preg_replace('/api-key=[^&]+/', 'api-key=***MASKED***', $checkUrl);
						log_message('error', 'Domain search failed - ' . $curlError . ' | URL: ' . $maskedUrl . ' | UserID: ' . $regVendor['auth_userid']);
						echo json_encode($resp_data);
						return;
					}

					// Process API response
					// Response format: {"domain.com": {"classkey": "domcno", "status": "available"}}
					foreach ($resp as $domainName => $domainInfo) {
						// Check if domain is available
						if (isset($domainInfo['status']) && $domainInfo['status'] == "available") {
							// Extract extension from domain name (e.g., "example.com" -> "com")
							$extArr = explode(".", $domainName);
							$cnt = count($extArr);
							$ext = $extArr[$cnt - 1];

							// Get price for this extension from database
							$domPriceObject = $this->getDomainPrice($priceList, "." . $ext);

							// Only add if we have pricing for this extension
							if (!empty($domPriceObject)) {
								$tmp[] = array(
									"name" => $domainName,
									"price" => !empty($domPriceObject["price"]) ? $domPriceObject["price"] : 0.0,
									"domPriceId" => !empty($domPriceObject["id"]) ? $domPriceObject["id"] : 0
								);
							}
						}
					}
				}

				if (!empty($tmp)) {
					$resp_data['status'] = 1;
				}
				$resp_data['info'] = $tmp;
			}
		} catch (Exception $e) {
			// Log error
			log_message('error', 'Domain Search Error: ' . $e->getMessage());
			ErrorHandler::log_database_error('domain_search', 'API Call', $e->getMessage());
			$resp_data['error'] = 'Domain search failed: ' . $e->getMessage();
		}

		echo json_encode($resp_data);
	}


	public function get_domain_suggestions()
	{
		$domkeyword = $this->input->get('domkeyword');
		$resp_data = $this->domainLiveSuggestions($domkeyword);
		echo json_encode($resp_data);
	}

	private function domainLiveSuggestions($domkeyword = NULL){

		try {
			if (!empty($domkeyword)) {
				$domArr = explode(".", $domkeyword);

				$keywrd = $domArr[0];
				$extension = "com";
				$len = count($domArr);
				if ($len > 1) {
					$extension = $domArr[$len - 1];
				}

				$regVendor = $this->Cart_model->getDomRegister("." . $extension);

				// Validate registrar configuration
				if (empty($regVendor)) {
					return array();
				}

				$priceList = $this->Cart_model->getDomPricing();
				$tmp = array();
				$platform = strtolower($regVendor['platform'] ?? 'resellerclub');

				// Namecheap doesn't have a domain suggestions API
				if ($platform === 'namecheap') {
					// For Namecheap, check availability of common TLD variations
					$this->load->helper('domain_helper');
					$commonTlds = array('com', 'net', 'org', 'io', 'co');
					$idx = 0;

					foreach ($commonTlds as $tld) {
						$fullDomain = $keywrd . '.' . $tld;
						$checkResult = namecheap_check_domain($regVendor, $fullDomain);

						if ($checkResult['success'] && $checkResult['available']) {
							$domPriceObject = $this->getDomainPrice($priceList, "." . $tld);
							if (!empty($domPriceObject)) {
								$tmp[$idx]["name"] = $fullDomain;
								$tmp[$idx]["transfer"] = !empty($domPriceObject["transfer"]) ? $domPriceObject["transfer"] : 0.0;
								$tmp[$idx]["renewal"] = !empty($domPriceObject["renewal"]) ? $domPriceObject["renewal"] : 0.0;
								$tmp[$idx]["price"] = !empty($domPriceObject["price"]) ? $domPriceObject["price"] : 0.0;
								$tmp[$idx]["domPriceId"] = !empty($domPriceObject["id"]) ? $domPriceObject["id"] : 0;
								$idx++;
							}
						}
					}
					return $tmp;
				}

				// ResellerClub / Resell.biz suggestions
				if (empty($regVendor['suggestion_api'])) {
					return array();
				}

				$url = $regVendor['suggestion_api'] . 'auth-userid=' . $regVendor['auth_userid'] . '&api-key=' . $regVendor['auth_apikey'];
				$suggsurl = $url . '&keyword=' . $keywrd. '&tld-only='.$extension;

				$list = $this->curlGetRequest($suggsurl);

				// Log API response for debugging
				log_message('debug', 'Domain Suggestion API Response: ' . json_encode($list));

				// BUGFIX: Return empty array properly
				if( is_null($list) || empty($list) ){
					$curlError = $this->getLastCurlError();
					if ($curlError) {
						log_message('error', 'Domain suggestions failed - cURL error: ' . $curlError);
					}
					return array();
				}

				$idx=0;
				foreach( $list as $domainName => $domainInfo ){
					// Check if domain is available
					if( isset($domainInfo['status']) && $domainInfo['status'] == "available" ){

						$extArr = explode(".", $domainName);
						$cnt = count($extArr);
						$ext = $extArr[$cnt - 1];
						$domPriceObject = $this->getDomainPrice($priceList, ".".$ext);

						// Only add if we have pricing for this extension
						if( !empty($domPriceObject) ){
							$tmp[$idx]["name"] = $domainName;
							$tmp[$idx]["transfer"] = !empty($domPriceObject["transfer"]) ? $domPriceObject["transfer"] : 0.0;
							$tmp[$idx]["renewal"] = !empty($domPriceObject["renewal"]) ? $domPriceObject["renewal"] : 0.0;
							$tmp[$idx]["price"] = !empty($domPriceObject["price"]) ? $domPriceObject["price"] : 0.0;
							$tmp[$idx]["domPriceId"] = !empty($domPriceObject["id"]) ? $domPriceObject["id"] : 0;

							$idx++;
						}
					}
				}

				return $tmp;
			}
		} catch (Exception $e) {
			// Log error
			log_message('error', 'Domain Suggestion Error: ' . $e->getMessage());
			ErrorHandler::log_database_error('domainLiveSuggestions', 'API Call', $e->getMessage());
		}

		return array();
	}

	private function getDomainPrice($priceList, $domainExt){
		foreach ($priceList as $row){
			if( $row["extension"] == $domainExt && $row["currency_id"] == getCurrencyId() ){
				return $row;
			}
		}
		return array();
	}

	/**
	 * Get domain transfer price for a given domain
	 * GET params: domain - the full domain name (e.g., example.com)
	 */
	public function getDomainTransferPrice()
	{
		$domain = $this->input->get('domain');

		if (empty($domain)) {
			echo json_encode(buildFailedResponse("Domain name is required"));
			return;
		}

		// Clean up domain name
		$domain = strtolower(trim($domain));
		$domain = preg_replace('/^(https?:\/\/)?(www\.)?/i', '', $domain);

		// Extract extension
		$parts = explode('.', $domain);
		if (count($parts) < 2) {
			echo json_encode(buildFailedResponse("Invalid domain format"));
			return;
		}

		$extension = '.' . end($parts);

		// Get domain pricing
		$priceList = $this->Cart_model->getDomPricing();
		$domPrice = $this->getDomainPrice($priceList, $extension);

		if (empty($domPrice)) {
			echo json_encode(buildFailedResponse("This domain extension ({$extension}) is not available for transfer"));
			return;
		}

		$transferPrice = !empty($domPrice['transfer']) ? floatval($domPrice['transfer']) : 0;

		if ($transferPrice <= 0) {
			echo json_encode(buildFailedResponse("Transfer is not available for this extension"));
			return;
		}

		echo json_encode(buildSuccessResponse(array(
			'domain' => $domain,
			'extension' => $extension,
			'transfer_price' => $transferPrice,
			'renewal_price' => !empty($domPrice['renewal']) ? floatval($domPrice['renewal']) : 0,
			'dom_pricing_id' => !empty($domPrice['id']) ? intval($domPrice['id']) : 0,
			'currency' => getCurrencyCode()
		), "Transfer price found"));
	}

	public function services($type = 0, $title = NULL)
	{

		$data['currency'] = $this->Cart_model->getCurrencies();
		$data['services'] = $this->Cart_model->getServiceGroups();
		$data['items'] = $this->Cart_model->getProductServiceItems($type);
		$data['query_title'] = $title;
		$data['type'] = $type;
		$this->load->view('cart_services', $data);
	}

	public function addToCartAjax($type, $orderId)
	{
		$this->processRestCall();
		$postData = $this->input->post();

		// Get and validate domain name if provided
		$hostingDomain = !empty($postData['hosting_domain']) ? strtolower(trim($postData['hosting_domain'])) : '';

		// Validate domain format for domain items (type == 1)
		if ($type == 1 && !empty($hostingDomain)) {
			$domainValidation = $this->_validateDomainFormat($hostingDomain);
			if (!$domainValidation['valid']) {
				echo $this->AppResponse(0, $domainValidation['error']);
				return;
			}
		}

		$cartArr = array();
		$cartArr['customer_session_id'] = getCustomerSessionId();
		$cartArr['user_id'] = getCustomerId();
		$cartArr['item_type'] = $type;

		if ($type == 2) {
			// Hosting/Service
			$cartArr['product_service_pricing_id'] = $orderId;
			$itemPrice = $this->Cart_model->getCartServicePrice($orderId);
			$cartArr['product_service_id'] = !empty($itemPrice['product_service_id']) ? $itemPrice['product_service_id'] : 0;
			$cartArr['billing_cycle_id'] = !empty($itemPrice['billing_cycle_id']) ? $itemPrice['billing_cycle_id'] : 0;
			$cartArr['billing_cycle'] = !empty($itemPrice['cycle_name']) ? $itemPrice['cycle_name'] : '';
		} else {
			// Domain (type == 1)
			$cartArr['dom_pricing_id'] = $orderId;
			$itemPrice = $this->Cart_model->getCartDomainPrice($orderId);
			$cartArr['product_service_id'] = 0;
			// Domains use reg_period (years), not billing_cycle
			// Use billing_cycle_id = 1 (yearly) for domains
			$cartArr['billing_cycle_id'] = 1; // Yearly billing cycle
			$regPeriod = !empty($itemPrice['reg_period']) ? $itemPrice['reg_period'] : 1;
			$cartArr['billing_cycle'] = $regPeriod . ' Year' . ($regPeriod > 1 ? 's' : '');

			// A transfer is billed at the transfer price, not the registration
			// price. linkDomainToHosting() and addDomainToCart() have always
			// branched on this; this path did not, so every transfer added
			// through the generic addToCartAjax route was charged the register
			// price -- a live billing bug independent of reseller pricing, and
			// one that would have quietly become a two-tier money bug.
			$hdt = !empty($postData['hosting_domain_type']) ? intval($postData['hosting_domain_type']) : 0;
			if ($hdt == 2 && !empty($itemPrice['transfer'])) {
				$itemPrice['item_price'] = $itemPrice['transfer'];
			}
		}

		$quantity = !empty($postData['quantity']) ? intval($postData['quantity']) : 1;

		$cartArr['note'] = $postData['item'];
		$cartArr['hosting_domain_type'] = !empty($postData['hosting_domain_type']) ? $postData['hosting_domain_type'] : 0;
		$cartArr['hosting_domain'] = $hostingDomain;
		$cartArr['sub_total'] = !empty($itemPrice['item_price']) ? $itemPrice['item_price'] * $quantity : 0;
		$cartArr['currency_id'] = !empty($itemPrice['currency_id']) ? $itemPrice['currency_id'] : getCurrencyId();
		$cartArr['currency_code'] = getCurrencyCode();
		$cartArr['tax'] = 0;
		$cartArr['vat'] = 0;
		$cartArr['quantity'] = $quantity;
		$cartArr['inserted_on'] = getDateTime();
		$cartArr['inserted_by'] = getCustomerId();
		$cartArr['total'] = !empty($itemPrice['item_price']) ? $itemPrice['item_price'] * $quantity : 0;

		if ($this->Cart_model->saveCart($cartArr)) {
			echo $this->AppResponse(1, "Cart item has been added successfully");
		} else {
			echo $this->AppResponse(0, "Cart item cannot add!");
		}
	}

	/**
	 * Flow-1: Add Hosting to Cart (Domain Required)
	 * Creates hosting cart item, then requires domain selection
	 *
	 * POST params:
	 * - product_service_pricing_id: Hosting pricing ID
	 * - quantity: Number of items (default 1)
	 */
	public function addHostingToCart()
	{
		$this->processRestCall();
		$postData = $this->input->post();

		$pricingId = !empty($postData['product_service_pricing_id']) ? intval($postData['product_service_pricing_id']) : 0;
		$quantity = !empty($postData['quantity']) ? intval($postData['quantity']) : 1;

		if ($pricingId <= 0) {
			echo json_encode(buildFailedResponse("Invalid hosting package selected"));
			return;
		}

		// Get hosting pricing details
		$itemPrice = $this->Cart_model->getCartServicePrice($pricingId);
		if (empty($itemPrice)) {
			echo json_encode(buildFailedResponse("Hosting package not found"));
			return;
		}

		$pricingDetails = $this->Cart_model->getProductServicePricingById($pricingId);

		// Create hosting cart item
		$cartArr = array(
			'customer_session_id' => getCustomerSessionId(),
			'user_id' => getCustomerId(),
			'parent_cart_id' => null, // This is parent
			'item_type' => 2, // product_service
			'product_service_id' => !empty($itemPrice['product_service_id']) ? $itemPrice['product_service_id'] : 0,
			'product_service_pricing_id' => $pricingId,
			'note' => !empty($pricingDetails['product_name']) ? $pricingDetails['product_name'] : 'Hosting Package',
			'hosting_domain' => null, // Will be set when domain is added
			'hosting_domain_type' => 0,
			'domain_action' => null,
			'sub_total' => $itemPrice['item_price'] * $quantity,
			'billing_cycle_id' => $itemPrice['billing_cycle_id'],
			'billing_cycle' => $itemPrice['cycle_name'],
			'currency_id' => $itemPrice['currency_id'],
			'currency_code' => getCurrencyCode(),
			'tax' => 0,
			'vat' => 0,
			'quantity' => $quantity,
			'total' => $itemPrice['item_price'] * $quantity,
			'inserted_on' => getDateTime(),
			'inserted_by' => getCustomerId()
		);

		$cartId = $this->Cart_model->saveCart($cartArr);

		if ($cartId) {
			echo json_encode(buildSuccessResponse(
				array(
					'cart_id' => $cartId,
					'requires_domain' => true,
					'hosting_type' => !empty($pricingDetails['service_type_key']) ? $pricingDetails['service_type_key'] : 'shared'
				),
				"Hosting added to cart. Please select a domain."
			));
		} else {
			echo json_encode(buildFailedResponse("Failed to add hosting to cart"));
		}
	}

	/**
	 * Add a software plan/product to the cart (item_type=3, standalone item).
	 * POST: software_pricing_id
	 */
	public function addSoftwareToCart()
	{
		$this->processRestCall();

		// License gate (JSON endpoint): block if this install can't sell software.
		if ( ! feature_enabled('software_license_selling')) {
			echo json_encode(buildFailedResponse("Software purchasing is not available."));
			return;
		}

		$postData = $this->input->post();

		$pricingId = !empty($postData['software_pricing_id']) ? intval($postData['software_pricing_id']) : 0;
		if ($pricingId <= 0) {
			echo json_encode(buildFailedResponse("Invalid software plan selected"));
			return;
		}

		$itemPrice = $this->Cart_model->getCartSoftwarePrice($pricingId);
		if (empty($itemPrice)) {
			echo json_encode(buildFailedResponse("Software plan not found"));
			return;
		}

		$amount = (float) $itemPrice['item_price'];

		$cartArr = array(
			'customer_session_id'        => getCustomerSessionId(),
			'user_id'                    => getCustomerId(),
			'parent_cart_id'             => null, // standalone parent
			'item_type'                  => 3, // license/software
			'product_service_id'         => !empty($itemPrice['product_id']) ? $itemPrice['product_id'] : 0, // plan_id
			'product_service_pricing_id' => $pricingId, // software_pricing.id
			'note'                       => !empty($itemPrice['product_name']) ? $itemPrice['product_name'] : 'Software',
			'hosting_domain'             => null,
			'hosting_domain_type'        => 0,
			'domain_action'              => null,
			'sub_total'                  => $amount,
			'billing_cycle_id'           => $itemPrice['billing_cycle_id'],
			'billing_cycle'              => $itemPrice['cycle_name'],
			'currency_id'                => $itemPrice['currency_id'],
			'currency_code'              => getCurrencyCode(),
			'tax'                        => 0,
			'vat'                        => 0,
			'quantity'                   => 1,
			'total'                      => $amount,
			'inserted_on'                => getDateTime(),
			'inserted_by'                => getCustomerId(),
		);

		$cartId = $this->Cart_model->saveCart($cartArr);

		if ($cartId) {
			echo json_encode(buildSuccessResponse(array('cart_id' => $cartId), "Software added to cart."));
		} else {
			echo json_encode(buildFailedResponse("Failed to add software to cart"));
		}
	}

	/**
	 * Validate domain format has a valid TLD
	 *
	 * @param string $domainName Full domain name (e.g., "example.com")
	 * @return array Result with 'valid', 'error'
	 */
	private function _validateDomainFormat($domainName)
	{
		if (empty($domainName)) {
			return array('valid' => false, 'error' => 'Domain name is required');
		}

		// Check if domain contains at least one dot
		if (strpos($domainName, '.') === false) {
			return array('valid' => false, 'error' => 'Domain must include extension (e.g., example.com)');
		}

		// Parse domain
		$parts = explode('.', $domainName, 2);
		$name = $parts[0];
		$tld = isset($parts[1]) ? $parts[1] : '';

		if (empty($name)) {
			return array('valid' => false, 'error' => 'Invalid domain name format');
		}

		if (empty($tld)) {
			return array('valid' => false, 'error' => 'Domain extension (TLD) is required');
		}

		// Basic TLD validation - should be alphabetic and reasonable length
		$tldParts = explode('.', $tld);
		foreach ($tldParts as $part) {
			if (!preg_match('/^[a-zA-Z]{2,}$/', $part)) {
				return array('valid' => false, 'error' => 'Invalid domain extension: .' . $tld);
			}
		}

		return array('valid' => true, 'error' => null);
	}

	/**
	 * Flow-1 Part 2: Link Domain to Hosting Cart Item
	 *
	 * POST params:
	 * - parent_cart_id: The hosting cart ID
	 * - domain_action: 'register', 'transfer', 'dns_update'
	 * - domain_name: The domain name
	 * - epp_code: EPP/Auth code (required for transfer)
	 * - dom_pricing_id: Domain pricing ID (required for register/transfer)
	 */
	public function linkDomainToHosting()
	{
		$this->processRestCall();
		$postData = $this->input->post();

		$parentCartId = !empty($postData['parent_cart_id']) ? intval($postData['parent_cart_id']) : 0;
		$domainAction = !empty($postData['domain_action']) ? $postData['domain_action'] : '';
		$domainName = !empty($postData['domain_name']) ? strtolower(trim($postData['domain_name'])) : '';
		$eppCode = !empty($postData['epp_code']) ? trim($postData['epp_code']) : null;
		$domPricingId = !empty($postData['dom_pricing_id']) ? intval($postData['dom_pricing_id']) : 0;

		// Validate inputs
		if ($parentCartId <= 0) {
			echo json_encode(buildFailedResponse("Invalid hosting cart ID"));
			return;
		}

		// Validate domain format
		$domainValidation = $this->_validateDomainFormat($domainName);
		if (!$domainValidation['valid']) {
			echo json_encode(buildFailedResponse($domainValidation['error']));
			return;
		}

		if (!in_array($domainAction, array('register', 'transfer', 'dns_update'))) {
			echo json_encode(buildFailedResponse("Invalid domain action"));
			return;
		}

		// Check parent cart exists
		$parentCart = $this->Cart_model->getCartById($parentCartId);
		if (empty($parentCart) || $parentCart['item_type'] != 2) {
			echo json_encode(buildFailedResponse("Hosting cart item not found"));
			return;
		}

		// Validate transfer requires EPP code
		if ($domainAction == 'transfer' && empty($eppCode)) {
			echo json_encode(buildFailedResponse("EPP/Auth code is required for domain transfer"));
			return;
		}

		// For register/transfer, validate domain pricing
		$domainTotal = 0;
		$billingCycleId = 1; // Default yearly for domains
		$billingCycle = 'Yearly';

		if ($domainAction == 'register' || $domainAction == 'transfer') {
			if ($domPricingId <= 0) {
				echo json_encode(buildFailedResponse("Domain pricing is required"));
				return;
			}

			$domPrice = $this->Cart_model->getCartDomainPrice($domPricingId);
			if (empty($domPrice)) {
				echo json_encode(buildFailedResponse("Domain pricing not found"));
				return;
			}

			$domainTotal = $domainAction == 'transfer' ?
				(!empty($domPrice['transfer']) ? $domPrice['transfer'] : $domPrice['item_price']) :
				$domPrice['item_price'];

			$billingCycleId = !empty($domPrice['billing_cycle_id']) ? $domPrice['billing_cycle_id'] : 1;
		}

		// Map domain_action to hosting_domain_type for legacy compatibility
		$hostingDomainType = 0; // DNS
		if ($domainAction == 'register') $hostingDomainType = 1;
		if ($domainAction == 'transfer') $hostingDomainType = 2;

		// Create domain cart item linked to hosting
		$domainCart = array(
			'customer_session_id' => getCustomerSessionId(),
			'user_id' => getCustomerId(),
			'parent_cart_id' => $parentCartId,
			'item_type' => 1, // domain
			'product_service_id' => 0,
			'dom_pricing_id' => $domPricingId,
			'note' => ucfirst($domainAction) . ': ' . $domainName,
			'hosting_domain' => $domainName,
			'hosting_domain_type' => $hostingDomainType,
			'domain_action' => $domainAction,
			'epp_code' => $eppCode,
			'sub_total' => $domainTotal,
			'billing_cycle_id' => $billingCycleId,
			'billing_cycle' => $billingCycle,
			'currency_id' => getCurrencyId(),
			'currency_code' => getCurrencyCode(),
			'tax' => 0,
			'vat' => 0,
			'quantity' => 1,
			'total' => $domainTotal,
			'inserted_on' => getDateTime(),
			'inserted_by' => getCustomerId()
		);

		$domainCartId = $this->Cart_model->saveCart($domainCart);

		if ($domainCartId) {
			// Update parent hosting cart with domain name
			$this->Cart_model->updateCart($parentCartId, array(
				'hosting_domain' => $domainName,
				'hosting_domain_type' => $hostingDomainType,
				'domain_action' => $domainAction,
				'updated_on' => getDateTime()
			));

			echo json_encode(buildSuccessResponse(
				array('domain_cart_id' => $domainCartId),
				"Domain linked to hosting successfully"
			));
		} else {
			echo json_encode(buildFailedResponse("Failed to add domain to cart"));
		}
	}

	/**
	 * Flow-2: Add Domain to Cart (Hosting Optional)
	 *
	 * POST params:
	 * - domain_action: 'register', 'transfer'
	 * - domain_name: The domain name
	 * - dom_pricing_id: Domain pricing ID
	 * - epp_code: EPP/Auth code (required for transfer)
	 */
	public function addDomainToCart()
	{
		$this->processRestCall();
		$postData = $this->input->post();

		$domainAction = !empty($postData['domain_action']) ? $postData['domain_action'] : '';
		$domainName = !empty($postData['domain_name']) ? strtolower(trim($postData['domain_name'])) : '';
		$domPricingId = !empty($postData['dom_pricing_id']) ? intval($postData['dom_pricing_id']) : 0;
		$eppCode = !empty($postData['epp_code']) ? trim($postData['epp_code']) : null;

		// Validate domain format
		$domainValidation = $this->_validateDomainFormat($domainName);
		if (!$domainValidation['valid']) {
			echo json_encode(buildFailedResponse($domainValidation['error']));
			return;
		}

		if (!in_array($domainAction, array('register', 'transfer'))) {
			echo json_encode(buildFailedResponse("Invalid domain action. Use 'register' or 'transfer'"));
			return;
		}

		if ($domPricingId <= 0) {
			echo json_encode(buildFailedResponse("Domain pricing is required"));
			return;
		}

		// Validate transfer requires EPP code
		if ($domainAction == 'transfer' && empty($eppCode)) {
			echo json_encode(buildFailedResponse("EPP/Auth code is required for domain transfer"));
			return;
		}

		// Get domain pricing
		$domPrice = $this->Cart_model->getCartDomainPrice($domPricingId);
		if (empty($domPrice)) {
			echo json_encode(buildFailedResponse("Domain pricing not found"));
			return;
		}

		$domainTotal = $domainAction == 'transfer' ?
			(!empty($domPrice['transfer']) ? $domPrice['transfer'] : $domPrice['item_price']) :
			$domPrice['item_price'];

		// Map domain_action to hosting_domain_type
		$hostingDomainType = $domainAction == 'register' ? 1 : 2;

		// Create domain cart item (standalone, no parent)
		$domainCart = array(
			'customer_session_id' => getCustomerSessionId(),
			'user_id' => getCustomerId(),
			'parent_cart_id' => null, // Standalone domain
			'item_type' => 1, // domain
			'product_service_id' => 0,
			'dom_pricing_id' => $domPricingId,
			'note' => ucfirst($domainAction) . ': ' . $domainName,
			'hosting_domain' => $domainName,
			'hosting_domain_type' => $hostingDomainType,
			'domain_action' => $domainAction,
			'epp_code' => $eppCode,
			'sub_total' => $domainTotal,
			'billing_cycle_id' => !empty($domPrice['billing_cycle_id']) ? $domPrice['billing_cycle_id'] : 1,
			'billing_cycle' => 'Yearly',
			'currency_id' => getCurrencyId(),
			'currency_code' => getCurrencyCode(),
			'tax' => 0,
			'vat' => 0,
			'quantity' => 1,
			'total' => $domainTotal,
			'inserted_on' => getDateTime(),
			'inserted_by' => getCustomerId()
		);

		$domainCartId = $this->Cart_model->saveCart($domainCart);

		if ($domainCartId) {
			echo json_encode(buildSuccessResponse(
				array(
					'cart_id' => $domainCartId,
					'show_hosting_options' => true
				),
				"Domain added to cart. You can optionally add hosting."
			));
		} else {
			echo json_encode(buildFailedResponse("Failed to add domain to cart"));
		}
	}

	/**
	 * Flow-2 Part 2: Link Hosting to Domain Cart Item (Optional)
	 *
	 * POST params:
	 * - parent_cart_id: The domain cart ID
	 * - product_service_pricing_id: Hosting pricing ID
	 * - quantity: Number of items (default 1)
	 */
	public function linkHostingToDomain()
	{
		$this->processRestCall();
		$postData = $this->input->post();

		$parentCartId = !empty($postData['parent_cart_id']) ? intval($postData['parent_cart_id']) : 0;
		$pricingId = !empty($postData['product_service_pricing_id']) ? intval($postData['product_service_pricing_id']) : 0;
		$quantity = !empty($postData['quantity']) ? intval($postData['quantity']) : 1;

		// Validate inputs
		if ($parentCartId <= 0) {
			echo json_encode(buildFailedResponse("Invalid domain cart ID"));
			return;
		}

		if ($pricingId <= 0) {
			echo json_encode(buildFailedResponse("Invalid hosting package selected"));
			return;
		}

		// Check parent cart exists and is a domain
		$parentCart = $this->Cart_model->getCartById($parentCartId);
		if (empty($parentCart) || $parentCart['item_type'] != 1) {
			echo json_encode(buildFailedResponse("Domain cart item not found"));
			return;
		}

		// Get hosting pricing details
		$itemPrice = $this->Cart_model->getCartServicePrice($pricingId);
		if (empty($itemPrice)) {
			echo json_encode(buildFailedResponse("Hosting package not found"));
			return;
		}

		$pricingDetails = $this->Cart_model->getProductServicePricingById($pricingId);

		// Create hosting cart item linked to domain
		$hostingCart = array(
			'customer_session_id' => getCustomerSessionId(),
			'user_id' => getCustomerId(),
			'parent_cart_id' => $parentCartId,
			'item_type' => 2, // product_service
			'product_service_id' => !empty($itemPrice['product_service_id']) ? $itemPrice['product_service_id'] : 0,
			'product_service_pricing_id' => $pricingId,
			'note' => !empty($pricingDetails['product_name']) ? $pricingDetails['product_name'] : 'Hosting Package',
			'hosting_domain' => $parentCart['hosting_domain'], // Copy domain from parent
			'hosting_domain_type' => $parentCart['hosting_domain_type'],
			'domain_action' => $parentCart['domain_action'],
			'sub_total' => $itemPrice['item_price'] * $quantity,
			'billing_cycle_id' => $itemPrice['billing_cycle_id'],
			'billing_cycle' => $itemPrice['cycle_name'],
			'currency_id' => $itemPrice['currency_id'],
			'currency_code' => getCurrencyCode(),
			'tax' => 0,
			'vat' => 0,
			'quantity' => $quantity,
			'total' => $itemPrice['item_price'] * $quantity,
			'inserted_on' => getDateTime(),
			'inserted_by' => getCustomerId()
		);

		$hostingCartId = $this->Cart_model->saveCart($hostingCart);

		if ($hostingCartId) {
			echo json_encode(buildSuccessResponse(
				array('hosting_cart_id' => $hostingCartId),
				"Hosting linked to domain successfully"
			));
		} else {
			echo json_encode(buildFailedResponse("Failed to add hosting to cart"));
		}
	}

	/**
	 * Get cart list with hierarchical structure
	 * Returns items grouped by parent-child relationship
	 */
	public function getCartWithLinkedItems()
	{
		$cartList = $this->Cart_model->getCartListWithChildren();
		echo json_encode(buildSuccessResponse($cartList));
	}

	/**
	 * Apply promo code to cart (AJAX)
	 */
	public function applyPromoCode()
	{
		$this->processRestCall();
		$postData = $this->input->post();

		$code = !empty($postData['promo_code']) ? trim($postData['promo_code']) : '';
		$companyId = getCompanyId();
		$currencyId = getCurrencyId();

		// Calculate cart subtotal
		$cartList = $this->Cart_model->getCartListWithChildren();
		$cartSubTotal = 0;
		$cartProductIds = array();

		foreach ($cartList as $row) {
			$cartSubTotal += floatval($row['total']);
			if ($row['item_type'] == 2 && !empty($row['product_service_id'])) {
				$cartProductIds[] = $row['product_service_id'];
			}
			if (!empty($row['children'])) {
				foreach ($row['children'] as $child) {
					$cartSubTotal += floatval($child['total']);
					if ($child['item_type'] == 2 && !empty($child['product_service_id'])) {
						$cartProductIds[] = $child['product_service_id'];
					}
				}
			}
		}

		$result = $this->Promocode_model->validatePromoCode($code, $companyId, $cartSubTotal, $currencyId, $cartProductIds);

		if ($result['valid']) {
			// Store in session
			$this->session->set_userdata('applied_promo', array(
				'code' => $result['promo']['code'],
				'promo_id' => $result['promo']['id'],
				'discount_amount' => $result['discount_amount'],
				'discount_type' => $result['promo']['discount_type'],
				'discount_value' => $result['promo']['discount_value']
			));

			echo json_encode(array(
				'code' => 200,
				'msg' => $result['message'],
				'data' => array(
					'discount_amount' => $result['discount_amount'],
					'promo_code' => $result['promo']['code']
				)
			));
		} else {
			// Clear any previously applied promo
			$this->session->unset_userdata('applied_promo');

			echo json_encode(array(
				'code' => 400,
				'msg' => $result['message'],
				'data' => null
			));
		}
	}

	/**
	 * Remove promo code from cart (AJAX)
	 */
	public function removePromoCode()
	{
		$this->session->unset_userdata('applied_promo');
		echo json_encode(array(
			'code' => 200,
			'msg' => 'Promo code removed.',
			'data' => null
		));
	}

}

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-09-02 17:51:22 --> Config Class Initialized
INFO - 2026-09-02 17:51:22 --> Hooks Class Initialized
DEBUG - 2026-09-02 17:51:22 --> UTF-8 Support Enabled
INFO - 2026-09-02 17:51:22 --> Utf8 Class Initialized
INFO - 2026-09-02 17:51:22 --> URI Class Initialized
DEBUG - 2026-09-02 17:51:22 --> No URI present. Default controller set.
INFO - 2026-09-02 17:51:22 --> Router Class Initialized
INFO - 2026-09-02 17:51:22 --> Output Class Initialized
INFO - 2026-09-02 17:51:22 --> Security Class Initialized
DEBUG - 2026-09-02 17:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 17:51:22 --> CSRF cookie sent
INFO - 2026-09-02 17:51:22 --> Input Class Initialized
INFO - 2026-09-02 17:51:22 --> Language Class Initialized
INFO - 2026-09-02 17:51:22 --> Language Class Initialized
INFO - 2026-09-02 17:51:22 --> Config Class Initialized
INFO - 2026-09-02 17:51:22 --> Loader Class Initialized
INFO - 2026-09-02 17:51:22 --> Helper loaded: url_helper
INFO - 2026-09-02 17:51:22 --> Helper loaded: form_helper
INFO - 2026-09-02 17:51:22 --> Helper loaded: html_helper
INFO - 2026-09-02 17:51:22 --> Helper loaded: file_helper
INFO - 2026-09-02 17:51:22 --> Helper loaded: email_helper
INFO - 2026-09-02 17:51:22 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 17:51:22 --> Helper loaded: ssp_helper
INFO - 2026-09-02 17:51:22 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 17:51:22 --> Helper loaded: plesk_helper
INFO - 2026-09-02 17:51:22 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 17:51:22 --> Helper loaded: domain_helper
INFO - 2026-09-02 17:51:22 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 17:51:22 --> Helper loaded: tenant_helper
INFO - 2026-09-02 17:51:22 --> Database Driver Class Initialized
INFO - 2026-09-02 17:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 17:51:24 --> Upload Class Initialized
DEBUG - 2026-09-02 17:51:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 17:51:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 17:51:24 --> Encryption Class Initialized
INFO - 2026-09-02 17:51:24 --> Form Validation Class Initialized
INFO - 2026-09-02 17:51:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 17:51:24 --> Pagination Class Initialized
INFO - 2026-09-02 17:51:24 --> Email Class Initialized
INFO - 2026-09-02 17:51:24 --> Controller Class Initialized
DEBUG - 2026-09-02 17:51:24 --> Home MX_Controller Initialized
INFO - 2026-09-02 17:51:24 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 17:51:24 --> Model "Auth_model" initialized
INFO - 2026-09-02 17:51:24 --> Model "Cart_model" initialized
DEBUG - 2026-09-02 17:51:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-09-02 17:51:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-09-02 17:51:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-09-02 17:51:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/home/views/home_view.php
INFO - 2026-09-02 17:51:25 --> Final output sent to browser
DEBUG - 2026-09-02 17:51:25 --> Total execution time: 3.0144
INFO - 2026-09-02 17:51:25 --> Config Class Initialized
INFO - 2026-09-02 17:51:25 --> Hooks Class Initialized
DEBUG - 2026-09-02 17:51:25 --> UTF-8 Support Enabled
INFO - 2026-09-02 17:51:25 --> Utf8 Class Initialized
INFO - 2026-09-02 17:51:25 --> URI Class Initialized
INFO - 2026-09-02 17:51:25 --> Router Class Initialized
INFO - 2026-09-02 17:51:25 --> Output Class Initialized
INFO - 2026-09-02 17:51:25 --> Security Class Initialized
DEBUG - 2026-09-02 17:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 17:51:25 --> CSRF cookie sent
INFO - 2026-09-02 17:51:25 --> Input Class Initialized
INFO - 2026-09-02 17:51:25 --> Language Class Initialized
INFO - 2026-09-02 17:51:25 --> Language Class Initialized
INFO - 2026-09-02 17:51:25 --> Config Class Initialized
INFO - 2026-09-02 17:51:25 --> Loader Class Initialized
INFO - 2026-09-02 17:51:25 --> Helper loaded: url_helper
INFO - 2026-09-02 17:51:25 --> Helper loaded: form_helper
INFO - 2026-09-02 17:51:25 --> Helper loaded: html_helper
INFO - 2026-09-02 17:51:25 --> Helper loaded: file_helper
INFO - 2026-09-02 17:51:25 --> Helper loaded: email_helper
INFO - 2026-09-02 17:51:25 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 17:51:25 --> Helper loaded: ssp_helper
INFO - 2026-09-02 17:51:25 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 17:51:25 --> Helper loaded: plesk_helper
INFO - 2026-09-02 17:51:25 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 17:51:25 --> Helper loaded: domain_helper
INFO - 2026-09-02 17:51:25 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 17:51:25 --> Helper loaded: tenant_helper
INFO - 2026-09-02 17:51:25 --> Database Driver Class Initialized
INFO - 2026-09-02 17:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 17:51:27 --> Upload Class Initialized
DEBUG - 2026-09-02 17:51:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 17:51:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 17:51:27 --> Encryption Class Initialized
INFO - 2026-09-02 17:51:27 --> Form Validation Class Initialized
INFO - 2026-09-02 17:51:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 17:51:27 --> Pagination Class Initialized
INFO - 2026-09-02 17:51:27 --> Email Class Initialized
INFO - 2026-09-02 17:51:27 --> Controller Class Initialized
DEBUG - 2026-09-02 17:51:27 --> Authenticate MX_Controller Initialized
INFO - 2026-09-02 17:51:27 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 17:51:27 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 17:51:27 --> Model "Appsetting_model" initialized
DEBUG - 2026-09-02 17:51:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-09-02 17:51:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-09-02 17:51:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-09-02 17:51:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-09-02 17:51:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-09-02 17:51:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-09-02 17:51:27 --> Final output sent to browser
DEBUG - 2026-09-02 17:51:27 --> Total execution time: 2.0543
INFO - 2026-09-02 17:52:23 --> Config Class Initialized
INFO - 2026-09-02 17:52:23 --> Hooks Class Initialized
DEBUG - 2026-09-02 17:52:23 --> UTF-8 Support Enabled
INFO - 2026-09-02 17:52:23 --> Utf8 Class Initialized
INFO - 2026-09-02 17:52:23 --> URI Class Initialized
INFO - 2026-09-02 17:52:23 --> Router Class Initialized
INFO - 2026-09-02 17:52:23 --> Output Class Initialized
INFO - 2026-09-02 17:52:23 --> Security Class Initialized
DEBUG - 2026-09-02 17:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 17:52:23 --> CSRF cookie sent
INFO - 2026-09-02 17:52:23 --> Input Class Initialized
INFO - 2026-09-02 17:52:23 --> Language Class Initialized
INFO - 2026-09-02 17:52:23 --> Language Class Initialized
INFO - 2026-09-02 17:52:23 --> Config Class Initialized
INFO - 2026-09-02 17:52:23 --> Loader Class Initialized
INFO - 2026-09-02 17:52:23 --> Helper loaded: url_helper
INFO - 2026-09-02 17:52:23 --> Helper loaded: form_helper
INFO - 2026-09-02 17:52:23 --> Helper loaded: html_helper
INFO - 2026-09-02 17:52:23 --> Helper loaded: file_helper
INFO - 2026-09-02 17:52:23 --> Helper loaded: email_helper
INFO - 2026-09-02 17:52:23 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 17:52:23 --> Helper loaded: ssp_helper
INFO - 2026-09-02 17:52:23 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 17:52:23 --> Helper loaded: plesk_helper
INFO - 2026-09-02 17:52:23 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 17:52:23 --> Helper loaded: domain_helper
INFO - 2026-09-02 17:52:23 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 17:52:23 --> Helper loaded: tenant_helper
INFO - 2026-09-02 17:52:23 --> Database Driver Class Initialized
INFO - 2026-09-02 17:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 17:52:25 --> Upload Class Initialized
DEBUG - 2026-09-02 17:52:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 17:52:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 17:52:25 --> Encryption Class Initialized
INFO - 2026-09-02 17:52:25 --> Form Validation Class Initialized
INFO - 2026-09-02 17:52:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 17:52:25 --> Pagination Class Initialized
INFO - 2026-09-02 17:52:25 --> Email Class Initialized
INFO - 2026-09-02 17:52:25 --> Controller Class Initialized
DEBUG - 2026-09-02 17:52:25 --> Authenticate MX_Controller Initialized
INFO - 2026-09-02 17:52:25 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 17:52:25 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 17:52:25 --> Model "Appsetting_model" initialized
DEBUG - 2026-09-02 17:52:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-09-02 17:52:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-09-02 17:52:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-09-02 17:52:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-09-02 17:52:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-09-02 17:52:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-09-02 17:52:25 --> Final output sent to browser
DEBUG - 2026-09-02 17:52:25 --> Total execution time: 2.1120
INFO - 2026-09-02 17:56:59 --> Config Class Initialized
INFO - 2026-09-02 17:56:59 --> Hooks Class Initialized
DEBUG - 2026-09-02 17:56:59 --> UTF-8 Support Enabled
INFO - 2026-09-02 17:56:59 --> Utf8 Class Initialized
INFO - 2026-09-02 17:56:59 --> URI Class Initialized
DEBUG - 2026-09-02 17:56:59 --> No URI present. Default controller set.
INFO - 2026-09-02 17:56:59 --> Router Class Initialized
INFO - 2026-09-02 17:56:59 --> Output Class Initialized
INFO - 2026-09-02 17:56:59 --> Security Class Initialized
DEBUG - 2026-09-02 17:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 17:56:59 --> CSRF cookie sent
INFO - 2026-09-02 17:56:59 --> Input Class Initialized
INFO - 2026-09-02 17:56:59 --> Language Class Initialized
INFO - 2026-09-02 17:56:59 --> Language Class Initialized
INFO - 2026-09-02 17:56:59 --> Config Class Initialized
INFO - 2026-09-02 17:56:59 --> Loader Class Initialized
INFO - 2026-09-02 17:56:59 --> Helper loaded: url_helper
INFO - 2026-09-02 17:56:59 --> Helper loaded: form_helper
INFO - 2026-09-02 17:56:59 --> Helper loaded: html_helper
INFO - 2026-09-02 17:56:59 --> Helper loaded: file_helper
INFO - 2026-09-02 17:56:59 --> Helper loaded: email_helper
INFO - 2026-09-02 17:56:59 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 17:56:59 --> Helper loaded: ssp_helper
INFO - 2026-09-02 17:56:59 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 17:56:59 --> Helper loaded: plesk_helper
INFO - 2026-09-02 17:56:59 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 17:56:59 --> Helper loaded: domain_helper
INFO - 2026-09-02 17:56:59 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 17:56:59 --> Helper loaded: tenant_helper
INFO - 2026-09-02 17:56:59 --> Database Driver Class Initialized
INFO - 2026-09-02 17:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 17:57:04 --> Upload Class Initialized
DEBUG - 2026-09-02 17:57:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 17:57:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 17:57:04 --> Encryption Class Initialized
INFO - 2026-09-02 17:57:04 --> Form Validation Class Initialized
INFO - 2026-09-02 17:57:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 17:57:04 --> Pagination Class Initialized
INFO - 2026-09-02 17:57:04 --> Email Class Initialized
INFO - 2026-09-02 17:57:04 --> Controller Class Initialized
DEBUG - 2026-09-02 17:57:04 --> Home MX_Controller Initialized
INFO - 2026-09-02 17:57:04 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 17:57:04 --> Model "Auth_model" initialized
INFO - 2026-09-02 17:57:04 --> Model "Cart_model" initialized
DEBUG - 2026-09-02 17:57:06 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-09-02 17:57:06 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-09-02 17:57:06 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-09-02 17:57:06 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/home/views/home_view.php
INFO - 2026-09-02 17:57:06 --> Final output sent to browser
DEBUG - 2026-09-02 17:57:06 --> Total execution time: 7.7118
INFO - 2026-09-02 18:02:59 --> Config Class Initialized
INFO - 2026-09-02 18:02:59 --> Hooks Class Initialized
DEBUG - 2026-09-02 18:02:59 --> UTF-8 Support Enabled
INFO - 2026-09-02 18:02:59 --> Utf8 Class Initialized
INFO - 2026-09-02 18:02:59 --> URI Class Initialized
DEBUG - 2026-09-02 18:02:59 --> No URI present. Default controller set.
INFO - 2026-09-02 18:02:59 --> Router Class Initialized
INFO - 2026-09-02 18:02:59 --> Output Class Initialized
INFO - 2026-09-02 18:02:59 --> Security Class Initialized
DEBUG - 2026-09-02 18:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 18:02:59 --> CSRF cookie sent
INFO - 2026-09-02 18:02:59 --> Input Class Initialized
INFO - 2026-09-02 18:02:59 --> Language Class Initialized
INFO - 2026-09-02 18:02:59 --> Language Class Initialized
INFO - 2026-09-02 18:02:59 --> Config Class Initialized
INFO - 2026-09-02 18:02:59 --> Loader Class Initialized
INFO - 2026-09-02 18:02:59 --> Helper loaded: url_helper
INFO - 2026-09-02 18:02:59 --> Helper loaded: form_helper
INFO - 2026-09-02 18:02:59 --> Helper loaded: html_helper
INFO - 2026-09-02 18:02:59 --> Helper loaded: file_helper
INFO - 2026-09-02 18:02:59 --> Helper loaded: email_helper
INFO - 2026-09-02 18:02:59 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 18:02:59 --> Helper loaded: ssp_helper
INFO - 2026-09-02 18:02:59 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 18:02:59 --> Helper loaded: plesk_helper
INFO - 2026-09-02 18:02:59 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 18:02:59 --> Helper loaded: domain_helper
INFO - 2026-09-02 18:02:59 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 18:02:59 --> Helper loaded: tenant_helper
INFO - 2026-09-02 18:02:59 --> Database Driver Class Initialized
INFO - 2026-09-02 18:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 18:03:01 --> Upload Class Initialized
DEBUG - 2026-09-02 18:03:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 18:03:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 18:03:01 --> Encryption Class Initialized
INFO - 2026-09-02 18:03:01 --> Form Validation Class Initialized
INFO - 2026-09-02 18:03:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 18:03:01 --> Pagination Class Initialized
INFO - 2026-09-02 18:03:01 --> Email Class Initialized
INFO - 2026-09-02 18:03:01 --> Controller Class Initialized
DEBUG - 2026-09-02 18:03:01 --> Home MX_Controller Initialized
INFO - 2026-09-02 18:03:01 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 18:03:01 --> Model "Auth_model" initialized
INFO - 2026-09-02 18:03:01 --> Model "Cart_model" initialized
DEBUG - 2026-09-02 18:03:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-09-02 18:03:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-09-02 18:03:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-09-02 18:03:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/home/views/home_view.php
INFO - 2026-09-02 18:03:03 --> Final output sent to browser
DEBUG - 2026-09-02 18:03:03 --> Total execution time: 3.2702
INFO - 2026-09-02 19:04:39 --> Config Class Initialized
INFO - 2026-09-02 19:04:39 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:04:39 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:04:39 --> Utf8 Class Initialized
INFO - 2026-09-02 19:04:39 --> URI Class Initialized
DEBUG - 2026-09-02 19:04:39 --> No URI present. Default controller set.
INFO - 2026-09-02 19:04:39 --> Router Class Initialized
INFO - 2026-09-02 19:04:39 --> Output Class Initialized
INFO - 2026-09-02 19:04:39 --> Security Class Initialized
DEBUG - 2026-09-02 19:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:04:39 --> CSRF cookie sent
INFO - 2026-09-02 19:04:39 --> Input Class Initialized
INFO - 2026-09-02 19:04:39 --> Language Class Initialized
INFO - 2026-09-02 19:04:39 --> Language Class Initialized
INFO - 2026-09-02 19:04:39 --> Config Class Initialized
INFO - 2026-09-02 19:04:39 --> Loader Class Initialized
INFO - 2026-09-02 19:04:39 --> Helper loaded: url_helper
INFO - 2026-09-02 19:04:39 --> Helper loaded: form_helper
INFO - 2026-09-02 19:04:39 --> Helper loaded: html_helper
INFO - 2026-09-02 19:04:39 --> Helper loaded: file_helper
INFO - 2026-09-02 19:04:39 --> Helper loaded: email_helper
INFO - 2026-09-02 19:04:39 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:04:39 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:04:39 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:04:39 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:04:39 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:04:39 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:04:39 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:04:39 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:04:39 --> Database Driver Class Initialized
INFO - 2026-09-02 19:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:04:41 --> Upload Class Initialized
DEBUG - 2026-09-02 19:04:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:04:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:04:41 --> Encryption Class Initialized
INFO - 2026-09-02 19:04:41 --> Form Validation Class Initialized
INFO - 2026-09-02 19:04:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:04:41 --> Pagination Class Initialized
INFO - 2026-09-02 19:04:41 --> Email Class Initialized
INFO - 2026-09-02 19:04:41 --> Controller Class Initialized
DEBUG - 2026-09-02 19:04:41 --> Home MX_Controller Initialized
INFO - 2026-09-02 19:04:41 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:04:41 --> Model "Auth_model" initialized
INFO - 2026-09-02 19:04:41 --> Model "Cart_model" initialized
DEBUG - 2026-09-02 19:04:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-09-02 19:04:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-09-02 19:04:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-09-02 19:04:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/home/views/home_view.php
INFO - 2026-09-02 19:04:42 --> Final output sent to browser
DEBUG - 2026-09-02 19:04:42 --> Total execution time: 3.7592
INFO - 2026-09-02 19:04:42 --> Config Class Initialized
INFO - 2026-09-02 19:04:42 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:04:42 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:04:42 --> Utf8 Class Initialized
INFO - 2026-09-02 19:04:42 --> URI Class Initialized
INFO - 2026-09-02 19:04:42 --> Router Class Initialized
INFO - 2026-09-02 19:04:42 --> Output Class Initialized
INFO - 2026-09-02 19:04:42 --> Security Class Initialized
DEBUG - 2026-09-02 19:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:04:42 --> CSRF cookie sent
INFO - 2026-09-02 19:04:42 --> Input Class Initialized
INFO - 2026-09-02 19:04:42 --> Language Class Initialized
INFO - 2026-09-02 19:04:42 --> Language Class Initialized
INFO - 2026-09-02 19:04:42 --> Config Class Initialized
INFO - 2026-09-02 19:04:42 --> Loader Class Initialized
INFO - 2026-09-02 19:04:42 --> Helper loaded: url_helper
INFO - 2026-09-02 19:04:42 --> Helper loaded: form_helper
INFO - 2026-09-02 19:04:42 --> Helper loaded: html_helper
INFO - 2026-09-02 19:04:42 --> Helper loaded: file_helper
INFO - 2026-09-02 19:04:42 --> Helper loaded: email_helper
INFO - 2026-09-02 19:04:42 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:04:42 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:04:42 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:04:42 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:04:42 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:04:42 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:04:42 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:04:42 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:04:42 --> Database Driver Class Initialized
INFO - 2026-09-02 19:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:04:44 --> Upload Class Initialized
DEBUG - 2026-09-02 19:04:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:04:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:04:44 --> Encryption Class Initialized
INFO - 2026-09-02 19:04:44 --> Form Validation Class Initialized
INFO - 2026-09-02 19:04:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:04:44 --> Pagination Class Initialized
INFO - 2026-09-02 19:04:44 --> Email Class Initialized
INFO - 2026-09-02 19:04:44 --> Controller Class Initialized
DEBUG - 2026-09-02 19:04:44 --> Authenticate MX_Controller Initialized
INFO - 2026-09-02 19:04:44 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:04:44 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:04:44 --> Model "Appsetting_model" initialized
DEBUG - 2026-09-02 19:04:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-09-02 19:04:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-09-02 19:04:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-09-02 19:04:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-09-02 19:04:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-09-02 19:04:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-09-02 19:04:45 --> Final output sent to browser
DEBUG - 2026-09-02 19:04:45 --> Total execution time: 2.1465
INFO - 2026-09-02 19:06:34 --> Config Class Initialized
INFO - 2026-09-02 19:06:34 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:06:35 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:06:35 --> Utf8 Class Initialized
INFO - 2026-09-02 19:06:35 --> URI Class Initialized
DEBUG - 2026-09-02 19:06:35 --> No URI present. Default controller set.
INFO - 2026-09-02 19:06:35 --> Router Class Initialized
INFO - 2026-09-02 19:06:35 --> Output Class Initialized
INFO - 2026-09-02 19:06:35 --> Security Class Initialized
DEBUG - 2026-09-02 19:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:06:35 --> CSRF cookie sent
INFO - 2026-09-02 19:06:35 --> Input Class Initialized
INFO - 2026-09-02 19:06:35 --> Language Class Initialized
INFO - 2026-09-02 19:06:35 --> Language Class Initialized
INFO - 2026-09-02 19:06:35 --> Config Class Initialized
INFO - 2026-09-02 19:06:35 --> Loader Class Initialized
INFO - 2026-09-02 19:06:35 --> Helper loaded: url_helper
INFO - 2026-09-02 19:06:35 --> Helper loaded: form_helper
INFO - 2026-09-02 19:06:35 --> Helper loaded: html_helper
INFO - 2026-09-02 19:06:35 --> Helper loaded: file_helper
INFO - 2026-09-02 19:06:35 --> Helper loaded: email_helper
INFO - 2026-09-02 19:06:35 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:06:35 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:06:35 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:06:35 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:06:35 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:06:35 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:06:35 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:06:35 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:06:35 --> Database Driver Class Initialized
INFO - 2026-09-02 19:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:06:36 --> Upload Class Initialized
DEBUG - 2026-09-02 19:06:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:06:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:06:36 --> Encryption Class Initialized
INFO - 2026-09-02 19:06:36 --> Form Validation Class Initialized
INFO - 2026-09-02 19:06:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:06:36 --> Pagination Class Initialized
INFO - 2026-09-02 19:06:36 --> Email Class Initialized
INFO - 2026-09-02 19:06:36 --> Controller Class Initialized
DEBUG - 2026-09-02 19:06:36 --> Home MX_Controller Initialized
INFO - 2026-09-02 19:06:36 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:06:36 --> Model "Auth_model" initialized
INFO - 2026-09-02 19:06:36 --> Model "Cart_model" initialized
DEBUG - 2026-09-02 19:06:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-09-02 19:06:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-09-02 19:06:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-09-02 19:06:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/home/views/home_view.php
INFO - 2026-09-02 19:06:38 --> Final output sent to browser
DEBUG - 2026-09-02 19:06:38 --> Total execution time: 3.4168
INFO - 2026-09-02 19:06:38 --> Config Class Initialized
INFO - 2026-09-02 19:06:38 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:06:38 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:06:38 --> Utf8 Class Initialized
INFO - 2026-09-02 19:06:38 --> URI Class Initialized
INFO - 2026-09-02 19:06:38 --> Router Class Initialized
INFO - 2026-09-02 19:06:38 --> Output Class Initialized
INFO - 2026-09-02 19:06:38 --> Security Class Initialized
DEBUG - 2026-09-02 19:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:06:38 --> CSRF cookie sent
INFO - 2026-09-02 19:06:38 --> Input Class Initialized
INFO - 2026-09-02 19:06:38 --> Language Class Initialized
INFO - 2026-09-02 19:06:38 --> Language Class Initialized
INFO - 2026-09-02 19:06:38 --> Config Class Initialized
INFO - 2026-09-02 19:06:38 --> Loader Class Initialized
INFO - 2026-09-02 19:06:38 --> Helper loaded: url_helper
INFO - 2026-09-02 19:06:38 --> Helper loaded: form_helper
INFO - 2026-09-02 19:06:38 --> Helper loaded: html_helper
INFO - 2026-09-02 19:06:38 --> Helper loaded: file_helper
INFO - 2026-09-02 19:06:38 --> Helper loaded: email_helper
INFO - 2026-09-02 19:06:38 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:06:38 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:06:38 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:06:38 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:06:38 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:06:38 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:06:38 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:06:38 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:06:38 --> Database Driver Class Initialized
INFO - 2026-09-02 19:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:06:40 --> Upload Class Initialized
DEBUG - 2026-09-02 19:06:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:06:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:06:40 --> Encryption Class Initialized
INFO - 2026-09-02 19:06:40 --> Form Validation Class Initialized
INFO - 2026-09-02 19:06:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:06:40 --> Pagination Class Initialized
INFO - 2026-09-02 19:06:40 --> Email Class Initialized
INFO - 2026-09-02 19:06:40 --> Controller Class Initialized
DEBUG - 2026-09-02 19:06:40 --> Authenticate MX_Controller Initialized
INFO - 2026-09-02 19:06:40 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:06:40 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:06:40 --> Model "Appsetting_model" initialized
DEBUG - 2026-09-02 19:06:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-09-02 19:06:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-09-02 19:06:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-09-02 19:06:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-09-02 19:06:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-09-02 19:06:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-09-02 19:06:40 --> Final output sent to browser
DEBUG - 2026-09-02 19:06:40 --> Total execution time: 2.2555
INFO - 2026-09-02 19:06:40 --> Config Class Initialized
INFO - 2026-09-02 19:06:40 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:06:40 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:06:40 --> Utf8 Class Initialized
INFO - 2026-09-02 19:06:40 --> URI Class Initialized
INFO - 2026-09-02 19:06:40 --> Router Class Initialized
INFO - 2026-09-02 19:06:40 --> Output Class Initialized
INFO - 2026-09-02 19:06:40 --> Security Class Initialized
DEBUG - 2026-09-02 19:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:06:40 --> CSRF cookie sent
INFO - 2026-09-02 19:06:40 --> Input Class Initialized
INFO - 2026-09-02 19:06:40 --> Language Class Initialized
INFO - 2026-09-02 19:06:40 --> Language Class Initialized
INFO - 2026-09-02 19:06:40 --> Config Class Initialized
INFO - 2026-09-02 19:06:40 --> Loader Class Initialized
INFO - 2026-09-02 19:06:40 --> Helper loaded: url_helper
INFO - 2026-09-02 19:06:40 --> Helper loaded: form_helper
INFO - 2026-09-02 19:06:40 --> Helper loaded: html_helper
INFO - 2026-09-02 19:06:40 --> Helper loaded: file_helper
INFO - 2026-09-02 19:06:40 --> Helper loaded: email_helper
INFO - 2026-09-02 19:06:40 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:06:40 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:06:40 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:06:40 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:06:40 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:06:40 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:06:40 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:06:40 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:06:40 --> Database Driver Class Initialized
INFO - 2026-09-02 19:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:06:42 --> Upload Class Initialized
DEBUG - 2026-09-02 19:06:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:06:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:06:42 --> Encryption Class Initialized
INFO - 2026-09-02 19:06:42 --> Form Validation Class Initialized
INFO - 2026-09-02 19:06:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:06:42 --> Pagination Class Initialized
INFO - 2026-09-02 19:06:42 --> Email Class Initialized
INFO - 2026-09-02 19:06:42 --> Controller Class Initialized
DEBUG - 2026-09-02 19:06:42 --> Cart MX_Controller Initialized
INFO - 2026-09-02 19:06:42 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:06:42 --> Model "Auth_model" initialized
INFO - 2026-09-02 19:06:42 --> Model "Cart_model" initialized
INFO - 2026-09-02 19:06:42 --> Model "Common_model" initialized
INFO - 2026-09-02 19:06:42 --> Model "Order_model" initialized
INFO - 2026-09-02 19:06:42 --> Model "Appsetting_model" initialized
INFO - 2026-09-02 19:06:42 --> Model "PaymentGateway_model" initialized
INFO - 2026-09-02 19:06:42 --> Model "Promocode_model" initialized
DEBUG - 2026-09-02 19:06:42 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-09-02 19:06:42 --> Model "Plan_model" initialized
INFO - 2026-09-02 19:06:42 --> Model "Orderlicense_model" initialized
DEBUG - 2026-09-02 19:06:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-09-02 19:06:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-09-02 19:06:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-09-02 19:06:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-09-02 19:06:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-09-02 19:06:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/view_card.php
INFO - 2026-09-02 19:06:46 --> Final output sent to browser
DEBUG - 2026-09-02 19:06:46 --> Total execution time: 5.6534
INFO - 2026-09-02 19:13:25 --> Config Class Initialized
INFO - 2026-09-02 19:13:25 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:13:25 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:13:25 --> Utf8 Class Initialized
INFO - 2026-09-02 19:13:25 --> URI Class Initialized
INFO - 2026-09-02 19:13:25 --> Router Class Initialized
INFO - 2026-09-02 19:13:25 --> Output Class Initialized
INFO - 2026-09-02 19:13:25 --> Security Class Initialized
DEBUG - 2026-09-02 19:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:13:25 --> CSRF cookie sent
INFO - 2026-09-02 19:13:25 --> Input Class Initialized
INFO - 2026-09-02 19:13:25 --> Language Class Initialized
INFO - 2026-09-02 19:13:25 --> Language Class Initialized
INFO - 2026-09-02 19:13:25 --> Config Class Initialized
INFO - 2026-09-02 19:13:25 --> Loader Class Initialized
INFO - 2026-09-02 19:13:25 --> Helper loaded: url_helper
INFO - 2026-09-02 19:13:25 --> Helper loaded: form_helper
INFO - 2026-09-02 19:13:25 --> Helper loaded: html_helper
INFO - 2026-09-02 19:13:25 --> Helper loaded: file_helper
INFO - 2026-09-02 19:13:25 --> Helper loaded: email_helper
INFO - 2026-09-02 19:13:25 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:13:25 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:13:25 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:13:25 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:13:25 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:13:25 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:13:25 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:13:25 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:13:25 --> Database Driver Class Initialized
INFO - 2026-09-02 19:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:13:27 --> Upload Class Initialized
DEBUG - 2026-09-02 19:13:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:13:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:13:27 --> Encryption Class Initialized
INFO - 2026-09-02 19:13:27 --> Form Validation Class Initialized
INFO - 2026-09-02 19:13:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:13:27 --> Pagination Class Initialized
INFO - 2026-09-02 19:13:27 --> Email Class Initialized
INFO - 2026-09-02 19:13:27 --> Controller Class Initialized
DEBUG - 2026-09-02 19:13:27 --> Authenticate MX_Controller Initialized
INFO - 2026-09-02 19:13:27 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:13:27 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:13:27 --> Model "Appsetting_model" initialized
DEBUG - 2026-09-02 19:13:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-09-02 19:13:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-09-02 19:13:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-09-02 19:13:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-09-02 19:13:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-09-02 19:13:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-09-02 19:13:27 --> Final output sent to browser
DEBUG - 2026-09-02 19:13:27 --> Total execution time: 2.1299
INFO - 2026-09-02 19:13:27 --> Config Class Initialized
INFO - 2026-09-02 19:13:27 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:13:27 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:13:27 --> Utf8 Class Initialized
INFO - 2026-09-02 19:13:27 --> URI Class Initialized
INFO - 2026-09-02 19:13:27 --> Router Class Initialized
INFO - 2026-09-02 19:13:27 --> Output Class Initialized
INFO - 2026-09-02 19:13:27 --> Security Class Initialized
DEBUG - 2026-09-02 19:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:13:27 --> CSRF cookie sent
INFO - 2026-09-02 19:13:27 --> Config Class Initialized
INFO - 2026-09-02 19:13:27 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:13:27 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:13:27 --> Utf8 Class Initialized
INFO - 2026-09-02 19:13:27 --> URI Class Initialized
INFO - 2026-09-02 19:13:27 --> Router Class Initialized
INFO - 2026-09-02 19:13:27 --> Output Class Initialized
INFO - 2026-09-02 19:13:27 --> Security Class Initialized
DEBUG - 2026-09-02 19:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:13:27 --> CSRF cookie sent
INFO - 2026-09-02 19:13:27 --> Input Class Initialized
INFO - 2026-09-02 19:13:27 --> Language Class Initialized
INFO - 2026-09-02 19:13:27 --> Language Class Initialized
INFO - 2026-09-02 19:13:27 --> Config Class Initialized
INFO - 2026-09-02 19:13:27 --> Loader Class Initialized
INFO - 2026-09-02 19:13:27 --> Helper loaded: url_helper
INFO - 2026-09-02 19:13:27 --> Helper loaded: form_helper
INFO - 2026-09-02 19:13:27 --> Helper loaded: html_helper
INFO - 2026-09-02 19:13:27 --> Helper loaded: file_helper
INFO - 2026-09-02 19:13:27 --> Helper loaded: email_helper
INFO - 2026-09-02 19:13:27 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:13:27 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:13:27 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:13:27 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:13:27 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:13:27 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:13:27 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:13:27 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:13:27 --> Database Driver Class Initialized
INFO - 2026-09-02 19:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:13:29 --> Upload Class Initialized
DEBUG - 2026-09-02 19:13:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:13:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:13:29 --> Encryption Class Initialized
INFO - 2026-09-02 19:13:29 --> Form Validation Class Initialized
INFO - 2026-09-02 19:13:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:13:29 --> Pagination Class Initialized
INFO - 2026-09-02 19:13:29 --> Email Class Initialized
INFO - 2026-09-02 19:13:29 --> Controller Class Initialized
DEBUG - 2026-09-02 19:13:29 --> Dashboard MX_Controller Initialized
INFO - 2026-09-02 19:13:29 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:13:29 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:13:29 --> Config Class Initialized
INFO - 2026-09-02 19:13:29 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:13:29 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:13:29 --> Utf8 Class Initialized
INFO - 2026-09-02 19:13:29 --> URI Class Initialized
INFO - 2026-09-02 19:13:29 --> Router Class Initialized
INFO - 2026-09-02 19:13:29 --> Output Class Initialized
INFO - 2026-09-02 19:13:29 --> Security Class Initialized
DEBUG - 2026-09-02 19:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:13:29 --> CSRF cookie sent
INFO - 2026-09-02 19:13:29 --> Input Class Initialized
INFO - 2026-09-02 19:13:29 --> Language Class Initialized
INFO - 2026-09-02 19:13:29 --> Language Class Initialized
INFO - 2026-09-02 19:13:29 --> Config Class Initialized
INFO - 2026-09-02 19:13:29 --> Loader Class Initialized
INFO - 2026-09-02 19:13:29 --> Helper loaded: url_helper
INFO - 2026-09-02 19:13:29 --> Helper loaded: form_helper
INFO - 2026-09-02 19:13:29 --> Helper loaded: html_helper
INFO - 2026-09-02 19:13:29 --> Helper loaded: file_helper
INFO - 2026-09-02 19:13:29 --> Helper loaded: email_helper
INFO - 2026-09-02 19:13:29 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:13:29 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:13:29 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:13:29 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:13:29 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:13:29 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:13:29 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:13:29 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:13:29 --> Database Driver Class Initialized
INFO - 2026-09-02 19:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:13:31 --> Upload Class Initialized
DEBUG - 2026-09-02 19:13:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:13:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:13:31 --> Encryption Class Initialized
INFO - 2026-09-02 19:13:31 --> Form Validation Class Initialized
INFO - 2026-09-02 19:13:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:13:31 --> Pagination Class Initialized
INFO - 2026-09-02 19:13:31 --> Email Class Initialized
INFO - 2026-09-02 19:13:31 --> Controller Class Initialized
DEBUG - 2026-09-02 19:13:31 --> Dashboard MX_Controller Initialized
INFO - 2026-09-02 19:13:31 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:13:31 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:13:31 --> Config Class Initialized
INFO - 2026-09-02 19:13:31 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:13:31 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:13:31 --> Utf8 Class Initialized
INFO - 2026-09-02 19:13:31 --> URI Class Initialized
INFO - 2026-09-02 19:13:31 --> Router Class Initialized
INFO - 2026-09-02 19:13:31 --> Output Class Initialized
INFO - 2026-09-02 19:13:31 --> Security Class Initialized
DEBUG - 2026-09-02 19:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:13:31 --> CSRF cookie sent
INFO - 2026-09-02 19:13:31 --> Input Class Initialized
INFO - 2026-09-02 19:13:31 --> Language Class Initialized
INFO - 2026-09-02 19:13:31 --> Language Class Initialized
INFO - 2026-09-02 19:13:31 --> Config Class Initialized
INFO - 2026-09-02 19:13:31 --> Loader Class Initialized
INFO - 2026-09-02 19:13:31 --> Helper loaded: url_helper
INFO - 2026-09-02 19:13:31 --> Helper loaded: form_helper
INFO - 2026-09-02 19:13:31 --> Helper loaded: html_helper
INFO - 2026-09-02 19:13:31 --> Helper loaded: file_helper
INFO - 2026-09-02 19:13:31 --> Helper loaded: email_helper
INFO - 2026-09-02 19:13:31 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:13:31 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:13:31 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:13:31 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:13:31 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:13:31 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:13:31 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:13:31 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:13:31 --> Database Driver Class Initialized
INFO - 2026-09-02 19:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:13:33 --> Upload Class Initialized
DEBUG - 2026-09-02 19:13:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:13:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:13:33 --> Encryption Class Initialized
INFO - 2026-09-02 19:13:33 --> Form Validation Class Initialized
INFO - 2026-09-02 19:13:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:13:33 --> Pagination Class Initialized
INFO - 2026-09-02 19:13:33 --> Email Class Initialized
INFO - 2026-09-02 19:13:33 --> Controller Class Initialized
DEBUG - 2026-09-02 19:13:33 --> Authenticate MX_Controller Initialized
INFO - 2026-09-02 19:13:33 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:13:33 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:13:33 --> Model "Appsetting_model" initialized
DEBUG - 2026-09-02 19:13:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-09-02 19:13:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-09-02 19:13:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-09-02 19:13:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-09-02 19:13:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-09-02 19:13:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-09-02 19:13:33 --> Final output sent to browser
DEBUG - 2026-09-02 19:13:33 --> Total execution time: 2.0185
INFO - 2026-09-02 19:13:33 --> Config Class Initialized
INFO - 2026-09-02 19:13:33 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:13:33 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:13:33 --> Utf8 Class Initialized
INFO - 2026-09-02 19:13:33 --> URI Class Initialized
INFO - 2026-09-02 19:13:33 --> Router Class Initialized
INFO - 2026-09-02 19:13:33 --> Output Class Initialized
INFO - 2026-09-02 19:13:33 --> Security Class Initialized
DEBUG - 2026-09-02 19:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:13:33 --> CSRF cookie sent
INFO - 2026-09-02 19:13:33 --> Config Class Initialized
INFO - 2026-09-02 19:13:33 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:13:33 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:13:33 --> Utf8 Class Initialized
INFO - 2026-09-02 19:13:33 --> URI Class Initialized
INFO - 2026-09-02 19:13:33 --> Router Class Initialized
INFO - 2026-09-02 19:13:33 --> Output Class Initialized
INFO - 2026-09-02 19:13:33 --> Security Class Initialized
DEBUG - 2026-09-02 19:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:13:33 --> CSRF cookie sent
INFO - 2026-09-02 19:13:33 --> Input Class Initialized
INFO - 2026-09-02 19:13:33 --> Language Class Initialized
INFO - 2026-09-02 19:13:33 --> Language Class Initialized
INFO - 2026-09-02 19:13:33 --> Config Class Initialized
INFO - 2026-09-02 19:13:33 --> Loader Class Initialized
INFO - 2026-09-02 19:13:33 --> Helper loaded: url_helper
INFO - 2026-09-02 19:13:33 --> Helper loaded: form_helper
INFO - 2026-09-02 19:13:33 --> Helper loaded: html_helper
INFO - 2026-09-02 19:13:33 --> Helper loaded: file_helper
INFO - 2026-09-02 19:13:33 --> Helper loaded: email_helper
INFO - 2026-09-02 19:13:33 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:13:33 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:13:33 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:13:33 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:13:33 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:13:33 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:13:33 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:13:33 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:13:33 --> Database Driver Class Initialized
INFO - 2026-09-02 19:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:13:35 --> Upload Class Initialized
DEBUG - 2026-09-02 19:13:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:13:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:13:35 --> Encryption Class Initialized
INFO - 2026-09-02 19:13:35 --> Form Validation Class Initialized
INFO - 2026-09-02 19:13:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:13:35 --> Pagination Class Initialized
INFO - 2026-09-02 19:13:35 --> Email Class Initialized
INFO - 2026-09-02 19:13:35 --> Controller Class Initialized
DEBUG - 2026-09-02 19:13:35 --> Dashboard MX_Controller Initialized
INFO - 2026-09-02 19:13:35 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:13:35 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:13:35 --> Config Class Initialized
INFO - 2026-09-02 19:13:35 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:13:35 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:13:35 --> Utf8 Class Initialized
INFO - 2026-09-02 19:13:35 --> URI Class Initialized
INFO - 2026-09-02 19:13:35 --> Router Class Initialized
INFO - 2026-09-02 19:13:35 --> Output Class Initialized
INFO - 2026-09-02 19:13:35 --> Security Class Initialized
DEBUG - 2026-09-02 19:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:13:35 --> CSRF cookie sent
INFO - 2026-09-02 19:13:35 --> Input Class Initialized
INFO - 2026-09-02 19:13:35 --> Language Class Initialized
INFO - 2026-09-02 19:13:35 --> Language Class Initialized
INFO - 2026-09-02 19:13:35 --> Config Class Initialized
INFO - 2026-09-02 19:13:35 --> Loader Class Initialized
INFO - 2026-09-02 19:13:35 --> Helper loaded: url_helper
INFO - 2026-09-02 19:13:35 --> Helper loaded: form_helper
INFO - 2026-09-02 19:13:35 --> Helper loaded: html_helper
INFO - 2026-09-02 19:13:35 --> Helper loaded: file_helper
INFO - 2026-09-02 19:13:35 --> Helper loaded: email_helper
INFO - 2026-09-02 19:13:35 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:13:35 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:13:35 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:13:35 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:13:35 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:13:35 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:13:35 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:13:35 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:13:35 --> Database Driver Class Initialized
INFO - 2026-09-02 19:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:13:37 --> Upload Class Initialized
DEBUG - 2026-09-02 19:13:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:13:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:13:37 --> Encryption Class Initialized
INFO - 2026-09-02 19:13:37 --> Form Validation Class Initialized
INFO - 2026-09-02 19:13:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:13:37 --> Pagination Class Initialized
INFO - 2026-09-02 19:13:37 --> Email Class Initialized
INFO - 2026-09-02 19:13:37 --> Controller Class Initialized
DEBUG - 2026-09-02 19:13:37 --> Dashboard MX_Controller Initialized
INFO - 2026-09-02 19:13:37 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:13:37 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:13:37 --> Config Class Initialized
INFO - 2026-09-02 19:13:37 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:13:37 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:13:37 --> Utf8 Class Initialized
INFO - 2026-09-02 19:13:37 --> URI Class Initialized
INFO - 2026-09-02 19:13:37 --> Router Class Initialized
INFO - 2026-09-02 19:13:37 --> Output Class Initialized
INFO - 2026-09-02 19:13:37 --> Security Class Initialized
DEBUG - 2026-09-02 19:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:13:37 --> CSRF cookie sent
INFO - 2026-09-02 19:13:37 --> Input Class Initialized
INFO - 2026-09-02 19:13:37 --> Language Class Initialized
INFO - 2026-09-02 19:13:37 --> Language Class Initialized
INFO - 2026-09-02 19:13:37 --> Config Class Initialized
INFO - 2026-09-02 19:13:37 --> Loader Class Initialized
INFO - 2026-09-02 19:13:37 --> Helper loaded: url_helper
INFO - 2026-09-02 19:13:37 --> Helper loaded: form_helper
INFO - 2026-09-02 19:13:37 --> Helper loaded: html_helper
INFO - 2026-09-02 19:13:37 --> Helper loaded: file_helper
INFO - 2026-09-02 19:13:37 --> Helper loaded: email_helper
INFO - 2026-09-02 19:13:37 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:13:37 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:13:37 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:13:37 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:13:37 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:13:37 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:13:37 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:13:37 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:13:37 --> Database Driver Class Initialized
INFO - 2026-09-02 19:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:13:38 --> Upload Class Initialized
DEBUG - 2026-09-02 19:13:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:13:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:13:38 --> Encryption Class Initialized
INFO - 2026-09-02 19:13:38 --> Form Validation Class Initialized
INFO - 2026-09-02 19:13:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:13:38 --> Pagination Class Initialized
INFO - 2026-09-02 19:13:38 --> Email Class Initialized
INFO - 2026-09-02 19:13:38 --> Controller Class Initialized
DEBUG - 2026-09-02 19:13:38 --> Authenticate MX_Controller Initialized
INFO - 2026-09-02 19:13:38 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:13:38 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:13:38 --> Model "Appsetting_model" initialized
DEBUG - 2026-09-02 19:13:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-09-02 19:13:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-09-02 19:13:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-09-02 19:13:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-09-02 19:13:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-09-02 19:13:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-09-02 19:13:39 --> Final output sent to browser
DEBUG - 2026-09-02 19:13:39 --> Total execution time: 2.3183
INFO - 2026-09-02 19:13:39 --> Config Class Initialized
INFO - 2026-09-02 19:13:39 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:13:39 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:13:39 --> Utf8 Class Initialized
INFO - 2026-09-02 19:13:39 --> URI Class Initialized
INFO - 2026-09-02 19:13:39 --> Router Class Initialized
INFO - 2026-09-02 19:13:39 --> Output Class Initialized
INFO - 2026-09-02 19:13:39 --> Security Class Initialized
DEBUG - 2026-09-02 19:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:13:39 --> CSRF cookie sent
INFO - 2026-09-02 19:13:39 --> Config Class Initialized
INFO - 2026-09-02 19:13:39 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:13:39 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:13:39 --> Utf8 Class Initialized
INFO - 2026-09-02 19:13:39 --> URI Class Initialized
INFO - 2026-09-02 19:13:39 --> Router Class Initialized
INFO - 2026-09-02 19:13:39 --> Output Class Initialized
INFO - 2026-09-02 19:13:39 --> Security Class Initialized
DEBUG - 2026-09-02 19:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:13:39 --> CSRF cookie sent
INFO - 2026-09-02 19:13:39 --> Input Class Initialized
INFO - 2026-09-02 19:13:39 --> Language Class Initialized
INFO - 2026-09-02 19:13:39 --> Language Class Initialized
INFO - 2026-09-02 19:13:39 --> Config Class Initialized
INFO - 2026-09-02 19:13:39 --> Loader Class Initialized
INFO - 2026-09-02 19:13:39 --> Helper loaded: url_helper
INFO - 2026-09-02 19:13:39 --> Helper loaded: form_helper
INFO - 2026-09-02 19:13:39 --> Helper loaded: html_helper
INFO - 2026-09-02 19:13:39 --> Helper loaded: file_helper
INFO - 2026-09-02 19:13:39 --> Helper loaded: email_helper
INFO - 2026-09-02 19:13:39 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:13:39 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:13:39 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:13:39 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:13:39 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:13:39 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:13:39 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:13:39 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:13:39 --> Database Driver Class Initialized
INFO - 2026-09-02 19:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:13:41 --> Upload Class Initialized
DEBUG - 2026-09-02 19:13:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:13:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:13:41 --> Encryption Class Initialized
INFO - 2026-09-02 19:13:41 --> Form Validation Class Initialized
INFO - 2026-09-02 19:13:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:13:41 --> Pagination Class Initialized
INFO - 2026-09-02 19:13:41 --> Email Class Initialized
INFO - 2026-09-02 19:13:41 --> Controller Class Initialized
DEBUG - 2026-09-02 19:13:41 --> Dashboard MX_Controller Initialized
INFO - 2026-09-02 19:13:41 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:13:41 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:13:41 --> Config Class Initialized
INFO - 2026-09-02 19:13:41 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:13:41 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:13:41 --> Utf8 Class Initialized
INFO - 2026-09-02 19:13:41 --> URI Class Initialized
INFO - 2026-09-02 19:13:41 --> Router Class Initialized
INFO - 2026-09-02 19:13:41 --> Output Class Initialized
INFO - 2026-09-02 19:13:41 --> Security Class Initialized
DEBUG - 2026-09-02 19:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:13:41 --> CSRF cookie sent
INFO - 2026-09-02 19:13:41 --> Input Class Initialized
INFO - 2026-09-02 19:13:41 --> Language Class Initialized
INFO - 2026-09-02 19:13:41 --> Language Class Initialized
INFO - 2026-09-02 19:13:41 --> Config Class Initialized
INFO - 2026-09-02 19:13:41 --> Loader Class Initialized
INFO - 2026-09-02 19:13:41 --> Helper loaded: url_helper
INFO - 2026-09-02 19:13:41 --> Helper loaded: form_helper
INFO - 2026-09-02 19:13:41 --> Helper loaded: html_helper
INFO - 2026-09-02 19:13:41 --> Helper loaded: file_helper
INFO - 2026-09-02 19:13:41 --> Helper loaded: email_helper
INFO - 2026-09-02 19:13:41 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:13:41 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:13:41 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:13:41 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:13:41 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:13:41 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:13:41 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:13:41 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:13:41 --> Database Driver Class Initialized
INFO - 2026-09-02 19:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:13:42 --> Upload Class Initialized
DEBUG - 2026-09-02 19:13:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:13:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:13:42 --> Encryption Class Initialized
INFO - 2026-09-02 19:13:42 --> Form Validation Class Initialized
INFO - 2026-09-02 19:13:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:13:42 --> Pagination Class Initialized
INFO - 2026-09-02 19:13:42 --> Email Class Initialized
INFO - 2026-09-02 19:13:42 --> Controller Class Initialized
DEBUG - 2026-09-02 19:13:42 --> Dashboard MX_Controller Initialized
INFO - 2026-09-02 19:13:42 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:13:42 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:13:53 --> Config Class Initialized
INFO - 2026-09-02 19:13:53 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:13:53 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:13:53 --> Utf8 Class Initialized
INFO - 2026-09-02 19:13:53 --> URI Class Initialized
INFO - 2026-09-02 19:13:53 --> Router Class Initialized
INFO - 2026-09-02 19:13:53 --> Output Class Initialized
INFO - 2026-09-02 19:13:53 --> Security Class Initialized
DEBUG - 2026-09-02 19:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:13:53 --> CSRF cookie sent
INFO - 2026-09-02 19:13:53 --> Input Class Initialized
INFO - 2026-09-02 19:13:53 --> Language Class Initialized
INFO - 2026-09-02 19:13:53 --> Language Class Initialized
INFO - 2026-09-02 19:13:53 --> Config Class Initialized
INFO - 2026-09-02 19:13:53 --> Loader Class Initialized
INFO - 2026-09-02 19:13:53 --> Helper loaded: url_helper
INFO - 2026-09-02 19:13:53 --> Helper loaded: form_helper
INFO - 2026-09-02 19:13:53 --> Helper loaded: html_helper
INFO - 2026-09-02 19:13:53 --> Helper loaded: file_helper
INFO - 2026-09-02 19:13:53 --> Helper loaded: email_helper
INFO - 2026-09-02 19:13:53 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:13:53 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:13:53 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:13:53 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:13:53 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:13:53 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:13:53 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:13:53 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:13:53 --> Database Driver Class Initialized
INFO - 2026-09-02 19:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:13:55 --> Upload Class Initialized
DEBUG - 2026-09-02 19:13:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:13:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:13:55 --> Encryption Class Initialized
INFO - 2026-09-02 19:13:55 --> Form Validation Class Initialized
INFO - 2026-09-02 19:13:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:13:55 --> Pagination Class Initialized
INFO - 2026-09-02 19:13:55 --> Email Class Initialized
INFO - 2026-09-02 19:13:55 --> Controller Class Initialized
DEBUG - 2026-09-02 19:13:55 --> Authenticate MX_Controller Initialized
INFO - 2026-09-02 19:13:55 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:13:55 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:13:55 --> Model "Appsetting_model" initialized
DEBUG - 2026-09-02 19:13:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-09-02 19:13:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-09-02 19:13:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-09-02 19:13:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-09-02 19:13:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-09-02 19:13:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-09-02 19:13:55 --> Final output sent to browser
DEBUG - 2026-09-02 19:13:55 --> Total execution time: 2.3009
INFO - 2026-09-02 19:13:55 --> Config Class Initialized
INFO - 2026-09-02 19:13:55 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:13:55 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:13:55 --> Utf8 Class Initialized
INFO - 2026-09-02 19:13:55 --> URI Class Initialized
INFO - 2026-09-02 19:13:55 --> Router Class Initialized
INFO - 2026-09-02 19:13:55 --> Output Class Initialized
INFO - 2026-09-02 19:13:55 --> Security Class Initialized
DEBUG - 2026-09-02 19:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:13:55 --> CSRF cookie sent
INFO - 2026-09-02 19:13:55 --> CSRF token verified
INFO - 2026-09-02 19:13:55 --> Input Class Initialized
INFO - 2026-09-02 19:13:55 --> Language Class Initialized
INFO - 2026-09-02 19:13:55 --> Language Class Initialized
INFO - 2026-09-02 19:13:55 --> Config Class Initialized
INFO - 2026-09-02 19:13:55 --> Loader Class Initialized
INFO - 2026-09-02 19:13:55 --> Helper loaded: url_helper
INFO - 2026-09-02 19:13:55 --> Helper loaded: form_helper
INFO - 2026-09-02 19:13:55 --> Helper loaded: html_helper
INFO - 2026-09-02 19:13:55 --> Helper loaded: file_helper
INFO - 2026-09-02 19:13:55 --> Helper loaded: email_helper
INFO - 2026-09-02 19:13:55 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:13:55 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:13:55 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:13:55 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:13:55 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:13:55 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:13:55 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:13:55 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:13:55 --> Database Driver Class Initialized
INFO - 2026-09-02 19:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:13:57 --> Upload Class Initialized
DEBUG - 2026-09-02 19:13:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:13:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:13:57 --> Encryption Class Initialized
INFO - 2026-09-02 19:13:57 --> Form Validation Class Initialized
INFO - 2026-09-02 19:13:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:13:57 --> Pagination Class Initialized
INFO - 2026-09-02 19:13:57 --> Email Class Initialized
INFO - 2026-09-02 19:13:57 --> Controller Class Initialized
DEBUG - 2026-09-02 19:13:57 --> Authenticate MX_Controller Initialized
INFO - 2026-09-02 19:13:57 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:13:57 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:13:57 --> Model "Appsetting_model" initialized
DEBUG - 2026-09-02 19:13:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-09-02 19:13:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-09-02 19:13:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-09-02 19:13:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-09-02 19:13:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-09-02 19:13:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-09-02 19:13:59 --> Final output sent to browser
DEBUG - 2026-09-02 19:13:59 --> Total execution time: 3.5976
INFO - 2026-09-02 19:13:59 --> Config Class Initialized
INFO - 2026-09-02 19:13:59 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:13:59 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:13:59 --> Utf8 Class Initialized
INFO - 2026-09-02 19:13:59 --> URI Class Initialized
INFO - 2026-09-02 19:13:59 --> Router Class Initialized
INFO - 2026-09-02 19:13:59 --> Output Class Initialized
INFO - 2026-09-02 19:13:59 --> Security Class Initialized
DEBUG - 2026-09-02 19:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:13:59 --> CSRF cookie sent
INFO - 2026-09-02 19:13:59 --> Input Class Initialized
INFO - 2026-09-02 19:13:59 --> Language Class Initialized
INFO - 2026-09-02 19:13:59 --> Language Class Initialized
INFO - 2026-09-02 19:13:59 --> Config Class Initialized
INFO - 2026-09-02 19:13:59 --> Loader Class Initialized
INFO - 2026-09-02 19:13:59 --> Helper loaded: url_helper
INFO - 2026-09-02 19:13:59 --> Helper loaded: form_helper
INFO - 2026-09-02 19:13:59 --> Helper loaded: html_helper
INFO - 2026-09-02 19:13:59 --> Helper loaded: file_helper
INFO - 2026-09-02 19:13:59 --> Helper loaded: email_helper
INFO - 2026-09-02 19:13:59 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:13:59 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:13:59 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:13:59 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:13:59 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:13:59 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:13:59 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:13:59 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:13:59 --> Database Driver Class Initialized
INFO - 2026-09-02 19:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:14:01 --> Upload Class Initialized
DEBUG - 2026-09-02 19:14:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:14:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:14:01 --> Encryption Class Initialized
INFO - 2026-09-02 19:14:01 --> Form Validation Class Initialized
INFO - 2026-09-02 19:14:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:14:01 --> Pagination Class Initialized
INFO - 2026-09-02 19:14:01 --> Email Class Initialized
INFO - 2026-09-02 19:14:01 --> Controller Class Initialized
DEBUG - 2026-09-02 19:14:01 --> Dashboard MX_Controller Initialized
INFO - 2026-09-02 19:14:01 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:14:01 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:14:01 --> Config Class Initialized
INFO - 2026-09-02 19:14:01 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:14:01 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:14:01 --> Utf8 Class Initialized
INFO - 2026-09-02 19:14:01 --> URI Class Initialized
INFO - 2026-09-02 19:14:01 --> Router Class Initialized
INFO - 2026-09-02 19:14:01 --> Output Class Initialized
INFO - 2026-09-02 19:14:01 --> Security Class Initialized
DEBUG - 2026-09-02 19:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:14:01 --> CSRF cookie sent
INFO - 2026-09-02 19:14:01 --> Input Class Initialized
INFO - 2026-09-02 19:14:01 --> Language Class Initialized
INFO - 2026-09-02 19:14:01 --> Language Class Initialized
INFO - 2026-09-02 19:14:01 --> Config Class Initialized
INFO - 2026-09-02 19:14:01 --> Loader Class Initialized
INFO - 2026-09-02 19:14:01 --> Helper loaded: url_helper
INFO - 2026-09-02 19:14:01 --> Helper loaded: form_helper
INFO - 2026-09-02 19:14:01 --> Helper loaded: html_helper
INFO - 2026-09-02 19:14:01 --> Helper loaded: file_helper
INFO - 2026-09-02 19:14:01 --> Helper loaded: email_helper
INFO - 2026-09-02 19:14:01 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:14:01 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:14:01 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:14:01 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:14:01 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:14:01 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:14:01 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:14:01 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:14:01 --> Database Driver Class Initialized
INFO - 2026-09-02 19:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:14:03 --> Upload Class Initialized
DEBUG - 2026-09-02 19:14:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:14:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:14:03 --> Encryption Class Initialized
INFO - 2026-09-02 19:14:03 --> Form Validation Class Initialized
INFO - 2026-09-02 19:14:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:14:03 --> Pagination Class Initialized
INFO - 2026-09-02 19:14:03 --> Email Class Initialized
INFO - 2026-09-02 19:14:03 --> Controller Class Initialized
DEBUG - 2026-09-02 19:14:03 --> Dashboard MX_Controller Initialized
INFO - 2026-09-02 19:14:03 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:14:03 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:14:03 --> Config Class Initialized
INFO - 2026-09-02 19:14:03 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:14:03 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:14:03 --> Utf8 Class Initialized
INFO - 2026-09-02 19:14:03 --> URI Class Initialized
INFO - 2026-09-02 19:14:03 --> Router Class Initialized
INFO - 2026-09-02 19:14:03 --> Output Class Initialized
INFO - 2026-09-02 19:14:03 --> Security Class Initialized
DEBUG - 2026-09-02 19:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:14:03 --> CSRF cookie sent
INFO - 2026-09-02 19:14:03 --> Input Class Initialized
INFO - 2026-09-02 19:14:03 --> Language Class Initialized
INFO - 2026-09-02 19:14:03 --> Language Class Initialized
INFO - 2026-09-02 19:14:03 --> Config Class Initialized
INFO - 2026-09-02 19:14:03 --> Loader Class Initialized
INFO - 2026-09-02 19:14:03 --> Helper loaded: url_helper
INFO - 2026-09-02 19:14:03 --> Helper loaded: form_helper
INFO - 2026-09-02 19:14:03 --> Helper loaded: html_helper
INFO - 2026-09-02 19:14:03 --> Helper loaded: file_helper
INFO - 2026-09-02 19:14:03 --> Helper loaded: email_helper
INFO - 2026-09-02 19:14:03 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:14:03 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:14:03 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:14:03 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:14:03 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:14:03 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:14:03 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:14:03 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:14:03 --> Database Driver Class Initialized
INFO - 2026-09-02 19:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:14:04 --> Upload Class Initialized
DEBUG - 2026-09-02 19:14:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:14:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:14:04 --> Encryption Class Initialized
INFO - 2026-09-02 19:14:04 --> Form Validation Class Initialized
INFO - 2026-09-02 19:14:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:14:04 --> Pagination Class Initialized
INFO - 2026-09-02 19:14:04 --> Email Class Initialized
INFO - 2026-09-02 19:14:04 --> Controller Class Initialized
DEBUG - 2026-09-02 19:14:04 --> Authenticate MX_Controller Initialized
INFO - 2026-09-02 19:14:04 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:14:04 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:14:04 --> Model "Appsetting_model" initialized
DEBUG - 2026-09-02 19:14:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-09-02 19:14:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-09-02 19:14:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-09-02 19:14:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-09-02 19:14:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-09-02 19:14:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-09-02 19:14:05 --> Final output sent to browser
DEBUG - 2026-09-02 19:14:05 --> Total execution time: 2.2280
INFO - 2026-09-02 19:14:05 --> Config Class Initialized
INFO - 2026-09-02 19:14:05 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:14:05 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:14:05 --> Utf8 Class Initialized
INFO - 2026-09-02 19:14:05 --> URI Class Initialized
INFO - 2026-09-02 19:14:05 --> Router Class Initialized
INFO - 2026-09-02 19:14:05 --> Output Class Initialized
INFO - 2026-09-02 19:14:05 --> Security Class Initialized
DEBUG - 2026-09-02 19:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:14:05 --> CSRF cookie sent
INFO - 2026-09-02 19:14:05 --> CSRF token verified
INFO - 2026-09-02 19:14:05 --> Input Class Initialized
INFO - 2026-09-02 19:14:05 --> Language Class Initialized
INFO - 2026-09-02 19:14:05 --> Language Class Initialized
INFO - 2026-09-02 19:14:05 --> Config Class Initialized
INFO - 2026-09-02 19:14:05 --> Loader Class Initialized
INFO - 2026-09-02 19:14:05 --> Helper loaded: url_helper
INFO - 2026-09-02 19:14:05 --> Helper loaded: form_helper
INFO - 2026-09-02 19:14:05 --> Helper loaded: html_helper
INFO - 2026-09-02 19:14:05 --> Helper loaded: file_helper
INFO - 2026-09-02 19:14:05 --> Helper loaded: email_helper
INFO - 2026-09-02 19:14:05 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:14:05 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:14:05 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:14:05 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:14:05 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:14:05 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:14:05 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:14:05 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:14:05 --> Database Driver Class Initialized
INFO - 2026-09-02 19:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:14:07 --> Upload Class Initialized
DEBUG - 2026-09-02 19:14:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:14:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:14:07 --> Encryption Class Initialized
INFO - 2026-09-02 19:14:07 --> Form Validation Class Initialized
INFO - 2026-09-02 19:14:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:14:07 --> Pagination Class Initialized
INFO - 2026-09-02 19:14:07 --> Email Class Initialized
INFO - 2026-09-02 19:14:07 --> Controller Class Initialized
DEBUG - 2026-09-02 19:14:07 --> Authenticate MX_Controller Initialized
INFO - 2026-09-02 19:14:07 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:14:07 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:14:07 --> Model "Appsetting_model" initialized
DEBUG - 2026-09-02 19:14:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-09-02 19:14:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-09-02 19:14:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-09-02 19:14:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-09-02 19:14:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-09-02 19:14:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-09-02 19:14:08 --> Final output sent to browser
DEBUG - 2026-09-02 19:14:08 --> Total execution time: 3.2668
INFO - 2026-09-02 19:14:08 --> Config Class Initialized
INFO - 2026-09-02 19:14:08 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:14:08 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:14:08 --> Utf8 Class Initialized
INFO - 2026-09-02 19:14:08 --> URI Class Initialized
INFO - 2026-09-02 19:14:08 --> Router Class Initialized
INFO - 2026-09-02 19:14:08 --> Output Class Initialized
INFO - 2026-09-02 19:14:08 --> Security Class Initialized
DEBUG - 2026-09-02 19:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:14:08 --> CSRF cookie sent
INFO - 2026-09-02 19:14:08 --> Input Class Initialized
INFO - 2026-09-02 19:14:08 --> Language Class Initialized
INFO - 2026-09-02 19:14:08 --> Language Class Initialized
INFO - 2026-09-02 19:14:08 --> Config Class Initialized
INFO - 2026-09-02 19:14:08 --> Loader Class Initialized
INFO - 2026-09-02 19:14:08 --> Helper loaded: url_helper
INFO - 2026-09-02 19:14:08 --> Helper loaded: form_helper
INFO - 2026-09-02 19:14:08 --> Helper loaded: html_helper
INFO - 2026-09-02 19:14:08 --> Helper loaded: file_helper
INFO - 2026-09-02 19:14:08 --> Helper loaded: email_helper
INFO - 2026-09-02 19:14:08 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:14:08 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:14:08 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:14:08 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:14:08 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:14:08 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:14:08 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:14:08 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:14:08 --> Database Driver Class Initialized
INFO - 2026-09-02 19:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:14:10 --> Upload Class Initialized
DEBUG - 2026-09-02 19:14:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:14:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:14:10 --> Encryption Class Initialized
INFO - 2026-09-02 19:14:10 --> Form Validation Class Initialized
INFO - 2026-09-02 19:14:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:14:10 --> Pagination Class Initialized
INFO - 2026-09-02 19:14:10 --> Email Class Initialized
INFO - 2026-09-02 19:14:10 --> Controller Class Initialized
DEBUG - 2026-09-02 19:14:10 --> Dashboard MX_Controller Initialized
INFO - 2026-09-02 19:14:10 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:14:10 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:14:10 --> Config Class Initialized
INFO - 2026-09-02 19:14:10 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:14:10 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:14:10 --> Utf8 Class Initialized
INFO - 2026-09-02 19:14:10 --> URI Class Initialized
INFO - 2026-09-02 19:14:10 --> Router Class Initialized
INFO - 2026-09-02 19:14:10 --> Output Class Initialized
INFO - 2026-09-02 19:14:10 --> Security Class Initialized
DEBUG - 2026-09-02 19:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:14:10 --> CSRF cookie sent
INFO - 2026-09-02 19:14:10 --> Input Class Initialized
INFO - 2026-09-02 19:14:10 --> Language Class Initialized
INFO - 2026-09-02 19:14:10 --> Language Class Initialized
INFO - 2026-09-02 19:14:10 --> Config Class Initialized
INFO - 2026-09-02 19:14:10 --> Loader Class Initialized
INFO - 2026-09-02 19:14:10 --> Helper loaded: url_helper
INFO - 2026-09-02 19:14:10 --> Helper loaded: form_helper
INFO - 2026-09-02 19:14:10 --> Helper loaded: html_helper
INFO - 2026-09-02 19:14:10 --> Helper loaded: file_helper
INFO - 2026-09-02 19:14:10 --> Helper loaded: email_helper
INFO - 2026-09-02 19:14:10 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:14:10 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:14:10 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:14:10 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:14:10 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:14:10 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:14:10 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:14:10 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:14:10 --> Database Driver Class Initialized
INFO - 2026-09-02 19:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:14:12 --> Upload Class Initialized
DEBUG - 2026-09-02 19:14:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:14:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:14:12 --> Encryption Class Initialized
INFO - 2026-09-02 19:14:12 --> Form Validation Class Initialized
INFO - 2026-09-02 19:14:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:14:12 --> Pagination Class Initialized
INFO - 2026-09-02 19:14:12 --> Email Class Initialized
INFO - 2026-09-02 19:14:12 --> Controller Class Initialized
DEBUG - 2026-09-02 19:14:12 --> Dashboard MX_Controller Initialized
INFO - 2026-09-02 19:14:12 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:14:12 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:14:12 --> Config Class Initialized
INFO - 2026-09-02 19:14:12 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:14:12 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:14:12 --> Utf8 Class Initialized
INFO - 2026-09-02 19:14:12 --> URI Class Initialized
INFO - 2026-09-02 19:14:12 --> Router Class Initialized
INFO - 2026-09-02 19:14:12 --> Output Class Initialized
INFO - 2026-09-02 19:14:12 --> Security Class Initialized
DEBUG - 2026-09-02 19:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:14:12 --> CSRF cookie sent
INFO - 2026-09-02 19:14:12 --> Input Class Initialized
INFO - 2026-09-02 19:14:12 --> Language Class Initialized
INFO - 2026-09-02 19:14:12 --> Language Class Initialized
INFO - 2026-09-02 19:14:12 --> Config Class Initialized
INFO - 2026-09-02 19:14:12 --> Loader Class Initialized
INFO - 2026-09-02 19:14:12 --> Helper loaded: url_helper
INFO - 2026-09-02 19:14:12 --> Helper loaded: form_helper
INFO - 2026-09-02 19:14:12 --> Helper loaded: html_helper
INFO - 2026-09-02 19:14:12 --> Helper loaded: file_helper
INFO - 2026-09-02 19:14:12 --> Helper loaded: email_helper
INFO - 2026-09-02 19:14:12 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:14:12 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:14:12 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:14:12 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:14:12 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:14:12 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:14:12 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:14:12 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:14:12 --> Database Driver Class Initialized
INFO - 2026-09-02 19:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:14:14 --> Upload Class Initialized
DEBUG - 2026-09-02 19:14:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:14:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:14:14 --> Encryption Class Initialized
INFO - 2026-09-02 19:14:14 --> Form Validation Class Initialized
INFO - 2026-09-02 19:14:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:14:14 --> Pagination Class Initialized
INFO - 2026-09-02 19:14:14 --> Email Class Initialized
INFO - 2026-09-02 19:14:14 --> Controller Class Initialized
DEBUG - 2026-09-02 19:14:14 --> Authenticate MX_Controller Initialized
INFO - 2026-09-02 19:14:14 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:14:14 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:14:14 --> Model "Appsetting_model" initialized
DEBUG - 2026-09-02 19:14:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-09-02 19:14:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-09-02 19:14:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-09-02 19:14:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-09-02 19:14:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-09-02 19:14:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-09-02 19:14:14 --> Final output sent to browser
DEBUG - 2026-09-02 19:14:14 --> Total execution time: 2.0580
INFO - 2026-09-02 19:14:14 --> Config Class Initialized
INFO - 2026-09-02 19:14:14 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:14:14 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:14:14 --> Utf8 Class Initialized
INFO - 2026-09-02 19:14:14 --> URI Class Initialized
INFO - 2026-09-02 19:14:14 --> Router Class Initialized
INFO - 2026-09-02 19:14:14 --> Output Class Initialized
INFO - 2026-09-02 19:14:14 --> Security Class Initialized
DEBUG - 2026-09-02 19:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:14:14 --> CSRF cookie sent
INFO - 2026-09-02 19:14:14 --> CSRF token verified
INFO - 2026-09-02 19:14:14 --> Input Class Initialized
INFO - 2026-09-02 19:14:14 --> Language Class Initialized
INFO - 2026-09-02 19:14:14 --> Language Class Initialized
INFO - 2026-09-02 19:14:14 --> Config Class Initialized
INFO - 2026-09-02 19:14:14 --> Loader Class Initialized
INFO - 2026-09-02 19:14:14 --> Helper loaded: url_helper
INFO - 2026-09-02 19:14:14 --> Helper loaded: form_helper
INFO - 2026-09-02 19:14:14 --> Helper loaded: html_helper
INFO - 2026-09-02 19:14:14 --> Helper loaded: file_helper
INFO - 2026-09-02 19:14:14 --> Helper loaded: email_helper
INFO - 2026-09-02 19:14:14 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:14:14 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:14:14 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:14:14 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:14:14 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:14:14 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:14:14 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:14:14 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:14:14 --> Database Driver Class Initialized
INFO - 2026-09-02 19:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:14:16 --> Upload Class Initialized
DEBUG - 2026-09-02 19:14:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:14:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:14:16 --> Encryption Class Initialized
INFO - 2026-09-02 19:14:16 --> Form Validation Class Initialized
INFO - 2026-09-02 19:14:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:14:16 --> Pagination Class Initialized
INFO - 2026-09-02 19:14:16 --> Email Class Initialized
INFO - 2026-09-02 19:14:16 --> Controller Class Initialized
DEBUG - 2026-09-02 19:14:16 --> Authenticate MX_Controller Initialized
INFO - 2026-09-02 19:14:16 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:14:16 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:14:16 --> Model "Appsetting_model" initialized
DEBUG - 2026-09-02 19:14:17 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-09-02 19:14:17 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-09-02 19:14:17 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-09-02 19:14:17 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-09-02 19:14:17 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-09-02 19:14:17 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-09-02 19:14:17 --> Final output sent to browser
DEBUG - 2026-09-02 19:14:17 --> Total execution time: 3.1223
INFO - 2026-09-02 19:14:17 --> Config Class Initialized
INFO - 2026-09-02 19:14:17 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:14:17 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:14:17 --> Utf8 Class Initialized
INFO - 2026-09-02 19:14:17 --> URI Class Initialized
INFO - 2026-09-02 19:14:17 --> Router Class Initialized
INFO - 2026-09-02 19:14:17 --> Output Class Initialized
INFO - 2026-09-02 19:14:17 --> Security Class Initialized
DEBUG - 2026-09-02 19:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:14:17 --> CSRF cookie sent
INFO - 2026-09-02 19:14:17 --> Input Class Initialized
INFO - 2026-09-02 19:14:17 --> Language Class Initialized
INFO - 2026-09-02 19:14:17 --> Language Class Initialized
INFO - 2026-09-02 19:14:17 --> Config Class Initialized
INFO - 2026-09-02 19:14:17 --> Loader Class Initialized
INFO - 2026-09-02 19:14:17 --> Helper loaded: url_helper
INFO - 2026-09-02 19:14:17 --> Helper loaded: form_helper
INFO - 2026-09-02 19:14:17 --> Helper loaded: html_helper
INFO - 2026-09-02 19:14:17 --> Helper loaded: file_helper
INFO - 2026-09-02 19:14:17 --> Helper loaded: email_helper
INFO - 2026-09-02 19:14:17 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:14:17 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:14:17 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:14:17 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:14:17 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:14:17 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:14:17 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:14:17 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:14:17 --> Database Driver Class Initialized
INFO - 2026-09-02 19:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:14:19 --> Upload Class Initialized
DEBUG - 2026-09-02 19:14:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:14:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:14:19 --> Encryption Class Initialized
INFO - 2026-09-02 19:14:19 --> Form Validation Class Initialized
INFO - 2026-09-02 19:14:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:14:19 --> Pagination Class Initialized
INFO - 2026-09-02 19:14:19 --> Email Class Initialized
INFO - 2026-09-02 19:14:19 --> Controller Class Initialized
DEBUG - 2026-09-02 19:14:19 --> Dashboard MX_Controller Initialized
INFO - 2026-09-02 19:14:19 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:14:19 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:14:19 --> Config Class Initialized
INFO - 2026-09-02 19:14:19 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:14:19 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:14:19 --> Utf8 Class Initialized
INFO - 2026-09-02 19:14:19 --> URI Class Initialized
INFO - 2026-09-02 19:14:19 --> Router Class Initialized
INFO - 2026-09-02 19:14:19 --> Output Class Initialized
INFO - 2026-09-02 19:14:19 --> Security Class Initialized
DEBUG - 2026-09-02 19:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:14:19 --> CSRF cookie sent
INFO - 2026-09-02 19:14:19 --> Input Class Initialized
INFO - 2026-09-02 19:14:19 --> Language Class Initialized
INFO - 2026-09-02 19:14:19 --> Language Class Initialized
INFO - 2026-09-02 19:14:19 --> Config Class Initialized
INFO - 2026-09-02 19:14:19 --> Loader Class Initialized
INFO - 2026-09-02 19:14:19 --> Helper loaded: url_helper
INFO - 2026-09-02 19:14:19 --> Helper loaded: form_helper
INFO - 2026-09-02 19:14:19 --> Helper loaded: html_helper
INFO - 2026-09-02 19:14:19 --> Helper loaded: file_helper
INFO - 2026-09-02 19:14:19 --> Helper loaded: email_helper
INFO - 2026-09-02 19:14:19 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:14:19 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:14:19 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:14:19 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:14:19 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:14:19 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:14:19 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:14:19 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:14:19 --> Database Driver Class Initialized
INFO - 2026-09-02 19:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:14:21 --> Upload Class Initialized
DEBUG - 2026-09-02 19:14:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:14:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:14:21 --> Encryption Class Initialized
INFO - 2026-09-02 19:14:21 --> Form Validation Class Initialized
INFO - 2026-09-02 19:14:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:14:21 --> Pagination Class Initialized
INFO - 2026-09-02 19:14:21 --> Email Class Initialized
INFO - 2026-09-02 19:14:21 --> Controller Class Initialized
DEBUG - 2026-09-02 19:14:21 --> Dashboard MX_Controller Initialized
INFO - 2026-09-02 19:14:21 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:14:21 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:14:21 --> Config Class Initialized
INFO - 2026-09-02 19:14:21 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:14:21 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:14:21 --> Utf8 Class Initialized
INFO - 2026-09-02 19:14:21 --> URI Class Initialized
INFO - 2026-09-02 19:14:21 --> Router Class Initialized
INFO - 2026-09-02 19:14:21 --> Output Class Initialized
INFO - 2026-09-02 19:14:21 --> Security Class Initialized
DEBUG - 2026-09-02 19:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:14:21 --> CSRF cookie sent
INFO - 2026-09-02 19:14:21 --> Input Class Initialized
INFO - 2026-09-02 19:14:21 --> Language Class Initialized
INFO - 2026-09-02 19:14:21 --> Language Class Initialized
INFO - 2026-09-02 19:14:21 --> Config Class Initialized
INFO - 2026-09-02 19:14:21 --> Loader Class Initialized
INFO - 2026-09-02 19:14:21 --> Helper loaded: url_helper
INFO - 2026-09-02 19:14:21 --> Helper loaded: form_helper
INFO - 2026-09-02 19:14:21 --> Helper loaded: html_helper
INFO - 2026-09-02 19:14:21 --> Helper loaded: file_helper
INFO - 2026-09-02 19:14:21 --> Helper loaded: email_helper
INFO - 2026-09-02 19:14:21 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:14:21 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:14:21 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:14:21 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:14:21 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:14:21 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:14:21 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:14:21 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:14:21 --> Database Driver Class Initialized
INFO - 2026-09-02 19:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:14:23 --> Upload Class Initialized
DEBUG - 2026-09-02 19:14:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:14:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:14:23 --> Encryption Class Initialized
INFO - 2026-09-02 19:14:23 --> Form Validation Class Initialized
INFO - 2026-09-02 19:14:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:14:23 --> Pagination Class Initialized
INFO - 2026-09-02 19:14:23 --> Email Class Initialized
INFO - 2026-09-02 19:14:23 --> Controller Class Initialized
DEBUG - 2026-09-02 19:14:23 --> Dashboard MX_Controller Initialized
INFO - 2026-09-02 19:14:23 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:14:23 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:14:23 --> Config Class Initialized
INFO - 2026-09-02 19:14:23 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:14:23 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:14:23 --> Utf8 Class Initialized
INFO - 2026-09-02 19:14:23 --> URI Class Initialized
INFO - 2026-09-02 19:14:23 --> Router Class Initialized
INFO - 2026-09-02 19:14:23 --> Output Class Initialized
INFO - 2026-09-02 19:14:23 --> Security Class Initialized
DEBUG - 2026-09-02 19:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:14:23 --> CSRF cookie sent
INFO - 2026-09-02 19:14:23 --> Input Class Initialized
INFO - 2026-09-02 19:14:23 --> Language Class Initialized
INFO - 2026-09-02 19:14:23 --> Language Class Initialized
INFO - 2026-09-02 19:14:23 --> Config Class Initialized
INFO - 2026-09-02 19:14:23 --> Loader Class Initialized
INFO - 2026-09-02 19:14:23 --> Helper loaded: url_helper
INFO - 2026-09-02 19:14:23 --> Helper loaded: form_helper
INFO - 2026-09-02 19:14:23 --> Helper loaded: html_helper
INFO - 2026-09-02 19:14:23 --> Helper loaded: file_helper
INFO - 2026-09-02 19:14:23 --> Helper loaded: email_helper
INFO - 2026-09-02 19:14:23 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:14:23 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:14:23 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:14:23 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:14:23 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:14:23 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:14:23 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:14:23 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:14:23 --> Database Driver Class Initialized
INFO - 2026-09-02 19:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:14:26 --> Upload Class Initialized
DEBUG - 2026-09-02 19:14:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:14:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:14:26 --> Encryption Class Initialized
INFO - 2026-09-02 19:14:26 --> Form Validation Class Initialized
INFO - 2026-09-02 19:14:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:14:26 --> Pagination Class Initialized
INFO - 2026-09-02 19:14:26 --> Email Class Initialized
INFO - 2026-09-02 19:14:26 --> Controller Class Initialized
DEBUG - 2026-09-02 19:14:26 --> Dashboard MX_Controller Initialized
INFO - 2026-09-02 19:14:26 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:14:26 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:14:26 --> Config Class Initialized
INFO - 2026-09-02 19:14:26 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:14:26 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:14:26 --> Utf8 Class Initialized
INFO - 2026-09-02 19:14:26 --> URI Class Initialized
INFO - 2026-09-02 19:14:26 --> Router Class Initialized
INFO - 2026-09-02 19:14:26 --> Output Class Initialized
INFO - 2026-09-02 19:14:26 --> Security Class Initialized
DEBUG - 2026-09-02 19:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:14:26 --> CSRF cookie sent
INFO - 2026-09-02 19:14:26 --> Input Class Initialized
INFO - 2026-09-02 19:14:26 --> Language Class Initialized
INFO - 2026-09-02 19:14:26 --> Language Class Initialized
INFO - 2026-09-02 19:14:26 --> Config Class Initialized
INFO - 2026-09-02 19:14:26 --> Loader Class Initialized
INFO - 2026-09-02 19:14:26 --> Helper loaded: url_helper
INFO - 2026-09-02 19:14:26 --> Helper loaded: form_helper
INFO - 2026-09-02 19:14:26 --> Helper loaded: html_helper
INFO - 2026-09-02 19:14:26 --> Helper loaded: file_helper
INFO - 2026-09-02 19:14:26 --> Helper loaded: email_helper
INFO - 2026-09-02 19:14:26 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:14:26 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:14:26 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:14:26 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:14:26 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:14:26 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:14:26 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:14:26 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:14:26 --> Database Driver Class Initialized
INFO - 2026-09-02 19:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:14:27 --> Upload Class Initialized
DEBUG - 2026-09-02 19:14:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:14:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:14:27 --> Encryption Class Initialized
INFO - 2026-09-02 19:14:27 --> Form Validation Class Initialized
INFO - 2026-09-02 19:14:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:14:27 --> Pagination Class Initialized
INFO - 2026-09-02 19:14:27 --> Email Class Initialized
INFO - 2026-09-02 19:14:27 --> Controller Class Initialized
DEBUG - 2026-09-02 19:14:27 --> Dashboard MX_Controller Initialized
INFO - 2026-09-02 19:14:27 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:14:27 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:14:39 --> Config Class Initialized
INFO - 2026-09-02 19:14:39 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:14:39 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:14:39 --> Utf8 Class Initialized
INFO - 2026-09-02 19:14:39 --> URI Class Initialized
INFO - 2026-09-02 19:14:39 --> Router Class Initialized
INFO - 2026-09-02 19:14:39 --> Output Class Initialized
INFO - 2026-09-02 19:14:39 --> Security Class Initialized
DEBUG - 2026-09-02 19:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:14:39 --> CSRF cookie sent
INFO - 2026-09-02 19:14:39 --> Input Class Initialized
INFO - 2026-09-02 19:14:39 --> Language Class Initialized
INFO - 2026-09-02 19:14:39 --> Language Class Initialized
INFO - 2026-09-02 19:14:39 --> Config Class Initialized
INFO - 2026-09-02 19:14:39 --> Loader Class Initialized
INFO - 2026-09-02 19:14:39 --> Helper loaded: url_helper
INFO - 2026-09-02 19:14:39 --> Helper loaded: form_helper
INFO - 2026-09-02 19:14:39 --> Helper loaded: html_helper
INFO - 2026-09-02 19:14:39 --> Helper loaded: file_helper
INFO - 2026-09-02 19:14:39 --> Helper loaded: email_helper
INFO - 2026-09-02 19:14:39 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:14:39 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:14:39 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:14:39 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:14:39 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:14:39 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:14:39 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:14:39 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:14:39 --> Database Driver Class Initialized
INFO - 2026-09-02 19:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:14:41 --> Upload Class Initialized
DEBUG - 2026-09-02 19:14:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:14:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:14:41 --> Encryption Class Initialized
INFO - 2026-09-02 19:14:41 --> Form Validation Class Initialized
INFO - 2026-09-02 19:14:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:14:41 --> Pagination Class Initialized
INFO - 2026-09-02 19:14:41 --> Email Class Initialized
INFO - 2026-09-02 19:14:41 --> Controller Class Initialized
DEBUG - 2026-09-02 19:14:41 --> Authenticate MX_Controller Initialized
INFO - 2026-09-02 19:14:41 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:14:41 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:14:41 --> Model "Appsetting_model" initialized
DEBUG - 2026-09-02 19:14:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-09-02 19:14:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-09-02 19:14:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-09-02 19:14:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-09-02 19:14:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-09-02 19:14:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-09-02 19:14:41 --> Final output sent to browser
DEBUG - 2026-09-02 19:14:41 --> Total execution time: 2.5029
INFO - 2026-09-02 19:14:41 --> Config Class Initialized
INFO - 2026-09-02 19:14:41 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:14:41 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:14:41 --> Utf8 Class Initialized
INFO - 2026-09-02 19:14:41 --> URI Class Initialized
INFO - 2026-09-02 19:14:41 --> Router Class Initialized
INFO - 2026-09-02 19:14:41 --> Output Class Initialized
INFO - 2026-09-02 19:14:41 --> Security Class Initialized
DEBUG - 2026-09-02 19:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:14:41 --> CSRF cookie sent
INFO - 2026-09-02 19:14:41 --> CSRF token verified
INFO - 2026-09-02 19:14:41 --> Input Class Initialized
INFO - 2026-09-02 19:14:41 --> Language Class Initialized
INFO - 2026-09-02 19:14:41 --> Language Class Initialized
INFO - 2026-09-02 19:14:41 --> Config Class Initialized
INFO - 2026-09-02 19:14:41 --> Loader Class Initialized
INFO - 2026-09-02 19:14:41 --> Helper loaded: url_helper
INFO - 2026-09-02 19:14:41 --> Helper loaded: form_helper
INFO - 2026-09-02 19:14:41 --> Helper loaded: html_helper
INFO - 2026-09-02 19:14:41 --> Helper loaded: file_helper
INFO - 2026-09-02 19:14:41 --> Helper loaded: email_helper
INFO - 2026-09-02 19:14:41 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:14:41 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:14:41 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:14:41 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:14:41 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:14:41 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:14:41 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:14:41 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:14:41 --> Database Driver Class Initialized
INFO - 2026-09-02 19:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:14:43 --> Upload Class Initialized
DEBUG - 2026-09-02 19:14:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:14:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:14:43 --> Encryption Class Initialized
INFO - 2026-09-02 19:14:43 --> Form Validation Class Initialized
INFO - 2026-09-02 19:14:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:14:43 --> Pagination Class Initialized
INFO - 2026-09-02 19:14:43 --> Email Class Initialized
INFO - 2026-09-02 19:14:43 --> Controller Class Initialized
DEBUG - 2026-09-02 19:14:43 --> Authenticate MX_Controller Initialized
INFO - 2026-09-02 19:14:43 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:14:43 --> Model "Adminauth_model" initialized
INFO - 2026-09-02 19:14:43 --> Model "Appsetting_model" initialized
DEBUG - 2026-09-02 19:14:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-09-02 19:14:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-09-02 19:14:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-09-02 19:14:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-09-02 19:14:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-09-02 19:14:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-09-02 19:14:45 --> Final output sent to browser
DEBUG - 2026-09-02 19:14:45 --> Total execution time: 3.2231
INFO - 2026-09-02 19:21:10 --> Config Class Initialized
INFO - 2026-09-02 19:21:10 --> Hooks Class Initialized
DEBUG - 2026-09-02 19:21:10 --> UTF-8 Support Enabled
INFO - 2026-09-02 19:21:10 --> Utf8 Class Initialized
INFO - 2026-09-02 19:21:10 --> URI Class Initialized
DEBUG - 2026-09-02 19:21:10 --> No URI present. Default controller set.
INFO - 2026-09-02 19:21:10 --> Router Class Initialized
INFO - 2026-09-02 19:21:10 --> Output Class Initialized
INFO - 2026-09-02 19:21:10 --> Security Class Initialized
DEBUG - 2026-09-02 19:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-02 19:21:10 --> CSRF cookie sent
INFO - 2026-09-02 19:21:10 --> Input Class Initialized
INFO - 2026-09-02 19:21:10 --> Language Class Initialized
INFO - 2026-09-02 19:21:10 --> Language Class Initialized
INFO - 2026-09-02 19:21:10 --> Config Class Initialized
INFO - 2026-09-02 19:21:10 --> Loader Class Initialized
INFO - 2026-09-02 19:21:10 --> Helper loaded: url_helper
INFO - 2026-09-02 19:21:10 --> Helper loaded: form_helper
INFO - 2026-09-02 19:21:10 --> Helper loaded: html_helper
INFO - 2026-09-02 19:21:10 --> Helper loaded: file_helper
INFO - 2026-09-02 19:21:10 --> Helper loaded: email_helper
INFO - 2026-09-02 19:21:10 --> Helper loaded: whmaz_helper
INFO - 2026-09-02 19:21:10 --> Helper loaded: ssp_helper
INFO - 2026-09-02 19:21:10 --> Helper loaded: cpanel_helper
INFO - 2026-09-02 19:21:10 --> Helper loaded: plesk_helper
INFO - 2026-09-02 19:21:10 --> Helper loaded: directadmin_helper
INFO - 2026-09-02 19:21:10 --> Helper loaded: domain_helper
INFO - 2026-09-02 19:21:10 --> Helper loaded: entitlement_helper
INFO - 2026-09-02 19:21:10 --> Helper loaded: tenant_helper
INFO - 2026-09-02 19:21:10 --> Database Driver Class Initialized
INFO - 2026-09-02 19:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-09-02 19:21:12 --> Upload Class Initialized
DEBUG - 2026-09-02 19:21:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-02 19:21:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-02 19:21:12 --> Encryption Class Initialized
INFO - 2026-09-02 19:21:12 --> Form Validation Class Initialized
INFO - 2026-09-02 19:21:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-02 19:21:12 --> Pagination Class Initialized
INFO - 2026-09-02 19:21:12 --> Email Class Initialized
INFO - 2026-09-02 19:21:12 --> Controller Class Initialized
DEBUG - 2026-09-02 19:21:12 --> Home MX_Controller Initialized
INFO - 2026-09-02 19:21:12 --> Model "Loginattempt_model" initialized
INFO - 2026-09-02 19:21:12 --> Model "Auth_model" initialized
INFO - 2026-09-02 19:21:12 --> Model "Cart_model" initialized
DEBUG - 2026-09-02 19:21:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-09-02 19:21:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-09-02 19:21:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-09-02 19:21:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/home/views/home_view.php
INFO - 2026-09-02 19:21:13 --> Final output sent to browser
DEBUG - 2026-09-02 19:21:13 --> Total execution time: 3.3457

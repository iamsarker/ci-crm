<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-03-19 08:14:13 --> Config Class Initialized
INFO - 2026-03-19 08:14:13 --> Hooks Class Initialized
DEBUG - 2026-03-19 08:14:13 --> UTF-8 Support Enabled
INFO - 2026-03-19 08:14:13 --> Utf8 Class Initialized
INFO - 2026-03-19 08:14:13 --> URI Class Initialized
INFO - 2026-03-19 08:14:13 --> Router Class Initialized
INFO - 2026-03-19 08:14:13 --> Output Class Initialized
INFO - 2026-03-19 08:14:13 --> Security Class Initialized
DEBUG - 2026-03-19 08:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-19 08:14:13 --> CSRF cookie sent
INFO - 2026-03-19 08:14:13 --> Input Class Initialized
INFO - 2026-03-19 08:14:13 --> Language Class Initialized
INFO - 2026-03-19 08:14:13 --> Language Class Initialized
INFO - 2026-03-19 08:14:13 --> Config Class Initialized
INFO - 2026-03-19 08:14:13 --> Loader Class Initialized
INFO - 2026-03-19 08:14:13 --> Helper loaded: url_helper
INFO - 2026-03-19 08:14:13 --> Helper loaded: form_helper
INFO - 2026-03-19 08:14:13 --> Helper loaded: html_helper
INFO - 2026-03-19 08:14:13 --> Helper loaded: file_helper
INFO - 2026-03-19 08:14:13 --> Helper loaded: email_helper
INFO - 2026-03-19 08:14:13 --> Helper loaded: whmaz_helper
INFO - 2026-03-19 08:14:13 --> Helper loaded: ssp_helper
INFO - 2026-03-19 08:14:13 --> Helper loaded: cpanel_helper
INFO - 2026-03-19 08:14:13 --> Helper loaded: plesk_helper
INFO - 2026-03-19 08:14:13 --> Helper loaded: directadmin_helper
INFO - 2026-03-19 08:14:13 --> Helper loaded: domain_helper
INFO - 2026-03-19 08:14:13 --> Database Driver Class Initialized
INFO - 2026-03-19 08:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-19 08:14:15 --> Upload Class Initialized
DEBUG - 2026-03-19 08:14:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-19 08:14:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-19 08:14:15 --> Encryption Class Initialized
INFO - 2026-03-19 08:14:15 --> Form Validation Class Initialized
INFO - 2026-03-19 08:14:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-19 08:14:15 --> Pagination Class Initialized
INFO - 2026-03-19 08:14:15 --> Email Class Initialized
INFO - 2026-03-19 08:14:15 --> Controller Class Initialized
DEBUG - 2026-03-19 08:14:15 --> Dashboard MX_Controller Initialized
INFO - 2026-03-19 08:14:15 --> Model "Loginattempt_model" initialized
INFO - 2026-03-19 08:14:15 --> Model "Adminauth_model" initialized

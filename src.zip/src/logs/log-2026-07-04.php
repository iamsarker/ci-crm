<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-07-04 07:05:44 --> Config Class Initialized
INFO - 2026-07-04 07:05:44 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:05:44 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:05:44 --> Utf8 Class Initialized
INFO - 2026-07-04 07:05:44 --> URI Class Initialized
DEBUG - 2026-07-04 07:05:44 --> No URI present. Default controller set.
INFO - 2026-07-04 07:05:44 --> Router Class Initialized
INFO - 2026-07-04 07:05:44 --> Output Class Initialized
INFO - 2026-07-04 07:05:44 --> Security Class Initialized
DEBUG - 2026-07-04 07:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:05:44 --> CSRF cookie sent
INFO - 2026-07-04 07:05:44 --> Input Class Initialized
INFO - 2026-07-04 07:05:44 --> Language Class Initialized
INFO - 2026-07-04 07:05:44 --> Language Class Initialized
INFO - 2026-07-04 07:05:44 --> Config Class Initialized
INFO - 2026-07-04 07:05:44 --> Loader Class Initialized
INFO - 2026-07-04 07:05:44 --> Helper loaded: url_helper
INFO - 2026-07-04 07:05:44 --> Helper loaded: form_helper
INFO - 2026-07-04 07:05:44 --> Helper loaded: html_helper
INFO - 2026-07-04 07:05:44 --> Helper loaded: file_helper
INFO - 2026-07-04 07:05:44 --> Helper loaded: email_helper
INFO - 2026-07-04 07:05:44 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:05:44 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:05:44 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:05:44 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:05:44 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:05:44 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:05:44 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:05:44 --> Database Driver Class Initialized
INFO - 2026-07-04 07:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:05:46 --> Upload Class Initialized
DEBUG - 2026-07-04 07:05:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:05:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:05:46 --> Encryption Class Initialized
INFO - 2026-07-04 07:05:46 --> Form Validation Class Initialized
INFO - 2026-07-04 07:05:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:05:46 --> Pagination Class Initialized
INFO - 2026-07-04 07:05:46 --> Email Class Initialized
INFO - 2026-07-04 07:05:46 --> Controller Class Initialized
DEBUG - 2026-07-04 07:05:46 --> Auth MX_Controller Initialized
INFO - 2026-07-04 07:05:46 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:05:46 --> Model "Auth_model" initialized
INFO - 2026-07-04 07:05:46 --> Model "Cart_model" initialized
INFO - 2026-07-04 07:05:47 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 07:05:47 --> Config Class Initialized
INFO - 2026-07-04 07:05:47 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:05:47 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:05:47 --> Utf8 Class Initialized
INFO - 2026-07-04 07:05:47 --> URI Class Initialized
INFO - 2026-07-04 07:05:47 --> Router Class Initialized
INFO - 2026-07-04 07:05:47 --> Output Class Initialized
INFO - 2026-07-04 07:05:47 --> Security Class Initialized
DEBUG - 2026-07-04 07:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:05:47 --> CSRF cookie sent
INFO - 2026-07-04 07:05:47 --> Input Class Initialized
INFO - 2026-07-04 07:05:47 --> Language Class Initialized
INFO - 2026-07-04 07:05:47 --> Language Class Initialized
INFO - 2026-07-04 07:05:47 --> Config Class Initialized
INFO - 2026-07-04 07:05:47 --> Loader Class Initialized
INFO - 2026-07-04 07:05:47 --> Helper loaded: url_helper
INFO - 2026-07-04 07:05:47 --> Helper loaded: form_helper
INFO - 2026-07-04 07:05:47 --> Helper loaded: html_helper
INFO - 2026-07-04 07:05:47 --> Helper loaded: file_helper
INFO - 2026-07-04 07:05:47 --> Helper loaded: email_helper
INFO - 2026-07-04 07:05:47 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:05:47 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:05:47 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:05:47 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:05:47 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:05:47 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:05:47 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:05:47 --> Database Driver Class Initialized
INFO - 2026-07-04 07:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:05:49 --> Upload Class Initialized
DEBUG - 2026-07-04 07:05:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:05:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:05:49 --> Encryption Class Initialized
INFO - 2026-07-04 07:05:49 --> Form Validation Class Initialized
INFO - 2026-07-04 07:05:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:05:49 --> Pagination Class Initialized
INFO - 2026-07-04 07:05:49 --> Email Class Initialized
INFO - 2026-07-04 07:05:49 --> Controller Class Initialized
DEBUG - 2026-07-04 07:05:49 --> Auth MX_Controller Initialized
INFO - 2026-07-04 07:05:49 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:05:49 --> Model "Auth_model" initialized
INFO - 2026-07-04 07:05:49 --> Model "Cart_model" initialized
INFO - 2026-07-04 07:05:49 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-04 07:05:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-04 07:05:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-04 07:05:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-04 07:05:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-07-04 07:05:49 --> Final output sent to browser
DEBUG - 2026-07-04 07:05:49 --> Total execution time: 2.3253
INFO - 2026-07-04 07:05:49 --> Config Class Initialized
INFO - 2026-07-04 07:05:49 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:05:49 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:05:49 --> Utf8 Class Initialized
INFO - 2026-07-04 07:05:49 --> URI Class Initialized
INFO - 2026-07-04 07:05:49 --> Router Class Initialized
INFO - 2026-07-04 07:05:49 --> Output Class Initialized
INFO - 2026-07-04 07:05:49 --> Security Class Initialized
DEBUG - 2026-07-04 07:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:05:49 --> CSRF cookie sent
INFO - 2026-07-04 07:05:49 --> Input Class Initialized
INFO - 2026-07-04 07:05:49 --> Language Class Initialized
INFO - 2026-07-04 07:05:49 --> Language Class Initialized
INFO - 2026-07-04 07:05:49 --> Config Class Initialized
INFO - 2026-07-04 07:05:49 --> Loader Class Initialized
INFO - 2026-07-04 07:05:49 --> Helper loaded: url_helper
INFO - 2026-07-04 07:05:49 --> Helper loaded: form_helper
INFO - 2026-07-04 07:05:49 --> Helper loaded: html_helper
INFO - 2026-07-04 07:05:49 --> Helper loaded: file_helper
INFO - 2026-07-04 07:05:49 --> Helper loaded: email_helper
INFO - 2026-07-04 07:05:49 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:05:49 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:05:49 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:05:49 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:05:49 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:05:49 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:05:49 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:05:49 --> Database Driver Class Initialized
INFO - 2026-07-04 07:05:51 --> Config Class Initialized
INFO - 2026-07-04 07:05:51 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:05:51 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:05:51 --> Utf8 Class Initialized
INFO - 2026-07-04 07:05:51 --> URI Class Initialized
INFO - 2026-07-04 07:05:51 --> Router Class Initialized
INFO - 2026-07-04 07:05:51 --> Output Class Initialized
INFO - 2026-07-04 07:05:51 --> Security Class Initialized
DEBUG - 2026-07-04 07:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:05:51 --> CSRF cookie sent
INFO - 2026-07-04 07:05:51 --> Input Class Initialized
INFO - 2026-07-04 07:05:51 --> Language Class Initialized
INFO - 2026-07-04 07:05:51 --> Language Class Initialized
INFO - 2026-07-04 07:05:51 --> Config Class Initialized
INFO - 2026-07-04 07:05:51 --> Loader Class Initialized
INFO - 2026-07-04 07:05:51 --> Helper loaded: url_helper
INFO - 2026-07-04 07:05:51 --> Helper loaded: form_helper
INFO - 2026-07-04 07:05:51 --> Helper loaded: html_helper
INFO - 2026-07-04 07:05:51 --> Helper loaded: file_helper
INFO - 2026-07-04 07:05:51 --> Helper loaded: email_helper
INFO - 2026-07-04 07:05:51 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:05:51 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:05:51 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:05:51 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:05:51 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:05:51 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:05:51 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:05:51 --> Database Driver Class Initialized
INFO - 2026-07-04 07:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:05:51 --> Upload Class Initialized
DEBUG - 2026-07-04 07:05:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:05:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:05:51 --> Encryption Class Initialized
INFO - 2026-07-04 07:05:51 --> Form Validation Class Initialized
INFO - 2026-07-04 07:05:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:05:51 --> Pagination Class Initialized
INFO - 2026-07-04 07:05:51 --> Email Class Initialized
INFO - 2026-07-04 07:05:51 --> Controller Class Initialized
DEBUG - 2026-07-04 07:05:51 --> Cart MX_Controller Initialized
INFO - 2026-07-04 07:05:51 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:05:51 --> Model "Auth_model" initialized
INFO - 2026-07-04 07:05:51 --> Model "Cart_model" initialized
INFO - 2026-07-04 07:05:51 --> Model "Common_model" initialized
INFO - 2026-07-04 07:05:51 --> Model "Order_model" initialized
INFO - 2026-07-04 07:05:51 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 07:05:51 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-04 07:05:51 --> Model "Promocode_model" initialized
DEBUG - 2026-07-04 07:05:51 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-04 07:05:51 --> Model "Plan_model" initialized
INFO - 2026-07-04 07:05:51 --> Model "Orderlicense_model" initialized
INFO - 2026-07-04 07:05:51 --> Final output sent to browser
DEBUG - 2026-07-04 07:05:51 --> Total execution time: 1.9207
INFO - 2026-07-04 07:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:05:53 --> Upload Class Initialized
DEBUG - 2026-07-04 07:05:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:05:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:05:53 --> Encryption Class Initialized
INFO - 2026-07-04 07:05:53 --> Form Validation Class Initialized
INFO - 2026-07-04 07:05:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:05:53 --> Pagination Class Initialized
INFO - 2026-07-04 07:05:53 --> Email Class Initialized
INFO - 2026-07-04 07:05:53 --> Controller Class Initialized
DEBUG - 2026-07-04 07:05:53 --> Dashboard MX_Controller Initialized
INFO - 2026-07-04 07:05:53 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:05:53 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:05:53 --> Config Class Initialized
INFO - 2026-07-04 07:05:53 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:05:53 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:05:53 --> Utf8 Class Initialized
INFO - 2026-07-04 07:05:53 --> URI Class Initialized
INFO - 2026-07-04 07:05:53 --> Router Class Initialized
INFO - 2026-07-04 07:05:53 --> Output Class Initialized
INFO - 2026-07-04 07:05:53 --> Security Class Initialized
DEBUG - 2026-07-04 07:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:05:53 --> CSRF cookie sent
INFO - 2026-07-04 07:05:53 --> Input Class Initialized
INFO - 2026-07-04 07:05:53 --> Language Class Initialized
INFO - 2026-07-04 07:05:53 --> Language Class Initialized
INFO - 2026-07-04 07:05:53 --> Config Class Initialized
INFO - 2026-07-04 07:05:53 --> Loader Class Initialized
INFO - 2026-07-04 07:05:53 --> Helper loaded: url_helper
INFO - 2026-07-04 07:05:53 --> Helper loaded: form_helper
INFO - 2026-07-04 07:05:53 --> Helper loaded: html_helper
INFO - 2026-07-04 07:05:53 --> Helper loaded: file_helper
INFO - 2026-07-04 07:05:53 --> Helper loaded: email_helper
INFO - 2026-07-04 07:05:53 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:05:53 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:05:53 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:05:53 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:05:53 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:05:53 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:05:53 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:05:53 --> Database Driver Class Initialized
INFO - 2026-07-04 07:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:05:55 --> Upload Class Initialized
DEBUG - 2026-07-04 07:05:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:05:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:05:55 --> Encryption Class Initialized
INFO - 2026-07-04 07:05:55 --> Form Validation Class Initialized
INFO - 2026-07-04 07:05:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:05:55 --> Pagination Class Initialized
INFO - 2026-07-04 07:05:55 --> Email Class Initialized
INFO - 2026-07-04 07:05:55 --> Controller Class Initialized
DEBUG - 2026-07-04 07:05:55 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 07:05:55 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:05:55 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:05:55 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-04 07:05:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-04 07:05:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-04 07:05:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-07-04 07:05:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-04 07:05:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-04 07:05:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-07-04 07:05:55 --> Final output sent to browser
DEBUG - 2026-07-04 07:05:55 --> Total execution time: 2.3808
INFO - 2026-07-04 07:06:13 --> Config Class Initialized
INFO - 2026-07-04 07:06:13 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:06:13 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:06:13 --> Utf8 Class Initialized
INFO - 2026-07-04 07:06:13 --> URI Class Initialized
INFO - 2026-07-04 07:06:13 --> Router Class Initialized
INFO - 2026-07-04 07:06:13 --> Output Class Initialized
INFO - 2026-07-04 07:06:13 --> Security Class Initialized
DEBUG - 2026-07-04 07:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:06:13 --> CSRF cookie sent
INFO - 2026-07-04 07:06:13 --> CSRF token verified
INFO - 2026-07-04 07:06:13 --> Input Class Initialized
INFO - 2026-07-04 07:06:13 --> Language Class Initialized
INFO - 2026-07-04 07:06:13 --> Language Class Initialized
INFO - 2026-07-04 07:06:13 --> Config Class Initialized
INFO - 2026-07-04 07:06:13 --> Loader Class Initialized
INFO - 2026-07-04 07:06:13 --> Helper loaded: url_helper
INFO - 2026-07-04 07:06:13 --> Helper loaded: form_helper
INFO - 2026-07-04 07:06:13 --> Helper loaded: html_helper
INFO - 2026-07-04 07:06:13 --> Helper loaded: file_helper
INFO - 2026-07-04 07:06:13 --> Helper loaded: email_helper
INFO - 2026-07-04 07:06:13 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:06:13 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:06:13 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:06:13 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:06:13 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:06:13 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:06:13 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:06:13 --> Database Driver Class Initialized
INFO - 2026-07-04 07:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:06:15 --> Upload Class Initialized
DEBUG - 2026-07-04 07:06:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:06:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:06:15 --> Encryption Class Initialized
INFO - 2026-07-04 07:06:15 --> Form Validation Class Initialized
INFO - 2026-07-04 07:06:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:06:15 --> Pagination Class Initialized
INFO - 2026-07-04 07:06:15 --> Email Class Initialized
INFO - 2026-07-04 07:06:15 --> Controller Class Initialized
DEBUG - 2026-07-04 07:06:15 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 07:06:15 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:06:15 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:06:15 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 07:06:19 --> Config Class Initialized
INFO - 2026-07-04 07:06:19 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:06:19 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:06:19 --> Utf8 Class Initialized
INFO - 2026-07-04 07:06:19 --> URI Class Initialized
INFO - 2026-07-04 07:06:19 --> Router Class Initialized
INFO - 2026-07-04 07:06:19 --> Output Class Initialized
INFO - 2026-07-04 07:06:19 --> Security Class Initialized
DEBUG - 2026-07-04 07:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:06:19 --> CSRF cookie sent
INFO - 2026-07-04 07:06:19 --> Input Class Initialized
INFO - 2026-07-04 07:06:19 --> Language Class Initialized
INFO - 2026-07-04 07:06:19 --> Language Class Initialized
INFO - 2026-07-04 07:06:19 --> Config Class Initialized
INFO - 2026-07-04 07:06:19 --> Loader Class Initialized
INFO - 2026-07-04 07:06:19 --> Helper loaded: url_helper
INFO - 2026-07-04 07:06:19 --> Helper loaded: form_helper
INFO - 2026-07-04 07:06:19 --> Helper loaded: html_helper
INFO - 2026-07-04 07:06:19 --> Helper loaded: file_helper
INFO - 2026-07-04 07:06:19 --> Helper loaded: email_helper
INFO - 2026-07-04 07:06:19 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:06:19 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:06:19 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:06:19 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:06:19 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:06:19 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:06:19 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:06:19 --> Database Driver Class Initialized
INFO - 2026-07-04 07:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:06:21 --> Upload Class Initialized
DEBUG - 2026-07-04 07:06:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:06:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:06:21 --> Encryption Class Initialized
INFO - 2026-07-04 07:06:21 --> Form Validation Class Initialized
INFO - 2026-07-04 07:06:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:06:21 --> Pagination Class Initialized
INFO - 2026-07-04 07:06:21 --> Email Class Initialized
INFO - 2026-07-04 07:06:21 --> Controller Class Initialized
DEBUG - 2026-07-04 07:06:21 --> Dashboard MX_Controller Initialized
INFO - 2026-07-04 07:06:21 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:06:21 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:06:22 --> Model "Dashboard_model" initialized
DEBUG - 2026-07-04 07:06:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-04 07:06:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-04 07:06:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-04 07:06:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-04 07:06:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-04 07:06:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/dashboard_index.php
INFO - 2026-07-04 07:06:22 --> Final output sent to browser
DEBUG - 2026-07-04 07:06:22 --> Total execution time: 2.1366
INFO - 2026-07-04 07:06:22 --> Config Class Initialized
INFO - 2026-07-04 07:06:22 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:06:22 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:06:22 --> Utf8 Class Initialized
INFO - 2026-07-04 07:06:22 --> URI Class Initialized
INFO - 2026-07-04 07:06:22 --> Config Class Initialized
INFO - 2026-07-04 07:06:22 --> Hooks Class Initialized
INFO - 2026-07-04 07:06:22 --> Config Class Initialized
DEBUG - 2026-07-04 07:06:22 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:06:22 --> Hooks Class Initialized
INFO - 2026-07-04 07:06:22 --> Utf8 Class Initialized
INFO - 2026-07-04 07:06:22 --> Router Class Initialized
INFO - 2026-07-04 07:06:22 --> URI Class Initialized
DEBUG - 2026-07-04 07:06:22 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:06:22 --> Utf8 Class Initialized
INFO - 2026-07-04 07:06:22 --> Output Class Initialized
INFO - 2026-07-04 07:06:22 --> Router Class Initialized
INFO - 2026-07-04 07:06:22 --> Security Class Initialized
DEBUG - 2026-07-04 07:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:06:22 --> Input Class Initialized
INFO - 2026-07-04 07:06:22 --> Language Class Initialized
INFO - 2026-07-04 07:06:22 --> Config Class Initialized
INFO - 2026-07-04 07:06:22 --> Hooks Class Initialized
INFO - 2026-07-04 07:06:22 --> Output Class Initialized
INFO - 2026-07-04 07:06:22 --> Language Class Initialized
INFO - 2026-07-04 07:06:22 --> Config Class Initialized
INFO - 2026-07-04 07:06:22 --> Security Class Initialized
DEBUG - 2026-07-04 07:06:22 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:06:22 --> Utf8 Class Initialized
DEBUG - 2026-07-04 07:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:06:22 --> Input Class Initialized
INFO - 2026-07-04 07:06:22 --> URI Class Initialized
INFO - 2026-07-04 07:06:22 --> Language Class Initialized
INFO - 2026-07-04 07:06:22 --> URI Class Initialized
INFO - 2026-07-04 07:06:22 --> Language Class Initialized
INFO - 2026-07-04 07:06:22 --> Config Class Initialized
INFO - 2026-07-04 07:06:22 --> Loader Class Initialized
INFO - 2026-07-04 07:06:22 --> Config Class Initialized
INFO - 2026-07-04 07:06:22 --> Hooks Class Initialized
INFO - 2026-07-04 07:06:22 --> Helper loaded: url_helper
INFO - 2026-07-04 07:06:22 --> Router Class Initialized
INFO - 2026-07-04 07:06:22 --> Loader Class Initialized
INFO - 2026-07-04 07:06:22 --> Router Class Initialized
INFO - 2026-07-04 07:06:22 --> Helper loaded: url_helper
INFO - 2026-07-04 07:06:22 --> Output Class Initialized
INFO - 2026-07-04 07:06:22 --> Helper loaded: form_helper
INFO - 2026-07-04 07:06:22 --> Output Class Initialized
INFO - 2026-07-04 07:06:22 --> Helper loaded: html_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: form_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: file_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: email_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: html_helper
INFO - 2026-07-04 07:06:22 --> Security Class Initialized
INFO - 2026-07-04 07:06:22 --> Helper loaded: file_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: email_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: ssp_helper
DEBUG - 2026-07-04 07:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:06:22 --> Input Class Initialized
INFO - 2026-07-04 07:06:22 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:06:22 --> Language Class Initialized
INFO - 2026-07-04 07:06:22 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: ssp_helper
DEBUG - 2026-07-04 07:06:22 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:06:22 --> Utf8 Class Initialized
INFO - 2026-07-04 07:06:22 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:06:22 --> URI Class Initialized
INFO - 2026-07-04 07:06:22 --> Language Class Initialized
INFO - 2026-07-04 07:06:22 --> Config Class Initialized
INFO - 2026-07-04 07:06:22 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:06:22 --> Security Class Initialized
INFO - 2026-07-04 07:06:22 --> Router Class Initialized
DEBUG - 2026-07-04 07:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:06:22 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:06:22 --> Config Class Initialized
INFO - 2026-07-04 07:06:22 --> Hooks Class Initialized
INFO - 2026-07-04 07:06:22 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:06:22 --> Output Class Initialized
DEBUG - 2026-07-04 07:06:22 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:06:22 --> Utf8 Class Initialized
INFO - 2026-07-04 07:06:22 --> Input Class Initialized
INFO - 2026-07-04 07:06:22 --> Loader Class Initialized
INFO - 2026-07-04 07:06:22 --> Security Class Initialized
INFO - 2026-07-04 07:06:22 --> Language Class Initialized
INFO - 2026-07-04 07:06:22 --> URI Class Initialized
INFO - 2026-07-04 07:06:22 --> Helper loaded: url_helper
INFO - 2026-07-04 07:06:22 --> Database Driver Class Initialized
DEBUG - 2026-07-04 07:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:06:22 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:06:22 --> Language Class Initialized
INFO - 2026-07-04 07:06:22 --> Config Class Initialized
INFO - 2026-07-04 07:06:22 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:06:22 --> Input Class Initialized
INFO - 2026-07-04 07:06:22 --> Language Class Initialized
INFO - 2026-07-04 07:06:22 --> Helper loaded: form_helper
INFO - 2026-07-04 07:06:22 --> Router Class Initialized
INFO - 2026-07-04 07:06:22 --> Helper loaded: html_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: file_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: email_helper
INFO - 2026-07-04 07:06:22 --> Loader Class Initialized
INFO - 2026-07-04 07:06:22 --> Language Class Initialized
INFO - 2026-07-04 07:06:22 --> Config Class Initialized
INFO - 2026-07-04 07:06:22 --> Output Class Initialized
INFO - 2026-07-04 07:06:22 --> Helper loaded: url_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:06:22 --> Security Class Initialized
INFO - 2026-07-04 07:06:22 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: form_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: html_helper
DEBUG - 2026-07-04 07:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:06:22 --> Loader Class Initialized
INFO - 2026-07-04 07:06:22 --> Input Class Initialized
INFO - 2026-07-04 07:06:22 --> Helper loaded: file_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: email_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:06:22 --> Language Class Initialized
INFO - 2026-07-04 07:06:22 --> Helper loaded: url_helper
INFO - 2026-07-04 07:06:22 --> Language Class Initialized
INFO - 2026-07-04 07:06:22 --> Config Class Initialized
INFO - 2026-07-04 07:06:22 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: form_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: html_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: file_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: email_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:06:22 --> Loader Class Initialized
INFO - 2026-07-04 07:06:22 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: url_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:06:22 --> Database Driver Class Initialized
INFO - 2026-07-04 07:06:22 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: form_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: html_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: file_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: email_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:06:22 --> Database Driver Class Initialized
INFO - 2026-07-04 07:06:22 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:06:22 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:06:22 --> Database Driver Class Initialized
INFO - 2026-07-04 07:06:22 --> Database Driver Class Initialized
INFO - 2026-07-04 07:06:22 --> Database Driver Class Initialized
INFO - 2026-07-04 07:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:06:24 --> Upload Class Initialized
DEBUG - 2026-07-04 07:06:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:06:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:06:24 --> Encryption Class Initialized
INFO - 2026-07-04 07:06:24 --> Form Validation Class Initialized
INFO - 2026-07-04 07:06:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:06:24 --> Pagination Class Initialized
INFO - 2026-07-04 07:06:24 --> Email Class Initialized
INFO - 2026-07-04 07:06:24 --> Controller Class Initialized
DEBUG - 2026-07-04 07:06:24 --> Invoice MX_Controller Initialized
INFO - 2026-07-04 07:06:24 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:06:24 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:06:24 --> Model "Billing_model" initialized
INFO - 2026-07-04 07:06:24 --> Model "Common_model" initialized
INFO - 2026-07-04 07:06:24 --> Model "Invoice_model" initialized
INFO - 2026-07-04 07:06:24 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 07:06:24 --> Final output sent to browser
DEBUG - 2026-07-04 07:06:24 --> Total execution time: 2.6106
INFO - 2026-07-04 07:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:06:24 --> Upload Class Initialized
DEBUG - 2026-07-04 07:06:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:06:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:06:24 --> Encryption Class Initialized
INFO - 2026-07-04 07:06:24 --> Form Validation Class Initialized
INFO - 2026-07-04 07:06:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:06:24 --> Pagination Class Initialized
INFO - 2026-07-04 07:06:24 --> Email Class Initialized
INFO - 2026-07-04 07:06:24 --> Controller Class Initialized
DEBUG - 2026-07-04 07:06:24 --> Dashboard MX_Controller Initialized
INFO - 2026-07-04 07:06:24 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:06:24 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:06:25 --> Model "Dashboard_model" initialized
INFO - 2026-07-04 07:06:25 --> Final output sent to browser
DEBUG - 2026-07-04 07:06:25 --> Total execution time: 3.4097
INFO - 2026-07-04 07:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:06:25 --> Upload Class Initialized
DEBUG - 2026-07-04 07:06:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:06:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:06:25 --> Encryption Class Initialized
INFO - 2026-07-04 07:06:25 --> Form Validation Class Initialized
INFO - 2026-07-04 07:06:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:06:25 --> Pagination Class Initialized
INFO - 2026-07-04 07:06:25 --> Email Class Initialized
INFO - 2026-07-04 07:06:25 --> Controller Class Initialized
DEBUG - 2026-07-04 07:06:25 --> Dashboard MX_Controller Initialized
INFO - 2026-07-04 07:06:25 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:06:25 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:06:25 --> Model "Dashboard_model" initialized
INFO - 2026-07-04 07:06:26 --> Final output sent to browser
DEBUG - 2026-07-04 07:06:26 --> Total execution time: 4.1403
INFO - 2026-07-04 07:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:06:26 --> Upload Class Initialized
DEBUG - 2026-07-04 07:06:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:06:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:06:26 --> Encryption Class Initialized
INFO - 2026-07-04 07:06:26 --> Form Validation Class Initialized
INFO - 2026-07-04 07:06:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:06:26 --> Pagination Class Initialized
INFO - 2026-07-04 07:06:26 --> Email Class Initialized
INFO - 2026-07-04 07:06:26 --> Controller Class Initialized
DEBUG - 2026-07-04 07:06:26 --> Order MX_Controller Initialized
INFO - 2026-07-04 07:06:26 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:06:26 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:06:26 --> Model "Order_model" initialized
INFO - 2026-07-04 07:06:26 --> Model "Common_model" initialized
INFO - 2026-07-04 07:06:26 --> Model "Currency_model" initialized
INFO - 2026-07-04 07:06:27 --> Final output sent to browser
DEBUG - 2026-07-04 07:06:27 --> Total execution time: 4.9260
INFO - 2026-07-04 07:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:06:27 --> Upload Class Initialized
DEBUG - 2026-07-04 07:06:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:06:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:06:27 --> Encryption Class Initialized
INFO - 2026-07-04 07:06:27 --> Form Validation Class Initialized
INFO - 2026-07-04 07:06:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:06:27 --> Pagination Class Initialized
INFO - 2026-07-04 07:06:27 --> Email Class Initialized
INFO - 2026-07-04 07:06:27 --> Controller Class Initialized
DEBUG - 2026-07-04 07:06:27 --> Dashboard MX_Controller Initialized
INFO - 2026-07-04 07:06:27 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:06:27 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:06:27 --> Model "Dashboard_model" initialized
INFO - 2026-07-04 07:06:27 --> Final output sent to browser
DEBUG - 2026-07-04 07:06:27 --> Total execution time: 5.6807
INFO - 2026-07-04 07:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:06:27 --> Upload Class Initialized
DEBUG - 2026-07-04 07:06:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:06:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:06:27 --> Encryption Class Initialized
INFO - 2026-07-04 07:06:27 --> Form Validation Class Initialized
INFO - 2026-07-04 07:06:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:06:27 --> Pagination Class Initialized
INFO - 2026-07-04 07:06:27 --> Email Class Initialized
INFO - 2026-07-04 07:06:27 --> Controller Class Initialized
DEBUG - 2026-07-04 07:06:27 --> Ticket MX_Controller Initialized
INFO - 2026-07-04 07:06:27 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:06:27 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:06:27 --> Model "Support_model" initialized
INFO - 2026-07-04 07:06:27 --> Model "Common_model" initialized
INFO - 2026-07-04 07:06:28 --> Final output sent to browser
DEBUG - 2026-07-04 07:06:28 --> Total execution time: 6.5068
INFO - 2026-07-04 07:07:35 --> Config Class Initialized
INFO - 2026-07-04 07:07:35 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:07:35 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:07:35 --> Utf8 Class Initialized
INFO - 2026-07-04 07:07:35 --> URI Class Initialized
INFO - 2026-07-04 07:07:35 --> Router Class Initialized
INFO - 2026-07-04 07:07:35 --> Output Class Initialized
INFO - 2026-07-04 07:07:35 --> Security Class Initialized
DEBUG - 2026-07-04 07:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:07:35 --> CSRF cookie sent
INFO - 2026-07-04 07:07:35 --> Input Class Initialized
INFO - 2026-07-04 07:07:35 --> Language Class Initialized
INFO - 2026-07-04 07:07:35 --> Language Class Initialized
INFO - 2026-07-04 07:07:35 --> Config Class Initialized
INFO - 2026-07-04 07:07:35 --> Loader Class Initialized
INFO - 2026-07-04 07:07:35 --> Helper loaded: url_helper
INFO - 2026-07-04 07:07:35 --> Helper loaded: form_helper
INFO - 2026-07-04 07:07:35 --> Helper loaded: html_helper
INFO - 2026-07-04 07:07:35 --> Helper loaded: file_helper
INFO - 2026-07-04 07:07:35 --> Helper loaded: email_helper
INFO - 2026-07-04 07:07:35 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:07:35 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:07:35 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:07:35 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:07:35 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:07:35 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:07:35 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:07:35 --> Database Driver Class Initialized
INFO - 2026-07-04 07:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:07:37 --> Upload Class Initialized
DEBUG - 2026-07-04 07:07:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:07:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:07:37 --> Encryption Class Initialized
INFO - 2026-07-04 07:07:37 --> Form Validation Class Initialized
INFO - 2026-07-04 07:07:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:07:37 --> Pagination Class Initialized
INFO - 2026-07-04 07:07:37 --> Email Class Initialized
INFO - 2026-07-04 07:07:37 --> Controller Class Initialized
DEBUG - 2026-07-04 07:07:37 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 07:07:37 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:07:37 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:07:37 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 07:07:37 --> Config Class Initialized
INFO - 2026-07-04 07:07:37 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:07:37 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:07:37 --> Utf8 Class Initialized
INFO - 2026-07-04 07:07:37 --> URI Class Initialized
INFO - 2026-07-04 07:07:37 --> Router Class Initialized
INFO - 2026-07-04 07:07:37 --> Output Class Initialized
INFO - 2026-07-04 07:07:37 --> Security Class Initialized
DEBUG - 2026-07-04 07:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:07:37 --> CSRF cookie sent
INFO - 2026-07-04 07:07:37 --> Input Class Initialized
INFO - 2026-07-04 07:07:37 --> Language Class Initialized
INFO - 2026-07-04 07:07:37 --> Language Class Initialized
INFO - 2026-07-04 07:07:37 --> Config Class Initialized
INFO - 2026-07-04 07:07:37 --> Loader Class Initialized
INFO - 2026-07-04 07:07:37 --> Helper loaded: url_helper
INFO - 2026-07-04 07:07:37 --> Helper loaded: form_helper
INFO - 2026-07-04 07:07:37 --> Helper loaded: html_helper
INFO - 2026-07-04 07:07:37 --> Helper loaded: file_helper
INFO - 2026-07-04 07:07:37 --> Helper loaded: email_helper
INFO - 2026-07-04 07:07:37 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:07:37 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:07:37 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:07:37 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:07:37 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:07:37 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:07:37 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:07:37 --> Database Driver Class Initialized
INFO - 2026-07-04 07:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:07:40 --> Upload Class Initialized
DEBUG - 2026-07-04 07:07:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:07:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:07:40 --> Encryption Class Initialized
INFO - 2026-07-04 07:07:40 --> Form Validation Class Initialized
INFO - 2026-07-04 07:07:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:07:40 --> Pagination Class Initialized
INFO - 2026-07-04 07:07:40 --> Email Class Initialized
INFO - 2026-07-04 07:07:40 --> Controller Class Initialized
DEBUG - 2026-07-04 07:07:40 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 07:07:40 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:07:40 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:07:40 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-04 07:07:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-04 07:07:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-04 07:07:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-07-04 07:07:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-04 07:07:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-04 07:07:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-07-04 07:07:40 --> Final output sent to browser
DEBUG - 2026-07-04 07:07:40 --> Total execution time: 3.4492
INFO - 2026-07-04 07:07:49 --> Config Class Initialized
INFO - 2026-07-04 07:07:49 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:07:49 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:07:49 --> Utf8 Class Initialized
INFO - 2026-07-04 07:07:49 --> URI Class Initialized
INFO - 2026-07-04 07:07:49 --> Router Class Initialized
INFO - 2026-07-04 07:07:49 --> Output Class Initialized
INFO - 2026-07-04 07:07:49 --> Security Class Initialized
DEBUG - 2026-07-04 07:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:07:49 --> CSRF cookie sent
INFO - 2026-07-04 07:07:49 --> CSRF token verified
INFO - 2026-07-04 07:07:49 --> Input Class Initialized
INFO - 2026-07-04 07:07:49 --> Language Class Initialized
INFO - 2026-07-04 07:07:49 --> Language Class Initialized
INFO - 2026-07-04 07:07:49 --> Config Class Initialized
INFO - 2026-07-04 07:07:49 --> Loader Class Initialized
INFO - 2026-07-04 07:07:49 --> Helper loaded: url_helper
INFO - 2026-07-04 07:07:49 --> Helper loaded: form_helper
INFO - 2026-07-04 07:07:49 --> Helper loaded: html_helper
INFO - 2026-07-04 07:07:49 --> Helper loaded: file_helper
INFO - 2026-07-04 07:07:49 --> Helper loaded: email_helper
INFO - 2026-07-04 07:07:49 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:07:49 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:07:49 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:07:49 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:07:49 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:07:49 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:07:49 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:07:49 --> Database Driver Class Initialized
INFO - 2026-07-04 07:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:07:51 --> Upload Class Initialized
DEBUG - 2026-07-04 07:07:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:07:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:07:51 --> Encryption Class Initialized
INFO - 2026-07-04 07:07:51 --> Form Validation Class Initialized
INFO - 2026-07-04 07:07:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:07:51 --> Pagination Class Initialized
INFO - 2026-07-04 07:07:51 --> Email Class Initialized
INFO - 2026-07-04 07:07:51 --> Controller Class Initialized
DEBUG - 2026-07-04 07:07:51 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 07:07:51 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:07:51 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:07:51 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-04 07:07:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-04 07:07:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-04 07:07:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-07-04 07:07:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-04 07:07:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-04 07:07:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-07-04 07:07:53 --> Final output sent to browser
DEBUG - 2026-07-04 07:07:53 --> Total execution time: 3.5882
INFO - 2026-07-04 07:08:02 --> Config Class Initialized
INFO - 2026-07-04 07:08:02 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:08:02 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:08:02 --> Utf8 Class Initialized
INFO - 2026-07-04 07:08:02 --> URI Class Initialized
INFO - 2026-07-04 07:08:02 --> Router Class Initialized
INFO - 2026-07-04 07:08:02 --> Output Class Initialized
INFO - 2026-07-04 07:08:02 --> Security Class Initialized
DEBUG - 2026-07-04 07:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:08:02 --> CSRF cookie sent
INFO - 2026-07-04 07:08:02 --> CSRF token verified
INFO - 2026-07-04 07:08:02 --> Input Class Initialized
INFO - 2026-07-04 07:08:02 --> Language Class Initialized
INFO - 2026-07-04 07:08:02 --> Language Class Initialized
INFO - 2026-07-04 07:08:02 --> Config Class Initialized
INFO - 2026-07-04 07:08:02 --> Loader Class Initialized
INFO - 2026-07-04 07:08:02 --> Helper loaded: url_helper
INFO - 2026-07-04 07:08:02 --> Helper loaded: form_helper
INFO - 2026-07-04 07:08:02 --> Helper loaded: html_helper
INFO - 2026-07-04 07:08:02 --> Helper loaded: file_helper
INFO - 2026-07-04 07:08:02 --> Helper loaded: email_helper
INFO - 2026-07-04 07:08:02 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:08:02 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:08:02 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:08:02 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:08:02 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:08:02 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:08:02 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:08:02 --> Database Driver Class Initialized
INFO - 2026-07-04 07:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:08:04 --> Upload Class Initialized
DEBUG - 2026-07-04 07:08:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:08:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:08:04 --> Encryption Class Initialized
INFO - 2026-07-04 07:08:04 --> Form Validation Class Initialized
INFO - 2026-07-04 07:08:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:08:04 --> Pagination Class Initialized
INFO - 2026-07-04 07:08:04 --> Email Class Initialized
INFO - 2026-07-04 07:08:04 --> Controller Class Initialized
DEBUG - 2026-07-04 07:08:04 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 07:08:04 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:08:04 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:08:04 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-04 07:08:06 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-04 07:08:06 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-04 07:08:06 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-07-04 07:08:06 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-04 07:08:06 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-04 07:08:06 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-07-04 07:08:06 --> Final output sent to browser
DEBUG - 2026-07-04 07:08:06 --> Total execution time: 3.6748
INFO - 2026-07-04 07:16:47 --> Config Class Initialized
INFO - 2026-07-04 07:16:47 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:16:47 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:16:47 --> Utf8 Class Initialized
INFO - 2026-07-04 07:16:47 --> URI Class Initialized
INFO - 2026-07-04 07:16:47 --> Router Class Initialized
INFO - 2026-07-04 07:16:47 --> Output Class Initialized
INFO - 2026-07-04 07:16:47 --> Security Class Initialized
DEBUG - 2026-07-04 07:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:16:47 --> CSRF cookie sent
INFO - 2026-07-04 07:16:49 --> Config Class Initialized
INFO - 2026-07-04 07:16:49 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:16:49 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:16:49 --> Utf8 Class Initialized
INFO - 2026-07-04 07:16:49 --> URI Class Initialized
INFO - 2026-07-04 07:16:49 --> Router Class Initialized
INFO - 2026-07-04 07:16:49 --> Output Class Initialized
INFO - 2026-07-04 07:16:49 --> Security Class Initialized
DEBUG - 2026-07-04 07:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:16:49 --> CSRF cookie sent
INFO - 2026-07-04 07:16:49 --> Input Class Initialized
INFO - 2026-07-04 07:16:49 --> Language Class Initialized
INFO - 2026-07-04 07:16:49 --> Language Class Initialized
INFO - 2026-07-04 07:16:49 --> Config Class Initialized
INFO - 2026-07-04 07:16:49 --> Loader Class Initialized
INFO - 2026-07-04 07:16:49 --> Helper loaded: url_helper
INFO - 2026-07-04 07:16:49 --> Helper loaded: form_helper
INFO - 2026-07-04 07:16:49 --> Helper loaded: html_helper
INFO - 2026-07-04 07:16:49 --> Helper loaded: file_helper
INFO - 2026-07-04 07:16:49 --> Helper loaded: email_helper
INFO - 2026-07-04 07:16:49 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:16:49 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:16:49 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:16:49 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:16:49 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:16:49 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:16:49 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:16:49 --> Database Driver Class Initialized
INFO - 2026-07-04 07:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:16:51 --> Upload Class Initialized
DEBUG - 2026-07-04 07:16:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:16:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:16:51 --> Encryption Class Initialized
INFO - 2026-07-04 07:16:51 --> Form Validation Class Initialized
INFO - 2026-07-04 07:16:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:16:51 --> Pagination Class Initialized
INFO - 2026-07-04 07:16:51 --> Email Class Initialized
INFO - 2026-07-04 07:16:51 --> Controller Class Initialized
DEBUG - 2026-07-04 07:16:51 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 07:16:51 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:16:51 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:16:51 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-04 07:16:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-04 07:16:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-04 07:16:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-07-04 07:16:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-04 07:16:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-04 07:16:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-07-04 07:16:52 --> Final output sent to browser
DEBUG - 2026-07-04 07:16:52 --> Total execution time: 2.4817
INFO - 2026-07-04 07:17:05 --> Config Class Initialized
INFO - 2026-07-04 07:17:05 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:17:05 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:17:05 --> Utf8 Class Initialized
INFO - 2026-07-04 07:17:05 --> URI Class Initialized
INFO - 2026-07-04 07:17:05 --> Router Class Initialized
INFO - 2026-07-04 07:17:05 --> Output Class Initialized
INFO - 2026-07-04 07:17:05 --> Security Class Initialized
DEBUG - 2026-07-04 07:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:17:05 --> CSRF cookie sent
INFO - 2026-07-04 07:17:05 --> CSRF token verified
INFO - 2026-07-04 07:17:05 --> Input Class Initialized
INFO - 2026-07-04 07:17:05 --> Language Class Initialized
INFO - 2026-07-04 07:17:05 --> Language Class Initialized
INFO - 2026-07-04 07:17:05 --> Config Class Initialized
INFO - 2026-07-04 07:17:05 --> Loader Class Initialized
INFO - 2026-07-04 07:17:05 --> Helper loaded: url_helper
INFO - 2026-07-04 07:17:05 --> Helper loaded: form_helper
INFO - 2026-07-04 07:17:05 --> Helper loaded: html_helper
INFO - 2026-07-04 07:17:05 --> Helper loaded: file_helper
INFO - 2026-07-04 07:17:05 --> Helper loaded: email_helper
INFO - 2026-07-04 07:17:05 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:17:05 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:17:05 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:17:05 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:17:05 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:17:05 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:17:05 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:17:05 --> Database Driver Class Initialized
INFO - 2026-07-04 07:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:17:07 --> Upload Class Initialized
DEBUG - 2026-07-04 07:17:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:17:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:17:07 --> Encryption Class Initialized
INFO - 2026-07-04 07:17:07 --> Form Validation Class Initialized
INFO - 2026-07-04 07:17:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:17:07 --> Pagination Class Initialized
INFO - 2026-07-04 07:17:07 --> Email Class Initialized
INFO - 2026-07-04 07:17:07 --> Controller Class Initialized
DEBUG - 2026-07-04 07:17:07 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 07:17:07 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:17:07 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:17:07 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-04 07:17:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-04 07:17:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-04 07:17:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-07-04 07:17:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-04 07:17:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-04 07:17:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-07-04 07:17:08 --> Final output sent to browser
DEBUG - 2026-07-04 07:17:08 --> Total execution time: 3.5408
INFO - 2026-07-04 07:19:59 --> Config Class Initialized
INFO - 2026-07-04 07:19:59 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:19:59 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:19:59 --> Utf8 Class Initialized
INFO - 2026-07-04 07:19:59 --> URI Class Initialized
INFO - 2026-07-04 07:19:59 --> Router Class Initialized
INFO - 2026-07-04 07:19:59 --> Output Class Initialized
INFO - 2026-07-04 07:19:59 --> Security Class Initialized
DEBUG - 2026-07-04 07:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:19:59 --> CSRF cookie sent
INFO - 2026-07-04 07:19:59 --> Input Class Initialized
INFO - 2026-07-04 07:19:59 --> Language Class Initialized
INFO - 2026-07-04 07:19:59 --> Language Class Initialized
INFO - 2026-07-04 07:19:59 --> Config Class Initialized
INFO - 2026-07-04 07:19:59 --> Loader Class Initialized
INFO - 2026-07-04 07:19:59 --> Helper loaded: url_helper
INFO - 2026-07-04 07:19:59 --> Helper loaded: form_helper
INFO - 2026-07-04 07:19:59 --> Helper loaded: html_helper
INFO - 2026-07-04 07:19:59 --> Helper loaded: file_helper
INFO - 2026-07-04 07:19:59 --> Helper loaded: email_helper
INFO - 2026-07-04 07:19:59 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:19:59 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:19:59 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:19:59 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:19:59 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:19:59 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:19:59 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:19:59 --> Database Driver Class Initialized
INFO - 2026-07-04 07:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:20:01 --> Upload Class Initialized
DEBUG - 2026-07-04 07:20:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:20:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:20:01 --> Encryption Class Initialized
INFO - 2026-07-04 07:20:01 --> Form Validation Class Initialized
INFO - 2026-07-04 07:20:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:20:01 --> Pagination Class Initialized
INFO - 2026-07-04 07:20:01 --> Email Class Initialized
INFO - 2026-07-04 07:20:01 --> Controller Class Initialized
DEBUG - 2026-07-04 07:20:01 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 07:20:01 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:20:01 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:20:01 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-04 07:20:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-04 07:20:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-04 07:20:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-07-04 07:20:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-04 07:20:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-04 07:20:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-07-04 07:20:01 --> Final output sent to browser
DEBUG - 2026-07-04 07:20:01 --> Total execution time: 2.4950
INFO - 2026-07-04 07:20:08 --> Config Class Initialized
INFO - 2026-07-04 07:20:08 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:20:08 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:20:08 --> Utf8 Class Initialized
INFO - 2026-07-04 07:20:08 --> URI Class Initialized
INFO - 2026-07-04 07:20:08 --> Router Class Initialized
INFO - 2026-07-04 07:20:08 --> Output Class Initialized
INFO - 2026-07-04 07:20:08 --> Security Class Initialized
DEBUG - 2026-07-04 07:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:20:08 --> CSRF cookie sent
INFO - 2026-07-04 07:20:08 --> CSRF token verified
INFO - 2026-07-04 07:20:08 --> Input Class Initialized
INFO - 2026-07-04 07:20:08 --> Language Class Initialized
INFO - 2026-07-04 07:20:08 --> Language Class Initialized
INFO - 2026-07-04 07:20:08 --> Config Class Initialized
INFO - 2026-07-04 07:20:08 --> Loader Class Initialized
INFO - 2026-07-04 07:20:08 --> Helper loaded: url_helper
INFO - 2026-07-04 07:20:08 --> Helper loaded: form_helper
INFO - 2026-07-04 07:20:08 --> Helper loaded: html_helper
INFO - 2026-07-04 07:20:08 --> Helper loaded: file_helper
INFO - 2026-07-04 07:20:08 --> Helper loaded: email_helper
INFO - 2026-07-04 07:20:08 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:20:08 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:20:08 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:20:08 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:20:08 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:20:08 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:20:08 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:20:08 --> Database Driver Class Initialized
INFO - 2026-07-04 07:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:20:10 --> Upload Class Initialized
DEBUG - 2026-07-04 07:20:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:20:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:20:10 --> Encryption Class Initialized
INFO - 2026-07-04 07:20:10 --> Form Validation Class Initialized
INFO - 2026-07-04 07:20:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:20:10 --> Pagination Class Initialized
INFO - 2026-07-04 07:20:10 --> Email Class Initialized
INFO - 2026-07-04 07:20:10 --> Controller Class Initialized
DEBUG - 2026-07-04 07:20:10 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 07:20:10 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:20:10 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:20:11 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-04 07:20:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-04 07:20:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-04 07:20:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-07-04 07:20:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-04 07:20:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-04 07:20:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-07-04 07:20:13 --> Final output sent to browser
DEBUG - 2026-07-04 07:20:13 --> Total execution time: 4.1829
INFO - 2026-07-04 07:40:11 --> Config Class Initialized
INFO - 2026-07-04 07:40:11 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:40:11 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:40:11 --> Utf8 Class Initialized
INFO - 2026-07-04 07:40:11 --> URI Class Initialized
INFO - 2026-07-04 07:40:11 --> Router Class Initialized
INFO - 2026-07-04 07:40:11 --> Output Class Initialized
INFO - 2026-07-04 07:40:11 --> Security Class Initialized
DEBUG - 2026-07-04 07:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:40:11 --> CSRF cookie sent
INFO - 2026-07-04 07:40:11 --> CSRF token verified
INFO - 2026-07-04 07:40:11 --> Input Class Initialized
INFO - 2026-07-04 07:40:11 --> Language Class Initialized
INFO - 2026-07-04 07:40:11 --> Language Class Initialized
INFO - 2026-07-04 07:40:11 --> Config Class Initialized
INFO - 2026-07-04 07:40:11 --> Loader Class Initialized
INFO - 2026-07-04 07:40:11 --> Helper loaded: url_helper
INFO - 2026-07-04 07:40:11 --> Helper loaded: form_helper
INFO - 2026-07-04 07:40:11 --> Helper loaded: html_helper
INFO - 2026-07-04 07:40:11 --> Helper loaded: file_helper
INFO - 2026-07-04 07:40:11 --> Helper loaded: email_helper
INFO - 2026-07-04 07:40:11 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:40:11 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:40:11 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:40:11 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:40:11 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:40:11 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:40:11 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:40:11 --> Database Driver Class Initialized
INFO - 2026-07-04 07:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:40:13 --> Upload Class Initialized
DEBUG - 2026-07-04 07:40:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:40:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:40:13 --> Encryption Class Initialized
INFO - 2026-07-04 07:40:13 --> Form Validation Class Initialized
INFO - 2026-07-04 07:40:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:40:13 --> Pagination Class Initialized
INFO - 2026-07-04 07:40:13 --> Email Class Initialized
INFO - 2026-07-04 07:40:13 --> Controller Class Initialized
DEBUG - 2026-07-04 07:40:13 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 07:40:13 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:40:13 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:40:13 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-04 07:40:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-04 07:40:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-04 07:40:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-07-04 07:40:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-04 07:40:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-04 07:40:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-07-04 07:40:14 --> Final output sent to browser
DEBUG - 2026-07-04 07:40:14 --> Total execution time: 3.0750
INFO - 2026-07-04 07:50:02 --> Config Class Initialized
INFO - 2026-07-04 07:50:02 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:50:02 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:50:02 --> Utf8 Class Initialized
INFO - 2026-07-04 07:50:02 --> URI Class Initialized
INFO - 2026-07-04 07:50:02 --> Router Class Initialized
INFO - 2026-07-04 07:50:02 --> Output Class Initialized
INFO - 2026-07-04 07:50:02 --> Security Class Initialized
DEBUG - 2026-07-04 07:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:50:02 --> CSRF cookie sent
INFO - 2026-07-04 07:50:02 --> CSRF token verified
INFO - 2026-07-04 07:50:02 --> Input Class Initialized
INFO - 2026-07-04 07:50:02 --> Language Class Initialized
INFO - 2026-07-04 07:50:02 --> Language Class Initialized
INFO - 2026-07-04 07:50:02 --> Config Class Initialized
INFO - 2026-07-04 07:50:02 --> Loader Class Initialized
INFO - 2026-07-04 07:50:02 --> Helper loaded: url_helper
INFO - 2026-07-04 07:50:02 --> Helper loaded: form_helper
INFO - 2026-07-04 07:50:02 --> Helper loaded: html_helper
INFO - 2026-07-04 07:50:02 --> Helper loaded: file_helper
INFO - 2026-07-04 07:50:02 --> Helper loaded: email_helper
INFO - 2026-07-04 07:50:02 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:50:02 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:50:02 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:50:02 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:50:02 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:50:02 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:50:02 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:50:02 --> Database Driver Class Initialized
INFO - 2026-07-04 07:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:50:04 --> Upload Class Initialized
DEBUG - 2026-07-04 07:50:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:50:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:50:04 --> Encryption Class Initialized
INFO - 2026-07-04 07:50:04 --> Form Validation Class Initialized
INFO - 2026-07-04 07:50:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:50:04 --> Pagination Class Initialized
INFO - 2026-07-04 07:50:04 --> Email Class Initialized
INFO - 2026-07-04 07:50:04 --> Controller Class Initialized
DEBUG - 2026-07-04 07:50:04 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 07:50:04 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:50:04 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:50:04 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-04 07:50:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-04 07:50:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-04 07:50:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-07-04 07:50:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-04 07:50:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-04 07:50:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-07-04 07:50:05 --> Final output sent to browser
DEBUG - 2026-07-04 07:50:05 --> Total execution time: 3.6936
INFO - 2026-07-04 07:50:29 --> Config Class Initialized
INFO - 2026-07-04 07:50:29 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:50:29 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:50:29 --> Utf8 Class Initialized
INFO - 2026-07-04 07:50:29 --> URI Class Initialized
INFO - 2026-07-04 07:50:29 --> Router Class Initialized
INFO - 2026-07-04 07:50:29 --> Output Class Initialized
INFO - 2026-07-04 07:50:29 --> Security Class Initialized
DEBUG - 2026-07-04 07:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:50:29 --> CSRF cookie sent
INFO - 2026-07-04 07:50:29 --> CSRF token verified
INFO - 2026-07-04 07:50:29 --> Input Class Initialized
INFO - 2026-07-04 07:50:29 --> Language Class Initialized
INFO - 2026-07-04 07:50:29 --> Language Class Initialized
INFO - 2026-07-04 07:50:29 --> Config Class Initialized
INFO - 2026-07-04 07:50:29 --> Loader Class Initialized
INFO - 2026-07-04 07:50:29 --> Helper loaded: url_helper
INFO - 2026-07-04 07:50:29 --> Helper loaded: form_helper
INFO - 2026-07-04 07:50:29 --> Helper loaded: html_helper
INFO - 2026-07-04 07:50:29 --> Helper loaded: file_helper
INFO - 2026-07-04 07:50:29 --> Helper loaded: email_helper
INFO - 2026-07-04 07:50:29 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:50:29 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:50:29 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:50:29 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:50:29 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:50:29 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:50:29 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:50:29 --> Database Driver Class Initialized
INFO - 2026-07-04 07:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:50:30 --> Upload Class Initialized
DEBUG - 2026-07-04 07:50:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:50:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:50:30 --> Encryption Class Initialized
INFO - 2026-07-04 07:50:30 --> Form Validation Class Initialized
INFO - 2026-07-04 07:50:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:50:30 --> Pagination Class Initialized
INFO - 2026-07-04 07:50:30 --> Email Class Initialized
INFO - 2026-07-04 07:50:30 --> Controller Class Initialized
DEBUG - 2026-07-04 07:50:30 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 07:50:30 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:50:30 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:50:30 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 07:50:34 --> Config Class Initialized
INFO - 2026-07-04 07:50:34 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:50:34 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:50:34 --> Utf8 Class Initialized
INFO - 2026-07-04 07:50:34 --> URI Class Initialized
INFO - 2026-07-04 07:50:34 --> Router Class Initialized
INFO - 2026-07-04 07:50:34 --> Output Class Initialized
INFO - 2026-07-04 07:50:34 --> Security Class Initialized
DEBUG - 2026-07-04 07:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:50:34 --> CSRF cookie sent
INFO - 2026-07-04 07:50:34 --> Input Class Initialized
INFO - 2026-07-04 07:50:34 --> Language Class Initialized
INFO - 2026-07-04 07:50:34 --> Language Class Initialized
INFO - 2026-07-04 07:50:34 --> Config Class Initialized
INFO - 2026-07-04 07:50:34 --> Loader Class Initialized
INFO - 2026-07-04 07:50:34 --> Helper loaded: url_helper
INFO - 2026-07-04 07:50:34 --> Helper loaded: form_helper
INFO - 2026-07-04 07:50:34 --> Helper loaded: html_helper
INFO - 2026-07-04 07:50:34 --> Helper loaded: file_helper
INFO - 2026-07-04 07:50:34 --> Helper loaded: email_helper
INFO - 2026-07-04 07:50:34 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:50:34 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:50:34 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:50:34 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:50:34 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:50:34 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:50:34 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:50:34 --> Database Driver Class Initialized
INFO - 2026-07-04 07:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:50:36 --> Upload Class Initialized
DEBUG - 2026-07-04 07:50:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:50:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:50:36 --> Encryption Class Initialized
INFO - 2026-07-04 07:50:36 --> Form Validation Class Initialized
INFO - 2026-07-04 07:50:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:50:36 --> Pagination Class Initialized
INFO - 2026-07-04 07:50:36 --> Email Class Initialized
INFO - 2026-07-04 07:50:36 --> Controller Class Initialized
DEBUG - 2026-07-04 07:50:36 --> Dashboard MX_Controller Initialized
INFO - 2026-07-04 07:50:36 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:50:36 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:50:36 --> Model "Dashboard_model" initialized
DEBUG - 2026-07-04 07:50:36 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-04 07:50:36 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-04 07:50:36 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-04 07:50:36 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-04 07:50:36 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-04 07:50:36 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/dashboard_index.php
INFO - 2026-07-04 07:50:36 --> Final output sent to browser
DEBUG - 2026-07-04 07:50:36 --> Total execution time: 1.8648
INFO - 2026-07-04 07:50:36 --> Config Class Initialized
INFO - 2026-07-04 07:50:36 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:50:36 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:50:36 --> Utf8 Class Initialized
INFO - 2026-07-04 07:50:36 --> Config Class Initialized
INFO - 2026-07-04 07:50:36 --> Hooks Class Initialized
INFO - 2026-07-04 07:50:36 --> URI Class Initialized
INFO - 2026-07-04 07:50:36 --> Config Class Initialized
INFO - 2026-07-04 07:50:36 --> Hooks Class Initialized
INFO - 2026-07-04 07:50:36 --> Config Class Initialized
INFO - 2026-07-04 07:50:36 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:50:36 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:50:36 --> Utf8 Class Initialized
DEBUG - 2026-07-04 07:50:36 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:50:36 --> Utf8 Class Initialized
INFO - 2026-07-04 07:50:36 --> URI Class Initialized
INFO - 2026-07-04 07:50:36 --> Router Class Initialized
DEBUG - 2026-07-04 07:50:36 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:50:36 --> Utf8 Class Initialized
INFO - 2026-07-04 07:50:36 --> URI Class Initialized
INFO - 2026-07-04 07:50:36 --> Config Class Initialized
INFO - 2026-07-04 07:50:36 --> Hooks Class Initialized
INFO - 2026-07-04 07:50:36 --> URI Class Initialized
INFO - 2026-07-04 07:50:36 --> Output Class Initialized
INFO - 2026-07-04 07:50:36 --> Router Class Initialized
DEBUG - 2026-07-04 07:50:36 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:50:36 --> Utf8 Class Initialized
INFO - 2026-07-04 07:50:36 --> Router Class Initialized
INFO - 2026-07-04 07:50:36 --> Security Class Initialized
INFO - 2026-07-04 07:50:36 --> URI Class Initialized
INFO - 2026-07-04 07:50:36 --> Router Class Initialized
INFO - 2026-07-04 07:50:36 --> Output Class Initialized
INFO - 2026-07-04 07:50:36 --> Config Class Initialized
DEBUG - 2026-07-04 07:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:50:36 --> Input Class Initialized
INFO - 2026-07-04 07:50:36 --> Language Class Initialized
INFO - 2026-07-04 07:50:36 --> Output Class Initialized
INFO - 2026-07-04 07:50:36 --> Router Class Initialized
INFO - 2026-07-04 07:50:36 --> Security Class Initialized
INFO - 2026-07-04 07:50:36 --> Language Class Initialized
INFO - 2026-07-04 07:50:36 --> Config Class Initialized
INFO - 2026-07-04 07:50:36 --> Security Class Initialized
INFO - 2026-07-04 07:50:36 --> Output Class Initialized
DEBUG - 2026-07-04 07:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:50:36 --> Output Class Initialized
INFO - 2026-07-04 07:50:36 --> Input Class Initialized
INFO - 2026-07-04 07:50:36 --> Hooks Class Initialized
INFO - 2026-07-04 07:50:36 --> Language Class Initialized
INFO - 2026-07-04 07:50:36 --> Security Class Initialized
INFO - 2026-07-04 07:50:36 --> Security Class Initialized
INFO - 2026-07-04 07:50:36 --> Language Class Initialized
INFO - 2026-07-04 07:50:36 --> Config Class Initialized
DEBUG - 2026-07-04 07:50:36 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:50:36 --> Loader Class Initialized
INFO - 2026-07-04 07:50:36 --> Utf8 Class Initialized
DEBUG - 2026-07-04 07:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:50:36 --> Input Class Initialized
INFO - 2026-07-04 07:50:36 --> Language Class Initialized
DEBUG - 2026-07-04 07:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:50:36 --> URI Class Initialized
INFO - 2026-07-04 07:50:36 --> Input Class Initialized
INFO - 2026-07-04 07:50:36 --> Language Class Initialized
INFO - 2026-07-04 07:50:36 --> Language Class Initialized
INFO - 2026-07-04 07:50:36 --> Config Class Initialized
DEBUG - 2026-07-04 07:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:50:36 --> Router Class Initialized
INFO - 2026-07-04 07:50:36 --> Input Class Initialized
INFO - 2026-07-04 07:50:36 --> Helper loaded: url_helper
INFO - 2026-07-04 07:50:36 --> Language Class Initialized
INFO - 2026-07-04 07:50:36 --> Language Class Initialized
INFO - 2026-07-04 07:50:36 --> Language Class Initialized
INFO - 2026-07-04 07:50:36 --> Config Class Initialized
INFO - 2026-07-04 07:50:36 --> Output Class Initialized
INFO - 2026-07-04 07:50:36 --> Helper loaded: form_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: html_helper
INFO - 2026-07-04 07:50:36 --> Loader Class Initialized
INFO - 2026-07-04 07:50:36 --> Helper loaded: file_helper
INFO - 2026-07-04 07:50:36 --> Security Class Initialized
INFO - 2026-07-04 07:50:36 --> Helper loaded: email_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: url_helper
DEBUG - 2026-07-04 07:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:50:36 --> Input Class Initialized
INFO - 2026-07-04 07:50:36 --> Loader Class Initialized
INFO - 2026-07-04 07:50:36 --> Language Class Initialized
INFO - 2026-07-04 07:50:36 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: form_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: url_helper
INFO - 2026-07-04 07:50:36 --> Language Class Initialized
INFO - 2026-07-04 07:50:36 --> Config Class Initialized
INFO - 2026-07-04 07:50:36 --> Helper loaded: html_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: file_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: email_helper
INFO - 2026-07-04 07:50:36 --> Loader Class Initialized
INFO - 2026-07-04 07:50:36 --> Helper loaded: url_helper
INFO - 2026-07-04 07:50:36 --> Loader Class Initialized
INFO - 2026-07-04 07:50:36 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: form_helper
INFO - 2026-07-04 07:50:36 --> Config Class Initialized
INFO - 2026-07-04 07:50:36 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: url_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: form_helper
INFO - 2026-07-04 07:50:36 --> Loader Class Initialized
INFO - 2026-07-04 07:50:36 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: html_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: file_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: url_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: email_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: form_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: html_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: form_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: html_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: file_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: email_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: file_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: email_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: html_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: file_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: email_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:50:36 --> Database Driver Class Initialized
INFO - 2026-07-04 07:50:36 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:50:36 --> Database Driver Class Initialized
INFO - 2026-07-04 07:50:36 --> Database Driver Class Initialized
INFO - 2026-07-04 07:50:36 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:50:36 --> Database Driver Class Initialized
INFO - 2026-07-04 07:50:36 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:50:36 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:50:36 --> Database Driver Class Initialized
INFO - 2026-07-04 07:50:36 --> Database Driver Class Initialized
INFO - 2026-07-04 07:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:50:38 --> Upload Class Initialized
DEBUG - 2026-07-04 07:50:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:50:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:50:38 --> Encryption Class Initialized
INFO - 2026-07-04 07:50:38 --> Form Validation Class Initialized
INFO - 2026-07-04 07:50:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:50:38 --> Pagination Class Initialized
INFO - 2026-07-04 07:50:38 --> Email Class Initialized
INFO - 2026-07-04 07:50:38 --> Controller Class Initialized
DEBUG - 2026-07-04 07:50:38 --> Dashboard MX_Controller Initialized
INFO - 2026-07-04 07:50:38 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:50:38 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:50:38 --> Model "Dashboard_model" initialized
INFO - 2026-07-04 07:50:38 --> Final output sent to browser
DEBUG - 2026-07-04 07:50:38 --> Total execution time: 2.1862
INFO - 2026-07-04 07:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:50:38 --> Upload Class Initialized
DEBUG - 2026-07-04 07:50:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:50:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:50:38 --> Encryption Class Initialized
INFO - 2026-07-04 07:50:38 --> Form Validation Class Initialized
INFO - 2026-07-04 07:50:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:50:38 --> Pagination Class Initialized
INFO - 2026-07-04 07:50:38 --> Email Class Initialized
INFO - 2026-07-04 07:50:38 --> Controller Class Initialized
DEBUG - 2026-07-04 07:50:38 --> Dashboard MX_Controller Initialized
INFO - 2026-07-04 07:50:38 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:50:38 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:50:39 --> Model "Dashboard_model" initialized
INFO - 2026-07-04 07:50:39 --> Final output sent to browser
DEBUG - 2026-07-04 07:50:39 --> Total execution time: 2.8044
INFO - 2026-07-04 07:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:50:39 --> Upload Class Initialized
DEBUG - 2026-07-04 07:50:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:50:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:50:39 --> Encryption Class Initialized
INFO - 2026-07-04 07:50:39 --> Form Validation Class Initialized
INFO - 2026-07-04 07:50:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:50:39 --> Pagination Class Initialized
INFO - 2026-07-04 07:50:39 --> Email Class Initialized
INFO - 2026-07-04 07:50:39 --> Controller Class Initialized
DEBUG - 2026-07-04 07:50:39 --> Ticket MX_Controller Initialized
INFO - 2026-07-04 07:50:39 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:50:39 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:50:39 --> Model "Support_model" initialized
INFO - 2026-07-04 07:50:39 --> Model "Common_model" initialized
INFO - 2026-07-04 07:50:40 --> Final output sent to browser
DEBUG - 2026-07-04 07:50:40 --> Total execution time: 3.4327
INFO - 2026-07-04 07:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:50:40 --> Upload Class Initialized
DEBUG - 2026-07-04 07:50:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:50:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:50:40 --> Encryption Class Initialized
INFO - 2026-07-04 07:50:40 --> Form Validation Class Initialized
INFO - 2026-07-04 07:50:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:50:40 --> Pagination Class Initialized
INFO - 2026-07-04 07:50:40 --> Email Class Initialized
INFO - 2026-07-04 07:50:40 --> Controller Class Initialized
DEBUG - 2026-07-04 07:50:40 --> Invoice MX_Controller Initialized
INFO - 2026-07-04 07:50:40 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:50:40 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:50:40 --> Model "Billing_model" initialized
INFO - 2026-07-04 07:50:40 --> Model "Common_model" initialized
INFO - 2026-07-04 07:50:40 --> Model "Invoice_model" initialized
INFO - 2026-07-04 07:50:40 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 07:50:40 --> Final output sent to browser
DEBUG - 2026-07-04 07:50:40 --> Total execution time: 4.0621
INFO - 2026-07-04 07:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:50:40 --> Upload Class Initialized
DEBUG - 2026-07-04 07:50:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:50:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:50:40 --> Encryption Class Initialized
INFO - 2026-07-04 07:50:40 --> Form Validation Class Initialized
INFO - 2026-07-04 07:50:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:50:40 --> Pagination Class Initialized
INFO - 2026-07-04 07:50:40 --> Email Class Initialized
INFO - 2026-07-04 07:50:40 --> Controller Class Initialized
DEBUG - 2026-07-04 07:50:40 --> Dashboard MX_Controller Initialized
INFO - 2026-07-04 07:50:40 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:50:40 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:50:41 --> Model "Dashboard_model" initialized
INFO - 2026-07-04 07:50:41 --> Final output sent to browser
DEBUG - 2026-07-04 07:50:41 --> Total execution time: 4.6937
INFO - 2026-07-04 07:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:50:41 --> Upload Class Initialized
DEBUG - 2026-07-04 07:50:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:50:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:50:41 --> Encryption Class Initialized
INFO - 2026-07-04 07:50:41 --> Form Validation Class Initialized
INFO - 2026-07-04 07:50:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:50:41 --> Pagination Class Initialized
INFO - 2026-07-04 07:50:41 --> Email Class Initialized
INFO - 2026-07-04 07:50:41 --> Controller Class Initialized
DEBUG - 2026-07-04 07:50:41 --> Order MX_Controller Initialized
INFO - 2026-07-04 07:50:41 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:50:41 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:50:41 --> Model "Order_model" initialized
INFO - 2026-07-04 07:50:41 --> Model "Common_model" initialized
INFO - 2026-07-04 07:50:41 --> Model "Currency_model" initialized
INFO - 2026-07-04 07:50:41 --> Final output sent to browser
DEBUG - 2026-07-04 07:50:41 --> Total execution time: 5.3193
INFO - 2026-07-04 07:57:39 --> Config Class Initialized
INFO - 2026-07-04 07:57:39 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:57:39 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:57:39 --> Utf8 Class Initialized
INFO - 2026-07-04 07:57:39 --> URI Class Initialized
INFO - 2026-07-04 07:57:39 --> Router Class Initialized
INFO - 2026-07-04 07:57:39 --> Output Class Initialized
INFO - 2026-07-04 07:57:39 --> Security Class Initialized
DEBUG - 2026-07-04 07:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:57:39 --> CSRF cookie sent
INFO - 2026-07-04 07:57:39 --> Input Class Initialized
INFO - 2026-07-04 07:57:39 --> Language Class Initialized
INFO - 2026-07-04 07:57:39 --> Language Class Initialized
INFO - 2026-07-04 07:57:39 --> Config Class Initialized
INFO - 2026-07-04 07:57:39 --> Loader Class Initialized
INFO - 2026-07-04 07:57:39 --> Helper loaded: url_helper
INFO - 2026-07-04 07:57:39 --> Helper loaded: form_helper
INFO - 2026-07-04 07:57:39 --> Helper loaded: html_helper
INFO - 2026-07-04 07:57:39 --> Helper loaded: file_helper
INFO - 2026-07-04 07:57:39 --> Helper loaded: email_helper
INFO - 2026-07-04 07:57:39 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:57:39 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:57:39 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:57:39 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:57:39 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:57:39 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:57:39 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:57:39 --> Database Driver Class Initialized
INFO - 2026-07-04 07:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:57:41 --> Upload Class Initialized
DEBUG - 2026-07-04 07:57:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:57:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:57:41 --> Encryption Class Initialized
INFO - 2026-07-04 07:57:41 --> Form Validation Class Initialized
INFO - 2026-07-04 07:57:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:57:41 --> Pagination Class Initialized
INFO - 2026-07-04 07:57:41 --> Email Class Initialized
INFO - 2026-07-04 07:57:41 --> Controller Class Initialized
DEBUG - 2026-07-04 07:57:41 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 07:57:41 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:57:41 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:57:41 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 07:57:41 --> Config Class Initialized
INFO - 2026-07-04 07:57:41 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:57:41 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:57:41 --> Utf8 Class Initialized
INFO - 2026-07-04 07:57:41 --> URI Class Initialized
INFO - 2026-07-04 07:57:41 --> Router Class Initialized
INFO - 2026-07-04 07:57:41 --> Output Class Initialized
INFO - 2026-07-04 07:57:41 --> Security Class Initialized
DEBUG - 2026-07-04 07:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:57:41 --> CSRF cookie sent
INFO - 2026-07-04 07:57:41 --> Input Class Initialized
INFO - 2026-07-04 07:57:41 --> Language Class Initialized
INFO - 2026-07-04 07:57:41 --> Language Class Initialized
INFO - 2026-07-04 07:57:41 --> Config Class Initialized
INFO - 2026-07-04 07:57:41 --> Loader Class Initialized
INFO - 2026-07-04 07:57:41 --> Helper loaded: url_helper
INFO - 2026-07-04 07:57:41 --> Helper loaded: form_helper
INFO - 2026-07-04 07:57:41 --> Helper loaded: html_helper
INFO - 2026-07-04 07:57:41 --> Helper loaded: file_helper
INFO - 2026-07-04 07:57:41 --> Helper loaded: email_helper
INFO - 2026-07-04 07:57:41 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:57:41 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:57:41 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:57:41 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:57:41 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:57:41 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:57:41 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:57:41 --> Database Driver Class Initialized
INFO - 2026-07-04 07:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:57:43 --> Upload Class Initialized
DEBUG - 2026-07-04 07:57:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:57:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:57:43 --> Encryption Class Initialized
INFO - 2026-07-04 07:57:43 --> Form Validation Class Initialized
INFO - 2026-07-04 07:57:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:57:43 --> Pagination Class Initialized
INFO - 2026-07-04 07:57:43 --> Email Class Initialized
INFO - 2026-07-04 07:57:43 --> Controller Class Initialized
DEBUG - 2026-07-04 07:57:43 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 07:57:43 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:57:43 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 07:57:43 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-04 07:57:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-04 07:57:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-04 07:57:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-07-04 07:57:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-04 07:57:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-04 07:57:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-07-04 07:57:43 --> Final output sent to browser
DEBUG - 2026-07-04 07:57:43 --> Total execution time: 1.8738
INFO - 2026-07-04 07:57:48 --> Config Class Initialized
INFO - 2026-07-04 07:57:48 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:57:48 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:57:48 --> Utf8 Class Initialized
INFO - 2026-07-04 07:57:48 --> URI Class Initialized
DEBUG - 2026-07-04 07:57:48 --> No URI present. Default controller set.
INFO - 2026-07-04 07:57:48 --> Router Class Initialized
INFO - 2026-07-04 07:57:48 --> Output Class Initialized
INFO - 2026-07-04 07:57:48 --> Security Class Initialized
DEBUG - 2026-07-04 07:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:57:48 --> CSRF cookie sent
INFO - 2026-07-04 07:57:48 --> Input Class Initialized
INFO - 2026-07-04 07:57:48 --> Language Class Initialized
INFO - 2026-07-04 07:57:48 --> Language Class Initialized
INFO - 2026-07-04 07:57:48 --> Config Class Initialized
INFO - 2026-07-04 07:57:48 --> Loader Class Initialized
INFO - 2026-07-04 07:57:48 --> Helper loaded: url_helper
INFO - 2026-07-04 07:57:48 --> Helper loaded: form_helper
INFO - 2026-07-04 07:57:48 --> Helper loaded: html_helper
INFO - 2026-07-04 07:57:48 --> Helper loaded: file_helper
INFO - 2026-07-04 07:57:48 --> Helper loaded: email_helper
INFO - 2026-07-04 07:57:48 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:57:48 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:57:48 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:57:48 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:57:48 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:57:48 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:57:48 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:57:48 --> Database Driver Class Initialized
INFO - 2026-07-04 07:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:57:50 --> Upload Class Initialized
DEBUG - 2026-07-04 07:57:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:57:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:57:50 --> Encryption Class Initialized
INFO - 2026-07-04 07:57:50 --> Form Validation Class Initialized
INFO - 2026-07-04 07:57:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:57:50 --> Pagination Class Initialized
INFO - 2026-07-04 07:57:50 --> Email Class Initialized
INFO - 2026-07-04 07:57:50 --> Controller Class Initialized
DEBUG - 2026-07-04 07:57:50 --> Auth MX_Controller Initialized
INFO - 2026-07-04 07:57:50 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:57:50 --> Model "Auth_model" initialized
INFO - 2026-07-04 07:57:50 --> Model "Cart_model" initialized
INFO - 2026-07-04 07:57:50 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 07:57:50 --> Config Class Initialized
INFO - 2026-07-04 07:57:50 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:57:50 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:57:50 --> Utf8 Class Initialized
INFO - 2026-07-04 07:57:50 --> URI Class Initialized
INFO - 2026-07-04 07:57:50 --> Router Class Initialized
INFO - 2026-07-04 07:57:50 --> Output Class Initialized
INFO - 2026-07-04 07:57:50 --> Security Class Initialized
DEBUG - 2026-07-04 07:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:57:50 --> CSRF cookie sent
INFO - 2026-07-04 07:57:50 --> Input Class Initialized
INFO - 2026-07-04 07:57:50 --> Language Class Initialized
INFO - 2026-07-04 07:57:50 --> Language Class Initialized
INFO - 2026-07-04 07:57:50 --> Config Class Initialized
INFO - 2026-07-04 07:57:50 --> Loader Class Initialized
INFO - 2026-07-04 07:57:50 --> Helper loaded: url_helper
INFO - 2026-07-04 07:57:50 --> Helper loaded: form_helper
INFO - 2026-07-04 07:57:50 --> Helper loaded: html_helper
INFO - 2026-07-04 07:57:50 --> Helper loaded: file_helper
INFO - 2026-07-04 07:57:50 --> Helper loaded: email_helper
INFO - 2026-07-04 07:57:50 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:57:50 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:57:50 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:57:50 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:57:50 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:57:50 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:57:50 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:57:50 --> Database Driver Class Initialized
INFO - 2026-07-04 07:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:57:52 --> Upload Class Initialized
DEBUG - 2026-07-04 07:57:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:57:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:57:52 --> Encryption Class Initialized
INFO - 2026-07-04 07:57:52 --> Form Validation Class Initialized
INFO - 2026-07-04 07:57:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:57:52 --> Pagination Class Initialized
INFO - 2026-07-04 07:57:52 --> Email Class Initialized
INFO - 2026-07-04 07:57:52 --> Controller Class Initialized
DEBUG - 2026-07-04 07:57:52 --> Auth MX_Controller Initialized
INFO - 2026-07-04 07:57:52 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:57:52 --> Model "Auth_model" initialized
INFO - 2026-07-04 07:57:52 --> Model "Cart_model" initialized
INFO - 2026-07-04 07:57:52 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-04 07:57:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-04 07:57:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-04 07:57:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-04 07:57:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-07-04 07:57:53 --> Final output sent to browser
DEBUG - 2026-07-04 07:57:53 --> Total execution time: 2.4773
INFO - 2026-07-04 07:57:53 --> Config Class Initialized
INFO - 2026-07-04 07:57:53 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:57:53 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:57:53 --> Utf8 Class Initialized
INFO - 2026-07-04 07:57:53 --> URI Class Initialized
INFO - 2026-07-04 07:57:53 --> Router Class Initialized
INFO - 2026-07-04 07:57:53 --> Output Class Initialized
INFO - 2026-07-04 07:57:53 --> Security Class Initialized
DEBUG - 2026-07-04 07:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:57:53 --> CSRF cookie sent
INFO - 2026-07-04 07:57:53 --> Input Class Initialized
INFO - 2026-07-04 07:57:53 --> Language Class Initialized
INFO - 2026-07-04 07:57:53 --> Language Class Initialized
INFO - 2026-07-04 07:57:53 --> Config Class Initialized
INFO - 2026-07-04 07:57:53 --> Loader Class Initialized
INFO - 2026-07-04 07:57:53 --> Helper loaded: url_helper
INFO - 2026-07-04 07:57:53 --> Helper loaded: form_helper
INFO - 2026-07-04 07:57:53 --> Helper loaded: html_helper
INFO - 2026-07-04 07:57:53 --> Helper loaded: file_helper
INFO - 2026-07-04 07:57:53 --> Helper loaded: email_helper
INFO - 2026-07-04 07:57:53 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:57:53 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:57:53 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:57:53 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:57:53 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:57:53 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:57:53 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:57:53 --> Database Driver Class Initialized
INFO - 2026-07-04 07:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:57:55 --> Upload Class Initialized
DEBUG - 2026-07-04 07:57:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:57:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:57:55 --> Encryption Class Initialized
INFO - 2026-07-04 07:57:55 --> Form Validation Class Initialized
INFO - 2026-07-04 07:57:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:57:55 --> Pagination Class Initialized
INFO - 2026-07-04 07:57:55 --> Email Class Initialized
INFO - 2026-07-04 07:57:55 --> Controller Class Initialized
DEBUG - 2026-07-04 07:57:55 --> Cart MX_Controller Initialized
INFO - 2026-07-04 07:57:55 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:57:55 --> Model "Auth_model" initialized
INFO - 2026-07-04 07:57:55 --> Model "Cart_model" initialized
INFO - 2026-07-04 07:57:55 --> Model "Common_model" initialized
INFO - 2026-07-04 07:57:55 --> Model "Order_model" initialized
INFO - 2026-07-04 07:57:55 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 07:57:55 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-04 07:57:55 --> Model "Promocode_model" initialized
DEBUG - 2026-07-04 07:57:55 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-04 07:57:55 --> Model "Plan_model" initialized
INFO - 2026-07-04 07:57:55 --> Model "Orderlicense_model" initialized
INFO - 2026-07-04 07:57:55 --> Final output sent to browser
DEBUG - 2026-07-04 07:57:55 --> Total execution time: 2.7182
INFO - 2026-07-04 07:58:05 --> Config Class Initialized
INFO - 2026-07-04 07:58:05 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:58:05 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:58:05 --> Utf8 Class Initialized
INFO - 2026-07-04 07:58:05 --> URI Class Initialized
INFO - 2026-07-04 07:58:05 --> Router Class Initialized
INFO - 2026-07-04 07:58:05 --> Output Class Initialized
INFO - 2026-07-04 07:58:05 --> Security Class Initialized
DEBUG - 2026-07-04 07:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:58:05 --> CSRF cookie sent
INFO - 2026-07-04 07:58:05 --> CSRF token verified
INFO - 2026-07-04 07:58:05 --> Input Class Initialized
INFO - 2026-07-04 07:58:05 --> Language Class Initialized
INFO - 2026-07-04 07:58:05 --> Language Class Initialized
INFO - 2026-07-04 07:58:05 --> Config Class Initialized
INFO - 2026-07-04 07:58:05 --> Loader Class Initialized
INFO - 2026-07-04 07:58:05 --> Helper loaded: url_helper
INFO - 2026-07-04 07:58:05 --> Helper loaded: form_helper
INFO - 2026-07-04 07:58:05 --> Helper loaded: html_helper
INFO - 2026-07-04 07:58:05 --> Helper loaded: file_helper
INFO - 2026-07-04 07:58:05 --> Helper loaded: email_helper
INFO - 2026-07-04 07:58:05 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:58:05 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:58:05 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:58:05 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:58:05 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:58:05 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:58:05 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:58:05 --> Database Driver Class Initialized
INFO - 2026-07-04 07:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:58:07 --> Upload Class Initialized
DEBUG - 2026-07-04 07:58:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:58:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:58:07 --> Encryption Class Initialized
INFO - 2026-07-04 07:58:07 --> Form Validation Class Initialized
INFO - 2026-07-04 07:58:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:58:07 --> Pagination Class Initialized
INFO - 2026-07-04 07:58:07 --> Email Class Initialized
INFO - 2026-07-04 07:58:07 --> Controller Class Initialized
DEBUG - 2026-07-04 07:58:07 --> Auth MX_Controller Initialized
INFO - 2026-07-04 07:58:07 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:58:07 --> Model "Auth_model" initialized
INFO - 2026-07-04 07:58:07 --> Model "Cart_model" initialized
INFO - 2026-07-04 07:58:07 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-04 07:58:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-04 07:58:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-04 07:58:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-04 07:58:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-07-04 07:58:10 --> Final output sent to browser
DEBUG - 2026-07-04 07:58:10 --> Total execution time: 4.9298
INFO - 2026-07-04 07:58:10 --> Config Class Initialized
INFO - 2026-07-04 07:58:10 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:58:10 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:58:10 --> Utf8 Class Initialized
INFO - 2026-07-04 07:58:10 --> URI Class Initialized
INFO - 2026-07-04 07:58:10 --> Router Class Initialized
INFO - 2026-07-04 07:58:10 --> Output Class Initialized
INFO - 2026-07-04 07:58:10 --> Security Class Initialized
DEBUG - 2026-07-04 07:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:58:10 --> CSRF cookie sent
INFO - 2026-07-04 07:58:10 --> Input Class Initialized
INFO - 2026-07-04 07:58:10 --> Language Class Initialized
INFO - 2026-07-04 07:58:10 --> Language Class Initialized
INFO - 2026-07-04 07:58:10 --> Config Class Initialized
INFO - 2026-07-04 07:58:10 --> Loader Class Initialized
INFO - 2026-07-04 07:58:10 --> Helper loaded: url_helper
INFO - 2026-07-04 07:58:10 --> Helper loaded: form_helper
INFO - 2026-07-04 07:58:10 --> Helper loaded: html_helper
INFO - 2026-07-04 07:58:10 --> Helper loaded: file_helper
INFO - 2026-07-04 07:58:10 --> Helper loaded: email_helper
INFO - 2026-07-04 07:58:10 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:58:10 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:58:10 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:58:10 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:58:10 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:58:10 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:58:10 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:58:10 --> Database Driver Class Initialized
INFO - 2026-07-04 07:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:58:12 --> Upload Class Initialized
DEBUG - 2026-07-04 07:58:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:58:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:58:12 --> Encryption Class Initialized
INFO - 2026-07-04 07:58:12 --> Form Validation Class Initialized
INFO - 2026-07-04 07:58:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:58:12 --> Pagination Class Initialized
INFO - 2026-07-04 07:58:12 --> Email Class Initialized
INFO - 2026-07-04 07:58:12 --> Controller Class Initialized
DEBUG - 2026-07-04 07:58:12 --> Cart MX_Controller Initialized
INFO - 2026-07-04 07:58:12 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:58:12 --> Model "Auth_model" initialized
INFO - 2026-07-04 07:58:12 --> Model "Cart_model" initialized
INFO - 2026-07-04 07:58:12 --> Model "Common_model" initialized
INFO - 2026-07-04 07:58:12 --> Model "Order_model" initialized
INFO - 2026-07-04 07:58:12 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 07:58:12 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-04 07:58:12 --> Model "Promocode_model" initialized
DEBUG - 2026-07-04 07:58:12 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-04 07:58:12 --> Model "Plan_model" initialized
INFO - 2026-07-04 07:58:12 --> Model "Orderlicense_model" initialized
INFO - 2026-07-04 07:58:12 --> Final output sent to browser
DEBUG - 2026-07-04 07:58:12 --> Total execution time: 2.2488
INFO - 2026-07-04 07:58:17 --> Config Class Initialized
INFO - 2026-07-04 07:58:17 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:58:17 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:58:17 --> Utf8 Class Initialized
INFO - 2026-07-04 07:58:17 --> URI Class Initialized
INFO - 2026-07-04 07:58:17 --> Router Class Initialized
INFO - 2026-07-04 07:58:17 --> Output Class Initialized
INFO - 2026-07-04 07:58:17 --> Security Class Initialized
DEBUG - 2026-07-04 07:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:58:17 --> CSRF cookie sent
INFO - 2026-07-04 07:58:17 --> CSRF token verified
INFO - 2026-07-04 07:58:17 --> Input Class Initialized
INFO - 2026-07-04 07:58:17 --> Language Class Initialized
INFO - 2026-07-04 07:58:17 --> Language Class Initialized
INFO - 2026-07-04 07:58:17 --> Config Class Initialized
INFO - 2026-07-04 07:58:17 --> Loader Class Initialized
INFO - 2026-07-04 07:58:17 --> Helper loaded: url_helper
INFO - 2026-07-04 07:58:17 --> Helper loaded: form_helper
INFO - 2026-07-04 07:58:17 --> Helper loaded: html_helper
INFO - 2026-07-04 07:58:17 --> Helper loaded: file_helper
INFO - 2026-07-04 07:58:17 --> Helper loaded: email_helper
INFO - 2026-07-04 07:58:17 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:58:17 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:58:17 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:58:17 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:58:17 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:58:17 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:58:17 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:58:17 --> Database Driver Class Initialized
INFO - 2026-07-04 07:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:58:18 --> Upload Class Initialized
DEBUG - 2026-07-04 07:58:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:58:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:58:18 --> Encryption Class Initialized
INFO - 2026-07-04 07:58:18 --> Form Validation Class Initialized
INFO - 2026-07-04 07:58:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:58:18 --> Pagination Class Initialized
INFO - 2026-07-04 07:58:18 --> Email Class Initialized
INFO - 2026-07-04 07:58:18 --> Controller Class Initialized
DEBUG - 2026-07-04 07:58:18 --> Auth MX_Controller Initialized
INFO - 2026-07-04 07:58:18 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:58:18 --> Model "Auth_model" initialized
INFO - 2026-07-04 07:58:18 --> Model "Cart_model" initialized
INFO - 2026-07-04 07:58:18 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 07:58:21 --> Config Class Initialized
INFO - 2026-07-04 07:58:21 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:58:21 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:58:21 --> Utf8 Class Initialized
INFO - 2026-07-04 07:58:21 --> URI Class Initialized
INFO - 2026-07-04 07:58:21 --> Router Class Initialized
INFO - 2026-07-04 07:58:21 --> Output Class Initialized
INFO - 2026-07-04 07:58:21 --> Security Class Initialized
DEBUG - 2026-07-04 07:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:58:21 --> CSRF cookie sent
INFO - 2026-07-04 07:58:21 --> Input Class Initialized
INFO - 2026-07-04 07:58:21 --> Language Class Initialized
INFO - 2026-07-04 07:58:21 --> Language Class Initialized
INFO - 2026-07-04 07:58:21 --> Config Class Initialized
INFO - 2026-07-04 07:58:21 --> Loader Class Initialized
INFO - 2026-07-04 07:58:21 --> Helper loaded: url_helper
INFO - 2026-07-04 07:58:21 --> Helper loaded: form_helper
INFO - 2026-07-04 07:58:21 --> Helper loaded: html_helper
INFO - 2026-07-04 07:58:21 --> Helper loaded: file_helper
INFO - 2026-07-04 07:58:21 --> Helper loaded: email_helper
INFO - 2026-07-04 07:58:21 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:58:21 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:58:21 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:58:21 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:58:21 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:58:21 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:58:21 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:58:21 --> Database Driver Class Initialized
INFO - 2026-07-04 07:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:58:22 --> Upload Class Initialized
DEBUG - 2026-07-04 07:58:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:58:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:58:22 --> Encryption Class Initialized
INFO - 2026-07-04 07:58:22 --> Form Validation Class Initialized
INFO - 2026-07-04 07:58:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:58:22 --> Pagination Class Initialized
INFO - 2026-07-04 07:58:22 --> Email Class Initialized
INFO - 2026-07-04 07:58:22 --> Controller Class Initialized
DEBUG - 2026-07-04 07:58:22 --> Clientarea MX_Controller Initialized
INFO - 2026-07-04 07:58:22 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:58:22 --> Model "Auth_model" initialized
INFO - 2026-07-04 07:58:22 --> Model "Cart_model" initialized
INFO - 2026-07-04 07:58:22 --> Model "Clientarea_model" initialized
INFO - 2026-07-04 07:58:22 --> Model "Billing_model" initialized
INFO - 2026-07-04 07:58:22 --> Model "Common_model" initialized
INFO - 2026-07-04 07:58:22 --> Model "Order_model" initialized
INFO - 2026-07-04 07:58:22 --> Model "Support_model" initialized
INFO - 2026-07-04 07:58:23 --> Model "Subscription_model" initialized
INFO - 2026-07-04 07:58:23 --> Model "Software_model" initialized
DEBUG - 2026-07-04 07:58:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-04 07:58:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-04 07:58:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-04 07:58:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_index.php
INFO - 2026-07-04 07:58:23 --> Final output sent to browser
DEBUG - 2026-07-04 07:58:23 --> Total execution time: 2.8262
INFO - 2026-07-04 07:58:24 --> Config Class Initialized
INFO - 2026-07-04 07:58:24 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:58:24 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:58:24 --> Utf8 Class Initialized
INFO - 2026-07-04 07:58:24 --> URI Class Initialized
INFO - 2026-07-04 07:58:24 --> Router Class Initialized
INFO - 2026-07-04 07:58:24 --> Output Class Initialized
INFO - 2026-07-04 07:58:24 --> Security Class Initialized
DEBUG - 2026-07-04 07:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:58:24 --> CSRF cookie sent
INFO - 2026-07-04 07:58:24 --> Input Class Initialized
INFO - 2026-07-04 07:58:24 --> Language Class Initialized
INFO - 2026-07-04 07:58:24 --> Language Class Initialized
INFO - 2026-07-04 07:58:24 --> Config Class Initialized
INFO - 2026-07-04 07:58:24 --> Loader Class Initialized
INFO - 2026-07-04 07:58:24 --> Helper loaded: url_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: form_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: html_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: file_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: email_helper
INFO - 2026-07-04 07:58:24 --> Config Class Initialized
INFO - 2026-07-04 07:58:24 --> Hooks Class Initialized
INFO - 2026-07-04 07:58:24 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:58:24 --> Config Class Initialized
INFO - 2026-07-04 07:58:24 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:58:24 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:58:24 --> Utf8 Class Initialized
INFO - 2026-07-04 07:58:24 --> URI Class Initialized
DEBUG - 2026-07-04 07:58:24 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:58:24 --> Utf8 Class Initialized
INFO - 2026-07-04 07:58:24 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:58:24 --> Router Class Initialized
INFO - 2026-07-04 07:58:24 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:58:24 --> Output Class Initialized
INFO - 2026-07-04 07:58:24 --> URI Class Initialized
INFO - 2026-07-04 07:58:24 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:58:24 --> Security Class Initialized
INFO - 2026-07-04 07:58:24 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:58:24 --> Config Class Initialized
INFO - 2026-07-04 07:58:24 --> Hooks Class Initialized
INFO - 2026-07-04 07:58:24 --> Router Class Initialized
DEBUG - 2026-07-04 07:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:58:24 --> Input Class Initialized
INFO - 2026-07-04 07:58:24 --> Language Class Initialized
INFO - 2026-07-04 07:58:24 --> Output Class Initialized
INFO - 2026-07-04 07:58:24 --> Language Class Initialized
INFO - 2026-07-04 07:58:24 --> Config Class Initialized
DEBUG - 2026-07-04 07:58:24 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:58:24 --> Utf8 Class Initialized
INFO - 2026-07-04 07:58:24 --> Security Class Initialized
INFO - 2026-07-04 07:58:24 --> URI Class Initialized
DEBUG - 2026-07-04 07:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:58:24 --> Input Class Initialized
INFO - 2026-07-04 07:58:24 --> Language Class Initialized
INFO - 2026-07-04 07:58:24 --> Router Class Initialized
INFO - 2026-07-04 07:58:24 --> Loader Class Initialized
INFO - 2026-07-04 07:58:24 --> Language Class Initialized
INFO - 2026-07-04 07:58:24 --> Config Class Initialized
INFO - 2026-07-04 07:58:24 --> Helper loaded: url_helper
INFO - 2026-07-04 07:58:24 --> Output Class Initialized
INFO - 2026-07-04 07:58:24 --> Helper loaded: form_helper
INFO - 2026-07-04 07:58:24 --> Database Driver Class Initialized
INFO - 2026-07-04 07:58:24 --> Loader Class Initialized
INFO - 2026-07-04 07:58:24 --> Helper loaded: html_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: url_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: file_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: email_helper
INFO - 2026-07-04 07:58:24 --> Security Class Initialized
INFO - 2026-07-04 07:58:24 --> Helper loaded: form_helper
DEBUG - 2026-07-04 07:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:58:24 --> Helper loaded: html_helper
INFO - 2026-07-04 07:58:24 --> Input Class Initialized
INFO - 2026-07-04 07:58:24 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:58:24 --> Language Class Initialized
INFO - 2026-07-04 07:58:24 --> Helper loaded: file_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: email_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:58:24 --> Language Class Initialized
INFO - 2026-07-04 07:58:24 --> Config Class Initialized
INFO - 2026-07-04 07:58:24 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:58:24 --> Loader Class Initialized
INFO - 2026-07-04 07:58:24 --> Helper loaded: url_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: form_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: html_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: file_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: email_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:58:24 --> Database Driver Class Initialized
INFO - 2026-07-04 07:58:24 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:58:24 --> Database Driver Class Initialized
INFO - 2026-07-04 07:58:24 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:58:24 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:58:24 --> Database Driver Class Initialized
INFO - 2026-07-04 07:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:58:25 --> Upload Class Initialized
DEBUG - 2026-07-04 07:58:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:58:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:58:25 --> Encryption Class Initialized
INFO - 2026-07-04 07:58:25 --> Form Validation Class Initialized
INFO - 2026-07-04 07:58:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:58:25 --> Pagination Class Initialized
INFO - 2026-07-04 07:58:25 --> Email Class Initialized
INFO - 2026-07-04 07:58:25 --> Controller Class Initialized
DEBUG - 2026-07-04 07:58:25 --> Cart MX_Controller Initialized
INFO - 2026-07-04 07:58:25 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:58:25 --> Model "Auth_model" initialized
INFO - 2026-07-04 07:58:25 --> Model "Cart_model" initialized
INFO - 2026-07-04 07:58:25 --> Model "Common_model" initialized
INFO - 2026-07-04 07:58:25 --> Model "Order_model" initialized
INFO - 2026-07-04 07:58:25 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 07:58:25 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-04 07:58:25 --> Model "Promocode_model" initialized
DEBUG - 2026-07-04 07:58:25 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-04 07:58:25 --> Model "Plan_model" initialized
INFO - 2026-07-04 07:58:25 --> Model "Orderlicense_model" initialized
INFO - 2026-07-04 07:58:25 --> Final output sent to browser
DEBUG - 2026-07-04 07:58:25 --> Total execution time: 1.8814
INFO - 2026-07-04 07:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:58:25 --> Upload Class Initialized
DEBUG - 2026-07-04 07:58:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:58:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:58:25 --> Encryption Class Initialized
INFO - 2026-07-04 07:58:25 --> Form Validation Class Initialized
INFO - 2026-07-04 07:58:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:58:25 --> Pagination Class Initialized
INFO - 2026-07-04 07:58:25 --> Email Class Initialized
INFO - 2026-07-04 07:58:25 --> Controller Class Initialized
DEBUG - 2026-07-04 07:58:25 --> Tickets MX_Controller Initialized
INFO - 2026-07-04 07:58:25 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:58:25 --> Model "Auth_model" initialized
INFO - 2026-07-04 07:58:25 --> Model "Cart_model" initialized
INFO - 2026-07-04 07:58:25 --> Model "Support_model" initialized
INFO - 2026-07-04 07:58:25 --> Model "Common_model" initialized
INFO - 2026-07-04 07:58:26 --> Final output sent to browser
DEBUG - 2026-07-04 07:58:26 --> Total execution time: 2.4984
INFO - 2026-07-04 07:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:58:26 --> Upload Class Initialized
DEBUG - 2026-07-04 07:58:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:58:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:58:26 --> Encryption Class Initialized
INFO - 2026-07-04 07:58:26 --> Form Validation Class Initialized
INFO - 2026-07-04 07:58:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:58:26 --> Pagination Class Initialized
INFO - 2026-07-04 07:58:26 --> Email Class Initialized
INFO - 2026-07-04 07:58:26 --> Controller Class Initialized
DEBUG - 2026-07-04 07:58:26 --> Clientarea MX_Controller Initialized
INFO - 2026-07-04 07:58:26 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:58:26 --> Model "Auth_model" initialized
INFO - 2026-07-04 07:58:26 --> Model "Cart_model" initialized
INFO - 2026-07-04 07:58:26 --> Model "Clientarea_model" initialized
INFO - 2026-07-04 07:58:26 --> Model "Billing_model" initialized
INFO - 2026-07-04 07:58:26 --> Model "Common_model" initialized
INFO - 2026-07-04 07:58:26 --> Model "Order_model" initialized
INFO - 2026-07-04 07:58:26 --> Model "Support_model" initialized
INFO - 2026-07-04 07:58:27 --> Final output sent to browser
DEBUG - 2026-07-04 07:58:27 --> Total execution time: 3.1273
INFO - 2026-07-04 07:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:58:27 --> Upload Class Initialized
DEBUG - 2026-07-04 07:58:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:58:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:58:27 --> Encryption Class Initialized
INFO - 2026-07-04 07:58:27 --> Form Validation Class Initialized
INFO - 2026-07-04 07:58:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:58:27 --> Pagination Class Initialized
INFO - 2026-07-04 07:58:27 --> Email Class Initialized
INFO - 2026-07-04 07:58:27 --> Controller Class Initialized
DEBUG - 2026-07-04 07:58:27 --> Billing MX_Controller Initialized
INFO - 2026-07-04 07:58:27 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:58:27 --> Model "Auth_model" initialized
INFO - 2026-07-04 07:58:27 --> Model "Cart_model" initialized
INFO - 2026-07-04 07:58:27 --> Model "Billing_model" initialized
INFO - 2026-07-04 07:58:27 --> Model "Common_model" initialized
INFO - 2026-07-04 07:58:27 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 07:58:27 --> Final output sent to browser
DEBUG - 2026-07-04 07:58:27 --> Total execution time: 3.7652
INFO - 2026-07-04 07:59:12 --> Config Class Initialized
INFO - 2026-07-04 07:59:12 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:59:12 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:59:12 --> Utf8 Class Initialized
INFO - 2026-07-04 07:59:12 --> URI Class Initialized
INFO - 2026-07-04 07:59:12 --> Router Class Initialized
INFO - 2026-07-04 07:59:12 --> Output Class Initialized
INFO - 2026-07-04 07:59:12 --> Security Class Initialized
DEBUG - 2026-07-04 07:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:59:12 --> CSRF cookie sent
INFO - 2026-07-04 07:59:12 --> Input Class Initialized
INFO - 2026-07-04 07:59:12 --> Language Class Initialized
INFO - 2026-07-04 07:59:12 --> Language Class Initialized
INFO - 2026-07-04 07:59:12 --> Config Class Initialized
INFO - 2026-07-04 07:59:12 --> Loader Class Initialized
INFO - 2026-07-04 07:59:12 --> Helper loaded: url_helper
INFO - 2026-07-04 07:59:12 --> Helper loaded: form_helper
INFO - 2026-07-04 07:59:12 --> Helper loaded: html_helper
INFO - 2026-07-04 07:59:12 --> Helper loaded: file_helper
INFO - 2026-07-04 07:59:12 --> Helper loaded: email_helper
INFO - 2026-07-04 07:59:12 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:59:12 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:59:12 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:59:12 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:59:12 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:59:12 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:59:12 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:59:12 --> Database Driver Class Initialized
INFO - 2026-07-04 07:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:59:14 --> Upload Class Initialized
DEBUG - 2026-07-04 07:59:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:59:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:59:14 --> Encryption Class Initialized
INFO - 2026-07-04 07:59:14 --> Form Validation Class Initialized
INFO - 2026-07-04 07:59:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:59:14 --> Pagination Class Initialized
INFO - 2026-07-04 07:59:14 --> Email Class Initialized
INFO - 2026-07-04 07:59:14 --> Controller Class Initialized
DEBUG - 2026-07-04 07:59:14 --> Subscription MX_Controller Initialized
INFO - 2026-07-04 07:59:14 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:59:14 --> Model "Auth_model" initialized
INFO - 2026-07-04 07:59:14 --> Model "Cart_model" initialized
DEBUG - 2026-07-04 07:59:14 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-04 07:59:14 --> Model "Plan_model" initialized
INFO - 2026-07-04 07:59:14 --> Model "Order_model" initialized
INFO - 2026-07-04 07:59:14 --> Model "Orderlicense_model" initialized
INFO - 2026-07-04 07:59:14 --> Model "Subscription_model" initialized
INFO - 2026-07-04 07:59:14 --> Model "Software_model" initialized
DEBUG - 2026-07-04 07:59:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-04 07:59:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-04 07:59:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-04 07:59:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/subscription/views/subscription_index.php
INFO - 2026-07-04 07:59:15 --> Final output sent to browser
DEBUG - 2026-07-04 07:59:15 --> Total execution time: 2.5374
INFO - 2026-07-04 07:59:15 --> Config Class Initialized
INFO - 2026-07-04 07:59:15 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:59:15 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:59:15 --> Utf8 Class Initialized
INFO - 2026-07-04 07:59:15 --> URI Class Initialized
INFO - 2026-07-04 07:59:15 --> Router Class Initialized
INFO - 2026-07-04 07:59:15 --> Output Class Initialized
INFO - 2026-07-04 07:59:15 --> Security Class Initialized
DEBUG - 2026-07-04 07:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:59:15 --> CSRF cookie sent
INFO - 2026-07-04 07:59:15 --> Input Class Initialized
INFO - 2026-07-04 07:59:15 --> Language Class Initialized
INFO - 2026-07-04 07:59:15 --> Language Class Initialized
INFO - 2026-07-04 07:59:15 --> Config Class Initialized
INFO - 2026-07-04 07:59:15 --> Loader Class Initialized
INFO - 2026-07-04 07:59:15 --> Helper loaded: url_helper
INFO - 2026-07-04 07:59:15 --> Helper loaded: form_helper
INFO - 2026-07-04 07:59:15 --> Helper loaded: html_helper
INFO - 2026-07-04 07:59:15 --> Helper loaded: file_helper
INFO - 2026-07-04 07:59:15 --> Helper loaded: email_helper
INFO - 2026-07-04 07:59:15 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:59:15 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:59:15 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:59:15 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:59:15 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:59:15 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:59:15 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:59:15 --> Database Driver Class Initialized
INFO - 2026-07-04 07:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:59:17 --> Upload Class Initialized
DEBUG - 2026-07-04 07:59:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:59:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:59:17 --> Encryption Class Initialized
INFO - 2026-07-04 07:59:17 --> Form Validation Class Initialized
INFO - 2026-07-04 07:59:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:59:17 --> Pagination Class Initialized
INFO - 2026-07-04 07:59:17 --> Email Class Initialized
INFO - 2026-07-04 07:59:17 --> Controller Class Initialized
DEBUG - 2026-07-04 07:59:17 --> Cart MX_Controller Initialized
INFO - 2026-07-04 07:59:17 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:59:17 --> Model "Auth_model" initialized
INFO - 2026-07-04 07:59:17 --> Model "Cart_model" initialized
INFO - 2026-07-04 07:59:17 --> Model "Common_model" initialized
INFO - 2026-07-04 07:59:17 --> Model "Order_model" initialized
INFO - 2026-07-04 07:59:17 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 07:59:17 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-04 07:59:17 --> Model "Promocode_model" initialized
DEBUG - 2026-07-04 07:59:17 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-04 07:59:17 --> Model "Plan_model" initialized
INFO - 2026-07-04 07:59:17 --> Model "Orderlicense_model" initialized
INFO - 2026-07-04 07:59:17 --> Final output sent to browser
DEBUG - 2026-07-04 07:59:17 --> Total execution time: 2.1061
INFO - 2026-07-04 07:59:24 --> Config Class Initialized
INFO - 2026-07-04 07:59:24 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:59:24 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:59:24 --> Utf8 Class Initialized
INFO - 2026-07-04 07:59:24 --> URI Class Initialized
INFO - 2026-07-04 07:59:24 --> Router Class Initialized
INFO - 2026-07-04 07:59:24 --> Output Class Initialized
INFO - 2026-07-04 07:59:24 --> Security Class Initialized
DEBUG - 2026-07-04 07:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:59:24 --> CSRF cookie sent
INFO - 2026-07-04 07:59:24 --> Input Class Initialized
INFO - 2026-07-04 07:59:24 --> Language Class Initialized
INFO - 2026-07-04 07:59:24 --> Language Class Initialized
INFO - 2026-07-04 07:59:24 --> Config Class Initialized
INFO - 2026-07-04 07:59:24 --> Loader Class Initialized
INFO - 2026-07-04 07:59:24 --> Helper loaded: url_helper
INFO - 2026-07-04 07:59:24 --> Helper loaded: form_helper
INFO - 2026-07-04 07:59:24 --> Helper loaded: html_helper
INFO - 2026-07-04 07:59:24 --> Helper loaded: file_helper
INFO - 2026-07-04 07:59:24 --> Helper loaded: email_helper
INFO - 2026-07-04 07:59:24 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:59:24 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:59:24 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:59:24 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:59:24 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:59:24 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:59:24 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:59:24 --> Database Driver Class Initialized
INFO - 2026-07-04 07:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:59:27 --> Upload Class Initialized
DEBUG - 2026-07-04 07:59:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:59:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:59:27 --> Encryption Class Initialized
INFO - 2026-07-04 07:59:27 --> Form Validation Class Initialized
INFO - 2026-07-04 07:59:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:59:27 --> Pagination Class Initialized
INFO - 2026-07-04 07:59:27 --> Email Class Initialized
INFO - 2026-07-04 07:59:27 --> Controller Class Initialized
DEBUG - 2026-07-04 07:59:27 --> Subscription MX_Controller Initialized
INFO - 2026-07-04 07:59:27 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:59:27 --> Model "Auth_model" initialized
INFO - 2026-07-04 07:59:27 --> Model "Cart_model" initialized
DEBUG - 2026-07-04 07:59:27 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-04 07:59:27 --> Model "Plan_model" initialized
INFO - 2026-07-04 07:59:27 --> Model "Order_model" initialized
INFO - 2026-07-04 07:59:27 --> Model "Orderlicense_model" initialized
INFO - 2026-07-04 07:59:27 --> Model "Subscription_model" initialized
INFO - 2026-07-04 07:59:27 --> Model "Software_model" initialized
DEBUG - 2026-07-04 07:59:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-04 07:59:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-04 07:59:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-04 07:59:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/subscription/views/subscription_bind.php
INFO - 2026-07-04 07:59:28 --> Final output sent to browser
DEBUG - 2026-07-04 07:59:28 --> Total execution time: 3.8477
INFO - 2026-07-04 07:59:28 --> Config Class Initialized
INFO - 2026-07-04 07:59:28 --> Hooks Class Initialized
DEBUG - 2026-07-04 07:59:28 --> UTF-8 Support Enabled
INFO - 2026-07-04 07:59:28 --> Utf8 Class Initialized
INFO - 2026-07-04 07:59:28 --> URI Class Initialized
INFO - 2026-07-04 07:59:28 --> Router Class Initialized
INFO - 2026-07-04 07:59:28 --> Output Class Initialized
INFO - 2026-07-04 07:59:28 --> Security Class Initialized
DEBUG - 2026-07-04 07:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 07:59:28 --> CSRF cookie sent
INFO - 2026-07-04 07:59:28 --> Input Class Initialized
INFO - 2026-07-04 07:59:28 --> Language Class Initialized
INFO - 2026-07-04 07:59:28 --> Language Class Initialized
INFO - 2026-07-04 07:59:28 --> Config Class Initialized
INFO - 2026-07-04 07:59:28 --> Loader Class Initialized
INFO - 2026-07-04 07:59:28 --> Helper loaded: url_helper
INFO - 2026-07-04 07:59:28 --> Helper loaded: form_helper
INFO - 2026-07-04 07:59:28 --> Helper loaded: html_helper
INFO - 2026-07-04 07:59:28 --> Helper loaded: file_helper
INFO - 2026-07-04 07:59:28 --> Helper loaded: email_helper
INFO - 2026-07-04 07:59:28 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 07:59:28 --> Helper loaded: ssp_helper
INFO - 2026-07-04 07:59:28 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 07:59:28 --> Helper loaded: plesk_helper
INFO - 2026-07-04 07:59:28 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 07:59:28 --> Helper loaded: domain_helper
INFO - 2026-07-04 07:59:28 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 07:59:28 --> Database Driver Class Initialized
INFO - 2026-07-04 07:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 07:59:30 --> Upload Class Initialized
DEBUG - 2026-07-04 07:59:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 07:59:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 07:59:30 --> Encryption Class Initialized
INFO - 2026-07-04 07:59:30 --> Form Validation Class Initialized
INFO - 2026-07-04 07:59:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 07:59:30 --> Pagination Class Initialized
INFO - 2026-07-04 07:59:30 --> Email Class Initialized
INFO - 2026-07-04 07:59:30 --> Controller Class Initialized
DEBUG - 2026-07-04 07:59:30 --> Cart MX_Controller Initialized
INFO - 2026-07-04 07:59:30 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 07:59:30 --> Model "Auth_model" initialized
INFO - 2026-07-04 07:59:30 --> Model "Cart_model" initialized
INFO - 2026-07-04 07:59:30 --> Model "Common_model" initialized
INFO - 2026-07-04 07:59:30 --> Model "Order_model" initialized
INFO - 2026-07-04 07:59:30 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 07:59:30 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-04 07:59:30 --> Model "Promocode_model" initialized
DEBUG - 2026-07-04 07:59:30 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-04 07:59:30 --> Model "Plan_model" initialized
INFO - 2026-07-04 07:59:30 --> Model "Orderlicense_model" initialized
INFO - 2026-07-04 07:59:30 --> Final output sent to browser
DEBUG - 2026-07-04 07:59:30 --> Total execution time: 1.8805
INFO - 2026-07-04 08:00:22 --> Config Class Initialized
INFO - 2026-07-04 08:00:22 --> Hooks Class Initialized
DEBUG - 2026-07-04 08:00:22 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:00:22 --> Utf8 Class Initialized
INFO - 2026-07-04 08:00:22 --> URI Class Initialized
INFO - 2026-07-04 08:00:22 --> Router Class Initialized
INFO - 2026-07-04 08:00:22 --> Output Class Initialized
INFO - 2026-07-04 08:00:22 --> Security Class Initialized
DEBUG - 2026-07-04 08:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:00:22 --> CSRF cookie sent
INFO - 2026-07-04 08:00:22 --> CSRF token verified
INFO - 2026-07-04 08:00:22 --> Input Class Initialized
INFO - 2026-07-04 08:00:22 --> Language Class Initialized
INFO - 2026-07-04 08:00:22 --> Language Class Initialized
INFO - 2026-07-04 08:00:22 --> Config Class Initialized
INFO - 2026-07-04 08:00:22 --> Loader Class Initialized
INFO - 2026-07-04 08:00:22 --> Helper loaded: url_helper
INFO - 2026-07-04 08:00:22 --> Helper loaded: form_helper
INFO - 2026-07-04 08:00:22 --> Helper loaded: html_helper
INFO - 2026-07-04 08:00:22 --> Helper loaded: file_helper
INFO - 2026-07-04 08:00:22 --> Helper loaded: email_helper
INFO - 2026-07-04 08:00:22 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:00:22 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:00:22 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:00:22 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:00:22 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:00:22 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:00:22 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:00:22 --> Database Driver Class Initialized
INFO - 2026-07-04 08:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:00:24 --> Upload Class Initialized
DEBUG - 2026-07-04 08:00:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:00:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:00:24 --> Encryption Class Initialized
INFO - 2026-07-04 08:00:24 --> Form Validation Class Initialized
INFO - 2026-07-04 08:00:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:00:24 --> Pagination Class Initialized
INFO - 2026-07-04 08:00:24 --> Email Class Initialized
INFO - 2026-07-04 08:00:24 --> Controller Class Initialized
DEBUG - 2026-07-04 08:00:24 --> Subscription MX_Controller Initialized
INFO - 2026-07-04 08:00:24 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:00:24 --> Model "Auth_model" initialized
INFO - 2026-07-04 08:00:24 --> Model "Cart_model" initialized
DEBUG - 2026-07-04 08:00:24 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-04 08:00:24 --> Model "Plan_model" initialized
INFO - 2026-07-04 08:00:24 --> Model "Order_model" initialized
INFO - 2026-07-04 08:00:24 --> Model "Orderlicense_model" initialized
INFO - 2026-07-04 08:00:24 --> Model "Subscription_model" initialized
INFO - 2026-07-04 08:00:24 --> Model "Software_model" initialized
INFO - 2026-07-04 08:00:26 --> Config Class Initialized
INFO - 2026-07-04 08:00:26 --> Hooks Class Initialized
DEBUG - 2026-07-04 08:00:26 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:00:26 --> Utf8 Class Initialized
INFO - 2026-07-04 08:00:26 --> URI Class Initialized
INFO - 2026-07-04 08:00:26 --> Router Class Initialized
INFO - 2026-07-04 08:00:26 --> Output Class Initialized
INFO - 2026-07-04 08:00:26 --> Security Class Initialized
DEBUG - 2026-07-04 08:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:00:26 --> CSRF cookie sent
INFO - 2026-07-04 08:00:26 --> Input Class Initialized
INFO - 2026-07-04 08:00:26 --> Language Class Initialized
INFO - 2026-07-04 08:00:26 --> Language Class Initialized
INFO - 2026-07-04 08:00:26 --> Config Class Initialized
INFO - 2026-07-04 08:00:26 --> Loader Class Initialized
INFO - 2026-07-04 08:00:26 --> Helper loaded: url_helper
INFO - 2026-07-04 08:00:26 --> Helper loaded: form_helper
INFO - 2026-07-04 08:00:26 --> Helper loaded: html_helper
INFO - 2026-07-04 08:00:26 --> Helper loaded: file_helper
INFO - 2026-07-04 08:00:26 --> Helper loaded: email_helper
INFO - 2026-07-04 08:00:26 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:00:26 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:00:26 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:00:26 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:00:26 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:00:26 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:00:26 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:00:26 --> Database Driver Class Initialized
INFO - 2026-07-04 08:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:00:27 --> Upload Class Initialized
DEBUG - 2026-07-04 08:00:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:00:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:00:27 --> Encryption Class Initialized
INFO - 2026-07-04 08:00:27 --> Form Validation Class Initialized
INFO - 2026-07-04 08:00:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:00:27 --> Pagination Class Initialized
INFO - 2026-07-04 08:00:27 --> Email Class Initialized
INFO - 2026-07-04 08:00:27 --> Controller Class Initialized
DEBUG - 2026-07-04 08:00:27 --> Subscription MX_Controller Initialized
INFO - 2026-07-04 08:00:27 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:00:27 --> Model "Auth_model" initialized
INFO - 2026-07-04 08:00:27 --> Model "Cart_model" initialized
DEBUG - 2026-07-04 08:00:27 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-04 08:00:27 --> Model "Plan_model" initialized
INFO - 2026-07-04 08:00:27 --> Model "Order_model" initialized
INFO - 2026-07-04 08:00:27 --> Model "Orderlicense_model" initialized
INFO - 2026-07-04 08:00:27 --> Model "Subscription_model" initialized
INFO - 2026-07-04 08:00:27 --> Model "Software_model" initialized
INFO - 2026-07-04 08:00:44 --> Config Class Initialized
INFO - 2026-07-04 08:00:44 --> Hooks Class Initialized
DEBUG - 2026-07-04 08:00:44 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:00:44 --> Utf8 Class Initialized
INFO - 2026-07-04 08:00:44 --> URI Class Initialized
DEBUG - 2026-07-04 08:00:44 --> No URI present. Default controller set.
INFO - 2026-07-04 08:00:44 --> Router Class Initialized
INFO - 2026-07-04 08:00:44 --> Output Class Initialized
INFO - 2026-07-04 08:00:44 --> Security Class Initialized
DEBUG - 2026-07-04 08:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:00:44 --> CSRF cookie sent
INFO - 2026-07-04 08:00:44 --> Input Class Initialized
INFO - 2026-07-04 08:00:44 --> Language Class Initialized
INFO - 2026-07-04 08:00:44 --> Language Class Initialized
INFO - 2026-07-04 08:00:44 --> Config Class Initialized
INFO - 2026-07-04 08:00:44 --> Loader Class Initialized
INFO - 2026-07-04 08:00:44 --> Helper loaded: url_helper
INFO - 2026-07-04 08:00:44 --> Helper loaded: form_helper
INFO - 2026-07-04 08:00:44 --> Helper loaded: html_helper
INFO - 2026-07-04 08:00:44 --> Helper loaded: file_helper
INFO - 2026-07-04 08:00:44 --> Helper loaded: email_helper
INFO - 2026-07-04 08:00:44 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:00:44 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:00:44 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:00:44 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:00:44 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:00:44 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:00:44 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:00:44 --> Database Driver Class Initialized
INFO - 2026-07-04 08:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:00:45 --> Upload Class Initialized
DEBUG - 2026-07-04 08:00:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:00:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:00:45 --> Encryption Class Initialized
INFO - 2026-07-04 08:00:45 --> Form Validation Class Initialized
INFO - 2026-07-04 08:00:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:00:45 --> Pagination Class Initialized
INFO - 2026-07-04 08:00:45 --> Email Class Initialized
INFO - 2026-07-04 08:00:45 --> Controller Class Initialized
DEBUG - 2026-07-04 08:00:45 --> Auth MX_Controller Initialized
INFO - 2026-07-04 08:00:45 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:00:45 --> Model "Auth_model" initialized
INFO - 2026-07-04 08:00:45 --> Model "Cart_model" initialized
INFO - 2026-07-04 08:00:45 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 08:00:45 --> Config Class Initialized
INFO - 2026-07-04 08:00:45 --> Hooks Class Initialized
DEBUG - 2026-07-04 08:00:45 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:00:45 --> Utf8 Class Initialized
INFO - 2026-07-04 08:00:45 --> URI Class Initialized
INFO - 2026-07-04 08:00:45 --> Router Class Initialized
INFO - 2026-07-04 08:00:45 --> Output Class Initialized
INFO - 2026-07-04 08:00:45 --> Security Class Initialized
DEBUG - 2026-07-04 08:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:00:45 --> CSRF cookie sent
INFO - 2026-07-04 08:00:45 --> Input Class Initialized
INFO - 2026-07-04 08:00:45 --> Language Class Initialized
INFO - 2026-07-04 08:00:45 --> Language Class Initialized
INFO - 2026-07-04 08:00:45 --> Config Class Initialized
INFO - 2026-07-04 08:00:45 --> Loader Class Initialized
INFO - 2026-07-04 08:00:45 --> Helper loaded: url_helper
INFO - 2026-07-04 08:00:45 --> Helper loaded: form_helper
INFO - 2026-07-04 08:00:45 --> Helper loaded: html_helper
INFO - 2026-07-04 08:00:45 --> Helper loaded: file_helper
INFO - 2026-07-04 08:00:45 --> Helper loaded: email_helper
INFO - 2026-07-04 08:00:45 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:00:45 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:00:45 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:00:45 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:00:45 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:00:45 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:00:45 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:00:45 --> Database Driver Class Initialized
INFO - 2026-07-04 08:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:00:47 --> Upload Class Initialized
DEBUG - 2026-07-04 08:00:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:00:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:00:47 --> Encryption Class Initialized
INFO - 2026-07-04 08:00:47 --> Form Validation Class Initialized
INFO - 2026-07-04 08:00:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:00:47 --> Pagination Class Initialized
INFO - 2026-07-04 08:00:47 --> Email Class Initialized
INFO - 2026-07-04 08:00:47 --> Controller Class Initialized
DEBUG - 2026-07-04 08:00:47 --> Auth MX_Controller Initialized
INFO - 2026-07-04 08:00:47 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:00:47 --> Model "Auth_model" initialized
INFO - 2026-07-04 08:00:47 --> Model "Cart_model" initialized
INFO - 2026-07-04 08:00:47 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-04 08:00:47 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-04 08:00:47 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-04 08:00:47 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-04 08:00:47 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-07-04 08:00:47 --> Final output sent to browser
DEBUG - 2026-07-04 08:00:47 --> Total execution time: 1.9558
INFO - 2026-07-04 08:00:47 --> Config Class Initialized
INFO - 2026-07-04 08:00:47 --> Hooks Class Initialized
DEBUG - 2026-07-04 08:00:47 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:00:47 --> Utf8 Class Initialized
INFO - 2026-07-04 08:00:47 --> URI Class Initialized
INFO - 2026-07-04 08:00:47 --> Router Class Initialized
INFO - 2026-07-04 08:00:47 --> Output Class Initialized
INFO - 2026-07-04 08:00:47 --> Security Class Initialized
DEBUG - 2026-07-04 08:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:00:47 --> CSRF cookie sent
INFO - 2026-07-04 08:00:47 --> Input Class Initialized
INFO - 2026-07-04 08:00:47 --> Language Class Initialized
INFO - 2026-07-04 08:00:47 --> Language Class Initialized
INFO - 2026-07-04 08:00:47 --> Config Class Initialized
INFO - 2026-07-04 08:00:47 --> Loader Class Initialized
INFO - 2026-07-04 08:00:47 --> Helper loaded: url_helper
INFO - 2026-07-04 08:00:47 --> Helper loaded: form_helper
INFO - 2026-07-04 08:00:47 --> Helper loaded: html_helper
INFO - 2026-07-04 08:00:47 --> Helper loaded: file_helper
INFO - 2026-07-04 08:00:47 --> Helper loaded: email_helper
INFO - 2026-07-04 08:00:47 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:00:47 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:00:47 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:00:47 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:00:47 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:00:47 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:00:47 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:00:47 --> Database Driver Class Initialized
INFO - 2026-07-04 08:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:00:49 --> Upload Class Initialized
DEBUG - 2026-07-04 08:00:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:00:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:00:49 --> Encryption Class Initialized
INFO - 2026-07-04 08:00:49 --> Form Validation Class Initialized
INFO - 2026-07-04 08:00:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:00:49 --> Pagination Class Initialized
INFO - 2026-07-04 08:00:49 --> Email Class Initialized
INFO - 2026-07-04 08:00:49 --> Controller Class Initialized
DEBUG - 2026-07-04 08:00:49 --> Cart MX_Controller Initialized
INFO - 2026-07-04 08:00:49 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:00:49 --> Model "Auth_model" initialized
INFO - 2026-07-04 08:00:49 --> Model "Cart_model" initialized
INFO - 2026-07-04 08:00:49 --> Model "Common_model" initialized
INFO - 2026-07-04 08:00:49 --> Model "Order_model" initialized
INFO - 2026-07-04 08:00:49 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 08:00:49 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-04 08:00:49 --> Model "Promocode_model" initialized
DEBUG - 2026-07-04 08:00:49 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-04 08:00:49 --> Model "Plan_model" initialized
INFO - 2026-07-04 08:00:49 --> Model "Orderlicense_model" initialized
INFO - 2026-07-04 08:00:49 --> Final output sent to browser
DEBUG - 2026-07-04 08:00:49 --> Total execution time: 1.8656
INFO - 2026-07-04 08:02:12 --> Config Class Initialized
INFO - 2026-07-04 08:02:12 --> Hooks Class Initialized
DEBUG - 2026-07-04 08:02:12 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:02:12 --> Utf8 Class Initialized
INFO - 2026-07-04 08:02:12 --> URI Class Initialized
INFO - 2026-07-04 08:02:12 --> Router Class Initialized
INFO - 2026-07-04 08:02:12 --> Output Class Initialized
INFO - 2026-07-04 08:02:12 --> Security Class Initialized
DEBUG - 2026-07-04 08:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:02:12 --> CSRF cookie sent
INFO - 2026-07-04 08:02:12 --> CSRF token verified
INFO - 2026-07-04 08:02:12 --> Input Class Initialized
INFO - 2026-07-04 08:02:12 --> Language Class Initialized
INFO - 2026-07-04 08:02:12 --> Language Class Initialized
INFO - 2026-07-04 08:02:12 --> Config Class Initialized
INFO - 2026-07-04 08:02:12 --> Loader Class Initialized
INFO - 2026-07-04 08:02:12 --> Helper loaded: url_helper
INFO - 2026-07-04 08:02:12 --> Helper loaded: form_helper
INFO - 2026-07-04 08:02:12 --> Helper loaded: html_helper
INFO - 2026-07-04 08:02:12 --> Helper loaded: file_helper
INFO - 2026-07-04 08:02:12 --> Helper loaded: email_helper
INFO - 2026-07-04 08:02:12 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:02:12 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:02:12 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:02:12 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:02:12 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:02:12 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:02:12 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:02:12 --> Database Driver Class Initialized
INFO - 2026-07-04 08:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:02:14 --> Upload Class Initialized
DEBUG - 2026-07-04 08:02:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:02:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:02:14 --> Encryption Class Initialized
INFO - 2026-07-04 08:02:14 --> Form Validation Class Initialized
INFO - 2026-07-04 08:02:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:02:14 --> Pagination Class Initialized
INFO - 2026-07-04 08:02:14 --> Email Class Initialized
INFO - 2026-07-04 08:02:14 --> Controller Class Initialized
DEBUG - 2026-07-04 08:02:14 --> Auth MX_Controller Initialized
INFO - 2026-07-04 08:02:14 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:02:14 --> Model "Auth_model" initialized
INFO - 2026-07-04 08:02:14 --> Model "Cart_model" initialized
INFO - 2026-07-04 08:02:14 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 08:02:16 --> Config Class Initialized
INFO - 2026-07-04 08:02:16 --> Hooks Class Initialized
DEBUG - 2026-07-04 08:02:16 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:02:16 --> Utf8 Class Initialized
INFO - 2026-07-04 08:02:16 --> URI Class Initialized
INFO - 2026-07-04 08:02:16 --> Router Class Initialized
INFO - 2026-07-04 08:02:16 --> Output Class Initialized
INFO - 2026-07-04 08:02:16 --> Security Class Initialized
DEBUG - 2026-07-04 08:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:02:16 --> CSRF cookie sent
INFO - 2026-07-04 08:02:16 --> Input Class Initialized
INFO - 2026-07-04 08:02:16 --> Language Class Initialized
INFO - 2026-07-04 08:02:16 --> Language Class Initialized
INFO - 2026-07-04 08:02:16 --> Config Class Initialized
INFO - 2026-07-04 08:02:16 --> Loader Class Initialized
INFO - 2026-07-04 08:02:16 --> Helper loaded: url_helper
INFO - 2026-07-04 08:02:16 --> Helper loaded: form_helper
INFO - 2026-07-04 08:02:16 --> Helper loaded: html_helper
INFO - 2026-07-04 08:02:16 --> Helper loaded: file_helper
INFO - 2026-07-04 08:02:16 --> Helper loaded: email_helper
INFO - 2026-07-04 08:02:16 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:02:16 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:02:16 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:02:16 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:02:16 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:02:16 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:02:16 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:02:16 --> Database Driver Class Initialized
INFO - 2026-07-04 08:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:02:18 --> Upload Class Initialized
DEBUG - 2026-07-04 08:02:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:02:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:02:18 --> Encryption Class Initialized
INFO - 2026-07-04 08:02:18 --> Form Validation Class Initialized
INFO - 2026-07-04 08:02:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:02:18 --> Pagination Class Initialized
INFO - 2026-07-04 08:02:18 --> Email Class Initialized
INFO - 2026-07-04 08:02:18 --> Controller Class Initialized
DEBUG - 2026-07-04 08:02:18 --> Clientarea MX_Controller Initialized
INFO - 2026-07-04 08:02:18 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:02:18 --> Model "Auth_model" initialized
INFO - 2026-07-04 08:02:18 --> Model "Cart_model" initialized
INFO - 2026-07-04 08:02:18 --> Model "Clientarea_model" initialized
INFO - 2026-07-04 08:02:18 --> Model "Billing_model" initialized
INFO - 2026-07-04 08:02:18 --> Model "Common_model" initialized
INFO - 2026-07-04 08:02:18 --> Model "Order_model" initialized
INFO - 2026-07-04 08:02:18 --> Model "Support_model" initialized
INFO - 2026-07-04 08:02:18 --> Model "Subscription_model" initialized
INFO - 2026-07-04 08:02:18 --> Model "Software_model" initialized
DEBUG - 2026-07-04 08:02:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-04 08:02:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-04 08:02:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-04 08:02:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_index.php
INFO - 2026-07-04 08:02:19 --> Final output sent to browser
DEBUG - 2026-07-04 08:02:19 --> Total execution time: 2.9040
INFO - 2026-07-04 08:02:19 --> Config Class Initialized
INFO - 2026-07-04 08:02:19 --> Hooks Class Initialized
DEBUG - 2026-07-04 08:02:19 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:02:19 --> Utf8 Class Initialized
INFO - 2026-07-04 08:02:19 --> URI Class Initialized
INFO - 2026-07-04 08:02:19 --> Router Class Initialized
INFO - 2026-07-04 08:02:19 --> Output Class Initialized
INFO - 2026-07-04 08:02:19 --> Security Class Initialized
DEBUG - 2026-07-04 08:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:02:19 --> CSRF cookie sent
INFO - 2026-07-04 08:02:19 --> Input Class Initialized
INFO - 2026-07-04 08:02:19 --> Language Class Initialized
INFO - 2026-07-04 08:02:19 --> Language Class Initialized
INFO - 2026-07-04 08:02:19 --> Config Class Initialized
INFO - 2026-07-04 08:02:19 --> Loader Class Initialized
INFO - 2026-07-04 08:02:19 --> Helper loaded: url_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: form_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: html_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: file_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: email_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:02:19 --> Config Class Initialized
INFO - 2026-07-04 08:02:19 --> Hooks Class Initialized
INFO - 2026-07-04 08:02:19 --> Helper loaded: directadmin_helper
DEBUG - 2026-07-04 08:02:19 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:02:19 --> Utf8 Class Initialized
INFO - 2026-07-04 08:02:19 --> URI Class Initialized
INFO - 2026-07-04 08:02:19 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:02:19 --> Router Class Initialized
INFO - 2026-07-04 08:02:19 --> Output Class Initialized
INFO - 2026-07-04 08:02:19 --> Security Class Initialized
DEBUG - 2026-07-04 08:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:02:19 --> Input Class Initialized
INFO - 2026-07-04 08:02:19 --> Language Class Initialized
INFO - 2026-07-04 08:02:19 --> Config Class Initialized
INFO - 2026-07-04 08:02:19 --> Hooks Class Initialized
INFO - 2026-07-04 08:02:19 --> Database Driver Class Initialized
DEBUG - 2026-07-04 08:02:19 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:02:19 --> Utf8 Class Initialized
INFO - 2026-07-04 08:02:19 --> Config Class Initialized
INFO - 2026-07-04 08:02:19 --> Hooks Class Initialized
INFO - 2026-07-04 08:02:19 --> URI Class Initialized
DEBUG - 2026-07-04 08:02:19 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:02:19 --> Utf8 Class Initialized
INFO - 2026-07-04 08:02:19 --> URI Class Initialized
INFO - 2026-07-04 08:02:19 --> Language Class Initialized
INFO - 2026-07-04 08:02:19 --> Config Class Initialized
INFO - 2026-07-04 08:02:19 --> Router Class Initialized
INFO - 2026-07-04 08:02:19 --> Router Class Initialized
INFO - 2026-07-04 08:02:19 --> Output Class Initialized
INFO - 2026-07-04 08:02:19 --> Loader Class Initialized
INFO - 2026-07-04 08:02:19 --> Output Class Initialized
INFO - 2026-07-04 08:02:19 --> Helper loaded: url_helper
INFO - 2026-07-04 08:02:19 --> Security Class Initialized
INFO - 2026-07-04 08:02:19 --> Security Class Initialized
INFO - 2026-07-04 08:02:19 --> Helper loaded: form_helper
DEBUG - 2026-07-04 08:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:02:19 --> Input Class Initialized
INFO - 2026-07-04 08:02:19 --> Helper loaded: html_helper
DEBUG - 2026-07-04 08:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:02:19 --> Language Class Initialized
INFO - 2026-07-04 08:02:19 --> Input Class Initialized
INFO - 2026-07-04 08:02:19 --> Helper loaded: file_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: email_helper
INFO - 2026-07-04 08:02:19 --> Language Class Initialized
INFO - 2026-07-04 08:02:19 --> Language Class Initialized
INFO - 2026-07-04 08:02:19 --> Config Class Initialized
INFO - 2026-07-04 08:02:19 --> Language Class Initialized
INFO - 2026-07-04 08:02:19 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:02:19 --> Config Class Initialized
INFO - 2026-07-04 08:02:19 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:02:19 --> Loader Class Initialized
INFO - 2026-07-04 08:02:19 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: url_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:02:19 --> Loader Class Initialized
INFO - 2026-07-04 08:02:19 --> Helper loaded: form_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: html_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: file_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: url_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: email_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: form_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: html_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: file_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: email_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:02:19 --> Database Driver Class Initialized
INFO - 2026-07-04 08:02:19 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:02:19 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:02:19 --> Database Driver Class Initialized
INFO - 2026-07-04 08:02:19 --> Database Driver Class Initialized
INFO - 2026-07-04 08:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:02:21 --> Upload Class Initialized
DEBUG - 2026-07-04 08:02:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:02:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:02:21 --> Encryption Class Initialized
INFO - 2026-07-04 08:02:21 --> Form Validation Class Initialized
INFO - 2026-07-04 08:02:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:02:21 --> Pagination Class Initialized
INFO - 2026-07-04 08:02:21 --> Email Class Initialized
INFO - 2026-07-04 08:02:21 --> Controller Class Initialized
DEBUG - 2026-07-04 08:02:21 --> Cart MX_Controller Initialized
INFO - 2026-07-04 08:02:21 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:02:21 --> Model "Auth_model" initialized
INFO - 2026-07-04 08:02:21 --> Model "Cart_model" initialized
INFO - 2026-07-04 08:02:21 --> Model "Common_model" initialized
INFO - 2026-07-04 08:02:21 --> Model "Order_model" initialized
INFO - 2026-07-04 08:02:21 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 08:02:21 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-04 08:02:21 --> Model "Promocode_model" initialized
DEBUG - 2026-07-04 08:02:21 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-04 08:02:21 --> Model "Plan_model" initialized
INFO - 2026-07-04 08:02:21 --> Model "Orderlicense_model" initialized
INFO - 2026-07-04 08:02:21 --> Final output sent to browser
DEBUG - 2026-07-04 08:02:21 --> Total execution time: 1.8853
INFO - 2026-07-04 08:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:02:21 --> Upload Class Initialized
DEBUG - 2026-07-04 08:02:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:02:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:02:21 --> Encryption Class Initialized
INFO - 2026-07-04 08:02:21 --> Form Validation Class Initialized
INFO - 2026-07-04 08:02:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:02:21 --> Pagination Class Initialized
INFO - 2026-07-04 08:02:21 --> Email Class Initialized
INFO - 2026-07-04 08:02:21 --> Controller Class Initialized
DEBUG - 2026-07-04 08:02:21 --> Clientarea MX_Controller Initialized
INFO - 2026-07-04 08:02:21 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:02:21 --> Model "Auth_model" initialized
INFO - 2026-07-04 08:02:21 --> Model "Cart_model" initialized
INFO - 2026-07-04 08:02:21 --> Model "Clientarea_model" initialized
INFO - 2026-07-04 08:02:21 --> Model "Billing_model" initialized
INFO - 2026-07-04 08:02:21 --> Model "Common_model" initialized
INFO - 2026-07-04 08:02:21 --> Model "Order_model" initialized
INFO - 2026-07-04 08:02:21 --> Model "Support_model" initialized
INFO - 2026-07-04 08:02:22 --> Final output sent to browser
DEBUG - 2026-07-04 08:02:22 --> Total execution time: 2.5009
INFO - 2026-07-04 08:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:02:22 --> Upload Class Initialized
DEBUG - 2026-07-04 08:02:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:02:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:02:22 --> Encryption Class Initialized
INFO - 2026-07-04 08:02:22 --> Form Validation Class Initialized
INFO - 2026-07-04 08:02:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:02:22 --> Pagination Class Initialized
INFO - 2026-07-04 08:02:22 --> Email Class Initialized
INFO - 2026-07-04 08:02:22 --> Controller Class Initialized
DEBUG - 2026-07-04 08:02:22 --> Tickets MX_Controller Initialized
INFO - 2026-07-04 08:02:22 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:02:22 --> Model "Auth_model" initialized
INFO - 2026-07-04 08:02:22 --> Model "Cart_model" initialized
INFO - 2026-07-04 08:02:22 --> Model "Support_model" initialized
INFO - 2026-07-04 08:02:22 --> Model "Common_model" initialized
INFO - 2026-07-04 08:02:22 --> Config Class Initialized
INFO - 2026-07-04 08:02:22 --> Hooks Class Initialized
DEBUG - 2026-07-04 08:02:22 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:02:22 --> Utf8 Class Initialized
INFO - 2026-07-04 08:02:22 --> URI Class Initialized
INFO - 2026-07-04 08:02:22 --> Router Class Initialized
INFO - 2026-07-04 08:02:22 --> Output Class Initialized
INFO - 2026-07-04 08:02:22 --> Security Class Initialized
DEBUG - 2026-07-04 08:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:02:22 --> CSRF cookie sent
INFO - 2026-07-04 08:02:22 --> Input Class Initialized
INFO - 2026-07-04 08:02:22 --> Language Class Initialized
INFO - 2026-07-04 08:02:22 --> Language Class Initialized
INFO - 2026-07-04 08:02:22 --> Config Class Initialized
INFO - 2026-07-04 08:02:22 --> Loader Class Initialized
INFO - 2026-07-04 08:02:22 --> Helper loaded: url_helper
INFO - 2026-07-04 08:02:22 --> Helper loaded: form_helper
INFO - 2026-07-04 08:02:22 --> Helper loaded: html_helper
INFO - 2026-07-04 08:02:22 --> Helper loaded: file_helper
INFO - 2026-07-04 08:02:22 --> Helper loaded: email_helper
INFO - 2026-07-04 08:02:22 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:02:22 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:02:22 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:02:22 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:02:22 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:02:22 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:02:22 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:02:22 --> Database Driver Class Initialized
INFO - 2026-07-04 08:02:23 --> Final output sent to browser
DEBUG - 2026-07-04 08:02:23 --> Total execution time: 3.4522
INFO - 2026-07-04 08:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:02:23 --> Upload Class Initialized
DEBUG - 2026-07-04 08:02:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:02:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:02:23 --> Encryption Class Initialized
INFO - 2026-07-04 08:02:23 --> Form Validation Class Initialized
INFO - 2026-07-04 08:02:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:02:23 --> Pagination Class Initialized
INFO - 2026-07-04 08:02:23 --> Email Class Initialized
INFO - 2026-07-04 08:02:23 --> Controller Class Initialized
DEBUG - 2026-07-04 08:02:23 --> Billing MX_Controller Initialized
INFO - 2026-07-04 08:02:23 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:02:23 --> Model "Auth_model" initialized
INFO - 2026-07-04 08:02:23 --> Model "Cart_model" initialized
INFO - 2026-07-04 08:02:23 --> Model "Billing_model" initialized
INFO - 2026-07-04 08:02:23 --> Model "Common_model" initialized
INFO - 2026-07-04 08:02:23 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 08:02:23 --> Final output sent to browser
DEBUG - 2026-07-04 08:02:23 --> Total execution time: 4.0698
INFO - 2026-07-04 08:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:02:25 --> Upload Class Initialized
DEBUG - 2026-07-04 08:02:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:02:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:02:25 --> Encryption Class Initialized
INFO - 2026-07-04 08:02:25 --> Form Validation Class Initialized
INFO - 2026-07-04 08:02:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:02:25 --> Pagination Class Initialized
INFO - 2026-07-04 08:02:25 --> Email Class Initialized
INFO - 2026-07-04 08:02:25 --> Controller Class Initialized
DEBUG - 2026-07-04 08:02:25 --> Subscription MX_Controller Initialized
INFO - 2026-07-04 08:02:25 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:02:25 --> Model "Auth_model" initialized
INFO - 2026-07-04 08:02:25 --> Model "Cart_model" initialized
DEBUG - 2026-07-04 08:02:25 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-04 08:02:25 --> Model "Plan_model" initialized
INFO - 2026-07-04 08:02:25 --> Model "Order_model" initialized
INFO - 2026-07-04 08:02:25 --> Model "Orderlicense_model" initialized
INFO - 2026-07-04 08:02:25 --> Model "Subscription_model" initialized
INFO - 2026-07-04 08:02:25 --> Model "Software_model" initialized
DEBUG - 2026-07-04 08:02:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-04 08:02:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-04 08:02:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-04 08:02:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/subscription/views/subscription_index.php
INFO - 2026-07-04 08:02:26 --> Final output sent to browser
DEBUG - 2026-07-04 08:02:26 --> Total execution time: 3.5380
INFO - 2026-07-04 08:02:26 --> Config Class Initialized
INFO - 2026-07-04 08:02:26 --> Hooks Class Initialized
DEBUG - 2026-07-04 08:02:26 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:02:26 --> Utf8 Class Initialized
INFO - 2026-07-04 08:02:26 --> URI Class Initialized
INFO - 2026-07-04 08:02:26 --> Router Class Initialized
INFO - 2026-07-04 08:02:26 --> Output Class Initialized
INFO - 2026-07-04 08:02:26 --> Security Class Initialized
DEBUG - 2026-07-04 08:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:02:26 --> CSRF cookie sent
INFO - 2026-07-04 08:02:26 --> Input Class Initialized
INFO - 2026-07-04 08:02:26 --> Language Class Initialized
INFO - 2026-07-04 08:02:26 --> Language Class Initialized
INFO - 2026-07-04 08:02:26 --> Config Class Initialized
INFO - 2026-07-04 08:02:26 --> Loader Class Initialized
INFO - 2026-07-04 08:02:26 --> Helper loaded: url_helper
INFO - 2026-07-04 08:02:26 --> Helper loaded: form_helper
INFO - 2026-07-04 08:02:26 --> Helper loaded: html_helper
INFO - 2026-07-04 08:02:26 --> Helper loaded: file_helper
INFO - 2026-07-04 08:02:26 --> Helper loaded: email_helper
INFO - 2026-07-04 08:02:26 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:02:26 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:02:26 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:02:26 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:02:26 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:02:26 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:02:26 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:02:26 --> Database Driver Class Initialized
INFO - 2026-07-04 08:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:02:27 --> Upload Class Initialized
DEBUG - 2026-07-04 08:02:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:02:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:02:27 --> Encryption Class Initialized
INFO - 2026-07-04 08:02:27 --> Form Validation Class Initialized
INFO - 2026-07-04 08:02:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:02:27 --> Pagination Class Initialized
INFO - 2026-07-04 08:02:27 --> Email Class Initialized
INFO - 2026-07-04 08:02:27 --> Controller Class Initialized
DEBUG - 2026-07-04 08:02:27 --> Cart MX_Controller Initialized
INFO - 2026-07-04 08:02:27 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:02:27 --> Model "Auth_model" initialized
INFO - 2026-07-04 08:02:27 --> Model "Cart_model" initialized
INFO - 2026-07-04 08:02:27 --> Model "Common_model" initialized
INFO - 2026-07-04 08:02:27 --> Model "Order_model" initialized
INFO - 2026-07-04 08:02:27 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 08:02:27 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-04 08:02:27 --> Model "Promocode_model" initialized
DEBUG - 2026-07-04 08:02:27 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-04 08:02:27 --> Model "Plan_model" initialized
INFO - 2026-07-04 08:02:27 --> Model "Orderlicense_model" initialized
INFO - 2026-07-04 08:02:27 --> Final output sent to browser
DEBUG - 2026-07-04 08:02:27 --> Total execution time: 1.8794
INFO - 2026-07-04 08:02:49 --> Config Class Initialized
INFO - 2026-07-04 08:02:49 --> Hooks Class Initialized
DEBUG - 2026-07-04 08:02:49 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:02:49 --> Utf8 Class Initialized
INFO - 2026-07-04 08:02:49 --> URI Class Initialized
INFO - 2026-07-04 08:02:49 --> Router Class Initialized
INFO - 2026-07-04 08:02:49 --> Output Class Initialized
INFO - 2026-07-04 08:02:49 --> Security Class Initialized
DEBUG - 2026-07-04 08:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:02:49 --> CSRF cookie sent
INFO - 2026-07-04 08:02:49 --> Input Class Initialized
INFO - 2026-07-04 08:02:49 --> Language Class Initialized
INFO - 2026-07-04 08:02:49 --> Language Class Initialized
INFO - 2026-07-04 08:02:49 --> Config Class Initialized
INFO - 2026-07-04 08:02:49 --> Loader Class Initialized
INFO - 2026-07-04 08:02:49 --> Helper loaded: url_helper
INFO - 2026-07-04 08:02:49 --> Helper loaded: form_helper
INFO - 2026-07-04 08:02:49 --> Helper loaded: html_helper
INFO - 2026-07-04 08:02:49 --> Helper loaded: file_helper
INFO - 2026-07-04 08:02:49 --> Helper loaded: email_helper
INFO - 2026-07-04 08:02:49 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:02:49 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:02:49 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:02:49 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:02:49 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:02:49 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:02:49 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:02:49 --> Database Driver Class Initialized
INFO - 2026-07-04 08:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:02:50 --> Upload Class Initialized
DEBUG - 2026-07-04 08:02:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:02:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:02:50 --> Encryption Class Initialized
INFO - 2026-07-04 08:02:50 --> Form Validation Class Initialized
INFO - 2026-07-04 08:02:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:02:50 --> Pagination Class Initialized
INFO - 2026-07-04 08:02:50 --> Email Class Initialized
INFO - 2026-07-04 08:02:50 --> Controller Class Initialized
DEBUG - 2026-07-04 08:02:50 --> Subscription MX_Controller Initialized
INFO - 2026-07-04 08:02:50 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:02:50 --> Model "Auth_model" initialized
INFO - 2026-07-04 08:02:50 --> Model "Cart_model" initialized
DEBUG - 2026-07-04 08:02:50 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-04 08:02:50 --> Model "Plan_model" initialized
INFO - 2026-07-04 08:02:50 --> Model "Order_model" initialized
INFO - 2026-07-04 08:02:50 --> Model "Orderlicense_model" initialized
INFO - 2026-07-04 08:02:50 --> Model "Subscription_model" initialized
INFO - 2026-07-04 08:02:50 --> Model "Software_model" initialized
INFO - 2026-07-04 08:42:44 --> Config Class Initialized
INFO - 2026-07-04 08:42:44 --> Hooks Class Initialized
DEBUG - 2026-07-04 08:42:44 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:42:44 --> Utf8 Class Initialized
INFO - 2026-07-04 08:42:44 --> URI Class Initialized
INFO - 2026-07-04 08:42:44 --> Router Class Initialized
INFO - 2026-07-04 08:42:44 --> Output Class Initialized
INFO - 2026-07-04 08:42:44 --> Security Class Initialized
DEBUG - 2026-07-04 08:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:42:44 --> CSRF cookie sent
INFO - 2026-07-04 08:42:44 --> Input Class Initialized
INFO - 2026-07-04 08:42:44 --> Language Class Initialized
INFO - 2026-07-04 08:42:44 --> Language Class Initialized
INFO - 2026-07-04 08:42:44 --> Config Class Initialized
INFO - 2026-07-04 08:42:44 --> Loader Class Initialized
INFO - 2026-07-04 08:42:44 --> Helper loaded: url_helper
INFO - 2026-07-04 08:42:44 --> Helper loaded: form_helper
INFO - 2026-07-04 08:42:44 --> Helper loaded: html_helper
INFO - 2026-07-04 08:42:44 --> Helper loaded: file_helper
INFO - 2026-07-04 08:42:44 --> Helper loaded: email_helper
INFO - 2026-07-04 08:42:44 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:42:44 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:42:44 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:42:44 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:42:44 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:42:44 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:42:44 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:42:44 --> Database Driver Class Initialized
INFO - 2026-07-04 08:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:42:46 --> Upload Class Initialized
DEBUG - 2026-07-04 08:42:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:42:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:42:46 --> Encryption Class Initialized
INFO - 2026-07-04 08:42:46 --> Form Validation Class Initialized
INFO - 2026-07-04 08:42:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:42:46 --> Pagination Class Initialized
INFO - 2026-07-04 08:42:46 --> Email Class Initialized
INFO - 2026-07-04 08:42:46 --> Controller Class Initialized
DEBUG - 2026-07-04 08:42:46 --> Auth MX_Controller Initialized
INFO - 2026-07-04 08:42:46 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:42:46 --> Model "Auth_model" initialized
INFO - 2026-07-04 08:42:46 --> Model "Cart_model" initialized
INFO - 2026-07-04 08:42:46 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 08:42:46 --> Config Class Initialized
INFO - 2026-07-04 08:42:46 --> Hooks Class Initialized
DEBUG - 2026-07-04 08:42:46 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:42:46 --> Utf8 Class Initialized
INFO - 2026-07-04 08:42:46 --> URI Class Initialized
INFO - 2026-07-04 08:42:46 --> Router Class Initialized
INFO - 2026-07-04 08:42:46 --> Output Class Initialized
INFO - 2026-07-04 08:42:46 --> Security Class Initialized
DEBUG - 2026-07-04 08:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:42:46 --> CSRF cookie sent
INFO - 2026-07-04 08:42:46 --> Input Class Initialized
INFO - 2026-07-04 08:42:46 --> Language Class Initialized
INFO - 2026-07-04 08:42:46 --> Language Class Initialized
INFO - 2026-07-04 08:42:46 --> Config Class Initialized
INFO - 2026-07-04 08:42:46 --> Loader Class Initialized
INFO - 2026-07-04 08:42:46 --> Helper loaded: url_helper
INFO - 2026-07-04 08:42:46 --> Helper loaded: form_helper
INFO - 2026-07-04 08:42:46 --> Helper loaded: html_helper
INFO - 2026-07-04 08:42:46 --> Helper loaded: file_helper
INFO - 2026-07-04 08:42:46 --> Helper loaded: email_helper
INFO - 2026-07-04 08:42:46 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:42:46 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:42:46 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:42:46 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:42:46 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:42:46 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:42:46 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:42:46 --> Database Driver Class Initialized
INFO - 2026-07-04 08:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:42:49 --> Upload Class Initialized
DEBUG - 2026-07-04 08:42:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:42:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:42:49 --> Encryption Class Initialized
INFO - 2026-07-04 08:42:49 --> Form Validation Class Initialized
INFO - 2026-07-04 08:42:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:42:50 --> Pagination Class Initialized
INFO - 2026-07-04 08:42:50 --> Email Class Initialized
INFO - 2026-07-04 08:42:50 --> Controller Class Initialized
DEBUG - 2026-07-04 08:42:50 --> Auth MX_Controller Initialized
INFO - 2026-07-04 08:42:50 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:42:50 --> Model "Auth_model" initialized
INFO - 2026-07-04 08:42:50 --> Model "Cart_model" initialized
INFO - 2026-07-04 08:42:50 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-04 08:42:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-04 08:42:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-04 08:42:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-04 08:42:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-07-04 08:42:50 --> Final output sent to browser
DEBUG - 2026-07-04 08:42:50 --> Total execution time: 3.7635
INFO - 2026-07-04 08:42:50 --> Config Class Initialized
INFO - 2026-07-04 08:42:50 --> Hooks Class Initialized
DEBUG - 2026-07-04 08:42:50 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:42:50 --> Utf8 Class Initialized
INFO - 2026-07-04 08:42:50 --> URI Class Initialized
INFO - 2026-07-04 08:42:50 --> Router Class Initialized
INFO - 2026-07-04 08:42:50 --> Output Class Initialized
INFO - 2026-07-04 08:42:50 --> Security Class Initialized
DEBUG - 2026-07-04 08:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:42:50 --> CSRF cookie sent
INFO - 2026-07-04 08:42:50 --> Input Class Initialized
INFO - 2026-07-04 08:42:50 --> Language Class Initialized
INFO - 2026-07-04 08:42:50 --> Language Class Initialized
INFO - 2026-07-04 08:42:50 --> Config Class Initialized
INFO - 2026-07-04 08:42:50 --> Loader Class Initialized
INFO - 2026-07-04 08:42:50 --> Helper loaded: url_helper
INFO - 2026-07-04 08:42:50 --> Helper loaded: form_helper
INFO - 2026-07-04 08:42:50 --> Helper loaded: html_helper
INFO - 2026-07-04 08:42:50 --> Helper loaded: file_helper
INFO - 2026-07-04 08:42:50 --> Helper loaded: email_helper
INFO - 2026-07-04 08:42:50 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:42:50 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:42:50 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:42:50 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:42:50 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:42:50 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:42:50 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:42:50 --> Database Driver Class Initialized
INFO - 2026-07-04 08:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:42:52 --> Upload Class Initialized
DEBUG - 2026-07-04 08:42:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:42:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:42:52 --> Encryption Class Initialized
INFO - 2026-07-04 08:42:52 --> Form Validation Class Initialized
INFO - 2026-07-04 08:42:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:42:52 --> Pagination Class Initialized
INFO - 2026-07-04 08:42:52 --> Email Class Initialized
INFO - 2026-07-04 08:42:52 --> Controller Class Initialized
DEBUG - 2026-07-04 08:42:52 --> Cart MX_Controller Initialized
INFO - 2026-07-04 08:42:52 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:42:52 --> Model "Auth_model" initialized
INFO - 2026-07-04 08:42:52 --> Model "Cart_model" initialized
INFO - 2026-07-04 08:42:52 --> Model "Common_model" initialized
INFO - 2026-07-04 08:42:52 --> Model "Order_model" initialized
INFO - 2026-07-04 08:42:52 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 08:42:52 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-04 08:42:52 --> Model "Promocode_model" initialized
DEBUG - 2026-07-04 08:42:52 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-04 08:42:52 --> Model "Plan_model" initialized
INFO - 2026-07-04 08:42:52 --> Model "Orderlicense_model" initialized
INFO - 2026-07-04 08:42:53 --> Final output sent to browser
DEBUG - 2026-07-04 08:42:53 --> Total execution time: 2.2262
INFO - 2026-07-04 08:43:00 --> Config Class Initialized
INFO - 2026-07-04 08:43:00 --> Hooks Class Initialized
DEBUG - 2026-07-04 08:43:00 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:43:00 --> Utf8 Class Initialized
INFO - 2026-07-04 08:43:00 --> URI Class Initialized
INFO - 2026-07-04 08:43:00 --> Router Class Initialized
INFO - 2026-07-04 08:43:00 --> Output Class Initialized
INFO - 2026-07-04 08:43:00 --> Security Class Initialized
DEBUG - 2026-07-04 08:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:43:00 --> CSRF cookie sent
INFO - 2026-07-04 08:43:00 --> Input Class Initialized
INFO - 2026-07-04 08:43:00 --> Language Class Initialized
INFO - 2026-07-04 08:43:00 --> Language Class Initialized
INFO - 2026-07-04 08:43:00 --> Config Class Initialized
INFO - 2026-07-04 08:43:00 --> Loader Class Initialized
INFO - 2026-07-04 08:43:00 --> Helper loaded: url_helper
INFO - 2026-07-04 08:43:00 --> Helper loaded: form_helper
INFO - 2026-07-04 08:43:00 --> Helper loaded: html_helper
INFO - 2026-07-04 08:43:00 --> Helper loaded: file_helper
INFO - 2026-07-04 08:43:00 --> Helper loaded: email_helper
INFO - 2026-07-04 08:43:00 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:43:00 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:43:00 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:43:00 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:43:00 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:43:00 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:43:00 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:43:00 --> Database Driver Class Initialized
INFO - 2026-07-04 08:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:43:02 --> Upload Class Initialized
DEBUG - 2026-07-04 08:43:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:43:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:43:02 --> Encryption Class Initialized
INFO - 2026-07-04 08:43:02 --> Form Validation Class Initialized
INFO - 2026-07-04 08:43:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:43:02 --> Pagination Class Initialized
INFO - 2026-07-04 08:43:02 --> Email Class Initialized
INFO - 2026-07-04 08:43:02 --> Controller Class Initialized
DEBUG - 2026-07-04 08:43:02 --> Dashboard MX_Controller Initialized
INFO - 2026-07-04 08:43:02 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:43:02 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 08:43:02 --> Config Class Initialized
INFO - 2026-07-04 08:43:02 --> Hooks Class Initialized
DEBUG - 2026-07-04 08:43:02 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:43:02 --> Utf8 Class Initialized
INFO - 2026-07-04 08:43:02 --> URI Class Initialized
INFO - 2026-07-04 08:43:02 --> Router Class Initialized
INFO - 2026-07-04 08:43:02 --> Output Class Initialized
INFO - 2026-07-04 08:43:02 --> Security Class Initialized
DEBUG - 2026-07-04 08:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:43:02 --> CSRF cookie sent
INFO - 2026-07-04 08:43:02 --> Input Class Initialized
INFO - 2026-07-04 08:43:02 --> Language Class Initialized
INFO - 2026-07-04 08:43:02 --> Language Class Initialized
INFO - 2026-07-04 08:43:02 --> Config Class Initialized
INFO - 2026-07-04 08:43:02 --> Loader Class Initialized
INFO - 2026-07-04 08:43:02 --> Helper loaded: url_helper
INFO - 2026-07-04 08:43:02 --> Helper loaded: form_helper
INFO - 2026-07-04 08:43:02 --> Helper loaded: html_helper
INFO - 2026-07-04 08:43:02 --> Helper loaded: file_helper
INFO - 2026-07-04 08:43:02 --> Helper loaded: email_helper
INFO - 2026-07-04 08:43:02 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:43:02 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:43:02 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:43:02 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:43:02 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:43:02 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:43:02 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:43:02 --> Database Driver Class Initialized
INFO - 2026-07-04 08:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:43:04 --> Upload Class Initialized
DEBUG - 2026-07-04 08:43:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:43:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:43:04 --> Encryption Class Initialized
INFO - 2026-07-04 08:43:04 --> Form Validation Class Initialized
INFO - 2026-07-04 08:43:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:43:04 --> Pagination Class Initialized
INFO - 2026-07-04 08:43:04 --> Email Class Initialized
INFO - 2026-07-04 08:43:04 --> Controller Class Initialized
DEBUG - 2026-07-04 08:43:04 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 08:43:04 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:43:04 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 08:43:04 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-04 08:43:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-04 08:43:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-04 08:43:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-07-04 08:43:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-04 08:43:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-04 08:43:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-07-04 08:43:04 --> Final output sent to browser
DEBUG - 2026-07-04 08:43:04 --> Total execution time: 2.3027
INFO - 2026-07-04 08:43:12 --> Config Class Initialized
INFO - 2026-07-04 08:43:12 --> Hooks Class Initialized
DEBUG - 2026-07-04 08:43:12 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:43:12 --> Utf8 Class Initialized
INFO - 2026-07-04 08:43:12 --> URI Class Initialized
INFO - 2026-07-04 08:43:12 --> Router Class Initialized
INFO - 2026-07-04 08:43:12 --> Output Class Initialized
INFO - 2026-07-04 08:43:12 --> Security Class Initialized
DEBUG - 2026-07-04 08:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:43:12 --> CSRF cookie sent
INFO - 2026-07-04 08:43:12 --> CSRF token verified
INFO - 2026-07-04 08:43:12 --> Input Class Initialized
INFO - 2026-07-04 08:43:12 --> Language Class Initialized
INFO - 2026-07-04 08:43:12 --> Language Class Initialized
INFO - 2026-07-04 08:43:12 --> Config Class Initialized
INFO - 2026-07-04 08:43:12 --> Loader Class Initialized
INFO - 2026-07-04 08:43:12 --> Helper loaded: url_helper
INFO - 2026-07-04 08:43:12 --> Helper loaded: form_helper
INFO - 2026-07-04 08:43:12 --> Helper loaded: html_helper
INFO - 2026-07-04 08:43:12 --> Helper loaded: file_helper
INFO - 2026-07-04 08:43:12 --> Helper loaded: email_helper
INFO - 2026-07-04 08:43:12 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:43:12 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:43:12 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:43:12 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:43:12 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:43:12 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:43:12 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:43:12 --> Database Driver Class Initialized
INFO - 2026-07-04 08:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:43:14 --> Upload Class Initialized
DEBUG - 2026-07-04 08:43:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:43:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:43:14 --> Encryption Class Initialized
INFO - 2026-07-04 08:43:14 --> Form Validation Class Initialized
INFO - 2026-07-04 08:43:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:43:14 --> Pagination Class Initialized
INFO - 2026-07-04 08:43:14 --> Email Class Initialized
INFO - 2026-07-04 08:43:14 --> Controller Class Initialized
DEBUG - 2026-07-04 08:43:14 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 08:43:14 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:43:14 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 08:43:14 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-04 08:43:16 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-04 08:43:16 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-04 08:43:16 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-07-04 08:43:16 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-04 08:43:16 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-04 08:43:16 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-07-04 08:43:16 --> Final output sent to browser
DEBUG - 2026-07-04 08:43:16 --> Total execution time: 3.5760
INFO - 2026-07-04 08:43:44 --> Config Class Initialized
INFO - 2026-07-04 08:43:44 --> Hooks Class Initialized
DEBUG - 2026-07-04 08:43:44 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:43:44 --> Utf8 Class Initialized
INFO - 2026-07-04 08:43:44 --> URI Class Initialized
INFO - 2026-07-04 08:43:44 --> Router Class Initialized
INFO - 2026-07-04 08:43:44 --> Output Class Initialized
INFO - 2026-07-04 08:43:44 --> Security Class Initialized
DEBUG - 2026-07-04 08:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:43:44 --> CSRF cookie sent
INFO - 2026-07-04 08:43:44 --> CSRF token verified
INFO - 2026-07-04 08:43:44 --> Input Class Initialized
INFO - 2026-07-04 08:43:44 --> Language Class Initialized
INFO - 2026-07-04 08:43:44 --> Language Class Initialized
INFO - 2026-07-04 08:43:44 --> Config Class Initialized
INFO - 2026-07-04 08:43:44 --> Loader Class Initialized
INFO - 2026-07-04 08:43:44 --> Helper loaded: url_helper
INFO - 2026-07-04 08:43:44 --> Helper loaded: form_helper
INFO - 2026-07-04 08:43:44 --> Helper loaded: html_helper
INFO - 2026-07-04 08:43:44 --> Helper loaded: file_helper
INFO - 2026-07-04 08:43:44 --> Helper loaded: email_helper
INFO - 2026-07-04 08:43:44 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:43:44 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:43:44 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:43:44 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:43:44 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:43:44 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:43:44 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:43:44 --> Database Driver Class Initialized
INFO - 2026-07-04 08:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:43:46 --> Upload Class Initialized
DEBUG - 2026-07-04 08:43:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:43:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:43:46 --> Encryption Class Initialized
INFO - 2026-07-04 08:43:46 --> Form Validation Class Initialized
INFO - 2026-07-04 08:43:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:43:46 --> Pagination Class Initialized
INFO - 2026-07-04 08:43:46 --> Email Class Initialized
INFO - 2026-07-04 08:43:46 --> Controller Class Initialized
DEBUG - 2026-07-04 08:43:46 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 08:43:46 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:43:46 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 08:43:46 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 08:43:51 --> Config Class Initialized
INFO - 2026-07-04 08:43:51 --> Hooks Class Initialized
DEBUG - 2026-07-04 08:43:51 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:43:51 --> Utf8 Class Initialized
INFO - 2026-07-04 08:43:51 --> URI Class Initialized
INFO - 2026-07-04 08:43:51 --> Router Class Initialized
INFO - 2026-07-04 08:43:51 --> Output Class Initialized
INFO - 2026-07-04 08:43:51 --> Security Class Initialized
DEBUG - 2026-07-04 08:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:43:51 --> CSRF cookie sent
INFO - 2026-07-04 08:43:51 --> Input Class Initialized
INFO - 2026-07-04 08:43:51 --> Language Class Initialized
INFO - 2026-07-04 08:43:51 --> Language Class Initialized
INFO - 2026-07-04 08:43:51 --> Config Class Initialized
INFO - 2026-07-04 08:43:51 --> Loader Class Initialized
INFO - 2026-07-04 08:43:51 --> Helper loaded: url_helper
INFO - 2026-07-04 08:43:51 --> Helper loaded: form_helper
INFO - 2026-07-04 08:43:51 --> Helper loaded: html_helper
INFO - 2026-07-04 08:43:51 --> Helper loaded: file_helper
INFO - 2026-07-04 08:43:51 --> Helper loaded: email_helper
INFO - 2026-07-04 08:43:51 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:43:51 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:43:51 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:43:51 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:43:51 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:43:51 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:43:51 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:43:51 --> Database Driver Class Initialized
INFO - 2026-07-04 08:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:43:53 --> Upload Class Initialized
DEBUG - 2026-07-04 08:43:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:43:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:43:53 --> Encryption Class Initialized
INFO - 2026-07-04 08:43:53 --> Form Validation Class Initialized
INFO - 2026-07-04 08:43:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:43:53 --> Pagination Class Initialized
INFO - 2026-07-04 08:43:53 --> Email Class Initialized
INFO - 2026-07-04 08:43:53 --> Controller Class Initialized
DEBUG - 2026-07-04 08:43:53 --> Dashboard MX_Controller Initialized
INFO - 2026-07-04 08:43:53 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:43:53 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 08:43:53 --> Model "Dashboard_model" initialized
DEBUG - 2026-07-04 08:43:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-04 08:43:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-04 08:43:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-04 08:43:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-04 08:43:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-04 08:43:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/dashboard_index.php
INFO - 2026-07-04 08:43:53 --> Final output sent to browser
DEBUG - 2026-07-04 08:43:53 --> Total execution time: 2.3133
INFO - 2026-07-04 08:43:53 --> Config Class Initialized
INFO - 2026-07-04 08:43:53 --> Hooks Class Initialized
INFO - 2026-07-04 08:43:53 --> Config Class Initialized
INFO - 2026-07-04 08:43:53 --> Hooks Class Initialized
INFO - 2026-07-04 08:43:53 --> Config Class Initialized
INFO - 2026-07-04 08:43:53 --> Hooks Class Initialized
DEBUG - 2026-07-04 08:43:53 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:43:53 --> Utf8 Class Initialized
DEBUG - 2026-07-04 08:43:53 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:43:53 --> Utf8 Class Initialized
INFO - 2026-07-04 08:43:53 --> URI Class Initialized
DEBUG - 2026-07-04 08:43:53 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:43:53 --> URI Class Initialized
INFO - 2026-07-04 08:43:53 --> Router Class Initialized
INFO - 2026-07-04 08:43:53 --> Output Class Initialized
INFO - 2026-07-04 08:43:53 --> Router Class Initialized
INFO - 2026-07-04 08:43:53 --> Security Class Initialized
INFO - 2026-07-04 08:43:53 --> Utf8 Class Initialized
INFO - 2026-07-04 08:43:53 --> Output Class Initialized
DEBUG - 2026-07-04 08:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:43:53 --> Input Class Initialized
INFO - 2026-07-04 08:43:53 --> Language Class Initialized
INFO - 2026-07-04 08:43:53 --> Config Class Initialized
INFO - 2026-07-04 08:43:53 --> Hooks Class Initialized
INFO - 2026-07-04 08:43:53 --> URI Class Initialized
INFO - 2026-07-04 08:43:53 --> Language Class Initialized
INFO - 2026-07-04 08:43:53 --> Config Class Initialized
INFO - 2026-07-04 08:43:53 --> Security Class Initialized
DEBUG - 2026-07-04 08:43:53 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:43:53 --> Utf8 Class Initialized
INFO - 2026-07-04 08:43:53 --> Router Class Initialized
DEBUG - 2026-07-04 08:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:43:53 --> URI Class Initialized
INFO - 2026-07-04 08:43:53 --> Input Class Initialized
INFO - 2026-07-04 08:43:53 --> Language Class Initialized
INFO - 2026-07-04 08:43:53 --> Loader Class Initialized
INFO - 2026-07-04 08:43:53 --> Output Class Initialized
INFO - 2026-07-04 08:43:53 --> Language Class Initialized
INFO - 2026-07-04 08:43:53 --> Config Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: url_helper
INFO - 2026-07-04 08:43:53 --> Router Class Initialized
INFO - 2026-07-04 08:43:53 --> Security Class Initialized
INFO - 2026-07-04 08:43:53 --> Config Class Initialized
INFO - 2026-07-04 08:43:53 --> Hooks Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: form_helper
INFO - 2026-07-04 08:43:53 --> Output Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: html_helper
DEBUG - 2026-07-04 08:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:43:53 --> Input Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: file_helper
DEBUG - 2026-07-04 08:43:53 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:43:53 --> Loader Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: email_helper
INFO - 2026-07-04 08:43:53 --> Language Class Initialized
INFO - 2026-07-04 08:43:53 --> Security Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: url_helper
INFO - 2026-07-04 08:43:53 --> Language Class Initialized
INFO - 2026-07-04 08:43:53 --> Config Class Initialized
DEBUG - 2026-07-04 08:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:43:53 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:43:53 --> Input Class Initialized
INFO - 2026-07-04 08:43:53 --> Config Class Initialized
INFO - 2026-07-04 08:43:53 --> Hooks Class Initialized
INFO - 2026-07-04 08:43:53 --> Utf8 Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: form_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: html_helper
INFO - 2026-07-04 08:43:53 --> URI Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: file_helper
DEBUG - 2026-07-04 08:43:53 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:43:53 --> Utf8 Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: email_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:43:53 --> Loader Class Initialized
INFO - 2026-07-04 08:43:53 --> URI Class Initialized
INFO - 2026-07-04 08:43:53 --> Router Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: url_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:43:53 --> Language Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: form_helper
INFO - 2026-07-04 08:43:53 --> Router Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:43:53 --> Language Class Initialized
INFO - 2026-07-04 08:43:53 --> Config Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: html_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:43:53 --> Output Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: file_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: email_helper
INFO - 2026-07-04 08:43:53 --> Output Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:43:53 --> Security Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: directadmin_helper
DEBUG - 2026-07-04 08:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:43:53 --> Input Class Initialized
INFO - 2026-07-04 08:43:53 --> Loader Class Initialized
INFO - 2026-07-04 08:43:53 --> Language Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: url_helper
INFO - 2026-07-04 08:43:53 --> Language Class Initialized
INFO - 2026-07-04 08:43:53 --> Config Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: form_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: html_helper
INFO - 2026-07-04 08:43:53 --> Security Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: file_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: email_helper
INFO - 2026-07-04 08:43:53 --> Loader Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: directadmin_helper
DEBUG - 2026-07-04 08:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:43:53 --> Input Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: url_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:43:53 --> Language Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:43:53 --> Language Class Initialized
INFO - 2026-07-04 08:43:53 --> Config Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: form_helper
INFO - 2026-07-04 08:43:53 --> Database Driver Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: html_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: file_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: email_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:43:53 --> Loader Class Initialized
INFO - 2026-07-04 08:43:53 --> Database Driver Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: url_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:43:53 --> Database Driver Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: form_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: html_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: file_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: email_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:43:53 --> Database Driver Class Initialized
INFO - 2026-07-04 08:43:53 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:43:53 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:43:53 --> Database Driver Class Initialized
INFO - 2026-07-04 08:43:53 --> Database Driver Class Initialized
INFO - 2026-07-04 08:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:43:55 --> Upload Class Initialized
DEBUG - 2026-07-04 08:43:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:43:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:43:55 --> Encryption Class Initialized
INFO - 2026-07-04 08:43:55 --> Form Validation Class Initialized
INFO - 2026-07-04 08:43:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:43:55 --> Pagination Class Initialized
INFO - 2026-07-04 08:43:55 --> Email Class Initialized
INFO - 2026-07-04 08:43:55 --> Controller Class Initialized
DEBUG - 2026-07-04 08:43:55 --> Ticket MX_Controller Initialized
INFO - 2026-07-04 08:43:55 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:43:55 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 08:43:55 --> Model "Support_model" initialized
INFO - 2026-07-04 08:43:55 --> Model "Common_model" initialized
INFO - 2026-07-04 08:43:56 --> Final output sent to browser
DEBUG - 2026-07-04 08:43:56 --> Total execution time: 2.7469
INFO - 2026-07-04 08:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:43:56 --> Upload Class Initialized
DEBUG - 2026-07-04 08:43:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:43:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:43:56 --> Encryption Class Initialized
INFO - 2026-07-04 08:43:56 --> Form Validation Class Initialized
INFO - 2026-07-04 08:43:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:43:56 --> Pagination Class Initialized
INFO - 2026-07-04 08:43:56 --> Email Class Initialized
INFO - 2026-07-04 08:43:56 --> Controller Class Initialized
DEBUG - 2026-07-04 08:43:56 --> Dashboard MX_Controller Initialized
INFO - 2026-07-04 08:43:56 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:43:56 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 08:43:56 --> Model "Dashboard_model" initialized
INFO - 2026-07-04 08:43:57 --> Final output sent to browser
DEBUG - 2026-07-04 08:43:57 --> Total execution time: 3.5922
INFO - 2026-07-04 08:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:43:57 --> Upload Class Initialized
DEBUG - 2026-07-04 08:43:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:43:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:43:57 --> Encryption Class Initialized
INFO - 2026-07-04 08:43:57 --> Form Validation Class Initialized
INFO - 2026-07-04 08:43:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:43:57 --> Pagination Class Initialized
INFO - 2026-07-04 08:43:57 --> Email Class Initialized
INFO - 2026-07-04 08:43:57 --> Controller Class Initialized
DEBUG - 2026-07-04 08:43:57 --> Invoice MX_Controller Initialized
INFO - 2026-07-04 08:43:57 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:43:57 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 08:43:57 --> Model "Billing_model" initialized
INFO - 2026-07-04 08:43:57 --> Model "Common_model" initialized
INFO - 2026-07-04 08:43:57 --> Model "Invoice_model" initialized
INFO - 2026-07-04 08:43:57 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 08:43:58 --> Final output sent to browser
DEBUG - 2026-07-04 08:43:58 --> Total execution time: 4.3984
INFO - 2026-07-04 08:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:43:58 --> Upload Class Initialized
DEBUG - 2026-07-04 08:43:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:43:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:43:58 --> Encryption Class Initialized
INFO - 2026-07-04 08:43:58 --> Form Validation Class Initialized
INFO - 2026-07-04 08:43:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:43:58 --> Pagination Class Initialized
INFO - 2026-07-04 08:43:58 --> Email Class Initialized
INFO - 2026-07-04 08:43:58 --> Controller Class Initialized
DEBUG - 2026-07-04 08:43:58 --> Dashboard MX_Controller Initialized
INFO - 2026-07-04 08:43:58 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:43:58 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 08:43:59 --> Model "Dashboard_model" initialized
INFO - 2026-07-04 08:43:59 --> Final output sent to browser
DEBUG - 2026-07-04 08:43:59 --> Total execution time: 6.1259
INFO - 2026-07-04 08:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:43:59 --> Upload Class Initialized
DEBUG - 2026-07-04 08:43:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:43:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:43:59 --> Encryption Class Initialized
INFO - 2026-07-04 08:43:59 --> Form Validation Class Initialized
INFO - 2026-07-04 08:43:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:43:59 --> Pagination Class Initialized
INFO - 2026-07-04 08:43:59 --> Email Class Initialized
INFO - 2026-07-04 08:43:59 --> Controller Class Initialized
DEBUG - 2026-07-04 08:43:59 --> Dashboard MX_Controller Initialized
INFO - 2026-07-04 08:43:59 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:43:59 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 08:44:00 --> Model "Dashboard_model" initialized
INFO - 2026-07-04 08:44:00 --> Final output sent to browser
DEBUG - 2026-07-04 08:44:00 --> Total execution time: 6.9475
INFO - 2026-07-04 08:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:44:00 --> Upload Class Initialized
DEBUG - 2026-07-04 08:44:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:44:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:44:00 --> Encryption Class Initialized
INFO - 2026-07-04 08:44:00 --> Form Validation Class Initialized
INFO - 2026-07-04 08:44:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:44:00 --> Pagination Class Initialized
INFO - 2026-07-04 08:44:00 --> Email Class Initialized
INFO - 2026-07-04 08:44:00 --> Controller Class Initialized
DEBUG - 2026-07-04 08:44:00 --> Order MX_Controller Initialized
INFO - 2026-07-04 08:44:00 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:44:00 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 08:44:00 --> Model "Order_model" initialized
INFO - 2026-07-04 08:44:00 --> Model "Common_model" initialized
INFO - 2026-07-04 08:44:00 --> Model "Currency_model" initialized
INFO - 2026-07-04 08:44:01 --> Final output sent to browser
DEBUG - 2026-07-04 08:44:01 --> Total execution time: 7.6688
INFO - 2026-07-04 08:44:10 --> Config Class Initialized
INFO - 2026-07-04 08:44:10 --> Hooks Class Initialized
DEBUG - 2026-07-04 08:44:10 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:44:10 --> Utf8 Class Initialized
INFO - 2026-07-04 08:44:10 --> URI Class Initialized
INFO - 2026-07-04 08:44:10 --> Router Class Initialized
INFO - 2026-07-04 08:44:10 --> Output Class Initialized
INFO - 2026-07-04 08:44:10 --> Security Class Initialized
DEBUG - 2026-07-04 08:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:44:10 --> CSRF cookie sent
INFO - 2026-07-04 08:44:10 --> Input Class Initialized
INFO - 2026-07-04 08:44:10 --> Language Class Initialized
INFO - 2026-07-04 08:44:10 --> Language Class Initialized
INFO - 2026-07-04 08:44:10 --> Config Class Initialized
INFO - 2026-07-04 08:44:10 --> Loader Class Initialized
INFO - 2026-07-04 08:44:10 --> Helper loaded: url_helper
INFO - 2026-07-04 08:44:10 --> Helper loaded: form_helper
INFO - 2026-07-04 08:44:10 --> Helper loaded: html_helper
INFO - 2026-07-04 08:44:10 --> Helper loaded: file_helper
INFO - 2026-07-04 08:44:10 --> Helper loaded: email_helper
INFO - 2026-07-04 08:44:10 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:44:10 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:44:10 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:44:10 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:44:10 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:44:10 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:44:10 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:44:10 --> Database Driver Class Initialized
INFO - 2026-07-04 08:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:44:12 --> Upload Class Initialized
DEBUG - 2026-07-04 08:44:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:44:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:44:12 --> Encryption Class Initialized
INFO - 2026-07-04 08:44:12 --> Form Validation Class Initialized
INFO - 2026-07-04 08:44:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:44:12 --> Pagination Class Initialized
INFO - 2026-07-04 08:44:12 --> Email Class Initialized
INFO - 2026-07-04 08:44:12 --> Controller Class Initialized
DEBUG - 2026-07-04 08:44:12 --> Company MX_Controller Initialized
INFO - 2026-07-04 08:44:12 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:44:12 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 08:44:12 --> Model "Company_model" initialized
INFO - 2026-07-04 08:44:12 --> Model "Common_model" initialized
DEBUG - 2026-07-04 08:44:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-04 08:44:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-04 08:44:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-04 08:44:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-04 08:44:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-04 08:44:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/company_list.php
INFO - 2026-07-04 08:44:13 --> Final output sent to browser
DEBUG - 2026-07-04 08:44:13 --> Total execution time: 2.4456
INFO - 2026-07-04 08:44:13 --> Config Class Initialized
INFO - 2026-07-04 08:44:13 --> Hooks Class Initialized
DEBUG - 2026-07-04 08:44:13 --> UTF-8 Support Enabled
INFO - 2026-07-04 08:44:13 --> Utf8 Class Initialized
INFO - 2026-07-04 08:44:13 --> URI Class Initialized
INFO - 2026-07-04 08:44:13 --> Router Class Initialized
INFO - 2026-07-04 08:44:13 --> Output Class Initialized
INFO - 2026-07-04 08:44:13 --> Security Class Initialized
DEBUG - 2026-07-04 08:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 08:44:13 --> CSRF cookie sent
INFO - 2026-07-04 08:44:13 --> Input Class Initialized
INFO - 2026-07-04 08:44:13 --> Language Class Initialized
INFO - 2026-07-04 08:44:13 --> Language Class Initialized
INFO - 2026-07-04 08:44:13 --> Config Class Initialized
INFO - 2026-07-04 08:44:13 --> Loader Class Initialized
INFO - 2026-07-04 08:44:13 --> Helper loaded: url_helper
INFO - 2026-07-04 08:44:13 --> Helper loaded: form_helper
INFO - 2026-07-04 08:44:13 --> Helper loaded: html_helper
INFO - 2026-07-04 08:44:13 --> Helper loaded: file_helper
INFO - 2026-07-04 08:44:13 --> Helper loaded: email_helper
INFO - 2026-07-04 08:44:13 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 08:44:13 --> Helper loaded: ssp_helper
INFO - 2026-07-04 08:44:13 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 08:44:13 --> Helper loaded: plesk_helper
INFO - 2026-07-04 08:44:13 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 08:44:13 --> Helper loaded: domain_helper
INFO - 2026-07-04 08:44:13 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 08:44:13 --> Database Driver Class Initialized
INFO - 2026-07-04 08:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 08:44:15 --> Upload Class Initialized
DEBUG - 2026-07-04 08:44:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 08:44:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 08:44:15 --> Encryption Class Initialized
INFO - 2026-07-04 08:44:15 --> Form Validation Class Initialized
INFO - 2026-07-04 08:44:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 08:44:15 --> Pagination Class Initialized
INFO - 2026-07-04 08:44:15 --> Email Class Initialized
INFO - 2026-07-04 08:44:15 --> Controller Class Initialized
DEBUG - 2026-07-04 08:44:15 --> Company MX_Controller Initialized
INFO - 2026-07-04 08:44:15 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 08:44:15 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 08:44:15 --> Model "Company_model" initialized
INFO - 2026-07-04 08:44:15 --> Model "Common_model" initialized
INFO - 2026-07-04 09:24:28 --> Config Class Initialized
INFO - 2026-07-04 09:24:28 --> Hooks Class Initialized
DEBUG - 2026-07-04 09:24:28 --> UTF-8 Support Enabled
INFO - 2026-07-04 09:24:28 --> Utf8 Class Initialized
INFO - 2026-07-04 09:24:28 --> URI Class Initialized
INFO - 2026-07-04 09:24:28 --> Router Class Initialized
INFO - 2026-07-04 09:24:28 --> Output Class Initialized
INFO - 2026-07-04 09:24:28 --> Security Class Initialized
DEBUG - 2026-07-04 09:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 09:24:28 --> CSRF cookie sent
INFO - 2026-07-04 09:24:28 --> Input Class Initialized
INFO - 2026-07-04 09:24:28 --> Language Class Initialized
INFO - 2026-07-04 09:24:28 --> Language Class Initialized
INFO - 2026-07-04 09:24:28 --> Config Class Initialized
INFO - 2026-07-04 09:24:28 --> Loader Class Initialized
INFO - 2026-07-04 09:24:28 --> Helper loaded: url_helper
INFO - 2026-07-04 09:24:28 --> Helper loaded: form_helper
INFO - 2026-07-04 09:24:28 --> Helper loaded: html_helper
INFO - 2026-07-04 09:24:28 --> Helper loaded: file_helper
INFO - 2026-07-04 09:24:28 --> Helper loaded: email_helper
INFO - 2026-07-04 09:24:28 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 09:24:28 --> Helper loaded: ssp_helper
INFO - 2026-07-04 09:24:28 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 09:24:28 --> Helper loaded: plesk_helper
INFO - 2026-07-04 09:24:28 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 09:24:28 --> Helper loaded: domain_helper
INFO - 2026-07-04 09:24:28 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 09:24:28 --> Database Driver Class Initialized
INFO - 2026-07-04 09:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 09:24:30 --> Upload Class Initialized
DEBUG - 2026-07-04 09:24:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 09:24:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 09:24:30 --> Encryption Class Initialized
INFO - 2026-07-04 09:24:30 --> Form Validation Class Initialized
INFO - 2026-07-04 09:24:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 09:24:30 --> Pagination Class Initialized
INFO - 2026-07-04 09:24:30 --> Email Class Initialized
INFO - 2026-07-04 09:24:30 --> Controller Class Initialized
DEBUG - 2026-07-04 09:24:30 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 09:24:30 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 09:24:30 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 09:24:30 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 09:24:30 --> Config Class Initialized
INFO - 2026-07-04 09:24:30 --> Hooks Class Initialized
DEBUG - 2026-07-04 09:24:30 --> UTF-8 Support Enabled
INFO - 2026-07-04 09:24:30 --> Utf8 Class Initialized
INFO - 2026-07-04 09:24:30 --> URI Class Initialized
INFO - 2026-07-04 09:24:30 --> Router Class Initialized
INFO - 2026-07-04 09:24:30 --> Output Class Initialized
INFO - 2026-07-04 09:24:30 --> Security Class Initialized
DEBUG - 2026-07-04 09:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 09:24:30 --> CSRF cookie sent
INFO - 2026-07-04 09:24:30 --> Input Class Initialized
INFO - 2026-07-04 09:24:30 --> Language Class Initialized
INFO - 2026-07-04 09:24:30 --> Language Class Initialized
INFO - 2026-07-04 09:24:30 --> Config Class Initialized
INFO - 2026-07-04 09:24:30 --> Loader Class Initialized
INFO - 2026-07-04 09:24:30 --> Helper loaded: url_helper
INFO - 2026-07-04 09:24:30 --> Helper loaded: form_helper
INFO - 2026-07-04 09:24:30 --> Helper loaded: html_helper
INFO - 2026-07-04 09:24:30 --> Helper loaded: file_helper
INFO - 2026-07-04 09:24:30 --> Helper loaded: email_helper
INFO - 2026-07-04 09:24:30 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 09:24:30 --> Helper loaded: ssp_helper
INFO - 2026-07-04 09:24:30 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 09:24:30 --> Helper loaded: plesk_helper
INFO - 2026-07-04 09:24:30 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 09:24:30 --> Helper loaded: domain_helper
INFO - 2026-07-04 09:24:30 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 09:24:30 --> Database Driver Class Initialized
INFO - 2026-07-04 09:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 09:24:32 --> Upload Class Initialized
DEBUG - 2026-07-04 09:24:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 09:24:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 09:24:32 --> Encryption Class Initialized
INFO - 2026-07-04 09:24:32 --> Form Validation Class Initialized
INFO - 2026-07-04 09:24:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 09:24:32 --> Pagination Class Initialized
INFO - 2026-07-04 09:24:32 --> Email Class Initialized
INFO - 2026-07-04 09:24:32 --> Controller Class Initialized
DEBUG - 2026-07-04 09:24:32 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 09:24:32 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 09:24:32 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 09:24:32 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-04 09:24:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-04 09:24:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-04 09:24:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-07-04 09:24:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-04 09:24:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-04 09:24:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-07-04 09:24:33 --> Final output sent to browser
DEBUG - 2026-07-04 09:24:33 --> Total execution time: 2.4332
INFO - 2026-07-04 09:24:43 --> Config Class Initialized
INFO - 2026-07-04 09:24:43 --> Hooks Class Initialized
DEBUG - 2026-07-04 09:24:43 --> UTF-8 Support Enabled
INFO - 2026-07-04 09:24:43 --> Utf8 Class Initialized
INFO - 2026-07-04 09:24:43 --> URI Class Initialized
INFO - 2026-07-04 09:24:43 --> Router Class Initialized
INFO - 2026-07-04 09:24:43 --> Output Class Initialized
INFO - 2026-07-04 09:24:43 --> Security Class Initialized
DEBUG - 2026-07-04 09:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 09:24:43 --> CSRF cookie sent
INFO - 2026-07-04 09:24:43 --> CSRF token verified
INFO - 2026-07-04 09:24:43 --> Input Class Initialized
INFO - 2026-07-04 09:24:43 --> Language Class Initialized
INFO - 2026-07-04 09:24:43 --> Language Class Initialized
INFO - 2026-07-04 09:24:43 --> Config Class Initialized
INFO - 2026-07-04 09:24:43 --> Loader Class Initialized
INFO - 2026-07-04 09:24:43 --> Helper loaded: url_helper
INFO - 2026-07-04 09:24:43 --> Helper loaded: form_helper
INFO - 2026-07-04 09:24:43 --> Helper loaded: html_helper
INFO - 2026-07-04 09:24:43 --> Helper loaded: file_helper
INFO - 2026-07-04 09:24:43 --> Helper loaded: email_helper
INFO - 2026-07-04 09:24:43 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 09:24:43 --> Helper loaded: ssp_helper
INFO - 2026-07-04 09:24:43 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 09:24:43 --> Helper loaded: plesk_helper
INFO - 2026-07-04 09:24:43 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 09:24:43 --> Helper loaded: domain_helper
INFO - 2026-07-04 09:24:43 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 09:24:43 --> Database Driver Class Initialized
INFO - 2026-07-04 09:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 09:24:46 --> Upload Class Initialized
DEBUG - 2026-07-04 09:24:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 09:24:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 09:24:46 --> Encryption Class Initialized
INFO - 2026-07-04 09:24:46 --> Form Validation Class Initialized
INFO - 2026-07-04 09:24:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 09:24:46 --> Pagination Class Initialized
INFO - 2026-07-04 09:24:46 --> Email Class Initialized
INFO - 2026-07-04 09:24:46 --> Controller Class Initialized
DEBUG - 2026-07-04 09:24:46 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 09:24:46 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 09:24:46 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 09:24:46 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 09:34:36 --> Config Class Initialized
INFO - 2026-07-04 09:34:36 --> Hooks Class Initialized
DEBUG - 2026-07-04 09:34:36 --> UTF-8 Support Enabled
INFO - 2026-07-04 09:34:36 --> Utf8 Class Initialized
INFO - 2026-07-04 09:34:36 --> URI Class Initialized
INFO - 2026-07-04 09:34:36 --> Router Class Initialized
INFO - 2026-07-04 09:34:36 --> Output Class Initialized
INFO - 2026-07-04 09:34:36 --> Security Class Initialized
DEBUG - 2026-07-04 09:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 09:34:36 --> CSRF cookie sent
INFO - 2026-07-04 09:34:36 --> Input Class Initialized
INFO - 2026-07-04 09:34:36 --> Language Class Initialized
INFO - 2026-07-04 09:34:36 --> Language Class Initialized
INFO - 2026-07-04 09:34:36 --> Config Class Initialized
INFO - 2026-07-04 09:34:36 --> Loader Class Initialized
INFO - 2026-07-04 09:34:36 --> Helper loaded: url_helper
INFO - 2026-07-04 09:34:36 --> Helper loaded: form_helper
INFO - 2026-07-04 09:34:36 --> Helper loaded: html_helper
INFO - 2026-07-04 09:34:36 --> Helper loaded: file_helper
INFO - 2026-07-04 09:34:36 --> Helper loaded: email_helper
INFO - 2026-07-04 09:34:36 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 09:34:36 --> Helper loaded: ssp_helper
INFO - 2026-07-04 09:34:36 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 09:34:36 --> Helper loaded: plesk_helper
INFO - 2026-07-04 09:34:36 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 09:34:36 --> Helper loaded: domain_helper
INFO - 2026-07-04 09:34:36 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 09:34:36 --> Database Driver Class Initialized
INFO - 2026-07-04 09:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 09:34:38 --> Upload Class Initialized
DEBUG - 2026-07-04 09:34:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 09:34:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 09:34:38 --> Encryption Class Initialized
INFO - 2026-07-04 09:34:38 --> Form Validation Class Initialized
INFO - 2026-07-04 09:34:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 09:34:38 --> Pagination Class Initialized
INFO - 2026-07-04 09:34:38 --> Email Class Initialized
INFO - 2026-07-04 09:34:38 --> Controller Class Initialized
DEBUG - 2026-07-04 09:34:38 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 09:34:38 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 09:34:38 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 09:34:38 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-04 09:34:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-04 09:34:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-04 09:34:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-07-04 09:34:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-04 09:34:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-04 09:34:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-07-04 09:34:39 --> Final output sent to browser
DEBUG - 2026-07-04 09:34:39 --> Total execution time: 2.4845
INFO - 2026-07-04 09:34:51 --> Config Class Initialized
INFO - 2026-07-04 09:34:51 --> Hooks Class Initialized
DEBUG - 2026-07-04 09:34:51 --> UTF-8 Support Enabled
INFO - 2026-07-04 09:34:51 --> Utf8 Class Initialized
INFO - 2026-07-04 09:34:51 --> URI Class Initialized
INFO - 2026-07-04 09:34:51 --> Router Class Initialized
INFO - 2026-07-04 09:34:51 --> Output Class Initialized
INFO - 2026-07-04 09:34:51 --> Security Class Initialized
DEBUG - 2026-07-04 09:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 09:34:51 --> CSRF cookie sent
INFO - 2026-07-04 09:34:51 --> CSRF token verified
INFO - 2026-07-04 09:34:51 --> Input Class Initialized
INFO - 2026-07-04 09:34:51 --> Language Class Initialized
INFO - 2026-07-04 09:34:51 --> Language Class Initialized
INFO - 2026-07-04 09:34:51 --> Config Class Initialized
INFO - 2026-07-04 09:34:51 --> Loader Class Initialized
INFO - 2026-07-04 09:34:51 --> Helper loaded: url_helper
INFO - 2026-07-04 09:34:51 --> Helper loaded: form_helper
INFO - 2026-07-04 09:34:51 --> Helper loaded: html_helper
INFO - 2026-07-04 09:34:51 --> Helper loaded: file_helper
INFO - 2026-07-04 09:34:51 --> Helper loaded: email_helper
INFO - 2026-07-04 09:34:51 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 09:34:51 --> Helper loaded: ssp_helper
INFO - 2026-07-04 09:34:51 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 09:34:51 --> Helper loaded: plesk_helper
INFO - 2026-07-04 09:34:51 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 09:34:51 --> Helper loaded: domain_helper
INFO - 2026-07-04 09:34:51 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 09:34:51 --> Database Driver Class Initialized
INFO - 2026-07-04 09:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 09:34:53 --> Upload Class Initialized
DEBUG - 2026-07-04 09:34:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 09:34:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 09:34:53 --> Encryption Class Initialized
INFO - 2026-07-04 09:34:53 --> Form Validation Class Initialized
INFO - 2026-07-04 09:34:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 09:34:53 --> Pagination Class Initialized
INFO - 2026-07-04 09:34:53 --> Email Class Initialized
INFO - 2026-07-04 09:34:53 --> Controller Class Initialized
DEBUG - 2026-07-04 09:34:53 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 09:34:53 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 09:34:53 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 09:34:53 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 09:34:58 --> Config Class Initialized
INFO - 2026-07-04 09:34:58 --> Hooks Class Initialized
DEBUG - 2026-07-04 09:34:58 --> UTF-8 Support Enabled
INFO - 2026-07-04 09:34:58 --> Utf8 Class Initialized
INFO - 2026-07-04 09:34:58 --> URI Class Initialized
INFO - 2026-07-04 09:34:58 --> Router Class Initialized
INFO - 2026-07-04 09:34:58 --> Output Class Initialized
INFO - 2026-07-04 09:34:58 --> Security Class Initialized
DEBUG - 2026-07-04 09:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 09:34:58 --> CSRF cookie sent
INFO - 2026-07-04 09:34:58 --> Input Class Initialized
INFO - 2026-07-04 09:34:58 --> Language Class Initialized
INFO - 2026-07-04 09:34:58 --> Language Class Initialized
INFO - 2026-07-04 09:34:58 --> Config Class Initialized
INFO - 2026-07-04 09:34:58 --> Loader Class Initialized
INFO - 2026-07-04 09:34:58 --> Helper loaded: url_helper
INFO - 2026-07-04 09:34:58 --> Helper loaded: form_helper
INFO - 2026-07-04 09:34:58 --> Helper loaded: html_helper
INFO - 2026-07-04 09:34:58 --> Helper loaded: file_helper
INFO - 2026-07-04 09:34:58 --> Helper loaded: email_helper
INFO - 2026-07-04 09:34:58 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 09:34:58 --> Helper loaded: ssp_helper
INFO - 2026-07-04 09:34:58 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 09:34:58 --> Helper loaded: plesk_helper
INFO - 2026-07-04 09:34:58 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 09:34:58 --> Helper loaded: domain_helper
INFO - 2026-07-04 09:34:58 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 09:34:58 --> Database Driver Class Initialized
INFO - 2026-07-04 09:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 09:35:00 --> Upload Class Initialized
DEBUG - 2026-07-04 09:35:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 09:35:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 09:35:00 --> Encryption Class Initialized
INFO - 2026-07-04 09:35:00 --> Form Validation Class Initialized
INFO - 2026-07-04 09:35:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 09:35:00 --> Pagination Class Initialized
INFO - 2026-07-04 09:35:00 --> Email Class Initialized
INFO - 2026-07-04 09:35:00 --> Controller Class Initialized
DEBUG - 2026-07-04 09:35:00 --> Dashboard MX_Controller Initialized
INFO - 2026-07-04 09:35:00 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 09:35:00 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 09:35:00 --> Model "Dashboard_model" initialized
DEBUG - 2026-07-04 09:35:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-04 09:35:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-04 09:35:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-04 09:35:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-04 09:35:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-04 09:35:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/dashboard_index.php
INFO - 2026-07-04 09:35:00 --> Final output sent to browser
DEBUG - 2026-07-04 09:35:00 --> Total execution time: 2.4211
INFO - 2026-07-04 09:35:00 --> Config Class Initialized
INFO - 2026-07-04 09:35:00 --> Hooks Class Initialized
INFO - 2026-07-04 09:35:00 --> Config Class Initialized
INFO - 2026-07-04 09:35:00 --> Hooks Class Initialized
DEBUG - 2026-07-04 09:35:00 --> UTF-8 Support Enabled
INFO - 2026-07-04 09:35:00 --> Utf8 Class Initialized
INFO - 2026-07-04 09:35:00 --> URI Class Initialized
INFO - 2026-07-04 09:35:00 --> Config Class Initialized
INFO - 2026-07-04 09:35:00 --> Hooks Class Initialized
DEBUG - 2026-07-04 09:35:00 --> UTF-8 Support Enabled
INFO - 2026-07-04 09:35:00 --> Utf8 Class Initialized
INFO - 2026-07-04 09:35:00 --> URI Class Initialized
INFO - 2026-07-04 09:35:00 --> Config Class Initialized
INFO - 2026-07-04 09:35:00 --> Hooks Class Initialized
DEBUG - 2026-07-04 09:35:00 --> UTF-8 Support Enabled
INFO - 2026-07-04 09:35:00 --> Utf8 Class Initialized
INFO - 2026-07-04 09:35:00 --> Router Class Initialized
INFO - 2026-07-04 09:35:00 --> URI Class Initialized
INFO - 2026-07-04 09:35:00 --> Router Class Initialized
DEBUG - 2026-07-04 09:35:00 --> UTF-8 Support Enabled
INFO - 2026-07-04 09:35:00 --> Utf8 Class Initialized
INFO - 2026-07-04 09:35:00 --> Output Class Initialized
INFO - 2026-07-04 09:35:00 --> Config Class Initialized
INFO - 2026-07-04 09:35:00 --> Hooks Class Initialized
INFO - 2026-07-04 09:35:00 --> URI Class Initialized
INFO - 2026-07-04 09:35:00 --> Security Class Initialized
INFO - 2026-07-04 09:35:00 --> Router Class Initialized
DEBUG - 2026-07-04 09:35:00 --> UTF-8 Support Enabled
INFO - 2026-07-04 09:35:00 --> Utf8 Class Initialized
INFO - 2026-07-04 09:35:00 --> URI Class Initialized
DEBUG - 2026-07-04 09:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 09:35:00 --> Output Class Initialized
INFO - 2026-07-04 09:35:00 --> Input Class Initialized
INFO - 2026-07-04 09:35:00 --> Router Class Initialized
INFO - 2026-07-04 09:35:00 --> Language Class Initialized
INFO - 2026-07-04 09:35:00 --> Security Class Initialized
INFO - 2026-07-04 09:35:00 --> Router Class Initialized
INFO - 2026-07-04 09:35:00 --> Language Class Initialized
INFO - 2026-07-04 09:35:00 --> Config Class Initialized
INFO - 2026-07-04 09:35:00 --> Output Class Initialized
DEBUG - 2026-07-04 09:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 09:35:00 --> Output Class Initialized
INFO - 2026-07-04 09:35:00 --> Security Class Initialized
INFO - 2026-07-04 09:35:00 --> Input Class Initialized
INFO - 2026-07-04 09:35:00 --> Language Class Initialized
INFO - 2026-07-04 09:35:00 --> Config Class Initialized
INFO - 2026-07-04 09:35:00 --> Hooks Class Initialized
DEBUG - 2026-07-04 09:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 09:35:00 --> Output Class Initialized
INFO - 2026-07-04 09:35:00 --> Loader Class Initialized
INFO - 2026-07-04 09:35:00 --> Language Class Initialized
INFO - 2026-07-04 09:35:00 --> Config Class Initialized
INFO - 2026-07-04 09:35:00 --> Input Class Initialized
INFO - 2026-07-04 09:35:00 --> Language Class Initialized
DEBUG - 2026-07-04 09:35:00 --> UTF-8 Support Enabled
INFO - 2026-07-04 09:35:00 --> Utf8 Class Initialized
INFO - 2026-07-04 09:35:00 --> Security Class Initialized
INFO - 2026-07-04 09:35:00 --> Helper loaded: url_helper
INFO - 2026-07-04 09:35:00 --> URI Class Initialized
INFO - 2026-07-04 09:35:00 --> Language Class Initialized
INFO - 2026-07-04 09:35:00 --> Config Class Initialized
DEBUG - 2026-07-04 09:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 09:35:00 --> Input Class Initialized
INFO - 2026-07-04 09:35:00 --> Helper loaded: form_helper
INFO - 2026-07-04 09:35:00 --> Language Class Initialized
INFO - 2026-07-04 09:35:00 --> Helper loaded: html_helper
INFO - 2026-07-04 09:35:00 --> Loader Class Initialized
INFO - 2026-07-04 09:35:00 --> Language Class Initialized
INFO - 2026-07-04 09:35:00 --> Config Class Initialized
INFO - 2026-07-04 09:35:00 --> Helper loaded: file_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: email_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: url_helper
INFO - 2026-07-04 09:35:00 --> Loader Class Initialized
INFO - 2026-07-04 09:35:00 --> Helper loaded: form_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: url_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: ssp_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: html_helper
INFO - 2026-07-04 09:35:00 --> Loader Class Initialized
INFO - 2026-07-04 09:35:00 --> Helper loaded: file_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: email_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: form_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: html_helper
INFO - 2026-07-04 09:35:00 --> Security Class Initialized
INFO - 2026-07-04 09:35:00 --> Helper loaded: url_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: file_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: email_helper
DEBUG - 2026-07-04 09:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 09:35:00 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 09:35:00 --> Input Class Initialized
INFO - 2026-07-04 09:35:00 --> Helper loaded: form_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: ssp_helper
INFO - 2026-07-04 09:35:00 --> Language Class Initialized
INFO - 2026-07-04 09:35:00 --> Helper loaded: plesk_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: html_helper
INFO - 2026-07-04 09:35:00 --> Language Class Initialized
INFO - 2026-07-04 09:35:00 --> Config Class Initialized
INFO - 2026-07-04 09:35:00 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: file_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: email_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: ssp_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 09:35:00 --> Router Class Initialized
INFO - 2026-07-04 09:35:00 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 09:35:00 --> Loader Class Initialized
INFO - 2026-07-04 09:35:00 --> Helper loaded: ssp_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: plesk_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 09:35:00 --> Output Class Initialized
INFO - 2026-07-04 09:35:00 --> Helper loaded: url_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: domain_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: plesk_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: form_helper
INFO - 2026-07-04 09:35:00 --> Security Class Initialized
INFO - 2026-07-04 09:35:00 --> Helper loaded: html_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: plesk_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: file_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: email_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: domain_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: ssp_helper
DEBUG - 2026-07-04 09:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 09:35:00 --> Helper loaded: domain_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 09:35:00 --> Input Class Initialized
INFO - 2026-07-04 09:35:00 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 09:35:00 --> Language Class Initialized
INFO - 2026-07-04 09:35:00 --> Helper loaded: domain_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: plesk_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 09:35:00 --> Language Class Initialized
INFO - 2026-07-04 09:35:00 --> Config Class Initialized
INFO - 2026-07-04 09:35:00 --> Database Driver Class Initialized
INFO - 2026-07-04 09:35:00 --> Helper loaded: domain_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 09:35:00 --> Loader Class Initialized
INFO - 2026-07-04 09:35:00 --> Database Driver Class Initialized
INFO - 2026-07-04 09:35:00 --> Database Driver Class Initialized
INFO - 2026-07-04 09:35:00 --> Database Driver Class Initialized
INFO - 2026-07-04 09:35:00 --> Database Driver Class Initialized
INFO - 2026-07-04 09:35:00 --> Helper loaded: url_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: form_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: html_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: file_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: email_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: ssp_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: plesk_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: domain_helper
INFO - 2026-07-04 09:35:00 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 09:35:00 --> Database Driver Class Initialized
INFO - 2026-07-04 09:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 09:35:02 --> Upload Class Initialized
DEBUG - 2026-07-04 09:35:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 09:35:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 09:35:02 --> Encryption Class Initialized
INFO - 2026-07-04 09:35:02 --> Form Validation Class Initialized
INFO - 2026-07-04 09:35:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 09:35:02 --> Pagination Class Initialized
INFO - 2026-07-04 09:35:02 --> Email Class Initialized
INFO - 2026-07-04 09:35:02 --> Controller Class Initialized
DEBUG - 2026-07-04 09:35:02 --> Dashboard MX_Controller Initialized
INFO - 2026-07-04 09:35:02 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 09:35:02 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 09:35:02 --> Model "Dashboard_model" initialized
INFO - 2026-07-04 09:35:04 --> Final output sent to browser
DEBUG - 2026-07-04 09:35:04 --> Total execution time: 3.4272
INFO - 2026-07-04 09:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 09:35:04 --> Upload Class Initialized
DEBUG - 2026-07-04 09:35:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 09:35:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 09:35:04 --> Encryption Class Initialized
INFO - 2026-07-04 09:35:04 --> Form Validation Class Initialized
INFO - 2026-07-04 09:35:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 09:35:04 --> Pagination Class Initialized
INFO - 2026-07-04 09:35:04 --> Email Class Initialized
INFO - 2026-07-04 09:35:04 --> Controller Class Initialized
DEBUG - 2026-07-04 09:35:04 --> Ticket MX_Controller Initialized
INFO - 2026-07-04 09:35:04 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 09:35:04 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 09:35:04 --> Model "Support_model" initialized
INFO - 2026-07-04 09:35:04 --> Model "Common_model" initialized
INFO - 2026-07-04 09:35:04 --> Final output sent to browser
DEBUG - 2026-07-04 09:35:04 --> Total execution time: 4.1756
INFO - 2026-07-04 09:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 09:35:04 --> Upload Class Initialized
DEBUG - 2026-07-04 09:35:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 09:35:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 09:35:04 --> Encryption Class Initialized
INFO - 2026-07-04 09:35:04 --> Form Validation Class Initialized
INFO - 2026-07-04 09:35:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 09:35:04 --> Pagination Class Initialized
INFO - 2026-07-04 09:35:04 --> Email Class Initialized
INFO - 2026-07-04 09:35:04 --> Controller Class Initialized
DEBUG - 2026-07-04 09:35:04 --> Dashboard MX_Controller Initialized
INFO - 2026-07-04 09:35:04 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 09:35:04 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 09:35:05 --> Model "Dashboard_model" initialized
INFO - 2026-07-04 09:35:05 --> Final output sent to browser
DEBUG - 2026-07-04 09:35:05 --> Total execution time: 4.9046
INFO - 2026-07-04 09:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 09:35:05 --> Upload Class Initialized
DEBUG - 2026-07-04 09:35:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 09:35:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 09:35:05 --> Encryption Class Initialized
INFO - 2026-07-04 09:35:05 --> Form Validation Class Initialized
INFO - 2026-07-04 09:35:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 09:35:05 --> Pagination Class Initialized
INFO - 2026-07-04 09:35:05 --> Email Class Initialized
INFO - 2026-07-04 09:35:05 --> Controller Class Initialized
DEBUG - 2026-07-04 09:35:05 --> Dashboard MX_Controller Initialized
INFO - 2026-07-04 09:35:05 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 09:35:05 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 09:35:05 --> Model "Dashboard_model" initialized
INFO - 2026-07-04 09:35:06 --> Final output sent to browser
DEBUG - 2026-07-04 09:35:06 --> Total execution time: 5.5275
INFO - 2026-07-04 09:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 09:35:06 --> Upload Class Initialized
DEBUG - 2026-07-04 09:35:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 09:35:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 09:35:06 --> Encryption Class Initialized
INFO - 2026-07-04 09:35:06 --> Form Validation Class Initialized
INFO - 2026-07-04 09:35:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 09:35:06 --> Pagination Class Initialized
INFO - 2026-07-04 09:35:06 --> Email Class Initialized
INFO - 2026-07-04 09:35:06 --> Controller Class Initialized
DEBUG - 2026-07-04 09:35:06 --> Invoice MX_Controller Initialized
INFO - 2026-07-04 09:35:06 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 09:35:06 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 09:35:06 --> Model "Billing_model" initialized
INFO - 2026-07-04 09:35:06 --> Model "Common_model" initialized
INFO - 2026-07-04 09:35:06 --> Model "Invoice_model" initialized
INFO - 2026-07-04 09:35:06 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 09:35:06 --> Final output sent to browser
DEBUG - 2026-07-04 09:35:06 --> Total execution time: 6.1453
INFO - 2026-07-04 09:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 09:35:06 --> Upload Class Initialized
DEBUG - 2026-07-04 09:35:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 09:35:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 09:35:06 --> Encryption Class Initialized
INFO - 2026-07-04 09:35:06 --> Form Validation Class Initialized
INFO - 2026-07-04 09:35:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 09:35:06 --> Pagination Class Initialized
INFO - 2026-07-04 09:35:06 --> Email Class Initialized
INFO - 2026-07-04 09:35:06 --> Controller Class Initialized
DEBUG - 2026-07-04 09:35:06 --> Order MX_Controller Initialized
INFO - 2026-07-04 09:35:06 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 09:35:06 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 09:35:07 --> Model "Order_model" initialized
INFO - 2026-07-04 09:35:07 --> Model "Common_model" initialized
INFO - 2026-07-04 09:35:07 --> Model "Currency_model" initialized
INFO - 2026-07-04 09:35:07 --> Final output sent to browser
DEBUG - 2026-07-04 09:35:07 --> Total execution time: 6.7936
INFO - 2026-07-04 16:08:32 --> Config Class Initialized
INFO - 2026-07-04 16:08:32 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:08:32 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:08:32 --> Utf8 Class Initialized
INFO - 2026-07-04 16:08:32 --> URI Class Initialized
DEBUG - 2026-07-04 16:08:32 --> No URI present. Default controller set.
INFO - 2026-07-04 16:08:32 --> Router Class Initialized
INFO - 2026-07-04 16:08:32 --> Output Class Initialized
INFO - 2026-07-04 16:08:32 --> Security Class Initialized
DEBUG - 2026-07-04 16:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:08:32 --> CSRF cookie sent
INFO - 2026-07-04 16:08:32 --> Input Class Initialized
INFO - 2026-07-04 16:08:32 --> Language Class Initialized
INFO - 2026-07-04 16:08:32 --> Language Class Initialized
INFO - 2026-07-04 16:08:32 --> Config Class Initialized
INFO - 2026-07-04 16:08:32 --> Loader Class Initialized
INFO - 2026-07-04 16:08:32 --> Helper loaded: url_helper
INFO - 2026-07-04 16:08:32 --> Helper loaded: form_helper
INFO - 2026-07-04 16:08:32 --> Helper loaded: html_helper
INFO - 2026-07-04 16:08:32 --> Helper loaded: file_helper
INFO - 2026-07-04 16:08:32 --> Helper loaded: email_helper
INFO - 2026-07-04 16:08:32 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:08:32 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:08:32 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:08:32 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:08:32 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:08:32 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:08:32 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:08:32 --> Database Driver Class Initialized
INFO - 2026-07-04 16:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:08:34 --> Upload Class Initialized
DEBUG - 2026-07-04 16:08:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:08:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:08:34 --> Encryption Class Initialized
INFO - 2026-07-04 16:08:34 --> Form Validation Class Initialized
INFO - 2026-07-04 16:08:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:08:34 --> Pagination Class Initialized
INFO - 2026-07-04 16:08:34 --> Email Class Initialized
INFO - 2026-07-04 16:08:34 --> Controller Class Initialized
DEBUG - 2026-07-04 16:08:34 --> Auth MX_Controller Initialized
INFO - 2026-07-04 16:08:34 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 16:08:34 --> Model "Auth_model" initialized
INFO - 2026-07-04 16:08:34 --> Model "Cart_model" initialized
INFO - 2026-07-04 16:08:34 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 16:08:34 --> Config Class Initialized
INFO - 2026-07-04 16:08:34 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:08:34 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:08:34 --> Utf8 Class Initialized
INFO - 2026-07-04 16:08:34 --> URI Class Initialized
INFO - 2026-07-04 16:08:34 --> Router Class Initialized
INFO - 2026-07-04 16:08:34 --> Output Class Initialized
INFO - 2026-07-04 16:08:34 --> Security Class Initialized
DEBUG - 2026-07-04 16:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:08:34 --> CSRF cookie sent
INFO - 2026-07-04 16:08:34 --> Input Class Initialized
INFO - 2026-07-04 16:08:34 --> Language Class Initialized
INFO - 2026-07-04 16:08:34 --> Language Class Initialized
INFO - 2026-07-04 16:08:34 --> Config Class Initialized
INFO - 2026-07-04 16:08:34 --> Loader Class Initialized
INFO - 2026-07-04 16:08:34 --> Helper loaded: url_helper
INFO - 2026-07-04 16:08:34 --> Helper loaded: form_helper
INFO - 2026-07-04 16:08:34 --> Helper loaded: html_helper
INFO - 2026-07-04 16:08:34 --> Helper loaded: file_helper
INFO - 2026-07-04 16:08:34 --> Helper loaded: email_helper
INFO - 2026-07-04 16:08:34 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:08:34 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:08:34 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:08:34 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:08:34 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:08:34 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:08:34 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:08:34 --> Database Driver Class Initialized
INFO - 2026-07-04 16:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:08:36 --> Upload Class Initialized
DEBUG - 2026-07-04 16:08:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:08:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:08:36 --> Encryption Class Initialized
INFO - 2026-07-04 16:08:36 --> Form Validation Class Initialized
INFO - 2026-07-04 16:08:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:08:36 --> Pagination Class Initialized
INFO - 2026-07-04 16:08:36 --> Email Class Initialized
INFO - 2026-07-04 16:08:36 --> Controller Class Initialized
DEBUG - 2026-07-04 16:08:36 --> Auth MX_Controller Initialized
INFO - 2026-07-04 16:08:36 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 16:08:36 --> Model "Auth_model" initialized
INFO - 2026-07-04 16:08:36 --> Model "Cart_model" initialized
INFO - 2026-07-04 16:08:36 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-04 16:08:36 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-04 16:08:36 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-04 16:08:36 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-04 16:08:36 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-07-04 16:08:36 --> Final output sent to browser
DEBUG - 2026-07-04 16:08:36 --> Total execution time: 2.2926
INFO - 2026-07-04 16:08:37 --> Config Class Initialized
INFO - 2026-07-04 16:08:37 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:08:37 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:08:37 --> Utf8 Class Initialized
INFO - 2026-07-04 16:08:37 --> URI Class Initialized
INFO - 2026-07-04 16:08:37 --> Router Class Initialized
INFO - 2026-07-04 16:08:37 --> Output Class Initialized
INFO - 2026-07-04 16:08:37 --> Security Class Initialized
DEBUG - 2026-07-04 16:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:08:37 --> CSRF cookie sent
INFO - 2026-07-04 16:08:37 --> Input Class Initialized
INFO - 2026-07-04 16:08:37 --> Language Class Initialized
INFO - 2026-07-04 16:08:37 --> Language Class Initialized
INFO - 2026-07-04 16:08:37 --> Config Class Initialized
INFO - 2026-07-04 16:08:37 --> Loader Class Initialized
INFO - 2026-07-04 16:08:37 --> Helper loaded: url_helper
INFO - 2026-07-04 16:08:37 --> Helper loaded: form_helper
INFO - 2026-07-04 16:08:37 --> Helper loaded: html_helper
INFO - 2026-07-04 16:08:37 --> Helper loaded: file_helper
INFO - 2026-07-04 16:08:37 --> Helper loaded: email_helper
INFO - 2026-07-04 16:08:37 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:08:37 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:08:37 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:08:37 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:08:37 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:08:37 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:08:37 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:08:37 --> Database Driver Class Initialized
INFO - 2026-07-04 16:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:08:38 --> Upload Class Initialized
DEBUG - 2026-07-04 16:08:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:08:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:08:38 --> Encryption Class Initialized
INFO - 2026-07-04 16:08:38 --> Form Validation Class Initialized
INFO - 2026-07-04 16:08:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:08:38 --> Pagination Class Initialized
INFO - 2026-07-04 16:08:38 --> Email Class Initialized
INFO - 2026-07-04 16:08:38 --> Controller Class Initialized
DEBUG - 2026-07-04 16:08:38 --> Cart MX_Controller Initialized
INFO - 2026-07-04 16:08:38 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 16:08:38 --> Model "Auth_model" initialized
INFO - 2026-07-04 16:08:38 --> Model "Cart_model" initialized
INFO - 2026-07-04 16:08:38 --> Model "Common_model" initialized
INFO - 2026-07-04 16:08:38 --> Model "Order_model" initialized
INFO - 2026-07-04 16:08:38 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 16:08:38 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-04 16:08:38 --> Model "Promocode_model" initialized
DEBUG - 2026-07-04 16:08:38 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-04 16:08:38 --> Model "Plan_model" initialized
INFO - 2026-07-04 16:08:38 --> Model "Orderlicense_model" initialized
INFO - 2026-07-04 16:08:39 --> Final output sent to browser
DEBUG - 2026-07-04 16:08:39 --> Total execution time: 2.1245
INFO - 2026-07-04 16:08:41 --> Config Class Initialized
INFO - 2026-07-04 16:08:41 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:08:41 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:08:41 --> Utf8 Class Initialized
INFO - 2026-07-04 16:08:41 --> URI Class Initialized
INFO - 2026-07-04 16:08:41 --> Router Class Initialized
INFO - 2026-07-04 16:08:41 --> Output Class Initialized
INFO - 2026-07-04 16:08:41 --> Security Class Initialized
DEBUG - 2026-07-04 16:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:08:41 --> CSRF cookie sent
INFO - 2026-07-04 16:08:41 --> CSRF token verified
INFO - 2026-07-04 16:08:41 --> Input Class Initialized
INFO - 2026-07-04 16:08:41 --> Language Class Initialized
INFO - 2026-07-04 16:08:41 --> Language Class Initialized
INFO - 2026-07-04 16:08:41 --> Config Class Initialized
INFO - 2026-07-04 16:08:41 --> Loader Class Initialized
INFO - 2026-07-04 16:08:41 --> Helper loaded: url_helper
INFO - 2026-07-04 16:08:41 --> Helper loaded: form_helper
INFO - 2026-07-04 16:08:41 --> Helper loaded: html_helper
INFO - 2026-07-04 16:08:41 --> Helper loaded: file_helper
INFO - 2026-07-04 16:08:41 --> Helper loaded: email_helper
INFO - 2026-07-04 16:08:41 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:08:41 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:08:41 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:08:41 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:08:41 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:08:41 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:08:41 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:08:41 --> Database Driver Class Initialized
INFO - 2026-07-04 16:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:08:43 --> Upload Class Initialized
DEBUG - 2026-07-04 16:08:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:08:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:08:43 --> Encryption Class Initialized
INFO - 2026-07-04 16:08:43 --> Form Validation Class Initialized
INFO - 2026-07-04 16:08:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:08:43 --> Pagination Class Initialized
INFO - 2026-07-04 16:08:43 --> Email Class Initialized
INFO - 2026-07-04 16:08:43 --> Controller Class Initialized
DEBUG - 2026-07-04 16:08:43 --> Auth MX_Controller Initialized
INFO - 2026-07-04 16:08:43 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 16:08:43 --> Model "Auth_model" initialized
INFO - 2026-07-04 16:08:43 --> Model "Cart_model" initialized
INFO - 2026-07-04 16:08:43 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 16:08:46 --> Config Class Initialized
INFO - 2026-07-04 16:08:46 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:08:46 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:08:46 --> Utf8 Class Initialized
INFO - 2026-07-04 16:08:46 --> URI Class Initialized
INFO - 2026-07-04 16:08:46 --> Router Class Initialized
INFO - 2026-07-04 16:08:46 --> Output Class Initialized
INFO - 2026-07-04 16:08:46 --> Security Class Initialized
DEBUG - 2026-07-04 16:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:08:46 --> CSRF cookie sent
INFO - 2026-07-04 16:08:46 --> Input Class Initialized
INFO - 2026-07-04 16:08:46 --> Language Class Initialized
INFO - 2026-07-04 16:08:46 --> Language Class Initialized
INFO - 2026-07-04 16:08:46 --> Config Class Initialized
INFO - 2026-07-04 16:08:47 --> Loader Class Initialized
INFO - 2026-07-04 16:08:47 --> Helper loaded: url_helper
INFO - 2026-07-04 16:08:47 --> Helper loaded: form_helper
INFO - 2026-07-04 16:08:47 --> Helper loaded: html_helper
INFO - 2026-07-04 16:08:47 --> Helper loaded: file_helper
INFO - 2026-07-04 16:08:47 --> Helper loaded: email_helper
INFO - 2026-07-04 16:08:47 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:08:47 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:08:47 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:08:47 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:08:47 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:08:47 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:08:47 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:08:47 --> Database Driver Class Initialized
INFO - 2026-07-04 16:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:08:48 --> Upload Class Initialized
DEBUG - 2026-07-04 16:08:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:08:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:08:48 --> Encryption Class Initialized
INFO - 2026-07-04 16:08:48 --> Form Validation Class Initialized
INFO - 2026-07-04 16:08:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:08:48 --> Pagination Class Initialized
INFO - 2026-07-04 16:08:48 --> Email Class Initialized
INFO - 2026-07-04 16:08:48 --> Controller Class Initialized
DEBUG - 2026-07-04 16:08:48 --> Clientarea MX_Controller Initialized
INFO - 2026-07-04 16:08:48 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 16:08:48 --> Model "Auth_model" initialized
INFO - 2026-07-04 16:08:48 --> Model "Cart_model" initialized
INFO - 2026-07-04 16:08:48 --> Model "Clientarea_model" initialized
INFO - 2026-07-04 16:08:48 --> Model "Billing_model" initialized
INFO - 2026-07-04 16:08:48 --> Model "Common_model" initialized
INFO - 2026-07-04 16:08:48 --> Model "Order_model" initialized
INFO - 2026-07-04 16:08:48 --> Model "Support_model" initialized
INFO - 2026-07-04 16:08:49 --> Model "Subscription_model" initialized
INFO - 2026-07-04 16:08:49 --> Model "Software_model" initialized
DEBUG - 2026-07-04 16:08:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-04 16:08:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-04 16:08:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-04 16:08:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_index.php
INFO - 2026-07-04 16:08:50 --> Final output sent to browser
DEBUG - 2026-07-04 16:08:50 --> Total execution time: 3.3774
INFO - 2026-07-04 16:08:50 --> Config Class Initialized
INFO - 2026-07-04 16:08:50 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:08:50 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:08:50 --> Utf8 Class Initialized
INFO - 2026-07-04 16:08:50 --> URI Class Initialized
INFO - 2026-07-04 16:08:50 --> Router Class Initialized
INFO - 2026-07-04 16:08:50 --> Output Class Initialized
INFO - 2026-07-04 16:08:50 --> Security Class Initialized
DEBUG - 2026-07-04 16:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:08:50 --> CSRF cookie sent
INFO - 2026-07-04 16:08:50 --> Input Class Initialized
INFO - 2026-07-04 16:08:50 --> Language Class Initialized
INFO - 2026-07-04 16:08:50 --> Language Class Initialized
INFO - 2026-07-04 16:08:50 --> Config Class Initialized
INFO - 2026-07-04 16:08:50 --> Loader Class Initialized
INFO - 2026-07-04 16:08:50 --> Helper loaded: url_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: form_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: html_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: file_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: email_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:08:50 --> Config Class Initialized
INFO - 2026-07-04 16:08:50 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:08:50 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:08:50 --> Utf8 Class Initialized
INFO - 2026-07-04 16:08:50 --> Database Driver Class Initialized
INFO - 2026-07-04 16:08:50 --> URI Class Initialized
INFO - 2026-07-04 16:08:50 --> Config Class Initialized
INFO - 2026-07-04 16:08:50 --> Hooks Class Initialized
INFO - 2026-07-04 16:08:50 --> Router Class Initialized
DEBUG - 2026-07-04 16:08:50 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:08:50 --> Utf8 Class Initialized
INFO - 2026-07-04 16:08:50 --> URI Class Initialized
INFO - 2026-07-04 16:08:50 --> Output Class Initialized
INFO - 2026-07-04 16:08:50 --> Security Class Initialized
INFO - 2026-07-04 16:08:50 --> Router Class Initialized
DEBUG - 2026-07-04 16:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:08:50 --> Input Class Initialized
INFO - 2026-07-04 16:08:50 --> Language Class Initialized
INFO - 2026-07-04 16:08:50 --> Output Class Initialized
INFO - 2026-07-04 16:08:50 --> Language Class Initialized
INFO - 2026-07-04 16:08:50 --> Config Class Initialized
INFO - 2026-07-04 16:08:50 --> Security Class Initialized
DEBUG - 2026-07-04 16:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:08:50 --> Input Class Initialized
INFO - 2026-07-04 16:08:50 --> Language Class Initialized
INFO - 2026-07-04 16:08:50 --> Loader Class Initialized
INFO - 2026-07-04 16:08:50 --> Language Class Initialized
INFO - 2026-07-04 16:08:50 --> Config Class Initialized
INFO - 2026-07-04 16:08:50 --> Helper loaded: url_helper
INFO - 2026-07-04 16:08:50 --> Config Class Initialized
INFO - 2026-07-04 16:08:50 --> Hooks Class Initialized
INFO - 2026-07-04 16:08:50 --> Helper loaded: form_helper
INFO - 2026-07-04 16:08:50 --> Loader Class Initialized
INFO - 2026-07-04 16:08:50 --> Helper loaded: html_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: file_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: url_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: email_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: form_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: html_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: file_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: email_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: cpanel_helper
DEBUG - 2026-07-04 16:08:50 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:08:50 --> Utf8 Class Initialized
INFO - 2026-07-04 16:08:50 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:08:50 --> URI Class Initialized
INFO - 2026-07-04 16:08:50 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:08:50 --> Database Driver Class Initialized
INFO - 2026-07-04 16:08:50 --> Router Class Initialized
INFO - 2026-07-04 16:08:50 --> Database Driver Class Initialized
INFO - 2026-07-04 16:08:50 --> Output Class Initialized
INFO - 2026-07-04 16:08:50 --> Security Class Initialized
DEBUG - 2026-07-04 16:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:08:50 --> Input Class Initialized
INFO - 2026-07-04 16:08:50 --> Language Class Initialized
INFO - 2026-07-04 16:08:50 --> Language Class Initialized
INFO - 2026-07-04 16:08:50 --> Config Class Initialized
INFO - 2026-07-04 16:08:50 --> Loader Class Initialized
INFO - 2026-07-04 16:08:50 --> Helper loaded: url_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: form_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: html_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: file_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: email_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:08:50 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:08:50 --> Database Driver Class Initialized
INFO - 2026-07-04 16:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:08:52 --> Upload Class Initialized
DEBUG - 2026-07-04 16:08:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:08:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:08:52 --> Encryption Class Initialized
INFO - 2026-07-04 16:08:52 --> Form Validation Class Initialized
INFO - 2026-07-04 16:08:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:08:52 --> Pagination Class Initialized
INFO - 2026-07-04 16:08:52 --> Email Class Initialized
INFO - 2026-07-04 16:08:52 --> Controller Class Initialized
DEBUG - 2026-07-04 16:08:52 --> Cart MX_Controller Initialized
INFO - 2026-07-04 16:08:52 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 16:08:52 --> Model "Auth_model" initialized
INFO - 2026-07-04 16:08:52 --> Model "Cart_model" initialized
INFO - 2026-07-04 16:08:52 --> Model "Common_model" initialized
INFO - 2026-07-04 16:08:52 --> Model "Order_model" initialized
INFO - 2026-07-04 16:08:52 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 16:08:52 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-04 16:08:52 --> Model "Promocode_model" initialized
DEBUG - 2026-07-04 16:08:52 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-04 16:08:52 --> Model "Plan_model" initialized
INFO - 2026-07-04 16:08:52 --> Model "Orderlicense_model" initialized
INFO - 2026-07-04 16:08:52 --> Final output sent to browser
DEBUG - 2026-07-04 16:08:52 --> Total execution time: 2.2610
INFO - 2026-07-04 16:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:08:52 --> Upload Class Initialized
DEBUG - 2026-07-04 16:08:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:08:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:08:52 --> Encryption Class Initialized
INFO - 2026-07-04 16:08:52 --> Form Validation Class Initialized
INFO - 2026-07-04 16:08:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:08:52 --> Pagination Class Initialized
INFO - 2026-07-04 16:08:52 --> Email Class Initialized
INFO - 2026-07-04 16:08:52 --> Controller Class Initialized
DEBUG - 2026-07-04 16:08:52 --> Tickets MX_Controller Initialized
INFO - 2026-07-04 16:08:52 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 16:08:52 --> Model "Auth_model" initialized
INFO - 2026-07-04 16:08:52 --> Model "Cart_model" initialized
INFO - 2026-07-04 16:08:52 --> Model "Support_model" initialized
INFO - 2026-07-04 16:08:52 --> Model "Common_model" initialized
INFO - 2026-07-04 16:08:53 --> Final output sent to browser
DEBUG - 2026-07-04 16:08:53 --> Total execution time: 3.0533
INFO - 2026-07-04 16:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:08:53 --> Upload Class Initialized
DEBUG - 2026-07-04 16:08:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:08:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:08:53 --> Encryption Class Initialized
INFO - 2026-07-04 16:08:53 --> Form Validation Class Initialized
INFO - 2026-07-04 16:08:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:08:53 --> Pagination Class Initialized
INFO - 2026-07-04 16:08:53 --> Email Class Initialized
INFO - 2026-07-04 16:08:53 --> Controller Class Initialized
DEBUG - 2026-07-04 16:08:53 --> Billing MX_Controller Initialized
INFO - 2026-07-04 16:08:53 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 16:08:53 --> Model "Auth_model" initialized
INFO - 2026-07-04 16:08:53 --> Model "Cart_model" initialized
INFO - 2026-07-04 16:08:53 --> Model "Billing_model" initialized
INFO - 2026-07-04 16:08:53 --> Model "Common_model" initialized
INFO - 2026-07-04 16:08:53 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 16:08:54 --> Final output sent to browser
DEBUG - 2026-07-04 16:08:54 --> Total execution time: 3.7936
INFO - 2026-07-04 16:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:08:54 --> Upload Class Initialized
DEBUG - 2026-07-04 16:08:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:08:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:08:54 --> Encryption Class Initialized
INFO - 2026-07-04 16:08:54 --> Form Validation Class Initialized
INFO - 2026-07-04 16:08:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:08:54 --> Pagination Class Initialized
INFO - 2026-07-04 16:08:54 --> Email Class Initialized
INFO - 2026-07-04 16:08:54 --> Controller Class Initialized
DEBUG - 2026-07-04 16:08:54 --> Clientarea MX_Controller Initialized
INFO - 2026-07-04 16:08:54 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 16:08:54 --> Model "Auth_model" initialized
INFO - 2026-07-04 16:08:54 --> Model "Cart_model" initialized
INFO - 2026-07-04 16:08:54 --> Model "Clientarea_model" initialized
INFO - 2026-07-04 16:08:54 --> Model "Billing_model" initialized
INFO - 2026-07-04 16:08:54 --> Model "Common_model" initialized
INFO - 2026-07-04 16:08:54 --> Model "Order_model" initialized
INFO - 2026-07-04 16:08:54 --> Model "Support_model" initialized
INFO - 2026-07-04 16:08:55 --> Final output sent to browser
DEBUG - 2026-07-04 16:08:55 --> Total execution time: 4.5992
INFO - 2026-07-04 16:08:56 --> Config Class Initialized
INFO - 2026-07-04 16:08:56 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:08:56 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:08:56 --> Utf8 Class Initialized
INFO - 2026-07-04 16:08:56 --> URI Class Initialized
INFO - 2026-07-04 16:08:56 --> Router Class Initialized
INFO - 2026-07-04 16:08:56 --> Output Class Initialized
INFO - 2026-07-04 16:08:56 --> Security Class Initialized
DEBUG - 2026-07-04 16:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:08:56 --> CSRF cookie sent
INFO - 2026-07-04 16:08:56 --> Input Class Initialized
INFO - 2026-07-04 16:08:56 --> Language Class Initialized
INFO - 2026-07-04 16:08:56 --> Language Class Initialized
INFO - 2026-07-04 16:08:56 --> Config Class Initialized
INFO - 2026-07-04 16:08:56 --> Loader Class Initialized
INFO - 2026-07-04 16:08:56 --> Helper loaded: url_helper
INFO - 2026-07-04 16:08:56 --> Helper loaded: form_helper
INFO - 2026-07-04 16:08:56 --> Helper loaded: html_helper
INFO - 2026-07-04 16:08:56 --> Helper loaded: file_helper
INFO - 2026-07-04 16:08:56 --> Helper loaded: email_helper
INFO - 2026-07-04 16:08:56 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:08:56 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:08:56 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:08:56 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:08:56 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:08:56 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:08:56 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:08:56 --> Database Driver Class Initialized
INFO - 2026-07-04 16:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:08:58 --> Upload Class Initialized
DEBUG - 2026-07-04 16:08:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:08:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:08:58 --> Encryption Class Initialized
INFO - 2026-07-04 16:08:58 --> Form Validation Class Initialized
INFO - 2026-07-04 16:08:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:08:58 --> Pagination Class Initialized
INFO - 2026-07-04 16:08:58 --> Email Class Initialized
INFO - 2026-07-04 16:08:58 --> Controller Class Initialized
DEBUG - 2026-07-04 16:08:58 --> Clientarea MX_Controller Initialized
INFO - 2026-07-04 16:08:58 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 16:08:58 --> Model "Auth_model" initialized
INFO - 2026-07-04 16:08:58 --> Model "Cart_model" initialized
INFO - 2026-07-04 16:08:58 --> Model "Clientarea_model" initialized
INFO - 2026-07-04 16:08:58 --> Model "Billing_model" initialized
INFO - 2026-07-04 16:08:58 --> Model "Common_model" initialized
INFO - 2026-07-04 16:08:58 --> Model "Order_model" initialized
INFO - 2026-07-04 16:08:58 --> Model "Support_model" initialized
DEBUG - 2026-07-04 16:08:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-04 16:08:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-07-04 16:08:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-04 16:08:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-04 16:08:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_domains.php
INFO - 2026-07-04 16:08:59 --> Final output sent to browser
DEBUG - 2026-07-04 16:08:59 --> Total execution time: 3.4212
INFO - 2026-07-04 16:08:59 --> Config Class Initialized
INFO - 2026-07-04 16:08:59 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:08:59 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:08:59 --> Utf8 Class Initialized
INFO - 2026-07-04 16:08:59 --> URI Class Initialized
INFO - 2026-07-04 16:08:59 --> Router Class Initialized
INFO - 2026-07-04 16:08:59 --> Output Class Initialized
INFO - 2026-07-04 16:08:59 --> Security Class Initialized
DEBUG - 2026-07-04 16:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:08:59 --> CSRF cookie sent
INFO - 2026-07-04 16:08:59 --> Input Class Initialized
INFO - 2026-07-04 16:08:59 --> Language Class Initialized
INFO - 2026-07-04 16:08:59 --> Language Class Initialized
INFO - 2026-07-04 16:08:59 --> Config Class Initialized
INFO - 2026-07-04 16:08:59 --> Loader Class Initialized
INFO - 2026-07-04 16:08:59 --> Helper loaded: url_helper
INFO - 2026-07-04 16:08:59 --> Helper loaded: form_helper
INFO - 2026-07-04 16:08:59 --> Helper loaded: html_helper
INFO - 2026-07-04 16:08:59 --> Helper loaded: file_helper
INFO - 2026-07-04 16:08:59 --> Helper loaded: email_helper
INFO - 2026-07-04 16:08:59 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:08:59 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:08:59 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:08:59 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:08:59 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:08:59 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:08:59 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:08:59 --> Database Driver Class Initialized
INFO - 2026-07-04 16:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:09:01 --> Upload Class Initialized
DEBUG - 2026-07-04 16:09:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:09:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:09:01 --> Encryption Class Initialized
INFO - 2026-07-04 16:09:01 --> Form Validation Class Initialized
INFO - 2026-07-04 16:09:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:09:01 --> Pagination Class Initialized
INFO - 2026-07-04 16:09:01 --> Email Class Initialized
INFO - 2026-07-04 16:09:01 --> Controller Class Initialized
DEBUG - 2026-07-04 16:09:01 --> Cart MX_Controller Initialized
INFO - 2026-07-04 16:09:01 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 16:09:01 --> Model "Auth_model" initialized
INFO - 2026-07-04 16:09:01 --> Model "Cart_model" initialized
INFO - 2026-07-04 16:09:01 --> Model "Common_model" initialized
INFO - 2026-07-04 16:09:01 --> Model "Order_model" initialized
INFO - 2026-07-04 16:09:01 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 16:09:01 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-04 16:09:01 --> Model "Promocode_model" initialized
DEBUG - 2026-07-04 16:09:01 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-04 16:09:01 --> Model "Plan_model" initialized
INFO - 2026-07-04 16:09:01 --> Model "Orderlicense_model" initialized
INFO - 2026-07-04 16:09:02 --> Final output sent to browser
DEBUG - 2026-07-04 16:09:02 --> Total execution time: 2.3636
INFO - 2026-07-04 16:09:04 --> Config Class Initialized
INFO - 2026-07-04 16:09:04 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:09:04 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:09:04 --> Utf8 Class Initialized
INFO - 2026-07-04 16:09:04 --> URI Class Initialized
INFO - 2026-07-04 16:09:04 --> Router Class Initialized
INFO - 2026-07-04 16:09:04 --> Output Class Initialized
INFO - 2026-07-04 16:09:04 --> Security Class Initialized
DEBUG - 2026-07-04 16:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:09:04 --> CSRF cookie sent
INFO - 2026-07-04 16:09:04 --> Input Class Initialized
INFO - 2026-07-04 16:09:04 --> Language Class Initialized
INFO - 2026-07-04 16:09:04 --> Language Class Initialized
INFO - 2026-07-04 16:09:04 --> Config Class Initialized
INFO - 2026-07-04 16:09:04 --> Loader Class Initialized
INFO - 2026-07-04 16:09:04 --> Helper loaded: url_helper
INFO - 2026-07-04 16:09:04 --> Helper loaded: form_helper
INFO - 2026-07-04 16:09:04 --> Helper loaded: html_helper
INFO - 2026-07-04 16:09:04 --> Helper loaded: file_helper
INFO - 2026-07-04 16:09:04 --> Helper loaded: email_helper
INFO - 2026-07-04 16:09:04 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:09:04 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:09:04 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:09:04 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:09:04 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:09:04 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:09:04 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:09:04 --> Database Driver Class Initialized
INFO - 2026-07-04 16:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:09:06 --> Upload Class Initialized
DEBUG - 2026-07-04 16:09:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:09:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:09:06 --> Encryption Class Initialized
INFO - 2026-07-04 16:09:06 --> Form Validation Class Initialized
INFO - 2026-07-04 16:09:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:09:06 --> Pagination Class Initialized
INFO - 2026-07-04 16:09:06 --> Email Class Initialized
INFO - 2026-07-04 16:09:06 --> Controller Class Initialized
DEBUG - 2026-07-04 16:09:06 --> Clientarea MX_Controller Initialized
INFO - 2026-07-04 16:09:06 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 16:09:06 --> Model "Auth_model" initialized
INFO - 2026-07-04 16:09:06 --> Model "Cart_model" initialized
INFO - 2026-07-04 16:09:06 --> Model "Clientarea_model" initialized
INFO - 2026-07-04 16:09:06 --> Model "Billing_model" initialized
INFO - 2026-07-04 16:09:06 --> Model "Common_model" initialized
INFO - 2026-07-04 16:09:06 --> Model "Order_model" initialized
INFO - 2026-07-04 16:09:06 --> Model "Support_model" initialized
DEBUG - 2026-07-04 16:09:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-04 16:09:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/domain_nav.php
DEBUG - 2026-07-04 16:09:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-04 16:09:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-04 16:09:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_domain_detail.php
INFO - 2026-07-04 16:09:07 --> Final output sent to browser
DEBUG - 2026-07-04 16:09:07 --> Total execution time: 3.2559
INFO - 2026-07-04 16:09:07 --> Config Class Initialized
INFO - 2026-07-04 16:09:07 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:09:07 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:09:07 --> Utf8 Class Initialized
INFO - 2026-07-04 16:09:07 --> URI Class Initialized
INFO - 2026-07-04 16:09:07 --> Router Class Initialized
INFO - 2026-07-04 16:09:07 --> Output Class Initialized
INFO - 2026-07-04 16:09:07 --> Security Class Initialized
INFO - 2026-07-04 16:09:07 --> Config Class Initialized
INFO - 2026-07-04 16:09:07 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:09:07 --> CSRF cookie sent
INFO - 2026-07-04 16:09:07 --> Input Class Initialized
INFO - 2026-07-04 16:09:07 --> Language Class Initialized
DEBUG - 2026-07-04 16:09:07 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:09:07 --> Utf8 Class Initialized
INFO - 2026-07-04 16:09:07 --> Language Class Initialized
INFO - 2026-07-04 16:09:07 --> Config Class Initialized
INFO - 2026-07-04 16:09:07 --> URI Class Initialized
INFO - 2026-07-04 16:09:07 --> Loader Class Initialized
INFO - 2026-07-04 16:09:07 --> Helper loaded: url_helper
INFO - 2026-07-04 16:09:07 --> Router Class Initialized
INFO - 2026-07-04 16:09:07 --> Helper loaded: form_helper
INFO - 2026-07-04 16:09:07 --> Helper loaded: html_helper
INFO - 2026-07-04 16:09:07 --> Helper loaded: file_helper
INFO - 2026-07-04 16:09:07 --> Helper loaded: email_helper
INFO - 2026-07-04 16:09:07 --> Output Class Initialized
INFO - 2026-07-04 16:09:07 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:09:07 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:09:07 --> Security Class Initialized
DEBUG - 2026-07-04 16:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:09:07 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:09:07 --> Input Class Initialized
INFO - 2026-07-04 16:09:07 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:09:07 --> Language Class Initialized
INFO - 2026-07-04 16:09:07 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:09:07 --> Language Class Initialized
INFO - 2026-07-04 16:09:07 --> Config Class Initialized
INFO - 2026-07-04 16:09:07 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:09:07 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:09:07 --> Loader Class Initialized
INFO - 2026-07-04 16:09:07 --> Helper loaded: url_helper
INFO - 2026-07-04 16:09:07 --> Helper loaded: form_helper
INFO - 2026-07-04 16:09:07 --> Helper loaded: html_helper
INFO - 2026-07-04 16:09:07 --> Helper loaded: file_helper
INFO - 2026-07-04 16:09:07 --> Helper loaded: email_helper
INFO - 2026-07-04 16:09:07 --> Database Driver Class Initialized
INFO - 2026-07-04 16:09:07 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:09:07 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:09:07 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:09:07 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:09:07 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:09:07 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:09:07 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:09:07 --> Database Driver Class Initialized
INFO - 2026-07-04 16:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:09:09 --> Upload Class Initialized
DEBUG - 2026-07-04 16:09:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:09:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:09:09 --> Encryption Class Initialized
INFO - 2026-07-04 16:09:09 --> Form Validation Class Initialized
INFO - 2026-07-04 16:09:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:09:09 --> Pagination Class Initialized
INFO - 2026-07-04 16:09:09 --> Email Class Initialized
INFO - 2026-07-04 16:09:09 --> Controller Class Initialized
DEBUG - 2026-07-04 16:09:09 --> Cart MX_Controller Initialized
INFO - 2026-07-04 16:09:09 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 16:09:09 --> Model "Auth_model" initialized
INFO - 2026-07-04 16:09:09 --> Model "Cart_model" initialized
INFO - 2026-07-04 16:09:09 --> Model "Common_model" initialized
INFO - 2026-07-04 16:09:09 --> Model "Order_model" initialized
INFO - 2026-07-04 16:09:09 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 16:09:09 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-04 16:09:09 --> Model "Promocode_model" initialized
DEBUG - 2026-07-04 16:09:09 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-04 16:09:09 --> Model "Plan_model" initialized
INFO - 2026-07-04 16:09:09 --> Model "Orderlicense_model" initialized
INFO - 2026-07-04 16:09:09 --> Final output sent to browser
DEBUG - 2026-07-04 16:09:09 --> Total execution time: 2.2046
INFO - 2026-07-04 16:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:09:09 --> Upload Class Initialized
DEBUG - 2026-07-04 16:09:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:09:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:09:09 --> Encryption Class Initialized
INFO - 2026-07-04 16:09:09 --> Form Validation Class Initialized
INFO - 2026-07-04 16:09:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:09:09 --> Pagination Class Initialized
INFO - 2026-07-04 16:09:10 --> Email Class Initialized
INFO - 2026-07-04 16:09:10 --> Controller Class Initialized
DEBUG - 2026-07-04 16:09:10 --> Clientarea MX_Controller Initialized
INFO - 2026-07-04 16:09:10 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 16:09:10 --> Model "Auth_model" initialized
INFO - 2026-07-04 16:09:10 --> Model "Cart_model" initialized
INFO - 2026-07-04 16:09:10 --> Model "Clientarea_model" initialized
INFO - 2026-07-04 16:09:10 --> Model "Billing_model" initialized
INFO - 2026-07-04 16:09:10 --> Model "Common_model" initialized
INFO - 2026-07-04 16:09:10 --> Model "Order_model" initialized
INFO - 2026-07-04 16:09:10 --> Model "Support_model" initialized
DEBUG - 2026-07-04 16:09:10 --> API Request URL: https://api.sandbox.namecheap.com/xml.response?ApiUser=tongbaritest&ApiKey=993d950d882041ed90eea8158abec1d3&UserName=tongbaritest&Command=namecheap.domains.getRegistrarLock&ClientIp=67.222.24.126&DomainName=testing-ecomz.xyz
INFO - 2026-07-04 16:09:12 --> Final output sent to browser
DEBUG - 2026-07-04 16:09:12 --> Total execution time: 4.5405
INFO - 2026-07-04 16:10:46 --> Config Class Initialized
INFO - 2026-07-04 16:10:46 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:10:46 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:10:46 --> Utf8 Class Initialized
INFO - 2026-07-04 16:10:46 --> URI Class Initialized
INFO - 2026-07-04 16:10:46 --> Router Class Initialized
INFO - 2026-07-04 16:10:46 --> Output Class Initialized
INFO - 2026-07-04 16:10:46 --> Security Class Initialized
DEBUG - 2026-07-04 16:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:10:46 --> Input Class Initialized
INFO - 2026-07-04 16:10:46 --> Language Class Initialized
INFO - 2026-07-04 16:10:46 --> Language Class Initialized
INFO - 2026-07-04 16:10:46 --> Config Class Initialized
INFO - 2026-07-04 16:10:46 --> Loader Class Initialized
INFO - 2026-07-04 16:10:46 --> Helper loaded: url_helper
INFO - 2026-07-04 16:10:46 --> Helper loaded: form_helper
INFO - 2026-07-04 16:10:46 --> Helper loaded: html_helper
INFO - 2026-07-04 16:10:46 --> Helper loaded: file_helper
INFO - 2026-07-04 16:10:46 --> Helper loaded: email_helper
INFO - 2026-07-04 16:10:46 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:10:46 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:10:46 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:10:46 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:10:46 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:10:46 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:10:46 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:10:46 --> Database Driver Class Initialized
INFO - 2026-07-04 16:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:10:48 --> Upload Class Initialized
DEBUG - 2026-07-04 16:10:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:10:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:10:48 --> Encryption Class Initialized
INFO - 2026-07-04 16:10:48 --> Form Validation Class Initialized
INFO - 2026-07-04 16:10:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:10:48 --> Pagination Class Initialized
INFO - 2026-07-04 16:10:48 --> Email Class Initialized
INFO - 2026-07-04 16:10:48 --> Controller Class Initialized
DEBUG - 2026-07-04 16:10:48 --> Clientarea MX_Controller Initialized
INFO - 2026-07-04 16:10:48 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 16:10:48 --> Model "Auth_model" initialized
INFO - 2026-07-04 16:10:48 --> Model "Cart_model" initialized
INFO - 2026-07-04 16:10:48 --> Model "Clientarea_model" initialized
INFO - 2026-07-04 16:10:48 --> Model "Billing_model" initialized
INFO - 2026-07-04 16:10:48 --> Model "Common_model" initialized
INFO - 2026-07-04 16:10:48 --> Model "Order_model" initialized
INFO - 2026-07-04 16:10:48 --> Model "Support_model" initialized
DEBUG - 2026-07-04 16:10:48 --> API Request URL: https://api.sandbox.namecheap.com/xml.response?ApiUser=tongbaritest&ApiKey=993d950d882041ed90eea8158abec1d3&UserName=tongbaritest&Command=namecheap.domains.getContacts&ClientIp=67.222.24.126&DomainName=testing-ecomz.xyz
INFO - 2026-07-04 16:10:49 --> Final output sent to browser
DEBUG - 2026-07-04 16:10:49 --> Total execution time: 3.0102
INFO - 2026-07-04 16:19:31 --> Config Class Initialized
INFO - 2026-07-04 16:19:31 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:19:31 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:19:31 --> Utf8 Class Initialized
INFO - 2026-07-04 16:19:31 --> URI Class Initialized
INFO - 2026-07-04 16:19:31 --> Router Class Initialized
INFO - 2026-07-04 16:19:31 --> Output Class Initialized
INFO - 2026-07-04 16:19:31 --> Security Class Initialized
DEBUG - 2026-07-04 16:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:19:31 --> CSRF cookie sent
INFO - 2026-07-04 16:19:31 --> Input Class Initialized
INFO - 2026-07-04 16:19:31 --> Language Class Initialized
INFO - 2026-07-04 16:19:31 --> Language Class Initialized
INFO - 2026-07-04 16:19:31 --> Config Class Initialized
INFO - 2026-07-04 16:19:31 --> Loader Class Initialized
INFO - 2026-07-04 16:19:31 --> Helper loaded: url_helper
INFO - 2026-07-04 16:19:31 --> Helper loaded: form_helper
INFO - 2026-07-04 16:19:31 --> Helper loaded: html_helper
INFO - 2026-07-04 16:19:31 --> Helper loaded: file_helper
INFO - 2026-07-04 16:19:31 --> Helper loaded: email_helper
INFO - 2026-07-04 16:19:31 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:19:31 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:19:31 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:19:31 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:19:31 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:19:31 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:19:31 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:19:32 --> Database Driver Class Initialized
INFO - 2026-07-04 16:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:19:33 --> Upload Class Initialized
DEBUG - 2026-07-04 16:19:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:19:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:19:33 --> Encryption Class Initialized
INFO - 2026-07-04 16:19:33 --> Form Validation Class Initialized
INFO - 2026-07-04 16:19:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:19:33 --> Pagination Class Initialized
INFO - 2026-07-04 16:19:33 --> Email Class Initialized
INFO - 2026-07-04 16:19:33 --> Controller Class Initialized
DEBUG - 2026-07-04 16:19:33 --> Clientarea MX_Controller Initialized
INFO - 2026-07-04 16:19:33 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 16:19:33 --> Model "Auth_model" initialized
INFO - 2026-07-04 16:19:33 --> Model "Cart_model" initialized
INFO - 2026-07-04 16:19:33 --> Model "Clientarea_model" initialized
INFO - 2026-07-04 16:19:33 --> Model "Billing_model" initialized
INFO - 2026-07-04 16:19:33 --> Model "Common_model" initialized
INFO - 2026-07-04 16:19:33 --> Model "Order_model" initialized
INFO - 2026-07-04 16:19:33 --> Model "Support_model" initialized
DEBUG - 2026-07-04 16:19:35 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-04 16:19:35 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/domain_nav.php
DEBUG - 2026-07-04 16:19:35 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-04 16:19:35 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-04 16:19:35 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_domain_detail.php
INFO - 2026-07-04 16:19:35 --> Final output sent to browser
DEBUG - 2026-07-04 16:19:35 --> Total execution time: 3.4746
INFO - 2026-07-04 16:19:35 --> Config Class Initialized
INFO - 2026-07-04 16:19:35 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:19:35 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:19:35 --> Utf8 Class Initialized
INFO - 2026-07-04 16:19:35 --> URI Class Initialized
INFO - 2026-07-04 16:19:35 --> Router Class Initialized
INFO - 2026-07-04 16:19:35 --> Output Class Initialized
INFO - 2026-07-04 16:19:35 --> Security Class Initialized
DEBUG - 2026-07-04 16:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:19:35 --> CSRF cookie sent
INFO - 2026-07-04 16:19:35 --> Input Class Initialized
INFO - 2026-07-04 16:19:35 --> Config Class Initialized
INFO - 2026-07-04 16:19:35 --> Hooks Class Initialized
INFO - 2026-07-04 16:19:35 --> Language Class Initialized
INFO - 2026-07-04 16:19:35 --> Language Class Initialized
INFO - 2026-07-04 16:19:35 --> Config Class Initialized
DEBUG - 2026-07-04 16:19:35 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:19:35 --> Utf8 Class Initialized
INFO - 2026-07-04 16:19:35 --> URI Class Initialized
INFO - 2026-07-04 16:19:35 --> Loader Class Initialized
INFO - 2026-07-04 16:19:35 --> Helper loaded: url_helper
INFO - 2026-07-04 16:19:35 --> Helper loaded: form_helper
INFO - 2026-07-04 16:19:35 --> Helper loaded: html_helper
INFO - 2026-07-04 16:19:35 --> Helper loaded: file_helper
INFO - 2026-07-04 16:19:35 --> Helper loaded: email_helper
INFO - 2026-07-04 16:19:35 --> Router Class Initialized
INFO - 2026-07-04 16:19:35 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:19:35 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:19:35 --> Output Class Initialized
INFO - 2026-07-04 16:19:35 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:19:35 --> Security Class Initialized
INFO - 2026-07-04 16:19:35 --> Helper loaded: plesk_helper
DEBUG - 2026-07-04 16:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:19:35 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:19:35 --> Input Class Initialized
INFO - 2026-07-04 16:19:35 --> Language Class Initialized
INFO - 2026-07-04 16:19:35 --> Language Class Initialized
INFO - 2026-07-04 16:19:35 --> Config Class Initialized
INFO - 2026-07-04 16:19:35 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:19:35 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:19:35 --> Loader Class Initialized
INFO - 2026-07-04 16:19:35 --> Helper loaded: url_helper
INFO - 2026-07-04 16:19:35 --> Helper loaded: form_helper
INFO - 2026-07-04 16:19:35 --> Helper loaded: html_helper
INFO - 2026-07-04 16:19:35 --> Database Driver Class Initialized
INFO - 2026-07-04 16:19:35 --> Helper loaded: file_helper
INFO - 2026-07-04 16:19:35 --> Helper loaded: email_helper
INFO - 2026-07-04 16:19:35 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:19:35 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:19:35 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:19:35 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:19:35 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:19:35 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:19:35 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:19:35 --> Database Driver Class Initialized
INFO - 2026-07-04 16:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:19:37 --> Upload Class Initialized
DEBUG - 2026-07-04 16:19:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:19:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:19:37 --> Encryption Class Initialized
INFO - 2026-07-04 16:19:37 --> Form Validation Class Initialized
INFO - 2026-07-04 16:19:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:19:37 --> Pagination Class Initialized
INFO - 2026-07-04 16:19:37 --> Email Class Initialized
INFO - 2026-07-04 16:19:37 --> Controller Class Initialized
DEBUG - 2026-07-04 16:19:37 --> Clientarea MX_Controller Initialized
INFO - 2026-07-04 16:19:37 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 16:19:37 --> Model "Auth_model" initialized
INFO - 2026-07-04 16:19:37 --> Model "Cart_model" initialized
INFO - 2026-07-04 16:19:37 --> Model "Clientarea_model" initialized
INFO - 2026-07-04 16:19:37 --> Model "Billing_model" initialized
INFO - 2026-07-04 16:19:37 --> Model "Common_model" initialized
INFO - 2026-07-04 16:19:37 --> Model "Order_model" initialized
INFO - 2026-07-04 16:19:37 --> Model "Support_model" initialized
DEBUG - 2026-07-04 16:19:38 --> API Request URL: https://api.sandbox.namecheap.com/xml.response?ApiUser=tongbaritest&ApiKey=993d950d882041ed90eea8158abec1d3&UserName=tongbaritest&Command=namecheap.domains.getRegistrarLock&ClientIp=67.222.24.126&DomainName=testing-ecomz.xyz
INFO - 2026-07-04 16:19:40 --> Final output sent to browser
DEBUG - 2026-07-04 16:19:40 --> Total execution time: 4.3417
INFO - 2026-07-04 16:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:19:40 --> Upload Class Initialized
DEBUG - 2026-07-04 16:19:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:19:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:19:40 --> Encryption Class Initialized
INFO - 2026-07-04 16:19:40 --> Form Validation Class Initialized
INFO - 2026-07-04 16:19:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:19:40 --> Pagination Class Initialized
INFO - 2026-07-04 16:19:40 --> Email Class Initialized
INFO - 2026-07-04 16:19:40 --> Controller Class Initialized
DEBUG - 2026-07-04 16:19:40 --> Cart MX_Controller Initialized
INFO - 2026-07-04 16:19:40 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 16:19:40 --> Model "Auth_model" initialized
INFO - 2026-07-04 16:19:40 --> Model "Cart_model" initialized
INFO - 2026-07-04 16:19:40 --> Model "Common_model" initialized
INFO - 2026-07-04 16:19:40 --> Model "Order_model" initialized
INFO - 2026-07-04 16:19:40 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 16:19:40 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-04 16:19:40 --> Model "Promocode_model" initialized
DEBUG - 2026-07-04 16:19:40 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-04 16:19:40 --> Model "Plan_model" initialized
INFO - 2026-07-04 16:19:40 --> Model "Orderlicense_model" initialized
INFO - 2026-07-04 16:19:40 --> Final output sent to browser
DEBUG - 2026-07-04 16:19:40 --> Total execution time: 4.7890
INFO - 2026-07-04 16:20:51 --> Config Class Initialized
INFO - 2026-07-04 16:20:51 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:20:51 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:20:51 --> Utf8 Class Initialized
INFO - 2026-07-04 16:20:51 --> URI Class Initialized
INFO - 2026-07-04 16:20:51 --> Router Class Initialized
INFO - 2026-07-04 16:20:51 --> Output Class Initialized
INFO - 2026-07-04 16:20:51 --> Config Class Initialized
INFO - 2026-07-04 16:20:51 --> Security Class Initialized
INFO - 2026-07-04 16:20:51 --> Hooks Class Initialized
INFO - 2026-07-04 16:20:51 --> Config Class Initialized
INFO - 2026-07-04 16:20:51 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:20:51 --> CSRF cookie sent
INFO - 2026-07-04 16:20:51 --> Input Class Initialized
INFO - 2026-07-04 16:20:51 --> Language Class Initialized
DEBUG - 2026-07-04 16:20:51 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:20:51 --> Utf8 Class Initialized
DEBUG - 2026-07-04 16:20:51 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:20:51 --> Utf8 Class Initialized
INFO - 2026-07-04 16:20:51 --> URI Class Initialized
INFO - 2026-07-04 16:20:51 --> Language Class Initialized
INFO - 2026-07-04 16:20:51 --> Config Class Initialized
INFO - 2026-07-04 16:20:51 --> URI Class Initialized
INFO - 2026-07-04 16:20:51 --> Config Class Initialized
INFO - 2026-07-04 16:20:51 --> Hooks Class Initialized
INFO - 2026-07-04 16:20:51 --> Router Class Initialized
INFO - 2026-07-04 16:20:51 --> Router Class Initialized
INFO - 2026-07-04 16:20:51 --> Config Class Initialized
INFO - 2026-07-04 16:20:51 --> Hooks Class Initialized
INFO - 2026-07-04 16:20:51 --> Loader Class Initialized
DEBUG - 2026-07-04 16:20:51 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:20:51 --> Utf8 Class Initialized
INFO - 2026-07-04 16:20:51 --> Helper loaded: url_helper
INFO - 2026-07-04 16:20:51 --> Output Class Initialized
INFO - 2026-07-04 16:20:51 --> Output Class Initialized
INFO - 2026-07-04 16:20:51 --> URI Class Initialized
DEBUG - 2026-07-04 16:20:51 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:20:51 --> Utf8 Class Initialized
INFO - 2026-07-04 16:20:51 --> Helper loaded: form_helper
INFO - 2026-07-04 16:20:51 --> URI Class Initialized
INFO - 2026-07-04 16:20:51 --> Security Class Initialized
INFO - 2026-07-04 16:20:51 --> Security Class Initialized
INFO - 2026-07-04 16:20:51 --> Helper loaded: html_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: file_helper
INFO - 2026-07-04 16:20:51 --> Router Class Initialized
INFO - 2026-07-04 16:20:51 --> Helper loaded: email_helper
DEBUG - 2026-07-04 16:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-07-04 16:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:20:51 --> CSRF cookie sent
INFO - 2026-07-04 16:20:51 --> CSRF cookie sent
INFO - 2026-07-04 16:20:51 --> Input Class Initialized
INFO - 2026-07-04 16:20:51 --> Input Class Initialized
INFO - 2026-07-04 16:20:51 --> Language Class Initialized
INFO - 2026-07-04 16:20:51 --> Language Class Initialized
INFO - 2026-07-04 16:20:51 --> Config Class Initialized
INFO - 2026-07-04 16:20:51 --> Hooks Class Initialized
INFO - 2026-07-04 16:20:51 --> Output Class Initialized
INFO - 2026-07-04 16:20:51 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:20:51 --> Language Class Initialized
INFO - 2026-07-04 16:20:51 --> Language Class Initialized
INFO - 2026-07-04 16:20:51 --> Config Class Initialized
INFO - 2026-07-04 16:20:51 --> Config Class Initialized
INFO - 2026-07-04 16:20:51 --> Security Class Initialized
DEBUG - 2026-07-04 16:20:51 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:20:51 --> Utf8 Class Initialized
DEBUG - 2026-07-04 16:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:20:51 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:20:51 --> URI Class Initialized
INFO - 2026-07-04 16:20:51 --> CSRF cookie sent
INFO - 2026-07-04 16:20:51 --> Input Class Initialized
INFO - 2026-07-04 16:20:51 --> Language Class Initialized
INFO - 2026-07-04 16:20:51 --> Router Class Initialized
INFO - 2026-07-04 16:20:51 --> Loader Class Initialized
INFO - 2026-07-04 16:20:51 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:20:51 --> Loader Class Initialized
INFO - 2026-07-04 16:20:51 --> Language Class Initialized
INFO - 2026-07-04 16:20:51 --> Config Class Initialized
INFO - 2026-07-04 16:20:51 --> Router Class Initialized
INFO - 2026-07-04 16:20:51 --> Helper loaded: url_helper
INFO - 2026-07-04 16:20:51 --> Output Class Initialized
INFO - 2026-07-04 16:20:51 --> Helper loaded: url_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: form_helper
INFO - 2026-07-04 16:20:51 --> Output Class Initialized
INFO - 2026-07-04 16:20:51 --> Security Class Initialized
INFO - 2026-07-04 16:20:51 --> Helper loaded: form_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: html_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: html_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: file_helper
DEBUG - 2026-07-04 16:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:20:51 --> Helper loaded: email_helper
INFO - 2026-07-04 16:20:51 --> CSRF cookie sent
INFO - 2026-07-04 16:20:51 --> Helper loaded: file_helper
INFO - 2026-07-04 16:20:51 --> Security Class Initialized
INFO - 2026-07-04 16:20:51 --> Input Class Initialized
INFO - 2026-07-04 16:20:51 --> Helper loaded: email_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:20:51 --> Loader Class Initialized
INFO - 2026-07-04 16:20:51 --> Language Class Initialized
INFO - 2026-07-04 16:20:51 --> Helper loaded: entitlement_helper
DEBUG - 2026-07-04 16:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:20:51 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:20:51 --> CSRF cookie sent
INFO - 2026-07-04 16:20:51 --> Input Class Initialized
INFO - 2026-07-04 16:20:51 --> Language Class Initialized
INFO - 2026-07-04 16:20:51 --> Config Class Initialized
INFO - 2026-07-04 16:20:51 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:20:51 --> Language Class Initialized
INFO - 2026-07-04 16:20:51 --> Helper loaded: url_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:20:51 --> Language Class Initialized
INFO - 2026-07-04 16:20:51 --> Config Class Initialized
INFO - 2026-07-04 16:20:51 --> Helper loaded: form_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: html_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:20:51 --> Loader Class Initialized
INFO - 2026-07-04 16:20:51 --> Helper loaded: file_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: email_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: url_helper
INFO - 2026-07-04 16:20:51 --> Loader Class Initialized
INFO - 2026-07-04 16:20:51 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: form_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: url_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: html_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:20:51 --> Database Driver Class Initialized
INFO - 2026-07-04 16:20:51 --> Helper loaded: file_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: email_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: form_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: html_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: file_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: email_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:20:51 --> Database Driver Class Initialized
INFO - 2026-07-04 16:20:51 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:20:51 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:20:51 --> Database Driver Class Initialized
INFO - 2026-07-04 16:20:51 --> Database Driver Class Initialized
INFO - 2026-07-04 16:20:51 --> Database Driver Class Initialized
INFO - 2026-07-04 16:20:51 --> Database Driver Class Initialized
INFO - 2026-07-04 16:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:20:53 --> Upload Class Initialized
DEBUG - 2026-07-04 16:20:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:20:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:20:53 --> Encryption Class Initialized
INFO - 2026-07-04 16:20:53 --> Form Validation Class Initialized
INFO - 2026-07-04 16:20:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:20:53 --> Pagination Class Initialized
INFO - 2026-07-04 16:20:53 --> Email Class Initialized
INFO - 2026-07-04 16:20:53 --> Controller Class Initialized
ERROR - 2026-07-04 16:20:53 --> 404 Page Not Found: /index
INFO - 2026-07-04 16:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:20:53 --> Upload Class Initialized
DEBUG - 2026-07-04 16:20:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:20:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:20:53 --> Encryption Class Initialized
INFO - 2026-07-04 16:20:53 --> Form Validation Class Initialized
INFO - 2026-07-04 16:20:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:20:53 --> Pagination Class Initialized
INFO - 2026-07-04 16:20:53 --> Config Class Initialized
INFO - 2026-07-04 16:20:53 --> Hooks Class Initialized
INFO - 2026-07-04 16:20:53 --> Email Class Initialized
INFO - 2026-07-04 16:20:53 --> Controller Class Initialized
DEBUG - 2026-07-04 16:20:53 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:20:53 --> Utf8 Class Initialized
ERROR - 2026-07-04 16:20:53 --> 404 Page Not Found: /index
INFO - 2026-07-04 16:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:20:53 --> URI Class Initialized
INFO - 2026-07-04 16:20:53 --> Upload Class Initialized
INFO - 2026-07-04 16:20:53 --> Router Class Initialized
DEBUG - 2026-07-04 16:20:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:20:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:20:53 --> Encryption Class Initialized
INFO - 2026-07-04 16:20:53 --> Output Class Initialized
INFO - 2026-07-04 16:20:53 --> Form Validation Class Initialized
INFO - 2026-07-04 16:20:53 --> Security Class Initialized
INFO - 2026-07-04 16:20:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:20:53 --> Pagination Class Initialized
DEBUG - 2026-07-04 16:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:20:53 --> CSRF cookie sent
INFO - 2026-07-04 16:20:53 --> Input Class Initialized
INFO - 2026-07-04 16:20:53 --> Language Class Initialized
INFO - 2026-07-04 16:20:53 --> Language Class Initialized
INFO - 2026-07-04 16:20:53 --> Config Class Initialized
INFO - 2026-07-04 16:20:53 --> Email Class Initialized
INFO - 2026-07-04 16:20:53 --> Controller Class Initialized
ERROR - 2026-07-04 16:20:53 --> 404 Page Not Found: /index
INFO - 2026-07-04 16:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:20:53 --> Loader Class Initialized
INFO - 2026-07-04 16:20:53 --> Helper loaded: url_helper
INFO - 2026-07-04 16:20:53 --> Upload Class Initialized
DEBUG - 2026-07-04 16:20:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:20:53 --> Helper loaded: form_helper
INFO - 2026-07-04 16:20:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:20:53 --> Encryption Class Initialized
INFO - 2026-07-04 16:20:53 --> Helper loaded: html_helper
INFO - 2026-07-04 16:20:53 --> Helper loaded: file_helper
INFO - 2026-07-04 16:20:53 --> Form Validation Class Initialized
INFO - 2026-07-04 16:20:53 --> Helper loaded: email_helper
INFO - 2026-07-04 16:20:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:20:53 --> Pagination Class Initialized
INFO - 2026-07-04 16:20:53 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:20:53 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:20:53 --> Email Class Initialized
INFO - 2026-07-04 16:20:53 --> Controller Class Initialized
ERROR - 2026-07-04 16:20:53 --> 404 Page Not Found: /index
INFO - 2026-07-04 16:20:53 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:20:53 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:20:53 --> Upload Class Initialized
INFO - 2026-07-04 16:20:53 --> Helper loaded: directadmin_helper
DEBUG - 2026-07-04 16:20:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:20:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:20:53 --> Encryption Class Initialized
INFO - 2026-07-04 16:20:53 --> Form Validation Class Initialized
INFO - 2026-07-04 16:20:53 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:20:53 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:20:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:20:53 --> Pagination Class Initialized
INFO - 2026-07-04 16:20:53 --> Email Class Initialized
INFO - 2026-07-04 16:20:53 --> Controller Class Initialized
ERROR - 2026-07-04 16:20:53 --> 404 Page Not Found: /index
INFO - 2026-07-04 16:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:20:53 --> Upload Class Initialized
INFO - 2026-07-04 16:20:53 --> Database Driver Class Initialized
DEBUG - 2026-07-04 16:20:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:20:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:20:53 --> Encryption Class Initialized
INFO - 2026-07-04 16:20:53 --> Form Validation Class Initialized
INFO - 2026-07-04 16:20:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:20:53 --> Pagination Class Initialized
INFO - 2026-07-04 16:20:53 --> Email Class Initialized
INFO - 2026-07-04 16:20:53 --> Controller Class Initialized
ERROR - 2026-07-04 16:20:53 --> 404 Page Not Found: /index
INFO - 2026-07-04 16:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:20:55 --> Upload Class Initialized
DEBUG - 2026-07-04 16:20:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:20:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:20:55 --> Encryption Class Initialized
INFO - 2026-07-04 16:20:55 --> Form Validation Class Initialized
INFO - 2026-07-04 16:20:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:20:55 --> Pagination Class Initialized
INFO - 2026-07-04 16:20:55 --> Email Class Initialized
INFO - 2026-07-04 16:20:55 --> Controller Class Initialized
ERROR - 2026-07-04 16:20:55 --> 404 Page Not Found: /index
INFO - 2026-07-04 16:21:00 --> Config Class Initialized
INFO - 2026-07-04 16:21:00 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:21:00 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:21:00 --> Utf8 Class Initialized
INFO - 2026-07-04 16:21:00 --> URI Class Initialized
INFO - 2026-07-04 16:21:00 --> Router Class Initialized
INFO - 2026-07-04 16:21:00 --> Output Class Initialized
INFO - 2026-07-04 16:21:00 --> Security Class Initialized
DEBUG - 2026-07-04 16:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:21:00 --> CSRF cookie sent
INFO - 2026-07-04 16:21:00 --> Input Class Initialized
INFO - 2026-07-04 16:21:00 --> Language Class Initialized
INFO - 2026-07-04 16:21:00 --> Language Class Initialized
INFO - 2026-07-04 16:21:00 --> Config Class Initialized
INFO - 2026-07-04 16:21:00 --> Loader Class Initialized
INFO - 2026-07-04 16:21:00 --> Helper loaded: url_helper
INFO - 2026-07-04 16:21:00 --> Helper loaded: form_helper
INFO - 2026-07-04 16:21:00 --> Helper loaded: html_helper
INFO - 2026-07-04 16:21:00 --> Helper loaded: file_helper
INFO - 2026-07-04 16:21:00 --> Helper loaded: email_helper
INFO - 2026-07-04 16:21:00 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:21:00 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:21:00 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:21:00 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:21:00 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:21:00 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:21:00 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:21:00 --> Database Driver Class Initialized
INFO - 2026-07-04 16:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:21:02 --> Upload Class Initialized
DEBUG - 2026-07-04 16:21:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:21:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:21:02 --> Encryption Class Initialized
INFO - 2026-07-04 16:21:02 --> Form Validation Class Initialized
INFO - 2026-07-04 16:21:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:21:02 --> Pagination Class Initialized
INFO - 2026-07-04 16:21:02 --> Email Class Initialized
INFO - 2026-07-04 16:21:02 --> Controller Class Initialized
DEBUG - 2026-07-04 16:21:02 --> Clientarea MX_Controller Initialized
INFO - 2026-07-04 16:21:02 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 16:21:02 --> Model "Auth_model" initialized
INFO - 2026-07-04 16:21:02 --> Model "Cart_model" initialized
INFO - 2026-07-04 16:21:02 --> Model "Clientarea_model" initialized
INFO - 2026-07-04 16:21:02 --> Model "Billing_model" initialized
INFO - 2026-07-04 16:21:02 --> Model "Common_model" initialized
INFO - 2026-07-04 16:21:02 --> Model "Order_model" initialized
INFO - 2026-07-04 16:21:02 --> Model "Support_model" initialized
DEBUG - 2026-07-04 16:21:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-04 16:21:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/domain_nav.php
DEBUG - 2026-07-04 16:21:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-04 16:21:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-04 16:21:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_domain_detail.php
INFO - 2026-07-04 16:21:03 --> Final output sent to browser
DEBUG - 2026-07-04 16:21:03 --> Total execution time: 3.4694
INFO - 2026-07-04 16:21:03 --> Config Class Initialized
INFO - 2026-07-04 16:21:03 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:21:03 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:21:03 --> Utf8 Class Initialized
INFO - 2026-07-04 16:21:03 --> URI Class Initialized
INFO - 2026-07-04 16:21:03 --> Router Class Initialized
INFO - 2026-07-04 16:21:03 --> Output Class Initialized
INFO - 2026-07-04 16:21:03 --> Security Class Initialized
DEBUG - 2026-07-04 16:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:21:03 --> CSRF cookie sent
INFO - 2026-07-04 16:21:03 --> Input Class Initialized
INFO - 2026-07-04 16:21:03 --> Language Class Initialized
INFO - 2026-07-04 16:21:03 --> Language Class Initialized
INFO - 2026-07-04 16:21:03 --> Config Class Initialized
INFO - 2026-07-04 16:21:03 --> Loader Class Initialized
INFO - 2026-07-04 16:21:03 --> Helper loaded: url_helper
INFO - 2026-07-04 16:21:03 --> Helper loaded: form_helper
INFO - 2026-07-04 16:21:03 --> Helper loaded: html_helper
INFO - 2026-07-04 16:21:03 --> Helper loaded: file_helper
INFO - 2026-07-04 16:21:03 --> Helper loaded: email_helper
INFO - 2026-07-04 16:21:03 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:21:03 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:21:03 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:21:03 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:21:03 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:21:03 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:21:03 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:21:03 --> Database Driver Class Initialized
INFO - 2026-07-04 16:21:04 --> Config Class Initialized
INFO - 2026-07-04 16:21:04 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:21:04 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:21:04 --> Utf8 Class Initialized
INFO - 2026-07-04 16:21:04 --> URI Class Initialized
INFO - 2026-07-04 16:21:04 --> Router Class Initialized
INFO - 2026-07-04 16:21:04 --> Output Class Initialized
INFO - 2026-07-04 16:21:04 --> Security Class Initialized
DEBUG - 2026-07-04 16:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:21:04 --> CSRF cookie sent
INFO - 2026-07-04 16:21:04 --> Input Class Initialized
INFO - 2026-07-04 16:21:04 --> Language Class Initialized
INFO - 2026-07-04 16:21:04 --> Language Class Initialized
INFO - 2026-07-04 16:21:04 --> Config Class Initialized
INFO - 2026-07-04 16:21:04 --> Loader Class Initialized
INFO - 2026-07-04 16:21:04 --> Helper loaded: url_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: form_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: html_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: file_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: email_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:21:04 --> Config Class Initialized
INFO - 2026-07-04 16:21:04 --> Hooks Class Initialized
INFO - 2026-07-04 16:21:04 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:21:04 --> Config Class Initialized
INFO - 2026-07-04 16:21:04 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:21:04 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:21:04 --> Utf8 Class Initialized
INFO - 2026-07-04 16:21:04 --> URI Class Initialized
DEBUG - 2026-07-04 16:21:04 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:21:04 --> Utf8 Class Initialized
INFO - 2026-07-04 16:21:04 --> Config Class Initialized
INFO - 2026-07-04 16:21:04 --> Hooks Class Initialized
INFO - 2026-07-04 16:21:04 --> Database Driver Class Initialized
INFO - 2026-07-04 16:21:04 --> URI Class Initialized
DEBUG - 2026-07-04 16:21:04 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:21:04 --> Utf8 Class Initialized
INFO - 2026-07-04 16:21:04 --> URI Class Initialized
INFO - 2026-07-04 16:21:04 --> Router Class Initialized
INFO - 2026-07-04 16:21:04 --> Router Class Initialized
INFO - 2026-07-04 16:21:04 --> Config Class Initialized
INFO - 2026-07-04 16:21:04 --> Hooks Class Initialized
INFO - 2026-07-04 16:21:04 --> Output Class Initialized
INFO - 2026-07-04 16:21:04 --> Output Class Initialized
DEBUG - 2026-07-04 16:21:04 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:21:04 --> Router Class Initialized
INFO - 2026-07-04 16:21:04 --> Security Class Initialized
DEBUG - 2026-07-04 16:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:21:04 --> Utf8 Class Initialized
INFO - 2026-07-04 16:21:04 --> CSRF cookie sent
INFO - 2026-07-04 16:21:04 --> Input Class Initialized
INFO - 2026-07-04 16:21:04 --> Language Class Initialized
INFO - 2026-07-04 16:21:04 --> URI Class Initialized
INFO - 2026-07-04 16:21:04 --> Output Class Initialized
INFO - 2026-07-04 16:21:04 --> Language Class Initialized
INFO - 2026-07-04 16:21:04 --> Config Class Initialized
INFO - 2026-07-04 16:21:04 --> Security Class Initialized
INFO - 2026-07-04 16:21:04 --> Loader Class Initialized
INFO - 2026-07-04 16:21:04 --> Router Class Initialized
INFO - 2026-07-04 16:21:04 --> Security Class Initialized
INFO - 2026-07-04 16:21:04 --> Helper loaded: url_helper
DEBUG - 2026-07-04 16:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:21:04 --> CSRF cookie sent
INFO - 2026-07-04 16:21:04 --> Input Class Initialized
INFO - 2026-07-04 16:21:04 --> Language Class Initialized
DEBUG - 2026-07-04 16:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:21:04 --> CSRF cookie sent
INFO - 2026-07-04 16:21:04 --> Input Class Initialized
INFO - 2026-07-04 16:21:04 --> Helper loaded: form_helper
INFO - 2026-07-04 16:21:04 --> Language Class Initialized
INFO - 2026-07-04 16:21:04 --> Language Class Initialized
INFO - 2026-07-04 16:21:04 --> Config Class Initialized
INFO - 2026-07-04 16:21:04 --> Language Class Initialized
INFO - 2026-07-04 16:21:04 --> Config Class Initialized
INFO - 2026-07-04 16:21:04 --> Output Class Initialized
INFO - 2026-07-04 16:21:04 --> Helper loaded: html_helper
INFO - 2026-07-04 16:21:04 --> Security Class Initialized
INFO - 2026-07-04 16:21:04 --> Helper loaded: file_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: email_helper
DEBUG - 2026-07-04 16:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:21:04 --> CSRF cookie sent
INFO - 2026-07-04 16:21:04 --> Input Class Initialized
INFO - 2026-07-04 16:21:04 --> Language Class Initialized
INFO - 2026-07-04 16:21:04 --> Loader Class Initialized
INFO - 2026-07-04 16:21:04 --> Language Class Initialized
INFO - 2026-07-04 16:21:04 --> Config Class Initialized
INFO - 2026-07-04 16:21:04 --> Loader Class Initialized
INFO - 2026-07-04 16:21:04 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:21:04 --> Loader Class Initialized
INFO - 2026-07-04 16:21:04 --> Helper loaded: url_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: form_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: url_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: html_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: file_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: form_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: email_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: html_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: url_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: file_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: email_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: form_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: html_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: file_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: email_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:21:04 --> Database Driver Class Initialized
INFO - 2026-07-04 16:21:04 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:21:04 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:21:04 --> Database Driver Class Initialized
INFO - 2026-07-04 16:21:04 --> Database Driver Class Initialized
INFO - 2026-07-04 16:21:04 --> Database Driver Class Initialized
INFO - 2026-07-04 16:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:21:05 --> Upload Class Initialized
DEBUG - 2026-07-04 16:21:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:21:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:21:05 --> Encryption Class Initialized
INFO - 2026-07-04 16:21:05 --> Form Validation Class Initialized
INFO - 2026-07-04 16:21:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:21:05 --> Pagination Class Initialized
INFO - 2026-07-04 16:21:05 --> Email Class Initialized
INFO - 2026-07-04 16:21:05 --> Controller Class Initialized
ERROR - 2026-07-04 16:21:05 --> 404 Page Not Found: /index
INFO - 2026-07-04 16:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:21:05 --> Upload Class Initialized
DEBUG - 2026-07-04 16:21:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:21:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:21:05 --> Encryption Class Initialized
INFO - 2026-07-04 16:21:05 --> Form Validation Class Initialized
INFO - 2026-07-04 16:21:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:21:05 --> Pagination Class Initialized
INFO - 2026-07-04 16:21:05 --> Config Class Initialized
INFO - 2026-07-04 16:21:05 --> Hooks Class Initialized
INFO - 2026-07-04 16:21:05 --> Email Class Initialized
INFO - 2026-07-04 16:21:05 --> Controller Class Initialized
ERROR - 2026-07-04 16:21:05 --> 404 Page Not Found: /index
DEBUG - 2026-07-04 16:21:05 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:21:05 --> Utf8 Class Initialized
INFO - 2026-07-04 16:21:05 --> URI Class Initialized
INFO - 2026-07-04 16:21:05 --> Upload Class Initialized
INFO - 2026-07-04 16:21:05 --> Router Class Initialized
DEBUG - 2026-07-04 16:21:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:21:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:21:05 --> Encryption Class Initialized
INFO - 2026-07-04 16:21:05 --> Output Class Initialized
INFO - 2026-07-04 16:21:05 --> Form Validation Class Initialized
INFO - 2026-07-04 16:21:05 --> Security Class Initialized
DEBUG - 2026-07-04 16:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:21:05 --> CSRF cookie sent
INFO - 2026-07-04 16:21:05 --> Input Class Initialized
INFO - 2026-07-04 16:21:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:21:05 --> Pagination Class Initialized
INFO - 2026-07-04 16:21:05 --> Language Class Initialized
INFO - 2026-07-04 16:21:05 --> Language Class Initialized
INFO - 2026-07-04 16:21:05 --> Config Class Initialized
INFO - 2026-07-04 16:21:05 --> Config Class Initialized
INFO - 2026-07-04 16:21:05 --> Hooks Class Initialized
INFO - 2026-07-04 16:21:05 --> Loader Class Initialized
DEBUG - 2026-07-04 16:21:05 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:21:05 --> Utf8 Class Initialized
INFO - 2026-07-04 16:21:05 --> Email Class Initialized
INFO - 2026-07-04 16:21:05 --> Controller Class Initialized
INFO - 2026-07-04 16:21:05 --> URI Class Initialized
INFO - 2026-07-04 16:21:05 --> Helper loaded: url_helper
ERROR - 2026-07-04 16:21:05 --> 404 Page Not Found: /index
INFO - 2026-07-04 16:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:21:05 --> Helper loaded: form_helper
INFO - 2026-07-04 16:21:05 --> Helper loaded: html_helper
INFO - 2026-07-04 16:21:05 --> Router Class Initialized
INFO - 2026-07-04 16:21:05 --> Helper loaded: file_helper
INFO - 2026-07-04 16:21:05 --> Helper loaded: email_helper
INFO - 2026-07-04 16:21:05 --> Upload Class Initialized
INFO - 2026-07-04 16:21:05 --> Output Class Initialized
INFO - 2026-07-04 16:21:05 --> Security Class Initialized
DEBUG - 2026-07-04 16:21:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:21:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:21:05 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:21:05 --> Encryption Class Initialized
INFO - 2026-07-04 16:21:05 --> Helper loaded: ssp_helper
DEBUG - 2026-07-04 16:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:21:05 --> Input Class Initialized
INFO - 2026-07-04 16:21:05 --> Language Class Initialized
INFO - 2026-07-04 16:21:05 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:21:05 --> Language Class Initialized
INFO - 2026-07-04 16:21:05 --> Config Class Initialized
INFO - 2026-07-04 16:21:05 --> Form Validation Class Initialized
INFO - 2026-07-04 16:21:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:21:05 --> Pagination Class Initialized
INFO - 2026-07-04 16:21:05 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:21:05 --> Loader Class Initialized
INFO - 2026-07-04 16:21:05 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:21:05 --> Helper loaded: url_helper
INFO - 2026-07-04 16:21:05 --> Email Class Initialized
INFO - 2026-07-04 16:21:05 --> Helper loaded: form_helper
INFO - 2026-07-04 16:21:05 --> Controller Class Initialized
INFO - 2026-07-04 16:21:05 --> Helper loaded: html_helper
ERROR - 2026-07-04 16:21:05 --> 404 Page Not Found: /index
INFO - 2026-07-04 16:21:05 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:21:05 --> Helper loaded: file_helper
INFO - 2026-07-04 16:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:21:05 --> Helper loaded: email_helper
INFO - 2026-07-04 16:21:05 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:21:05 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:21:05 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:21:05 --> Upload Class Initialized
INFO - 2026-07-04 16:21:05 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:21:05 --> Config Class Initialized
INFO - 2026-07-04 16:21:05 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:21:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:21:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:21:05 --> Encryption Class Initialized
INFO - 2026-07-04 16:21:05 --> Helper loaded: plesk_helper
DEBUG - 2026-07-04 16:21:05 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:21:05 --> Utf8 Class Initialized
INFO - 2026-07-04 16:21:05 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:21:05 --> URI Class Initialized
INFO - 2026-07-04 16:21:05 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:21:05 --> Database Driver Class Initialized
INFO - 2026-07-04 16:21:05 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:21:05 --> Router Class Initialized
INFO - 2026-07-04 16:21:05 --> Form Validation Class Initialized
INFO - 2026-07-04 16:21:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:21:05 --> Pagination Class Initialized
INFO - 2026-07-04 16:21:05 --> Output Class Initialized
INFO - 2026-07-04 16:21:05 --> Security Class Initialized
DEBUG - 2026-07-04 16:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:21:05 --> CSRF cookie sent
INFO - 2026-07-04 16:21:05 --> Input Class Initialized
INFO - 2026-07-04 16:21:05 --> Language Class Initialized
INFO - 2026-07-04 16:21:05 --> Email Class Initialized
INFO - 2026-07-04 16:21:05 --> Controller Class Initialized
ERROR - 2026-07-04 16:21:05 --> 404 Page Not Found: /index
INFO - 2026-07-04 16:21:05 --> Database Driver Class Initialized
INFO - 2026-07-04 16:21:05 --> Language Class Initialized
INFO - 2026-07-04 16:21:05 --> Config Class Initialized
INFO - 2026-07-04 16:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:21:05 --> Upload Class Initialized
INFO - 2026-07-04 16:21:05 --> Loader Class Initialized
DEBUG - 2026-07-04 16:21:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:21:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:21:05 --> Encryption Class Initialized
INFO - 2026-07-04 16:21:05 --> Helper loaded: url_helper
INFO - 2026-07-04 16:21:05 --> Helper loaded: form_helper
INFO - 2026-07-04 16:21:05 --> Form Validation Class Initialized
INFO - 2026-07-04 16:21:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:21:05 --> Helper loaded: html_helper
INFO - 2026-07-04 16:21:05 --> Pagination Class Initialized
INFO - 2026-07-04 16:21:05 --> Helper loaded: file_helper
INFO - 2026-07-04 16:21:05 --> Helper loaded: email_helper
INFO - 2026-07-04 16:21:05 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:21:05 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:21:05 --> Email Class Initialized
INFO - 2026-07-04 16:21:05 --> Controller Class Initialized
ERROR - 2026-07-04 16:21:05 --> 404 Page Not Found: /index
INFO - 2026-07-04 16:21:05 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:21:05 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:21:05 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:21:05 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:21:05 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:21:05 --> Database Driver Class Initialized
INFO - 2026-07-04 16:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:21:07 --> Upload Class Initialized
DEBUG - 2026-07-04 16:21:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:21:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:21:07 --> Encryption Class Initialized
INFO - 2026-07-04 16:21:07 --> Form Validation Class Initialized
INFO - 2026-07-04 16:21:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:21:07 --> Pagination Class Initialized
INFO - 2026-07-04 16:21:07 --> Email Class Initialized
INFO - 2026-07-04 16:21:07 --> Controller Class Initialized
DEBUG - 2026-07-04 16:21:07 --> Clientarea MX_Controller Initialized
INFO - 2026-07-04 16:21:07 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 16:21:07 --> Model "Auth_model" initialized
INFO - 2026-07-04 16:21:07 --> Model "Cart_model" initialized
INFO - 2026-07-04 16:21:07 --> Model "Clientarea_model" initialized
INFO - 2026-07-04 16:21:07 --> Model "Billing_model" initialized
INFO - 2026-07-04 16:21:07 --> Model "Common_model" initialized
INFO - 2026-07-04 16:21:07 --> Model "Order_model" initialized
INFO - 2026-07-04 16:21:07 --> Model "Support_model" initialized
DEBUG - 2026-07-04 16:21:08 --> API Request URL: https://api.sandbox.namecheap.com/xml.response?ApiUser=tongbaritest&ApiKey=993d950d882041ed90eea8158abec1d3&UserName=tongbaritest&Command=namecheap.domains.getRegistrarLock&ClientIp=67.222.24.126&DomainName=testing-ecomz.xyz
INFO - 2026-07-04 16:21:10 --> Final output sent to browser
DEBUG - 2026-07-04 16:21:10 --> Total execution time: 4.2870
INFO - 2026-07-04 16:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:21:10 --> Upload Class Initialized
DEBUG - 2026-07-04 16:21:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:21:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:21:10 --> Encryption Class Initialized
INFO - 2026-07-04 16:21:10 --> Form Validation Class Initialized
INFO - 2026-07-04 16:21:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:21:10 --> Pagination Class Initialized
INFO - 2026-07-04 16:21:10 --> Email Class Initialized
INFO - 2026-07-04 16:21:10 --> Controller Class Initialized
ERROR - 2026-07-04 16:21:10 --> 404 Page Not Found: /index
INFO - 2026-07-04 16:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:21:10 --> Upload Class Initialized
DEBUG - 2026-07-04 16:21:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:21:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:21:10 --> Encryption Class Initialized
INFO - 2026-07-04 16:21:10 --> Form Validation Class Initialized
INFO - 2026-07-04 16:21:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:21:10 --> Pagination Class Initialized
INFO - 2026-07-04 16:21:10 --> Email Class Initialized
INFO - 2026-07-04 16:21:10 --> Controller Class Initialized
DEBUG - 2026-07-04 16:21:10 --> Cart MX_Controller Initialized
INFO - 2026-07-04 16:21:10 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 16:21:10 --> Model "Auth_model" initialized
INFO - 2026-07-04 16:21:10 --> Model "Cart_model" initialized
INFO - 2026-07-04 16:21:10 --> Model "Common_model" initialized
INFO - 2026-07-04 16:21:10 --> Model "Order_model" initialized
INFO - 2026-07-04 16:21:10 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 16:21:10 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-04 16:21:10 --> Model "Promocode_model" initialized
DEBUG - 2026-07-04 16:21:10 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-04 16:21:10 --> Model "Plan_model" initialized
INFO - 2026-07-04 16:21:10 --> Model "Orderlicense_model" initialized
INFO - 2026-07-04 16:21:10 --> Final output sent to browser
DEBUG - 2026-07-04 16:21:10 --> Total execution time: 4.7035
INFO - 2026-07-04 16:24:41 --> Config Class Initialized
INFO - 2026-07-04 16:24:41 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:24:41 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:24:41 --> Utf8 Class Initialized
INFO - 2026-07-04 16:24:41 --> URI Class Initialized
INFO - 2026-07-04 16:24:41 --> Router Class Initialized
INFO - 2026-07-04 16:24:41 --> Output Class Initialized
INFO - 2026-07-04 16:24:41 --> Security Class Initialized
DEBUG - 2026-07-04 16:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:24:41 --> CSRF cookie sent
INFO - 2026-07-04 16:24:41 --> Input Class Initialized
INFO - 2026-07-04 16:24:41 --> Language Class Initialized
INFO - 2026-07-04 16:24:41 --> Language Class Initialized
INFO - 2026-07-04 16:24:41 --> Config Class Initialized
INFO - 2026-07-04 16:24:41 --> Loader Class Initialized
INFO - 2026-07-04 16:24:41 --> Helper loaded: url_helper
INFO - 2026-07-04 16:24:41 --> Helper loaded: form_helper
INFO - 2026-07-04 16:24:41 --> Helper loaded: html_helper
INFO - 2026-07-04 16:24:41 --> Helper loaded: file_helper
INFO - 2026-07-04 16:24:41 --> Helper loaded: email_helper
INFO - 2026-07-04 16:24:41 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:24:41 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:24:41 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:24:41 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:24:41 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:24:41 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:24:41 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:24:41 --> Database Driver Class Initialized
INFO - 2026-07-04 16:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:24:43 --> Upload Class Initialized
DEBUG - 2026-07-04 16:24:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:24:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:24:43 --> Encryption Class Initialized
INFO - 2026-07-04 16:24:43 --> Form Validation Class Initialized
INFO - 2026-07-04 16:24:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:24:43 --> Pagination Class Initialized
INFO - 2026-07-04 16:24:43 --> Email Class Initialized
INFO - 2026-07-04 16:24:43 --> Controller Class Initialized
DEBUG - 2026-07-04 16:24:43 --> Clientarea MX_Controller Initialized
INFO - 2026-07-04 16:24:43 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 16:24:43 --> Model "Auth_model" initialized
INFO - 2026-07-04 16:24:43 --> Model "Cart_model" initialized
INFO - 2026-07-04 16:24:43 --> Model "Clientarea_model" initialized
INFO - 2026-07-04 16:24:43 --> Model "Billing_model" initialized
INFO - 2026-07-04 16:24:43 --> Model "Common_model" initialized
INFO - 2026-07-04 16:24:43 --> Model "Order_model" initialized
INFO - 2026-07-04 16:24:43 --> Model "Support_model" initialized
DEBUG - 2026-07-04 16:24:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-04 16:24:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/domain_nav.php
DEBUG - 2026-07-04 16:24:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-04 16:24:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-04 16:24:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_domain_detail.php
INFO - 2026-07-04 16:24:45 --> Final output sent to browser
DEBUG - 2026-07-04 16:24:45 --> Total execution time: 3.2375
INFO - 2026-07-04 16:24:45 --> Config Class Initialized
INFO - 2026-07-04 16:24:45 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:24:45 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:24:45 --> Utf8 Class Initialized
INFO - 2026-07-04 16:24:45 --> URI Class Initialized
INFO - 2026-07-04 16:24:45 --> Router Class Initialized
INFO - 2026-07-04 16:24:45 --> Output Class Initialized
INFO - 2026-07-04 16:24:45 --> Security Class Initialized
DEBUG - 2026-07-04 16:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:24:45 --> CSRF cookie sent
INFO - 2026-07-04 16:24:45 --> Input Class Initialized
INFO - 2026-07-04 16:24:45 --> Language Class Initialized
INFO - 2026-07-04 16:24:45 --> Language Class Initialized
INFO - 2026-07-04 16:24:45 --> Config Class Initialized
INFO - 2026-07-04 16:24:45 --> Loader Class Initialized
INFO - 2026-07-04 16:24:45 --> Helper loaded: url_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: form_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: html_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: file_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: email_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:24:45 --> Database Driver Class Initialized
INFO - 2026-07-04 16:24:45 --> Config Class Initialized
INFO - 2026-07-04 16:24:45 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:24:45 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:24:45 --> Utf8 Class Initialized
INFO - 2026-07-04 16:24:45 --> URI Class Initialized
INFO - 2026-07-04 16:24:45 --> Router Class Initialized
INFO - 2026-07-04 16:24:45 --> Output Class Initialized
INFO - 2026-07-04 16:24:45 --> Security Class Initialized
DEBUG - 2026-07-04 16:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:24:45 --> CSRF cookie sent
INFO - 2026-07-04 16:24:45 --> Input Class Initialized
INFO - 2026-07-04 16:24:45 --> Language Class Initialized
INFO - 2026-07-04 16:24:45 --> Language Class Initialized
INFO - 2026-07-04 16:24:45 --> Config Class Initialized
INFO - 2026-07-04 16:24:45 --> Loader Class Initialized
INFO - 2026-07-04 16:24:45 --> Helper loaded: url_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: form_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: html_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: file_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: email_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:24:45 --> Database Driver Class Initialized
INFO - 2026-07-04 16:24:45 --> Config Class Initialized
INFO - 2026-07-04 16:24:45 --> Hooks Class Initialized
INFO - 2026-07-04 16:24:45 --> Config Class Initialized
INFO - 2026-07-04 16:24:45 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:24:45 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:24:45 --> Utf8 Class Initialized
INFO - 2026-07-04 16:24:45 --> URI Class Initialized
INFO - 2026-07-04 16:24:45 --> Config Class Initialized
INFO - 2026-07-04 16:24:45 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:24:45 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:24:45 --> Utf8 Class Initialized
INFO - 2026-07-04 16:24:45 --> URI Class Initialized
INFO - 2026-07-04 16:24:45 --> Router Class Initialized
DEBUG - 2026-07-04 16:24:45 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:24:45 --> Utf8 Class Initialized
INFO - 2026-07-04 16:24:45 --> Output Class Initialized
INFO - 2026-07-04 16:24:45 --> URI Class Initialized
INFO - 2026-07-04 16:24:45 --> Security Class Initialized
INFO - 2026-07-04 16:24:45 --> Config Class Initialized
INFO - 2026-07-04 16:24:45 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:24:45 --> CSRF cookie sent
INFO - 2026-07-04 16:24:45 --> Input Class Initialized
INFO - 2026-07-04 16:24:45 --> Language Class Initialized
INFO - 2026-07-04 16:24:45 --> Router Class Initialized
DEBUG - 2026-07-04 16:24:45 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:24:45 --> Utf8 Class Initialized
INFO - 2026-07-04 16:24:45 --> Router Class Initialized
INFO - 2026-07-04 16:24:45 --> Language Class Initialized
INFO - 2026-07-04 16:24:45 --> Config Class Initialized
INFO - 2026-07-04 16:24:45 --> URI Class Initialized
INFO - 2026-07-04 16:24:45 --> Output Class Initialized
INFO - 2026-07-04 16:24:45 --> Output Class Initialized
INFO - 2026-07-04 16:24:45 --> Router Class Initialized
INFO - 2026-07-04 16:24:45 --> Loader Class Initialized
INFO - 2026-07-04 16:24:45 --> Security Class Initialized
INFO - 2026-07-04 16:24:45 --> Security Class Initialized
INFO - 2026-07-04 16:24:45 --> Helper loaded: url_helper
INFO - 2026-07-04 16:24:45 --> Output Class Initialized
DEBUG - 2026-07-04 16:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-07-04 16:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:24:45 --> CSRF cookie sent
INFO - 2026-07-04 16:24:45 --> Input Class Initialized
INFO - 2026-07-04 16:24:45 --> Language Class Initialized
INFO - 2026-07-04 16:24:45 --> Helper loaded: form_helper
INFO - 2026-07-04 16:24:45 --> Security Class Initialized
INFO - 2026-07-04 16:24:45 --> Helper loaded: html_helper
INFO - 2026-07-04 16:24:45 --> Language Class Initialized
INFO - 2026-07-04 16:24:45 --> Config Class Initialized
INFO - 2026-07-04 16:24:45 --> Helper loaded: file_helper
DEBUG - 2026-07-04 16:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:24:45 --> CSRF cookie sent
INFO - 2026-07-04 16:24:45 --> Input Class Initialized
INFO - 2026-07-04 16:24:45 --> Helper loaded: email_helper
INFO - 2026-07-04 16:24:45 --> Language Class Initialized
INFO - 2026-07-04 16:24:45 --> Language Class Initialized
INFO - 2026-07-04 16:24:45 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:24:45 --> Config Class Initialized
INFO - 2026-07-04 16:24:45 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:24:45 --> Loader Class Initialized
INFO - 2026-07-04 16:24:45 --> Helper loaded: url_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: form_helper
INFO - 2026-07-04 16:24:45 --> Loader Class Initialized
INFO - 2026-07-04 16:24:45 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: html_helper
INFO - 2026-07-04 16:24:45 --> CSRF cookie sent
INFO - 2026-07-04 16:24:45 --> Input Class Initialized
INFO - 2026-07-04 16:24:45 --> Helper loaded: url_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:24:45 --> Language Class Initialized
INFO - 2026-07-04 16:24:45 --> Helper loaded: form_helper
INFO - 2026-07-04 16:24:45 --> Language Class Initialized
INFO - 2026-07-04 16:24:45 --> Config Class Initialized
INFO - 2026-07-04 16:24:45 --> Helper loaded: html_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: file_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: email_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: file_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: email_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:24:45 --> Loader Class Initialized
INFO - 2026-07-04 16:24:45 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:24:45 --> Database Driver Class Initialized
INFO - 2026-07-04 16:24:45 --> Helper loaded: url_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: form_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: html_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: file_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: email_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:24:45 --> Database Driver Class Initialized
INFO - 2026-07-04 16:24:45 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:24:45 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:24:45 --> Database Driver Class Initialized
INFO - 2026-07-04 16:24:45 --> Database Driver Class Initialized
INFO - 2026-07-04 16:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:24:47 --> Upload Class Initialized
DEBUG - 2026-07-04 16:24:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:24:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:24:47 --> Encryption Class Initialized
INFO - 2026-07-04 16:24:47 --> Form Validation Class Initialized
INFO - 2026-07-04 16:24:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:24:47 --> Pagination Class Initialized
INFO - 2026-07-04 16:24:47 --> Email Class Initialized
INFO - 2026-07-04 16:24:47 --> Controller Class Initialized
ERROR - 2026-07-04 16:24:47 --> 404 Page Not Found: /index
INFO - 2026-07-04 16:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:24:47 --> Upload Class Initialized
DEBUG - 2026-07-04 16:24:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:24:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:24:47 --> Encryption Class Initialized
INFO - 2026-07-04 16:24:47 --> Form Validation Class Initialized
INFO - 2026-07-04 16:24:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:24:47 --> Pagination Class Initialized
INFO - 2026-07-04 16:24:47 --> Email Class Initialized
INFO - 2026-07-04 16:24:47 --> Controller Class Initialized
ERROR - 2026-07-04 16:24:47 --> 404 Page Not Found: /index
INFO - 2026-07-04 16:24:47 --> Config Class Initialized
INFO - 2026-07-04 16:24:47 --> Hooks Class Initialized
INFO - 2026-07-04 16:24:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-07-04 16:24:47 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:24:47 --> Utf8 Class Initialized
INFO - 2026-07-04 16:24:47 --> Upload Class Initialized
INFO - 2026-07-04 16:24:47 --> URI Class Initialized
DEBUG - 2026-07-04 16:24:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:24:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:24:47 --> Encryption Class Initialized
INFO - 2026-07-04 16:24:47 --> Router Class Initialized
INFO - 2026-07-04 16:24:47 --> Form Validation Class Initialized
INFO - 2026-07-04 16:24:47 --> Output Class Initialized
INFO - 2026-07-04 16:24:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:24:47 --> Pagination Class Initialized
INFO - 2026-07-04 16:24:47 --> Security Class Initialized
DEBUG - 2026-07-04 16:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:24:47 --> CSRF cookie sent
INFO - 2026-07-04 16:24:47 --> Input Class Initialized
INFO - 2026-07-04 16:24:47 --> Language Class Initialized
INFO - 2026-07-04 16:24:47 --> Email Class Initialized
INFO - 2026-07-04 16:24:47 --> Controller Class Initialized
INFO - 2026-07-04 16:24:47 --> Config Class Initialized
INFO - 2026-07-04 16:24:47 --> Hooks Class Initialized
ERROR - 2026-07-04 16:24:47 --> 404 Page Not Found: /index
INFO - 2026-07-04 16:24:47 --> Language Class Initialized
INFO - 2026-07-04 16:24:47 --> Config Class Initialized
INFO - 2026-07-04 16:24:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-07-04 16:24:47 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:24:47 --> Utf8 Class Initialized
INFO - 2026-07-04 16:24:47 --> URI Class Initialized
INFO - 2026-07-04 16:24:47 --> Upload Class Initialized
INFO - 2026-07-04 16:24:47 --> Loader Class Initialized
INFO - 2026-07-04 16:24:47 --> Helper loaded: url_helper
DEBUG - 2026-07-04 16:24:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:24:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:24:47 --> Encryption Class Initialized
INFO - 2026-07-04 16:24:47 --> Router Class Initialized
INFO - 2026-07-04 16:24:47 --> Helper loaded: form_helper
INFO - 2026-07-04 16:24:47 --> Helper loaded: html_helper
INFO - 2026-07-04 16:24:47 --> Helper loaded: file_helper
INFO - 2026-07-04 16:24:47 --> Helper loaded: email_helper
INFO - 2026-07-04 16:24:47 --> Form Validation Class Initialized
INFO - 2026-07-04 16:24:47 --> Output Class Initialized
INFO - 2026-07-04 16:24:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:24:47 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:24:47 --> Pagination Class Initialized
INFO - 2026-07-04 16:24:47 --> Security Class Initialized
INFO - 2026-07-04 16:24:47 --> Helper loaded: ssp_helper
DEBUG - 2026-07-04 16:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:24:47 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:24:47 --> Input Class Initialized
INFO - 2026-07-04 16:24:47 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:24:47 --> Language Class Initialized
INFO - 2026-07-04 16:24:47 --> Email Class Initialized
INFO - 2026-07-04 16:24:47 --> Controller Class Initialized
ERROR - 2026-07-04 16:24:47 --> 404 Page Not Found: /index
INFO - 2026-07-04 16:24:47 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:24:47 --> Language Class Initialized
INFO - 2026-07-04 16:24:47 --> Config Class Initialized
INFO - 2026-07-04 16:24:47 --> Config Class Initialized
INFO - 2026-07-04 16:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:24:47 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:24:47 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:24:47 --> Utf8 Class Initialized
INFO - 2026-07-04 16:24:47 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:24:47 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:24:47 --> Loader Class Initialized
INFO - 2026-07-04 16:24:47 --> URI Class Initialized
INFO - 2026-07-04 16:24:47 --> Helper loaded: url_helper
INFO - 2026-07-04 16:24:47 --> Router Class Initialized
INFO - 2026-07-04 16:24:47 --> Helper loaded: form_helper
INFO - 2026-07-04 16:24:47 --> Upload Class Initialized
INFO - 2026-07-04 16:24:47 --> Helper loaded: html_helper
INFO - 2026-07-04 16:24:47 --> Helper loaded: file_helper
INFO - 2026-07-04 16:24:47 --> Output Class Initialized
INFO - 2026-07-04 16:24:47 --> Helper loaded: email_helper
DEBUG - 2026-07-04 16:24:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:24:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:24:47 --> Encryption Class Initialized
INFO - 2026-07-04 16:24:47 --> Security Class Initialized
INFO - 2026-07-04 16:24:47 --> Database Driver Class Initialized
INFO - 2026-07-04 16:24:47 --> Helper loaded: whmaz_helper
DEBUG - 2026-07-04 16:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:24:47 --> CSRF cookie sent
INFO - 2026-07-04 16:24:47 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:24:47 --> Input Class Initialized
INFO - 2026-07-04 16:24:47 --> Language Class Initialized
INFO - 2026-07-04 16:24:47 --> Form Validation Class Initialized
INFO - 2026-07-04 16:24:47 --> Language Class Initialized
INFO - 2026-07-04 16:24:47 --> Config Class Initialized
INFO - 2026-07-04 16:24:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:24:47 --> Pagination Class Initialized
INFO - 2026-07-04 16:24:47 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:24:47 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:24:47 --> Loader Class Initialized
INFO - 2026-07-04 16:24:47 --> Helper loaded: url_helper
INFO - 2026-07-04 16:24:47 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:24:47 --> Email Class Initialized
INFO - 2026-07-04 16:24:47 --> Helper loaded: form_helper
INFO - 2026-07-04 16:24:47 --> Controller Class Initialized
INFO - 2026-07-04 16:24:47 --> Helper loaded: html_helper
ERROR - 2026-07-04 16:24:47 --> 404 Page Not Found: /index
INFO - 2026-07-04 16:24:47 --> Helper loaded: file_helper
INFO - 2026-07-04 16:24:47 --> Helper loaded: email_helper
INFO - 2026-07-04 16:24:47 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:24:47 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:24:47 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:24:47 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:24:47 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:24:47 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:24:47 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:24:47 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:24:47 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:24:47 --> Database Driver Class Initialized
INFO - 2026-07-04 16:24:47 --> Database Driver Class Initialized
INFO - 2026-07-04 16:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:24:47 --> Upload Class Initialized
DEBUG - 2026-07-04 16:24:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:24:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:24:47 --> Encryption Class Initialized
INFO - 2026-07-04 16:24:47 --> Form Validation Class Initialized
INFO - 2026-07-04 16:24:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:24:47 --> Pagination Class Initialized
INFO - 2026-07-04 16:24:47 --> Email Class Initialized
INFO - 2026-07-04 16:24:47 --> Controller Class Initialized
ERROR - 2026-07-04 16:24:47 --> 404 Page Not Found: /index
INFO - 2026-07-04 16:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:24:49 --> Upload Class Initialized
DEBUG - 2026-07-04 16:24:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:24:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:24:49 --> Encryption Class Initialized
INFO - 2026-07-04 16:24:49 --> Form Validation Class Initialized
INFO - 2026-07-04 16:24:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:24:49 --> Pagination Class Initialized
INFO - 2026-07-04 16:24:49 --> Email Class Initialized
INFO - 2026-07-04 16:24:49 --> Controller Class Initialized
DEBUG - 2026-07-04 16:24:49 --> Clientarea MX_Controller Initialized
INFO - 2026-07-04 16:24:49 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 16:24:49 --> Model "Auth_model" initialized
INFO - 2026-07-04 16:24:49 --> Model "Cart_model" initialized
INFO - 2026-07-04 16:24:49 --> Model "Clientarea_model" initialized
INFO - 2026-07-04 16:24:49 --> Model "Billing_model" initialized
INFO - 2026-07-04 16:24:49 --> Model "Common_model" initialized
INFO - 2026-07-04 16:24:49 --> Model "Order_model" initialized
INFO - 2026-07-04 16:24:49 --> Model "Support_model" initialized
DEBUG - 2026-07-04 16:24:49 --> API Request URL: https://api.sandbox.namecheap.com/xml.response?ApiUser=tongbaritest&ApiKey=993d950d882041ed90eea8158abec1d3&UserName=tongbaritest&Command=namecheap.domains.getRegistrarLock&ClientIp=67.222.24.126&DomainName=testing-ecomz.xyz
INFO - 2026-07-04 16:24:51 --> Final output sent to browser
DEBUG - 2026-07-04 16:24:51 --> Total execution time: 4.2088
INFO - 2026-07-04 16:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:24:51 --> Upload Class Initialized
DEBUG - 2026-07-04 16:24:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:24:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:24:51 --> Encryption Class Initialized
INFO - 2026-07-04 16:24:51 --> Form Validation Class Initialized
INFO - 2026-07-04 16:24:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:24:51 --> Pagination Class Initialized
INFO - 2026-07-04 16:24:51 --> Email Class Initialized
INFO - 2026-07-04 16:24:51 --> Controller Class Initialized
DEBUG - 2026-07-04 16:24:51 --> Cart MX_Controller Initialized
INFO - 2026-07-04 16:24:51 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 16:24:51 --> Model "Auth_model" initialized
INFO - 2026-07-04 16:24:51 --> Model "Cart_model" initialized
INFO - 2026-07-04 16:24:51 --> Model "Common_model" initialized
INFO - 2026-07-04 16:24:51 --> Model "Order_model" initialized
INFO - 2026-07-04 16:24:51 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 16:24:51 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-04 16:24:51 --> Model "Promocode_model" initialized
DEBUG - 2026-07-04 16:24:51 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-04 16:24:51 --> Model "Plan_model" initialized
INFO - 2026-07-04 16:24:51 --> Model "Orderlicense_model" initialized
INFO - 2026-07-04 16:24:51 --> Final output sent to browser
DEBUG - 2026-07-04 16:24:51 --> Total execution time: 4.5971
INFO - 2026-07-04 16:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:24:51 --> Upload Class Initialized
DEBUG - 2026-07-04 16:24:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:24:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:24:51 --> Encryption Class Initialized
INFO - 2026-07-04 16:24:51 --> Form Validation Class Initialized
INFO - 2026-07-04 16:24:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:24:51 --> Pagination Class Initialized
INFO - 2026-07-04 16:24:51 --> Email Class Initialized
INFO - 2026-07-04 16:24:51 --> Controller Class Initialized
ERROR - 2026-07-04 16:24:51 --> 404 Page Not Found: /index
INFO - 2026-07-04 16:25:09 --> Config Class Initialized
INFO - 2026-07-04 16:25:09 --> Hooks Class Initialized
DEBUG - 2026-07-04 16:25:09 --> UTF-8 Support Enabled
INFO - 2026-07-04 16:25:09 --> Utf8 Class Initialized
INFO - 2026-07-04 16:25:09 --> URI Class Initialized
INFO - 2026-07-04 16:25:09 --> Router Class Initialized
INFO - 2026-07-04 16:25:09 --> Output Class Initialized
INFO - 2026-07-04 16:25:09 --> Security Class Initialized
DEBUG - 2026-07-04 16:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 16:25:09 --> CSRF cookie sent
INFO - 2026-07-04 16:25:09 --> CSRF token verified
INFO - 2026-07-04 16:25:09 --> Input Class Initialized
INFO - 2026-07-04 16:25:09 --> Language Class Initialized
INFO - 2026-07-04 16:25:09 --> Language Class Initialized
INFO - 2026-07-04 16:25:09 --> Config Class Initialized
INFO - 2026-07-04 16:25:09 --> Loader Class Initialized
INFO - 2026-07-04 16:25:09 --> Helper loaded: url_helper
INFO - 2026-07-04 16:25:09 --> Helper loaded: form_helper
INFO - 2026-07-04 16:25:09 --> Helper loaded: html_helper
INFO - 2026-07-04 16:25:09 --> Helper loaded: file_helper
INFO - 2026-07-04 16:25:09 --> Helper loaded: email_helper
INFO - 2026-07-04 16:25:09 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 16:25:09 --> Helper loaded: ssp_helper
INFO - 2026-07-04 16:25:09 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 16:25:09 --> Helper loaded: plesk_helper
INFO - 2026-07-04 16:25:09 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 16:25:09 --> Helper loaded: domain_helper
INFO - 2026-07-04 16:25:09 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 16:25:09 --> Database Driver Class Initialized
INFO - 2026-07-04 16:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 16:25:10 --> Upload Class Initialized
DEBUG - 2026-07-04 16:25:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 16:25:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 16:25:10 --> Encryption Class Initialized
INFO - 2026-07-04 16:25:10 --> Form Validation Class Initialized
INFO - 2026-07-04 16:25:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 16:25:10 --> Pagination Class Initialized
INFO - 2026-07-04 16:25:10 --> Email Class Initialized
INFO - 2026-07-04 16:25:10 --> Controller Class Initialized
DEBUG - 2026-07-04 16:25:10 --> Clientarea MX_Controller Initialized
INFO - 2026-07-04 16:25:10 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 16:25:10 --> Model "Auth_model" initialized
INFO - 2026-07-04 16:25:10 --> Model "Cart_model" initialized
INFO - 2026-07-04 16:25:10 --> Model "Clientarea_model" initialized
INFO - 2026-07-04 16:25:10 --> Model "Billing_model" initialized
INFO - 2026-07-04 16:25:10 --> Model "Common_model" initialized
INFO - 2026-07-04 16:25:10 --> Model "Order_model" initialized
INFO - 2026-07-04 16:25:10 --> Model "Support_model" initialized
INFO - 2026-07-04 16:25:26 --> Final output sent to browser
DEBUG - 2026-07-04 16:25:26 --> Total execution time: 17.3371
INFO - 2026-07-04 19:28:56 --> Config Class Initialized
INFO - 2026-07-04 19:28:56 --> Hooks Class Initialized
DEBUG - 2026-07-04 19:28:56 --> UTF-8 Support Enabled
INFO - 2026-07-04 19:28:56 --> Utf8 Class Initialized
INFO - 2026-07-04 19:28:56 --> URI Class Initialized
INFO - 2026-07-04 19:28:56 --> Router Class Initialized
INFO - 2026-07-04 19:28:56 --> Output Class Initialized
INFO - 2026-07-04 19:28:56 --> Security Class Initialized
DEBUG - 2026-07-04 19:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 19:28:56 --> CSRF cookie sent
INFO - 2026-07-04 19:28:56 --> Input Class Initialized
INFO - 2026-07-04 19:28:56 --> Language Class Initialized
INFO - 2026-07-04 19:28:56 --> Language Class Initialized
INFO - 2026-07-04 19:28:56 --> Config Class Initialized
INFO - 2026-07-04 19:28:56 --> Loader Class Initialized
INFO - 2026-07-04 19:28:56 --> Helper loaded: url_helper
INFO - 2026-07-04 19:28:56 --> Helper loaded: form_helper
INFO - 2026-07-04 19:28:56 --> Helper loaded: html_helper
INFO - 2026-07-04 19:28:56 --> Helper loaded: file_helper
INFO - 2026-07-04 19:28:56 --> Helper loaded: email_helper
INFO - 2026-07-04 19:28:56 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 19:28:56 --> Helper loaded: ssp_helper
INFO - 2026-07-04 19:28:56 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 19:28:56 --> Helper loaded: plesk_helper
INFO - 2026-07-04 19:28:56 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 19:28:56 --> Helper loaded: domain_helper
INFO - 2026-07-04 19:28:56 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 19:28:56 --> Database Driver Class Initialized
INFO - 2026-07-04 19:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 19:28:58 --> Upload Class Initialized
DEBUG - 2026-07-04 19:28:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 19:28:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 19:28:58 --> Encryption Class Initialized
INFO - 2026-07-04 19:28:58 --> Form Validation Class Initialized
INFO - 2026-07-04 19:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 19:28:58 --> Pagination Class Initialized
INFO - 2026-07-04 19:28:58 --> Email Class Initialized
INFO - 2026-07-04 19:28:58 --> Controller Class Initialized
DEBUG - 2026-07-04 19:28:58 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 19:28:58 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 19:28:58 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 19:28:58 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-04 19:28:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-04 19:28:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-04 19:28:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-07-04 19:28:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-04 19:28:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-04 19:28:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-07-04 19:28:59 --> Final output sent to browser
DEBUG - 2026-07-04 19:28:59 --> Total execution time: 2.1178
INFO - 2026-07-04 19:29:05 --> Config Class Initialized
INFO - 2026-07-04 19:29:05 --> Hooks Class Initialized
DEBUG - 2026-07-04 19:29:05 --> UTF-8 Support Enabled
INFO - 2026-07-04 19:29:05 --> Utf8 Class Initialized
INFO - 2026-07-04 19:29:05 --> URI Class Initialized
INFO - 2026-07-04 19:29:05 --> Router Class Initialized
INFO - 2026-07-04 19:29:05 --> Output Class Initialized
INFO - 2026-07-04 19:29:05 --> Security Class Initialized
DEBUG - 2026-07-04 19:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 19:29:05 --> CSRF cookie sent
INFO - 2026-07-04 19:29:05 --> CSRF token verified
INFO - 2026-07-04 19:29:05 --> Input Class Initialized
INFO - 2026-07-04 19:29:05 --> Language Class Initialized
INFO - 2026-07-04 19:29:05 --> Language Class Initialized
INFO - 2026-07-04 19:29:05 --> Config Class Initialized
INFO - 2026-07-04 19:29:05 --> Loader Class Initialized
INFO - 2026-07-04 19:29:05 --> Helper loaded: url_helper
INFO - 2026-07-04 19:29:05 --> Helper loaded: form_helper
INFO - 2026-07-04 19:29:05 --> Helper loaded: html_helper
INFO - 2026-07-04 19:29:05 --> Helper loaded: file_helper
INFO - 2026-07-04 19:29:05 --> Helper loaded: email_helper
INFO - 2026-07-04 19:29:05 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 19:29:05 --> Helper loaded: ssp_helper
INFO - 2026-07-04 19:29:05 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 19:29:05 --> Helper loaded: plesk_helper
INFO - 2026-07-04 19:29:05 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 19:29:05 --> Helper loaded: domain_helper
INFO - 2026-07-04 19:29:05 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 19:29:05 --> Database Driver Class Initialized
INFO - 2026-07-04 19:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 19:29:08 --> Upload Class Initialized
DEBUG - 2026-07-04 19:29:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 19:29:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 19:29:08 --> Encryption Class Initialized
INFO - 2026-07-04 19:29:08 --> Form Validation Class Initialized
INFO - 2026-07-04 19:29:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 19:29:08 --> Pagination Class Initialized
INFO - 2026-07-04 19:29:08 --> Email Class Initialized
INFO - 2026-07-04 19:29:08 --> Controller Class Initialized
DEBUG - 2026-07-04 19:29:08 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 19:29:08 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 19:29:08 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 19:29:08 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 19:29:15 --> Config Class Initialized
INFO - 2026-07-04 19:29:15 --> Hooks Class Initialized
DEBUG - 2026-07-04 19:29:15 --> UTF-8 Support Enabled
INFO - 2026-07-04 19:29:15 --> Utf8 Class Initialized
INFO - 2026-07-04 19:29:15 --> URI Class Initialized
INFO - 2026-07-04 19:29:15 --> Router Class Initialized
INFO - 2026-07-04 19:29:15 --> Output Class Initialized
INFO - 2026-07-04 19:29:15 --> Security Class Initialized
DEBUG - 2026-07-04 19:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 19:29:15 --> CSRF cookie sent
INFO - 2026-07-04 19:29:15 --> Input Class Initialized
INFO - 2026-07-04 19:29:15 --> Language Class Initialized
INFO - 2026-07-04 19:29:15 --> Language Class Initialized
INFO - 2026-07-04 19:29:15 --> Config Class Initialized
INFO - 2026-07-04 19:29:15 --> Loader Class Initialized
INFO - 2026-07-04 19:29:15 --> Helper loaded: url_helper
INFO - 2026-07-04 19:29:15 --> Helper loaded: form_helper
INFO - 2026-07-04 19:29:15 --> Helper loaded: html_helper
INFO - 2026-07-04 19:29:15 --> Helper loaded: file_helper
INFO - 2026-07-04 19:29:15 --> Helper loaded: email_helper
INFO - 2026-07-04 19:29:15 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 19:29:15 --> Helper loaded: ssp_helper
INFO - 2026-07-04 19:29:15 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 19:29:15 --> Helper loaded: plesk_helper
INFO - 2026-07-04 19:29:15 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 19:29:15 --> Helper loaded: domain_helper
INFO - 2026-07-04 19:29:16 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 19:29:16 --> Database Driver Class Initialized
INFO - 2026-07-04 19:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 19:29:18 --> Upload Class Initialized
DEBUG - 2026-07-04 19:29:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 19:29:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 19:29:18 --> Encryption Class Initialized
INFO - 2026-07-04 19:29:18 --> Form Validation Class Initialized
INFO - 2026-07-04 19:29:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 19:29:18 --> Pagination Class Initialized
INFO - 2026-07-04 19:29:18 --> Email Class Initialized
INFO - 2026-07-04 19:29:18 --> Controller Class Initialized
DEBUG - 2026-07-04 19:29:18 --> Dashboard MX_Controller Initialized
INFO - 2026-07-04 19:29:18 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 19:29:18 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 19:29:18 --> Model "Dashboard_model" initialized
DEBUG - 2026-07-04 19:29:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-04 19:29:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-04 19:29:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-04 19:29:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-04 19:29:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-04 19:29:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/dashboard_index.php
INFO - 2026-07-04 19:29:18 --> Final output sent to browser
DEBUG - 2026-07-04 19:29:18 --> Total execution time: 3.0255
INFO - 2026-07-04 19:29:19 --> Config Class Initialized
INFO - 2026-07-04 19:29:19 --> Hooks Class Initialized
DEBUG - 2026-07-04 19:29:19 --> UTF-8 Support Enabled
INFO - 2026-07-04 19:29:19 --> Utf8 Class Initialized
INFO - 2026-07-04 19:29:19 --> URI Class Initialized
INFO - 2026-07-04 19:29:19 --> Config Class Initialized
INFO - 2026-07-04 19:29:19 --> Hooks Class Initialized
INFO - 2026-07-04 19:29:19 --> Router Class Initialized
INFO - 2026-07-04 19:29:19 --> Config Class Initialized
INFO - 2026-07-04 19:29:19 --> Hooks Class Initialized
INFO - 2026-07-04 19:29:19 --> Config Class Initialized
INFO - 2026-07-04 19:29:19 --> Hooks Class Initialized
DEBUG - 2026-07-04 19:29:19 --> UTF-8 Support Enabled
INFO - 2026-07-04 19:29:19 --> Utf8 Class Initialized
INFO - 2026-07-04 19:29:19 --> Output Class Initialized
DEBUG - 2026-07-04 19:29:19 --> UTF-8 Support Enabled
INFO - 2026-07-04 19:29:19 --> URI Class Initialized
INFO - 2026-07-04 19:29:19 --> Utf8 Class Initialized
DEBUG - 2026-07-04 19:29:19 --> UTF-8 Support Enabled
INFO - 2026-07-04 19:29:19 --> Utf8 Class Initialized
INFO - 2026-07-04 19:29:19 --> URI Class Initialized
INFO - 2026-07-04 19:29:19 --> Security Class Initialized
INFO - 2026-07-04 19:29:19 --> URI Class Initialized
INFO - 2026-07-04 19:29:19 --> Router Class Initialized
DEBUG - 2026-07-04 19:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 19:29:19 --> CSRF cookie sent
INFO - 2026-07-04 19:29:19 --> Input Class Initialized
INFO - 2026-07-04 19:29:19 --> Language Class Initialized
INFO - 2026-07-04 19:29:19 --> Router Class Initialized
INFO - 2026-07-04 19:29:19 --> Router Class Initialized
INFO - 2026-07-04 19:29:19 --> Output Class Initialized
INFO - 2026-07-04 19:29:19 --> Language Class Initialized
INFO - 2026-07-04 19:29:19 --> Config Class Initialized
INFO - 2026-07-04 19:29:19 --> Output Class Initialized
INFO - 2026-07-04 19:29:19 --> Security Class Initialized
INFO - 2026-07-04 19:29:19 --> Output Class Initialized
INFO - 2026-07-04 19:29:19 --> Security Class Initialized
DEBUG - 2026-07-04 19:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 19:29:19 --> Input Class Initialized
INFO - 2026-07-04 19:29:19 --> Security Class Initialized
INFO - 2026-07-04 19:29:19 --> Language Class Initialized
INFO - 2026-07-04 19:29:19 --> Loader Class Initialized
DEBUG - 2026-07-04 19:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 19:29:19 --> Config Class Initialized
INFO - 2026-07-04 19:29:19 --> Input Class Initialized
INFO - 2026-07-04 19:29:19 --> Hooks Class Initialized
INFO - 2026-07-04 19:29:19 --> Language Class Initialized
INFO - 2026-07-04 19:29:19 --> Helper loaded: url_helper
INFO - 2026-07-04 19:29:19 --> Config Class Initialized
DEBUG - 2026-07-04 19:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 19:29:19 --> Hooks Class Initialized
INFO - 2026-07-04 19:29:19 --> Config Class Initialized
INFO - 2026-07-04 19:29:19 --> Language Class Initialized
INFO - 2026-07-04 19:29:19 --> Input Class Initialized
INFO - 2026-07-04 19:29:19 --> Language Class Initialized
INFO - 2026-07-04 19:29:19 --> Language Class Initialized
INFO - 2026-07-04 19:29:19 --> Config Class Initialized
INFO - 2026-07-04 19:29:19 --> Helper loaded: form_helper
DEBUG - 2026-07-04 19:29:19 --> UTF-8 Support Enabled
INFO - 2026-07-04 19:29:19 --> Utf8 Class Initialized
DEBUG - 2026-07-04 19:29:19 --> UTF-8 Support Enabled
INFO - 2026-07-04 19:29:19 --> Utf8 Class Initialized
INFO - 2026-07-04 19:29:19 --> Language Class Initialized
INFO - 2026-07-04 19:29:19 --> Config Class Initialized
INFO - 2026-07-04 19:29:19 --> Helper loaded: html_helper
INFO - 2026-07-04 19:29:19 --> URI Class Initialized
INFO - 2026-07-04 19:29:19 --> URI Class Initialized
INFO - 2026-07-04 19:29:19 --> Helper loaded: file_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: email_helper
INFO - 2026-07-04 19:29:19 --> Loader Class Initialized
INFO - 2026-07-04 19:29:19 --> Helper loaded: url_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 19:29:19 --> Router Class Initialized
INFO - 2026-07-04 19:29:19 --> Loader Class Initialized
INFO - 2026-07-04 19:29:19 --> Router Class Initialized
INFO - 2026-07-04 19:29:19 --> Output Class Initialized
INFO - 2026-07-04 19:29:19 --> Loader Class Initialized
INFO - 2026-07-04 19:29:19 --> Helper loaded: url_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: url_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: form_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: form_helper
INFO - 2026-07-04 19:29:19 --> Security Class Initialized
INFO - 2026-07-04 19:29:19 --> Output Class Initialized
INFO - 2026-07-04 19:29:19 --> Helper loaded: ssp_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: form_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: html_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: html_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: html_helper
DEBUG - 2026-07-04 19:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 19:29:19 --> Input Class Initialized
INFO - 2026-07-04 19:29:19 --> Security Class Initialized
INFO - 2026-07-04 19:29:19 --> Helper loaded: file_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: file_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: file_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: email_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: email_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: email_helper
INFO - 2026-07-04 19:29:19 --> Language Class Initialized
INFO - 2026-07-04 19:29:19 --> Helper loaded: cpanel_helper
DEBUG - 2026-07-04 19:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 19:29:19 --> Input Class Initialized
INFO - 2026-07-04 19:29:19 --> Language Class Initialized
INFO - 2026-07-04 19:29:19 --> Config Class Initialized
INFO - 2026-07-04 19:29:19 --> Language Class Initialized
INFO - 2026-07-04 19:29:19 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: plesk_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: ssp_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: ssp_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: ssp_helper
INFO - 2026-07-04 19:29:19 --> Language Class Initialized
INFO - 2026-07-04 19:29:19 --> Config Class Initialized
INFO - 2026-07-04 19:29:19 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 19:29:19 --> Loader Class Initialized
INFO - 2026-07-04 19:29:19 --> Helper loaded: plesk_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: plesk_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: plesk_helper
INFO - 2026-07-04 19:29:19 --> Loader Class Initialized
INFO - 2026-07-04 19:29:19 --> Helper loaded: url_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: url_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: domain_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: form_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: html_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: form_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: html_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: file_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: email_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: file_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: email_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: domain_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: domain_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: domain_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: ssp_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: ssp_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: plesk_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: plesk_helper
INFO - 2026-07-04 19:29:19 --> Database Driver Class Initialized
INFO - 2026-07-04 19:29:19 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 19:29:19 --> Database Driver Class Initialized
INFO - 2026-07-04 19:29:19 --> Helper loaded: domain_helper
INFO - 2026-07-04 19:29:19 --> Database Driver Class Initialized
INFO - 2026-07-04 19:29:19 --> Database Driver Class Initialized
INFO - 2026-07-04 19:29:19 --> Helper loaded: domain_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 19:29:19 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 19:29:19 --> Database Driver Class Initialized
INFO - 2026-07-04 19:29:19 --> Database Driver Class Initialized
INFO - 2026-07-04 19:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 19:29:20 --> Upload Class Initialized
DEBUG - 2026-07-04 19:29:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 19:29:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 19:29:20 --> Encryption Class Initialized
INFO - 2026-07-04 19:29:20 --> Form Validation Class Initialized
INFO - 2026-07-04 19:29:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 19:29:20 --> Pagination Class Initialized
INFO - 2026-07-04 19:29:20 --> Email Class Initialized
INFO - 2026-07-04 19:29:20 --> Controller Class Initialized
DEBUG - 2026-07-04 19:29:20 --> Ticket MX_Controller Initialized
INFO - 2026-07-04 19:29:20 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 19:29:20 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 19:29:20 --> Model "Support_model" initialized
INFO - 2026-07-04 19:29:20 --> Model "Common_model" initialized
INFO - 2026-07-04 19:29:22 --> Final output sent to browser
DEBUG - 2026-07-04 19:29:22 --> Total execution time: 3.4329
INFO - 2026-07-04 19:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 19:29:22 --> Upload Class Initialized
DEBUG - 2026-07-04 19:29:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 19:29:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 19:29:22 --> Encryption Class Initialized
INFO - 2026-07-04 19:29:22 --> Form Validation Class Initialized
INFO - 2026-07-04 19:29:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 19:29:22 --> Pagination Class Initialized
INFO - 2026-07-04 19:29:22 --> Config Class Initialized
INFO - 2026-07-04 19:29:22 --> Hooks Class Initialized
INFO - 2026-07-04 19:29:22 --> Email Class Initialized
INFO - 2026-07-04 19:29:22 --> Controller Class Initialized
DEBUG - 2026-07-04 19:29:22 --> UTF-8 Support Enabled
INFO - 2026-07-04 19:29:22 --> Utf8 Class Initialized
DEBUG - 2026-07-04 19:29:22 --> Dashboard MX_Controller Initialized
INFO - 2026-07-04 19:29:22 --> URI Class Initialized
INFO - 2026-07-04 19:29:22 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 19:29:22 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 19:29:22 --> Router Class Initialized
INFO - 2026-07-04 19:29:22 --> Output Class Initialized
INFO - 2026-07-04 19:29:22 --> Security Class Initialized
DEBUG - 2026-07-04 19:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 19:29:22 --> Input Class Initialized
INFO - 2026-07-04 19:29:22 --> Language Class Initialized
INFO - 2026-07-04 19:29:22 --> Language Class Initialized
INFO - 2026-07-04 19:29:22 --> Config Class Initialized
INFO - 2026-07-04 19:29:22 --> Loader Class Initialized
INFO - 2026-07-04 19:29:22 --> Helper loaded: url_helper
INFO - 2026-07-04 19:29:22 --> Helper loaded: form_helper
INFO - 2026-07-04 19:29:22 --> Helper loaded: html_helper
INFO - 2026-07-04 19:29:22 --> Helper loaded: file_helper
INFO - 2026-07-04 19:29:22 --> Helper loaded: email_helper
INFO - 2026-07-04 19:29:22 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 19:29:22 --> Helper loaded: ssp_helper
INFO - 2026-07-04 19:29:22 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 19:29:22 --> Helper loaded: plesk_helper
INFO - 2026-07-04 19:29:22 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 19:29:22 --> Helper loaded: domain_helper
INFO - 2026-07-04 19:29:22 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 19:29:22 --> Database Driver Class Initialized
INFO - 2026-07-04 19:29:22 --> Model "Dashboard_model" initialized
INFO - 2026-07-04 19:29:23 --> Final output sent to browser
DEBUG - 2026-07-04 19:29:23 --> Total execution time: 4.2456
INFO - 2026-07-04 19:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 19:29:23 --> Upload Class Initialized
DEBUG - 2026-07-04 19:29:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 19:29:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 19:29:23 --> Encryption Class Initialized
INFO - 2026-07-04 19:29:23 --> Form Validation Class Initialized
INFO - 2026-07-04 19:29:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 19:29:23 --> Pagination Class Initialized
INFO - 2026-07-04 19:29:23 --> Email Class Initialized
INFO - 2026-07-04 19:29:23 --> Controller Class Initialized
DEBUG - 2026-07-04 19:29:23 --> Order MX_Controller Initialized
INFO - 2026-07-04 19:29:23 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 19:29:23 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 19:29:23 --> Model "Order_model" initialized
INFO - 2026-07-04 19:29:23 --> Model "Common_model" initialized
INFO - 2026-07-04 19:29:23 --> Model "Currency_model" initialized
INFO - 2026-07-04 19:29:24 --> Final output sent to browser
DEBUG - 2026-07-04 19:29:24 --> Total execution time: 5.0758
INFO - 2026-07-04 19:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 19:29:24 --> Upload Class Initialized
DEBUG - 2026-07-04 19:29:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 19:29:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 19:29:24 --> Encryption Class Initialized
INFO - 2026-07-04 19:29:24 --> Form Validation Class Initialized
INFO - 2026-07-04 19:29:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 19:29:24 --> Pagination Class Initialized
INFO - 2026-07-04 19:29:24 --> Email Class Initialized
INFO - 2026-07-04 19:29:24 --> Controller Class Initialized
DEBUG - 2026-07-04 19:29:24 --> Notification MX_Controller Initialized
INFO - 2026-07-04 19:29:24 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 19:29:24 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 19:29:24 --> Model "Notification_model" initialized
INFO - 2026-07-04 19:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 19:29:25 --> Upload Class Initialized
DEBUG - 2026-07-04 19:29:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 19:29:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 19:29:25 --> Encryption Class Initialized
INFO - 2026-07-04 19:29:25 --> Form Validation Class Initialized
INFO - 2026-07-04 19:29:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 19:29:25 --> Pagination Class Initialized
INFO - 2026-07-04 19:29:25 --> Email Class Initialized
INFO - 2026-07-04 19:29:25 --> Controller Class Initialized
DEBUG - 2026-07-04 19:29:25 --> Invoice MX_Controller Initialized
INFO - 2026-07-04 19:29:25 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 19:29:25 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 19:29:25 --> Model "Billing_model" initialized
INFO - 2026-07-04 19:29:25 --> Model "Common_model" initialized
INFO - 2026-07-04 19:29:25 --> Model "Invoice_model" initialized
INFO - 2026-07-04 19:29:25 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 19:29:26 --> Final output sent to browser
DEBUG - 2026-07-04 19:29:26 --> Total execution time: 7.4251
INFO - 2026-07-04 19:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 19:29:26 --> Upload Class Initialized
DEBUG - 2026-07-04 19:29:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 19:29:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 19:29:26 --> Encryption Class Initialized
INFO - 2026-07-04 19:29:26 --> Form Validation Class Initialized
INFO - 2026-07-04 19:29:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 19:29:26 --> Pagination Class Initialized
INFO - 2026-07-04 19:29:26 --> Email Class Initialized
INFO - 2026-07-04 19:29:26 --> Controller Class Initialized
DEBUG - 2026-07-04 19:29:26 --> Dashboard MX_Controller Initialized
INFO - 2026-07-04 19:29:26 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 19:29:26 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 19:29:26 --> Model "Dashboard_model" initialized
INFO - 2026-07-04 19:29:27 --> Final output sent to browser
DEBUG - 2026-07-04 19:29:27 --> Total execution time: 8.2456
INFO - 2026-07-04 19:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 19:29:27 --> Upload Class Initialized
DEBUG - 2026-07-04 19:29:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 19:29:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 19:29:27 --> Encryption Class Initialized
INFO - 2026-07-04 19:29:27 --> Form Validation Class Initialized
INFO - 2026-07-04 19:29:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 19:29:27 --> Pagination Class Initialized
INFO - 2026-07-04 19:29:27 --> Email Class Initialized
INFO - 2026-07-04 19:29:27 --> Controller Class Initialized
DEBUG - 2026-07-04 19:29:27 --> Dashboard MX_Controller Initialized
INFO - 2026-07-04 19:29:27 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 19:29:27 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 19:29:27 --> Model "Dashboard_model" initialized
INFO - 2026-07-04 19:29:29 --> Final output sent to browser
DEBUG - 2026-07-04 19:29:29 --> Total execution time: 6.4409
INFO - 2026-07-04 19:29:44 --> Config Class Initialized
INFO - 2026-07-04 19:29:44 --> Hooks Class Initialized
DEBUG - 2026-07-04 19:29:44 --> UTF-8 Support Enabled
INFO - 2026-07-04 19:29:44 --> Utf8 Class Initialized
INFO - 2026-07-04 19:29:44 --> URI Class Initialized
INFO - 2026-07-04 19:29:44 --> Router Class Initialized
INFO - 2026-07-04 19:29:44 --> Output Class Initialized
INFO - 2026-07-04 19:29:44 --> Security Class Initialized
DEBUG - 2026-07-04 19:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 19:29:44 --> CSRF cookie sent
INFO - 2026-07-04 19:29:44 --> Input Class Initialized
INFO - 2026-07-04 19:29:44 --> Language Class Initialized
INFO - 2026-07-04 19:29:44 --> Language Class Initialized
INFO - 2026-07-04 19:29:44 --> Config Class Initialized
INFO - 2026-07-04 19:29:44 --> Loader Class Initialized
INFO - 2026-07-04 19:29:44 --> Helper loaded: url_helper
INFO - 2026-07-04 19:29:44 --> Helper loaded: form_helper
INFO - 2026-07-04 19:29:44 --> Helper loaded: html_helper
INFO - 2026-07-04 19:29:44 --> Helper loaded: file_helper
INFO - 2026-07-04 19:29:44 --> Helper loaded: email_helper
INFO - 2026-07-04 19:29:44 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 19:29:44 --> Helper loaded: ssp_helper
INFO - 2026-07-04 19:29:44 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 19:29:44 --> Helper loaded: plesk_helper
INFO - 2026-07-04 19:29:44 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 19:29:44 --> Helper loaded: domain_helper
INFO - 2026-07-04 19:29:44 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 19:29:44 --> Database Driver Class Initialized
INFO - 2026-07-04 19:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 19:29:46 --> Upload Class Initialized
DEBUG - 2026-07-04 19:29:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 19:29:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 19:29:46 --> Encryption Class Initialized
INFO - 2026-07-04 19:29:46 --> Form Validation Class Initialized
INFO - 2026-07-04 19:29:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 19:29:46 --> Pagination Class Initialized
INFO - 2026-07-04 19:29:46 --> Email Class Initialized
INFO - 2026-07-04 19:29:46 --> Controller Class Initialized
DEBUG - 2026-07-04 19:29:46 --> Paymentgateway MX_Controller Initialized
INFO - 2026-07-04 19:29:46 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 19:29:46 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 19:29:46 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-04 19:29:46 --> Model "Payment_model" initialized
DEBUG - 2026-07-04 19:29:48 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-04 19:29:48 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-04 19:29:48 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-04 19:29:48 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-04 19:29:48 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-04 19:29:48 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/paymentgateway_list.php
INFO - 2026-07-04 19:29:48 --> Final output sent to browser
DEBUG - 2026-07-04 19:29:48 --> Total execution time: 3.5852
INFO - 2026-07-04 19:29:48 --> Config Class Initialized
INFO - 2026-07-04 19:29:48 --> Hooks Class Initialized
DEBUG - 2026-07-04 19:29:48 --> UTF-8 Support Enabled
INFO - 2026-07-04 19:29:48 --> Utf8 Class Initialized
INFO - 2026-07-04 19:29:48 --> URI Class Initialized
INFO - 2026-07-04 19:29:48 --> Router Class Initialized
INFO - 2026-07-04 19:29:48 --> Output Class Initialized
INFO - 2026-07-04 19:29:48 --> Security Class Initialized
DEBUG - 2026-07-04 19:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 19:29:48 --> CSRF cookie sent
INFO - 2026-07-04 19:29:48 --> Input Class Initialized
INFO - 2026-07-04 19:29:48 --> Language Class Initialized
INFO - 2026-07-04 19:29:48 --> Language Class Initialized
INFO - 2026-07-04 19:29:48 --> Config Class Initialized
INFO - 2026-07-04 19:29:48 --> Loader Class Initialized
INFO - 2026-07-04 19:29:48 --> Helper loaded: url_helper
INFO - 2026-07-04 19:29:48 --> Helper loaded: form_helper
INFO - 2026-07-04 19:29:48 --> Helper loaded: html_helper
INFO - 2026-07-04 19:29:48 --> Helper loaded: file_helper
INFO - 2026-07-04 19:29:48 --> Helper loaded: email_helper
INFO - 2026-07-04 19:29:48 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 19:29:48 --> Helper loaded: ssp_helper
INFO - 2026-07-04 19:29:48 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 19:29:48 --> Helper loaded: plesk_helper
INFO - 2026-07-04 19:29:48 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 19:29:48 --> Helper loaded: domain_helper
INFO - 2026-07-04 19:29:48 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 19:29:48 --> Database Driver Class Initialized
INFO - 2026-07-04 19:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 19:29:50 --> Upload Class Initialized
DEBUG - 2026-07-04 19:29:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 19:29:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 19:29:50 --> Encryption Class Initialized
INFO - 2026-07-04 19:29:50 --> Form Validation Class Initialized
INFO - 2026-07-04 19:29:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 19:29:50 --> Pagination Class Initialized
INFO - 2026-07-04 19:29:50 --> Email Class Initialized
INFO - 2026-07-04 19:29:50 --> Controller Class Initialized
DEBUG - 2026-07-04 19:29:50 --> Notification MX_Controller Initialized
INFO - 2026-07-04 19:29:50 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 19:29:50 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 19:29:50 --> Model "Notification_model" initialized
INFO - 2026-07-04 19:30:27 --> Config Class Initialized
INFO - 2026-07-04 19:30:27 --> Hooks Class Initialized
DEBUG - 2026-07-04 19:30:27 --> UTF-8 Support Enabled
INFO - 2026-07-04 19:30:27 --> Utf8 Class Initialized
INFO - 2026-07-04 19:30:27 --> URI Class Initialized
INFO - 2026-07-04 19:30:27 --> Router Class Initialized
INFO - 2026-07-04 19:30:27 --> Output Class Initialized
INFO - 2026-07-04 19:30:27 --> Security Class Initialized
DEBUG - 2026-07-04 19:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 19:30:27 --> CSRF cookie sent
INFO - 2026-07-04 19:30:27 --> Input Class Initialized
INFO - 2026-07-04 19:30:27 --> Language Class Initialized
INFO - 2026-07-04 19:30:27 --> Language Class Initialized
INFO - 2026-07-04 19:30:27 --> Config Class Initialized
INFO - 2026-07-04 19:30:27 --> Loader Class Initialized
INFO - 2026-07-04 19:30:27 --> Helper loaded: url_helper
INFO - 2026-07-04 19:30:27 --> Helper loaded: form_helper
INFO - 2026-07-04 19:30:27 --> Helper loaded: html_helper
INFO - 2026-07-04 19:30:27 --> Helper loaded: file_helper
INFO - 2026-07-04 19:30:27 --> Helper loaded: email_helper
INFO - 2026-07-04 19:30:27 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 19:30:27 --> Helper loaded: ssp_helper
INFO - 2026-07-04 19:30:27 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 19:30:27 --> Helper loaded: plesk_helper
INFO - 2026-07-04 19:30:27 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 19:30:27 --> Helper loaded: domain_helper
INFO - 2026-07-04 19:30:27 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 19:30:27 --> Database Driver Class Initialized
INFO - 2026-07-04 19:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 19:30:30 --> Upload Class Initialized
DEBUG - 2026-07-04 19:30:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 19:30:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 19:30:30 --> Encryption Class Initialized
INFO - 2026-07-04 19:30:30 --> Form Validation Class Initialized
INFO - 2026-07-04 19:30:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 19:30:30 --> Pagination Class Initialized
INFO - 2026-07-04 19:30:30 --> Email Class Initialized
INFO - 2026-07-04 19:30:30 --> Controller Class Initialized
DEBUG - 2026-07-04 19:30:30 --> Paymentgateway MX_Controller Initialized
INFO - 2026-07-04 19:30:30 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 19:30:30 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 19:30:30 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-04 19:30:30 --> Model "Payment_model" initialized
DEBUG - 2026-07-04 19:30:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-04 19:30:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-04 19:30:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-04 19:30:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-04 19:30:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-04 19:30:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/paymentgateway_manage.php
INFO - 2026-07-04 19:30:31 --> Final output sent to browser
DEBUG - 2026-07-04 19:30:31 --> Total execution time: 4.3079
INFO - 2026-07-04 19:30:32 --> Config Class Initialized
INFO - 2026-07-04 19:30:32 --> Hooks Class Initialized
DEBUG - 2026-07-04 19:30:32 --> UTF-8 Support Enabled
INFO - 2026-07-04 19:30:32 --> Utf8 Class Initialized
INFO - 2026-07-04 19:30:32 --> URI Class Initialized
INFO - 2026-07-04 19:30:32 --> Router Class Initialized
INFO - 2026-07-04 19:30:32 --> Output Class Initialized
INFO - 2026-07-04 19:30:32 --> Security Class Initialized
DEBUG - 2026-07-04 19:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 19:30:32 --> CSRF cookie sent
INFO - 2026-07-04 19:30:32 --> Input Class Initialized
INFO - 2026-07-04 19:30:32 --> Language Class Initialized
INFO - 2026-07-04 19:30:32 --> Language Class Initialized
INFO - 2026-07-04 19:30:32 --> Config Class Initialized
INFO - 2026-07-04 19:30:32 --> Loader Class Initialized
INFO - 2026-07-04 19:30:32 --> Helper loaded: url_helper
INFO - 2026-07-04 19:30:32 --> Helper loaded: form_helper
INFO - 2026-07-04 19:30:32 --> Helper loaded: html_helper
INFO - 2026-07-04 19:30:32 --> Helper loaded: file_helper
INFO - 2026-07-04 19:30:32 --> Helper loaded: email_helper
INFO - 2026-07-04 19:30:32 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 19:30:32 --> Helper loaded: ssp_helper
INFO - 2026-07-04 19:30:32 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 19:30:32 --> Helper loaded: plesk_helper
INFO - 2026-07-04 19:30:32 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 19:30:32 --> Helper loaded: domain_helper
INFO - 2026-07-04 19:30:32 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 19:30:32 --> Database Driver Class Initialized
INFO - 2026-07-04 19:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 19:30:34 --> Upload Class Initialized
DEBUG - 2026-07-04 19:30:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 19:30:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 19:30:34 --> Encryption Class Initialized
INFO - 2026-07-04 19:30:34 --> Form Validation Class Initialized
INFO - 2026-07-04 19:30:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 19:30:34 --> Pagination Class Initialized
INFO - 2026-07-04 19:30:34 --> Email Class Initialized
INFO - 2026-07-04 19:30:34 --> Controller Class Initialized
DEBUG - 2026-07-04 19:30:34 --> Notification MX_Controller Initialized
INFO - 2026-07-04 19:30:34 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 19:30:34 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 19:30:34 --> Model "Notification_model" initialized
INFO - 2026-07-04 19:31:01 --> Config Class Initialized
INFO - 2026-07-04 19:31:01 --> Hooks Class Initialized
DEBUG - 2026-07-04 19:31:01 --> UTF-8 Support Enabled
INFO - 2026-07-04 19:31:01 --> Utf8 Class Initialized
INFO - 2026-07-04 19:31:01 --> URI Class Initialized
INFO - 2026-07-04 19:31:01 --> Router Class Initialized
INFO - 2026-07-04 19:31:01 --> Output Class Initialized
INFO - 2026-07-04 19:31:01 --> Security Class Initialized
DEBUG - 2026-07-04 19:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 19:31:01 --> CSRF cookie sent
INFO - 2026-07-04 19:31:01 --> Input Class Initialized
INFO - 2026-07-04 19:31:01 --> Language Class Initialized
INFO - 2026-07-04 19:31:01 --> Language Class Initialized
INFO - 2026-07-04 19:31:01 --> Config Class Initialized
INFO - 2026-07-04 19:31:01 --> Loader Class Initialized
INFO - 2026-07-04 19:31:01 --> Helper loaded: url_helper
INFO - 2026-07-04 19:31:01 --> Helper loaded: form_helper
INFO - 2026-07-04 19:31:01 --> Helper loaded: html_helper
INFO - 2026-07-04 19:31:01 --> Helper loaded: file_helper
INFO - 2026-07-04 19:31:01 --> Helper loaded: email_helper
INFO - 2026-07-04 19:31:01 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 19:31:01 --> Helper loaded: ssp_helper
INFO - 2026-07-04 19:31:01 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 19:31:01 --> Helper loaded: plesk_helper
INFO - 2026-07-04 19:31:01 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 19:31:01 --> Helper loaded: domain_helper
INFO - 2026-07-04 19:31:01 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 19:31:01 --> Database Driver Class Initialized
INFO - 2026-07-04 19:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 19:31:03 --> Upload Class Initialized
DEBUG - 2026-07-04 19:31:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 19:31:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 19:31:03 --> Encryption Class Initialized
INFO - 2026-07-04 19:31:03 --> Form Validation Class Initialized
INFO - 2026-07-04 19:31:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 19:31:03 --> Pagination Class Initialized
INFO - 2026-07-04 19:31:03 --> Email Class Initialized
INFO - 2026-07-04 19:31:03 --> Controller Class Initialized
DEBUG - 2026-07-04 19:31:03 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 19:31:03 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 19:31:03 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 19:31:03 --> Model "Appsetting_model" initialized
INFO - 2026-07-04 19:31:03 --> Config Class Initialized
INFO - 2026-07-04 19:31:03 --> Hooks Class Initialized
DEBUG - 2026-07-04 19:31:03 --> UTF-8 Support Enabled
INFO - 2026-07-04 19:31:03 --> Utf8 Class Initialized
INFO - 2026-07-04 19:31:03 --> URI Class Initialized
INFO - 2026-07-04 19:31:03 --> Router Class Initialized
INFO - 2026-07-04 19:31:03 --> Output Class Initialized
INFO - 2026-07-04 19:31:03 --> Security Class Initialized
DEBUG - 2026-07-04 19:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-04 19:31:03 --> CSRF cookie sent
INFO - 2026-07-04 19:31:03 --> Input Class Initialized
INFO - 2026-07-04 19:31:03 --> Language Class Initialized
INFO - 2026-07-04 19:31:03 --> Language Class Initialized
INFO - 2026-07-04 19:31:03 --> Config Class Initialized
INFO - 2026-07-04 19:31:03 --> Loader Class Initialized
INFO - 2026-07-04 19:31:03 --> Helper loaded: url_helper
INFO - 2026-07-04 19:31:03 --> Helper loaded: form_helper
INFO - 2026-07-04 19:31:03 --> Helper loaded: html_helper
INFO - 2026-07-04 19:31:03 --> Helper loaded: file_helper
INFO - 2026-07-04 19:31:03 --> Helper loaded: email_helper
INFO - 2026-07-04 19:31:03 --> Helper loaded: whmaz_helper
INFO - 2026-07-04 19:31:03 --> Helper loaded: ssp_helper
INFO - 2026-07-04 19:31:03 --> Helper loaded: cpanel_helper
INFO - 2026-07-04 19:31:03 --> Helper loaded: plesk_helper
INFO - 2026-07-04 19:31:03 --> Helper loaded: directadmin_helper
INFO - 2026-07-04 19:31:03 --> Helper loaded: domain_helper
INFO - 2026-07-04 19:31:03 --> Helper loaded: entitlement_helper
INFO - 2026-07-04 19:31:03 --> Database Driver Class Initialized
INFO - 2026-07-04 19:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-04 19:31:05 --> Upload Class Initialized
DEBUG - 2026-07-04 19:31:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-04 19:31:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-04 19:31:05 --> Encryption Class Initialized
INFO - 2026-07-04 19:31:05 --> Form Validation Class Initialized
INFO - 2026-07-04 19:31:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-04 19:31:05 --> Pagination Class Initialized
INFO - 2026-07-04 19:31:05 --> Email Class Initialized
INFO - 2026-07-04 19:31:05 --> Controller Class Initialized
DEBUG - 2026-07-04 19:31:05 --> Authenticate MX_Controller Initialized
INFO - 2026-07-04 19:31:05 --> Model "Loginattempt_model" initialized
INFO - 2026-07-04 19:31:05 --> Model "Adminauth_model" initialized
INFO - 2026-07-04 19:31:05 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-04 19:31:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-04 19:31:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-04 19:31:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-07-04 19:31:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-04 19:31:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-04 19:31:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-07-04 19:31:05 --> Final output sent to browser
DEBUG - 2026-07-04 19:31:05 --> Total execution time: 2.3911

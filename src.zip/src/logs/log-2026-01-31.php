<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-01-31 04:34:04 --> Config Class Initialized
INFO - 2026-01-31 04:34:04 --> Hooks Class Initialized
DEBUG - 2026-01-31 04:34:04 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:34:04 --> Utf8 Class Initialized
INFO - 2026-01-31 04:34:04 --> URI Class Initialized
INFO - 2026-01-31 04:34:04 --> Router Class Initialized
INFO - 2026-01-31 04:34:04 --> Output Class Initialized
INFO - 2026-01-31 04:34:04 --> Security Class Initialized
DEBUG - 2026-01-31 04:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:34:04 --> CSRF cookie sent
INFO - 2026-01-31 04:34:04 --> Input Class Initialized
INFO - 2026-01-31 04:34:04 --> Language Class Initialized
INFO - 2026-01-31 04:34:04 --> Language Class Initialized
INFO - 2026-01-31 04:34:04 --> Config Class Initialized
INFO - 2026-01-31 04:34:04 --> Loader Class Initialized
INFO - 2026-01-31 04:34:04 --> Helper loaded: url_helper
INFO - 2026-01-31 04:34:04 --> Helper loaded: form_helper
INFO - 2026-01-31 04:34:04 --> Helper loaded: html_helper
INFO - 2026-01-31 04:34:04 --> Helper loaded: file_helper
INFO - 2026-01-31 04:34:04 --> Helper loaded: email_helper
INFO - 2026-01-31 04:34:04 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:34:04 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:34:04 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:34:04 --> Database Driver Class Initialized
INFO - 2026-01-31 04:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:34:05 --> Upload Class Initialized
DEBUG - 2026-01-31 04:34:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:34:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:34:05 --> Encryption Class Initialized
INFO - 2026-01-31 04:34:05 --> Form Validation Class Initialized
INFO - 2026-01-31 04:34:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:34:05 --> Pagination Class Initialized
INFO - 2026-01-31 04:34:05 --> Email Class Initialized
INFO - 2026-01-31 04:34:05 --> Controller Class Initialized
DEBUG - 2026-01-31 04:34:05 --> Auth MX_Controller Initialized
INFO - 2026-01-31 04:34:05 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 04:34:05 --> Model "Auth_model" initialized
INFO - 2026-01-31 04:34:05 --> Model "Cart_model" initialized
INFO - 2026-01-31 04:34:05 --> Model "Appsetting_model" initialized
DEBUG - 2026-01-31 04:34:06 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 04:34:06 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 04:34:06 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 04:34:06 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_resetpassword.php
INFO - 2026-01-31 04:34:06 --> Final output sent to browser
DEBUG - 2026-01-31 04:34:06 --> Total execution time: 2.4431
INFO - 2026-01-31 04:34:06 --> Config Class Initialized
INFO - 2026-01-31 04:34:06 --> Hooks Class Initialized
INFO - 2026-01-31 04:34:06 --> Config Class Initialized
INFO - 2026-01-31 04:34:06 --> Hooks Class Initialized
DEBUG - 2026-01-31 04:34:06 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:34:06 --> Utf8 Class Initialized
INFO - 2026-01-31 04:34:06 --> URI Class Initialized
DEBUG - 2026-01-31 04:34:06 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:34:06 --> Utf8 Class Initialized
INFO - 2026-01-31 04:34:06 --> URI Class Initialized
INFO - 2026-01-31 04:34:06 --> Router Class Initialized
INFO - 2026-01-31 04:34:06 --> Output Class Initialized
INFO - 2026-01-31 04:34:06 --> Router Class Initialized
INFO - 2026-01-31 04:34:06 --> Security Class Initialized
DEBUG - 2026-01-31 04:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:34:06 --> CSRF cookie sent
INFO - 2026-01-31 04:34:06 --> Input Class Initialized
INFO - 2026-01-31 04:34:06 --> Output Class Initialized
INFO - 2026-01-31 04:34:06 --> Language Class Initialized
INFO - 2026-01-31 04:34:06 --> Language Class Initialized
INFO - 2026-01-31 04:34:06 --> Config Class Initialized
INFO - 2026-01-31 04:34:06 --> Security Class Initialized
DEBUG - 2026-01-31 04:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:34:06 --> CSRF cookie sent
INFO - 2026-01-31 04:34:06 --> Input Class Initialized
INFO - 2026-01-31 04:34:06 --> Loader Class Initialized
INFO - 2026-01-31 04:34:06 --> Language Class Initialized
INFO - 2026-01-31 04:34:06 --> Language Class Initialized
INFO - 2026-01-31 04:34:06 --> Helper loaded: url_helper
INFO - 2026-01-31 04:34:06 --> Config Class Initialized
INFO - 2026-01-31 04:34:06 --> Helper loaded: form_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: html_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: file_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: email_helper
INFO - 2026-01-31 04:34:06 --> Loader Class Initialized
INFO - 2026-01-31 04:34:06 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: url_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: form_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: html_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: file_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: email_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:34:06 --> Database Driver Class Initialized
INFO - 2026-01-31 04:34:06 --> Database Driver Class Initialized
INFO - 2026-01-31 04:34:06 --> Config Class Initialized
INFO - 2026-01-31 04:34:06 --> Hooks Class Initialized
INFO - 2026-01-31 04:34:06 --> Config Class Initialized
INFO - 2026-01-31 04:34:06 --> Hooks Class Initialized
DEBUG - 2026-01-31 04:34:06 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:34:06 --> Utf8 Class Initialized
INFO - 2026-01-31 04:34:06 --> Config Class Initialized
INFO - 2026-01-31 04:34:06 --> Hooks Class Initialized
INFO - 2026-01-31 04:34:06 --> URI Class Initialized
DEBUG - 2026-01-31 04:34:06 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:34:06 --> Utf8 Class Initialized
DEBUG - 2026-01-31 04:34:06 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:34:06 --> Utf8 Class Initialized
INFO - 2026-01-31 04:34:06 --> URI Class Initialized
INFO - 2026-01-31 04:34:06 --> URI Class Initialized
INFO - 2026-01-31 04:34:06 --> Router Class Initialized
INFO - 2026-01-31 04:34:06 --> Router Class Initialized
INFO - 2026-01-31 04:34:06 --> Router Class Initialized
INFO - 2026-01-31 04:34:06 --> Output Class Initialized
INFO - 2026-01-31 04:34:06 --> Output Class Initialized
INFO - 2026-01-31 04:34:06 --> Security Class Initialized
INFO - 2026-01-31 04:34:06 --> Output Class Initialized
INFO - 2026-01-31 04:34:06 --> Security Class Initialized
DEBUG - 2026-01-31 04:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:34:06 --> CSRF cookie sent
INFO - 2026-01-31 04:34:06 --> Input Class Initialized
INFO - 2026-01-31 04:34:06 --> Security Class Initialized
INFO - 2026-01-31 04:34:06 --> Language Class Initialized
DEBUG - 2026-01-31 04:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:34:06 --> CSRF cookie sent
INFO - 2026-01-31 04:34:06 --> Input Class Initialized
INFO - 2026-01-31 04:34:06 --> Language Class Initialized
INFO - 2026-01-31 04:34:06 --> Language Class Initialized
INFO - 2026-01-31 04:34:06 --> Config Class Initialized
DEBUG - 2026-01-31 04:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:34:06 --> CSRF cookie sent
INFO - 2026-01-31 04:34:06 --> Input Class Initialized
INFO - 2026-01-31 04:34:06 --> Language Class Initialized
INFO - 2026-01-31 04:34:06 --> Config Class Initialized
INFO - 2026-01-31 04:34:06 --> Language Class Initialized
INFO - 2026-01-31 04:34:06 --> Language Class Initialized
INFO - 2026-01-31 04:34:06 --> Config Class Initialized
INFO - 2026-01-31 04:34:06 --> Loader Class Initialized
INFO - 2026-01-31 04:34:06 --> Loader Class Initialized
INFO - 2026-01-31 04:34:06 --> Helper loaded: url_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: url_helper
INFO - 2026-01-31 04:34:06 --> Loader Class Initialized
INFO - 2026-01-31 04:34:06 --> Helper loaded: url_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: form_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: form_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: html_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: html_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: file_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: file_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: form_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: email_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: email_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: html_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: file_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: email_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:34:06 --> Database Driver Class Initialized
INFO - 2026-01-31 04:34:06 --> Database Driver Class Initialized
INFO - 2026-01-31 04:34:06 --> Database Driver Class Initialized
INFO - 2026-01-31 04:34:06 --> Config Class Initialized
INFO - 2026-01-31 04:34:06 --> Hooks Class Initialized
DEBUG - 2026-01-31 04:34:06 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:34:06 --> Utf8 Class Initialized
INFO - 2026-01-31 04:34:06 --> URI Class Initialized
INFO - 2026-01-31 04:34:06 --> Router Class Initialized
INFO - 2026-01-31 04:34:06 --> Output Class Initialized
INFO - 2026-01-31 04:34:06 --> Security Class Initialized
DEBUG - 2026-01-31 04:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:34:06 --> CSRF cookie sent
INFO - 2026-01-31 04:34:06 --> Input Class Initialized
INFO - 2026-01-31 04:34:06 --> Language Class Initialized
INFO - 2026-01-31 04:34:06 --> Language Class Initialized
INFO - 2026-01-31 04:34:06 --> Config Class Initialized
INFO - 2026-01-31 04:34:06 --> Loader Class Initialized
INFO - 2026-01-31 04:34:06 --> Helper loaded: url_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: form_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: html_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: file_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: email_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:34:06 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:34:06 --> Database Driver Class Initialized
INFO - 2026-01-31 04:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:34:08 --> Upload Class Initialized
DEBUG - 2026-01-31 04:34:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:34:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:34:08 --> Encryption Class Initialized
INFO - 2026-01-31 04:34:08 --> Form Validation Class Initialized
INFO - 2026-01-31 04:34:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:34:08 --> Pagination Class Initialized
INFO - 2026-01-31 04:34:08 --> Email Class Initialized
INFO - 2026-01-31 04:34:08 --> Controller Class Initialized
ERROR - 2026-01-31 04:34:08 --> 404 Page Not Found: /index
INFO - 2026-01-31 04:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:34:08 --> Upload Class Initialized
DEBUG - 2026-01-31 04:34:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:34:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:34:08 --> Encryption Class Initialized
INFO - 2026-01-31 04:34:08 --> Form Validation Class Initialized
INFO - 2026-01-31 04:34:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:34:08 --> Pagination Class Initialized
INFO - 2026-01-31 04:34:08 --> Email Class Initialized
INFO - 2026-01-31 04:34:08 --> Controller Class Initialized
INFO - 2026-01-31 04:34:08 --> Config Class Initialized
INFO - 2026-01-31 04:34:08 --> Hooks Class Initialized
ERROR - 2026-01-31 04:34:08 --> 404 Page Not Found: /index
INFO - 2026-01-31 04:34:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-01-31 04:34:08 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:34:08 --> Utf8 Class Initialized
INFO - 2026-01-31 04:34:08 --> URI Class Initialized
INFO - 2026-01-31 04:34:08 --> Upload Class Initialized
DEBUG - 2026-01-31 04:34:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:34:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:34:08 --> Encryption Class Initialized
INFO - 2026-01-31 04:34:08 --> Router Class Initialized
INFO - 2026-01-31 04:34:08 --> Form Validation Class Initialized
INFO - 2026-01-31 04:34:08 --> Output Class Initialized
INFO - 2026-01-31 04:34:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:34:08 --> Pagination Class Initialized
INFO - 2026-01-31 04:34:08 --> Security Class Initialized
DEBUG - 2026-01-31 04:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:34:08 --> CSRF cookie sent
INFO - 2026-01-31 04:34:08 --> Input Class Initialized
INFO - 2026-01-31 04:34:08 --> Language Class Initialized
INFO - 2026-01-31 04:34:08 --> Language Class Initialized
INFO - 2026-01-31 04:34:08 --> Config Class Initialized
INFO - 2026-01-31 04:34:08 --> Email Class Initialized
INFO - 2026-01-31 04:34:08 --> Controller Class Initialized
ERROR - 2026-01-31 04:34:08 --> 404 Page Not Found: /index
INFO - 2026-01-31 04:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:34:08 --> Loader Class Initialized
INFO - 2026-01-31 04:34:08 --> Upload Class Initialized
INFO - 2026-01-31 04:34:08 --> Helper loaded: url_helper
DEBUG - 2026-01-31 04:34:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:34:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:34:08 --> Encryption Class Initialized
INFO - 2026-01-31 04:34:08 --> Helper loaded: form_helper
INFO - 2026-01-31 04:34:08 --> Helper loaded: html_helper
INFO - 2026-01-31 04:34:08 --> Form Validation Class Initialized
INFO - 2026-01-31 04:34:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:34:08 --> Pagination Class Initialized
INFO - 2026-01-31 04:34:08 --> Config Class Initialized
INFO - 2026-01-31 04:34:08 --> Hooks Class Initialized
DEBUG - 2026-01-31 04:34:08 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:34:08 --> Utf8 Class Initialized
INFO - 2026-01-31 04:34:08 --> Helper loaded: file_helper
INFO - 2026-01-31 04:34:08 --> Helper loaded: email_helper
INFO - 2026-01-31 04:34:08 --> URI Class Initialized
INFO - 2026-01-31 04:34:08 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:34:08 --> Router Class Initialized
INFO - 2026-01-31 04:34:08 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:34:08 --> Email Class Initialized
INFO - 2026-01-31 04:34:08 --> Output Class Initialized
INFO - 2026-01-31 04:34:08 --> Controller Class Initialized
ERROR - 2026-01-31 04:34:08 --> 404 Page Not Found: /index
INFO - 2026-01-31 04:34:08 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:34:08 --> Security Class Initialized
INFO - 2026-01-31 04:34:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-01-31 04:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:34:08 --> CSRF cookie sent
INFO - 2026-01-31 04:34:08 --> Input Class Initialized
INFO - 2026-01-31 04:34:08 --> Language Class Initialized
INFO - 2026-01-31 04:34:08 --> Language Class Initialized
INFO - 2026-01-31 04:34:08 --> Config Class Initialized
INFO - 2026-01-31 04:34:08 --> Upload Class Initialized
DEBUG - 2026-01-31 04:34:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:34:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:34:08 --> Encryption Class Initialized
INFO - 2026-01-31 04:34:08 --> Loader Class Initialized
INFO - 2026-01-31 04:34:08 --> Helper loaded: url_helper
INFO - 2026-01-31 04:34:08 --> Form Validation Class Initialized
INFO - 2026-01-31 04:34:08 --> Database Driver Class Initialized
INFO - 2026-01-31 04:34:08 --> Helper loaded: form_helper
INFO - 2026-01-31 04:34:08 --> Helper loaded: html_helper
INFO - 2026-01-31 04:34:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:34:08 --> Pagination Class Initialized
INFO - 2026-01-31 04:34:08 --> Helper loaded: file_helper
INFO - 2026-01-31 04:34:08 --> Helper loaded: email_helper
INFO - 2026-01-31 04:34:08 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:34:08 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:34:08 --> Email Class Initialized
INFO - 2026-01-31 04:34:08 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:34:08 --> Controller Class Initialized
ERROR - 2026-01-31 04:34:08 --> 404 Page Not Found: /index
INFO - 2026-01-31 04:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:34:08 --> Upload Class Initialized
DEBUG - 2026-01-31 04:34:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:34:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:34:08 --> Encryption Class Initialized
INFO - 2026-01-31 04:34:08 --> Database Driver Class Initialized
INFO - 2026-01-31 04:34:08 --> Form Validation Class Initialized
INFO - 2026-01-31 04:34:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:34:08 --> Pagination Class Initialized
INFO - 2026-01-31 04:34:08 --> Email Class Initialized
INFO - 2026-01-31 04:34:08 --> Controller Class Initialized
ERROR - 2026-01-31 04:34:08 --> 404 Page Not Found: /index
INFO - 2026-01-31 04:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:34:10 --> Upload Class Initialized
DEBUG - 2026-01-31 04:34:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:34:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:34:10 --> Encryption Class Initialized
INFO - 2026-01-31 04:34:10 --> Form Validation Class Initialized
INFO - 2026-01-31 04:34:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:34:10 --> Pagination Class Initialized
INFO - 2026-01-31 04:34:10 --> Email Class Initialized
INFO - 2026-01-31 04:34:10 --> Controller Class Initialized
ERROR - 2026-01-31 04:34:10 --> 404 Page Not Found: /index
INFO - 2026-01-31 04:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:34:10 --> Upload Class Initialized
DEBUG - 2026-01-31 04:34:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:34:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:34:10 --> Encryption Class Initialized
INFO - 2026-01-31 04:34:10 --> Form Validation Class Initialized
INFO - 2026-01-31 04:34:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:34:10 --> Pagination Class Initialized
INFO - 2026-01-31 04:34:10 --> Email Class Initialized
INFO - 2026-01-31 04:34:10 --> Controller Class Initialized
ERROR - 2026-01-31 04:34:10 --> 404 Page Not Found: /index
INFO - 2026-01-31 04:34:38 --> Config Class Initialized
INFO - 2026-01-31 04:34:38 --> Hooks Class Initialized
DEBUG - 2026-01-31 04:34:38 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:34:38 --> Utf8 Class Initialized
INFO - 2026-01-31 04:34:38 --> URI Class Initialized
INFO - 2026-01-31 04:34:38 --> Router Class Initialized
INFO - 2026-01-31 04:34:38 --> Output Class Initialized
INFO - 2026-01-31 04:34:38 --> Security Class Initialized
DEBUG - 2026-01-31 04:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:34:38 --> CSRF cookie sent
INFO - 2026-01-31 04:34:38 --> CSRF token verified
INFO - 2026-01-31 04:34:38 --> Input Class Initialized
INFO - 2026-01-31 04:34:38 --> Language Class Initialized
INFO - 2026-01-31 04:34:38 --> Language Class Initialized
INFO - 2026-01-31 04:34:38 --> Config Class Initialized
INFO - 2026-01-31 04:34:38 --> Loader Class Initialized
INFO - 2026-01-31 04:34:38 --> Helper loaded: url_helper
INFO - 2026-01-31 04:34:38 --> Helper loaded: form_helper
INFO - 2026-01-31 04:34:38 --> Helper loaded: html_helper
INFO - 2026-01-31 04:34:38 --> Helper loaded: file_helper
INFO - 2026-01-31 04:34:38 --> Helper loaded: email_helper
INFO - 2026-01-31 04:34:38 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:34:38 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:34:38 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:34:38 --> Database Driver Class Initialized
INFO - 2026-01-31 04:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:34:39 --> Upload Class Initialized
DEBUG - 2026-01-31 04:34:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:34:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:34:39 --> Encryption Class Initialized
INFO - 2026-01-31 04:34:39 --> Form Validation Class Initialized
INFO - 2026-01-31 04:34:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:34:39 --> Pagination Class Initialized
INFO - 2026-01-31 04:34:39 --> Email Class Initialized
INFO - 2026-01-31 04:34:39 --> Controller Class Initialized
DEBUG - 2026-01-31 04:34:39 --> Auth MX_Controller Initialized
INFO - 2026-01-31 04:34:39 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 04:34:39 --> Model "Auth_model" initialized
INFO - 2026-01-31 04:34:39 --> Model "Cart_model" initialized
INFO - 2026-01-31 04:34:39 --> Model "Appsetting_model" initialized
INFO - 2026-01-31 04:34:41 --> Final output sent to browser
DEBUG - 2026-01-31 04:34:41 --> Total execution time: 2.9414
INFO - 2026-01-31 04:44:19 --> Config Class Initialized
INFO - 2026-01-31 04:44:19 --> Hooks Class Initialized
DEBUG - 2026-01-31 04:44:19 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:44:19 --> Utf8 Class Initialized
INFO - 2026-01-31 04:44:19 --> URI Class Initialized
INFO - 2026-01-31 04:44:19 --> Router Class Initialized
INFO - 2026-01-31 04:44:19 --> Output Class Initialized
INFO - 2026-01-31 04:44:19 --> Security Class Initialized
DEBUG - 2026-01-31 04:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:44:19 --> CSRF cookie sent
INFO - 2026-01-31 04:44:19 --> Input Class Initialized
INFO - 2026-01-31 04:44:19 --> Language Class Initialized
INFO - 2026-01-31 04:44:19 --> Language Class Initialized
INFO - 2026-01-31 04:44:19 --> Config Class Initialized
INFO - 2026-01-31 04:44:19 --> Loader Class Initialized
INFO - 2026-01-31 04:44:19 --> Helper loaded: url_helper
INFO - 2026-01-31 04:44:19 --> Helper loaded: form_helper
INFO - 2026-01-31 04:44:19 --> Helper loaded: html_helper
INFO - 2026-01-31 04:44:19 --> Helper loaded: file_helper
INFO - 2026-01-31 04:44:19 --> Helper loaded: email_helper
INFO - 2026-01-31 04:44:19 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:44:19 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:44:19 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:44:19 --> Database Driver Class Initialized
INFO - 2026-01-31 04:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:44:21 --> Upload Class Initialized
DEBUG - 2026-01-31 04:44:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:44:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:44:21 --> Encryption Class Initialized
INFO - 2026-01-31 04:44:21 --> Form Validation Class Initialized
INFO - 2026-01-31 04:44:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:44:21 --> Pagination Class Initialized
INFO - 2026-01-31 04:44:21 --> Email Class Initialized
INFO - 2026-01-31 04:44:21 --> Controller Class Initialized
DEBUG - 2026-01-31 04:44:21 --> Auth MX_Controller Initialized
INFO - 2026-01-31 04:44:21 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 04:44:21 --> Model "Auth_model" initialized
INFO - 2026-01-31 04:44:21 --> Model "Cart_model" initialized
INFO - 2026-01-31 04:44:21 --> Model "Appsetting_model" initialized
INFO - 2026-01-31 04:44:24 --> Config Class Initialized
INFO - 2026-01-31 04:44:24 --> Hooks Class Initialized
DEBUG - 2026-01-31 04:44:24 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:44:24 --> Utf8 Class Initialized
INFO - 2026-01-31 04:44:24 --> URI Class Initialized
INFO - 2026-01-31 04:44:24 --> Router Class Initialized
INFO - 2026-01-31 04:44:24 --> Output Class Initialized
INFO - 2026-01-31 04:44:24 --> Security Class Initialized
DEBUG - 2026-01-31 04:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:44:24 --> CSRF cookie sent
INFO - 2026-01-31 04:44:24 --> Input Class Initialized
INFO - 2026-01-31 04:44:24 --> Language Class Initialized
INFO - 2026-01-31 04:44:24 --> Language Class Initialized
INFO - 2026-01-31 04:44:24 --> Config Class Initialized
INFO - 2026-01-31 04:44:24 --> Loader Class Initialized
INFO - 2026-01-31 04:44:24 --> Helper loaded: url_helper
INFO - 2026-01-31 04:44:24 --> Helper loaded: form_helper
INFO - 2026-01-31 04:44:24 --> Helper loaded: html_helper
INFO - 2026-01-31 04:44:24 --> Helper loaded: file_helper
INFO - 2026-01-31 04:44:24 --> Helper loaded: email_helper
INFO - 2026-01-31 04:44:24 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:44:24 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:44:24 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:44:24 --> Database Driver Class Initialized
INFO - 2026-01-31 04:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:44:27 --> Upload Class Initialized
DEBUG - 2026-01-31 04:44:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:44:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:44:27 --> Encryption Class Initialized
INFO - 2026-01-31 04:44:27 --> Form Validation Class Initialized
INFO - 2026-01-31 04:44:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:44:27 --> Pagination Class Initialized
INFO - 2026-01-31 04:44:27 --> Email Class Initialized
INFO - 2026-01-31 04:44:27 --> Controller Class Initialized
DEBUG - 2026-01-31 04:44:27 --> Auth MX_Controller Initialized
INFO - 2026-01-31 04:44:27 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 04:44:27 --> Model "Auth_model" initialized
INFO - 2026-01-31 04:44:27 --> Model "Cart_model" initialized
INFO - 2026-01-31 04:44:27 --> Model "Appsetting_model" initialized
DEBUG - 2026-01-31 04:44:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 04:44:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 04:44:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 04:44:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-01-31 04:44:27 --> Final output sent to browser
DEBUG - 2026-01-31 04:44:27 --> Total execution time: 3.3281
INFO - 2026-01-31 04:44:28 --> Config Class Initialized
INFO - 2026-01-31 04:44:28 --> Hooks Class Initialized
INFO - 2026-01-31 04:44:28 --> Config Class Initialized
INFO - 2026-01-31 04:44:28 --> Hooks Class Initialized
DEBUG - 2026-01-31 04:44:28 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:44:28 --> Utf8 Class Initialized
INFO - 2026-01-31 04:44:28 --> URI Class Initialized
DEBUG - 2026-01-31 04:44:28 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:44:28 --> Utf8 Class Initialized
INFO - 2026-01-31 04:44:28 --> Router Class Initialized
INFO - 2026-01-31 04:44:28 --> URI Class Initialized
INFO - 2026-01-31 04:44:28 --> Output Class Initialized
INFO - 2026-01-31 04:44:28 --> Router Class Initialized
INFO - 2026-01-31 04:44:28 --> Security Class Initialized
INFO - 2026-01-31 04:44:28 --> Output Class Initialized
DEBUG - 2026-01-31 04:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:44:28 --> CSRF cookie sent
INFO - 2026-01-31 04:44:28 --> Input Class Initialized
INFO - 2026-01-31 04:44:28 --> Language Class Initialized
INFO - 2026-01-31 04:44:28 --> Language Class Initialized
INFO - 2026-01-31 04:44:28 --> Security Class Initialized
INFO - 2026-01-31 04:44:28 --> Config Class Initialized
DEBUG - 2026-01-31 04:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:44:28 --> CSRF cookie sent
INFO - 2026-01-31 04:44:28 --> Input Class Initialized
INFO - 2026-01-31 04:44:28 --> Language Class Initialized
INFO - 2026-01-31 04:44:28 --> Language Class Initialized
INFO - 2026-01-31 04:44:28 --> Config Class Initialized
INFO - 2026-01-31 04:44:28 --> Loader Class Initialized
INFO - 2026-01-31 04:44:28 --> Helper loaded: url_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: form_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: html_helper
INFO - 2026-01-31 04:44:28 --> Loader Class Initialized
INFO - 2026-01-31 04:44:28 --> Helper loaded: file_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: email_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: url_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: form_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: html_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: file_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: email_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:44:28 --> Database Driver Class Initialized
INFO - 2026-01-31 04:44:28 --> Database Driver Class Initialized
INFO - 2026-01-31 04:44:28 --> Config Class Initialized
INFO - 2026-01-31 04:44:28 --> Hooks Class Initialized
DEBUG - 2026-01-31 04:44:28 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:44:28 --> Utf8 Class Initialized
INFO - 2026-01-31 04:44:28 --> URI Class Initialized
INFO - 2026-01-31 04:44:28 --> Router Class Initialized
INFO - 2026-01-31 04:44:28 --> Output Class Initialized
INFO - 2026-01-31 04:44:28 --> Security Class Initialized
DEBUG - 2026-01-31 04:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:44:28 --> CSRF cookie sent
INFO - 2026-01-31 04:44:28 --> Input Class Initialized
INFO - 2026-01-31 04:44:28 --> Language Class Initialized
INFO - 2026-01-31 04:44:28 --> Language Class Initialized
INFO - 2026-01-31 04:44:28 --> Config Class Initialized
INFO - 2026-01-31 04:44:28 --> Loader Class Initialized
INFO - 2026-01-31 04:44:28 --> Helper loaded: url_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: form_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: html_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: file_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: email_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:44:28 --> Database Driver Class Initialized
INFO - 2026-01-31 04:44:28 --> Config Class Initialized
INFO - 2026-01-31 04:44:28 --> Hooks Class Initialized
INFO - 2026-01-31 04:44:28 --> Config Class Initialized
INFO - 2026-01-31 04:44:28 --> Hooks Class Initialized
DEBUG - 2026-01-31 04:44:28 --> UTF-8 Support Enabled
DEBUG - 2026-01-31 04:44:28 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:44:28 --> Utf8 Class Initialized
INFO - 2026-01-31 04:44:28 --> Utf8 Class Initialized
INFO - 2026-01-31 04:44:28 --> URI Class Initialized
INFO - 2026-01-31 04:44:28 --> URI Class Initialized
INFO - 2026-01-31 04:44:28 --> Router Class Initialized
INFO - 2026-01-31 04:44:28 --> Router Class Initialized
INFO - 2026-01-31 04:44:28 --> Output Class Initialized
INFO - 2026-01-31 04:44:28 --> Output Class Initialized
INFO - 2026-01-31 04:44:28 --> Security Class Initialized
INFO - 2026-01-31 04:44:28 --> Security Class Initialized
DEBUG - 2026-01-31 04:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-01-31 04:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:44:28 --> CSRF cookie sent
INFO - 2026-01-31 04:44:28 --> Input Class Initialized
INFO - 2026-01-31 04:44:28 --> CSRF cookie sent
INFO - 2026-01-31 04:44:28 --> Input Class Initialized
INFO - 2026-01-31 04:44:28 --> Language Class Initialized
INFO - 2026-01-31 04:44:28 --> Language Class Initialized
INFO - 2026-01-31 04:44:28 --> Language Class Initialized
INFO - 2026-01-31 04:44:28 --> Language Class Initialized
INFO - 2026-01-31 04:44:28 --> Config Class Initialized
INFO - 2026-01-31 04:44:28 --> Config Class Initialized
INFO - 2026-01-31 04:44:28 --> Loader Class Initialized
INFO - 2026-01-31 04:44:28 --> Loader Class Initialized
INFO - 2026-01-31 04:44:28 --> Helper loaded: url_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: url_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: form_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: form_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: html_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: html_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: file_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: email_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: file_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: email_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:44:28 --> Database Driver Class Initialized
INFO - 2026-01-31 04:44:28 --> Config Class Initialized
INFO - 2026-01-31 04:44:28 --> Hooks Class Initialized
INFO - 2026-01-31 04:44:28 --> Database Driver Class Initialized
DEBUG - 2026-01-31 04:44:28 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:44:28 --> Utf8 Class Initialized
INFO - 2026-01-31 04:44:28 --> URI Class Initialized
INFO - 2026-01-31 04:44:28 --> Router Class Initialized
INFO - 2026-01-31 04:44:28 --> Output Class Initialized
INFO - 2026-01-31 04:44:28 --> Security Class Initialized
DEBUG - 2026-01-31 04:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:44:28 --> CSRF cookie sent
INFO - 2026-01-31 04:44:28 --> Input Class Initialized
INFO - 2026-01-31 04:44:28 --> Language Class Initialized
INFO - 2026-01-31 04:44:28 --> Language Class Initialized
INFO - 2026-01-31 04:44:28 --> Config Class Initialized
INFO - 2026-01-31 04:44:28 --> Loader Class Initialized
INFO - 2026-01-31 04:44:28 --> Helper loaded: url_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: form_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: html_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: file_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: email_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:44:28 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:44:28 --> Database Driver Class Initialized
INFO - 2026-01-31 04:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:44:29 --> Upload Class Initialized
DEBUG - 2026-01-31 04:44:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:44:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:44:29 --> Encryption Class Initialized
INFO - 2026-01-31 04:44:29 --> Form Validation Class Initialized
INFO - 2026-01-31 04:44:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:44:29 --> Pagination Class Initialized
INFO - 2026-01-31 04:44:29 --> Email Class Initialized
INFO - 2026-01-31 04:44:29 --> Controller Class Initialized
ERROR - 2026-01-31 04:44:29 --> 404 Page Not Found: /index
INFO - 2026-01-31 04:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:44:29 --> Upload Class Initialized
DEBUG - 2026-01-31 04:44:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:44:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:44:29 --> Encryption Class Initialized
INFO - 2026-01-31 04:44:29 --> Form Validation Class Initialized
INFO - 2026-01-31 04:44:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:44:29 --> Pagination Class Initialized
INFO - 2026-01-31 04:44:29 --> Config Class Initialized
INFO - 2026-01-31 04:44:29 --> Hooks Class Initialized
INFO - 2026-01-31 04:44:29 --> Email Class Initialized
INFO - 2026-01-31 04:44:29 --> Controller Class Initialized
ERROR - 2026-01-31 04:44:29 --> 404 Page Not Found: /index
INFO - 2026-01-31 04:44:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-01-31 04:44:29 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:44:29 --> Utf8 Class Initialized
INFO - 2026-01-31 04:44:29 --> URI Class Initialized
INFO - 2026-01-31 04:44:29 --> Upload Class Initialized
INFO - 2026-01-31 04:44:29 --> Router Class Initialized
DEBUG - 2026-01-31 04:44:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:44:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:44:29 --> Encryption Class Initialized
INFO - 2026-01-31 04:44:29 --> Output Class Initialized
INFO - 2026-01-31 04:44:29 --> Form Validation Class Initialized
INFO - 2026-01-31 04:44:29 --> Security Class Initialized
INFO - 2026-01-31 04:44:29 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2026-01-31 04:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:44:29 --> Pagination Class Initialized
INFO - 2026-01-31 04:44:29 --> CSRF cookie sent
INFO - 2026-01-31 04:44:29 --> Input Class Initialized
INFO - 2026-01-31 04:44:29 --> Language Class Initialized
INFO - 2026-01-31 04:44:29 --> Language Class Initialized
INFO - 2026-01-31 04:44:29 --> Config Class Initialized
INFO - 2026-01-31 04:44:29 --> Config Class Initialized
INFO - 2026-01-31 04:44:29 --> Hooks Class Initialized
INFO - 2026-01-31 04:44:29 --> Email Class Initialized
INFO - 2026-01-31 04:44:29 --> Controller Class Initialized
INFO - 2026-01-31 04:44:29 --> Loader Class Initialized
ERROR - 2026-01-31 04:44:29 --> 404 Page Not Found: /index
DEBUG - 2026-01-31 04:44:29 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:44:29 --> Utf8 Class Initialized
INFO - 2026-01-31 04:44:29 --> URI Class Initialized
INFO - 2026-01-31 04:44:29 --> Helper loaded: url_helper
INFO - 2026-01-31 04:44:29 --> Helper loaded: form_helper
INFO - 2026-01-31 04:44:29 --> Router Class Initialized
INFO - 2026-01-31 04:44:29 --> Helper loaded: html_helper
INFO - 2026-01-31 04:44:29 --> Helper loaded: file_helper
INFO - 2026-01-31 04:44:29 --> Output Class Initialized
INFO - 2026-01-31 04:44:29 --> Helper loaded: email_helper
INFO - 2026-01-31 04:44:29 --> Security Class Initialized
INFO - 2026-01-31 04:44:29 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:44:29 --> Helper loaded: ssp_helper
DEBUG - 2026-01-31 04:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:44:29 --> CSRF cookie sent
INFO - 2026-01-31 04:44:29 --> Input Class Initialized
INFO - 2026-01-31 04:44:29 --> Language Class Initialized
INFO - 2026-01-31 04:44:29 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:44:29 --> Language Class Initialized
INFO - 2026-01-31 04:44:29 --> Config Class Initialized
INFO - 2026-01-31 04:44:29 --> Loader Class Initialized
INFO - 2026-01-31 04:44:29 --> Helper loaded: url_helper
INFO - 2026-01-31 04:44:29 --> Helper loaded: form_helper
INFO - 2026-01-31 04:44:29 --> Helper loaded: html_helper
INFO - 2026-01-31 04:44:29 --> Database Driver Class Initialized
INFO - 2026-01-31 04:44:29 --> Helper loaded: file_helper
INFO - 2026-01-31 04:44:29 --> Helper loaded: email_helper
INFO - 2026-01-31 04:44:29 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:44:29 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:44:29 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:44:29 --> Database Driver Class Initialized
INFO - 2026-01-31 04:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:44:30 --> Upload Class Initialized
DEBUG - 2026-01-31 04:44:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:44:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:44:30 --> Encryption Class Initialized
INFO - 2026-01-31 04:44:30 --> Form Validation Class Initialized
INFO - 2026-01-31 04:44:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:44:30 --> Pagination Class Initialized
INFO - 2026-01-31 04:44:30 --> Email Class Initialized
INFO - 2026-01-31 04:44:30 --> Controller Class Initialized
ERROR - 2026-01-31 04:44:30 --> 404 Page Not Found: /index
INFO - 2026-01-31 04:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:44:31 --> Upload Class Initialized
DEBUG - 2026-01-31 04:44:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:44:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:44:31 --> Encryption Class Initialized
INFO - 2026-01-31 04:44:31 --> Form Validation Class Initialized
INFO - 2026-01-31 04:44:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:44:31 --> Pagination Class Initialized
INFO - 2026-01-31 04:44:31 --> Email Class Initialized
INFO - 2026-01-31 04:44:31 --> Controller Class Initialized
ERROR - 2026-01-31 04:44:31 --> 404 Page Not Found: /index
INFO - 2026-01-31 04:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:44:32 --> Upload Class Initialized
DEBUG - 2026-01-31 04:44:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:44:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:44:32 --> Encryption Class Initialized
INFO - 2026-01-31 04:44:32 --> Form Validation Class Initialized
INFO - 2026-01-31 04:44:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:44:32 --> Pagination Class Initialized
INFO - 2026-01-31 04:44:32 --> Email Class Initialized
INFO - 2026-01-31 04:44:32 --> Controller Class Initialized
ERROR - 2026-01-31 04:44:32 --> 404 Page Not Found: /index
INFO - 2026-01-31 04:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:44:33 --> Upload Class Initialized
DEBUG - 2026-01-31 04:44:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:44:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:44:33 --> Encryption Class Initialized
INFO - 2026-01-31 04:44:33 --> Form Validation Class Initialized
INFO - 2026-01-31 04:44:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:44:33 --> Pagination Class Initialized
INFO - 2026-01-31 04:44:33 --> Email Class Initialized
INFO - 2026-01-31 04:44:33 --> Controller Class Initialized
ERROR - 2026-01-31 04:44:33 --> 404 Page Not Found: /index
INFO - 2026-01-31 04:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:44:33 --> Upload Class Initialized
DEBUG - 2026-01-31 04:44:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:44:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:44:33 --> Encryption Class Initialized
INFO - 2026-01-31 04:44:33 --> Form Validation Class Initialized
INFO - 2026-01-31 04:44:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:44:33 --> Pagination Class Initialized
INFO - 2026-01-31 04:44:33 --> Email Class Initialized
INFO - 2026-01-31 04:44:33 --> Controller Class Initialized
ERROR - 2026-01-31 04:44:33 --> 404 Page Not Found: /index
INFO - 2026-01-31 04:45:23 --> Config Class Initialized
INFO - 2026-01-31 04:45:23 --> Hooks Class Initialized
DEBUG - 2026-01-31 04:45:23 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:45:23 --> Utf8 Class Initialized
INFO - 2026-01-31 04:45:23 --> URI Class Initialized
INFO - 2026-01-31 04:45:23 --> Router Class Initialized
INFO - 2026-01-31 04:45:23 --> Output Class Initialized
INFO - 2026-01-31 04:45:23 --> Security Class Initialized
DEBUG - 2026-01-31 04:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:45:23 --> CSRF cookie sent
INFO - 2026-01-31 04:45:23 --> Input Class Initialized
INFO - 2026-01-31 04:45:23 --> Language Class Initialized
INFO - 2026-01-31 04:45:23 --> Language Class Initialized
INFO - 2026-01-31 04:45:23 --> Config Class Initialized
INFO - 2026-01-31 04:45:23 --> Loader Class Initialized
INFO - 2026-01-31 04:45:23 --> Helper loaded: url_helper
INFO - 2026-01-31 04:45:23 --> Helper loaded: form_helper
INFO - 2026-01-31 04:45:23 --> Helper loaded: html_helper
INFO - 2026-01-31 04:45:23 --> Helper loaded: file_helper
INFO - 2026-01-31 04:45:23 --> Helper loaded: email_helper
INFO - 2026-01-31 04:45:23 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:45:23 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:45:23 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:45:23 --> Database Driver Class Initialized
INFO - 2026-01-31 04:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:45:25 --> Upload Class Initialized
DEBUG - 2026-01-31 04:45:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:45:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:45:25 --> Encryption Class Initialized
INFO - 2026-01-31 04:45:25 --> Form Validation Class Initialized
INFO - 2026-01-31 04:45:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:45:25 --> Pagination Class Initialized
INFO - 2026-01-31 04:45:25 --> Email Class Initialized
INFO - 2026-01-31 04:45:25 --> Controller Class Initialized
DEBUG - 2026-01-31 04:45:25 --> Auth MX_Controller Initialized
INFO - 2026-01-31 04:45:25 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 04:45:25 --> Model "Auth_model" initialized
INFO - 2026-01-31 04:45:25 --> Model "Cart_model" initialized
INFO - 2026-01-31 04:45:25 --> Model "Appsetting_model" initialized
INFO - 2026-01-31 04:45:25 --> Config Class Initialized
INFO - 2026-01-31 04:45:25 --> Hooks Class Initialized
DEBUG - 2026-01-31 04:45:25 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:45:25 --> Utf8 Class Initialized
INFO - 2026-01-31 04:45:25 --> URI Class Initialized
INFO - 2026-01-31 04:45:25 --> Router Class Initialized
INFO - 2026-01-31 04:45:25 --> Output Class Initialized
INFO - 2026-01-31 04:45:25 --> Security Class Initialized
DEBUG - 2026-01-31 04:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:45:25 --> CSRF cookie sent
INFO - 2026-01-31 04:45:25 --> Input Class Initialized
INFO - 2026-01-31 04:45:25 --> Language Class Initialized
INFO - 2026-01-31 04:45:25 --> Language Class Initialized
INFO - 2026-01-31 04:45:25 --> Config Class Initialized
INFO - 2026-01-31 04:45:25 --> Loader Class Initialized
INFO - 2026-01-31 04:45:25 --> Helper loaded: url_helper
INFO - 2026-01-31 04:45:25 --> Helper loaded: form_helper
INFO - 2026-01-31 04:45:25 --> Helper loaded: html_helper
INFO - 2026-01-31 04:45:25 --> Helper loaded: file_helper
INFO - 2026-01-31 04:45:25 --> Helper loaded: email_helper
INFO - 2026-01-31 04:45:25 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:45:25 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:45:25 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:45:25 --> Database Driver Class Initialized
INFO - 2026-01-31 04:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:45:27 --> Upload Class Initialized
DEBUG - 2026-01-31 04:45:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:45:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:45:27 --> Encryption Class Initialized
INFO - 2026-01-31 04:45:27 --> Form Validation Class Initialized
INFO - 2026-01-31 04:45:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:45:27 --> Pagination Class Initialized
INFO - 2026-01-31 04:45:27 --> Email Class Initialized
INFO - 2026-01-31 04:45:27 --> Controller Class Initialized
DEBUG - 2026-01-31 04:45:27 --> Auth MX_Controller Initialized
INFO - 2026-01-31 04:45:27 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 04:45:27 --> Model "Auth_model" initialized
INFO - 2026-01-31 04:45:27 --> Model "Cart_model" initialized
INFO - 2026-01-31 04:45:27 --> Model "Appsetting_model" initialized
DEBUG - 2026-01-31 04:45:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 04:45:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 04:45:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 04:45:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-01-31 04:45:27 --> Final output sent to browser
DEBUG - 2026-01-31 04:45:27 --> Total execution time: 2.4504
INFO - 2026-01-31 04:45:44 --> Config Class Initialized
INFO - 2026-01-31 04:45:44 --> Hooks Class Initialized
DEBUG - 2026-01-31 04:45:44 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:45:44 --> Utf8 Class Initialized
INFO - 2026-01-31 04:45:44 --> URI Class Initialized
INFO - 2026-01-31 04:45:44 --> Router Class Initialized
INFO - 2026-01-31 04:45:44 --> Output Class Initialized
INFO - 2026-01-31 04:45:44 --> Security Class Initialized
DEBUG - 2026-01-31 04:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:45:44 --> CSRF cookie sent
INFO - 2026-01-31 04:45:44 --> Input Class Initialized
INFO - 2026-01-31 04:45:44 --> Language Class Initialized
INFO - 2026-01-31 04:45:44 --> Language Class Initialized
INFO - 2026-01-31 04:45:44 --> Config Class Initialized
INFO - 2026-01-31 04:45:44 --> Loader Class Initialized
INFO - 2026-01-31 04:45:44 --> Helper loaded: url_helper
INFO - 2026-01-31 04:45:44 --> Helper loaded: form_helper
INFO - 2026-01-31 04:45:44 --> Helper loaded: html_helper
INFO - 2026-01-31 04:45:44 --> Helper loaded: file_helper
INFO - 2026-01-31 04:45:44 --> Helper loaded: email_helper
INFO - 2026-01-31 04:45:44 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:45:44 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:45:44 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:45:44 --> Database Driver Class Initialized
INFO - 2026-01-31 04:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:45:46 --> Upload Class Initialized
DEBUG - 2026-01-31 04:45:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:45:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:45:46 --> Encryption Class Initialized
INFO - 2026-01-31 04:45:46 --> Form Validation Class Initialized
INFO - 2026-01-31 04:45:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:45:46 --> Pagination Class Initialized
INFO - 2026-01-31 04:45:46 --> Email Class Initialized
INFO - 2026-01-31 04:45:46 --> Controller Class Initialized
DEBUG - 2026-01-31 04:45:46 --> Auth MX_Controller Initialized
INFO - 2026-01-31 04:45:46 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 04:45:46 --> Model "Auth_model" initialized
INFO - 2026-01-31 04:45:46 --> Model "Cart_model" initialized
INFO - 2026-01-31 04:45:46 --> Model "Appsetting_model" initialized
INFO - 2026-01-31 04:45:47 --> Config Class Initialized
INFO - 2026-01-31 04:45:47 --> Hooks Class Initialized
DEBUG - 2026-01-31 04:45:47 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:45:47 --> Utf8 Class Initialized
INFO - 2026-01-31 04:45:47 --> URI Class Initialized
INFO - 2026-01-31 04:45:47 --> Router Class Initialized
INFO - 2026-01-31 04:45:47 --> Output Class Initialized
INFO - 2026-01-31 04:45:47 --> Security Class Initialized
DEBUG - 2026-01-31 04:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:45:47 --> CSRF cookie sent
INFO - 2026-01-31 04:45:47 --> Input Class Initialized
INFO - 2026-01-31 04:45:47 --> Language Class Initialized
INFO - 2026-01-31 04:45:47 --> Language Class Initialized
INFO - 2026-01-31 04:45:47 --> Config Class Initialized
INFO - 2026-01-31 04:45:47 --> Loader Class Initialized
INFO - 2026-01-31 04:45:47 --> Helper loaded: url_helper
INFO - 2026-01-31 04:45:47 --> Helper loaded: form_helper
INFO - 2026-01-31 04:45:47 --> Helper loaded: html_helper
INFO - 2026-01-31 04:45:47 --> Helper loaded: file_helper
INFO - 2026-01-31 04:45:47 --> Helper loaded: email_helper
INFO - 2026-01-31 04:45:47 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:45:47 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:45:47 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:45:47 --> Database Driver Class Initialized
INFO - 2026-01-31 04:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:45:48 --> Upload Class Initialized
DEBUG - 2026-01-31 04:45:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:45:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:45:48 --> Encryption Class Initialized
INFO - 2026-01-31 04:45:48 --> Form Validation Class Initialized
INFO - 2026-01-31 04:45:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:45:48 --> Pagination Class Initialized
INFO - 2026-01-31 04:45:48 --> Email Class Initialized
INFO - 2026-01-31 04:45:48 --> Controller Class Initialized
DEBUG - 2026-01-31 04:45:48 --> Auth MX_Controller Initialized
INFO - 2026-01-31 04:45:48 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 04:45:48 --> Model "Auth_model" initialized
INFO - 2026-01-31 04:45:48 --> Model "Cart_model" initialized
INFO - 2026-01-31 04:45:48 --> Model "Appsetting_model" initialized
DEBUG - 2026-01-31 04:45:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 04:45:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 04:45:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 04:45:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-01-31 04:45:49 --> Final output sent to browser
DEBUG - 2026-01-31 04:45:49 --> Total execution time: 2.2491
INFO - 2026-01-31 04:47:52 --> Config Class Initialized
INFO - 2026-01-31 04:47:52 --> Hooks Class Initialized
DEBUG - 2026-01-31 04:47:52 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:47:52 --> Utf8 Class Initialized
INFO - 2026-01-31 04:47:52 --> URI Class Initialized
INFO - 2026-01-31 04:47:52 --> Router Class Initialized
INFO - 2026-01-31 04:47:52 --> Output Class Initialized
INFO - 2026-01-31 04:47:52 --> Security Class Initialized
DEBUG - 2026-01-31 04:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:47:52 --> CSRF cookie sent
INFO - 2026-01-31 04:47:52 --> Input Class Initialized
INFO - 2026-01-31 04:47:52 --> Language Class Initialized
INFO - 2026-01-31 04:47:52 --> Language Class Initialized
INFO - 2026-01-31 04:47:52 --> Config Class Initialized
INFO - 2026-01-31 04:47:52 --> Loader Class Initialized
INFO - 2026-01-31 04:47:52 --> Helper loaded: url_helper
INFO - 2026-01-31 04:47:52 --> Helper loaded: form_helper
INFO - 2026-01-31 04:47:52 --> Helper loaded: html_helper
INFO - 2026-01-31 04:47:52 --> Helper loaded: file_helper
INFO - 2026-01-31 04:47:52 --> Helper loaded: email_helper
INFO - 2026-01-31 04:47:52 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:47:52 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:47:52 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:47:52 --> Database Driver Class Initialized
INFO - 2026-01-31 04:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:47:54 --> Upload Class Initialized
DEBUG - 2026-01-31 04:47:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:47:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:47:54 --> Encryption Class Initialized
INFO - 2026-01-31 04:47:54 --> Form Validation Class Initialized
INFO - 2026-01-31 04:47:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:47:54 --> Pagination Class Initialized
INFO - 2026-01-31 04:47:54 --> Email Class Initialized
INFO - 2026-01-31 04:47:54 --> Controller Class Initialized
DEBUG - 2026-01-31 04:47:54 --> Dashboard MX_Controller Initialized
INFO - 2026-01-31 04:47:54 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 04:47:54 --> Model "Adminauth_model" initialized
INFO - 2026-01-31 04:48:02 --> Config Class Initialized
INFO - 2026-01-31 04:48:02 --> Hooks Class Initialized
DEBUG - 2026-01-31 04:48:02 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:48:02 --> Utf8 Class Initialized
INFO - 2026-01-31 04:48:02 --> URI Class Initialized
INFO - 2026-01-31 04:48:02 --> Router Class Initialized
INFO - 2026-01-31 04:48:02 --> Output Class Initialized
INFO - 2026-01-31 04:48:02 --> Security Class Initialized
DEBUG - 2026-01-31 04:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:48:02 --> CSRF cookie sent
INFO - 2026-01-31 04:48:02 --> Input Class Initialized
INFO - 2026-01-31 04:48:02 --> Language Class Initialized
INFO - 2026-01-31 04:48:02 --> Language Class Initialized
INFO - 2026-01-31 04:48:02 --> Config Class Initialized
INFO - 2026-01-31 04:48:02 --> Loader Class Initialized
INFO - 2026-01-31 04:48:02 --> Helper loaded: url_helper
INFO - 2026-01-31 04:48:02 --> Helper loaded: form_helper
INFO - 2026-01-31 04:48:02 --> Helper loaded: html_helper
INFO - 2026-01-31 04:48:02 --> Helper loaded: file_helper
INFO - 2026-01-31 04:48:02 --> Helper loaded: email_helper
INFO - 2026-01-31 04:48:02 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:48:02 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:48:02 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:48:02 --> Database Driver Class Initialized
INFO - 2026-01-31 04:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:48:03 --> Upload Class Initialized
DEBUG - 2026-01-31 04:48:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:48:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:48:03 --> Encryption Class Initialized
INFO - 2026-01-31 04:48:03 --> Form Validation Class Initialized
INFO - 2026-01-31 04:48:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:48:03 --> Pagination Class Initialized
INFO - 2026-01-31 04:48:03 --> Email Class Initialized
INFO - 2026-01-31 04:48:03 --> Controller Class Initialized
DEBUG - 2026-01-31 04:48:03 --> Dashboard MX_Controller Initialized
INFO - 2026-01-31 04:48:03 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 04:48:03 --> Model "Adminauth_model" initialized
INFO - 2026-01-31 04:49:06 --> Config Class Initialized
INFO - 2026-01-31 04:49:06 --> Hooks Class Initialized
DEBUG - 2026-01-31 04:49:06 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:49:06 --> Utf8 Class Initialized
INFO - 2026-01-31 04:49:06 --> URI Class Initialized
INFO - 2026-01-31 04:49:06 --> Router Class Initialized
INFO - 2026-01-31 04:49:06 --> Output Class Initialized
INFO - 2026-01-31 04:49:06 --> Security Class Initialized
DEBUG - 2026-01-31 04:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:49:06 --> CSRF cookie sent
INFO - 2026-01-31 04:49:06 --> Input Class Initialized
INFO - 2026-01-31 04:49:06 --> Language Class Initialized
INFO - 2026-01-31 04:49:06 --> Language Class Initialized
INFO - 2026-01-31 04:49:06 --> Config Class Initialized
INFO - 2026-01-31 04:49:06 --> Loader Class Initialized
INFO - 2026-01-31 04:49:06 --> Helper loaded: url_helper
INFO - 2026-01-31 04:49:06 --> Helper loaded: form_helper
INFO - 2026-01-31 04:49:06 --> Helper loaded: html_helper
INFO - 2026-01-31 04:49:06 --> Helper loaded: file_helper
INFO - 2026-01-31 04:49:06 --> Helper loaded: email_helper
INFO - 2026-01-31 04:49:06 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:49:06 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:49:06 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:49:06 --> Database Driver Class Initialized
INFO - 2026-01-31 04:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:49:08 --> Upload Class Initialized
DEBUG - 2026-01-31 04:49:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:49:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:49:08 --> Encryption Class Initialized
INFO - 2026-01-31 04:49:08 --> Form Validation Class Initialized
INFO - 2026-01-31 04:49:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:49:08 --> Pagination Class Initialized
INFO - 2026-01-31 04:49:08 --> Email Class Initialized
INFO - 2026-01-31 04:49:08 --> Controller Class Initialized
DEBUG - 2026-01-31 04:49:08 --> Auth MX_Controller Initialized
INFO - 2026-01-31 04:49:08 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 04:49:08 --> Model "Auth_model" initialized
INFO - 2026-01-31 04:49:08 --> Model "Cart_model" initialized
INFO - 2026-01-31 04:49:08 --> Model "Appsetting_model" initialized
DEBUG - 2026-01-31 04:49:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 04:49:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 04:49:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 04:49:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_forgetpass.php
INFO - 2026-01-31 04:49:08 --> Final output sent to browser
DEBUG - 2026-01-31 04:49:08 --> Total execution time: 2.2780
INFO - 2026-01-31 04:49:13 --> Config Class Initialized
INFO - 2026-01-31 04:49:13 --> Hooks Class Initialized
DEBUG - 2026-01-31 04:49:13 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:49:13 --> Utf8 Class Initialized
INFO - 2026-01-31 04:49:13 --> URI Class Initialized
INFO - 2026-01-31 04:49:13 --> Router Class Initialized
INFO - 2026-01-31 04:49:13 --> Output Class Initialized
INFO - 2026-01-31 04:49:13 --> Security Class Initialized
DEBUG - 2026-01-31 04:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:49:13 --> CSRF cookie sent
INFO - 2026-01-31 04:49:13 --> CSRF token verified
INFO - 2026-01-31 04:49:13 --> Input Class Initialized
INFO - 2026-01-31 04:49:13 --> Language Class Initialized
INFO - 2026-01-31 04:49:13 --> Language Class Initialized
INFO - 2026-01-31 04:49:13 --> Config Class Initialized
INFO - 2026-01-31 04:49:13 --> Loader Class Initialized
INFO - 2026-01-31 04:49:13 --> Helper loaded: url_helper
INFO - 2026-01-31 04:49:13 --> Helper loaded: form_helper
INFO - 2026-01-31 04:49:13 --> Helper loaded: html_helper
INFO - 2026-01-31 04:49:13 --> Helper loaded: file_helper
INFO - 2026-01-31 04:49:13 --> Helper loaded: email_helper
INFO - 2026-01-31 04:49:13 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:49:13 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:49:13 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:49:13 --> Database Driver Class Initialized
INFO - 2026-01-31 04:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:49:15 --> Upload Class Initialized
DEBUG - 2026-01-31 04:49:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:49:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:49:15 --> Encryption Class Initialized
INFO - 2026-01-31 04:49:15 --> Form Validation Class Initialized
INFO - 2026-01-31 04:49:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:49:15 --> Pagination Class Initialized
INFO - 2026-01-31 04:49:15 --> Email Class Initialized
INFO - 2026-01-31 04:49:15 --> Controller Class Initialized
DEBUG - 2026-01-31 04:49:15 --> Auth MX_Controller Initialized
INFO - 2026-01-31 04:49:15 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 04:49:15 --> Model "Auth_model" initialized
INFO - 2026-01-31 04:49:15 --> Model "Cart_model" initialized
INFO - 2026-01-31 04:49:15 --> Model "Appsetting_model" initialized
INFO - 2026-01-31 04:49:18 --> Language file loaded: language/english/email_lang.php
DEBUG - 2026-01-31 04:49:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 04:49:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 04:49:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 04:49:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_forgetpass.php
INFO - 2026-01-31 04:49:24 --> Final output sent to browser
DEBUG - 2026-01-31 04:49:24 --> Total execution time: 10.7805
INFO - 2026-01-31 04:49:35 --> Config Class Initialized
INFO - 2026-01-31 04:49:35 --> Hooks Class Initialized
DEBUG - 2026-01-31 04:49:35 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:49:35 --> Utf8 Class Initialized
INFO - 2026-01-31 04:49:35 --> URI Class Initialized
INFO - 2026-01-31 04:49:35 --> Router Class Initialized
INFO - 2026-01-31 04:49:35 --> Output Class Initialized
INFO - 2026-01-31 04:49:35 --> Security Class Initialized
DEBUG - 2026-01-31 04:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:49:35 --> CSRF cookie sent
INFO - 2026-01-31 04:49:35 --> Input Class Initialized
INFO - 2026-01-31 04:49:35 --> Language Class Initialized
INFO - 2026-01-31 04:49:35 --> Language Class Initialized
INFO - 2026-01-31 04:49:35 --> Config Class Initialized
INFO - 2026-01-31 04:49:35 --> Loader Class Initialized
INFO - 2026-01-31 04:49:35 --> Helper loaded: url_helper
INFO - 2026-01-31 04:49:35 --> Helper loaded: form_helper
INFO - 2026-01-31 04:49:35 --> Helper loaded: html_helper
INFO - 2026-01-31 04:49:35 --> Helper loaded: file_helper
INFO - 2026-01-31 04:49:35 --> Helper loaded: email_helper
INFO - 2026-01-31 04:49:35 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:49:35 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:49:35 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:49:35 --> Database Driver Class Initialized
INFO - 2026-01-31 04:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:49:37 --> Upload Class Initialized
DEBUG - 2026-01-31 04:49:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:49:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:49:37 --> Encryption Class Initialized
INFO - 2026-01-31 04:49:37 --> Form Validation Class Initialized
INFO - 2026-01-31 04:49:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:49:37 --> Pagination Class Initialized
INFO - 2026-01-31 04:49:37 --> Email Class Initialized
INFO - 2026-01-31 04:49:37 --> Controller Class Initialized
DEBUG - 2026-01-31 04:49:37 --> Auth MX_Controller Initialized
INFO - 2026-01-31 04:49:37 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 04:49:37 --> Model "Auth_model" initialized
INFO - 2026-01-31 04:49:37 --> Model "Cart_model" initialized
INFO - 2026-01-31 04:49:37 --> Model "Appsetting_model" initialized
INFO - 2026-01-31 04:49:37 --> Config Class Initialized
INFO - 2026-01-31 04:49:37 --> Hooks Class Initialized
DEBUG - 2026-01-31 04:49:37 --> UTF-8 Support Enabled
INFO - 2026-01-31 04:49:37 --> Utf8 Class Initialized
INFO - 2026-01-31 04:49:37 --> URI Class Initialized
INFO - 2026-01-31 04:49:37 --> Router Class Initialized
INFO - 2026-01-31 04:49:37 --> Output Class Initialized
INFO - 2026-01-31 04:49:37 --> Security Class Initialized
DEBUG - 2026-01-31 04:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 04:49:37 --> CSRF cookie sent
INFO - 2026-01-31 04:49:37 --> Input Class Initialized
INFO - 2026-01-31 04:49:37 --> Language Class Initialized
INFO - 2026-01-31 04:49:37 --> Language Class Initialized
INFO - 2026-01-31 04:49:37 --> Config Class Initialized
INFO - 2026-01-31 04:49:37 --> Loader Class Initialized
INFO - 2026-01-31 04:49:37 --> Helper loaded: url_helper
INFO - 2026-01-31 04:49:37 --> Helper loaded: form_helper
INFO - 2026-01-31 04:49:37 --> Helper loaded: html_helper
INFO - 2026-01-31 04:49:37 --> Helper loaded: file_helper
INFO - 2026-01-31 04:49:37 --> Helper loaded: email_helper
INFO - 2026-01-31 04:49:37 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 04:49:37 --> Helper loaded: ssp_helper
INFO - 2026-01-31 04:49:37 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 04:49:37 --> Database Driver Class Initialized
INFO - 2026-01-31 04:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 04:49:39 --> Upload Class Initialized
DEBUG - 2026-01-31 04:49:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 04:49:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 04:49:39 --> Encryption Class Initialized
INFO - 2026-01-31 04:49:39 --> Form Validation Class Initialized
INFO - 2026-01-31 04:49:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 04:49:39 --> Pagination Class Initialized
INFO - 2026-01-31 04:49:39 --> Email Class Initialized
INFO - 2026-01-31 04:49:39 --> Controller Class Initialized
DEBUG - 2026-01-31 04:49:39 --> Auth MX_Controller Initialized
INFO - 2026-01-31 04:49:39 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 04:49:39 --> Model "Auth_model" initialized
INFO - 2026-01-31 04:49:39 --> Model "Cart_model" initialized
INFO - 2026-01-31 04:49:39 --> Model "Appsetting_model" initialized
DEBUG - 2026-01-31 04:49:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 04:49:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 04:49:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 04:49:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-01-31 04:49:40 --> Final output sent to browser
DEBUG - 2026-01-31 04:49:40 --> Total execution time: 2.3261
INFO - 2026-01-31 05:04:31 --> Config Class Initialized
INFO - 2026-01-31 05:04:31 --> Hooks Class Initialized
DEBUG - 2026-01-31 05:04:31 --> UTF-8 Support Enabled
INFO - 2026-01-31 05:04:31 --> Utf8 Class Initialized
INFO - 2026-01-31 05:04:31 --> URI Class Initialized
INFO - 2026-01-31 05:04:31 --> Router Class Initialized
INFO - 2026-01-31 05:04:31 --> Output Class Initialized
INFO - 2026-01-31 05:04:31 --> Security Class Initialized
DEBUG - 2026-01-31 05:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 05:04:31 --> CSRF cookie sent
INFO - 2026-01-31 05:04:31 --> Input Class Initialized
INFO - 2026-01-31 05:04:31 --> Language Class Initialized
INFO - 2026-01-31 05:04:31 --> Language Class Initialized
INFO - 2026-01-31 05:04:31 --> Config Class Initialized
INFO - 2026-01-31 05:04:31 --> Loader Class Initialized
INFO - 2026-01-31 05:04:31 --> Helper loaded: url_helper
INFO - 2026-01-31 05:04:31 --> Helper loaded: form_helper
INFO - 2026-01-31 05:04:31 --> Helper loaded: html_helper
INFO - 2026-01-31 05:04:31 --> Helper loaded: file_helper
INFO - 2026-01-31 05:04:31 --> Helper loaded: email_helper
INFO - 2026-01-31 05:04:31 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 05:04:31 --> Helper loaded: ssp_helper
INFO - 2026-01-31 05:04:31 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 05:04:31 --> Database Driver Class Initialized
INFO - 2026-01-31 05:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 05:04:32 --> Upload Class Initialized
DEBUG - 2026-01-31 05:04:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 05:04:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 05:04:32 --> Encryption Class Initialized
INFO - 2026-01-31 05:04:32 --> Form Validation Class Initialized
INFO - 2026-01-31 05:04:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 05:04:32 --> Pagination Class Initialized
INFO - 2026-01-31 05:04:32 --> Email Class Initialized
INFO - 2026-01-31 05:04:32 --> Controller Class Initialized
DEBUG - 2026-01-31 05:04:32 --> Auth MX_Controller Initialized
INFO - 2026-01-31 05:04:32 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 05:04:32 --> Model "Auth_model" initialized
INFO - 2026-01-31 05:04:32 --> Model "Cart_model" initialized
INFO - 2026-01-31 05:04:32 --> Model "Appsetting_model" initialized
DEBUG - 2026-01-31 05:04:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 05:04:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 05:04:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 05:04:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_forgetpass.php
INFO - 2026-01-31 05:04:33 --> Final output sent to browser
DEBUG - 2026-01-31 05:04:33 --> Total execution time: 2.1973
INFO - 2026-01-31 05:04:35 --> Config Class Initialized
INFO - 2026-01-31 05:04:35 --> Hooks Class Initialized
DEBUG - 2026-01-31 05:04:35 --> UTF-8 Support Enabled
INFO - 2026-01-31 05:04:35 --> Utf8 Class Initialized
INFO - 2026-01-31 05:04:35 --> URI Class Initialized
INFO - 2026-01-31 05:04:35 --> Router Class Initialized
INFO - 2026-01-31 05:04:35 --> Output Class Initialized
INFO - 2026-01-31 05:04:35 --> Security Class Initialized
DEBUG - 2026-01-31 05:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 05:04:35 --> CSRF cookie sent
INFO - 2026-01-31 05:04:35 --> CSRF token verified
INFO - 2026-01-31 05:04:35 --> Input Class Initialized
INFO - 2026-01-31 05:04:35 --> Language Class Initialized
INFO - 2026-01-31 05:04:35 --> Language Class Initialized
INFO - 2026-01-31 05:04:35 --> Config Class Initialized
INFO - 2026-01-31 05:04:35 --> Loader Class Initialized
INFO - 2026-01-31 05:04:35 --> Helper loaded: url_helper
INFO - 2026-01-31 05:04:35 --> Helper loaded: form_helper
INFO - 2026-01-31 05:04:35 --> Helper loaded: html_helper
INFO - 2026-01-31 05:04:35 --> Helper loaded: file_helper
INFO - 2026-01-31 05:04:35 --> Helper loaded: email_helper
INFO - 2026-01-31 05:04:35 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 05:04:35 --> Helper loaded: ssp_helper
INFO - 2026-01-31 05:04:35 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 05:04:35 --> Database Driver Class Initialized
INFO - 2026-01-31 05:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 05:04:37 --> Upload Class Initialized
DEBUG - 2026-01-31 05:04:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 05:04:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 05:04:37 --> Encryption Class Initialized
INFO - 2026-01-31 05:04:37 --> Form Validation Class Initialized
INFO - 2026-01-31 05:04:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 05:04:37 --> Pagination Class Initialized
INFO - 2026-01-31 05:04:37 --> Email Class Initialized
INFO - 2026-01-31 05:04:37 --> Controller Class Initialized
DEBUG - 2026-01-31 05:04:37 --> Auth MX_Controller Initialized
INFO - 2026-01-31 05:04:37 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 05:04:37 --> Model "Auth_model" initialized
INFO - 2026-01-31 05:04:37 --> Model "Cart_model" initialized
INFO - 2026-01-31 05:04:37 --> Model "Appsetting_model" initialized
INFO - 2026-01-31 05:04:39 --> Language file loaded: language/english/email_lang.php
DEBUG - 2026-01-31 05:04:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 05:04:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 05:04:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 05:04:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_forgetpass.php
INFO - 2026-01-31 05:04:45 --> Final output sent to browser
DEBUG - 2026-01-31 05:04:45 --> Total execution time: 9.8506
INFO - 2026-01-31 05:10:16 --> Config Class Initialized
INFO - 2026-01-31 05:10:16 --> Hooks Class Initialized
DEBUG - 2026-01-31 05:10:16 --> UTF-8 Support Enabled
INFO - 2026-01-31 05:10:16 --> Utf8 Class Initialized
INFO - 2026-01-31 05:10:16 --> URI Class Initialized
INFO - 2026-01-31 05:10:16 --> Router Class Initialized
INFO - 2026-01-31 05:10:16 --> Output Class Initialized
INFO - 2026-01-31 05:10:16 --> Security Class Initialized
DEBUG - 2026-01-31 05:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 05:10:16 --> CSRF cookie sent
INFO - 2026-01-31 05:10:16 --> CSRF token verified
INFO - 2026-01-31 05:10:16 --> Input Class Initialized
INFO - 2026-01-31 05:10:16 --> Language Class Initialized
INFO - 2026-01-31 05:10:16 --> Language Class Initialized
INFO - 2026-01-31 05:10:16 --> Config Class Initialized
INFO - 2026-01-31 05:10:16 --> Loader Class Initialized
INFO - 2026-01-31 05:10:16 --> Helper loaded: url_helper
INFO - 2026-01-31 05:10:16 --> Helper loaded: form_helper
INFO - 2026-01-31 05:10:16 --> Helper loaded: html_helper
INFO - 2026-01-31 05:10:16 --> Helper loaded: file_helper
INFO - 2026-01-31 05:10:16 --> Helper loaded: email_helper
INFO - 2026-01-31 05:10:16 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 05:10:16 --> Helper loaded: ssp_helper
INFO - 2026-01-31 05:10:16 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 05:10:16 --> Database Driver Class Initialized
INFO - 2026-01-31 05:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 05:10:18 --> Upload Class Initialized
DEBUG - 2026-01-31 05:10:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 05:10:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 05:10:18 --> Encryption Class Initialized
INFO - 2026-01-31 05:10:18 --> Form Validation Class Initialized
INFO - 2026-01-31 05:10:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 05:10:18 --> Pagination Class Initialized
INFO - 2026-01-31 05:10:18 --> Email Class Initialized
INFO - 2026-01-31 05:10:18 --> Controller Class Initialized
DEBUG - 2026-01-31 05:10:18 --> Auth MX_Controller Initialized
INFO - 2026-01-31 05:10:18 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 05:10:18 --> Model "Auth_model" initialized
INFO - 2026-01-31 05:10:18 --> Model "Cart_model" initialized
INFO - 2026-01-31 05:10:18 --> Model "Appsetting_model" initialized
INFO - 2026-01-31 05:10:20 --> Language file loaded: language/english/email_lang.php
DEBUG - 2026-01-31 05:10:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 05:10:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 05:10:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 05:10:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_forgetpass.php
INFO - 2026-01-31 05:10:26 --> Final output sent to browser
DEBUG - 2026-01-31 05:10:26 --> Total execution time: 9.9345
INFO - 2026-01-31 05:10:51 --> Config Class Initialized
INFO - 2026-01-31 05:10:51 --> Hooks Class Initialized
DEBUG - 2026-01-31 05:10:51 --> UTF-8 Support Enabled
INFO - 2026-01-31 05:10:51 --> Utf8 Class Initialized
INFO - 2026-01-31 05:10:51 --> URI Class Initialized
INFO - 2026-01-31 05:10:51 --> Router Class Initialized
INFO - 2026-01-31 05:10:51 --> Output Class Initialized
INFO - 2026-01-31 05:10:51 --> Security Class Initialized
DEBUG - 2026-01-31 05:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 05:10:51 --> CSRF cookie sent
INFO - 2026-01-31 05:10:51 --> Input Class Initialized
INFO - 2026-01-31 05:10:51 --> Language Class Initialized
INFO - 2026-01-31 05:10:51 --> Language Class Initialized
INFO - 2026-01-31 05:10:51 --> Config Class Initialized
INFO - 2026-01-31 05:10:51 --> Loader Class Initialized
INFO - 2026-01-31 05:10:51 --> Helper loaded: url_helper
INFO - 2026-01-31 05:10:51 --> Helper loaded: form_helper
INFO - 2026-01-31 05:10:51 --> Helper loaded: html_helper
INFO - 2026-01-31 05:10:51 --> Helper loaded: file_helper
INFO - 2026-01-31 05:10:51 --> Helper loaded: email_helper
INFO - 2026-01-31 05:10:51 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 05:10:51 --> Helper loaded: ssp_helper
INFO - 2026-01-31 05:10:51 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 05:10:51 --> Database Driver Class Initialized
INFO - 2026-01-31 05:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 05:10:53 --> Upload Class Initialized
DEBUG - 2026-01-31 05:10:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 05:10:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 05:10:53 --> Encryption Class Initialized
INFO - 2026-01-31 05:10:53 --> Form Validation Class Initialized
INFO - 2026-01-31 05:10:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 05:10:53 --> Pagination Class Initialized
INFO - 2026-01-31 05:10:53 --> Email Class Initialized
INFO - 2026-01-31 05:10:53 --> Controller Class Initialized
DEBUG - 2026-01-31 05:10:53 --> Auth MX_Controller Initialized
INFO - 2026-01-31 05:10:53 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 05:10:53 --> Model "Auth_model" initialized
INFO - 2026-01-31 05:10:53 --> Model "Cart_model" initialized
INFO - 2026-01-31 05:10:53 --> Model "Appsetting_model" initialized
INFO - 2026-01-31 05:10:54 --> Config Class Initialized
INFO - 2026-01-31 05:10:54 --> Hooks Class Initialized
DEBUG - 2026-01-31 05:10:54 --> UTF-8 Support Enabled
INFO - 2026-01-31 05:10:54 --> Utf8 Class Initialized
INFO - 2026-01-31 05:10:54 --> URI Class Initialized
INFO - 2026-01-31 05:10:54 --> Router Class Initialized
INFO - 2026-01-31 05:10:54 --> Output Class Initialized
INFO - 2026-01-31 05:10:54 --> Security Class Initialized
DEBUG - 2026-01-31 05:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 05:10:54 --> CSRF cookie sent
INFO - 2026-01-31 05:10:54 --> Input Class Initialized
INFO - 2026-01-31 05:10:54 --> Language Class Initialized
INFO - 2026-01-31 05:10:54 --> Language Class Initialized
INFO - 2026-01-31 05:10:54 --> Config Class Initialized
INFO - 2026-01-31 05:10:54 --> Loader Class Initialized
INFO - 2026-01-31 05:10:54 --> Helper loaded: url_helper
INFO - 2026-01-31 05:10:54 --> Helper loaded: form_helper
INFO - 2026-01-31 05:10:54 --> Helper loaded: html_helper
INFO - 2026-01-31 05:10:54 --> Helper loaded: file_helper
INFO - 2026-01-31 05:10:54 --> Helper loaded: email_helper
INFO - 2026-01-31 05:10:54 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 05:10:54 --> Helper loaded: ssp_helper
INFO - 2026-01-31 05:10:54 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 05:10:54 --> Database Driver Class Initialized
INFO - 2026-01-31 05:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 05:10:56 --> Upload Class Initialized
DEBUG - 2026-01-31 05:10:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 05:10:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 05:10:56 --> Encryption Class Initialized
INFO - 2026-01-31 05:10:56 --> Form Validation Class Initialized
INFO - 2026-01-31 05:10:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 05:10:56 --> Pagination Class Initialized
INFO - 2026-01-31 05:10:56 --> Email Class Initialized
INFO - 2026-01-31 05:10:56 --> Controller Class Initialized
DEBUG - 2026-01-31 05:10:56 --> Auth MX_Controller Initialized
INFO - 2026-01-31 05:10:56 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 05:10:56 --> Model "Auth_model" initialized
INFO - 2026-01-31 05:10:56 --> Model "Cart_model" initialized
INFO - 2026-01-31 05:10:56 --> Model "Appsetting_model" initialized
DEBUG - 2026-01-31 05:10:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 05:10:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 05:10:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 05:10:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-01-31 05:10:56 --> Final output sent to browser
DEBUG - 2026-01-31 05:10:56 --> Total execution time: 2.3975
INFO - 2026-01-31 05:13:33 --> Config Class Initialized
INFO - 2026-01-31 05:13:33 --> Hooks Class Initialized
DEBUG - 2026-01-31 05:13:33 --> UTF-8 Support Enabled
INFO - 2026-01-31 05:13:33 --> Utf8 Class Initialized
INFO - 2026-01-31 05:13:33 --> URI Class Initialized
INFO - 2026-01-31 05:13:33 --> Router Class Initialized
INFO - 2026-01-31 05:13:33 --> Output Class Initialized
INFO - 2026-01-31 05:13:33 --> Security Class Initialized
DEBUG - 2026-01-31 05:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 05:13:33 --> CSRF cookie sent
INFO - 2026-01-31 05:13:33 --> Input Class Initialized
INFO - 2026-01-31 05:13:33 --> Language Class Initialized
INFO - 2026-01-31 05:13:33 --> Language Class Initialized
INFO - 2026-01-31 05:13:33 --> Config Class Initialized
INFO - 2026-01-31 05:13:33 --> Loader Class Initialized
INFO - 2026-01-31 05:13:33 --> Helper loaded: url_helper
INFO - 2026-01-31 05:13:33 --> Helper loaded: form_helper
INFO - 2026-01-31 05:13:33 --> Helper loaded: html_helper
INFO - 2026-01-31 05:13:33 --> Helper loaded: file_helper
INFO - 2026-01-31 05:13:33 --> Helper loaded: email_helper
INFO - 2026-01-31 05:13:33 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 05:13:33 --> Helper loaded: ssp_helper
INFO - 2026-01-31 05:13:33 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 05:13:33 --> Database Driver Class Initialized
INFO - 2026-01-31 05:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 05:13:35 --> Upload Class Initialized
DEBUG - 2026-01-31 05:13:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 05:13:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 05:13:35 --> Encryption Class Initialized
INFO - 2026-01-31 05:13:35 --> Form Validation Class Initialized
INFO - 2026-01-31 05:13:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 05:13:35 --> Pagination Class Initialized
INFO - 2026-01-31 05:13:35 --> Email Class Initialized
INFO - 2026-01-31 05:13:35 --> Controller Class Initialized
DEBUG - 2026-01-31 05:13:35 --> Auth MX_Controller Initialized
INFO - 2026-01-31 05:13:35 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 05:13:35 --> Model "Auth_model" initialized
INFO - 2026-01-31 05:13:35 --> Model "Cart_model" initialized
INFO - 2026-01-31 05:13:35 --> Model "Appsetting_model" initialized
INFO - 2026-01-31 05:13:36 --> Config Class Initialized
INFO - 2026-01-31 05:13:36 --> Hooks Class Initialized
DEBUG - 2026-01-31 05:13:36 --> UTF-8 Support Enabled
INFO - 2026-01-31 05:13:36 --> Utf8 Class Initialized
INFO - 2026-01-31 05:13:36 --> URI Class Initialized
INFO - 2026-01-31 05:13:36 --> Router Class Initialized
INFO - 2026-01-31 05:13:36 --> Output Class Initialized
INFO - 2026-01-31 05:13:36 --> Security Class Initialized
DEBUG - 2026-01-31 05:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 05:13:36 --> CSRF cookie sent
INFO - 2026-01-31 05:13:36 --> Input Class Initialized
INFO - 2026-01-31 05:13:36 --> Language Class Initialized
INFO - 2026-01-31 05:13:36 --> Language Class Initialized
INFO - 2026-01-31 05:13:36 --> Config Class Initialized
INFO - 2026-01-31 05:13:36 --> Loader Class Initialized
INFO - 2026-01-31 05:13:36 --> Helper loaded: url_helper
INFO - 2026-01-31 05:13:36 --> Helper loaded: form_helper
INFO - 2026-01-31 05:13:36 --> Helper loaded: html_helper
INFO - 2026-01-31 05:13:36 --> Helper loaded: file_helper
INFO - 2026-01-31 05:13:36 --> Helper loaded: email_helper
INFO - 2026-01-31 05:13:36 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 05:13:36 --> Helper loaded: ssp_helper
INFO - 2026-01-31 05:13:36 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 05:13:36 --> Database Driver Class Initialized
INFO - 2026-01-31 05:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 05:13:38 --> Upload Class Initialized
DEBUG - 2026-01-31 05:13:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 05:13:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 05:13:38 --> Encryption Class Initialized
INFO - 2026-01-31 05:13:38 --> Form Validation Class Initialized
INFO - 2026-01-31 05:13:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 05:13:38 --> Pagination Class Initialized
INFO - 2026-01-31 05:13:38 --> Email Class Initialized
INFO - 2026-01-31 05:13:38 --> Controller Class Initialized
DEBUG - 2026-01-31 05:13:38 --> Auth MX_Controller Initialized
INFO - 2026-01-31 05:13:38 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 05:13:38 --> Model "Auth_model" initialized
INFO - 2026-01-31 05:13:38 --> Model "Cart_model" initialized
INFO - 2026-01-31 05:13:38 --> Model "Appsetting_model" initialized
DEBUG - 2026-01-31 05:13:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 05:13:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 05:13:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 05:13:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-01-31 05:13:38 --> Final output sent to browser
DEBUG - 2026-01-31 05:13:38 --> Total execution time: 2.3317
INFO - 2026-01-31 05:15:47 --> Config Class Initialized
INFO - 2026-01-31 05:15:47 --> Hooks Class Initialized
DEBUG - 2026-01-31 05:15:47 --> UTF-8 Support Enabled
INFO - 2026-01-31 05:15:47 --> Utf8 Class Initialized
INFO - 2026-01-31 05:15:47 --> URI Class Initialized
INFO - 2026-01-31 05:15:47 --> Router Class Initialized
INFO - 2026-01-31 05:15:47 --> Output Class Initialized
INFO - 2026-01-31 05:15:47 --> Security Class Initialized
DEBUG - 2026-01-31 05:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 05:15:47 --> CSRF cookie sent
INFO - 2026-01-31 05:15:47 --> Input Class Initialized
INFO - 2026-01-31 05:15:47 --> Language Class Initialized
INFO - 2026-01-31 05:15:47 --> Language Class Initialized
INFO - 2026-01-31 05:15:47 --> Config Class Initialized
INFO - 2026-01-31 05:15:47 --> Loader Class Initialized
INFO - 2026-01-31 05:15:47 --> Helper loaded: url_helper
INFO - 2026-01-31 05:15:47 --> Helper loaded: form_helper
INFO - 2026-01-31 05:15:47 --> Helper loaded: html_helper
INFO - 2026-01-31 05:15:47 --> Helper loaded: file_helper
INFO - 2026-01-31 05:15:47 --> Helper loaded: email_helper
INFO - 2026-01-31 05:15:47 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 05:15:47 --> Helper loaded: ssp_helper
INFO - 2026-01-31 05:15:47 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 05:15:47 --> Database Driver Class Initialized
INFO - 2026-01-31 05:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 05:15:49 --> Upload Class Initialized
DEBUG - 2026-01-31 05:15:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 05:15:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 05:15:49 --> Encryption Class Initialized
INFO - 2026-01-31 05:15:49 --> Form Validation Class Initialized
INFO - 2026-01-31 05:15:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 05:15:49 --> Pagination Class Initialized
INFO - 2026-01-31 05:15:49 --> Email Class Initialized
INFO - 2026-01-31 05:15:49 --> Controller Class Initialized
DEBUG - 2026-01-31 05:15:49 --> Auth MX_Controller Initialized
INFO - 2026-01-31 05:15:49 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 05:15:49 --> Model "Auth_model" initialized
INFO - 2026-01-31 05:15:49 --> Model "Cart_model" initialized
INFO - 2026-01-31 05:15:49 --> Model "Appsetting_model" initialized
DEBUG - 2026-01-31 05:15:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 05:15:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 05:15:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 05:15:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_resetpassword.php
INFO - 2026-01-31 05:15:50 --> Final output sent to browser
DEBUG - 2026-01-31 05:15:50 --> Total execution time: 2.6584
INFO - 2026-01-31 05:19:51 --> Config Class Initialized
INFO - 2026-01-31 05:19:51 --> Hooks Class Initialized
DEBUG - 2026-01-31 05:19:51 --> UTF-8 Support Enabled
INFO - 2026-01-31 05:19:51 --> Utf8 Class Initialized
INFO - 2026-01-31 05:19:51 --> URI Class Initialized
INFO - 2026-01-31 05:19:51 --> Router Class Initialized
INFO - 2026-01-31 05:19:51 --> Output Class Initialized
INFO - 2026-01-31 05:19:51 --> Security Class Initialized
DEBUG - 2026-01-31 05:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 05:19:51 --> CSRF cookie sent
INFO - 2026-01-31 05:19:51 --> CSRF token verified
INFO - 2026-01-31 05:19:51 --> Input Class Initialized
INFO - 2026-01-31 05:19:51 --> Language Class Initialized
INFO - 2026-01-31 05:19:51 --> Language Class Initialized
INFO - 2026-01-31 05:19:51 --> Config Class Initialized
INFO - 2026-01-31 05:19:51 --> Loader Class Initialized
INFO - 2026-01-31 05:19:51 --> Helper loaded: url_helper
INFO - 2026-01-31 05:19:51 --> Helper loaded: form_helper
INFO - 2026-01-31 05:19:51 --> Helper loaded: html_helper
INFO - 2026-01-31 05:19:51 --> Helper loaded: file_helper
INFO - 2026-01-31 05:19:51 --> Helper loaded: email_helper
INFO - 2026-01-31 05:19:51 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 05:19:51 --> Helper loaded: ssp_helper
INFO - 2026-01-31 05:19:51 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 05:19:51 --> Database Driver Class Initialized
INFO - 2026-01-31 05:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 05:19:53 --> Upload Class Initialized
DEBUG - 2026-01-31 05:19:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 05:19:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 05:19:53 --> Encryption Class Initialized
INFO - 2026-01-31 05:19:53 --> Form Validation Class Initialized
INFO - 2026-01-31 05:19:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 05:19:53 --> Pagination Class Initialized
INFO - 2026-01-31 05:19:53 --> Email Class Initialized
INFO - 2026-01-31 05:19:53 --> Controller Class Initialized
DEBUG - 2026-01-31 05:19:53 --> Auth MX_Controller Initialized
INFO - 2026-01-31 05:19:53 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 05:19:53 --> Model "Auth_model" initialized
INFO - 2026-01-31 05:19:53 --> Model "Cart_model" initialized
INFO - 2026-01-31 05:19:53 --> Model "Appsetting_model" initialized
INFO - 2026-01-31 05:19:56 --> Language file loaded: language/english/email_lang.php
DEBUG - 2026-01-31 05:20:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 05:20:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 05:20:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 05:20:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_forgetpass.php
INFO - 2026-01-31 05:20:02 --> Final output sent to browser
DEBUG - 2026-01-31 05:20:02 --> Total execution time: 10.7059
INFO - 2026-01-31 05:20:26 --> Config Class Initialized
INFO - 2026-01-31 05:20:26 --> Hooks Class Initialized
DEBUG - 2026-01-31 05:20:26 --> UTF-8 Support Enabled
INFO - 2026-01-31 05:20:26 --> Utf8 Class Initialized
INFO - 2026-01-31 05:20:26 --> URI Class Initialized
INFO - 2026-01-31 05:20:26 --> Router Class Initialized
INFO - 2026-01-31 05:20:26 --> Output Class Initialized
INFO - 2026-01-31 05:20:26 --> Security Class Initialized
DEBUG - 2026-01-31 05:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 05:20:26 --> CSRF cookie sent
INFO - 2026-01-31 05:20:26 --> Input Class Initialized
INFO - 2026-01-31 05:20:26 --> Language Class Initialized
INFO - 2026-01-31 05:20:26 --> Language Class Initialized
INFO - 2026-01-31 05:20:26 --> Config Class Initialized
INFO - 2026-01-31 05:20:26 --> Loader Class Initialized
INFO - 2026-01-31 05:20:26 --> Helper loaded: url_helper
INFO - 2026-01-31 05:20:26 --> Helper loaded: form_helper
INFO - 2026-01-31 05:20:26 --> Helper loaded: html_helper
INFO - 2026-01-31 05:20:26 --> Helper loaded: file_helper
INFO - 2026-01-31 05:20:26 --> Helper loaded: email_helper
INFO - 2026-01-31 05:20:26 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 05:20:26 --> Helper loaded: ssp_helper
INFO - 2026-01-31 05:20:26 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 05:20:26 --> Database Driver Class Initialized
INFO - 2026-01-31 05:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 05:20:28 --> Upload Class Initialized
DEBUG - 2026-01-31 05:20:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 05:20:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 05:20:28 --> Encryption Class Initialized
INFO - 2026-01-31 05:20:28 --> Form Validation Class Initialized
INFO - 2026-01-31 05:20:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 05:20:28 --> Pagination Class Initialized
INFO - 2026-01-31 05:20:28 --> Email Class Initialized
INFO - 2026-01-31 05:20:28 --> Controller Class Initialized
DEBUG - 2026-01-31 05:20:28 --> Auth MX_Controller Initialized
INFO - 2026-01-31 05:20:28 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 05:20:28 --> Model "Auth_model" initialized
INFO - 2026-01-31 05:20:28 --> Model "Cart_model" initialized
INFO - 2026-01-31 05:20:28 --> Model "Appsetting_model" initialized
DEBUG - 2026-01-31 05:20:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 05:20:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 05:20:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 05:20:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_resetpassword.php
INFO - 2026-01-31 05:20:29 --> Final output sent to browser
DEBUG - 2026-01-31 05:20:29 --> Total execution time: 2.6099
INFO - 2026-01-31 05:32:33 --> Config Class Initialized
INFO - 2026-01-31 05:32:33 --> Hooks Class Initialized
DEBUG - 2026-01-31 05:32:33 --> UTF-8 Support Enabled
INFO - 2026-01-31 05:32:33 --> Utf8 Class Initialized
INFO - 2026-01-31 05:32:33 --> URI Class Initialized
INFO - 2026-01-31 05:32:33 --> Router Class Initialized
INFO - 2026-01-31 05:32:33 --> Output Class Initialized
INFO - 2026-01-31 05:32:33 --> Security Class Initialized
DEBUG - 2026-01-31 05:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 05:32:33 --> CSRF cookie sent
INFO - 2026-01-31 05:32:33 --> CSRF token verified
INFO - 2026-01-31 05:32:33 --> Input Class Initialized
INFO - 2026-01-31 05:32:33 --> Language Class Initialized
INFO - 2026-01-31 05:32:33 --> Language Class Initialized
INFO - 2026-01-31 05:32:33 --> Config Class Initialized
INFO - 2026-01-31 05:32:33 --> Loader Class Initialized
INFO - 2026-01-31 05:32:33 --> Helper loaded: url_helper
INFO - 2026-01-31 05:32:33 --> Helper loaded: form_helper
INFO - 2026-01-31 05:32:33 --> Helper loaded: html_helper
INFO - 2026-01-31 05:32:33 --> Helper loaded: file_helper
INFO - 2026-01-31 05:32:33 --> Helper loaded: email_helper
INFO - 2026-01-31 05:32:33 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 05:32:33 --> Helper loaded: ssp_helper
INFO - 2026-01-31 05:32:33 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 05:32:33 --> Database Driver Class Initialized
INFO - 2026-01-31 05:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 05:32:35 --> Upload Class Initialized
DEBUG - 2026-01-31 05:32:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 05:32:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 05:32:35 --> Encryption Class Initialized
INFO - 2026-01-31 05:32:35 --> Form Validation Class Initialized
INFO - 2026-01-31 05:32:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 05:32:35 --> Pagination Class Initialized
INFO - 2026-01-31 05:32:35 --> Email Class Initialized
INFO - 2026-01-31 05:32:35 --> Controller Class Initialized
DEBUG - 2026-01-31 05:32:35 --> Auth MX_Controller Initialized
INFO - 2026-01-31 05:32:35 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 05:32:35 --> Model "Auth_model" initialized
INFO - 2026-01-31 05:32:35 --> Model "Cart_model" initialized
INFO - 2026-01-31 05:32:35 --> Model "Appsetting_model" initialized
INFO - 2026-01-31 05:32:37 --> Language file loaded: language/english/email_lang.php
DEBUG - 2026-01-31 05:32:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 05:32:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 05:32:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 05:32:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_forgetpass.php
INFO - 2026-01-31 05:32:44 --> Final output sent to browser
DEBUG - 2026-01-31 05:32:44 --> Total execution time: 10.2121
INFO - 2026-01-31 16:41:18 --> Config Class Initialized
INFO - 2026-01-31 16:41:18 --> Hooks Class Initialized
DEBUG - 2026-01-31 16:41:18 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:41:18 --> Utf8 Class Initialized
INFO - 2026-01-31 16:41:18 --> URI Class Initialized
INFO - 2026-01-31 16:41:18 --> Router Class Initialized
INFO - 2026-01-31 16:41:18 --> Output Class Initialized
INFO - 2026-01-31 16:41:18 --> Security Class Initialized
DEBUG - 2026-01-31 16:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:41:18 --> CSRF cookie sent
INFO - 2026-01-31 16:41:18 --> Input Class Initialized
INFO - 2026-01-31 16:41:18 --> Language Class Initialized
INFO - 2026-01-31 16:41:18 --> Language Class Initialized
INFO - 2026-01-31 16:41:18 --> Config Class Initialized
INFO - 2026-01-31 16:41:18 --> Loader Class Initialized
INFO - 2026-01-31 16:41:18 --> Helper loaded: url_helper
INFO - 2026-01-31 16:41:18 --> Helper loaded: form_helper
INFO - 2026-01-31 16:41:18 --> Helper loaded: html_helper
INFO - 2026-01-31 16:41:18 --> Helper loaded: file_helper
INFO - 2026-01-31 16:41:18 --> Helper loaded: email_helper
INFO - 2026-01-31 16:41:18 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:41:18 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:41:18 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:41:18 --> Database Driver Class Initialized
INFO - 2026-01-31 16:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:41:20 --> Upload Class Initialized
DEBUG - 2026-01-31 16:41:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:41:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:41:20 --> Encryption Class Initialized
INFO - 2026-01-31 16:41:20 --> Form Validation Class Initialized
INFO - 2026-01-31 16:41:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:41:20 --> Pagination Class Initialized
INFO - 2026-01-31 16:41:20 --> Email Class Initialized
INFO - 2026-01-31 16:41:20 --> Controller Class Initialized
DEBUG - 2026-01-31 16:41:20 --> Auth MX_Controller Initialized
INFO - 2026-01-31 16:41:20 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:41:20 --> Model "Auth_model" initialized
INFO - 2026-01-31 16:41:20 --> Model "Cart_model" initialized
INFO - 2026-01-31 16:41:21 --> Model "Appsetting_model" initialized
INFO - 2026-01-31 16:41:22 --> Config Class Initialized
INFO - 2026-01-31 16:41:22 --> Hooks Class Initialized
DEBUG - 2026-01-31 16:41:22 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:41:22 --> Utf8 Class Initialized
INFO - 2026-01-31 16:41:22 --> URI Class Initialized
INFO - 2026-01-31 16:41:22 --> Router Class Initialized
INFO - 2026-01-31 16:41:22 --> Output Class Initialized
INFO - 2026-01-31 16:41:22 --> Security Class Initialized
DEBUG - 2026-01-31 16:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:41:22 --> CSRF cookie sent
INFO - 2026-01-31 16:41:22 --> Input Class Initialized
INFO - 2026-01-31 16:41:22 --> Language Class Initialized
INFO - 2026-01-31 16:41:22 --> Language Class Initialized
INFO - 2026-01-31 16:41:22 --> Config Class Initialized
INFO - 2026-01-31 16:41:22 --> Loader Class Initialized
INFO - 2026-01-31 16:41:22 --> Helper loaded: url_helper
INFO - 2026-01-31 16:41:22 --> Helper loaded: form_helper
INFO - 2026-01-31 16:41:22 --> Helper loaded: html_helper
INFO - 2026-01-31 16:41:22 --> Helper loaded: file_helper
INFO - 2026-01-31 16:41:22 --> Helper loaded: email_helper
INFO - 2026-01-31 16:41:22 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:41:22 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:41:22 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:41:22 --> Database Driver Class Initialized
INFO - 2026-01-31 16:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:41:24 --> Upload Class Initialized
DEBUG - 2026-01-31 16:41:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:41:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:41:24 --> Encryption Class Initialized
INFO - 2026-01-31 16:41:24 --> Form Validation Class Initialized
INFO - 2026-01-31 16:41:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:41:24 --> Pagination Class Initialized
INFO - 2026-01-31 16:41:24 --> Email Class Initialized
INFO - 2026-01-31 16:41:24 --> Controller Class Initialized
DEBUG - 2026-01-31 16:41:24 --> Auth MX_Controller Initialized
INFO - 2026-01-31 16:41:24 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:41:24 --> Model "Auth_model" initialized
INFO - 2026-01-31 16:41:24 --> Model "Cart_model" initialized
INFO - 2026-01-31 16:41:24 --> Model "Appsetting_model" initialized
DEBUG - 2026-01-31 16:41:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 16:41:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 16:41:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 16:41:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-01-31 16:41:24 --> Final output sent to browser
DEBUG - 2026-01-31 16:41:24 --> Total execution time: 2.5103
INFO - 2026-01-31 16:41:26 --> Config Class Initialized
INFO - 2026-01-31 16:41:26 --> Hooks Class Initialized
DEBUG - 2026-01-31 16:41:26 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:41:26 --> Utf8 Class Initialized
INFO - 2026-01-31 16:41:26 --> URI Class Initialized
INFO - 2026-01-31 16:41:26 --> Router Class Initialized
INFO - 2026-01-31 16:41:26 --> Output Class Initialized
INFO - 2026-01-31 16:41:26 --> Security Class Initialized
DEBUG - 2026-01-31 16:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:41:26 --> CSRF cookie sent
INFO - 2026-01-31 16:41:26 --> Input Class Initialized
INFO - 2026-01-31 16:41:26 --> Language Class Initialized
INFO - 2026-01-31 16:41:26 --> Language Class Initialized
INFO - 2026-01-31 16:41:26 --> Config Class Initialized
INFO - 2026-01-31 16:41:26 --> Loader Class Initialized
INFO - 2026-01-31 16:41:26 --> Helper loaded: url_helper
INFO - 2026-01-31 16:41:26 --> Helper loaded: form_helper
INFO - 2026-01-31 16:41:26 --> Helper loaded: html_helper
INFO - 2026-01-31 16:41:26 --> Helper loaded: file_helper
INFO - 2026-01-31 16:41:26 --> Helper loaded: email_helper
INFO - 2026-01-31 16:41:26 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:41:26 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:41:26 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:41:26 --> Database Driver Class Initialized
INFO - 2026-01-31 16:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:41:28 --> Upload Class Initialized
DEBUG - 2026-01-31 16:41:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:41:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:41:28 --> Encryption Class Initialized
INFO - 2026-01-31 16:41:28 --> Form Validation Class Initialized
INFO - 2026-01-31 16:41:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:41:28 --> Pagination Class Initialized
INFO - 2026-01-31 16:41:28 --> Email Class Initialized
INFO - 2026-01-31 16:41:28 --> Controller Class Initialized
DEBUG - 2026-01-31 16:41:28 --> Auth MX_Controller Initialized
INFO - 2026-01-31 16:41:28 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:41:28 --> Model "Auth_model" initialized
INFO - 2026-01-31 16:41:28 --> Model "Cart_model" initialized
INFO - 2026-01-31 16:41:28 --> Model "Appsetting_model" initialized
DEBUG - 2026-01-31 16:41:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 16:41:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 16:41:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 16:41:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_forgetpass.php
INFO - 2026-01-31 16:41:29 --> Final output sent to browser
DEBUG - 2026-01-31 16:41:29 --> Total execution time: 2.2348
INFO - 2026-01-31 16:41:33 --> Config Class Initialized
INFO - 2026-01-31 16:41:33 --> Hooks Class Initialized
DEBUG - 2026-01-31 16:41:33 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:41:33 --> Utf8 Class Initialized
INFO - 2026-01-31 16:41:33 --> URI Class Initialized
INFO - 2026-01-31 16:41:33 --> Router Class Initialized
INFO - 2026-01-31 16:41:33 --> Output Class Initialized
INFO - 2026-01-31 16:41:33 --> Security Class Initialized
DEBUG - 2026-01-31 16:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:41:33 --> CSRF cookie sent
INFO - 2026-01-31 16:41:33 --> CSRF token verified
INFO - 2026-01-31 16:41:33 --> Input Class Initialized
INFO - 2026-01-31 16:41:33 --> Language Class Initialized
INFO - 2026-01-31 16:41:33 --> Language Class Initialized
INFO - 2026-01-31 16:41:33 --> Config Class Initialized
INFO - 2026-01-31 16:41:33 --> Loader Class Initialized
INFO - 2026-01-31 16:41:33 --> Helper loaded: url_helper
INFO - 2026-01-31 16:41:33 --> Helper loaded: form_helper
INFO - 2026-01-31 16:41:33 --> Helper loaded: html_helper
INFO - 2026-01-31 16:41:33 --> Helper loaded: file_helper
INFO - 2026-01-31 16:41:33 --> Helper loaded: email_helper
INFO - 2026-01-31 16:41:33 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:41:33 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:41:33 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:41:33 --> Database Driver Class Initialized
INFO - 2026-01-31 16:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:41:35 --> Upload Class Initialized
DEBUG - 2026-01-31 16:41:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:41:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:41:35 --> Encryption Class Initialized
INFO - 2026-01-31 16:41:35 --> Form Validation Class Initialized
INFO - 2026-01-31 16:41:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:41:35 --> Pagination Class Initialized
INFO - 2026-01-31 16:41:35 --> Email Class Initialized
INFO - 2026-01-31 16:41:35 --> Controller Class Initialized
DEBUG - 2026-01-31 16:41:35 --> Auth MX_Controller Initialized
INFO - 2026-01-31 16:41:35 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:41:35 --> Model "Auth_model" initialized
INFO - 2026-01-31 16:41:35 --> Model "Cart_model" initialized
INFO - 2026-01-31 16:41:35 --> Model "Appsetting_model" initialized
DEBUG - 2026-01-31 16:41:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 16:41:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 16:41:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 16:41:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_forgetpass.php
INFO - 2026-01-31 16:41:44 --> Final output sent to browser
DEBUG - 2026-01-31 16:41:44 --> Total execution time: 11.1634
INFO - 2026-01-31 16:42:25 --> Config Class Initialized
INFO - 2026-01-31 16:42:25 --> Hooks Class Initialized
DEBUG - 2026-01-31 16:42:25 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:42:25 --> Utf8 Class Initialized
INFO - 2026-01-31 16:42:25 --> URI Class Initialized
INFO - 2026-01-31 16:42:25 --> Router Class Initialized
INFO - 2026-01-31 16:42:25 --> Output Class Initialized
INFO - 2026-01-31 16:42:25 --> Security Class Initialized
DEBUG - 2026-01-31 16:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:42:25 --> CSRF cookie sent
INFO - 2026-01-31 16:42:25 --> Input Class Initialized
INFO - 2026-01-31 16:42:25 --> Language Class Initialized
INFO - 2026-01-31 16:42:25 --> Language Class Initialized
INFO - 2026-01-31 16:42:25 --> Config Class Initialized
INFO - 2026-01-31 16:42:25 --> Loader Class Initialized
INFO - 2026-01-31 16:42:25 --> Helper loaded: url_helper
INFO - 2026-01-31 16:42:25 --> Helper loaded: form_helper
INFO - 2026-01-31 16:42:25 --> Helper loaded: html_helper
INFO - 2026-01-31 16:42:25 --> Helper loaded: file_helper
INFO - 2026-01-31 16:42:25 --> Helper loaded: email_helper
INFO - 2026-01-31 16:42:25 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:42:25 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:42:25 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:42:25 --> Database Driver Class Initialized
INFO - 2026-01-31 16:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:42:28 --> Upload Class Initialized
DEBUG - 2026-01-31 16:42:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:42:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:42:28 --> Encryption Class Initialized
INFO - 2026-01-31 16:42:28 --> Form Validation Class Initialized
INFO - 2026-01-31 16:42:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:42:28 --> Pagination Class Initialized
INFO - 2026-01-31 16:42:28 --> Email Class Initialized
INFO - 2026-01-31 16:42:28 --> Controller Class Initialized
DEBUG - 2026-01-31 16:42:28 --> Auth MX_Controller Initialized
INFO - 2026-01-31 16:42:28 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:42:28 --> Model "Auth_model" initialized
INFO - 2026-01-31 16:42:28 --> Model "Cart_model" initialized
INFO - 2026-01-31 16:42:28 --> Model "Appsetting_model" initialized
DEBUG - 2026-01-31 16:42:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 16:42:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 16:42:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 16:42:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_resetpassword.php
INFO - 2026-01-31 16:42:28 --> Final output sent to browser
DEBUG - 2026-01-31 16:42:28 --> Total execution time: 3.5991
INFO - 2026-01-31 16:42:48 --> Config Class Initialized
INFO - 2026-01-31 16:42:48 --> Hooks Class Initialized
DEBUG - 2026-01-31 16:42:48 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:42:48 --> Utf8 Class Initialized
INFO - 2026-01-31 16:42:48 --> URI Class Initialized
INFO - 2026-01-31 16:42:48 --> Router Class Initialized
INFO - 2026-01-31 16:42:48 --> Output Class Initialized
INFO - 2026-01-31 16:42:48 --> Security Class Initialized
DEBUG - 2026-01-31 16:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:42:48 --> CSRF cookie sent
INFO - 2026-01-31 16:42:48 --> CSRF token verified
INFO - 2026-01-31 16:42:48 --> Input Class Initialized
INFO - 2026-01-31 16:42:48 --> Language Class Initialized
INFO - 2026-01-31 16:42:48 --> Language Class Initialized
INFO - 2026-01-31 16:42:48 --> Config Class Initialized
INFO - 2026-01-31 16:42:48 --> Loader Class Initialized
INFO - 2026-01-31 16:42:48 --> Helper loaded: url_helper
INFO - 2026-01-31 16:42:48 --> Helper loaded: form_helper
INFO - 2026-01-31 16:42:48 --> Helper loaded: html_helper
INFO - 2026-01-31 16:42:48 --> Helper loaded: file_helper
INFO - 2026-01-31 16:42:48 --> Helper loaded: email_helper
INFO - 2026-01-31 16:42:48 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:42:48 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:42:48 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:42:48 --> Database Driver Class Initialized
INFO - 2026-01-31 16:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:42:50 --> Upload Class Initialized
DEBUG - 2026-01-31 16:42:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:42:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:42:50 --> Encryption Class Initialized
INFO - 2026-01-31 16:42:50 --> Form Validation Class Initialized
INFO - 2026-01-31 16:42:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:42:50 --> Pagination Class Initialized
INFO - 2026-01-31 16:42:50 --> Email Class Initialized
INFO - 2026-01-31 16:42:50 --> Controller Class Initialized
DEBUG - 2026-01-31 16:42:50 --> Auth MX_Controller Initialized
INFO - 2026-01-31 16:42:50 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:42:50 --> Model "Auth_model" initialized
INFO - 2026-01-31 16:42:50 --> Model "Cart_model" initialized
INFO - 2026-01-31 16:42:50 --> Model "Appsetting_model" initialized
INFO - 2026-01-31 16:42:51 --> Final output sent to browser
DEBUG - 2026-01-31 16:42:51 --> Total execution time: 3.0405
INFO - 2026-01-31 16:43:54 --> Config Class Initialized
INFO - 2026-01-31 16:43:54 --> Hooks Class Initialized
DEBUG - 2026-01-31 16:43:54 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:43:54 --> Utf8 Class Initialized
INFO - 2026-01-31 16:43:54 --> URI Class Initialized
INFO - 2026-01-31 16:43:54 --> Router Class Initialized
INFO - 2026-01-31 16:43:54 --> Output Class Initialized
INFO - 2026-01-31 16:43:54 --> Security Class Initialized
DEBUG - 2026-01-31 16:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:43:54 --> CSRF cookie sent
INFO - 2026-01-31 16:43:54 --> Input Class Initialized
INFO - 2026-01-31 16:43:54 --> Language Class Initialized
INFO - 2026-01-31 16:43:54 --> Language Class Initialized
INFO - 2026-01-31 16:43:54 --> Config Class Initialized
INFO - 2026-01-31 16:43:54 --> Loader Class Initialized
INFO - 2026-01-31 16:43:54 --> Helper loaded: url_helper
INFO - 2026-01-31 16:43:54 --> Helper loaded: form_helper
INFO - 2026-01-31 16:43:54 --> Helper loaded: html_helper
INFO - 2026-01-31 16:43:54 --> Helper loaded: file_helper
INFO - 2026-01-31 16:43:54 --> Helper loaded: email_helper
INFO - 2026-01-31 16:43:54 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:43:54 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:43:54 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:43:54 --> Database Driver Class Initialized
INFO - 2026-01-31 16:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:43:56 --> Upload Class Initialized
DEBUG - 2026-01-31 16:43:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:43:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:43:56 --> Encryption Class Initialized
INFO - 2026-01-31 16:43:56 --> Form Validation Class Initialized
INFO - 2026-01-31 16:43:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:43:56 --> Pagination Class Initialized
INFO - 2026-01-31 16:43:56 --> Email Class Initialized
INFO - 2026-01-31 16:43:56 --> Controller Class Initialized
DEBUG - 2026-01-31 16:43:56 --> Auth MX_Controller Initialized
INFO - 2026-01-31 16:43:56 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:43:56 --> Model "Auth_model" initialized
INFO - 2026-01-31 16:43:56 --> Model "Cart_model" initialized
INFO - 2026-01-31 16:43:56 --> Model "Appsetting_model" initialized
INFO - 2026-01-31 16:43:57 --> Config Class Initialized
INFO - 2026-01-31 16:43:57 --> Hooks Class Initialized
DEBUG - 2026-01-31 16:43:57 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:43:57 --> Utf8 Class Initialized
INFO - 2026-01-31 16:43:57 --> URI Class Initialized
INFO - 2026-01-31 16:43:57 --> Router Class Initialized
INFO - 2026-01-31 16:43:57 --> Output Class Initialized
INFO - 2026-01-31 16:43:57 --> Security Class Initialized
DEBUG - 2026-01-31 16:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:43:57 --> CSRF cookie sent
INFO - 2026-01-31 16:43:57 --> Input Class Initialized
INFO - 2026-01-31 16:43:57 --> Language Class Initialized
INFO - 2026-01-31 16:43:57 --> Language Class Initialized
INFO - 2026-01-31 16:43:57 --> Config Class Initialized
INFO - 2026-01-31 16:43:57 --> Loader Class Initialized
INFO - 2026-01-31 16:43:57 --> Helper loaded: url_helper
INFO - 2026-01-31 16:43:57 --> Helper loaded: form_helper
INFO - 2026-01-31 16:43:57 --> Helper loaded: html_helper
INFO - 2026-01-31 16:43:57 --> Helper loaded: file_helper
INFO - 2026-01-31 16:43:57 --> Helper loaded: email_helper
INFO - 2026-01-31 16:43:57 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:43:57 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:43:57 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:43:57 --> Database Driver Class Initialized
INFO - 2026-01-31 16:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:43:59 --> Upload Class Initialized
DEBUG - 2026-01-31 16:43:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:43:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:43:59 --> Encryption Class Initialized
INFO - 2026-01-31 16:43:59 --> Form Validation Class Initialized
INFO - 2026-01-31 16:43:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:43:59 --> Pagination Class Initialized
INFO - 2026-01-31 16:43:59 --> Email Class Initialized
INFO - 2026-01-31 16:43:59 --> Controller Class Initialized
DEBUG - 2026-01-31 16:43:59 --> Auth MX_Controller Initialized
INFO - 2026-01-31 16:43:59 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:43:59 --> Model "Auth_model" initialized
INFO - 2026-01-31 16:43:59 --> Model "Cart_model" initialized
INFO - 2026-01-31 16:43:59 --> Model "Appsetting_model" initialized
DEBUG - 2026-01-31 16:43:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 16:43:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 16:43:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 16:43:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-01-31 16:43:59 --> Final output sent to browser
DEBUG - 2026-01-31 16:43:59 --> Total execution time: 2.5161
INFO - 2026-01-31 16:44:06 --> Config Class Initialized
INFO - 2026-01-31 16:44:06 --> Hooks Class Initialized
DEBUG - 2026-01-31 16:44:06 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:44:06 --> Utf8 Class Initialized
INFO - 2026-01-31 16:44:06 --> URI Class Initialized
INFO - 2026-01-31 16:44:06 --> Router Class Initialized
INFO - 2026-01-31 16:44:06 --> Output Class Initialized
INFO - 2026-01-31 16:44:06 --> Security Class Initialized
DEBUG - 2026-01-31 16:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:44:06 --> CSRF cookie sent
INFO - 2026-01-31 16:44:06 --> CSRF token verified
INFO - 2026-01-31 16:44:06 --> Input Class Initialized
INFO - 2026-01-31 16:44:06 --> Language Class Initialized
INFO - 2026-01-31 16:44:06 --> Language Class Initialized
INFO - 2026-01-31 16:44:06 --> Config Class Initialized
INFO - 2026-01-31 16:44:06 --> Loader Class Initialized
INFO - 2026-01-31 16:44:06 --> Helper loaded: url_helper
INFO - 2026-01-31 16:44:06 --> Helper loaded: form_helper
INFO - 2026-01-31 16:44:06 --> Helper loaded: html_helper
INFO - 2026-01-31 16:44:06 --> Helper loaded: file_helper
INFO - 2026-01-31 16:44:06 --> Helper loaded: email_helper
INFO - 2026-01-31 16:44:06 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:44:06 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:44:06 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:44:06 --> Database Driver Class Initialized
INFO - 2026-01-31 16:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:44:08 --> Upload Class Initialized
DEBUG - 2026-01-31 16:44:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:44:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:44:08 --> Encryption Class Initialized
INFO - 2026-01-31 16:44:08 --> Form Validation Class Initialized
INFO - 2026-01-31 16:44:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:44:08 --> Pagination Class Initialized
INFO - 2026-01-31 16:44:08 --> Email Class Initialized
INFO - 2026-01-31 16:44:08 --> Controller Class Initialized
DEBUG - 2026-01-31 16:44:08 --> Auth MX_Controller Initialized
INFO - 2026-01-31 16:44:08 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:44:08 --> Model "Auth_model" initialized
INFO - 2026-01-31 16:44:08 --> Model "Cart_model" initialized
INFO - 2026-01-31 16:44:08 --> Model "Appsetting_model" initialized
INFO - 2026-01-31 16:44:11 --> Config Class Initialized
INFO - 2026-01-31 16:44:11 --> Hooks Class Initialized
DEBUG - 2026-01-31 16:44:11 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:44:11 --> Utf8 Class Initialized
INFO - 2026-01-31 16:44:11 --> URI Class Initialized
INFO - 2026-01-31 16:44:11 --> Router Class Initialized
INFO - 2026-01-31 16:44:11 --> Output Class Initialized
INFO - 2026-01-31 16:44:11 --> Security Class Initialized
DEBUG - 2026-01-31 16:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:44:11 --> CSRF cookie sent
INFO - 2026-01-31 16:44:11 --> Input Class Initialized
INFO - 2026-01-31 16:44:11 --> Language Class Initialized
INFO - 2026-01-31 16:44:11 --> Language Class Initialized
INFO - 2026-01-31 16:44:11 --> Config Class Initialized
INFO - 2026-01-31 16:44:11 --> Loader Class Initialized
INFO - 2026-01-31 16:44:11 --> Helper loaded: url_helper
INFO - 2026-01-31 16:44:11 --> Helper loaded: form_helper
INFO - 2026-01-31 16:44:11 --> Helper loaded: html_helper
INFO - 2026-01-31 16:44:11 --> Helper loaded: file_helper
INFO - 2026-01-31 16:44:11 --> Helper loaded: email_helper
INFO - 2026-01-31 16:44:11 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:44:11 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:44:11 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:44:11 --> Database Driver Class Initialized
INFO - 2026-01-31 16:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:44:13 --> Upload Class Initialized
DEBUG - 2026-01-31 16:44:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:44:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:44:13 --> Encryption Class Initialized
INFO - 2026-01-31 16:44:13 --> Form Validation Class Initialized
INFO - 2026-01-31 16:44:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:44:13 --> Pagination Class Initialized
INFO - 2026-01-31 16:44:13 --> Email Class Initialized
INFO - 2026-01-31 16:44:13 --> Controller Class Initialized
DEBUG - 2026-01-31 16:44:13 --> Clientarea MX_Controller Initialized
INFO - 2026-01-31 16:44:13 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:44:13 --> Model "Auth_model" initialized
INFO - 2026-01-31 16:44:13 --> Model "Cart_model" initialized
INFO - 2026-01-31 16:44:13 --> Model "Clientarea_model" initialized
INFO - 2026-01-31 16:44:13 --> Model "Billing_model" initialized
INFO - 2026-01-31 16:44:13 --> Model "Common_model" initialized
INFO - 2026-01-31 16:44:13 --> Model "Order_model" initialized
INFO - 2026-01-31 16:44:13 --> Model "Support_model" initialized
DEBUG - 2026-01-31 16:44:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 16:44:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 16:44:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 16:44:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_index.php
INFO - 2026-01-31 16:44:13 --> Final output sent to browser
DEBUG - 2026-01-31 16:44:13 --> Total execution time: 2.2898
INFO - 2026-01-31 16:44:13 --> Config Class Initialized
INFO - 2026-01-31 16:44:13 --> Hooks Class Initialized
DEBUG - 2026-01-31 16:44:13 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:44:13 --> Utf8 Class Initialized
INFO - 2026-01-31 16:44:13 --> URI Class Initialized
INFO - 2026-01-31 16:44:13 --> Router Class Initialized
INFO - 2026-01-31 16:44:13 --> Output Class Initialized
INFO - 2026-01-31 16:44:13 --> Security Class Initialized
DEBUG - 2026-01-31 16:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:44:13 --> Input Class Initialized
INFO - 2026-01-31 16:44:13 --> Config Class Initialized
INFO - 2026-01-31 16:44:13 --> Language Class Initialized
INFO - 2026-01-31 16:44:13 --> Hooks Class Initialized
INFO - 2026-01-31 16:44:13 --> Language Class Initialized
INFO - 2026-01-31 16:44:13 --> Config Class Initialized
INFO - 2026-01-31 16:44:13 --> Config Class Initialized
INFO - 2026-01-31 16:44:13 --> Hooks Class Initialized
DEBUG - 2026-01-31 16:44:13 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:44:13 --> Utf8 Class Initialized
DEBUG - 2026-01-31 16:44:13 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:44:13 --> Utf8 Class Initialized
INFO - 2026-01-31 16:44:13 --> URI Class Initialized
INFO - 2026-01-31 16:44:13 --> URI Class Initialized
INFO - 2026-01-31 16:44:13 --> Loader Class Initialized
INFO - 2026-01-31 16:44:13 --> Router Class Initialized
INFO - 2026-01-31 16:44:13 --> Helper loaded: url_helper
INFO - 2026-01-31 16:44:13 --> Router Class Initialized
INFO - 2026-01-31 16:44:13 --> Output Class Initialized
INFO - 2026-01-31 16:44:13 --> Helper loaded: form_helper
INFO - 2026-01-31 16:44:13 --> Output Class Initialized
INFO - 2026-01-31 16:44:13 --> Helper loaded: html_helper
INFO - 2026-01-31 16:44:13 --> Security Class Initialized
INFO - 2026-01-31 16:44:13 --> Helper loaded: file_helper
INFO - 2026-01-31 16:44:13 --> Helper loaded: email_helper
INFO - 2026-01-31 16:44:13 --> Security Class Initialized
DEBUG - 2026-01-31 16:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:44:13 --> Input Class Initialized
INFO - 2026-01-31 16:44:13 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:44:13 --> Language Class Initialized
DEBUG - 2026-01-31 16:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:44:13 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:44:13 --> Input Class Initialized
INFO - 2026-01-31 16:44:13 --> Language Class Initialized
INFO - 2026-01-31 16:44:13 --> Config Class Initialized
INFO - 2026-01-31 16:44:13 --> Language Class Initialized
INFO - 2026-01-31 16:44:13 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:44:13 --> Language Class Initialized
INFO - 2026-01-31 16:44:13 --> Config Class Initialized
INFO - 2026-01-31 16:44:13 --> Loader Class Initialized
INFO - 2026-01-31 16:44:13 --> Helper loaded: url_helper
INFO - 2026-01-31 16:44:13 --> Loader Class Initialized
INFO - 2026-01-31 16:44:13 --> Helper loaded: form_helper
INFO - 2026-01-31 16:44:13 --> Helper loaded: url_helper
INFO - 2026-01-31 16:44:13 --> Helper loaded: html_helper
INFO - 2026-01-31 16:44:13 --> Helper loaded: file_helper
INFO - 2026-01-31 16:44:13 --> Helper loaded: email_helper
INFO - 2026-01-31 16:44:13 --> Helper loaded: form_helper
INFO - 2026-01-31 16:44:13 --> Helper loaded: html_helper
INFO - 2026-01-31 16:44:13 --> Database Driver Class Initialized
INFO - 2026-01-31 16:44:13 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:44:13 --> Helper loaded: file_helper
INFO - 2026-01-31 16:44:13 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:44:13 --> Helper loaded: email_helper
INFO - 2026-01-31 16:44:13 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:44:13 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:44:13 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:44:13 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:44:13 --> Database Driver Class Initialized
INFO - 2026-01-31 16:44:13 --> Database Driver Class Initialized
INFO - 2026-01-31 16:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:44:16 --> Upload Class Initialized
DEBUG - 2026-01-31 16:44:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:44:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:44:16 --> Encryption Class Initialized
INFO - 2026-01-31 16:44:16 --> Form Validation Class Initialized
INFO - 2026-01-31 16:44:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:44:16 --> Pagination Class Initialized
INFO - 2026-01-31 16:44:16 --> Email Class Initialized
INFO - 2026-01-31 16:44:16 --> Controller Class Initialized
DEBUG - 2026-01-31 16:44:16 --> Tickets MX_Controller Initialized
INFO - 2026-01-31 16:44:16 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:44:16 --> Model "Auth_model" initialized
INFO - 2026-01-31 16:44:16 --> Model "Cart_model" initialized
INFO - 2026-01-31 16:44:16 --> Model "Support_model" initialized
INFO - 2026-01-31 16:44:16 --> Model "Common_model" initialized
INFO - 2026-01-31 16:44:17 --> Final output sent to browser
DEBUG - 2026-01-31 16:44:17 --> Total execution time: 3.4824
INFO - 2026-01-31 16:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:44:17 --> Upload Class Initialized
DEBUG - 2026-01-31 16:44:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:44:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:44:17 --> Encryption Class Initialized
INFO - 2026-01-31 16:44:17 --> Form Validation Class Initialized
INFO - 2026-01-31 16:44:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:44:17 --> Pagination Class Initialized
INFO - 2026-01-31 16:44:17 --> Email Class Initialized
INFO - 2026-01-31 16:44:17 --> Controller Class Initialized
DEBUG - 2026-01-31 16:44:17 --> Clientarea MX_Controller Initialized
INFO - 2026-01-31 16:44:17 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:44:17 --> Model "Auth_model" initialized
INFO - 2026-01-31 16:44:17 --> Model "Cart_model" initialized
INFO - 2026-01-31 16:44:17 --> Model "Clientarea_model" initialized
INFO - 2026-01-31 16:44:17 --> Model "Billing_model" initialized
INFO - 2026-01-31 16:44:17 --> Model "Common_model" initialized
INFO - 2026-01-31 16:44:17 --> Model "Order_model" initialized
INFO - 2026-01-31 16:44:17 --> Model "Support_model" initialized
INFO - 2026-01-31 16:44:18 --> Final output sent to browser
DEBUG - 2026-01-31 16:44:18 --> Total execution time: 4.2911
INFO - 2026-01-31 16:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:44:18 --> Upload Class Initialized
DEBUG - 2026-01-31 16:44:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:44:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:44:18 --> Encryption Class Initialized
INFO - 2026-01-31 16:44:18 --> Form Validation Class Initialized
INFO - 2026-01-31 16:44:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:44:18 --> Pagination Class Initialized
INFO - 2026-01-31 16:44:18 --> Email Class Initialized
INFO - 2026-01-31 16:44:18 --> Controller Class Initialized
DEBUG - 2026-01-31 16:44:18 --> Billing MX_Controller Initialized
INFO - 2026-01-31 16:44:18 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:44:18 --> Model "Auth_model" initialized
INFO - 2026-01-31 16:44:18 --> Model "Cart_model" initialized
INFO - 2026-01-31 16:44:18 --> Model "Billing_model" initialized
INFO - 2026-01-31 16:44:18 --> Model "Common_model" initialized
INFO - 2026-01-31 16:44:18 --> Final output sent to browser
DEBUG - 2026-01-31 16:44:18 --> Total execution time: 5.1050
INFO - 2026-01-31 16:46:10 --> Config Class Initialized
INFO - 2026-01-31 16:46:10 --> Hooks Class Initialized
DEBUG - 2026-01-31 16:46:10 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:46:10 --> Utf8 Class Initialized
INFO - 2026-01-31 16:46:10 --> URI Class Initialized
INFO - 2026-01-31 16:46:10 --> Router Class Initialized
INFO - 2026-01-31 16:46:10 --> Output Class Initialized
INFO - 2026-01-31 16:46:10 --> Security Class Initialized
DEBUG - 2026-01-31 16:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:46:10 --> CSRF cookie sent
INFO - 2026-01-31 16:46:10 --> Input Class Initialized
INFO - 2026-01-31 16:46:10 --> Language Class Initialized
INFO - 2026-01-31 16:46:10 --> Language Class Initialized
INFO - 2026-01-31 16:46:10 --> Config Class Initialized
INFO - 2026-01-31 16:46:10 --> Loader Class Initialized
INFO - 2026-01-31 16:46:10 --> Helper loaded: url_helper
INFO - 2026-01-31 16:46:10 --> Helper loaded: form_helper
INFO - 2026-01-31 16:46:10 --> Helper loaded: html_helper
INFO - 2026-01-31 16:46:10 --> Helper loaded: file_helper
INFO - 2026-01-31 16:46:10 --> Helper loaded: email_helper
INFO - 2026-01-31 16:46:10 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:46:10 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:46:10 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:46:10 --> Database Driver Class Initialized
INFO - 2026-01-31 16:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:46:12 --> Upload Class Initialized
DEBUG - 2026-01-31 16:46:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:46:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:46:12 --> Encryption Class Initialized
INFO - 2026-01-31 16:46:12 --> Form Validation Class Initialized
INFO - 2026-01-31 16:46:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:46:12 --> Pagination Class Initialized
INFO - 2026-01-31 16:46:12 --> Email Class Initialized
INFO - 2026-01-31 16:46:12 --> Controller Class Initialized
DEBUG - 2026-01-31 16:46:12 --> Auth MX_Controller Initialized
INFO - 2026-01-31 16:46:12 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:46:12 --> Model "Auth_model" initialized
INFO - 2026-01-31 16:46:12 --> Model "Cart_model" initialized
INFO - 2026-01-31 16:46:12 --> Model "Appsetting_model" initialized
INFO - 2026-01-31 16:46:12 --> Config Class Initialized
INFO - 2026-01-31 16:46:12 --> Hooks Class Initialized
DEBUG - 2026-01-31 16:46:12 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:46:12 --> Utf8 Class Initialized
INFO - 2026-01-31 16:46:12 --> URI Class Initialized
INFO - 2026-01-31 16:46:12 --> Router Class Initialized
INFO - 2026-01-31 16:46:12 --> Output Class Initialized
INFO - 2026-01-31 16:46:12 --> Security Class Initialized
DEBUG - 2026-01-31 16:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:46:12 --> CSRF cookie sent
INFO - 2026-01-31 16:46:12 --> Input Class Initialized
INFO - 2026-01-31 16:46:12 --> Language Class Initialized
INFO - 2026-01-31 16:46:12 --> Language Class Initialized
INFO - 2026-01-31 16:46:12 --> Config Class Initialized
INFO - 2026-01-31 16:46:12 --> Loader Class Initialized
INFO - 2026-01-31 16:46:12 --> Helper loaded: url_helper
INFO - 2026-01-31 16:46:12 --> Helper loaded: form_helper
INFO - 2026-01-31 16:46:12 --> Helper loaded: html_helper
INFO - 2026-01-31 16:46:12 --> Helper loaded: file_helper
INFO - 2026-01-31 16:46:12 --> Helper loaded: email_helper
INFO - 2026-01-31 16:46:12 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:46:12 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:46:12 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:46:12 --> Database Driver Class Initialized
INFO - 2026-01-31 16:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:46:14 --> Upload Class Initialized
DEBUG - 2026-01-31 16:46:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:46:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:46:14 --> Encryption Class Initialized
INFO - 2026-01-31 16:46:14 --> Form Validation Class Initialized
INFO - 2026-01-31 16:46:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:46:14 --> Pagination Class Initialized
INFO - 2026-01-31 16:46:14 --> Email Class Initialized
INFO - 2026-01-31 16:46:14 --> Controller Class Initialized
DEBUG - 2026-01-31 16:46:14 --> Auth MX_Controller Initialized
INFO - 2026-01-31 16:46:14 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:46:14 --> Model "Auth_model" initialized
INFO - 2026-01-31 16:46:14 --> Model "Cart_model" initialized
INFO - 2026-01-31 16:46:15 --> Model "Appsetting_model" initialized
DEBUG - 2026-01-31 16:46:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 16:46:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 16:46:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 16:46:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-01-31 16:46:15 --> Final output sent to browser
DEBUG - 2026-01-31 16:46:15 --> Total execution time: 2.9116
INFO - 2026-01-31 16:46:21 --> Config Class Initialized
INFO - 2026-01-31 16:46:21 --> Hooks Class Initialized
DEBUG - 2026-01-31 16:46:21 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:46:21 --> Utf8 Class Initialized
INFO - 2026-01-31 16:46:21 --> URI Class Initialized
INFO - 2026-01-31 16:46:21 --> Router Class Initialized
INFO - 2026-01-31 16:46:21 --> Output Class Initialized
INFO - 2026-01-31 16:46:21 --> Security Class Initialized
DEBUG - 2026-01-31 16:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:46:21 --> CSRF cookie sent
INFO - 2026-01-31 16:46:21 --> Input Class Initialized
INFO - 2026-01-31 16:46:21 --> Language Class Initialized
INFO - 2026-01-31 16:46:21 --> Language Class Initialized
INFO - 2026-01-31 16:46:21 --> Config Class Initialized
INFO - 2026-01-31 16:46:21 --> Loader Class Initialized
INFO - 2026-01-31 16:46:21 --> Helper loaded: url_helper
INFO - 2026-01-31 16:46:21 --> Helper loaded: form_helper
INFO - 2026-01-31 16:46:21 --> Helper loaded: html_helper
INFO - 2026-01-31 16:46:21 --> Helper loaded: file_helper
INFO - 2026-01-31 16:46:21 --> Helper loaded: email_helper
INFO - 2026-01-31 16:46:21 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:46:21 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:46:21 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:46:21 --> Database Driver Class Initialized
INFO - 2026-01-31 16:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:46:23 --> Upload Class Initialized
DEBUG - 2026-01-31 16:46:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:46:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:46:23 --> Encryption Class Initialized
INFO - 2026-01-31 16:46:23 --> Form Validation Class Initialized
INFO - 2026-01-31 16:46:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:46:23 --> Pagination Class Initialized
INFO - 2026-01-31 16:46:23 --> Email Class Initialized
INFO - 2026-01-31 16:46:23 --> Controller Class Initialized
DEBUG - 2026-01-31 16:46:23 --> Auth MX_Controller Initialized
INFO - 2026-01-31 16:46:23 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:46:23 --> Model "Auth_model" initialized
INFO - 2026-01-31 16:46:23 --> Model "Cart_model" initialized
INFO - 2026-01-31 16:46:23 --> Model "Appsetting_model" initialized
DEBUG - 2026-01-31 16:46:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 16:46:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 16:46:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 16:46:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_forgetpass.php
INFO - 2026-01-31 16:46:24 --> Final output sent to browser
DEBUG - 2026-01-31 16:46:24 --> Total execution time: 2.4474
INFO - 2026-01-31 16:46:27 --> Config Class Initialized
INFO - 2026-01-31 16:46:27 --> Hooks Class Initialized
DEBUG - 2026-01-31 16:46:27 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:46:27 --> Utf8 Class Initialized
INFO - 2026-01-31 16:46:27 --> URI Class Initialized
INFO - 2026-01-31 16:46:27 --> Router Class Initialized
INFO - 2026-01-31 16:46:27 --> Output Class Initialized
INFO - 2026-01-31 16:46:27 --> Security Class Initialized
DEBUG - 2026-01-31 16:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:46:27 --> CSRF cookie sent
INFO - 2026-01-31 16:46:27 --> CSRF token verified
INFO - 2026-01-31 16:46:27 --> Input Class Initialized
INFO - 2026-01-31 16:46:27 --> Language Class Initialized
INFO - 2026-01-31 16:46:27 --> Language Class Initialized
INFO - 2026-01-31 16:46:27 --> Config Class Initialized
INFO - 2026-01-31 16:46:27 --> Loader Class Initialized
INFO - 2026-01-31 16:46:27 --> Helper loaded: url_helper
INFO - 2026-01-31 16:46:27 --> Helper loaded: form_helper
INFO - 2026-01-31 16:46:27 --> Helper loaded: html_helper
INFO - 2026-01-31 16:46:27 --> Helper loaded: file_helper
INFO - 2026-01-31 16:46:27 --> Helper loaded: email_helper
INFO - 2026-01-31 16:46:27 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:46:27 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:46:27 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:46:27 --> Database Driver Class Initialized
INFO - 2026-01-31 16:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:46:30 --> Upload Class Initialized
DEBUG - 2026-01-31 16:46:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:46:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:46:30 --> Encryption Class Initialized
INFO - 2026-01-31 16:46:30 --> Form Validation Class Initialized
INFO - 2026-01-31 16:46:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:46:30 --> Pagination Class Initialized
INFO - 2026-01-31 16:46:30 --> Email Class Initialized
INFO - 2026-01-31 16:46:30 --> Controller Class Initialized
DEBUG - 2026-01-31 16:46:30 --> Auth MX_Controller Initialized
INFO - 2026-01-31 16:46:30 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:46:30 --> Model "Auth_model" initialized
INFO - 2026-01-31 16:46:30 --> Model "Cart_model" initialized
INFO - 2026-01-31 16:46:30 --> Model "Appsetting_model" initialized
DEBUG - 2026-01-31 16:46:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 16:46:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 16:46:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 16:46:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_forgetpass.php
INFO - 2026-01-31 16:46:39 --> Final output sent to browser
DEBUG - 2026-01-31 16:46:39 --> Total execution time: 11.4930
INFO - 2026-01-31 16:46:50 --> Config Class Initialized
INFO - 2026-01-31 16:46:50 --> Hooks Class Initialized
DEBUG - 2026-01-31 16:46:50 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:46:50 --> Utf8 Class Initialized
INFO - 2026-01-31 16:46:50 --> URI Class Initialized
INFO - 2026-01-31 16:46:50 --> Router Class Initialized
INFO - 2026-01-31 16:46:50 --> Output Class Initialized
INFO - 2026-01-31 16:46:50 --> Security Class Initialized
DEBUG - 2026-01-31 16:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:46:50 --> CSRF cookie sent
INFO - 2026-01-31 16:46:50 --> Input Class Initialized
INFO - 2026-01-31 16:46:50 --> Language Class Initialized
INFO - 2026-01-31 16:46:50 --> Language Class Initialized
INFO - 2026-01-31 16:46:50 --> Config Class Initialized
INFO - 2026-01-31 16:46:50 --> Loader Class Initialized
INFO - 2026-01-31 16:46:50 --> Helper loaded: url_helper
INFO - 2026-01-31 16:46:50 --> Helper loaded: form_helper
INFO - 2026-01-31 16:46:50 --> Helper loaded: html_helper
INFO - 2026-01-31 16:46:50 --> Helper loaded: file_helper
INFO - 2026-01-31 16:46:50 --> Helper loaded: email_helper
INFO - 2026-01-31 16:46:50 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:46:50 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:46:50 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:46:50 --> Database Driver Class Initialized
INFO - 2026-01-31 16:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:46:52 --> Upload Class Initialized
DEBUG - 2026-01-31 16:46:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:46:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:46:52 --> Encryption Class Initialized
INFO - 2026-01-31 16:46:52 --> Form Validation Class Initialized
INFO - 2026-01-31 16:46:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:46:52 --> Pagination Class Initialized
INFO - 2026-01-31 16:46:52 --> Email Class Initialized
INFO - 2026-01-31 16:46:52 --> Controller Class Initialized
DEBUG - 2026-01-31 16:46:52 --> Auth MX_Controller Initialized
INFO - 2026-01-31 16:46:52 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:46:52 --> Model "Auth_model" initialized
INFO - 2026-01-31 16:46:52 --> Model "Cart_model" initialized
INFO - 2026-01-31 16:46:52 --> Model "Appsetting_model" initialized
DEBUG - 2026-01-31 16:46:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 16:46:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 16:46:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 16:46:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_resetpassword.php
INFO - 2026-01-31 16:46:53 --> Final output sent to browser
DEBUG - 2026-01-31 16:46:53 --> Total execution time: 2.6476
INFO - 2026-01-31 16:47:08 --> Config Class Initialized
INFO - 2026-01-31 16:47:08 --> Hooks Class Initialized
DEBUG - 2026-01-31 16:47:08 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:47:08 --> Utf8 Class Initialized
INFO - 2026-01-31 16:47:08 --> URI Class Initialized
INFO - 2026-01-31 16:47:08 --> Router Class Initialized
INFO - 2026-01-31 16:47:08 --> Output Class Initialized
INFO - 2026-01-31 16:47:08 --> Security Class Initialized
DEBUG - 2026-01-31 16:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:47:08 --> CSRF cookie sent
INFO - 2026-01-31 16:47:08 --> CSRF token verified
INFO - 2026-01-31 16:47:08 --> Input Class Initialized
INFO - 2026-01-31 16:47:08 --> Language Class Initialized
INFO - 2026-01-31 16:47:08 --> Language Class Initialized
INFO - 2026-01-31 16:47:08 --> Config Class Initialized
INFO - 2026-01-31 16:47:08 --> Loader Class Initialized
INFO - 2026-01-31 16:47:08 --> Helper loaded: url_helper
INFO - 2026-01-31 16:47:08 --> Helper loaded: form_helper
INFO - 2026-01-31 16:47:08 --> Helper loaded: html_helper
INFO - 2026-01-31 16:47:08 --> Helper loaded: file_helper
INFO - 2026-01-31 16:47:08 --> Helper loaded: email_helper
INFO - 2026-01-31 16:47:08 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:47:08 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:47:08 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:47:08 --> Database Driver Class Initialized
INFO - 2026-01-31 16:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:47:10 --> Upload Class Initialized
DEBUG - 2026-01-31 16:47:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:47:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:47:10 --> Encryption Class Initialized
INFO - 2026-01-31 16:47:10 --> Form Validation Class Initialized
INFO - 2026-01-31 16:47:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:47:10 --> Pagination Class Initialized
INFO - 2026-01-31 16:47:10 --> Email Class Initialized
INFO - 2026-01-31 16:47:10 --> Controller Class Initialized
DEBUG - 2026-01-31 16:47:10 --> Auth MX_Controller Initialized
INFO - 2026-01-31 16:47:10 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:47:10 --> Model "Auth_model" initialized
INFO - 2026-01-31 16:47:10 --> Model "Cart_model" initialized
INFO - 2026-01-31 16:47:10 --> Model "Appsetting_model" initialized
DEBUG - 2026-01-31 16:47:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 16:47:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 16:47:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 16:47:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_resetpassword.php
INFO - 2026-01-31 16:47:11 --> Final output sent to browser
DEBUG - 2026-01-31 16:47:11 --> Total execution time: 2.8390
INFO - 2026-01-31 16:47:28 --> Config Class Initialized
INFO - 2026-01-31 16:47:28 --> Hooks Class Initialized
DEBUG - 2026-01-31 16:47:28 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:47:28 --> Utf8 Class Initialized
INFO - 2026-01-31 16:47:28 --> URI Class Initialized
INFO - 2026-01-31 16:47:28 --> Router Class Initialized
INFO - 2026-01-31 16:47:28 --> Output Class Initialized
INFO - 2026-01-31 16:47:28 --> Security Class Initialized
DEBUG - 2026-01-31 16:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:47:28 --> CSRF cookie sent
INFO - 2026-01-31 16:47:28 --> CSRF token verified
INFO - 2026-01-31 16:47:28 --> Input Class Initialized
INFO - 2026-01-31 16:47:28 --> Language Class Initialized
INFO - 2026-01-31 16:47:28 --> Language Class Initialized
INFO - 2026-01-31 16:47:28 --> Config Class Initialized
INFO - 2026-01-31 16:47:28 --> Loader Class Initialized
INFO - 2026-01-31 16:47:28 --> Helper loaded: url_helper
INFO - 2026-01-31 16:47:28 --> Helper loaded: form_helper
INFO - 2026-01-31 16:47:28 --> Helper loaded: html_helper
INFO - 2026-01-31 16:47:28 --> Helper loaded: file_helper
INFO - 2026-01-31 16:47:28 --> Helper loaded: email_helper
INFO - 2026-01-31 16:47:28 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:47:28 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:47:28 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:47:28 --> Database Driver Class Initialized
INFO - 2026-01-31 16:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:47:31 --> Upload Class Initialized
DEBUG - 2026-01-31 16:47:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:47:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:47:31 --> Encryption Class Initialized
INFO - 2026-01-31 16:47:31 --> Form Validation Class Initialized
INFO - 2026-01-31 16:47:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:47:31 --> Pagination Class Initialized
INFO - 2026-01-31 16:47:31 --> Email Class Initialized
INFO - 2026-01-31 16:47:31 --> Controller Class Initialized
DEBUG - 2026-01-31 16:47:31 --> Auth MX_Controller Initialized
INFO - 2026-01-31 16:47:31 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:47:31 --> Model "Auth_model" initialized
INFO - 2026-01-31 16:47:31 --> Model "Cart_model" initialized
INFO - 2026-01-31 16:47:31 --> Model "Appsetting_model" initialized
INFO - 2026-01-31 16:47:32 --> Config Class Initialized
INFO - 2026-01-31 16:47:32 --> Hooks Class Initialized
DEBUG - 2026-01-31 16:47:32 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:47:32 --> Utf8 Class Initialized
INFO - 2026-01-31 16:47:32 --> URI Class Initialized
INFO - 2026-01-31 16:47:32 --> Router Class Initialized
INFO - 2026-01-31 16:47:32 --> Output Class Initialized
INFO - 2026-01-31 16:47:32 --> Security Class Initialized
DEBUG - 2026-01-31 16:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:47:32 --> CSRF cookie sent
INFO - 2026-01-31 16:47:32 --> Input Class Initialized
INFO - 2026-01-31 16:47:32 --> Language Class Initialized
INFO - 2026-01-31 16:47:32 --> Language Class Initialized
INFO - 2026-01-31 16:47:32 --> Config Class Initialized
INFO - 2026-01-31 16:47:32 --> Loader Class Initialized
INFO - 2026-01-31 16:47:32 --> Helper loaded: url_helper
INFO - 2026-01-31 16:47:32 --> Helper loaded: form_helper
INFO - 2026-01-31 16:47:32 --> Helper loaded: html_helper
INFO - 2026-01-31 16:47:32 --> Helper loaded: file_helper
INFO - 2026-01-31 16:47:32 --> Helper loaded: email_helper
INFO - 2026-01-31 16:47:32 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:47:32 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:47:32 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:47:32 --> Database Driver Class Initialized
INFO - 2026-01-31 16:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:47:34 --> Upload Class Initialized
DEBUG - 2026-01-31 16:47:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:47:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:47:34 --> Encryption Class Initialized
INFO - 2026-01-31 16:47:34 --> Form Validation Class Initialized
INFO - 2026-01-31 16:47:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:47:34 --> Pagination Class Initialized
INFO - 2026-01-31 16:47:34 --> Email Class Initialized
INFO - 2026-01-31 16:47:34 --> Controller Class Initialized
DEBUG - 2026-01-31 16:47:34 --> Auth MX_Controller Initialized
INFO - 2026-01-31 16:47:34 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:47:34 --> Model "Auth_model" initialized
INFO - 2026-01-31 16:47:34 --> Model "Cart_model" initialized
INFO - 2026-01-31 16:47:34 --> Model "Appsetting_model" initialized
DEBUG - 2026-01-31 16:47:35 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 16:47:35 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 16:47:35 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 16:47:35 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-01-31 16:47:35 --> Final output sent to browser
DEBUG - 2026-01-31 16:47:35 --> Total execution time: 3.2621
INFO - 2026-01-31 16:47:41 --> Config Class Initialized
INFO - 2026-01-31 16:47:41 --> Hooks Class Initialized
DEBUG - 2026-01-31 16:47:41 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:47:41 --> Utf8 Class Initialized
INFO - 2026-01-31 16:47:41 --> URI Class Initialized
INFO - 2026-01-31 16:47:41 --> Router Class Initialized
INFO - 2026-01-31 16:47:41 --> Output Class Initialized
INFO - 2026-01-31 16:47:41 --> Security Class Initialized
DEBUG - 2026-01-31 16:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:47:41 --> CSRF cookie sent
INFO - 2026-01-31 16:47:41 --> CSRF token verified
INFO - 2026-01-31 16:47:41 --> Input Class Initialized
INFO - 2026-01-31 16:47:41 --> Language Class Initialized
INFO - 2026-01-31 16:47:41 --> Language Class Initialized
INFO - 2026-01-31 16:47:41 --> Config Class Initialized
INFO - 2026-01-31 16:47:41 --> Loader Class Initialized
INFO - 2026-01-31 16:47:41 --> Helper loaded: url_helper
INFO - 2026-01-31 16:47:41 --> Helper loaded: form_helper
INFO - 2026-01-31 16:47:41 --> Helper loaded: html_helper
INFO - 2026-01-31 16:47:41 --> Helper loaded: file_helper
INFO - 2026-01-31 16:47:41 --> Helper loaded: email_helper
INFO - 2026-01-31 16:47:41 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:47:41 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:47:41 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:47:41 --> Database Driver Class Initialized
INFO - 2026-01-31 16:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:47:43 --> Upload Class Initialized
DEBUG - 2026-01-31 16:47:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:47:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:47:43 --> Encryption Class Initialized
INFO - 2026-01-31 16:47:43 --> Form Validation Class Initialized
INFO - 2026-01-31 16:47:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:47:43 --> Pagination Class Initialized
INFO - 2026-01-31 16:47:43 --> Email Class Initialized
INFO - 2026-01-31 16:47:43 --> Controller Class Initialized
DEBUG - 2026-01-31 16:47:43 --> Auth MX_Controller Initialized
INFO - 2026-01-31 16:47:43 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:47:43 --> Model "Auth_model" initialized
INFO - 2026-01-31 16:47:43 --> Model "Cart_model" initialized
INFO - 2026-01-31 16:47:43 --> Model "Appsetting_model" initialized
INFO - 2026-01-31 16:47:46 --> Config Class Initialized
INFO - 2026-01-31 16:47:46 --> Hooks Class Initialized
DEBUG - 2026-01-31 16:47:46 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:47:46 --> Utf8 Class Initialized
INFO - 2026-01-31 16:47:46 --> URI Class Initialized
INFO - 2026-01-31 16:47:46 --> Router Class Initialized
INFO - 2026-01-31 16:47:46 --> Output Class Initialized
INFO - 2026-01-31 16:47:46 --> Security Class Initialized
DEBUG - 2026-01-31 16:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:47:46 --> CSRF cookie sent
INFO - 2026-01-31 16:47:46 --> Input Class Initialized
INFO - 2026-01-31 16:47:46 --> Language Class Initialized
INFO - 2026-01-31 16:47:46 --> Language Class Initialized
INFO - 2026-01-31 16:47:46 --> Config Class Initialized
INFO - 2026-01-31 16:47:46 --> Loader Class Initialized
INFO - 2026-01-31 16:47:46 --> Helper loaded: url_helper
INFO - 2026-01-31 16:47:46 --> Helper loaded: form_helper
INFO - 2026-01-31 16:47:46 --> Helper loaded: html_helper
INFO - 2026-01-31 16:47:46 --> Helper loaded: file_helper
INFO - 2026-01-31 16:47:46 --> Helper loaded: email_helper
INFO - 2026-01-31 16:47:46 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:47:46 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:47:46 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:47:46 --> Database Driver Class Initialized
INFO - 2026-01-31 16:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:47:48 --> Upload Class Initialized
DEBUG - 2026-01-31 16:47:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:47:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:47:48 --> Encryption Class Initialized
INFO - 2026-01-31 16:47:48 --> Form Validation Class Initialized
INFO - 2026-01-31 16:47:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:47:48 --> Pagination Class Initialized
INFO - 2026-01-31 16:47:48 --> Email Class Initialized
INFO - 2026-01-31 16:47:48 --> Controller Class Initialized
DEBUG - 2026-01-31 16:47:48 --> Clientarea MX_Controller Initialized
INFO - 2026-01-31 16:47:48 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:47:48 --> Model "Auth_model" initialized
INFO - 2026-01-31 16:47:48 --> Model "Cart_model" initialized
INFO - 2026-01-31 16:47:48 --> Model "Clientarea_model" initialized
INFO - 2026-01-31 16:47:48 --> Model "Billing_model" initialized
INFO - 2026-01-31 16:47:48 --> Model "Common_model" initialized
INFO - 2026-01-31 16:47:48 --> Model "Order_model" initialized
INFO - 2026-01-31 16:47:48 --> Model "Support_model" initialized
DEBUG - 2026-01-31 16:47:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 16:47:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 16:47:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 16:47:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_index.php
INFO - 2026-01-31 16:47:49 --> Final output sent to browser
DEBUG - 2026-01-31 16:47:49 --> Total execution time: 2.3954
INFO - 2026-01-31 16:47:49 --> Config Class Initialized
INFO - 2026-01-31 16:47:49 --> Hooks Class Initialized
INFO - 2026-01-31 16:47:49 --> Config Class Initialized
INFO - 2026-01-31 16:47:49 --> Hooks Class Initialized
INFO - 2026-01-31 16:47:49 --> Config Class Initialized
INFO - 2026-01-31 16:47:49 --> Hooks Class Initialized
DEBUG - 2026-01-31 16:47:49 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:47:49 --> Utf8 Class Initialized
DEBUG - 2026-01-31 16:47:49 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:47:49 --> Utf8 Class Initialized
INFO - 2026-01-31 16:47:49 --> URI Class Initialized
DEBUG - 2026-01-31 16:47:49 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:47:49 --> Utf8 Class Initialized
INFO - 2026-01-31 16:47:49 --> URI Class Initialized
INFO - 2026-01-31 16:47:49 --> Router Class Initialized
INFO - 2026-01-31 16:47:49 --> URI Class Initialized
INFO - 2026-01-31 16:47:49 --> Router Class Initialized
INFO - 2026-01-31 16:47:49 --> Output Class Initialized
INFO - 2026-01-31 16:47:49 --> Router Class Initialized
INFO - 2026-01-31 16:47:49 --> Output Class Initialized
INFO - 2026-01-31 16:47:49 --> Security Class Initialized
INFO - 2026-01-31 16:47:49 --> Security Class Initialized
INFO - 2026-01-31 16:47:49 --> Output Class Initialized
DEBUG - 2026-01-31 16:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:47:49 --> Input Class Initialized
DEBUG - 2026-01-31 16:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:47:49 --> Input Class Initialized
INFO - 2026-01-31 16:47:49 --> Language Class Initialized
INFO - 2026-01-31 16:47:49 --> Language Class Initialized
INFO - 2026-01-31 16:47:49 --> Security Class Initialized
INFO - 2026-01-31 16:47:49 --> Language Class Initialized
INFO - 2026-01-31 16:47:49 --> Config Class Initialized
INFO - 2026-01-31 16:47:49 --> Language Class Initialized
INFO - 2026-01-31 16:47:49 --> Config Class Initialized
DEBUG - 2026-01-31 16:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:47:49 --> Input Class Initialized
INFO - 2026-01-31 16:47:49 --> Language Class Initialized
INFO - 2026-01-31 16:47:49 --> Language Class Initialized
INFO - 2026-01-31 16:47:49 --> Config Class Initialized
INFO - 2026-01-31 16:47:49 --> Loader Class Initialized
INFO - 2026-01-31 16:47:49 --> Loader Class Initialized
INFO - 2026-01-31 16:47:49 --> Helper loaded: url_helper
INFO - 2026-01-31 16:47:49 --> Helper loaded: url_helper
INFO - 2026-01-31 16:47:49 --> Helper loaded: form_helper
INFO - 2026-01-31 16:47:49 --> Helper loaded: html_helper
INFO - 2026-01-31 16:47:49 --> Loader Class Initialized
INFO - 2026-01-31 16:47:49 --> Helper loaded: file_helper
INFO - 2026-01-31 16:47:49 --> Helper loaded: email_helper
INFO - 2026-01-31 16:47:49 --> Helper loaded: form_helper
INFO - 2026-01-31 16:47:49 --> Helper loaded: url_helper
INFO - 2026-01-31 16:47:49 --> Helper loaded: html_helper
INFO - 2026-01-31 16:47:49 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:47:49 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:47:49 --> Helper loaded: file_helper
INFO - 2026-01-31 16:47:49 --> Helper loaded: email_helper
INFO - 2026-01-31 16:47:49 --> Helper loaded: form_helper
INFO - 2026-01-31 16:47:49 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:47:49 --> Helper loaded: html_helper
INFO - 2026-01-31 16:47:49 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:47:49 --> Helper loaded: file_helper
INFO - 2026-01-31 16:47:49 --> Helper loaded: email_helper
INFO - 2026-01-31 16:47:49 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:47:49 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:47:49 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:47:49 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:47:49 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:47:49 --> Database Driver Class Initialized
INFO - 2026-01-31 16:47:49 --> Database Driver Class Initialized
INFO - 2026-01-31 16:47:49 --> Database Driver Class Initialized
INFO - 2026-01-31 16:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:47:51 --> Upload Class Initialized
DEBUG - 2026-01-31 16:47:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:47:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:47:51 --> Encryption Class Initialized
INFO - 2026-01-31 16:47:51 --> Form Validation Class Initialized
INFO - 2026-01-31 16:47:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:47:51 --> Pagination Class Initialized
INFO - 2026-01-31 16:47:51 --> Email Class Initialized
INFO - 2026-01-31 16:47:51 --> Controller Class Initialized
DEBUG - 2026-01-31 16:47:51 --> Clientarea MX_Controller Initialized
INFO - 2026-01-31 16:47:51 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:47:51 --> Model "Auth_model" initialized
INFO - 2026-01-31 16:47:51 --> Model "Cart_model" initialized
INFO - 2026-01-31 16:47:51 --> Model "Clientarea_model" initialized
INFO - 2026-01-31 16:47:51 --> Model "Billing_model" initialized
INFO - 2026-01-31 16:47:51 --> Model "Common_model" initialized
INFO - 2026-01-31 16:47:51 --> Model "Order_model" initialized
INFO - 2026-01-31 16:47:51 --> Model "Support_model" initialized
INFO - 2026-01-31 16:47:52 --> Final output sent to browser
DEBUG - 2026-01-31 16:47:52 --> Total execution time: 2.6816
INFO - 2026-01-31 16:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:47:52 --> Upload Class Initialized
DEBUG - 2026-01-31 16:47:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:47:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:47:52 --> Encryption Class Initialized
INFO - 2026-01-31 16:47:52 --> Form Validation Class Initialized
INFO - 2026-01-31 16:47:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:47:52 --> Pagination Class Initialized
INFO - 2026-01-31 16:47:52 --> Email Class Initialized
INFO - 2026-01-31 16:47:52 --> Controller Class Initialized
DEBUG - 2026-01-31 16:47:52 --> Tickets MX_Controller Initialized
INFO - 2026-01-31 16:47:52 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:47:52 --> Model "Auth_model" initialized
INFO - 2026-01-31 16:47:52 --> Model "Cart_model" initialized
INFO - 2026-01-31 16:47:52 --> Model "Support_model" initialized
INFO - 2026-01-31 16:47:52 --> Model "Common_model" initialized
INFO - 2026-01-31 16:47:52 --> Final output sent to browser
DEBUG - 2026-01-31 16:47:52 --> Total execution time: 3.3996
INFO - 2026-01-31 16:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:47:52 --> Upload Class Initialized
DEBUG - 2026-01-31 16:47:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:47:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:47:52 --> Encryption Class Initialized
INFO - 2026-01-31 16:47:52 --> Form Validation Class Initialized
INFO - 2026-01-31 16:47:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:47:52 --> Pagination Class Initialized
INFO - 2026-01-31 16:47:52 --> Email Class Initialized
INFO - 2026-01-31 16:47:52 --> Controller Class Initialized
DEBUG - 2026-01-31 16:47:52 --> Billing MX_Controller Initialized
INFO - 2026-01-31 16:47:52 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:47:52 --> Model "Auth_model" initialized
INFO - 2026-01-31 16:47:52 --> Model "Cart_model" initialized
INFO - 2026-01-31 16:47:52 --> Model "Billing_model" initialized
INFO - 2026-01-31 16:47:52 --> Model "Common_model" initialized
INFO - 2026-01-31 16:47:53 --> Final output sent to browser
DEBUG - 2026-01-31 16:47:53 --> Total execution time: 4.2187
INFO - 2026-01-31 16:51:32 --> Config Class Initialized
INFO - 2026-01-31 16:51:32 --> Hooks Class Initialized
DEBUG - 2026-01-31 16:51:32 --> UTF-8 Support Enabled
INFO - 2026-01-31 16:51:32 --> Utf8 Class Initialized
INFO - 2026-01-31 16:51:32 --> URI Class Initialized
INFO - 2026-01-31 16:51:32 --> Router Class Initialized
INFO - 2026-01-31 16:51:32 --> Output Class Initialized
INFO - 2026-01-31 16:51:32 --> Security Class Initialized
DEBUG - 2026-01-31 16:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 16:51:32 --> CSRF cookie sent
INFO - 2026-01-31 16:51:32 --> Input Class Initialized
INFO - 2026-01-31 16:51:32 --> Language Class Initialized
INFO - 2026-01-31 16:51:32 --> Language Class Initialized
INFO - 2026-01-31 16:51:32 --> Config Class Initialized
INFO - 2026-01-31 16:51:32 --> Loader Class Initialized
INFO - 2026-01-31 16:51:32 --> Helper loaded: url_helper
INFO - 2026-01-31 16:51:32 --> Helper loaded: form_helper
INFO - 2026-01-31 16:51:32 --> Helper loaded: html_helper
INFO - 2026-01-31 16:51:32 --> Helper loaded: file_helper
INFO - 2026-01-31 16:51:32 --> Helper loaded: email_helper
INFO - 2026-01-31 16:51:32 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 16:51:32 --> Helper loaded: ssp_helper
INFO - 2026-01-31 16:51:32 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 16:51:32 --> Database Driver Class Initialized
INFO - 2026-01-31 16:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 16:51:34 --> Upload Class Initialized
DEBUG - 2026-01-31 16:51:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 16:51:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 16:51:34 --> Encryption Class Initialized
INFO - 2026-01-31 16:51:34 --> Form Validation Class Initialized
INFO - 2026-01-31 16:51:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 16:51:34 --> Pagination Class Initialized
INFO - 2026-01-31 16:51:34 --> Email Class Initialized
INFO - 2026-01-31 16:51:34 --> Controller Class Initialized
DEBUG - 2026-01-31 16:51:34 --> Dashboard MX_Controller Initialized
INFO - 2026-01-31 16:51:34 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 16:51:34 --> Model "Adminauth_model" initialized
INFO - 2026-01-31 17:02:25 --> Config Class Initialized
INFO - 2026-01-31 17:02:25 --> Hooks Class Initialized
DEBUG - 2026-01-31 17:02:25 --> UTF-8 Support Enabled
INFO - 2026-01-31 17:02:25 --> Utf8 Class Initialized
INFO - 2026-01-31 17:02:25 --> URI Class Initialized
INFO - 2026-01-31 17:02:25 --> Router Class Initialized
INFO - 2026-01-31 17:02:25 --> Output Class Initialized
INFO - 2026-01-31 17:02:25 --> Security Class Initialized
DEBUG - 2026-01-31 17:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 17:02:25 --> CSRF cookie sent
INFO - 2026-01-31 17:02:25 --> Input Class Initialized
INFO - 2026-01-31 17:02:25 --> Language Class Initialized
INFO - 2026-01-31 17:02:25 --> Language Class Initialized
INFO - 2026-01-31 17:02:25 --> Config Class Initialized
INFO - 2026-01-31 17:02:25 --> Loader Class Initialized
INFO - 2026-01-31 17:02:25 --> Helper loaded: url_helper
INFO - 2026-01-31 17:02:25 --> Helper loaded: form_helper
INFO - 2026-01-31 17:02:25 --> Helper loaded: html_helper
INFO - 2026-01-31 17:02:25 --> Helper loaded: file_helper
INFO - 2026-01-31 17:02:25 --> Helper loaded: email_helper
INFO - 2026-01-31 17:02:25 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 17:02:25 --> Helper loaded: ssp_helper
INFO - 2026-01-31 17:02:25 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 17:02:25 --> Database Driver Class Initialized
INFO - 2026-01-31 17:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 17:02:27 --> Upload Class Initialized
DEBUG - 2026-01-31 17:02:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 17:02:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 17:02:27 --> Encryption Class Initialized
INFO - 2026-01-31 17:02:27 --> Form Validation Class Initialized
INFO - 2026-01-31 17:02:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 17:02:27 --> Pagination Class Initialized
INFO - 2026-01-31 17:02:27 --> Email Class Initialized
INFO - 2026-01-31 17:02:27 --> Controller Class Initialized
DEBUG - 2026-01-31 17:02:27 --> Auth MX_Controller Initialized
INFO - 2026-01-31 17:02:27 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 17:02:27 --> Model "Auth_model" initialized
INFO - 2026-01-31 17:02:27 --> Model "Cart_model" initialized
INFO - 2026-01-31 17:02:27 --> Model "Appsetting_model" initialized
DEBUG - 2026-01-31 17:02:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 17:02:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 17:02:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 17:02:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-01-31 17:02:27 --> Final output sent to browser
DEBUG - 2026-01-31 17:02:27 --> Total execution time: 1.9803
INFO - 2026-01-31 17:02:29 --> Config Class Initialized
INFO - 2026-01-31 17:02:29 --> Hooks Class Initialized
DEBUG - 2026-01-31 17:02:29 --> UTF-8 Support Enabled
INFO - 2026-01-31 17:02:29 --> Utf8 Class Initialized
INFO - 2026-01-31 17:02:29 --> URI Class Initialized
INFO - 2026-01-31 17:02:29 --> Router Class Initialized
INFO - 2026-01-31 17:02:29 --> Output Class Initialized
INFO - 2026-01-31 17:02:29 --> Security Class Initialized
DEBUG - 2026-01-31 17:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 17:02:29 --> CSRF cookie sent
INFO - 2026-01-31 17:02:29 --> Input Class Initialized
INFO - 2026-01-31 17:02:29 --> Language Class Initialized
INFO - 2026-01-31 17:02:29 --> Language Class Initialized
INFO - 2026-01-31 17:02:29 --> Config Class Initialized
INFO - 2026-01-31 17:02:29 --> Loader Class Initialized
INFO - 2026-01-31 17:02:29 --> Helper loaded: url_helper
INFO - 2026-01-31 17:02:29 --> Helper loaded: form_helper
INFO - 2026-01-31 17:02:29 --> Helper loaded: html_helper
INFO - 2026-01-31 17:02:29 --> Helper loaded: file_helper
INFO - 2026-01-31 17:02:29 --> Helper loaded: email_helper
INFO - 2026-01-31 17:02:29 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 17:02:29 --> Helper loaded: ssp_helper
INFO - 2026-01-31 17:02:29 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 17:02:29 --> Database Driver Class Initialized
INFO - 2026-01-31 17:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 17:02:31 --> Upload Class Initialized
DEBUG - 2026-01-31 17:02:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 17:02:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 17:02:31 --> Encryption Class Initialized
INFO - 2026-01-31 17:02:31 --> Form Validation Class Initialized
INFO - 2026-01-31 17:02:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 17:02:31 --> Pagination Class Initialized
INFO - 2026-01-31 17:02:31 --> Email Class Initialized
INFO - 2026-01-31 17:02:31 --> Controller Class Initialized
DEBUG - 2026-01-31 17:02:31 --> Auth MX_Controller Initialized
INFO - 2026-01-31 17:02:31 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 17:02:31 --> Model "Auth_model" initialized
INFO - 2026-01-31 17:02:31 --> Model "Cart_model" initialized
INFO - 2026-01-31 17:02:31 --> Model "Appsetting_model" initialized
DEBUG - 2026-01-31 17:02:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 17:02:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 17:02:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 17:02:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_register.php
INFO - 2026-01-31 17:02:32 --> Final output sent to browser
DEBUG - 2026-01-31 17:02:32 --> Total execution time: 2.9108
INFO - 2026-01-31 17:34:21 --> Config Class Initialized
INFO - 2026-01-31 17:34:21 --> Hooks Class Initialized
DEBUG - 2026-01-31 17:34:21 --> UTF-8 Support Enabled
INFO - 2026-01-31 17:34:21 --> Utf8 Class Initialized
INFO - 2026-01-31 17:34:21 --> URI Class Initialized
INFO - 2026-01-31 17:34:21 --> Router Class Initialized
INFO - 2026-01-31 17:34:21 --> Output Class Initialized
INFO - 2026-01-31 17:34:21 --> Security Class Initialized
DEBUG - 2026-01-31 17:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 17:34:21 --> CSRF cookie sent
INFO - 2026-01-31 17:34:21 --> Input Class Initialized
INFO - 2026-01-31 17:34:21 --> Language Class Initialized
INFO - 2026-01-31 17:34:21 --> Language Class Initialized
INFO - 2026-01-31 17:34:21 --> Config Class Initialized
INFO - 2026-01-31 17:34:21 --> Loader Class Initialized
INFO - 2026-01-31 17:34:21 --> Helper loaded: url_helper
INFO - 2026-01-31 17:34:21 --> Helper loaded: form_helper
INFO - 2026-01-31 17:34:21 --> Helper loaded: html_helper
INFO - 2026-01-31 17:34:21 --> Helper loaded: file_helper
INFO - 2026-01-31 17:34:21 --> Helper loaded: email_helper
INFO - 2026-01-31 17:34:21 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 17:34:21 --> Helper loaded: ssp_helper
INFO - 2026-01-31 17:34:21 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 17:34:21 --> Database Driver Class Initialized
INFO - 2026-01-31 17:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 17:34:23 --> Upload Class Initialized
DEBUG - 2026-01-31 17:34:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 17:34:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 17:34:23 --> Encryption Class Initialized
INFO - 2026-01-31 17:34:23 --> Form Validation Class Initialized
INFO - 2026-01-31 17:34:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 17:34:23 --> Pagination Class Initialized
INFO - 2026-01-31 17:34:23 --> Email Class Initialized
INFO - 2026-01-31 17:34:23 --> Controller Class Initialized
DEBUG - 2026-01-31 17:34:23 --> Clientarea MX_Controller Initialized
INFO - 2026-01-31 17:34:23 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 17:34:23 --> Model "Auth_model" initialized
INFO - 2026-01-31 17:34:23 --> Model "Cart_model" initialized
INFO - 2026-01-31 17:34:23 --> Model "Clientarea_model" initialized
INFO - 2026-01-31 17:34:23 --> Model "Billing_model" initialized
INFO - 2026-01-31 17:34:23 --> Model "Common_model" initialized
INFO - 2026-01-31 17:34:23 --> Model "Order_model" initialized
INFO - 2026-01-31 17:34:23 --> Model "Support_model" initialized
DEBUG - 2026-01-31 17:34:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 17:34:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 17:34:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 17:34:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_index.php
INFO - 2026-01-31 17:34:24 --> Final output sent to browser
DEBUG - 2026-01-31 17:34:24 --> Total execution time: 2.6052
INFO - 2026-01-31 17:34:24 --> Config Class Initialized
INFO - 2026-01-31 17:34:24 --> Config Class Initialized
INFO - 2026-01-31 17:34:24 --> Hooks Class Initialized
INFO - 2026-01-31 17:34:24 --> Hooks Class Initialized
INFO - 2026-01-31 17:34:24 --> Config Class Initialized
INFO - 2026-01-31 17:34:24 --> Hooks Class Initialized
DEBUG - 2026-01-31 17:34:24 --> UTF-8 Support Enabled
DEBUG - 2026-01-31 17:34:24 --> UTF-8 Support Enabled
INFO - 2026-01-31 17:34:24 --> Utf8 Class Initialized
INFO - 2026-01-31 17:34:24 --> Utf8 Class Initialized
DEBUG - 2026-01-31 17:34:24 --> UTF-8 Support Enabled
INFO - 2026-01-31 17:34:24 --> Utf8 Class Initialized
INFO - 2026-01-31 17:34:24 --> URI Class Initialized
INFO - 2026-01-31 17:34:24 --> URI Class Initialized
INFO - 2026-01-31 17:34:24 --> URI Class Initialized
INFO - 2026-01-31 17:34:24 --> Router Class Initialized
INFO - 2026-01-31 17:34:24 --> Router Class Initialized
INFO - 2026-01-31 17:34:24 --> Router Class Initialized
INFO - 2026-01-31 17:34:24 --> Output Class Initialized
INFO - 2026-01-31 17:34:24 --> Output Class Initialized
INFO - 2026-01-31 17:34:24 --> Security Class Initialized
INFO - 2026-01-31 17:34:24 --> Output Class Initialized
DEBUG - 2026-01-31 17:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 17:34:24 --> Security Class Initialized
INFO - 2026-01-31 17:34:24 --> Input Class Initialized
INFO - 2026-01-31 17:34:24 --> Language Class Initialized
INFO - 2026-01-31 17:34:24 --> Security Class Initialized
DEBUG - 2026-01-31 17:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 17:34:24 --> Input Class Initialized
INFO - 2026-01-31 17:34:24 --> Language Class Initialized
INFO - 2026-01-31 17:34:24 --> Config Class Initialized
INFO - 2026-01-31 17:34:24 --> Language Class Initialized
DEBUG - 2026-01-31 17:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 17:34:24 --> Input Class Initialized
INFO - 2026-01-31 17:34:24 --> Language Class Initialized
INFO - 2026-01-31 17:34:24 --> Config Class Initialized
INFO - 2026-01-31 17:34:24 --> Language Class Initialized
INFO - 2026-01-31 17:34:24 --> Language Class Initialized
INFO - 2026-01-31 17:34:24 --> Config Class Initialized
INFO - 2026-01-31 17:34:24 --> Loader Class Initialized
INFO - 2026-01-31 17:34:24 --> Helper loaded: url_helper
INFO - 2026-01-31 17:34:24 --> Helper loaded: form_helper
INFO - 2026-01-31 17:34:24 --> Loader Class Initialized
INFO - 2026-01-31 17:34:24 --> Helper loaded: html_helper
INFO - 2026-01-31 17:34:24 --> Helper loaded: file_helper
INFO - 2026-01-31 17:34:24 --> Helper loaded: email_helper
INFO - 2026-01-31 17:34:24 --> Helper loaded: url_helper
INFO - 2026-01-31 17:34:24 --> Loader Class Initialized
INFO - 2026-01-31 17:34:24 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 17:34:24 --> Helper loaded: url_helper
INFO - 2026-01-31 17:34:24 --> Helper loaded: ssp_helper
INFO - 2026-01-31 17:34:24 --> Helper loaded: form_helper
INFO - 2026-01-31 17:34:24 --> Helper loaded: html_helper
INFO - 2026-01-31 17:34:24 --> Helper loaded: form_helper
INFO - 2026-01-31 17:34:24 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 17:34:24 --> Helper loaded: file_helper
INFO - 2026-01-31 17:34:24 --> Helper loaded: email_helper
INFO - 2026-01-31 17:34:24 --> Helper loaded: html_helper
INFO - 2026-01-31 17:34:24 --> Helper loaded: file_helper
INFO - 2026-01-31 17:34:24 --> Helper loaded: email_helper
INFO - 2026-01-31 17:34:24 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 17:34:24 --> Helper loaded: ssp_helper
INFO - 2026-01-31 17:34:24 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 17:34:24 --> Helper loaded: ssp_helper
INFO - 2026-01-31 17:34:24 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 17:34:24 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 17:34:24 --> Database Driver Class Initialized
INFO - 2026-01-31 17:34:24 --> Database Driver Class Initialized
INFO - 2026-01-31 17:34:24 --> Database Driver Class Initialized
INFO - 2026-01-31 17:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 17:34:26 --> Upload Class Initialized
DEBUG - 2026-01-31 17:34:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 17:34:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 17:34:26 --> Encryption Class Initialized
INFO - 2026-01-31 17:34:26 --> Form Validation Class Initialized
INFO - 2026-01-31 17:34:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 17:34:26 --> Pagination Class Initialized
INFO - 2026-01-31 17:34:26 --> Email Class Initialized
INFO - 2026-01-31 17:34:26 --> Controller Class Initialized
DEBUG - 2026-01-31 17:34:26 --> Billing MX_Controller Initialized
INFO - 2026-01-31 17:34:26 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 17:34:26 --> Model "Auth_model" initialized
INFO - 2026-01-31 17:34:26 --> Model "Cart_model" initialized
INFO - 2026-01-31 17:34:26 --> Model "Billing_model" initialized
INFO - 2026-01-31 17:34:26 --> Model "Common_model" initialized
INFO - 2026-01-31 17:34:27 --> Final output sent to browser
DEBUG - 2026-01-31 17:34:27 --> Total execution time: 2.7698
INFO - 2026-01-31 17:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 17:34:27 --> Upload Class Initialized
DEBUG - 2026-01-31 17:34:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 17:34:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 17:34:27 --> Encryption Class Initialized
INFO - 2026-01-31 17:34:27 --> Form Validation Class Initialized
INFO - 2026-01-31 17:34:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 17:34:27 --> Pagination Class Initialized
INFO - 2026-01-31 17:34:27 --> Email Class Initialized
INFO - 2026-01-31 17:34:27 --> Controller Class Initialized
DEBUG - 2026-01-31 17:34:27 --> Clientarea MX_Controller Initialized
INFO - 2026-01-31 17:34:27 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 17:34:27 --> Model "Auth_model" initialized
INFO - 2026-01-31 17:34:27 --> Model "Cart_model" initialized
INFO - 2026-01-31 17:34:27 --> Model "Clientarea_model" initialized
INFO - 2026-01-31 17:34:27 --> Model "Billing_model" initialized
INFO - 2026-01-31 17:34:27 --> Model "Common_model" initialized
INFO - 2026-01-31 17:34:27 --> Model "Order_model" initialized
INFO - 2026-01-31 17:34:27 --> Model "Support_model" initialized
INFO - 2026-01-31 17:34:28 --> Final output sent to browser
DEBUG - 2026-01-31 17:34:28 --> Total execution time: 3.4922
INFO - 2026-01-31 17:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 17:34:28 --> Upload Class Initialized
DEBUG - 2026-01-31 17:34:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 17:34:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 17:34:28 --> Encryption Class Initialized
INFO - 2026-01-31 17:34:28 --> Form Validation Class Initialized
INFO - 2026-01-31 17:34:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 17:34:28 --> Pagination Class Initialized
INFO - 2026-01-31 17:34:28 --> Email Class Initialized
INFO - 2026-01-31 17:34:28 --> Controller Class Initialized
DEBUG - 2026-01-31 17:34:28 --> Tickets MX_Controller Initialized
INFO - 2026-01-31 17:34:28 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 17:34:28 --> Model "Auth_model" initialized
INFO - 2026-01-31 17:34:28 --> Model "Cart_model" initialized
INFO - 2026-01-31 17:34:28 --> Model "Support_model" initialized
INFO - 2026-01-31 17:34:28 --> Model "Common_model" initialized
INFO - 2026-01-31 17:34:28 --> Final output sent to browser
DEBUG - 2026-01-31 17:34:28 --> Total execution time: 4.3134
INFO - 2026-01-31 17:34:40 --> Config Class Initialized
INFO - 2026-01-31 17:34:40 --> Hooks Class Initialized
DEBUG - 2026-01-31 17:34:40 --> UTF-8 Support Enabled
INFO - 2026-01-31 17:34:40 --> Utf8 Class Initialized
INFO - 2026-01-31 17:34:40 --> URI Class Initialized
INFO - 2026-01-31 17:34:40 --> Router Class Initialized
INFO - 2026-01-31 17:34:40 --> Output Class Initialized
INFO - 2026-01-31 17:34:40 --> Security Class Initialized
DEBUG - 2026-01-31 17:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 17:34:40 --> CSRF cookie sent
INFO - 2026-01-31 17:34:40 --> Input Class Initialized
INFO - 2026-01-31 17:34:40 --> Language Class Initialized
INFO - 2026-01-31 17:34:40 --> Language Class Initialized
INFO - 2026-01-31 17:34:40 --> Config Class Initialized
INFO - 2026-01-31 17:34:40 --> Loader Class Initialized
INFO - 2026-01-31 17:34:40 --> Helper loaded: url_helper
INFO - 2026-01-31 17:34:40 --> Helper loaded: form_helper
INFO - 2026-01-31 17:34:40 --> Helper loaded: html_helper
INFO - 2026-01-31 17:34:40 --> Helper loaded: file_helper
INFO - 2026-01-31 17:34:40 --> Helper loaded: email_helper
INFO - 2026-01-31 17:34:40 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 17:34:40 --> Helper loaded: ssp_helper
INFO - 2026-01-31 17:34:40 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 17:34:40 --> Database Driver Class Initialized
INFO - 2026-01-31 17:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 17:34:41 --> Upload Class Initialized
DEBUG - 2026-01-31 17:34:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 17:34:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 17:34:41 --> Encryption Class Initialized
INFO - 2026-01-31 17:34:41 --> Form Validation Class Initialized
INFO - 2026-01-31 17:34:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 17:34:41 --> Pagination Class Initialized
INFO - 2026-01-31 17:34:41 --> Email Class Initialized
INFO - 2026-01-31 17:34:41 --> Controller Class Initialized
DEBUG - 2026-01-31 17:34:41 --> Clientarea MX_Controller Initialized
INFO - 2026-01-31 17:34:41 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 17:34:41 --> Model "Auth_model" initialized
INFO - 2026-01-31 17:34:41 --> Model "Cart_model" initialized
INFO - 2026-01-31 17:34:41 --> Model "Clientarea_model" initialized
INFO - 2026-01-31 17:34:41 --> Model "Billing_model" initialized
INFO - 2026-01-31 17:34:41 --> Model "Common_model" initialized
INFO - 2026-01-31 17:34:41 --> Model "Order_model" initialized
INFO - 2026-01-31 17:34:41 --> Model "Support_model" initialized
DEBUG - 2026-01-31 17:34:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 17:34:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 17:34:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 17:34:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_changepassword.php
INFO - 2026-01-31 17:34:42 --> Final output sent to browser
DEBUG - 2026-01-31 17:34:42 --> Total execution time: 2.3253
INFO - 2026-01-31 17:35:25 --> Config Class Initialized
INFO - 2026-01-31 17:35:25 --> Hooks Class Initialized
DEBUG - 2026-01-31 17:35:25 --> UTF-8 Support Enabled
INFO - 2026-01-31 17:35:25 --> Utf8 Class Initialized
INFO - 2026-01-31 17:35:25 --> URI Class Initialized
INFO - 2026-01-31 17:35:25 --> Router Class Initialized
INFO - 2026-01-31 17:35:25 --> Output Class Initialized
INFO - 2026-01-31 17:35:25 --> Security Class Initialized
DEBUG - 2026-01-31 17:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 17:35:25 --> CSRF cookie sent
INFO - 2026-01-31 17:35:25 --> Input Class Initialized
INFO - 2026-01-31 17:35:25 --> Language Class Initialized
INFO - 2026-01-31 17:35:25 --> Language Class Initialized
INFO - 2026-01-31 17:35:25 --> Config Class Initialized
INFO - 2026-01-31 17:35:25 --> Loader Class Initialized
INFO - 2026-01-31 17:35:25 --> Helper loaded: url_helper
INFO - 2026-01-31 17:35:25 --> Helper loaded: form_helper
INFO - 2026-01-31 17:35:25 --> Helper loaded: html_helper
INFO - 2026-01-31 17:35:25 --> Helper loaded: file_helper
INFO - 2026-01-31 17:35:25 --> Helper loaded: email_helper
INFO - 2026-01-31 17:35:25 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 17:35:25 --> Helper loaded: ssp_helper
INFO - 2026-01-31 17:35:25 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 17:35:25 --> Database Driver Class Initialized
INFO - 2026-01-31 17:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 17:35:27 --> Upload Class Initialized
DEBUG - 2026-01-31 17:35:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 17:35:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 17:35:27 --> Encryption Class Initialized
INFO - 2026-01-31 17:35:27 --> Form Validation Class Initialized
INFO - 2026-01-31 17:35:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 17:35:27 --> Pagination Class Initialized
INFO - 2026-01-31 17:35:27 --> Email Class Initialized
INFO - 2026-01-31 17:35:27 --> Controller Class Initialized
DEBUG - 2026-01-31 17:35:27 --> Clientarea MX_Controller Initialized
INFO - 2026-01-31 17:35:27 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 17:35:27 --> Model "Auth_model" initialized
INFO - 2026-01-31 17:35:27 --> Model "Cart_model" initialized
INFO - 2026-01-31 17:35:27 --> Model "Clientarea_model" initialized
INFO - 2026-01-31 17:35:27 --> Model "Billing_model" initialized
INFO - 2026-01-31 17:35:27 --> Model "Common_model" initialized
INFO - 2026-01-31 17:35:27 --> Model "Order_model" initialized
INFO - 2026-01-31 17:35:27 --> Model "Support_model" initialized
DEBUG - 2026-01-31 17:35:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 17:35:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 17:35:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 17:35:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_changepassword.php
INFO - 2026-01-31 17:35:27 --> Final output sent to browser
DEBUG - 2026-01-31 17:35:27 --> Total execution time: 2.5677
INFO - 2026-01-31 17:35:39 --> Config Class Initialized
INFO - 2026-01-31 17:35:39 --> Hooks Class Initialized
DEBUG - 2026-01-31 17:35:39 --> UTF-8 Support Enabled
INFO - 2026-01-31 17:35:39 --> Utf8 Class Initialized
INFO - 2026-01-31 17:35:39 --> URI Class Initialized
INFO - 2026-01-31 17:35:39 --> Router Class Initialized
INFO - 2026-01-31 17:35:39 --> Output Class Initialized
INFO - 2026-01-31 17:35:39 --> Security Class Initialized
DEBUG - 2026-01-31 17:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 17:35:39 --> CSRF cookie sent
INFO - 2026-01-31 17:35:39 --> Input Class Initialized
INFO - 2026-01-31 17:35:39 --> Language Class Initialized
INFO - 2026-01-31 17:35:39 --> Language Class Initialized
INFO - 2026-01-31 17:35:39 --> Config Class Initialized
INFO - 2026-01-31 17:35:39 --> Loader Class Initialized
INFO - 2026-01-31 17:35:39 --> Helper loaded: url_helper
INFO - 2026-01-31 17:35:39 --> Helper loaded: form_helper
INFO - 2026-01-31 17:35:39 --> Helper loaded: html_helper
INFO - 2026-01-31 17:35:39 --> Helper loaded: file_helper
INFO - 2026-01-31 17:35:39 --> Helper loaded: email_helper
INFO - 2026-01-31 17:35:39 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 17:35:39 --> Helper loaded: ssp_helper
INFO - 2026-01-31 17:35:39 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 17:35:39 --> Database Driver Class Initialized
INFO - 2026-01-31 17:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 17:35:41 --> Upload Class Initialized
DEBUG - 2026-01-31 17:35:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 17:35:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 17:35:41 --> Encryption Class Initialized
INFO - 2026-01-31 17:35:41 --> Form Validation Class Initialized
INFO - 2026-01-31 17:35:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 17:35:41 --> Pagination Class Initialized
INFO - 2026-01-31 17:35:41 --> Email Class Initialized
INFO - 2026-01-31 17:35:41 --> Controller Class Initialized
DEBUG - 2026-01-31 17:35:41 --> Clientarea MX_Controller Initialized
INFO - 2026-01-31 17:35:41 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 17:35:41 --> Model "Auth_model" initialized
INFO - 2026-01-31 17:35:41 --> Model "Cart_model" initialized
INFO - 2026-01-31 17:35:41 --> Model "Clientarea_model" initialized
INFO - 2026-01-31 17:35:41 --> Model "Billing_model" initialized
INFO - 2026-01-31 17:35:41 --> Model "Common_model" initialized
INFO - 2026-01-31 17:35:41 --> Model "Order_model" initialized
INFO - 2026-01-31 17:35:41 --> Model "Support_model" initialized
DEBUG - 2026-01-31 17:35:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 17:35:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 17:35:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 17:35:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_changepassword.php
INFO - 2026-01-31 17:35:41 --> Final output sent to browser
DEBUG - 2026-01-31 17:35:41 --> Total execution time: 2.4079
INFO - 2026-01-31 17:37:31 --> Config Class Initialized
INFO - 2026-01-31 17:37:31 --> Hooks Class Initialized
DEBUG - 2026-01-31 17:37:31 --> UTF-8 Support Enabled
INFO - 2026-01-31 17:37:31 --> Utf8 Class Initialized
INFO - 2026-01-31 17:37:31 --> URI Class Initialized
INFO - 2026-01-31 17:37:31 --> Router Class Initialized
INFO - 2026-01-31 17:37:31 --> Output Class Initialized
INFO - 2026-01-31 17:37:31 --> Security Class Initialized
DEBUG - 2026-01-31 17:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 17:37:31 --> CSRF cookie sent
INFO - 2026-01-31 17:37:31 --> Input Class Initialized
INFO - 2026-01-31 17:37:31 --> Language Class Initialized
INFO - 2026-01-31 17:37:31 --> Language Class Initialized
INFO - 2026-01-31 17:37:31 --> Config Class Initialized
INFO - 2026-01-31 17:37:31 --> Loader Class Initialized
INFO - 2026-01-31 17:37:31 --> Helper loaded: url_helper
INFO - 2026-01-31 17:37:31 --> Helper loaded: form_helper
INFO - 2026-01-31 17:37:31 --> Helper loaded: html_helper
INFO - 2026-01-31 17:37:31 --> Helper loaded: file_helper
INFO - 2026-01-31 17:37:31 --> Helper loaded: email_helper
INFO - 2026-01-31 17:37:31 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 17:37:31 --> Helper loaded: ssp_helper
INFO - 2026-01-31 17:37:31 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 17:37:31 --> Database Driver Class Initialized
INFO - 2026-01-31 17:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 17:37:34 --> Upload Class Initialized
DEBUG - 2026-01-31 17:37:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 17:37:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 17:37:34 --> Encryption Class Initialized
INFO - 2026-01-31 17:37:34 --> Form Validation Class Initialized
INFO - 2026-01-31 17:37:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 17:37:34 --> Pagination Class Initialized
INFO - 2026-01-31 17:37:34 --> Email Class Initialized
INFO - 2026-01-31 17:37:34 --> Controller Class Initialized
DEBUG - 2026-01-31 17:37:34 --> Clientarea MX_Controller Initialized
INFO - 2026-01-31 17:37:34 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 17:37:34 --> Model "Auth_model" initialized
INFO - 2026-01-31 17:37:34 --> Model "Cart_model" initialized
INFO - 2026-01-31 17:37:34 --> Model "Clientarea_model" initialized
INFO - 2026-01-31 17:37:34 --> Model "Billing_model" initialized
INFO - 2026-01-31 17:37:34 --> Model "Common_model" initialized
INFO - 2026-01-31 17:37:34 --> Model "Order_model" initialized
INFO - 2026-01-31 17:37:34 --> Model "Support_model" initialized
DEBUG - 2026-01-31 17:37:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 17:37:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 17:37:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 17:37:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_changepassword.php
INFO - 2026-01-31 17:37:34 --> Final output sent to browser
DEBUG - 2026-01-31 17:37:34 --> Total execution time: 3.3699
INFO - 2026-01-31 17:37:50 --> Config Class Initialized
INFO - 2026-01-31 17:37:50 --> Hooks Class Initialized
DEBUG - 2026-01-31 17:37:50 --> UTF-8 Support Enabled
INFO - 2026-01-31 17:37:50 --> Utf8 Class Initialized
INFO - 2026-01-31 17:37:50 --> URI Class Initialized
INFO - 2026-01-31 17:37:50 --> Router Class Initialized
INFO - 2026-01-31 17:37:50 --> Output Class Initialized
INFO - 2026-01-31 17:37:50 --> Security Class Initialized
DEBUG - 2026-01-31 17:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 17:37:50 --> CSRF cookie sent
INFO - 2026-01-31 17:37:50 --> CSRF token verified
INFO - 2026-01-31 17:37:50 --> Input Class Initialized
INFO - 2026-01-31 17:37:50 --> Language Class Initialized
INFO - 2026-01-31 17:37:50 --> Language Class Initialized
INFO - 2026-01-31 17:37:50 --> Config Class Initialized
INFO - 2026-01-31 17:37:50 --> Loader Class Initialized
INFO - 2026-01-31 17:37:50 --> Helper loaded: url_helper
INFO - 2026-01-31 17:37:50 --> Helper loaded: form_helper
INFO - 2026-01-31 17:37:50 --> Helper loaded: html_helper
INFO - 2026-01-31 17:37:50 --> Helper loaded: file_helper
INFO - 2026-01-31 17:37:50 --> Helper loaded: email_helper
INFO - 2026-01-31 17:37:50 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 17:37:50 --> Helper loaded: ssp_helper
INFO - 2026-01-31 17:37:50 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 17:37:50 --> Database Driver Class Initialized
INFO - 2026-01-31 17:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 17:37:52 --> Upload Class Initialized
DEBUG - 2026-01-31 17:37:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 17:37:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 17:37:52 --> Encryption Class Initialized
INFO - 2026-01-31 17:37:52 --> Form Validation Class Initialized
INFO - 2026-01-31 17:37:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 17:37:52 --> Pagination Class Initialized
INFO - 2026-01-31 17:37:52 --> Email Class Initialized
INFO - 2026-01-31 17:37:52 --> Controller Class Initialized
DEBUG - 2026-01-31 17:37:52 --> Clientarea MX_Controller Initialized
INFO - 2026-01-31 17:37:52 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 17:37:52 --> Model "Auth_model" initialized
INFO - 2026-01-31 17:37:52 --> Model "Cart_model" initialized
INFO - 2026-01-31 17:37:52 --> Model "Clientarea_model" initialized
INFO - 2026-01-31 17:37:52 --> Model "Billing_model" initialized
INFO - 2026-01-31 17:37:52 --> Model "Common_model" initialized
INFO - 2026-01-31 17:37:52 --> Model "Order_model" initialized
INFO - 2026-01-31 17:37:52 --> Model "Support_model" initialized
INFO - 2026-01-31 17:37:53 --> Config Class Initialized
INFO - 2026-01-31 17:37:53 --> Hooks Class Initialized
DEBUG - 2026-01-31 17:37:53 --> UTF-8 Support Enabled
INFO - 2026-01-31 17:37:53 --> Utf8 Class Initialized
INFO - 2026-01-31 17:37:53 --> URI Class Initialized
INFO - 2026-01-31 17:37:53 --> Router Class Initialized
INFO - 2026-01-31 17:37:53 --> Output Class Initialized
INFO - 2026-01-31 17:37:53 --> Security Class Initialized
DEBUG - 2026-01-31 17:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 17:37:53 --> CSRF cookie sent
INFO - 2026-01-31 17:37:53 --> Input Class Initialized
INFO - 2026-01-31 17:37:53 --> Language Class Initialized
INFO - 2026-01-31 17:37:53 --> Language Class Initialized
INFO - 2026-01-31 17:37:53 --> Config Class Initialized
INFO - 2026-01-31 17:37:53 --> Loader Class Initialized
INFO - 2026-01-31 17:37:53 --> Helper loaded: url_helper
INFO - 2026-01-31 17:37:53 --> Helper loaded: form_helper
INFO - 2026-01-31 17:37:53 --> Helper loaded: html_helper
INFO - 2026-01-31 17:37:53 --> Helper loaded: file_helper
INFO - 2026-01-31 17:37:53 --> Helper loaded: email_helper
INFO - 2026-01-31 17:37:53 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 17:37:53 --> Helper loaded: ssp_helper
INFO - 2026-01-31 17:37:53 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 17:37:53 --> Database Driver Class Initialized
INFO - 2026-01-31 17:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 17:37:55 --> Upload Class Initialized
DEBUG - 2026-01-31 17:37:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 17:37:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 17:37:55 --> Encryption Class Initialized
INFO - 2026-01-31 17:37:55 --> Form Validation Class Initialized
INFO - 2026-01-31 17:37:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 17:37:55 --> Pagination Class Initialized
INFO - 2026-01-31 17:37:55 --> Email Class Initialized
INFO - 2026-01-31 17:37:55 --> Controller Class Initialized
DEBUG - 2026-01-31 17:37:55 --> Clientarea MX_Controller Initialized
INFO - 2026-01-31 17:37:55 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 17:37:55 --> Model "Auth_model" initialized
INFO - 2026-01-31 17:37:55 --> Model "Cart_model" initialized
INFO - 2026-01-31 17:37:55 --> Model "Clientarea_model" initialized
INFO - 2026-01-31 17:37:55 --> Model "Billing_model" initialized
INFO - 2026-01-31 17:37:55 --> Model "Common_model" initialized
INFO - 2026-01-31 17:37:55 --> Model "Order_model" initialized
INFO - 2026-01-31 17:37:55 --> Model "Support_model" initialized
DEBUG - 2026-01-31 17:37:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 17:37:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 17:37:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 17:37:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_changepassword.php
INFO - 2026-01-31 17:37:55 --> Final output sent to browser
DEBUG - 2026-01-31 17:37:55 --> Total execution time: 2.5922
INFO - 2026-01-31 17:38:12 --> Config Class Initialized
INFO - 2026-01-31 17:38:12 --> Hooks Class Initialized
DEBUG - 2026-01-31 17:38:12 --> UTF-8 Support Enabled
INFO - 2026-01-31 17:38:12 --> Utf8 Class Initialized
INFO - 2026-01-31 17:38:12 --> URI Class Initialized
INFO - 2026-01-31 17:38:12 --> Router Class Initialized
INFO - 2026-01-31 17:38:12 --> Output Class Initialized
INFO - 2026-01-31 17:38:12 --> Security Class Initialized
DEBUG - 2026-01-31 17:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 17:38:12 --> CSRF cookie sent
INFO - 2026-01-31 17:38:12 --> CSRF token verified
INFO - 2026-01-31 17:38:12 --> Input Class Initialized
INFO - 2026-01-31 17:38:12 --> Language Class Initialized
INFO - 2026-01-31 17:38:12 --> Language Class Initialized
INFO - 2026-01-31 17:38:12 --> Config Class Initialized
INFO - 2026-01-31 17:38:12 --> Loader Class Initialized
INFO - 2026-01-31 17:38:12 --> Helper loaded: url_helper
INFO - 2026-01-31 17:38:12 --> Helper loaded: form_helper
INFO - 2026-01-31 17:38:12 --> Helper loaded: html_helper
INFO - 2026-01-31 17:38:12 --> Helper loaded: file_helper
INFO - 2026-01-31 17:38:12 --> Helper loaded: email_helper
INFO - 2026-01-31 17:38:12 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 17:38:12 --> Helper loaded: ssp_helper
INFO - 2026-01-31 17:38:12 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 17:38:12 --> Database Driver Class Initialized
INFO - 2026-01-31 17:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 17:38:14 --> Upload Class Initialized
DEBUG - 2026-01-31 17:38:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 17:38:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 17:38:14 --> Encryption Class Initialized
INFO - 2026-01-31 17:38:14 --> Form Validation Class Initialized
INFO - 2026-01-31 17:38:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 17:38:14 --> Pagination Class Initialized
INFO - 2026-01-31 17:38:14 --> Email Class Initialized
INFO - 2026-01-31 17:38:14 --> Controller Class Initialized
DEBUG - 2026-01-31 17:38:14 --> Clientarea MX_Controller Initialized
INFO - 2026-01-31 17:38:14 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 17:38:14 --> Model "Auth_model" initialized
INFO - 2026-01-31 17:38:14 --> Model "Cart_model" initialized
INFO - 2026-01-31 17:38:14 --> Model "Clientarea_model" initialized
INFO - 2026-01-31 17:38:14 --> Model "Billing_model" initialized
INFO - 2026-01-31 17:38:14 --> Model "Common_model" initialized
INFO - 2026-01-31 17:38:14 --> Model "Order_model" initialized
INFO - 2026-01-31 17:38:14 --> Model "Support_model" initialized
INFO - 2026-01-31 17:38:15 --> Config Class Initialized
INFO - 2026-01-31 17:38:15 --> Hooks Class Initialized
DEBUG - 2026-01-31 17:38:15 --> UTF-8 Support Enabled
INFO - 2026-01-31 17:38:15 --> Utf8 Class Initialized
INFO - 2026-01-31 17:38:15 --> URI Class Initialized
INFO - 2026-01-31 17:38:15 --> Router Class Initialized
INFO - 2026-01-31 17:38:15 --> Output Class Initialized
INFO - 2026-01-31 17:38:15 --> Security Class Initialized
DEBUG - 2026-01-31 17:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 17:38:15 --> CSRF cookie sent
INFO - 2026-01-31 17:38:15 --> Input Class Initialized
INFO - 2026-01-31 17:38:15 --> Language Class Initialized
INFO - 2026-01-31 17:38:15 --> Language Class Initialized
INFO - 2026-01-31 17:38:15 --> Config Class Initialized
INFO - 2026-01-31 17:38:15 --> Loader Class Initialized
INFO - 2026-01-31 17:38:15 --> Helper loaded: url_helper
INFO - 2026-01-31 17:38:15 --> Helper loaded: form_helper
INFO - 2026-01-31 17:38:15 --> Helper loaded: html_helper
INFO - 2026-01-31 17:38:15 --> Helper loaded: file_helper
INFO - 2026-01-31 17:38:15 --> Helper loaded: email_helper
INFO - 2026-01-31 17:38:15 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 17:38:15 --> Helper loaded: ssp_helper
INFO - 2026-01-31 17:38:15 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 17:38:15 --> Database Driver Class Initialized
INFO - 2026-01-31 17:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 17:38:17 --> Upload Class Initialized
DEBUG - 2026-01-31 17:38:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 17:38:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 17:38:17 --> Encryption Class Initialized
INFO - 2026-01-31 17:38:17 --> Form Validation Class Initialized
INFO - 2026-01-31 17:38:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 17:38:17 --> Pagination Class Initialized
INFO - 2026-01-31 17:38:17 --> Email Class Initialized
INFO - 2026-01-31 17:38:17 --> Controller Class Initialized
DEBUG - 2026-01-31 17:38:17 --> Clientarea MX_Controller Initialized
INFO - 2026-01-31 17:38:17 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 17:38:17 --> Model "Auth_model" initialized
INFO - 2026-01-31 17:38:17 --> Model "Cart_model" initialized
INFO - 2026-01-31 17:38:17 --> Model "Clientarea_model" initialized
INFO - 2026-01-31 17:38:17 --> Model "Billing_model" initialized
INFO - 2026-01-31 17:38:17 --> Model "Common_model" initialized
INFO - 2026-01-31 17:38:17 --> Model "Order_model" initialized
INFO - 2026-01-31 17:38:17 --> Model "Support_model" initialized
DEBUG - 2026-01-31 17:38:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 17:38:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 17:38:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 17:38:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_changepassword.php
INFO - 2026-01-31 17:38:18 --> Final output sent to browser
DEBUG - 2026-01-31 17:38:18 --> Total execution time: 2.3576
INFO - 2026-01-31 17:38:38 --> Config Class Initialized
INFO - 2026-01-31 17:38:38 --> Hooks Class Initialized
DEBUG - 2026-01-31 17:38:38 --> UTF-8 Support Enabled
INFO - 2026-01-31 17:38:38 --> Utf8 Class Initialized
INFO - 2026-01-31 17:38:38 --> URI Class Initialized
INFO - 2026-01-31 17:38:38 --> Router Class Initialized
INFO - 2026-01-31 17:38:38 --> Output Class Initialized
INFO - 2026-01-31 17:38:38 --> Security Class Initialized
DEBUG - 2026-01-31 17:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 17:38:38 --> CSRF cookie sent
INFO - 2026-01-31 17:38:38 --> CSRF token verified
INFO - 2026-01-31 17:38:38 --> Input Class Initialized
INFO - 2026-01-31 17:38:38 --> Language Class Initialized
INFO - 2026-01-31 17:38:38 --> Language Class Initialized
INFO - 2026-01-31 17:38:38 --> Config Class Initialized
INFO - 2026-01-31 17:38:38 --> Loader Class Initialized
INFO - 2026-01-31 17:38:38 --> Helper loaded: url_helper
INFO - 2026-01-31 17:38:38 --> Helper loaded: form_helper
INFO - 2026-01-31 17:38:38 --> Helper loaded: html_helper
INFO - 2026-01-31 17:38:38 --> Helper loaded: file_helper
INFO - 2026-01-31 17:38:38 --> Helper loaded: email_helper
INFO - 2026-01-31 17:38:38 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 17:38:38 --> Helper loaded: ssp_helper
INFO - 2026-01-31 17:38:38 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 17:38:38 --> Database Driver Class Initialized
INFO - 2026-01-31 17:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 17:38:40 --> Upload Class Initialized
DEBUG - 2026-01-31 17:38:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 17:38:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 17:38:40 --> Encryption Class Initialized
INFO - 2026-01-31 17:38:40 --> Form Validation Class Initialized
INFO - 2026-01-31 17:38:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 17:38:40 --> Pagination Class Initialized
INFO - 2026-01-31 17:38:40 --> Email Class Initialized
INFO - 2026-01-31 17:38:40 --> Controller Class Initialized
DEBUG - 2026-01-31 17:38:40 --> Clientarea MX_Controller Initialized
INFO - 2026-01-31 17:38:40 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 17:38:40 --> Model "Auth_model" initialized
INFO - 2026-01-31 17:38:40 --> Model "Cart_model" initialized
INFO - 2026-01-31 17:38:40 --> Model "Clientarea_model" initialized
INFO - 2026-01-31 17:38:40 --> Model "Billing_model" initialized
INFO - 2026-01-31 17:38:40 --> Model "Common_model" initialized
INFO - 2026-01-31 17:38:40 --> Model "Order_model" initialized
INFO - 2026-01-31 17:38:40 --> Model "Support_model" initialized
INFO - 2026-01-31 17:38:50 --> Config Class Initialized
INFO - 2026-01-31 17:38:50 --> Hooks Class Initialized
DEBUG - 2026-01-31 17:38:50 --> UTF-8 Support Enabled
INFO - 2026-01-31 17:38:50 --> Utf8 Class Initialized
INFO - 2026-01-31 17:38:50 --> URI Class Initialized
INFO - 2026-01-31 17:38:50 --> Router Class Initialized
INFO - 2026-01-31 17:38:50 --> Output Class Initialized
INFO - 2026-01-31 17:38:50 --> Security Class Initialized
DEBUG - 2026-01-31 17:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 17:38:50 --> CSRF cookie sent
INFO - 2026-01-31 17:38:50 --> Input Class Initialized
INFO - 2026-01-31 17:38:50 --> Language Class Initialized
INFO - 2026-01-31 17:38:50 --> Language Class Initialized
INFO - 2026-01-31 17:38:50 --> Config Class Initialized
INFO - 2026-01-31 17:38:50 --> Loader Class Initialized
INFO - 2026-01-31 17:38:50 --> Helper loaded: url_helper
INFO - 2026-01-31 17:38:50 --> Helper loaded: form_helper
INFO - 2026-01-31 17:38:50 --> Helper loaded: html_helper
INFO - 2026-01-31 17:38:50 --> Helper loaded: file_helper
INFO - 2026-01-31 17:38:50 --> Helper loaded: email_helper
INFO - 2026-01-31 17:38:50 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 17:38:50 --> Helper loaded: ssp_helper
INFO - 2026-01-31 17:38:50 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 17:38:50 --> Database Driver Class Initialized
INFO - 2026-01-31 17:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 17:38:52 --> Upload Class Initialized
DEBUG - 2026-01-31 17:38:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 17:38:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 17:38:52 --> Encryption Class Initialized
INFO - 2026-01-31 17:38:52 --> Form Validation Class Initialized
INFO - 2026-01-31 17:38:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 17:38:52 --> Pagination Class Initialized
INFO - 2026-01-31 17:38:52 --> Email Class Initialized
INFO - 2026-01-31 17:38:52 --> Controller Class Initialized
DEBUG - 2026-01-31 17:38:52 --> Clientarea MX_Controller Initialized
INFO - 2026-01-31 17:38:52 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 17:38:52 --> Model "Auth_model" initialized
INFO - 2026-01-31 17:38:52 --> Model "Cart_model" initialized
INFO - 2026-01-31 17:38:52 --> Model "Clientarea_model" initialized
INFO - 2026-01-31 17:38:52 --> Model "Billing_model" initialized
INFO - 2026-01-31 17:38:52 --> Model "Common_model" initialized
INFO - 2026-01-31 17:38:52 --> Model "Order_model" initialized
INFO - 2026-01-31 17:38:52 --> Model "Support_model" initialized
DEBUG - 2026-01-31 17:38:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 17:38:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 17:38:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 17:38:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_changepassword.php
INFO - 2026-01-31 17:38:52 --> Final output sent to browser
DEBUG - 2026-01-31 17:38:52 --> Total execution time: 2.4361
INFO - 2026-01-31 17:39:29 --> Config Class Initialized
INFO - 2026-01-31 17:39:29 --> Hooks Class Initialized
DEBUG - 2026-01-31 17:39:29 --> UTF-8 Support Enabled
INFO - 2026-01-31 17:39:29 --> Utf8 Class Initialized
INFO - 2026-01-31 17:39:29 --> URI Class Initialized
INFO - 2026-01-31 17:39:29 --> Router Class Initialized
INFO - 2026-01-31 17:39:29 --> Output Class Initialized
INFO - 2026-01-31 17:39:29 --> Security Class Initialized
DEBUG - 2026-01-31 17:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 17:39:29 --> CSRF cookie sent
INFO - 2026-01-31 17:39:29 --> Input Class Initialized
INFO - 2026-01-31 17:39:29 --> Language Class Initialized
INFO - 2026-01-31 17:39:29 --> Language Class Initialized
INFO - 2026-01-31 17:39:29 --> Config Class Initialized
INFO - 2026-01-31 17:39:29 --> Loader Class Initialized
INFO - 2026-01-31 17:39:29 --> Helper loaded: url_helper
INFO - 2026-01-31 17:39:29 --> Helper loaded: form_helper
INFO - 2026-01-31 17:39:29 --> Helper loaded: html_helper
INFO - 2026-01-31 17:39:29 --> Helper loaded: file_helper
INFO - 2026-01-31 17:39:29 --> Helper loaded: email_helper
INFO - 2026-01-31 17:39:29 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 17:39:29 --> Helper loaded: ssp_helper
INFO - 2026-01-31 17:39:29 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 17:39:29 --> Database Driver Class Initialized
INFO - 2026-01-31 17:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 17:39:31 --> Upload Class Initialized
DEBUG - 2026-01-31 17:39:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 17:39:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 17:39:31 --> Encryption Class Initialized
INFO - 2026-01-31 17:39:31 --> Form Validation Class Initialized
INFO - 2026-01-31 17:39:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 17:39:31 --> Pagination Class Initialized
INFO - 2026-01-31 17:39:31 --> Email Class Initialized
INFO - 2026-01-31 17:39:31 --> Controller Class Initialized
DEBUG - 2026-01-31 17:39:31 --> Clientarea MX_Controller Initialized
INFO - 2026-01-31 17:39:31 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 17:39:31 --> Model "Auth_model" initialized
INFO - 2026-01-31 17:39:31 --> Model "Cart_model" initialized
INFO - 2026-01-31 17:39:31 --> Model "Clientarea_model" initialized
INFO - 2026-01-31 17:39:31 --> Model "Billing_model" initialized
INFO - 2026-01-31 17:39:31 --> Model "Common_model" initialized
INFO - 2026-01-31 17:39:31 --> Model "Order_model" initialized
INFO - 2026-01-31 17:39:31 --> Model "Support_model" initialized
DEBUG - 2026-01-31 17:39:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 17:39:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 17:39:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 17:39:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_index.php
INFO - 2026-01-31 17:39:32 --> Final output sent to browser
DEBUG - 2026-01-31 17:39:32 --> Total execution time: 2.5092
INFO - 2026-01-31 17:39:32 --> Config Class Initialized
INFO - 2026-01-31 17:39:32 --> Hooks Class Initialized
INFO - 2026-01-31 17:39:32 --> Config Class Initialized
INFO - 2026-01-31 17:39:32 --> Hooks Class Initialized
DEBUG - 2026-01-31 17:39:32 --> UTF-8 Support Enabled
INFO - 2026-01-31 17:39:32 --> Utf8 Class Initialized
INFO - 2026-01-31 17:39:32 --> Config Class Initialized
INFO - 2026-01-31 17:39:32 --> Hooks Class Initialized
INFO - 2026-01-31 17:39:32 --> URI Class Initialized
DEBUG - 2026-01-31 17:39:32 --> UTF-8 Support Enabled
INFO - 2026-01-31 17:39:32 --> Utf8 Class Initialized
INFO - 2026-01-31 17:39:32 --> URI Class Initialized
DEBUG - 2026-01-31 17:39:32 --> UTF-8 Support Enabled
INFO - 2026-01-31 17:39:32 --> Router Class Initialized
INFO - 2026-01-31 17:39:32 --> Utf8 Class Initialized
INFO - 2026-01-31 17:39:32 --> URI Class Initialized
INFO - 2026-01-31 17:39:32 --> Output Class Initialized
INFO - 2026-01-31 17:39:32 --> Router Class Initialized
INFO - 2026-01-31 17:39:32 --> Security Class Initialized
INFO - 2026-01-31 17:39:32 --> Router Class Initialized
INFO - 2026-01-31 17:39:32 --> Output Class Initialized
DEBUG - 2026-01-31 17:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 17:39:32 --> Input Class Initialized
INFO - 2026-01-31 17:39:32 --> Language Class Initialized
INFO - 2026-01-31 17:39:32 --> Output Class Initialized
INFO - 2026-01-31 17:39:32 --> Language Class Initialized
INFO - 2026-01-31 17:39:32 --> Security Class Initialized
INFO - 2026-01-31 17:39:32 --> Config Class Initialized
DEBUG - 2026-01-31 17:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 17:39:32 --> Security Class Initialized
INFO - 2026-01-31 17:39:32 --> Input Class Initialized
INFO - 2026-01-31 17:39:32 --> Language Class Initialized
DEBUG - 2026-01-31 17:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 17:39:32 --> Language Class Initialized
INFO - 2026-01-31 17:39:32 --> Input Class Initialized
INFO - 2026-01-31 17:39:32 --> Config Class Initialized
INFO - 2026-01-31 17:39:32 --> Loader Class Initialized
INFO - 2026-01-31 17:39:32 --> Language Class Initialized
INFO - 2026-01-31 17:39:32 --> Helper loaded: url_helper
INFO - 2026-01-31 17:39:32 --> Language Class Initialized
INFO - 2026-01-31 17:39:32 --> Config Class Initialized
INFO - 2026-01-31 17:39:32 --> Helper loaded: form_helper
INFO - 2026-01-31 17:39:32 --> Helper loaded: html_helper
INFO - 2026-01-31 17:39:32 --> Helper loaded: file_helper
INFO - 2026-01-31 17:39:32 --> Helper loaded: email_helper
INFO - 2026-01-31 17:39:32 --> Loader Class Initialized
INFO - 2026-01-31 17:39:32 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 17:39:32 --> Loader Class Initialized
INFO - 2026-01-31 17:39:32 --> Helper loaded: ssp_helper
INFO - 2026-01-31 17:39:32 --> Helper loaded: url_helper
INFO - 2026-01-31 17:39:32 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 17:39:32 --> Helper loaded: url_helper
INFO - 2026-01-31 17:39:32 --> Helper loaded: form_helper
INFO - 2026-01-31 17:39:32 --> Helper loaded: html_helper
INFO - 2026-01-31 17:39:32 --> Helper loaded: form_helper
INFO - 2026-01-31 17:39:32 --> Helper loaded: html_helper
INFO - 2026-01-31 17:39:32 --> Helper loaded: file_helper
INFO - 2026-01-31 17:39:32 --> Helper loaded: email_helper
INFO - 2026-01-31 17:39:32 --> Helper loaded: file_helper
INFO - 2026-01-31 17:39:32 --> Helper loaded: email_helper
INFO - 2026-01-31 17:39:32 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 17:39:32 --> Helper loaded: ssp_helper
INFO - 2026-01-31 17:39:32 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 17:39:32 --> Helper loaded: ssp_helper
INFO - 2026-01-31 17:39:32 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 17:39:32 --> Database Driver Class Initialized
INFO - 2026-01-31 17:39:32 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 17:39:32 --> Database Driver Class Initialized
INFO - 2026-01-31 17:39:32 --> Database Driver Class Initialized
INFO - 2026-01-31 17:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 17:39:34 --> Upload Class Initialized
DEBUG - 2026-01-31 17:39:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 17:39:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 17:39:34 --> Encryption Class Initialized
INFO - 2026-01-31 17:39:34 --> Form Validation Class Initialized
INFO - 2026-01-31 17:39:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 17:39:34 --> Pagination Class Initialized
INFO - 2026-01-31 17:39:34 --> Email Class Initialized
INFO - 2026-01-31 17:39:34 --> Controller Class Initialized
DEBUG - 2026-01-31 17:39:34 --> Billing MX_Controller Initialized
INFO - 2026-01-31 17:39:34 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 17:39:34 --> Model "Auth_model" initialized
INFO - 2026-01-31 17:39:34 --> Model "Cart_model" initialized
INFO - 2026-01-31 17:39:34 --> Model "Billing_model" initialized
INFO - 2026-01-31 17:39:34 --> Model "Common_model" initialized
INFO - 2026-01-31 17:39:35 --> Final output sent to browser
DEBUG - 2026-01-31 17:39:35 --> Total execution time: 2.7313
INFO - 2026-01-31 17:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 17:39:35 --> Upload Class Initialized
DEBUG - 2026-01-31 17:39:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 17:39:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 17:39:35 --> Encryption Class Initialized
INFO - 2026-01-31 17:39:35 --> Form Validation Class Initialized
INFO - 2026-01-31 17:39:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 17:39:35 --> Pagination Class Initialized
INFO - 2026-01-31 17:39:35 --> Email Class Initialized
INFO - 2026-01-31 17:39:35 --> Controller Class Initialized
DEBUG - 2026-01-31 17:39:35 --> Tickets MX_Controller Initialized
INFO - 2026-01-31 17:39:35 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 17:39:35 --> Model "Auth_model" initialized
INFO - 2026-01-31 17:39:35 --> Model "Cart_model" initialized
INFO - 2026-01-31 17:39:35 --> Model "Support_model" initialized
INFO - 2026-01-31 17:39:35 --> Model "Common_model" initialized
INFO - 2026-01-31 17:39:35 --> Final output sent to browser
DEBUG - 2026-01-31 17:39:35 --> Total execution time: 3.5965
INFO - 2026-01-31 17:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 17:39:35 --> Upload Class Initialized
DEBUG - 2026-01-31 17:39:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 17:39:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 17:39:35 --> Encryption Class Initialized
INFO - 2026-01-31 17:39:35 --> Form Validation Class Initialized
INFO - 2026-01-31 17:39:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 17:39:35 --> Pagination Class Initialized
INFO - 2026-01-31 17:39:35 --> Email Class Initialized
INFO - 2026-01-31 17:39:35 --> Controller Class Initialized
DEBUG - 2026-01-31 17:39:35 --> Clientarea MX_Controller Initialized
INFO - 2026-01-31 17:39:35 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 17:39:35 --> Model "Auth_model" initialized
INFO - 2026-01-31 17:39:35 --> Model "Cart_model" initialized
INFO - 2026-01-31 17:39:35 --> Model "Clientarea_model" initialized
INFO - 2026-01-31 17:39:35 --> Model "Billing_model" initialized
INFO - 2026-01-31 17:39:35 --> Model "Common_model" initialized
INFO - 2026-01-31 17:39:35 --> Model "Order_model" initialized
INFO - 2026-01-31 17:39:35 --> Model "Support_model" initialized
INFO - 2026-01-31 17:39:36 --> Final output sent to browser
DEBUG - 2026-01-31 17:39:36 --> Total execution time: 4.3171
INFO - 2026-01-31 17:43:36 --> Config Class Initialized
INFO - 2026-01-31 17:43:36 --> Hooks Class Initialized
DEBUG - 2026-01-31 17:43:36 --> UTF-8 Support Enabled
INFO - 2026-01-31 17:43:36 --> Utf8 Class Initialized
INFO - 2026-01-31 17:43:36 --> URI Class Initialized
INFO - 2026-01-31 17:43:36 --> Router Class Initialized
INFO - 2026-01-31 17:43:36 --> Output Class Initialized
INFO - 2026-01-31 17:43:36 --> Security Class Initialized
DEBUG - 2026-01-31 17:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-01-31 17:43:36 --> CSRF cookie sent
INFO - 2026-01-31 17:43:36 --> Input Class Initialized
INFO - 2026-01-31 17:43:36 --> Language Class Initialized
INFO - 2026-01-31 17:43:36 --> Language Class Initialized
INFO - 2026-01-31 17:43:36 --> Config Class Initialized
INFO - 2026-01-31 17:43:36 --> Loader Class Initialized
INFO - 2026-01-31 17:43:36 --> Helper loaded: url_helper
INFO - 2026-01-31 17:43:36 --> Helper loaded: form_helper
INFO - 2026-01-31 17:43:36 --> Helper loaded: html_helper
INFO - 2026-01-31 17:43:36 --> Helper loaded: file_helper
INFO - 2026-01-31 17:43:36 --> Helper loaded: email_helper
INFO - 2026-01-31 17:43:36 --> Helper loaded: whmaz_helper
INFO - 2026-01-31 17:43:36 --> Helper loaded: ssp_helper
INFO - 2026-01-31 17:43:36 --> Helper loaded: cpanel_helper
INFO - 2026-01-31 17:43:36 --> Database Driver Class Initialized
INFO - 2026-01-31 17:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-01-31 17:43:38 --> Upload Class Initialized
DEBUG - 2026-01-31 17:43:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-01-31 17:43:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-01-31 17:43:38 --> Encryption Class Initialized
INFO - 2026-01-31 17:43:38 --> Form Validation Class Initialized
INFO - 2026-01-31 17:43:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-01-31 17:43:38 --> Pagination Class Initialized
INFO - 2026-01-31 17:43:38 --> Email Class Initialized
INFO - 2026-01-31 17:43:38 --> Controller Class Initialized
DEBUG - 2026-01-31 17:43:38 --> Cart MX_Controller Initialized
INFO - 2026-01-31 17:43:38 --> Model "Loginattempt_model" initialized
INFO - 2026-01-31 17:43:38 --> Model "Auth_model" initialized
INFO - 2026-01-31 17:43:38 --> Model "Cart_model" initialized
INFO - 2026-01-31 17:43:38 --> Model "Common_model" initialized
INFO - 2026-01-31 17:43:38 --> Model "Order_model" initialized
INFO - 2026-01-31 17:43:38 --> Model "Appsetting_model" initialized
DEBUG - 2026-01-31 17:43:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-01-31 17:43:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-01-31 17:43:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-01-31 17:43:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-01-31 17:43:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-01-31 17:43:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/cart_regnewdomain.php
INFO - 2026-01-31 17:43:40 --> Final output sent to browser
DEBUG - 2026-01-31 17:43:40 --> Total execution time: 3.6151

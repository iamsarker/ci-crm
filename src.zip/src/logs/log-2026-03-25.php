<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-03-25 01:59:30 --> Config Class Initialized
INFO - 2026-03-25 01:59:30 --> Hooks Class Initialized
DEBUG - 2026-03-25 01:59:30 --> UTF-8 Support Enabled
INFO - 2026-03-25 01:59:30 --> Utf8 Class Initialized
INFO - 2026-03-25 01:59:30 --> URI Class Initialized
DEBUG - 2026-03-25 01:59:30 --> No URI present. Default controller set.
INFO - 2026-03-25 01:59:30 --> Router Class Initialized
INFO - 2026-03-25 01:59:30 --> Output Class Initialized
INFO - 2026-03-25 01:59:30 --> Security Class Initialized
DEBUG - 2026-03-25 01:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-25 01:59:30 --> CSRF cookie sent
INFO - 2026-03-25 01:59:30 --> Input Class Initialized
INFO - 2026-03-25 01:59:30 --> Language Class Initialized
INFO - 2026-03-25 01:59:30 --> Language Class Initialized
INFO - 2026-03-25 01:59:30 --> Config Class Initialized
INFO - 2026-03-25 01:59:30 --> Loader Class Initialized
INFO - 2026-03-25 01:59:30 --> Helper loaded: url_helper
INFO - 2026-03-25 01:59:30 --> Helper loaded: form_helper
INFO - 2026-03-25 01:59:30 --> Helper loaded: html_helper
INFO - 2026-03-25 01:59:30 --> Helper loaded: file_helper
INFO - 2026-03-25 01:59:30 --> Helper loaded: email_helper
INFO - 2026-03-25 01:59:30 --> Helper loaded: whmaz_helper
INFO - 2026-03-25 01:59:30 --> Helper loaded: ssp_helper
INFO - 2026-03-25 01:59:30 --> Helper loaded: cpanel_helper
INFO - 2026-03-25 01:59:30 --> Helper loaded: plesk_helper
INFO - 2026-03-25 01:59:30 --> Helper loaded: directadmin_helper
INFO - 2026-03-25 01:59:30 --> Helper loaded: domain_helper
INFO - 2026-03-25 01:59:30 --> Database Driver Class Initialized
INFO - 2026-03-25 01:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-25 01:59:32 --> Upload Class Initialized
DEBUG - 2026-03-25 01:59:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-25 01:59:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-25 01:59:32 --> Encryption Class Initialized
INFO - 2026-03-25 01:59:32 --> Form Validation Class Initialized
INFO - 2026-03-25 01:59:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-25 01:59:32 --> Pagination Class Initialized
INFO - 2026-03-25 01:59:32 --> Email Class Initialized
INFO - 2026-03-25 01:59:32 --> Controller Class Initialized
DEBUG - 2026-03-25 01:59:32 --> Auth MX_Controller Initialized
INFO - 2026-03-25 01:59:32 --> Model "Loginattempt_model" initialized
INFO - 2026-03-25 01:59:32 --> Model "Auth_model" initialized
INFO - 2026-03-25 01:59:32 --> Model "Cart_model" initialized
INFO - 2026-03-25 01:59:33 --> Model "Appsetting_model" initialized
INFO - 2026-03-25 01:59:33 --> Config Class Initialized
INFO - 2026-03-25 01:59:33 --> Hooks Class Initialized
DEBUG - 2026-03-25 01:59:33 --> UTF-8 Support Enabled
INFO - 2026-03-25 01:59:33 --> Utf8 Class Initialized
INFO - 2026-03-25 01:59:33 --> URI Class Initialized
INFO - 2026-03-25 01:59:33 --> Router Class Initialized
INFO - 2026-03-25 01:59:33 --> Output Class Initialized
INFO - 2026-03-25 01:59:33 --> Security Class Initialized
DEBUG - 2026-03-25 01:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-25 01:59:33 --> CSRF cookie sent
INFO - 2026-03-25 01:59:33 --> Input Class Initialized
INFO - 2026-03-25 01:59:33 --> Language Class Initialized
INFO - 2026-03-25 01:59:33 --> Language Class Initialized
INFO - 2026-03-25 01:59:33 --> Config Class Initialized
INFO - 2026-03-25 01:59:33 --> Loader Class Initialized
INFO - 2026-03-25 01:59:33 --> Helper loaded: url_helper
INFO - 2026-03-25 01:59:33 --> Helper loaded: form_helper
INFO - 2026-03-25 01:59:33 --> Helper loaded: html_helper
INFO - 2026-03-25 01:59:33 --> Helper loaded: file_helper
INFO - 2026-03-25 01:59:33 --> Helper loaded: email_helper
INFO - 2026-03-25 01:59:33 --> Helper loaded: whmaz_helper
INFO - 2026-03-25 01:59:33 --> Helper loaded: ssp_helper
INFO - 2026-03-25 01:59:33 --> Helper loaded: cpanel_helper
INFO - 2026-03-25 01:59:33 --> Helper loaded: plesk_helper
INFO - 2026-03-25 01:59:33 --> Helper loaded: directadmin_helper
INFO - 2026-03-25 01:59:33 --> Helper loaded: domain_helper
INFO - 2026-03-25 01:59:33 --> Database Driver Class Initialized
INFO - 2026-03-25 01:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-25 01:59:35 --> Upload Class Initialized
DEBUG - 2026-03-25 01:59:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-25 01:59:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-25 01:59:35 --> Encryption Class Initialized
INFO - 2026-03-25 01:59:35 --> Form Validation Class Initialized
INFO - 2026-03-25 01:59:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-25 01:59:35 --> Pagination Class Initialized
INFO - 2026-03-25 01:59:35 --> Email Class Initialized
INFO - 2026-03-25 01:59:35 --> Controller Class Initialized
DEBUG - 2026-03-25 01:59:35 --> Auth MX_Controller Initialized
INFO - 2026-03-25 01:59:35 --> Model "Loginattempt_model" initialized
INFO - 2026-03-25 01:59:35 --> Model "Auth_model" initialized
INFO - 2026-03-25 01:59:35 --> Model "Cart_model" initialized
INFO - 2026-03-25 01:59:35 --> Model "Appsetting_model" initialized
DEBUG - 2026-03-25 01:59:35 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-03-25 01:59:35 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-03-25 01:59:35 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-03-25 01:59:35 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-03-25 01:59:35 --> Final output sent to browser
DEBUG - 2026-03-25 01:59:35 --> Total execution time: 2.3162
INFO - 2026-03-25 01:59:35 --> Config Class Initialized
INFO - 2026-03-25 01:59:35 --> Hooks Class Initialized
DEBUG - 2026-03-25 01:59:35 --> UTF-8 Support Enabled
INFO - 2026-03-25 01:59:35 --> Utf8 Class Initialized
INFO - 2026-03-25 01:59:35 --> URI Class Initialized
INFO - 2026-03-25 01:59:35 --> Router Class Initialized
INFO - 2026-03-25 01:59:35 --> Output Class Initialized
INFO - 2026-03-25 01:59:35 --> Security Class Initialized
DEBUG - 2026-03-25 01:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-25 01:59:35 --> CSRF cookie sent
INFO - 2026-03-25 01:59:35 --> Input Class Initialized
INFO - 2026-03-25 01:59:35 --> Language Class Initialized
INFO - 2026-03-25 01:59:35 --> Language Class Initialized
INFO - 2026-03-25 01:59:35 --> Config Class Initialized
INFO - 2026-03-25 01:59:35 --> Loader Class Initialized
INFO - 2026-03-25 01:59:35 --> Helper loaded: url_helper
INFO - 2026-03-25 01:59:35 --> Helper loaded: form_helper
INFO - 2026-03-25 01:59:35 --> Helper loaded: html_helper
INFO - 2026-03-25 01:59:35 --> Helper loaded: file_helper
INFO - 2026-03-25 01:59:35 --> Helper loaded: email_helper
INFO - 2026-03-25 01:59:35 --> Helper loaded: whmaz_helper
INFO - 2026-03-25 01:59:35 --> Helper loaded: ssp_helper
INFO - 2026-03-25 01:59:35 --> Helper loaded: cpanel_helper
INFO - 2026-03-25 01:59:35 --> Helper loaded: plesk_helper
INFO - 2026-03-25 01:59:35 --> Helper loaded: directadmin_helper
INFO - 2026-03-25 01:59:35 --> Helper loaded: domain_helper
INFO - 2026-03-25 01:59:35 --> Database Driver Class Initialized
INFO - 2026-03-25 01:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-25 01:59:37 --> Upload Class Initialized
DEBUG - 2026-03-25 01:59:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-25 01:59:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-25 01:59:37 --> Encryption Class Initialized
INFO - 2026-03-25 01:59:37 --> Form Validation Class Initialized
INFO - 2026-03-25 01:59:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-25 01:59:37 --> Pagination Class Initialized
INFO - 2026-03-25 01:59:37 --> Email Class Initialized
INFO - 2026-03-25 01:59:37 --> Controller Class Initialized
DEBUG - 2026-03-25 01:59:37 --> Cart MX_Controller Initialized
INFO - 2026-03-25 01:59:37 --> Model "Loginattempt_model" initialized
INFO - 2026-03-25 01:59:37 --> Model "Auth_model" initialized
INFO - 2026-03-25 01:59:37 --> Model "Cart_model" initialized
INFO - 2026-03-25 01:59:37 --> Model "Common_model" initialized
INFO - 2026-03-25 01:59:37 --> Model "Order_model" initialized
INFO - 2026-03-25 01:59:37 --> Model "Appsetting_model" initialized
INFO - 2026-03-25 01:59:37 --> Model "PaymentGateway_model" initialized
INFO - 2026-03-25 01:59:37 --> Model "Promocode_model" initialized
INFO - 2026-03-25 01:59:37 --> Final output sent to browser
DEBUG - 2026-03-25 01:59:37 --> Total execution time: 2.2959
INFO - 2026-03-25 02:01:37 --> Config Class Initialized
INFO - 2026-03-25 02:01:37 --> Hooks Class Initialized
DEBUG - 2026-03-25 02:01:37 --> UTF-8 Support Enabled
INFO - 2026-03-25 02:01:37 --> Utf8 Class Initialized
INFO - 2026-03-25 02:01:37 --> URI Class Initialized
INFO - 2026-03-25 02:01:37 --> Router Class Initialized
INFO - 2026-03-25 02:01:37 --> Output Class Initialized
INFO - 2026-03-25 02:01:37 --> Security Class Initialized
DEBUG - 2026-03-25 02:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-25 02:01:37 --> CSRF cookie sent
INFO - 2026-03-25 02:01:37 --> CSRF token verified
INFO - 2026-03-25 02:01:37 --> Input Class Initialized
INFO - 2026-03-25 02:01:37 --> Language Class Initialized
INFO - 2026-03-25 02:01:37 --> Language Class Initialized
INFO - 2026-03-25 02:01:37 --> Config Class Initialized
INFO - 2026-03-25 02:01:37 --> Loader Class Initialized
INFO - 2026-03-25 02:01:37 --> Helper loaded: url_helper
INFO - 2026-03-25 02:01:37 --> Helper loaded: form_helper
INFO - 2026-03-25 02:01:37 --> Helper loaded: html_helper
INFO - 2026-03-25 02:01:37 --> Helper loaded: file_helper
INFO - 2026-03-25 02:01:37 --> Helper loaded: email_helper
INFO - 2026-03-25 02:01:37 --> Helper loaded: whmaz_helper
INFO - 2026-03-25 02:01:37 --> Helper loaded: ssp_helper
INFO - 2026-03-25 02:01:37 --> Helper loaded: cpanel_helper
INFO - 2026-03-25 02:01:37 --> Helper loaded: plesk_helper
INFO - 2026-03-25 02:01:37 --> Helper loaded: directadmin_helper
INFO - 2026-03-25 02:01:37 --> Helper loaded: domain_helper
INFO - 2026-03-25 02:01:37 --> Database Driver Class Initialized
INFO - 2026-03-25 02:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-25 02:01:39 --> Upload Class Initialized
DEBUG - 2026-03-25 02:01:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-25 02:01:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-25 02:01:39 --> Encryption Class Initialized
INFO - 2026-03-25 02:01:39 --> Form Validation Class Initialized
INFO - 2026-03-25 02:01:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-25 02:01:39 --> Pagination Class Initialized
INFO - 2026-03-25 02:01:39 --> Email Class Initialized
INFO - 2026-03-25 02:01:39 --> Controller Class Initialized
DEBUG - 2026-03-25 02:01:39 --> Auth MX_Controller Initialized
INFO - 2026-03-25 02:01:39 --> Model "Loginattempt_model" initialized
INFO - 2026-03-25 02:01:39 --> Model "Auth_model" initialized
INFO - 2026-03-25 02:01:39 --> Model "Cart_model" initialized
INFO - 2026-03-25 02:01:39 --> Model "Appsetting_model" initialized
INFO - 2026-03-25 02:01:43 --> Config Class Initialized
INFO - 2026-03-25 02:01:43 --> Hooks Class Initialized
DEBUG - 2026-03-25 02:01:43 --> UTF-8 Support Enabled
INFO - 2026-03-25 02:01:43 --> Utf8 Class Initialized
INFO - 2026-03-25 02:01:43 --> URI Class Initialized
INFO - 2026-03-25 02:01:43 --> Router Class Initialized
INFO - 2026-03-25 02:01:43 --> Output Class Initialized
INFO - 2026-03-25 02:01:43 --> Security Class Initialized
DEBUG - 2026-03-25 02:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-25 02:01:43 --> CSRF cookie sent
INFO - 2026-03-25 02:01:43 --> Input Class Initialized
INFO - 2026-03-25 02:01:43 --> Language Class Initialized
INFO - 2026-03-25 02:01:43 --> Language Class Initialized
INFO - 2026-03-25 02:01:43 --> Config Class Initialized
INFO - 2026-03-25 02:01:43 --> Loader Class Initialized
INFO - 2026-03-25 02:01:43 --> Helper loaded: url_helper
INFO - 2026-03-25 02:01:43 --> Helper loaded: form_helper
INFO - 2026-03-25 02:01:43 --> Helper loaded: html_helper
INFO - 2026-03-25 02:01:43 --> Helper loaded: file_helper
INFO - 2026-03-25 02:01:43 --> Helper loaded: email_helper
INFO - 2026-03-25 02:01:43 --> Helper loaded: whmaz_helper
INFO - 2026-03-25 02:01:43 --> Helper loaded: ssp_helper
INFO - 2026-03-25 02:01:43 --> Helper loaded: cpanel_helper
INFO - 2026-03-25 02:01:43 --> Helper loaded: plesk_helper
INFO - 2026-03-25 02:01:43 --> Helper loaded: directadmin_helper
INFO - 2026-03-25 02:01:43 --> Helper loaded: domain_helper
INFO - 2026-03-25 02:01:43 --> Database Driver Class Initialized
INFO - 2026-03-25 02:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-25 02:01:45 --> Upload Class Initialized
DEBUG - 2026-03-25 02:01:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-25 02:01:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-25 02:01:45 --> Encryption Class Initialized
INFO - 2026-03-25 02:01:45 --> Form Validation Class Initialized
INFO - 2026-03-25 02:01:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-25 02:01:45 --> Pagination Class Initialized
INFO - 2026-03-25 02:01:45 --> Email Class Initialized
INFO - 2026-03-25 02:01:45 --> Controller Class Initialized
DEBUG - 2026-03-25 02:01:45 --> Clientarea MX_Controller Initialized
INFO - 2026-03-25 02:01:45 --> Model "Loginattempt_model" initialized
INFO - 2026-03-25 02:01:45 --> Model "Auth_model" initialized
INFO - 2026-03-25 02:01:45 --> Model "Cart_model" initialized
INFO - 2026-03-25 02:01:45 --> Model "Clientarea_model" initialized
INFO - 2026-03-25 02:01:45 --> Model "Billing_model" initialized
INFO - 2026-03-25 02:01:45 --> Model "Common_model" initialized
INFO - 2026-03-25 02:01:45 --> Model "Order_model" initialized
INFO - 2026-03-25 02:01:45 --> Model "Support_model" initialized
DEBUG - 2026-03-25 02:01:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-03-25 02:01:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-03-25 02:01:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-03-25 02:01:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_index.php
INFO - 2026-03-25 02:01:45 --> Final output sent to browser
DEBUG - 2026-03-25 02:01:45 --> Total execution time: 2.4258
INFO - 2026-03-25 02:01:45 --> Config Class Initialized
INFO - 2026-03-25 02:01:45 --> Hooks Class Initialized
DEBUG - 2026-03-25 02:01:45 --> UTF-8 Support Enabled
INFO - 2026-03-25 02:01:45 --> Utf8 Class Initialized
INFO - 2026-03-25 02:01:45 --> URI Class Initialized
INFO - 2026-03-25 02:01:45 --> Router Class Initialized
INFO - 2026-03-25 02:01:45 --> Output Class Initialized
INFO - 2026-03-25 02:01:45 --> Security Class Initialized
DEBUG - 2026-03-25 02:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-25 02:01:45 --> CSRF cookie sent
INFO - 2026-03-25 02:01:45 --> Input Class Initialized
INFO - 2026-03-25 02:01:45 --> Language Class Initialized
INFO - 2026-03-25 02:01:45 --> Language Class Initialized
INFO - 2026-03-25 02:01:45 --> Config Class Initialized
INFO - 2026-03-25 02:01:45 --> Loader Class Initialized
INFO - 2026-03-25 02:01:45 --> Helper loaded: url_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: form_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: html_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: file_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: email_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: whmaz_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: ssp_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: cpanel_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: plesk_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: directadmin_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: domain_helper
INFO - 2026-03-25 02:01:45 --> Config Class Initialized
INFO - 2026-03-25 02:01:45 --> Hooks Class Initialized
INFO - 2026-03-25 02:01:45 --> Config Class Initialized
INFO - 2026-03-25 02:01:45 --> Hooks Class Initialized
DEBUG - 2026-03-25 02:01:45 --> UTF-8 Support Enabled
INFO - 2026-03-25 02:01:45 --> Utf8 Class Initialized
DEBUG - 2026-03-25 02:01:45 --> UTF-8 Support Enabled
INFO - 2026-03-25 02:01:45 --> Utf8 Class Initialized
INFO - 2026-03-25 02:01:45 --> Database Driver Class Initialized
INFO - 2026-03-25 02:01:45 --> URI Class Initialized
INFO - 2026-03-25 02:01:45 --> URI Class Initialized
INFO - 2026-03-25 02:01:45 --> Router Class Initialized
INFO - 2026-03-25 02:01:45 --> Router Class Initialized
INFO - 2026-03-25 02:01:45 --> Output Class Initialized
INFO - 2026-03-25 02:01:45 --> Output Class Initialized
INFO - 2026-03-25 02:01:45 --> Security Class Initialized
DEBUG - 2026-03-25 02:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-25 02:01:45 --> Security Class Initialized
INFO - 2026-03-25 02:01:45 --> Input Class Initialized
INFO - 2026-03-25 02:01:45 --> Language Class Initialized
DEBUG - 2026-03-25 02:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-25 02:01:45 --> Language Class Initialized
INFO - 2026-03-25 02:01:45 --> Config Class Initialized
INFO - 2026-03-25 02:01:45 --> Input Class Initialized
INFO - 2026-03-25 02:01:45 --> Language Class Initialized
INFO - 2026-03-25 02:01:45 --> Language Class Initialized
INFO - 2026-03-25 02:01:45 --> Config Class Initialized
INFO - 2026-03-25 02:01:45 --> Config Class Initialized
INFO - 2026-03-25 02:01:45 --> Hooks Class Initialized
INFO - 2026-03-25 02:01:45 --> Loader Class Initialized
DEBUG - 2026-03-25 02:01:45 --> UTF-8 Support Enabled
INFO - 2026-03-25 02:01:45 --> Utf8 Class Initialized
INFO - 2026-03-25 02:01:45 --> Helper loaded: url_helper
INFO - 2026-03-25 02:01:45 --> Loader Class Initialized
INFO - 2026-03-25 02:01:45 --> URI Class Initialized
INFO - 2026-03-25 02:01:45 --> Helper loaded: form_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: url_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: html_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: file_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: email_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: form_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: html_helper
INFO - 2026-03-25 02:01:45 --> Router Class Initialized
INFO - 2026-03-25 02:01:45 --> Helper loaded: file_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: email_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: whmaz_helper
INFO - 2026-03-25 02:01:45 --> Output Class Initialized
INFO - 2026-03-25 02:01:45 --> Helper loaded: ssp_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: whmaz_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: ssp_helper
INFO - 2026-03-25 02:01:45 --> Security Class Initialized
INFO - 2026-03-25 02:01:45 --> Helper loaded: cpanel_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: cpanel_helper
DEBUG - 2026-03-25 02:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-25 02:01:45 --> Input Class Initialized
INFO - 2026-03-25 02:01:45 --> Language Class Initialized
INFO - 2026-03-25 02:01:45 --> Helper loaded: plesk_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: plesk_helper
INFO - 2026-03-25 02:01:45 --> Language Class Initialized
INFO - 2026-03-25 02:01:45 --> Config Class Initialized
INFO - 2026-03-25 02:01:45 --> Helper loaded: directadmin_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: directadmin_helper
INFO - 2026-03-25 02:01:45 --> Loader Class Initialized
INFO - 2026-03-25 02:01:45 --> Helper loaded: domain_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: domain_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: url_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: form_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: html_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: file_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: email_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: whmaz_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: ssp_helper
INFO - 2026-03-25 02:01:45 --> Database Driver Class Initialized
INFO - 2026-03-25 02:01:45 --> Helper loaded: cpanel_helper
INFO - 2026-03-25 02:01:45 --> Database Driver Class Initialized
INFO - 2026-03-25 02:01:45 --> Helper loaded: plesk_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: directadmin_helper
INFO - 2026-03-25 02:01:45 --> Helper loaded: domain_helper
INFO - 2026-03-25 02:01:45 --> Database Driver Class Initialized
INFO - 2026-03-25 02:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-25 02:01:47 --> Upload Class Initialized
DEBUG - 2026-03-25 02:01:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-25 02:01:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-25 02:01:47 --> Encryption Class Initialized
INFO - 2026-03-25 02:01:47 --> Form Validation Class Initialized
INFO - 2026-03-25 02:01:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-25 02:01:47 --> Pagination Class Initialized
INFO - 2026-03-25 02:01:47 --> Email Class Initialized
INFO - 2026-03-25 02:01:47 --> Controller Class Initialized
DEBUG - 2026-03-25 02:01:47 --> Tickets MX_Controller Initialized
INFO - 2026-03-25 02:01:47 --> Model "Loginattempt_model" initialized
INFO - 2026-03-25 02:01:47 --> Model "Auth_model" initialized
INFO - 2026-03-25 02:01:47 --> Model "Cart_model" initialized
INFO - 2026-03-25 02:01:47 --> Model "Support_model" initialized
INFO - 2026-03-25 02:01:47 --> Model "Common_model" initialized
INFO - 2026-03-25 02:01:48 --> Final output sent to browser
DEBUG - 2026-03-25 02:01:48 --> Total execution time: 2.6657
INFO - 2026-03-25 02:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-25 02:01:48 --> Upload Class Initialized
DEBUG - 2026-03-25 02:01:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-25 02:01:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-25 02:01:48 --> Encryption Class Initialized
INFO - 2026-03-25 02:01:48 --> Form Validation Class Initialized
INFO - 2026-03-25 02:01:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-25 02:01:48 --> Pagination Class Initialized
INFO - 2026-03-25 02:01:48 --> Email Class Initialized
INFO - 2026-03-25 02:01:48 --> Controller Class Initialized
DEBUG - 2026-03-25 02:01:48 --> Cart MX_Controller Initialized
INFO - 2026-03-25 02:01:48 --> Model "Loginattempt_model" initialized
INFO - 2026-03-25 02:01:48 --> Model "Auth_model" initialized
INFO - 2026-03-25 02:01:48 --> Model "Cart_model" initialized
INFO - 2026-03-25 02:01:48 --> Model "Common_model" initialized
INFO - 2026-03-25 02:01:48 --> Model "Order_model" initialized
INFO - 2026-03-25 02:01:48 --> Model "Appsetting_model" initialized
INFO - 2026-03-25 02:01:48 --> Model "PaymentGateway_model" initialized
INFO - 2026-03-25 02:01:48 --> Model "Promocode_model" initialized
INFO - 2026-03-25 02:01:48 --> Final output sent to browser
DEBUG - 2026-03-25 02:01:48 --> Total execution time: 3.0880
INFO - 2026-03-25 02:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-25 02:01:48 --> Upload Class Initialized
DEBUG - 2026-03-25 02:01:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-25 02:01:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-25 02:01:48 --> Encryption Class Initialized
INFO - 2026-03-25 02:01:48 --> Form Validation Class Initialized
INFO - 2026-03-25 02:01:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-25 02:01:48 --> Pagination Class Initialized
INFO - 2026-03-25 02:01:48 --> Email Class Initialized
INFO - 2026-03-25 02:01:48 --> Controller Class Initialized
DEBUG - 2026-03-25 02:01:48 --> Clientarea MX_Controller Initialized
INFO - 2026-03-25 02:01:48 --> Model "Loginattempt_model" initialized
INFO - 2026-03-25 02:01:48 --> Model "Auth_model" initialized
INFO - 2026-03-25 02:01:48 --> Model "Cart_model" initialized
INFO - 2026-03-25 02:01:48 --> Model "Clientarea_model" initialized
INFO - 2026-03-25 02:01:48 --> Model "Billing_model" initialized
INFO - 2026-03-25 02:01:48 --> Model "Common_model" initialized
INFO - 2026-03-25 02:01:48 --> Model "Order_model" initialized
INFO - 2026-03-25 02:01:48 --> Model "Support_model" initialized
INFO - 2026-03-25 02:01:49 --> Final output sent to browser
DEBUG - 2026-03-25 02:01:49 --> Total execution time: 3.8961
INFO - 2026-03-25 02:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-25 02:01:49 --> Upload Class Initialized
DEBUG - 2026-03-25 02:01:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-25 02:01:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-25 02:01:49 --> Encryption Class Initialized
INFO - 2026-03-25 02:01:49 --> Form Validation Class Initialized
INFO - 2026-03-25 02:01:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-25 02:01:49 --> Pagination Class Initialized
INFO - 2026-03-25 02:01:49 --> Email Class Initialized
INFO - 2026-03-25 02:01:49 --> Controller Class Initialized
DEBUG - 2026-03-25 02:01:49 --> Billing MX_Controller Initialized
INFO - 2026-03-25 02:01:49 --> Model "Loginattempt_model" initialized
INFO - 2026-03-25 02:01:49 --> Model "Auth_model" initialized
INFO - 2026-03-25 02:01:49 --> Model "Cart_model" initialized
INFO - 2026-03-25 02:01:49 --> Model "Billing_model" initialized
INFO - 2026-03-25 02:01:49 --> Model "Common_model" initialized
INFO - 2026-03-25 02:01:49 --> Model "Appsetting_model" initialized
INFO - 2026-03-25 02:01:50 --> Final output sent to browser
DEBUG - 2026-03-25 02:01:50 --> Total execution time: 4.7047
INFO - 2026-03-25 02:10:49 --> Config Class Initialized
INFO - 2026-03-25 02:10:49 --> Hooks Class Initialized
DEBUG - 2026-03-25 02:10:49 --> UTF-8 Support Enabled
INFO - 2026-03-25 02:10:49 --> Utf8 Class Initialized
INFO - 2026-03-25 02:10:49 --> URI Class Initialized
INFO - 2026-03-25 02:10:49 --> Router Class Initialized
INFO - 2026-03-25 02:10:49 --> Output Class Initialized
INFO - 2026-03-25 02:10:49 --> Security Class Initialized
DEBUG - 2026-03-25 02:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-25 02:10:49 --> CSRF cookie sent
INFO - 2026-03-25 02:10:49 --> Input Class Initialized
INFO - 2026-03-25 02:10:49 --> Language Class Initialized
INFO - 2026-03-25 02:10:49 --> Language Class Initialized
INFO - 2026-03-25 02:10:49 --> Config Class Initialized
INFO - 2026-03-25 02:10:49 --> Loader Class Initialized
INFO - 2026-03-25 02:10:49 --> Helper loaded: url_helper
INFO - 2026-03-25 02:10:49 --> Helper loaded: form_helper
INFO - 2026-03-25 02:10:49 --> Helper loaded: html_helper
INFO - 2026-03-25 02:10:49 --> Helper loaded: file_helper
INFO - 2026-03-25 02:10:49 --> Helper loaded: email_helper
INFO - 2026-03-25 02:10:49 --> Helper loaded: whmaz_helper
INFO - 2026-03-25 02:10:49 --> Helper loaded: ssp_helper
INFO - 2026-03-25 02:10:49 --> Helper loaded: cpanel_helper
INFO - 2026-03-25 02:10:49 --> Helper loaded: plesk_helper
INFO - 2026-03-25 02:10:49 --> Helper loaded: directadmin_helper
INFO - 2026-03-25 02:10:49 --> Helper loaded: domain_helper
INFO - 2026-03-25 02:10:49 --> Database Driver Class Initialized
INFO - 2026-03-25 02:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-25 02:10:51 --> Upload Class Initialized
DEBUG - 2026-03-25 02:10:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-25 02:10:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-25 02:10:51 --> Encryption Class Initialized
INFO - 2026-03-25 02:10:51 --> Form Validation Class Initialized
INFO - 2026-03-25 02:10:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-25 02:10:51 --> Pagination Class Initialized
INFO - 2026-03-25 02:10:51 --> Email Class Initialized
INFO - 2026-03-25 02:10:51 --> Controller Class Initialized
DEBUG - 2026-03-25 02:10:51 --> Cart MX_Controller Initialized
INFO - 2026-03-25 02:10:51 --> Model "Loginattempt_model" initialized
INFO - 2026-03-25 02:10:51 --> Model "Auth_model" initialized
INFO - 2026-03-25 02:10:51 --> Model "Cart_model" initialized
INFO - 2026-03-25 02:10:51 --> Model "Common_model" initialized
INFO - 2026-03-25 02:10:51 --> Model "Order_model" initialized
INFO - 2026-03-25 02:10:51 --> Model "Appsetting_model" initialized
INFO - 2026-03-25 02:10:51 --> Model "PaymentGateway_model" initialized
INFO - 2026-03-25 02:10:51 --> Model "Promocode_model" initialized
DEBUG - 2026-03-25 02:10:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-03-25 02:10:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-03-25 02:10:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-03-25 02:10:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-03-25 02:10:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-03-25 02:10:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/cart_regnewdomain.php
INFO - 2026-03-25 02:10:52 --> Final output sent to browser
DEBUG - 2026-03-25 02:10:52 --> Total execution time: 3.6914
INFO - 2026-03-25 02:10:52 --> Config Class Initialized
INFO - 2026-03-25 02:10:52 --> Hooks Class Initialized
DEBUG - 2026-03-25 02:10:52 --> UTF-8 Support Enabled
INFO - 2026-03-25 02:10:52 --> Utf8 Class Initialized
INFO - 2026-03-25 02:10:52 --> URI Class Initialized
INFO - 2026-03-25 02:10:52 --> Router Class Initialized
INFO - 2026-03-25 02:10:52 --> Output Class Initialized
INFO - 2026-03-25 02:10:52 --> Security Class Initialized
DEBUG - 2026-03-25 02:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-25 02:10:52 --> CSRF cookie sent
INFO - 2026-03-25 02:10:52 --> Input Class Initialized
INFO - 2026-03-25 02:10:52 --> Language Class Initialized
INFO - 2026-03-25 02:10:52 --> Language Class Initialized
INFO - 2026-03-25 02:10:52 --> Config Class Initialized
INFO - 2026-03-25 02:10:52 --> Loader Class Initialized
INFO - 2026-03-25 02:10:52 --> Helper loaded: url_helper
INFO - 2026-03-25 02:10:52 --> Helper loaded: form_helper
INFO - 2026-03-25 02:10:52 --> Helper loaded: html_helper
INFO - 2026-03-25 02:10:52 --> Helper loaded: file_helper
INFO - 2026-03-25 02:10:52 --> Helper loaded: email_helper
INFO - 2026-03-25 02:10:52 --> Helper loaded: whmaz_helper
INFO - 2026-03-25 02:10:52 --> Helper loaded: ssp_helper
INFO - 2026-03-25 02:10:52 --> Helper loaded: cpanel_helper
INFO - 2026-03-25 02:10:52 --> Helper loaded: plesk_helper
INFO - 2026-03-25 02:10:52 --> Helper loaded: directadmin_helper
INFO - 2026-03-25 02:10:52 --> Helper loaded: domain_helper
INFO - 2026-03-25 02:10:52 --> Database Driver Class Initialized
INFO - 2026-03-25 02:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-25 02:10:54 --> Upload Class Initialized
DEBUG - 2026-03-25 02:10:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-25 02:10:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-25 02:10:54 --> Encryption Class Initialized
INFO - 2026-03-25 02:10:54 --> Form Validation Class Initialized
INFO - 2026-03-25 02:10:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-25 02:10:54 --> Pagination Class Initialized
INFO - 2026-03-25 02:10:54 --> Email Class Initialized
INFO - 2026-03-25 02:10:54 --> Controller Class Initialized
DEBUG - 2026-03-25 02:10:54 --> Cart MX_Controller Initialized
INFO - 2026-03-25 02:10:54 --> Model "Loginattempt_model" initialized
INFO - 2026-03-25 02:10:54 --> Model "Auth_model" initialized
INFO - 2026-03-25 02:10:54 --> Model "Cart_model" initialized
INFO - 2026-03-25 02:10:54 --> Model "Common_model" initialized
INFO - 2026-03-25 02:10:54 --> Model "Order_model" initialized
INFO - 2026-03-25 02:10:54 --> Model "Appsetting_model" initialized
INFO - 2026-03-25 02:10:54 --> Model "PaymentGateway_model" initialized
INFO - 2026-03-25 02:10:54 --> Model "Promocode_model" initialized
INFO - 2026-03-25 02:10:55 --> Final output sent to browser
DEBUG - 2026-03-25 02:10:55 --> Total execution time: 2.1785
INFO - 2026-03-25 02:12:13 --> Config Class Initialized
INFO - 2026-03-25 02:12:13 --> Hooks Class Initialized
DEBUG - 2026-03-25 02:12:13 --> UTF-8 Support Enabled
INFO - 2026-03-25 02:12:13 --> Utf8 Class Initialized
INFO - 2026-03-25 02:12:13 --> URI Class Initialized
INFO - 2026-03-25 02:12:13 --> Router Class Initialized
INFO - 2026-03-25 02:12:13 --> Output Class Initialized
INFO - 2026-03-25 02:12:13 --> Security Class Initialized
DEBUG - 2026-03-25 02:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-25 02:12:13 --> CSRF cookie sent
INFO - 2026-03-25 02:12:13 --> Input Class Initialized
INFO - 2026-03-25 02:12:13 --> Language Class Initialized
INFO - 2026-03-25 02:12:13 --> Language Class Initialized
INFO - 2026-03-25 02:12:13 --> Config Class Initialized
INFO - 2026-03-25 02:12:13 --> Loader Class Initialized
INFO - 2026-03-25 02:12:13 --> Helper loaded: url_helper
INFO - 2026-03-25 02:12:13 --> Helper loaded: form_helper
INFO - 2026-03-25 02:12:13 --> Helper loaded: html_helper
INFO - 2026-03-25 02:12:13 --> Helper loaded: file_helper
INFO - 2026-03-25 02:12:13 --> Helper loaded: email_helper
INFO - 2026-03-25 02:12:13 --> Helper loaded: whmaz_helper
INFO - 2026-03-25 02:12:13 --> Helper loaded: ssp_helper
INFO - 2026-03-25 02:12:13 --> Helper loaded: cpanel_helper
INFO - 2026-03-25 02:12:13 --> Helper loaded: plesk_helper
INFO - 2026-03-25 02:12:13 --> Helper loaded: directadmin_helper
INFO - 2026-03-25 02:12:13 --> Helper loaded: domain_helper
INFO - 2026-03-25 02:12:13 --> Database Driver Class Initialized
INFO - 2026-03-25 02:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-25 02:12:15 --> Upload Class Initialized
DEBUG - 2026-03-25 02:12:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-25 02:12:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-25 02:12:15 --> Encryption Class Initialized
INFO - 2026-03-25 02:12:15 --> Form Validation Class Initialized
INFO - 2026-03-25 02:12:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-25 02:12:15 --> Pagination Class Initialized
INFO - 2026-03-25 02:12:15 --> Email Class Initialized
INFO - 2026-03-25 02:12:15 --> Controller Class Initialized
DEBUG - 2026-03-25 02:12:15 --> Dashboard MX_Controller Initialized
INFO - 2026-03-25 02:12:15 --> Model "Loginattempt_model" initialized
INFO - 2026-03-25 02:12:15 --> Model "Adminauth_model" initialized
INFO - 2026-03-25 02:12:15 --> Config Class Initialized
INFO - 2026-03-25 02:12:15 --> Hooks Class Initialized
DEBUG - 2026-03-25 02:12:15 --> UTF-8 Support Enabled
INFO - 2026-03-25 02:12:15 --> Utf8 Class Initialized
INFO - 2026-03-25 02:12:15 --> URI Class Initialized
INFO - 2026-03-25 02:12:15 --> Router Class Initialized
INFO - 2026-03-25 02:12:15 --> Output Class Initialized
INFO - 2026-03-25 02:12:15 --> Security Class Initialized
DEBUG - 2026-03-25 02:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-25 02:12:15 --> CSRF cookie sent
INFO - 2026-03-25 02:12:15 --> Input Class Initialized
INFO - 2026-03-25 02:12:15 --> Language Class Initialized
INFO - 2026-03-25 02:12:15 --> Language Class Initialized
INFO - 2026-03-25 02:12:15 --> Config Class Initialized
INFO - 2026-03-25 02:12:15 --> Loader Class Initialized
INFO - 2026-03-25 02:12:15 --> Helper loaded: url_helper
INFO - 2026-03-25 02:12:15 --> Helper loaded: form_helper
INFO - 2026-03-25 02:12:15 --> Helper loaded: html_helper
INFO - 2026-03-25 02:12:15 --> Helper loaded: file_helper
INFO - 2026-03-25 02:12:15 --> Helper loaded: email_helper
INFO - 2026-03-25 02:12:15 --> Helper loaded: whmaz_helper
INFO - 2026-03-25 02:12:15 --> Helper loaded: ssp_helper
INFO - 2026-03-25 02:12:15 --> Helper loaded: cpanel_helper
INFO - 2026-03-25 02:12:15 --> Helper loaded: plesk_helper
INFO - 2026-03-25 02:12:15 --> Helper loaded: directadmin_helper
INFO - 2026-03-25 02:12:15 --> Helper loaded: domain_helper
INFO - 2026-03-25 02:12:15 --> Database Driver Class Initialized
INFO - 2026-03-25 02:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-25 02:12:17 --> Upload Class Initialized
DEBUG - 2026-03-25 02:12:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-25 02:12:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-25 02:12:17 --> Encryption Class Initialized
INFO - 2026-03-25 02:12:17 --> Form Validation Class Initialized
INFO - 2026-03-25 02:12:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-25 02:12:17 --> Pagination Class Initialized
INFO - 2026-03-25 02:12:17 --> Email Class Initialized
INFO - 2026-03-25 02:12:17 --> Controller Class Initialized
DEBUG - 2026-03-25 02:12:17 --> Authenticate MX_Controller Initialized
INFO - 2026-03-25 02:12:17 --> Model "Loginattempt_model" initialized
INFO - 2026-03-25 02:12:17 --> Model "Adminauth_model" initialized
INFO - 2026-03-25 02:12:17 --> Model "Appsetting_model" initialized
DEBUG - 2026-03-25 02:12:17 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-25 02:12:17 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-25 02:12:17 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-03-25 02:12:17 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-25 02:12:17 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-25 02:12:17 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-03-25 02:12:17 --> Final output sent to browser
DEBUG - 2026-03-25 02:12:17 --> Total execution time: 2.3298
INFO - 2026-03-25 02:12:42 --> Config Class Initialized
INFO - 2026-03-25 02:12:42 --> Hooks Class Initialized
DEBUG - 2026-03-25 02:12:42 --> UTF-8 Support Enabled
INFO - 2026-03-25 02:12:42 --> Utf8 Class Initialized
INFO - 2026-03-25 02:12:42 --> URI Class Initialized
INFO - 2026-03-25 02:12:42 --> Router Class Initialized
INFO - 2026-03-25 02:12:42 --> Output Class Initialized
INFO - 2026-03-25 02:12:42 --> Security Class Initialized
DEBUG - 2026-03-25 02:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-25 02:12:42 --> CSRF cookie sent
INFO - 2026-03-25 02:12:42 --> CSRF token verified
INFO - 2026-03-25 02:12:42 --> Input Class Initialized
INFO - 2026-03-25 02:12:42 --> Language Class Initialized
INFO - 2026-03-25 02:12:42 --> Language Class Initialized
INFO - 2026-03-25 02:12:42 --> Config Class Initialized
INFO - 2026-03-25 02:12:42 --> Loader Class Initialized
INFO - 2026-03-25 02:12:42 --> Helper loaded: url_helper
INFO - 2026-03-25 02:12:42 --> Helper loaded: form_helper
INFO - 2026-03-25 02:12:42 --> Helper loaded: html_helper
INFO - 2026-03-25 02:12:42 --> Helper loaded: file_helper
INFO - 2026-03-25 02:12:42 --> Helper loaded: email_helper
INFO - 2026-03-25 02:12:42 --> Helper loaded: whmaz_helper
INFO - 2026-03-25 02:12:42 --> Helper loaded: ssp_helper
INFO - 2026-03-25 02:12:42 --> Helper loaded: cpanel_helper
INFO - 2026-03-25 02:12:42 --> Helper loaded: plesk_helper
INFO - 2026-03-25 02:12:42 --> Helper loaded: directadmin_helper
INFO - 2026-03-25 02:12:42 --> Helper loaded: domain_helper
INFO - 2026-03-25 02:12:42 --> Database Driver Class Initialized
INFO - 2026-03-25 02:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-25 02:12:44 --> Upload Class Initialized
DEBUG - 2026-03-25 02:12:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-25 02:12:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-25 02:12:44 --> Encryption Class Initialized
INFO - 2026-03-25 02:12:44 --> Form Validation Class Initialized
INFO - 2026-03-25 02:12:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-25 02:12:44 --> Pagination Class Initialized
INFO - 2026-03-25 02:12:44 --> Email Class Initialized
INFO - 2026-03-25 02:12:44 --> Controller Class Initialized
DEBUG - 2026-03-25 02:12:44 --> Authenticate MX_Controller Initialized
INFO - 2026-03-25 02:12:44 --> Model "Loginattempt_model" initialized
INFO - 2026-03-25 02:12:44 --> Model "Adminauth_model" initialized
INFO - 2026-03-25 02:12:44 --> Model "Appsetting_model" initialized
INFO - 2026-03-25 02:12:47 --> Config Class Initialized
INFO - 2026-03-25 02:12:47 --> Hooks Class Initialized
DEBUG - 2026-03-25 02:12:47 --> UTF-8 Support Enabled
INFO - 2026-03-25 02:12:47 --> Utf8 Class Initialized
INFO - 2026-03-25 02:12:47 --> URI Class Initialized
INFO - 2026-03-25 02:12:47 --> Router Class Initialized
INFO - 2026-03-25 02:12:47 --> Output Class Initialized
INFO - 2026-03-25 02:12:47 --> Security Class Initialized
DEBUG - 2026-03-25 02:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-25 02:12:47 --> CSRF cookie sent
INFO - 2026-03-25 02:12:47 --> Input Class Initialized
INFO - 2026-03-25 02:12:47 --> Language Class Initialized
INFO - 2026-03-25 02:12:47 --> Language Class Initialized
INFO - 2026-03-25 02:12:47 --> Config Class Initialized
INFO - 2026-03-25 02:12:47 --> Loader Class Initialized
INFO - 2026-03-25 02:12:47 --> Helper loaded: url_helper
INFO - 2026-03-25 02:12:47 --> Helper loaded: form_helper
INFO - 2026-03-25 02:12:47 --> Helper loaded: html_helper
INFO - 2026-03-25 02:12:47 --> Helper loaded: file_helper
INFO - 2026-03-25 02:12:47 --> Helper loaded: email_helper
INFO - 2026-03-25 02:12:47 --> Helper loaded: whmaz_helper
INFO - 2026-03-25 02:12:47 --> Helper loaded: ssp_helper
INFO - 2026-03-25 02:12:47 --> Helper loaded: cpanel_helper
INFO - 2026-03-25 02:12:47 --> Helper loaded: plesk_helper
INFO - 2026-03-25 02:12:47 --> Helper loaded: directadmin_helper
INFO - 2026-03-25 02:12:47 --> Helper loaded: domain_helper
INFO - 2026-03-25 02:12:47 --> Database Driver Class Initialized
INFO - 2026-03-25 02:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-25 02:12:49 --> Upload Class Initialized
DEBUG - 2026-03-25 02:12:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-25 02:12:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-25 02:12:49 --> Encryption Class Initialized
INFO - 2026-03-25 02:12:49 --> Form Validation Class Initialized
INFO - 2026-03-25 02:12:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-25 02:12:49 --> Pagination Class Initialized
INFO - 2026-03-25 02:12:49 --> Email Class Initialized
INFO - 2026-03-25 02:12:49 --> Controller Class Initialized
DEBUG - 2026-03-25 02:12:49 --> Dashboard MX_Controller Initialized
INFO - 2026-03-25 02:12:49 --> Model "Loginattempt_model" initialized
INFO - 2026-03-25 02:12:49 --> Model "Adminauth_model" initialized
INFO - 2026-03-25 02:12:49 --> Model "Dashboard_model" initialized
DEBUG - 2026-03-25 02:12:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-25 02:12:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-25 02:12:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-25 02:12:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-25 02:12:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-25 02:12:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/dashboard_index.php
INFO - 2026-03-25 02:12:49 --> Final output sent to browser
DEBUG - 2026-03-25 02:12:49 --> Total execution time: 2.4346
INFO - 2026-03-25 02:12:49 --> Config Class Initialized
INFO - 2026-03-25 02:12:49 --> Hooks Class Initialized
DEBUG - 2026-03-25 02:12:49 --> UTF-8 Support Enabled
INFO - 2026-03-25 02:12:49 --> Utf8 Class Initialized
INFO - 2026-03-25 02:12:49 --> Config Class Initialized
INFO - 2026-03-25 02:12:49 --> Hooks Class Initialized
INFO - 2026-03-25 02:12:49 --> URI Class Initialized
INFO - 2026-03-25 02:12:49 --> Config Class Initialized
INFO - 2026-03-25 02:12:49 --> Hooks Class Initialized
DEBUG - 2026-03-25 02:12:49 --> UTF-8 Support Enabled
INFO - 2026-03-25 02:12:49 --> Utf8 Class Initialized
INFO - 2026-03-25 02:12:49 --> URI Class Initialized
DEBUG - 2026-03-25 02:12:49 --> UTF-8 Support Enabled
INFO - 2026-03-25 02:12:49 --> Router Class Initialized
INFO - 2026-03-25 02:12:49 --> Utf8 Class Initialized
INFO - 2026-03-25 02:12:49 --> Config Class Initialized
INFO - 2026-03-25 02:12:49 --> Hooks Class Initialized
INFO - 2026-03-25 02:12:49 --> URI Class Initialized
INFO - 2026-03-25 02:12:49 --> Output Class Initialized
INFO - 2026-03-25 02:12:49 --> Config Class Initialized
INFO - 2026-03-25 02:12:49 --> Hooks Class Initialized
INFO - 2026-03-25 02:12:49 --> Router Class Initialized
DEBUG - 2026-03-25 02:12:49 --> UTF-8 Support Enabled
INFO - 2026-03-25 02:12:49 --> Utf8 Class Initialized
INFO - 2026-03-25 02:12:49 --> Router Class Initialized
INFO - 2026-03-25 02:12:49 --> Security Class Initialized
DEBUG - 2026-03-25 02:12:49 --> UTF-8 Support Enabled
INFO - 2026-03-25 02:12:49 --> Utf8 Class Initialized
INFO - 2026-03-25 02:12:49 --> URI Class Initialized
INFO - 2026-03-25 02:12:49 --> Output Class Initialized
INFO - 2026-03-25 02:12:49 --> URI Class Initialized
DEBUG - 2026-03-25 02:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-25 02:12:49 --> Input Class Initialized
INFO - 2026-03-25 02:12:49 --> Output Class Initialized
INFO - 2026-03-25 02:12:49 --> Language Class Initialized
INFO - 2026-03-25 02:12:49 --> Security Class Initialized
INFO - 2026-03-25 02:12:49 --> Router Class Initialized
INFO - 2026-03-25 02:12:49 --> Language Class Initialized
INFO - 2026-03-25 02:12:49 --> Config Class Initialized
INFO - 2026-03-25 02:12:49 --> Security Class Initialized
INFO - 2026-03-25 02:12:49 --> Router Class Initialized
DEBUG - 2026-03-25 02:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-25 02:12:49 --> Input Class Initialized
INFO - 2026-03-25 02:12:49 --> Language Class Initialized
INFO - 2026-03-25 02:12:49 --> Output Class Initialized
INFO - 2026-03-25 02:12:49 --> Language Class Initialized
INFO - 2026-03-25 02:12:49 --> Config Class Initialized
INFO - 2026-03-25 02:12:49 --> Output Class Initialized
INFO - 2026-03-25 02:12:49 --> Security Class Initialized
DEBUG - 2026-03-25 02:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-25 02:12:49 --> Security Class Initialized
INFO - 2026-03-25 02:12:49 --> Input Class Initialized
INFO - 2026-03-25 02:12:49 --> Language Class Initialized
DEBUG - 2026-03-25 02:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-03-25 02:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-25 02:12:49 --> Input Class Initialized
INFO - 2026-03-25 02:12:49 --> Loader Class Initialized
INFO - 2026-03-25 02:12:49 --> Input Class Initialized
INFO - 2026-03-25 02:12:49 --> Language Class Initialized
INFO - 2026-03-25 02:12:49 --> Language Class Initialized
INFO - 2026-03-25 02:12:49 --> Config Class Initialized
INFO - 2026-03-25 02:12:49 --> Language Class Initialized
INFO - 2026-03-25 02:12:49 --> Language Class Initialized
INFO - 2026-03-25 02:12:49 --> Helper loaded: url_helper
INFO - 2026-03-25 02:12:49 --> Config Class Initialized
INFO - 2026-03-25 02:12:49 --> Language Class Initialized
INFO - 2026-03-25 02:12:49 --> Config Class Initialized
INFO - 2026-03-25 02:12:49 --> Loader Class Initialized
INFO - 2026-03-25 02:12:49 --> Loader Class Initialized
INFO - 2026-03-25 02:12:49 --> Loader Class Initialized
INFO - 2026-03-25 02:12:49 --> Helper loaded: url_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: url_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: url_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: form_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: form_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: form_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: html_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: html_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: html_helper
INFO - 2026-03-25 02:12:49 --> Loader Class Initialized
INFO - 2026-03-25 02:12:49 --> Helper loaded: file_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: email_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: file_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: email_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: file_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: email_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: url_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: whmaz_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: whmaz_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: ssp_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: ssp_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: whmaz_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: form_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: ssp_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: html_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: form_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: html_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: cpanel_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: cpanel_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: file_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: cpanel_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: email_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: plesk_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: whmaz_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: plesk_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: directadmin_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: ssp_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: directadmin_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: cpanel_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: plesk_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: domain_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: file_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: email_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: domain_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: directadmin_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: whmaz_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: ssp_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: cpanel_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: domain_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: plesk_helper
INFO - 2026-03-25 02:12:49 --> Database Driver Class Initialized
INFO - 2026-03-25 02:12:49 --> Helper loaded: directadmin_helper
INFO - 2026-03-25 02:12:49 --> Database Driver Class Initialized
INFO - 2026-03-25 02:12:49 --> Helper loaded: plesk_helper
INFO - 2026-03-25 02:12:49 --> Config Class Initialized
INFO - 2026-03-25 02:12:49 --> Hooks Class Initialized
INFO - 2026-03-25 02:12:49 --> Helper loaded: domain_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: directadmin_helper
DEBUG - 2026-03-25 02:12:49 --> UTF-8 Support Enabled
INFO - 2026-03-25 02:12:49 --> Utf8 Class Initialized
INFO - 2026-03-25 02:12:49 --> URI Class Initialized
INFO - 2026-03-25 02:12:49 --> Database Driver Class Initialized
INFO - 2026-03-25 02:12:49 --> Helper loaded: domain_helper
INFO - 2026-03-25 02:12:49 --> Router Class Initialized
INFO - 2026-03-25 02:12:49 --> Output Class Initialized
INFO - 2026-03-25 02:12:49 --> Database Driver Class Initialized
INFO - 2026-03-25 02:12:49 --> Security Class Initialized
DEBUG - 2026-03-25 02:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-25 02:12:49 --> Database Driver Class Initialized
INFO - 2026-03-25 02:12:49 --> Input Class Initialized
INFO - 2026-03-25 02:12:49 --> Language Class Initialized
INFO - 2026-03-25 02:12:49 --> Language Class Initialized
INFO - 2026-03-25 02:12:49 --> Config Class Initialized
INFO - 2026-03-25 02:12:49 --> Loader Class Initialized
INFO - 2026-03-25 02:12:49 --> Helper loaded: url_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: form_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: html_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: file_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: email_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: whmaz_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: ssp_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: cpanel_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: plesk_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: directadmin_helper
INFO - 2026-03-25 02:12:49 --> Helper loaded: domain_helper
INFO - 2026-03-25 02:12:49 --> Database Driver Class Initialized
INFO - 2026-03-25 02:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-25 02:12:51 --> Upload Class Initialized
DEBUG - 2026-03-25 02:12:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-25 02:12:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-25 02:12:51 --> Encryption Class Initialized
INFO - 2026-03-25 02:12:51 --> Form Validation Class Initialized
INFO - 2026-03-25 02:12:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-25 02:12:51 --> Pagination Class Initialized
INFO - 2026-03-25 02:12:51 --> Email Class Initialized
INFO - 2026-03-25 02:12:51 --> Controller Class Initialized
DEBUG - 2026-03-25 02:12:51 --> Dashboard MX_Controller Initialized
INFO - 2026-03-25 02:12:51 --> Model "Loginattempt_model" initialized
INFO - 2026-03-25 02:12:51 --> Model "Adminauth_model" initialized
INFO - 2026-03-25 02:12:52 --> Model "Dashboard_model" initialized
INFO - 2026-03-25 02:12:52 --> Final output sent to browser
DEBUG - 2026-03-25 02:12:52 --> Total execution time: 2.7313
INFO - 2026-03-25 02:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-25 02:12:52 --> Upload Class Initialized
DEBUG - 2026-03-25 02:12:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-25 02:12:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-25 02:12:52 --> Encryption Class Initialized
INFO - 2026-03-25 02:12:52 --> Form Validation Class Initialized
INFO - 2026-03-25 02:12:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-25 02:12:52 --> Pagination Class Initialized
INFO - 2026-03-25 02:12:52 --> Email Class Initialized
INFO - 2026-03-25 02:12:52 --> Controller Class Initialized
DEBUG - 2026-03-25 02:12:52 --> Dashboard MX_Controller Initialized
INFO - 2026-03-25 02:12:52 --> Model "Loginattempt_model" initialized
INFO - 2026-03-25 02:12:52 --> Model "Adminauth_model" initialized
INFO - 2026-03-25 02:12:52 --> Model "Dashboard_model" initialized
INFO - 2026-03-25 02:12:53 --> Final output sent to browser
DEBUG - 2026-03-25 02:12:53 --> Total execution time: 3.5556
INFO - 2026-03-25 02:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-25 02:12:53 --> Upload Class Initialized
DEBUG - 2026-03-25 02:12:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-25 02:12:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-25 02:12:53 --> Encryption Class Initialized
INFO - 2026-03-25 02:12:53 --> Form Validation Class Initialized
INFO - 2026-03-25 02:12:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-25 02:12:53 --> Pagination Class Initialized
INFO - 2026-03-25 02:12:53 --> Email Class Initialized
INFO - 2026-03-25 02:12:53 --> Controller Class Initialized
DEBUG - 2026-03-25 02:12:53 --> Order MX_Controller Initialized
INFO - 2026-03-25 02:12:53 --> Model "Loginattempt_model" initialized
INFO - 2026-03-25 02:12:53 --> Model "Adminauth_model" initialized
INFO - 2026-03-25 02:12:53 --> Model "Order_model" initialized
INFO - 2026-03-25 02:12:53 --> Model "Common_model" initialized
INFO - 2026-03-25 02:12:53 --> Model "Currency_model" initialized
INFO - 2026-03-25 02:12:54 --> Final output sent to browser
DEBUG - 2026-03-25 02:12:54 --> Total execution time: 4.3756
INFO - 2026-03-25 02:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-25 02:12:54 --> Upload Class Initialized
DEBUG - 2026-03-25 02:12:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-25 02:12:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-25 02:12:54 --> Encryption Class Initialized
INFO - 2026-03-25 02:12:54 --> Form Validation Class Initialized
INFO - 2026-03-25 02:12:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-25 02:12:54 --> Pagination Class Initialized
INFO - 2026-03-25 02:12:54 --> Email Class Initialized
INFO - 2026-03-25 02:12:54 --> Controller Class Initialized
DEBUG - 2026-03-25 02:12:54 --> Dashboard MX_Controller Initialized
INFO - 2026-03-25 02:12:54 --> Model "Loginattempt_model" initialized
INFO - 2026-03-25 02:12:54 --> Model "Adminauth_model" initialized
INFO - 2026-03-25 02:12:54 --> Model "Dashboard_model" initialized
INFO - 2026-03-25 02:12:54 --> Final output sent to browser
DEBUG - 2026-03-25 02:12:54 --> Total execution time: 5.1783
INFO - 2026-03-25 02:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-25 02:12:54 --> Upload Class Initialized
DEBUG - 2026-03-25 02:12:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-25 02:12:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-25 02:12:54 --> Encryption Class Initialized
INFO - 2026-03-25 02:12:54 --> Form Validation Class Initialized
INFO - 2026-03-25 02:12:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-25 02:12:54 --> Pagination Class Initialized
INFO - 2026-03-25 02:12:54 --> Email Class Initialized
INFO - 2026-03-25 02:12:54 --> Controller Class Initialized
DEBUG - 2026-03-25 02:12:54 --> Ticket MX_Controller Initialized
INFO - 2026-03-25 02:12:54 --> Model "Loginattempt_model" initialized
INFO - 2026-03-25 02:12:54 --> Model "Adminauth_model" initialized
INFO - 2026-03-25 02:12:54 --> Model "Support_model" initialized
INFO - 2026-03-25 02:12:54 --> Model "Common_model" initialized
INFO - 2026-03-25 02:12:55 --> Final output sent to browser
DEBUG - 2026-03-25 02:12:55 --> Total execution time: 6.0136
INFO - 2026-03-25 02:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-25 02:12:55 --> Upload Class Initialized
DEBUG - 2026-03-25 02:12:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-25 02:12:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-25 02:12:55 --> Encryption Class Initialized
INFO - 2026-03-25 02:12:55 --> Form Validation Class Initialized
INFO - 2026-03-25 02:12:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-25 02:12:55 --> Pagination Class Initialized
INFO - 2026-03-25 02:12:55 --> Email Class Initialized
INFO - 2026-03-25 02:12:55 --> Controller Class Initialized
DEBUG - 2026-03-25 02:12:55 --> Invoice MX_Controller Initialized
INFO - 2026-03-25 02:12:55 --> Model "Loginattempt_model" initialized
INFO - 2026-03-25 02:12:55 --> Model "Adminauth_model" initialized
INFO - 2026-03-25 02:12:55 --> Model "Billing_model" initialized
INFO - 2026-03-25 02:12:55 --> Model "Common_model" initialized
INFO - 2026-03-25 02:12:55 --> Model "Invoice_model" initialized
INFO - 2026-03-25 02:12:55 --> Model "Appsetting_model" initialized
INFO - 2026-03-25 02:12:56 --> Final output sent to browser
DEBUG - 2026-03-25 02:12:56 --> Total execution time: 6.7321

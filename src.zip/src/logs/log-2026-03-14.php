<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-03-14 05:15:10 --> Config Class Initialized
INFO - 2026-03-14 05:15:10 --> Hooks Class Initialized
DEBUG - 2026-03-14 05:15:10 --> UTF-8 Support Enabled
INFO - 2026-03-14 05:15:10 --> Utf8 Class Initialized
INFO - 2026-03-14 05:15:10 --> URI Class Initialized
INFO - 2026-03-14 05:15:10 --> Router Class Initialized
INFO - 2026-03-14 05:15:10 --> Output Class Initialized
INFO - 2026-03-14 05:15:10 --> Security Class Initialized
DEBUG - 2026-03-14 05:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 05:15:10 --> CSRF cookie sent
INFO - 2026-03-14 05:15:10 --> Input Class Initialized
INFO - 2026-03-14 05:15:10 --> Language Class Initialized
INFO - 2026-03-14 05:15:10 --> Language Class Initialized
INFO - 2026-03-14 05:15:10 --> Config Class Initialized
INFO - 2026-03-14 05:15:10 --> Loader Class Initialized
INFO - 2026-03-14 05:15:10 --> Helper loaded: url_helper
INFO - 2026-03-14 05:15:10 --> Helper loaded: form_helper
INFO - 2026-03-14 05:15:10 --> Helper loaded: html_helper
INFO - 2026-03-14 05:15:10 --> Helper loaded: file_helper
INFO - 2026-03-14 05:15:10 --> Helper loaded: email_helper
INFO - 2026-03-14 05:15:10 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 05:15:10 --> Helper loaded: ssp_helper
INFO - 2026-03-14 05:15:10 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 05:15:10 --> Helper loaded: domain_helper
INFO - 2026-03-14 05:15:10 --> Database Driver Class Initialized
INFO - 2026-03-14 05:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 05:15:12 --> Upload Class Initialized
DEBUG - 2026-03-14 05:15:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 05:15:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 05:15:12 --> Encryption Class Initialized
INFO - 2026-03-14 05:15:12 --> Form Validation Class Initialized
INFO - 2026-03-14 05:15:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 05:15:12 --> Pagination Class Initialized
INFO - 2026-03-14 05:15:12 --> Email Class Initialized
INFO - 2026-03-14 05:15:12 --> Controller Class Initialized
DEBUG - 2026-03-14 05:15:12 --> Dashboard MX_Controller Initialized
INFO - 2026-03-14 05:15:12 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 05:15:12 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 05:15:12 --> Config Class Initialized
INFO - 2026-03-14 05:15:12 --> Hooks Class Initialized
DEBUG - 2026-03-14 05:15:12 --> UTF-8 Support Enabled
INFO - 2026-03-14 05:15:12 --> Utf8 Class Initialized
INFO - 2026-03-14 05:15:12 --> URI Class Initialized
INFO - 2026-03-14 05:15:12 --> Router Class Initialized
INFO - 2026-03-14 05:15:12 --> Output Class Initialized
INFO - 2026-03-14 05:15:12 --> Security Class Initialized
DEBUG - 2026-03-14 05:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 05:15:12 --> CSRF cookie sent
INFO - 2026-03-14 05:15:12 --> Input Class Initialized
INFO - 2026-03-14 05:15:12 --> Language Class Initialized
INFO - 2026-03-14 05:15:12 --> Language Class Initialized
INFO - 2026-03-14 05:15:12 --> Config Class Initialized
INFO - 2026-03-14 05:15:12 --> Loader Class Initialized
INFO - 2026-03-14 05:15:12 --> Helper loaded: url_helper
INFO - 2026-03-14 05:15:12 --> Helper loaded: form_helper
INFO - 2026-03-14 05:15:12 --> Helper loaded: html_helper
INFO - 2026-03-14 05:15:12 --> Helper loaded: file_helper
INFO - 2026-03-14 05:15:12 --> Helper loaded: email_helper
INFO - 2026-03-14 05:15:12 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 05:15:12 --> Helper loaded: ssp_helper
INFO - 2026-03-14 05:15:12 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 05:15:12 --> Helper loaded: domain_helper
INFO - 2026-03-14 05:15:12 --> Database Driver Class Initialized
INFO - 2026-03-14 05:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 05:15:14 --> Upload Class Initialized
DEBUG - 2026-03-14 05:15:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 05:15:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 05:15:14 --> Encryption Class Initialized
INFO - 2026-03-14 05:15:14 --> Form Validation Class Initialized
INFO - 2026-03-14 05:15:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 05:15:14 --> Pagination Class Initialized
INFO - 2026-03-14 05:15:14 --> Email Class Initialized
INFO - 2026-03-14 05:15:14 --> Controller Class Initialized
DEBUG - 2026-03-14 05:15:14 --> Authenticate MX_Controller Initialized
INFO - 2026-03-14 05:15:14 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 05:15:14 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 05:15:14 --> Model "Appsetting_model" initialized
DEBUG - 2026-03-14 05:15:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-14 05:15:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-14 05:15:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-03-14 05:15:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-14 05:15:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-14 05:15:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-03-14 05:15:14 --> Final output sent to browser
DEBUG - 2026-03-14 05:15:14 --> Total execution time: 2.4049
INFO - 2026-03-14 06:44:00 --> Config Class Initialized
INFO - 2026-03-14 06:44:00 --> Hooks Class Initialized
DEBUG - 2026-03-14 06:44:00 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:00 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:00 --> URI Class Initialized
INFO - 2026-03-14 06:44:00 --> Router Class Initialized
INFO - 2026-03-14 06:44:00 --> Output Class Initialized
INFO - 2026-03-14 06:44:00 --> Security Class Initialized
DEBUG - 2026-03-14 06:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:00 --> CSRF cookie sent
INFO - 2026-03-14 06:44:00 --> Input Class Initialized
INFO - 2026-03-14 06:44:00 --> Language Class Initialized
INFO - 2026-03-14 06:44:00 --> Language Class Initialized
INFO - 2026-03-14 06:44:00 --> Config Class Initialized
INFO - 2026-03-14 06:44:00 --> Loader Class Initialized
INFO - 2026-03-14 06:44:00 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:00 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:00 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:00 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:00 --> Helper loaded: email_helper
INFO - 2026-03-14 06:44:00 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:00 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:00 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:00 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:00 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:44:02 --> Upload Class Initialized
DEBUG - 2026-03-14 06:44:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:44:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:44:02 --> Encryption Class Initialized
INFO - 2026-03-14 06:44:02 --> Form Validation Class Initialized
INFO - 2026-03-14 06:44:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:44:02 --> Pagination Class Initialized
INFO - 2026-03-14 06:44:02 --> Email Class Initialized
INFO - 2026-03-14 06:44:02 --> Controller Class Initialized
DEBUG - 2026-03-14 06:44:02 --> Authenticate MX_Controller Initialized
INFO - 2026-03-14 06:44:02 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 06:44:02 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 06:44:02 --> Model "Appsetting_model" initialized
DEBUG - 2026-03-14 06:44:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-14 06:44:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-14 06:44:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-03-14 06:44:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-14 06:44:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-14 06:44:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-03-14 06:44:03 --> Final output sent to browser
DEBUG - 2026-03-14 06:44:03 --> Total execution time: 2.4569
INFO - 2026-03-14 06:44:11 --> Config Class Initialized
INFO - 2026-03-14 06:44:11 --> Hooks Class Initialized
DEBUG - 2026-03-14 06:44:11 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:11 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:11 --> URI Class Initialized
INFO - 2026-03-14 06:44:11 --> Router Class Initialized
INFO - 2026-03-14 06:44:11 --> Output Class Initialized
INFO - 2026-03-14 06:44:11 --> Security Class Initialized
DEBUG - 2026-03-14 06:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:11 --> CSRF cookie sent
INFO - 2026-03-14 06:44:11 --> CSRF token verified
INFO - 2026-03-14 06:44:11 --> Input Class Initialized
INFO - 2026-03-14 06:44:11 --> Language Class Initialized
INFO - 2026-03-14 06:44:11 --> Language Class Initialized
INFO - 2026-03-14 06:44:11 --> Config Class Initialized
INFO - 2026-03-14 06:44:11 --> Loader Class Initialized
INFO - 2026-03-14 06:44:11 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:11 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:11 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:11 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:11 --> Helper loaded: email_helper
INFO - 2026-03-14 06:44:11 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:11 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:11 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:11 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:11 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:44:13 --> Upload Class Initialized
DEBUG - 2026-03-14 06:44:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:44:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:44:13 --> Encryption Class Initialized
INFO - 2026-03-14 06:44:13 --> Form Validation Class Initialized
INFO - 2026-03-14 06:44:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:44:13 --> Pagination Class Initialized
INFO - 2026-03-14 06:44:13 --> Email Class Initialized
INFO - 2026-03-14 06:44:13 --> Controller Class Initialized
DEBUG - 2026-03-14 06:44:13 --> Authenticate MX_Controller Initialized
INFO - 2026-03-14 06:44:13 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 06:44:13 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 06:44:13 --> Model "Appsetting_model" initialized
INFO - 2026-03-14 06:44:16 --> Config Class Initialized
INFO - 2026-03-14 06:44:16 --> Hooks Class Initialized
DEBUG - 2026-03-14 06:44:16 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:16 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:16 --> URI Class Initialized
INFO - 2026-03-14 06:44:16 --> Router Class Initialized
INFO - 2026-03-14 06:44:16 --> Output Class Initialized
INFO - 2026-03-14 06:44:16 --> Security Class Initialized
DEBUG - 2026-03-14 06:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:16 --> CSRF cookie sent
INFO - 2026-03-14 06:44:16 --> Input Class Initialized
INFO - 2026-03-14 06:44:16 --> Language Class Initialized
INFO - 2026-03-14 06:44:16 --> Language Class Initialized
INFO - 2026-03-14 06:44:16 --> Config Class Initialized
INFO - 2026-03-14 06:44:16 --> Loader Class Initialized
INFO - 2026-03-14 06:44:16 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:16 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:16 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:16 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:16 --> Helper loaded: email_helper
INFO - 2026-03-14 06:44:16 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:16 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:16 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:16 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:16 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:44:18 --> Upload Class Initialized
DEBUG - 2026-03-14 06:44:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:44:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:44:18 --> Encryption Class Initialized
INFO - 2026-03-14 06:44:18 --> Form Validation Class Initialized
INFO - 2026-03-14 06:44:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:44:18 --> Pagination Class Initialized
INFO - 2026-03-14 06:44:18 --> Email Class Initialized
INFO - 2026-03-14 06:44:18 --> Controller Class Initialized
DEBUG - 2026-03-14 06:44:18 --> Dashboard MX_Controller Initialized
INFO - 2026-03-14 06:44:18 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 06:44:18 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 06:44:18 --> Model "Dashboard_model" initialized
DEBUG - 2026-03-14 06:44:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-14 06:44:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-14 06:44:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-14 06:44:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-14 06:44:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-14 06:44:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/dashboard_index.php
INFO - 2026-03-14 06:44:18 --> Final output sent to browser
DEBUG - 2026-03-14 06:44:18 --> Total execution time: 2.3894
INFO - 2026-03-14 06:44:18 --> Config Class Initialized
INFO - 2026-03-14 06:44:18 --> Hooks Class Initialized
DEBUG - 2026-03-14 06:44:18 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:18 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:18 --> URI Class Initialized
INFO - 2026-03-14 06:44:18 --> Router Class Initialized
INFO - 2026-03-14 06:44:18 --> Output Class Initialized
INFO - 2026-03-14 06:44:18 --> Security Class Initialized
INFO - 2026-03-14 06:44:18 --> Config Class Initialized
INFO - 2026-03-14 06:44:18 --> Hooks Class Initialized
DEBUG - 2026-03-14 06:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:18 --> Config Class Initialized
INFO - 2026-03-14 06:44:18 --> Hooks Class Initialized
DEBUG - 2026-03-14 06:44:18 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:18 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:18 --> Input Class Initialized
INFO - 2026-03-14 06:44:18 --> Language Class Initialized
INFO - 2026-03-14 06:44:18 --> URI Class Initialized
DEBUG - 2026-03-14 06:44:18 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:18 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:18 --> URI Class Initialized
INFO - 2026-03-14 06:44:18 --> Router Class Initialized
INFO - 2026-03-14 06:44:18 --> Output Class Initialized
INFO - 2026-03-14 06:44:18 --> Router Class Initialized
INFO - 2026-03-14 06:44:18 --> Language Class Initialized
INFO - 2026-03-14 06:44:18 --> Config Class Initialized
INFO - 2026-03-14 06:44:18 --> Security Class Initialized
INFO - 2026-03-14 06:44:18 --> Output Class Initialized
DEBUG - 2026-03-14 06:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:18 --> Input Class Initialized
INFO - 2026-03-14 06:44:18 --> Security Class Initialized
INFO - 2026-03-14 06:44:18 --> Language Class Initialized
INFO - 2026-03-14 06:44:18 --> Language Class Initialized
INFO - 2026-03-14 06:44:18 --> Config Class Initialized
DEBUG - 2026-03-14 06:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:18 --> Input Class Initialized
INFO - 2026-03-14 06:44:18 --> Language Class Initialized
INFO - 2026-03-14 06:44:18 --> Language Class Initialized
INFO - 2026-03-14 06:44:18 --> Config Class Initialized
INFO - 2026-03-14 06:44:18 --> Config Class Initialized
INFO - 2026-03-14 06:44:18 --> Hooks Class Initialized
INFO - 2026-03-14 06:44:18 --> Loader Class Initialized
INFO - 2026-03-14 06:44:18 --> Loader Class Initialized
INFO - 2026-03-14 06:44:18 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: url_helper
DEBUG - 2026-03-14 06:44:18 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:18 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:18 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:18 --> URI Class Initialized
INFO - 2026-03-14 06:44:18 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:18 --> Config Class Initialized
INFO - 2026-03-14 06:44:18 --> Hooks Class Initialized
INFO - 2026-03-14 06:44:18 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:18 --> Config Class Initialized
INFO - 2026-03-14 06:44:18 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: email_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: email_helper
DEBUG - 2026-03-14 06:44:18 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:18 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:18 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:18 --> Router Class Initialized
INFO - 2026-03-14 06:44:18 --> URI Class Initialized
INFO - 2026-03-14 06:44:18 --> Loader Class Initialized
INFO - 2026-03-14 06:44:18 --> Output Class Initialized
INFO - 2026-03-14 06:44:18 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:18 --> Router Class Initialized
INFO - 2026-03-14 06:44:18 --> Security Class Initialized
INFO - 2026-03-14 06:44:18 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:18 --> Hooks Class Initialized
INFO - 2026-03-14 06:44:18 --> Output Class Initialized
DEBUG - 2026-03-14 06:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:18 --> Input Class Initialized
INFO - 2026-03-14 06:44:18 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:18 --> Language Class Initialized
INFO - 2026-03-14 06:44:18 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:18 --> Security Class Initialized
DEBUG - 2026-03-14 06:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:18 --> Language Class Initialized
INFO - 2026-03-14 06:44:18 --> Config Class Initialized
INFO - 2026-03-14 06:44:18 --> Input Class Initialized
INFO - 2026-03-14 06:44:18 --> Language Class Initialized
INFO - 2026-03-14 06:44:18 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:18 --> Language Class Initialized
INFO - 2026-03-14 06:44:18 --> Config Class Initialized
INFO - 2026-03-14 06:44:18 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:18 --> Loader Class Initialized
INFO - 2026-03-14 06:44:18 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: email_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:18 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:18 --> Loader Class Initialized
INFO - 2026-03-14 06:44:18 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: email_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:18 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:18 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: email_helper
DEBUG - 2026-03-14 06:44:18 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:18 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:18 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:18 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:18 --> URI Class Initialized
INFO - 2026-03-14 06:44:18 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:18 --> Router Class Initialized
INFO - 2026-03-14 06:44:18 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:18 --> Output Class Initialized
INFO - 2026-03-14 06:44:18 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:18 --> Security Class Initialized
DEBUG - 2026-03-14 06:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:18 --> Input Class Initialized
INFO - 2026-03-14 06:44:18 --> Language Class Initialized
INFO - 2026-03-14 06:44:18 --> Language Class Initialized
INFO - 2026-03-14 06:44:18 --> Config Class Initialized
INFO - 2026-03-14 06:44:18 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:18 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:18 --> Loader Class Initialized
INFO - 2026-03-14 06:44:18 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:18 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: email_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:18 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:18 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:44:20 --> Upload Class Initialized
DEBUG - 2026-03-14 06:44:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:44:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:44:20 --> Encryption Class Initialized
INFO - 2026-03-14 06:44:20 --> Form Validation Class Initialized
INFO - 2026-03-14 06:44:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:44:20 --> Pagination Class Initialized
INFO - 2026-03-14 06:44:20 --> Email Class Initialized
INFO - 2026-03-14 06:44:20 --> Controller Class Initialized
DEBUG - 2026-03-14 06:44:20 --> Invoice MX_Controller Initialized
INFO - 2026-03-14 06:44:20 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 06:44:20 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 06:44:20 --> Model "Billing_model" initialized
INFO - 2026-03-14 06:44:20 --> Model "Common_model" initialized
INFO - 2026-03-14 06:44:20 --> Model "Invoice_model" initialized
INFO - 2026-03-14 06:44:20 --> Model "Appsetting_model" initialized
INFO - 2026-03-14 06:44:21 --> Final output sent to browser
DEBUG - 2026-03-14 06:44:21 --> Total execution time: 2.7990
INFO - 2026-03-14 06:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:44:21 --> Upload Class Initialized
DEBUG - 2026-03-14 06:44:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:44:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:44:21 --> Encryption Class Initialized
INFO - 2026-03-14 06:44:21 --> Form Validation Class Initialized
INFO - 2026-03-14 06:44:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:44:21 --> Pagination Class Initialized
INFO - 2026-03-14 06:44:21 --> Email Class Initialized
INFO - 2026-03-14 06:44:21 --> Controller Class Initialized
DEBUG - 2026-03-14 06:44:21 --> Order MX_Controller Initialized
INFO - 2026-03-14 06:44:21 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 06:44:21 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 06:44:21 --> Model "Order_model" initialized
INFO - 2026-03-14 06:44:21 --> Model "Common_model" initialized
INFO - 2026-03-14 06:44:21 --> Model "Currency_model" initialized
INFO - 2026-03-14 06:44:22 --> Final output sent to browser
DEBUG - 2026-03-14 06:44:22 --> Total execution time: 3.6280
INFO - 2026-03-14 06:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:44:22 --> Upload Class Initialized
DEBUG - 2026-03-14 06:44:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:44:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:44:22 --> Encryption Class Initialized
INFO - 2026-03-14 06:44:22 --> Form Validation Class Initialized
INFO - 2026-03-14 06:44:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:44:22 --> Pagination Class Initialized
INFO - 2026-03-14 06:44:22 --> Email Class Initialized
INFO - 2026-03-14 06:44:22 --> Controller Class Initialized
DEBUG - 2026-03-14 06:44:22 --> Dashboard MX_Controller Initialized
INFO - 2026-03-14 06:44:22 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 06:44:22 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 06:44:22 --> Model "Dashboard_model" initialized
INFO - 2026-03-14 06:44:23 --> Final output sent to browser
DEBUG - 2026-03-14 06:44:23 --> Total execution time: 4.4481
INFO - 2026-03-14 06:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:44:23 --> Upload Class Initialized
DEBUG - 2026-03-14 06:44:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:44:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:44:23 --> Encryption Class Initialized
INFO - 2026-03-14 06:44:23 --> Form Validation Class Initialized
INFO - 2026-03-14 06:44:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:44:23 --> Pagination Class Initialized
INFO - 2026-03-14 06:44:23 --> Email Class Initialized
INFO - 2026-03-14 06:44:23 --> Controller Class Initialized
DEBUG - 2026-03-14 06:44:23 --> Dashboard MX_Controller Initialized
INFO - 2026-03-14 06:44:23 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 06:44:23 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 06:44:23 --> Model "Dashboard_model" initialized
INFO - 2026-03-14 06:44:24 --> Final output sent to browser
DEBUG - 2026-03-14 06:44:24 --> Total execution time: 5.2541
INFO - 2026-03-14 06:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:44:24 --> Upload Class Initialized
DEBUG - 2026-03-14 06:44:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:44:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:44:24 --> Encryption Class Initialized
INFO - 2026-03-14 06:44:24 --> Form Validation Class Initialized
INFO - 2026-03-14 06:44:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:44:24 --> Pagination Class Initialized
INFO - 2026-03-14 06:44:24 --> Email Class Initialized
INFO - 2026-03-14 06:44:24 --> Controller Class Initialized
DEBUG - 2026-03-14 06:44:24 --> Ticket MX_Controller Initialized
INFO - 2026-03-14 06:44:24 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 06:44:24 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 06:44:24 --> Model "Support_model" initialized
INFO - 2026-03-14 06:44:24 --> Model "Common_model" initialized
INFO - 2026-03-14 06:44:24 --> Final output sent to browser
DEBUG - 2026-03-14 06:44:24 --> Total execution time: 5.9785
INFO - 2026-03-14 06:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:44:24 --> Upload Class Initialized
DEBUG - 2026-03-14 06:44:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:44:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:44:24 --> Encryption Class Initialized
INFO - 2026-03-14 06:44:24 --> Form Validation Class Initialized
INFO - 2026-03-14 06:44:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:44:24 --> Pagination Class Initialized
INFO - 2026-03-14 06:44:24 --> Email Class Initialized
INFO - 2026-03-14 06:44:24 --> Controller Class Initialized
DEBUG - 2026-03-14 06:44:24 --> Dashboard MX_Controller Initialized
INFO - 2026-03-14 06:44:24 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 06:44:24 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 06:44:25 --> Model "Dashboard_model" initialized
INFO - 2026-03-14 06:44:25 --> Final output sent to browser
DEBUG - 2026-03-14 06:44:25 --> Total execution time: 6.7915
INFO - 2026-03-14 06:44:44 --> Config Class Initialized
INFO - 2026-03-14 06:44:44 --> Hooks Class Initialized
DEBUG - 2026-03-14 06:44:44 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:44 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:44 --> URI Class Initialized
INFO - 2026-03-14 06:44:44 --> Router Class Initialized
INFO - 2026-03-14 06:44:44 --> Output Class Initialized
INFO - 2026-03-14 06:44:44 --> Security Class Initialized
DEBUG - 2026-03-14 06:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:44 --> CSRF cookie sent
INFO - 2026-03-14 06:44:44 --> Input Class Initialized
INFO - 2026-03-14 06:44:44 --> Language Class Initialized
INFO - 2026-03-14 06:44:44 --> Language Class Initialized
INFO - 2026-03-14 06:44:44 --> Config Class Initialized
INFO - 2026-03-14 06:44:44 --> Loader Class Initialized
INFO - 2026-03-14 06:44:44 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: email_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:44 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:44 --> Config Class Initialized
INFO - 2026-03-14 06:44:44 --> Hooks Class Initialized
DEBUG - 2026-03-14 06:44:44 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:44 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:44 --> URI Class Initialized
INFO - 2026-03-14 06:44:44 --> Config Class Initialized
INFO - 2026-03-14 06:44:44 --> Hooks Class Initialized
INFO - 2026-03-14 06:44:44 --> Router Class Initialized
INFO - 2026-03-14 06:44:44 --> Output Class Initialized
INFO - 2026-03-14 06:44:44 --> Security Class Initialized
INFO - 2026-03-14 06:44:44 --> Config Class Initialized
INFO - 2026-03-14 06:44:44 --> Hooks Class Initialized
INFO - 2026-03-14 06:44:44 --> Config Class Initialized
INFO - 2026-03-14 06:44:44 --> Hooks Class Initialized
DEBUG - 2026-03-14 06:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:44 --> CSRF cookie sent
INFO - 2026-03-14 06:44:44 --> Input Class Initialized
INFO - 2026-03-14 06:44:44 --> Language Class Initialized
DEBUG - 2026-03-14 06:44:44 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:44 --> Utf8 Class Initialized
DEBUG - 2026-03-14 06:44:44 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:44 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:44 --> Config Class Initialized
INFO - 2026-03-14 06:44:44 --> Hooks Class Initialized
INFO - 2026-03-14 06:44:44 --> Language Class Initialized
INFO - 2026-03-14 06:44:44 --> Config Class Initialized
DEBUG - 2026-03-14 06:44:44 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:44 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:44 --> URI Class Initialized
INFO - 2026-03-14 06:44:44 --> URI Class Initialized
INFO - 2026-03-14 06:44:44 --> URI Class Initialized
DEBUG - 2026-03-14 06:44:44 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:44 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:44 --> URI Class Initialized
INFO - 2026-03-14 06:44:44 --> Router Class Initialized
INFO - 2026-03-14 06:44:44 --> Loader Class Initialized
INFO - 2026-03-14 06:44:44 --> Output Class Initialized
INFO - 2026-03-14 06:44:44 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:44 --> Security Class Initialized
INFO - 2026-03-14 06:44:44 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: html_helper
DEBUG - 2026-03-14 06:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:44 --> CSRF cookie sent
INFO - 2026-03-14 06:44:44 --> Input Class Initialized
INFO - 2026-03-14 06:44:44 --> Language Class Initialized
INFO - 2026-03-14 06:44:44 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: email_helper
INFO - 2026-03-14 06:44:44 --> Language Class Initialized
INFO - 2026-03-14 06:44:44 --> Router Class Initialized
INFO - 2026-03-14 06:44:44 --> Config Class Initialized
INFO - 2026-03-14 06:44:44 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:44 --> Output Class Initialized
INFO - 2026-03-14 06:44:44 --> Router Class Initialized
INFO - 2026-03-14 06:44:44 --> Loader Class Initialized
INFO - 2026-03-14 06:44:44 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:44 --> Security Class Initialized
INFO - 2026-03-14 06:44:44 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: email_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:44 --> Output Class Initialized
INFO - 2026-03-14 06:44:44 --> Helper loaded: cpanel_helper
DEBUG - 2026-03-14 06:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:44 --> CSRF cookie sent
INFO - 2026-03-14 06:44:44 --> Input Class Initialized
INFO - 2026-03-14 06:44:44 --> Router Class Initialized
INFO - 2026-03-14 06:44:44 --> Security Class Initialized
INFO - 2026-03-14 06:44:44 --> Language Class Initialized
INFO - 2026-03-14 06:44:44 --> Language Class Initialized
INFO - 2026-03-14 06:44:44 --> Config Class Initialized
DEBUG - 2026-03-14 06:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:44 --> CSRF cookie sent
INFO - 2026-03-14 06:44:44 --> Input Class Initialized
INFO - 2026-03-14 06:44:44 --> Output Class Initialized
INFO - 2026-03-14 06:44:44 --> Language Class Initialized
INFO - 2026-03-14 06:44:44 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:44 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:44 --> Security Class Initialized
INFO - 2026-03-14 06:44:44 --> Language Class Initialized
INFO - 2026-03-14 06:44:44 --> Config Class Initialized
DEBUG - 2026-03-14 06:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:44 --> CSRF cookie sent
INFO - 2026-03-14 06:44:44 --> Input Class Initialized
INFO - 2026-03-14 06:44:44 --> Loader Class Initialized
INFO - 2026-03-14 06:44:44 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:44 --> Loader Class Initialized
INFO - 2026-03-14 06:44:44 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:44 --> Language Class Initialized
INFO - 2026-03-14 06:44:44 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:44 --> Language Class Initialized
INFO - 2026-03-14 06:44:44 --> Config Class Initialized
INFO - 2026-03-14 06:44:44 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:44 --> Loader Class Initialized
INFO - 2026-03-14 06:44:44 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: email_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: email_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: email_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:44 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:44 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:44 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:44 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:44:46 --> Upload Class Initialized
DEBUG - 2026-03-14 06:44:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:44:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:44:46 --> Encryption Class Initialized
INFO - 2026-03-14 06:44:46 --> Form Validation Class Initialized
INFO - 2026-03-14 06:44:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:44:46 --> Pagination Class Initialized
INFO - 2026-03-14 06:44:46 --> Email Class Initialized
INFO - 2026-03-14 06:44:46 --> Controller Class Initialized
ERROR - 2026-03-14 06:44:46 --> 404 Page Not Found: /index
INFO - 2026-03-14 06:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:44:46 --> Upload Class Initialized
DEBUG - 2026-03-14 06:44:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:44:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:44:46 --> Encryption Class Initialized
INFO - 2026-03-14 06:44:46 --> Form Validation Class Initialized
INFO - 2026-03-14 06:44:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:44:46 --> Pagination Class Initialized
INFO - 2026-03-14 06:44:46 --> Email Class Initialized
INFO - 2026-03-14 06:44:46 --> Controller Class Initialized
ERROR - 2026-03-14 06:44:46 --> 404 Page Not Found: /index
INFO - 2026-03-14 06:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:44:46 --> Upload Class Initialized
INFO - 2026-03-14 06:44:46 --> Config Class Initialized
INFO - 2026-03-14 06:44:46 --> Hooks Class Initialized
DEBUG - 2026-03-14 06:44:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:44:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:44:46 --> Encryption Class Initialized
DEBUG - 2026-03-14 06:44:46 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:46 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:46 --> URI Class Initialized
INFO - 2026-03-14 06:44:46 --> Form Validation Class Initialized
INFO - 2026-03-14 06:44:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:44:46 --> Pagination Class Initialized
INFO - 2026-03-14 06:44:46 --> Router Class Initialized
INFO - 2026-03-14 06:44:46 --> Output Class Initialized
INFO - 2026-03-14 06:44:46 --> Security Class Initialized
INFO - 2026-03-14 06:44:46 --> Email Class Initialized
INFO - 2026-03-14 06:44:46 --> Controller Class Initialized
ERROR - 2026-03-14 06:44:46 --> 404 Page Not Found: /index
DEBUG - 2026-03-14 06:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:46 --> CSRF cookie sent
INFO - 2026-03-14 06:44:46 --> Input Class Initialized
INFO - 2026-03-14 06:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:44:46 --> Language Class Initialized
INFO - 2026-03-14 06:44:46 --> Language Class Initialized
INFO - 2026-03-14 06:44:46 --> Config Class Initialized
INFO - 2026-03-14 06:44:46 --> Upload Class Initialized
DEBUG - 2026-03-14 06:44:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:44:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:44:46 --> Encryption Class Initialized
INFO - 2026-03-14 06:44:46 --> Loader Class Initialized
INFO - 2026-03-14 06:44:46 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:46 --> Form Validation Class Initialized
INFO - 2026-03-14 06:44:46 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:44:46 --> Pagination Class Initialized
INFO - 2026-03-14 06:44:46 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:46 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:46 --> Helper loaded: email_helper
INFO - 2026-03-14 06:44:46 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:46 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:46 --> Email Class Initialized
INFO - 2026-03-14 06:44:46 --> Controller Class Initialized
ERROR - 2026-03-14 06:44:46 --> 404 Page Not Found: /index
INFO - 2026-03-14 06:44:46 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:44:46 --> Upload Class Initialized
INFO - 2026-03-14 06:44:46 --> Helper loaded: domain_helper
DEBUG - 2026-03-14 06:44:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:44:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:44:46 --> Encryption Class Initialized
INFO - 2026-03-14 06:44:46 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:46 --> Form Validation Class Initialized
INFO - 2026-03-14 06:44:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:44:46 --> Pagination Class Initialized
INFO - 2026-03-14 06:44:46 --> Email Class Initialized
INFO - 2026-03-14 06:44:46 --> Controller Class Initialized
ERROR - 2026-03-14 06:44:46 --> 404 Page Not Found: /index
INFO - 2026-03-14 06:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:44:46 --> Upload Class Initialized
DEBUG - 2026-03-14 06:44:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:44:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:44:46 --> Encryption Class Initialized
INFO - 2026-03-14 06:44:46 --> Form Validation Class Initialized
INFO - 2026-03-14 06:44:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:44:46 --> Pagination Class Initialized
INFO - 2026-03-14 06:44:46 --> Email Class Initialized
INFO - 2026-03-14 06:44:46 --> Controller Class Initialized
ERROR - 2026-03-14 06:44:46 --> 404 Page Not Found: /index
INFO - 2026-03-14 06:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:44:48 --> Upload Class Initialized
DEBUG - 2026-03-14 06:44:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:44:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:44:48 --> Encryption Class Initialized
INFO - 2026-03-14 06:44:48 --> Form Validation Class Initialized
INFO - 2026-03-14 06:44:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:44:48 --> Pagination Class Initialized
INFO - 2026-03-14 06:44:48 --> Email Class Initialized
INFO - 2026-03-14 06:44:48 --> Controller Class Initialized
ERROR - 2026-03-14 06:44:48 --> 404 Page Not Found: /index
INFO - 2026-03-14 06:44:51 --> Config Class Initialized
INFO - 2026-03-14 06:44:51 --> Hooks Class Initialized
DEBUG - 2026-03-14 06:44:51 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:51 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:51 --> URI Class Initialized
INFO - 2026-03-14 06:44:51 --> Router Class Initialized
INFO - 2026-03-14 06:44:51 --> Output Class Initialized
INFO - 2026-03-14 06:44:51 --> Security Class Initialized
DEBUG - 2026-03-14 06:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:51 --> CSRF cookie sent
INFO - 2026-03-14 06:44:51 --> Input Class Initialized
INFO - 2026-03-14 06:44:51 --> Language Class Initialized
INFO - 2026-03-14 06:44:51 --> Language Class Initialized
INFO - 2026-03-14 06:44:51 --> Config Class Initialized
INFO - 2026-03-14 06:44:51 --> Loader Class Initialized
INFO - 2026-03-14 06:44:51 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:51 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:51 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:51 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:51 --> Helper loaded: email_helper
INFO - 2026-03-14 06:44:51 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:51 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:51 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:51 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:51 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:44:53 --> Upload Class Initialized
DEBUG - 2026-03-14 06:44:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:44:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:44:53 --> Encryption Class Initialized
INFO - 2026-03-14 06:44:53 --> Form Validation Class Initialized
INFO - 2026-03-14 06:44:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:44:53 --> Pagination Class Initialized
INFO - 2026-03-14 06:44:53 --> Email Class Initialized
INFO - 2026-03-14 06:44:53 --> Controller Class Initialized
DEBUG - 2026-03-14 06:44:53 --> Dashboard MX_Controller Initialized
INFO - 2026-03-14 06:44:53 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 06:44:53 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 06:44:54 --> Model "Dashboard_model" initialized
DEBUG - 2026-03-14 06:44:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-14 06:44:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-14 06:44:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-14 06:44:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-14 06:44:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-14 06:44:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/dashboard_index.php
INFO - 2026-03-14 06:44:54 --> Final output sent to browser
DEBUG - 2026-03-14 06:44:54 --> Total execution time: 2.3963
INFO - 2026-03-14 06:44:54 --> Config Class Initialized
INFO - 2026-03-14 06:44:54 --> Hooks Class Initialized
DEBUG - 2026-03-14 06:44:54 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:54 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:54 --> URI Class Initialized
INFO - 2026-03-14 06:44:54 --> Router Class Initialized
INFO - 2026-03-14 06:44:54 --> Output Class Initialized
INFO - 2026-03-14 06:44:54 --> Security Class Initialized
DEBUG - 2026-03-14 06:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:54 --> CSRF cookie sent
INFO - 2026-03-14 06:44:54 --> Input Class Initialized
INFO - 2026-03-14 06:44:54 --> Language Class Initialized
INFO - 2026-03-14 06:44:54 --> Language Class Initialized
INFO - 2026-03-14 06:44:54 --> Config Class Initialized
INFO - 2026-03-14 06:44:54 --> Loader Class Initialized
INFO - 2026-03-14 06:44:54 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: email_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:54 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:54 --> Config Class Initialized
INFO - 2026-03-14 06:44:54 --> Hooks Class Initialized
DEBUG - 2026-03-14 06:44:54 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:54 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:54 --> URI Class Initialized
INFO - 2026-03-14 06:44:54 --> Router Class Initialized
INFO - 2026-03-14 06:44:54 --> Config Class Initialized
INFO - 2026-03-14 06:44:54 --> Hooks Class Initialized
INFO - 2026-03-14 06:44:54 --> Output Class Initialized
INFO - 2026-03-14 06:44:54 --> Security Class Initialized
DEBUG - 2026-03-14 06:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:54 --> CSRF cookie sent
INFO - 2026-03-14 06:44:54 --> Input Class Initialized
INFO - 2026-03-14 06:44:54 --> Language Class Initialized
INFO - 2026-03-14 06:44:54 --> Language Class Initialized
INFO - 2026-03-14 06:44:54 --> Config Class Initialized
DEBUG - 2026-03-14 06:44:54 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:54 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:54 --> Config Class Initialized
INFO - 2026-03-14 06:44:54 --> Hooks Class Initialized
INFO - 2026-03-14 06:44:54 --> Loader Class Initialized
INFO - 2026-03-14 06:44:54 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:54 --> URI Class Initialized
DEBUG - 2026-03-14 06:44:54 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:54 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:54 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:54 --> URI Class Initialized
INFO - 2026-03-14 06:44:54 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:54 --> Router Class Initialized
INFO - 2026-03-14 06:44:54 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: email_helper
INFO - 2026-03-14 06:44:54 --> Output Class Initialized
INFO - 2026-03-14 06:44:54 --> Router Class Initialized
INFO - 2026-03-14 06:44:54 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:54 --> Security Class Initialized
INFO - 2026-03-14 06:44:54 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:54 --> Output Class Initialized
DEBUG - 2026-03-14 06:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:54 --> CSRF cookie sent
INFO - 2026-03-14 06:44:54 --> Input Class Initialized
INFO - 2026-03-14 06:44:54 --> Language Class Initialized
INFO - 2026-03-14 06:44:54 --> Security Class Initialized
INFO - 2026-03-14 06:44:54 --> Language Class Initialized
INFO - 2026-03-14 06:44:54 --> Config Class Initialized
DEBUG - 2026-03-14 06:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:54 --> CSRF cookie sent
INFO - 2026-03-14 06:44:54 --> Input Class Initialized
INFO - 2026-03-14 06:44:54 --> Language Class Initialized
INFO - 2026-03-14 06:44:54 --> Language Class Initialized
INFO - 2026-03-14 06:44:54 --> Config Class Initialized
INFO - 2026-03-14 06:44:54 --> Loader Class Initialized
INFO - 2026-03-14 06:44:54 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:54 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:54 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:54 --> Loader Class Initialized
INFO - 2026-03-14 06:44:54 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: email_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: email_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:54 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:54 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:54 --> Config Class Initialized
INFO - 2026-03-14 06:44:54 --> Hooks Class Initialized
INFO - 2026-03-14 06:44:54 --> Config Class Initialized
INFO - 2026-03-14 06:44:54 --> Hooks Class Initialized
DEBUG - 2026-03-14 06:44:54 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:54 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:54 --> URI Class Initialized
DEBUG - 2026-03-14 06:44:54 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:54 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:54 --> URI Class Initialized
INFO - 2026-03-14 06:44:54 --> Router Class Initialized
INFO - 2026-03-14 06:44:54 --> Router Class Initialized
INFO - 2026-03-14 06:44:54 --> Output Class Initialized
INFO - 2026-03-14 06:44:54 --> Output Class Initialized
INFO - 2026-03-14 06:44:54 --> Security Class Initialized
DEBUG - 2026-03-14 06:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:54 --> CSRF cookie sent
INFO - 2026-03-14 06:44:54 --> Input Class Initialized
INFO - 2026-03-14 06:44:54 --> Security Class Initialized
DEBUG - 2026-03-14 06:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:54 --> CSRF cookie sent
INFO - 2026-03-14 06:44:54 --> Input Class Initialized
INFO - 2026-03-14 06:44:54 --> Language Class Initialized
INFO - 2026-03-14 06:44:54 --> Language Class Initialized
INFO - 2026-03-14 06:44:54 --> Config Class Initialized
INFO - 2026-03-14 06:44:54 --> Language Class Initialized
INFO - 2026-03-14 06:44:54 --> Language Class Initialized
INFO - 2026-03-14 06:44:54 --> Config Class Initialized
INFO - 2026-03-14 06:44:54 --> Loader Class Initialized
INFO - 2026-03-14 06:44:54 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:54 --> Loader Class Initialized
INFO - 2026-03-14 06:44:54 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: email_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: email_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:54 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:54 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:54 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:44:55 --> Upload Class Initialized
DEBUG - 2026-03-14 06:44:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:44:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:44:55 --> Encryption Class Initialized
INFO - 2026-03-14 06:44:55 --> Form Validation Class Initialized
INFO - 2026-03-14 06:44:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:44:55 --> Pagination Class Initialized
INFO - 2026-03-14 06:44:55 --> Email Class Initialized
INFO - 2026-03-14 06:44:55 --> Controller Class Initialized
ERROR - 2026-03-14 06:44:55 --> 404 Page Not Found: /index
INFO - 2026-03-14 06:44:55 --> Config Class Initialized
INFO - 2026-03-14 06:44:55 --> Hooks Class Initialized
DEBUG - 2026-03-14 06:44:55 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:55 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:55 --> URI Class Initialized
INFO - 2026-03-14 06:44:55 --> Router Class Initialized
INFO - 2026-03-14 06:44:55 --> Output Class Initialized
INFO - 2026-03-14 06:44:55 --> Security Class Initialized
DEBUG - 2026-03-14 06:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:55 --> Input Class Initialized
INFO - 2026-03-14 06:44:55 --> Language Class Initialized
INFO - 2026-03-14 06:44:55 --> Language Class Initialized
INFO - 2026-03-14 06:44:55 --> Config Class Initialized
INFO - 2026-03-14 06:44:55 --> Loader Class Initialized
INFO - 2026-03-14 06:44:55 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:55 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:55 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:55 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:55 --> Helper loaded: email_helper
INFO - 2026-03-14 06:44:55 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:55 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:55 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:55 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:55 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:44:56 --> Upload Class Initialized
DEBUG - 2026-03-14 06:44:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:44:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:44:56 --> Encryption Class Initialized
INFO - 2026-03-14 06:44:56 --> Form Validation Class Initialized
INFO - 2026-03-14 06:44:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:44:56 --> Pagination Class Initialized
INFO - 2026-03-14 06:44:56 --> Email Class Initialized
INFO - 2026-03-14 06:44:56 --> Controller Class Initialized
ERROR - 2026-03-14 06:44:56 --> 404 Page Not Found: /index
INFO - 2026-03-14 06:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:44:56 --> Upload Class Initialized
DEBUG - 2026-03-14 06:44:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:44:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:44:56 --> Encryption Class Initialized
INFO - 2026-03-14 06:44:56 --> Form Validation Class Initialized
INFO - 2026-03-14 06:44:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:44:56 --> Pagination Class Initialized
INFO - 2026-03-14 06:44:56 --> Config Class Initialized
INFO - 2026-03-14 06:44:56 --> Hooks Class Initialized
INFO - 2026-03-14 06:44:56 --> Email Class Initialized
INFO - 2026-03-14 06:44:56 --> Controller Class Initialized
DEBUG - 2026-03-14 06:44:56 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:56 --> Utf8 Class Initialized
ERROR - 2026-03-14 06:44:56 --> 404 Page Not Found: /index
INFO - 2026-03-14 06:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:44:56 --> URI Class Initialized
INFO - 2026-03-14 06:44:56 --> Upload Class Initialized
INFO - 2026-03-14 06:44:56 --> Router Class Initialized
DEBUG - 2026-03-14 06:44:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:44:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:44:56 --> Output Class Initialized
INFO - 2026-03-14 06:44:56 --> Encryption Class Initialized
INFO - 2026-03-14 06:44:56 --> Security Class Initialized
DEBUG - 2026-03-14 06:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:56 --> Form Validation Class Initialized
INFO - 2026-03-14 06:44:56 --> Input Class Initialized
INFO - 2026-03-14 06:44:56 --> Language Class Initialized
INFO - 2026-03-14 06:44:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:44:56 --> Pagination Class Initialized
INFO - 2026-03-14 06:44:56 --> Language Class Initialized
INFO - 2026-03-14 06:44:56 --> Config Class Initialized
INFO - 2026-03-14 06:44:56 --> Loader Class Initialized
INFO - 2026-03-14 06:44:56 --> Config Class Initialized
INFO - 2026-03-14 06:44:56 --> Hooks Class Initialized
INFO - 2026-03-14 06:44:56 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:56 --> Email Class Initialized
INFO - 2026-03-14 06:44:56 --> Controller Class Initialized
INFO - 2026-03-14 06:44:56 --> Helper loaded: form_helper
ERROR - 2026-03-14 06:44:56 --> 404 Page Not Found: /index
DEBUG - 2026-03-14 06:44:56 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:56 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:56 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:44:56 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:56 --> Helper loaded: email_helper
INFO - 2026-03-14 06:44:56 --> URI Class Initialized
INFO - 2026-03-14 06:44:56 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:56 --> Upload Class Initialized
INFO - 2026-03-14 06:44:56 --> Router Class Initialized
INFO - 2026-03-14 06:44:56 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:56 --> Output Class Initialized
DEBUG - 2026-03-14 06:44:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:44:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:44:56 --> Encryption Class Initialized
INFO - 2026-03-14 06:44:56 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:56 --> Security Class Initialized
DEBUG - 2026-03-14 06:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:56 --> Input Class Initialized
INFO - 2026-03-14 06:44:56 --> Form Validation Class Initialized
INFO - 2026-03-14 06:44:56 --> Language Class Initialized
INFO - 2026-03-14 06:44:56 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:44:56 --> Pagination Class Initialized
INFO - 2026-03-14 06:44:56 --> Language Class Initialized
INFO - 2026-03-14 06:44:56 --> Config Class Initialized
INFO - 2026-03-14 06:44:56 --> Config Class Initialized
INFO - 2026-03-14 06:44:56 --> Hooks Class Initialized
INFO - 2026-03-14 06:44:56 --> Loader Class Initialized
INFO - 2026-03-14 06:44:56 --> Email Class Initialized
INFO - 2026-03-14 06:44:56 --> Controller Class Initialized
ERROR - 2026-03-14 06:44:56 --> 404 Page Not Found: /index
INFO - 2026-03-14 06:44:56 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:56 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-03-14 06:44:56 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:56 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:56 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:56 --> URI Class Initialized
INFO - 2026-03-14 06:44:56 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:56 --> Upload Class Initialized
INFO - 2026-03-14 06:44:56 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:56 --> Helper loaded: email_helper
DEBUG - 2026-03-14 06:44:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:44:56 --> Router Class Initialized
INFO - 2026-03-14 06:44:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:44:56 --> Encryption Class Initialized
INFO - 2026-03-14 06:44:56 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:56 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:56 --> Output Class Initialized
INFO - 2026-03-14 06:44:56 --> Form Validation Class Initialized
INFO - 2026-03-14 06:44:56 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:56 --> Security Class Initialized
INFO - 2026-03-14 06:44:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:44:56 --> Pagination Class Initialized
DEBUG - 2026-03-14 06:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:56 --> Input Class Initialized
INFO - 2026-03-14 06:44:56 --> Language Class Initialized
INFO - 2026-03-14 06:44:56 --> Config Class Initialized
INFO - 2026-03-14 06:44:56 --> Hooks Class Initialized
INFO - 2026-03-14 06:44:56 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:56 --> Email Class Initialized
INFO - 2026-03-14 06:44:56 --> Language Class Initialized
INFO - 2026-03-14 06:44:56 --> Config Class Initialized
INFO - 2026-03-14 06:44:56 --> Controller Class Initialized
ERROR - 2026-03-14 06:44:56 --> 404 Page Not Found: /index
DEBUG - 2026-03-14 06:44:56 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:56 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:56 --> URI Class Initialized
INFO - 2026-03-14 06:44:56 --> Loader Class Initialized
INFO - 2026-03-14 06:44:56 --> Router Class Initialized
INFO - 2026-03-14 06:44:56 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:56 --> Output Class Initialized
INFO - 2026-03-14 06:44:56 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:56 --> Security Class Initialized
INFO - 2026-03-14 06:44:56 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:56 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:56 --> Helper loaded: email_helper
DEBUG - 2026-03-14 06:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:56 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:56 --> Input Class Initialized
INFO - 2026-03-14 06:44:56 --> Language Class Initialized
INFO - 2026-03-14 06:44:56 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:56 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:56 --> Language Class Initialized
INFO - 2026-03-14 06:44:56 --> Config Class Initialized
INFO - 2026-03-14 06:44:56 --> Config Class Initialized
INFO - 2026-03-14 06:44:56 --> Hooks Class Initialized
INFO - 2026-03-14 06:44:56 --> Helper loaded: cpanel_helper
DEBUG - 2026-03-14 06:44:56 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:56 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:56 --> Loader Class Initialized
INFO - 2026-03-14 06:44:56 --> URI Class Initialized
INFO - 2026-03-14 06:44:56 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:56 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:56 --> Router Class Initialized
INFO - 2026-03-14 06:44:56 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:56 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:56 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:56 --> Output Class Initialized
INFO - 2026-03-14 06:44:56 --> Helper loaded: email_helper
INFO - 2026-03-14 06:44:56 --> Security Class Initialized
INFO - 2026-03-14 06:44:56 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:56 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:56 --> Database Driver Class Initialized
DEBUG - 2026-03-14 06:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:56 --> Input Class Initialized
INFO - 2026-03-14 06:44:56 --> Language Class Initialized
INFO - 2026-03-14 06:44:56 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:56 --> Language Class Initialized
INFO - 2026-03-14 06:44:56 --> Config Class Initialized
INFO - 2026-03-14 06:44:56 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:56 --> Loader Class Initialized
INFO - 2026-03-14 06:44:56 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:56 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:56 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:56 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:56 --> Helper loaded: email_helper
INFO - 2026-03-14 06:44:56 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:56 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:56 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:56 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:56 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:56 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:44:57 --> Upload Class Initialized
DEBUG - 2026-03-14 06:44:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:44:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:44:57 --> Encryption Class Initialized
INFO - 2026-03-14 06:44:57 --> Form Validation Class Initialized
INFO - 2026-03-14 06:44:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:44:57 --> Pagination Class Initialized
INFO - 2026-03-14 06:44:57 --> Email Class Initialized
INFO - 2026-03-14 06:44:57 --> Controller Class Initialized
DEBUG - 2026-03-14 06:44:57 --> Dashboard MX_Controller Initialized
INFO - 2026-03-14 06:44:57 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 06:44:57 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 06:44:58 --> Model "Dashboard_model" initialized
INFO - 2026-03-14 06:44:58 --> Final output sent to browser
DEBUG - 2026-03-14 06:44:58 --> Total execution time: 2.7432
INFO - 2026-03-14 06:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:44:58 --> Upload Class Initialized
DEBUG - 2026-03-14 06:44:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:44:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:44:58 --> Encryption Class Initialized
INFO - 2026-03-14 06:44:58 --> Form Validation Class Initialized
INFO - 2026-03-14 06:44:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:44:58 --> Pagination Class Initialized
INFO - 2026-03-14 06:44:58 --> Email Class Initialized
INFO - 2026-03-14 06:44:58 --> Controller Class Initialized
DEBUG - 2026-03-14 06:44:58 --> Dashboard MX_Controller Initialized
INFO - 2026-03-14 06:44:58 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 06:44:58 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 06:44:58 --> Config Class Initialized
INFO - 2026-03-14 06:44:58 --> Hooks Class Initialized
DEBUG - 2026-03-14 06:44:58 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:44:58 --> Utf8 Class Initialized
INFO - 2026-03-14 06:44:58 --> URI Class Initialized
INFO - 2026-03-14 06:44:58 --> Router Class Initialized
INFO - 2026-03-14 06:44:58 --> Output Class Initialized
INFO - 2026-03-14 06:44:58 --> Security Class Initialized
DEBUG - 2026-03-14 06:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:44:58 --> CSRF cookie sent
INFO - 2026-03-14 06:44:58 --> Input Class Initialized
INFO - 2026-03-14 06:44:58 --> Language Class Initialized
INFO - 2026-03-14 06:44:58 --> Language Class Initialized
INFO - 2026-03-14 06:44:58 --> Config Class Initialized
INFO - 2026-03-14 06:44:58 --> Loader Class Initialized
INFO - 2026-03-14 06:44:58 --> Helper loaded: url_helper
INFO - 2026-03-14 06:44:58 --> Helper loaded: form_helper
INFO - 2026-03-14 06:44:58 --> Helper loaded: html_helper
INFO - 2026-03-14 06:44:58 --> Helper loaded: file_helper
INFO - 2026-03-14 06:44:58 --> Helper loaded: email_helper
INFO - 2026-03-14 06:44:58 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:44:58 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:44:58 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:44:58 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:44:58 --> Database Driver Class Initialized
INFO - 2026-03-14 06:44:59 --> Model "Dashboard_model" initialized
INFO - 2026-03-14 06:44:59 --> Final output sent to browser
DEBUG - 2026-03-14 06:44:59 --> Total execution time: 3.0550
INFO - 2026-03-14 06:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:44:59 --> Upload Class Initialized
DEBUG - 2026-03-14 06:44:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:44:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:44:59 --> Encryption Class Initialized
INFO - 2026-03-14 06:44:59 --> Form Validation Class Initialized
INFO - 2026-03-14 06:44:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:44:59 --> Pagination Class Initialized
INFO - 2026-03-14 06:44:59 --> Email Class Initialized
INFO - 2026-03-14 06:44:59 --> Controller Class Initialized
DEBUG - 2026-03-14 06:44:59 --> Invoice MX_Controller Initialized
INFO - 2026-03-14 06:44:59 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 06:44:59 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 06:44:59 --> Model "Billing_model" initialized
INFO - 2026-03-14 06:44:59 --> Model "Common_model" initialized
INFO - 2026-03-14 06:44:59 --> Model "Invoice_model" initialized
INFO - 2026-03-14 06:44:59 --> Model "Appsetting_model" initialized
INFO - 2026-03-14 06:45:00 --> Final output sent to browser
DEBUG - 2026-03-14 06:45:00 --> Total execution time: 3.7687
INFO - 2026-03-14 06:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:45:00 --> Upload Class Initialized
DEBUG - 2026-03-14 06:45:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:45:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:45:00 --> Encryption Class Initialized
INFO - 2026-03-14 06:45:00 --> Form Validation Class Initialized
INFO - 2026-03-14 06:45:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:45:00 --> Pagination Class Initialized
INFO - 2026-03-14 06:45:00 --> Email Class Initialized
INFO - 2026-03-14 06:45:00 --> Controller Class Initialized
DEBUG - 2026-03-14 06:45:00 --> Order MX_Controller Initialized
INFO - 2026-03-14 06:45:00 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 06:45:00 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 06:45:00 --> Model "Order_model" initialized
INFO - 2026-03-14 06:45:00 --> Model "Common_model" initialized
INFO - 2026-03-14 06:45:00 --> Model "Currency_model" initialized
INFO - 2026-03-14 06:45:00 --> Final output sent to browser
DEBUG - 2026-03-14 06:45:00 --> Total execution time: 4.5977
INFO - 2026-03-14 06:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:45:00 --> Upload Class Initialized
DEBUG - 2026-03-14 06:45:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:45:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:45:00 --> Encryption Class Initialized
INFO - 2026-03-14 06:45:00 --> Form Validation Class Initialized
INFO - 2026-03-14 06:45:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:45:00 --> Pagination Class Initialized
INFO - 2026-03-14 06:45:00 --> Email Class Initialized
INFO - 2026-03-14 06:45:00 --> Controller Class Initialized
DEBUG - 2026-03-14 06:45:00 --> Dashboard MX_Controller Initialized
INFO - 2026-03-14 06:45:00 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 06:45:00 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 06:45:01 --> Model "Dashboard_model" initialized
INFO - 2026-03-14 06:45:01 --> Final output sent to browser
DEBUG - 2026-03-14 06:45:01 --> Total execution time: 5.3930
INFO - 2026-03-14 06:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:45:01 --> Upload Class Initialized
DEBUG - 2026-03-14 06:45:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:45:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:45:01 --> Encryption Class Initialized
INFO - 2026-03-14 06:45:01 --> Form Validation Class Initialized
INFO - 2026-03-14 06:45:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:45:01 --> Pagination Class Initialized
INFO - 2026-03-14 06:45:01 --> Email Class Initialized
INFO - 2026-03-14 06:45:01 --> Controller Class Initialized
DEBUG - 2026-03-14 06:45:01 --> Ticket MX_Controller Initialized
INFO - 2026-03-14 06:45:01 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 06:45:01 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 06:45:01 --> Model "Support_model" initialized
INFO - 2026-03-14 06:45:01 --> Model "Common_model" initialized
INFO - 2026-03-14 06:45:02 --> Final output sent to browser
DEBUG - 2026-03-14 06:45:02 --> Total execution time: 6.2297
INFO - 2026-03-14 06:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:45:02 --> Upload Class Initialized
DEBUG - 2026-03-14 06:45:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:45:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:45:02 --> Encryption Class Initialized
INFO - 2026-03-14 06:45:02 --> Form Validation Class Initialized
INFO - 2026-03-14 06:45:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:45:02 --> Pagination Class Initialized
INFO - 2026-03-14 06:45:02 --> Email Class Initialized
INFO - 2026-03-14 06:45:02 --> Controller Class Initialized
ERROR - 2026-03-14 06:45:02 --> 404 Page Not Found: /index
INFO - 2026-03-14 06:53:43 --> Config Class Initialized
INFO - 2026-03-14 06:53:43 --> Hooks Class Initialized
DEBUG - 2026-03-14 06:53:43 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:53:43 --> Utf8 Class Initialized
INFO - 2026-03-14 06:53:43 --> URI Class Initialized
INFO - 2026-03-14 06:53:43 --> Router Class Initialized
INFO - 2026-03-14 06:53:43 --> Output Class Initialized
INFO - 2026-03-14 06:53:43 --> Security Class Initialized
DEBUG - 2026-03-14 06:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:53:43 --> CSRF cookie sent
INFO - 2026-03-14 06:53:43 --> Input Class Initialized
INFO - 2026-03-14 06:53:43 --> Language Class Initialized
INFO - 2026-03-14 06:53:43 --> Language Class Initialized
INFO - 2026-03-14 06:53:43 --> Config Class Initialized
INFO - 2026-03-14 06:53:43 --> Loader Class Initialized
INFO - 2026-03-14 06:53:43 --> Helper loaded: url_helper
INFO - 2026-03-14 06:53:43 --> Helper loaded: form_helper
INFO - 2026-03-14 06:53:43 --> Helper loaded: html_helper
INFO - 2026-03-14 06:53:43 --> Helper loaded: file_helper
INFO - 2026-03-14 06:53:43 --> Helper loaded: email_helper
INFO - 2026-03-14 06:53:43 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:53:43 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:53:43 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:53:43 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:53:43 --> Database Driver Class Initialized
INFO - 2026-03-14 06:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:53:45 --> Upload Class Initialized
DEBUG - 2026-03-14 06:53:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:53:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:53:45 --> Encryption Class Initialized
INFO - 2026-03-14 06:53:45 --> Form Validation Class Initialized
INFO - 2026-03-14 06:53:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:53:45 --> Pagination Class Initialized
INFO - 2026-03-14 06:53:45 --> Email Class Initialized
INFO - 2026-03-14 06:53:45 --> Controller Class Initialized
DEBUG - 2026-03-14 06:53:45 --> Dashboard MX_Controller Initialized
INFO - 2026-03-14 06:53:45 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 06:53:45 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 06:53:46 --> Model "Dashboard_model" initialized
DEBUG - 2026-03-14 06:53:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-14 06:53:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-14 06:53:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-14 06:53:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-14 06:53:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-14 06:53:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/dashboard_index.php
INFO - 2026-03-14 06:53:46 --> Final output sent to browser
DEBUG - 2026-03-14 06:53:46 --> Total execution time: 2.4485
INFO - 2026-03-14 06:53:46 --> Config Class Initialized
INFO - 2026-03-14 06:53:46 --> Hooks Class Initialized
DEBUG - 2026-03-14 06:53:46 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:53:46 --> Utf8 Class Initialized
INFO - 2026-03-14 06:53:46 --> URI Class Initialized
INFO - 2026-03-14 06:53:46 --> Router Class Initialized
INFO - 2026-03-14 06:53:46 --> Output Class Initialized
INFO - 2026-03-14 06:53:46 --> Security Class Initialized
DEBUG - 2026-03-14 06:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:53:46 --> CSRF cookie sent
INFO - 2026-03-14 06:53:46 --> Input Class Initialized
INFO - 2026-03-14 06:53:46 --> Language Class Initialized
INFO - 2026-03-14 06:53:46 --> Language Class Initialized
INFO - 2026-03-14 06:53:46 --> Config Class Initialized
INFO - 2026-03-14 06:53:46 --> Loader Class Initialized
INFO - 2026-03-14 06:53:46 --> Helper loaded: url_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: form_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: html_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: file_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: email_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:53:46 --> Database Driver Class Initialized
INFO - 2026-03-14 06:53:46 --> Config Class Initialized
INFO - 2026-03-14 06:53:46 --> Config Class Initialized
INFO - 2026-03-14 06:53:46 --> Hooks Class Initialized
INFO - 2026-03-14 06:53:46 --> Hooks Class Initialized
DEBUG - 2026-03-14 06:53:46 --> UTF-8 Support Enabled
DEBUG - 2026-03-14 06:53:46 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:53:46 --> Utf8 Class Initialized
INFO - 2026-03-14 06:53:46 --> Utf8 Class Initialized
INFO - 2026-03-14 06:53:46 --> URI Class Initialized
INFO - 2026-03-14 06:53:46 --> URI Class Initialized
INFO - 2026-03-14 06:53:46 --> Router Class Initialized
INFO - 2026-03-14 06:53:46 --> Router Class Initialized
INFO - 2026-03-14 06:53:46 --> Output Class Initialized
INFO - 2026-03-14 06:53:46 --> Security Class Initialized
INFO - 2026-03-14 06:53:46 --> Output Class Initialized
INFO - 2026-03-14 06:53:46 --> Security Class Initialized
DEBUG - 2026-03-14 06:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:53:46 --> Config Class Initialized
INFO - 2026-03-14 06:53:46 --> Hooks Class Initialized
INFO - 2026-03-14 06:53:46 --> CSRF cookie sent
INFO - 2026-03-14 06:53:46 --> Input Class Initialized
INFO - 2026-03-14 06:53:46 --> Language Class Initialized
DEBUG - 2026-03-14 06:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:53:46 --> CSRF cookie sent
INFO - 2026-03-14 06:53:46 --> Input Class Initialized
INFO - 2026-03-14 06:53:46 --> Language Class Initialized
INFO - 2026-03-14 06:53:46 --> Language Class Initialized
INFO - 2026-03-14 06:53:46 --> Config Class Initialized
INFO - 2026-03-14 06:53:46 --> Language Class Initialized
DEBUG - 2026-03-14 06:53:46 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:53:46 --> Config Class Initialized
INFO - 2026-03-14 06:53:46 --> Utf8 Class Initialized
INFO - 2026-03-14 06:53:46 --> URI Class Initialized
INFO - 2026-03-14 06:53:46 --> Loader Class Initialized
INFO - 2026-03-14 06:53:46 --> Loader Class Initialized
INFO - 2026-03-14 06:53:46 --> Helper loaded: url_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: url_helper
INFO - 2026-03-14 06:53:46 --> Router Class Initialized
INFO - 2026-03-14 06:53:46 --> Helper loaded: form_helper
INFO - 2026-03-14 06:53:46 --> Config Class Initialized
INFO - 2026-03-14 06:53:46 --> Hooks Class Initialized
INFO - 2026-03-14 06:53:46 --> Helper loaded: html_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: form_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: file_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: html_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: email_helper
INFO - 2026-03-14 06:53:46 --> Output Class Initialized
INFO - 2026-03-14 06:53:46 --> Helper loaded: file_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: email_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:53:46 --> Security Class Initialized
INFO - 2026-03-14 06:53:46 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: cpanel_helper
DEBUG - 2026-03-14 06:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:53:46 --> CSRF cookie sent
INFO - 2026-03-14 06:53:46 --> Input Class Initialized
INFO - 2026-03-14 06:53:46 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:53:46 --> Language Class Initialized
INFO - 2026-03-14 06:53:46 --> Language Class Initialized
INFO - 2026-03-14 06:53:46 --> Config Class Initialized
DEBUG - 2026-03-14 06:53:46 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:53:46 --> Utf8 Class Initialized
INFO - 2026-03-14 06:53:46 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:53:46 --> Config Class Initialized
INFO - 2026-03-14 06:53:46 --> Hooks Class Initialized
INFO - 2026-03-14 06:53:46 --> Loader Class Initialized
INFO - 2026-03-14 06:53:46 --> Helper loaded: url_helper
INFO - 2026-03-14 06:53:46 --> URI Class Initialized
INFO - 2026-03-14 06:53:46 --> Helper loaded: form_helper
INFO - 2026-03-14 06:53:46 --> Database Driver Class Initialized
INFO - 2026-03-14 06:53:46 --> Helper loaded: html_helper
INFO - 2026-03-14 06:53:46 --> Database Driver Class Initialized
DEBUG - 2026-03-14 06:53:46 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:53:46 --> Utf8 Class Initialized
INFO - 2026-03-14 06:53:46 --> Helper loaded: file_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: email_helper
INFO - 2026-03-14 06:53:46 --> URI Class Initialized
INFO - 2026-03-14 06:53:46 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:53:46 --> Router Class Initialized
INFO - 2026-03-14 06:53:46 --> Output Class Initialized
INFO - 2026-03-14 06:53:46 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:53:46 --> Security Class Initialized
INFO - 2026-03-14 06:53:46 --> Router Class Initialized
INFO - 2026-03-14 06:53:46 --> Database Driver Class Initialized
INFO - 2026-03-14 06:53:46 --> Output Class Initialized
INFO - 2026-03-14 06:53:46 --> Security Class Initialized
DEBUG - 2026-03-14 06:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:53:46 --> CSRF cookie sent
INFO - 2026-03-14 06:53:46 --> Input Class Initialized
INFO - 2026-03-14 06:53:46 --> Language Class Initialized
INFO - 2026-03-14 06:53:46 --> Language Class Initialized
INFO - 2026-03-14 06:53:46 --> Config Class Initialized
DEBUG - 2026-03-14 06:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:53:46 --> CSRF cookie sent
INFO - 2026-03-14 06:53:46 --> Input Class Initialized
INFO - 2026-03-14 06:53:46 --> Language Class Initialized
INFO - 2026-03-14 06:53:46 --> Language Class Initialized
INFO - 2026-03-14 06:53:46 --> Config Class Initialized
INFO - 2026-03-14 06:53:46 --> Loader Class Initialized
INFO - 2026-03-14 06:53:46 --> Helper loaded: url_helper
INFO - 2026-03-14 06:53:46 --> Loader Class Initialized
INFO - 2026-03-14 06:53:46 --> Helper loaded: form_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: url_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: html_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: file_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: email_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: form_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: html_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: file_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: email_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:53:46 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:53:46 --> Database Driver Class Initialized
INFO - 2026-03-14 06:53:46 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:53:46 --> Database Driver Class Initialized
INFO - 2026-03-14 06:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:53:48 --> Upload Class Initialized
DEBUG - 2026-03-14 06:53:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:53:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:53:48 --> Encryption Class Initialized
INFO - 2026-03-14 06:53:48 --> Form Validation Class Initialized
INFO - 2026-03-14 06:53:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:53:48 --> Pagination Class Initialized
INFO - 2026-03-14 06:53:48 --> Email Class Initialized
INFO - 2026-03-14 06:53:48 --> Controller Class Initialized
ERROR - 2026-03-14 06:53:48 --> 404 Page Not Found: /index
INFO - 2026-03-14 06:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:53:48 --> Upload Class Initialized
DEBUG - 2026-03-14 06:53:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:53:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:53:48 --> Encryption Class Initialized
INFO - 2026-03-14 06:53:48 --> Form Validation Class Initialized
INFO - 2026-03-14 06:53:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:53:48 --> Pagination Class Initialized
INFO - 2026-03-14 06:53:48 --> Email Class Initialized
INFO - 2026-03-14 06:53:48 --> Controller Class Initialized
INFO - 2026-03-14 06:53:48 --> Config Class Initialized
INFO - 2026-03-14 06:53:48 --> Hooks Class Initialized
ERROR - 2026-03-14 06:53:48 --> 404 Page Not Found: /index
INFO - 2026-03-14 06:53:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-03-14 06:53:48 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:53:48 --> Utf8 Class Initialized
INFO - 2026-03-14 06:53:48 --> URI Class Initialized
INFO - 2026-03-14 06:53:48 --> Upload Class Initialized
INFO - 2026-03-14 06:53:48 --> Router Class Initialized
DEBUG - 2026-03-14 06:53:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:53:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:53:48 --> Encryption Class Initialized
INFO - 2026-03-14 06:53:48 --> Output Class Initialized
INFO - 2026-03-14 06:53:48 --> Security Class Initialized
INFO - 2026-03-14 06:53:48 --> Form Validation Class Initialized
DEBUG - 2026-03-14 06:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:53:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:53:48 --> Pagination Class Initialized
INFO - 2026-03-14 06:53:48 --> Input Class Initialized
INFO - 2026-03-14 06:53:48 --> Language Class Initialized
INFO - 2026-03-14 06:53:48 --> Language Class Initialized
INFO - 2026-03-14 06:53:48 --> Config Class Initialized
INFO - 2026-03-14 06:53:48 --> Config Class Initialized
INFO - 2026-03-14 06:53:48 --> Hooks Class Initialized
INFO - 2026-03-14 06:53:48 --> Email Class Initialized
INFO - 2026-03-14 06:53:48 --> Controller Class Initialized
ERROR - 2026-03-14 06:53:48 --> 404 Page Not Found: /index
INFO - 2026-03-14 06:53:48 --> Loader Class Initialized
INFO - 2026-03-14 06:53:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-03-14 06:53:48 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:53:48 --> Utf8 Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: url_helper
INFO - 2026-03-14 06:53:48 --> URI Class Initialized
INFO - 2026-03-14 06:53:48 --> Upload Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: form_helper
INFO - 2026-03-14 06:53:48 --> Helper loaded: html_helper
INFO - 2026-03-14 06:53:48 --> Helper loaded: file_helper
DEBUG - 2026-03-14 06:53:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:53:48 --> Router Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: email_helper
INFO - 2026-03-14 06:53:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:53:48 --> Encryption Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:53:48 --> Output Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:53:48 --> Form Validation Class Initialized
INFO - 2026-03-14 06:53:48 --> Security Class Initialized
INFO - 2026-03-14 06:53:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:53:48 --> Pagination Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: cpanel_helper
DEBUG - 2026-03-14 06:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:53:48 --> Input Class Initialized
INFO - 2026-03-14 06:53:48 --> Language Class Initialized
INFO - 2026-03-14 06:53:48 --> Language Class Initialized
INFO - 2026-03-14 06:53:48 --> Config Class Initialized
INFO - 2026-03-14 06:53:48 --> Email Class Initialized
INFO - 2026-03-14 06:53:48 --> Config Class Initialized
INFO - 2026-03-14 06:53:48 --> Hooks Class Initialized
INFO - 2026-03-14 06:53:48 --> Controller Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: domain_helper
ERROR - 2026-03-14 06:53:48 --> 404 Page Not Found: /index
INFO - 2026-03-14 06:53:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-03-14 06:53:48 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:53:48 --> Utf8 Class Initialized
INFO - 2026-03-14 06:53:48 --> URI Class Initialized
INFO - 2026-03-14 06:53:48 --> Upload Class Initialized
INFO - 2026-03-14 06:53:48 --> Loader Class Initialized
INFO - 2026-03-14 06:53:48 --> Router Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: url_helper
DEBUG - 2026-03-14 06:53:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:53:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:53:48 --> Encryption Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: form_helper
INFO - 2026-03-14 06:53:48 --> Output Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: html_helper
INFO - 2026-03-14 06:53:48 --> Helper loaded: file_helper
INFO - 2026-03-14 06:53:48 --> Security Class Initialized
INFO - 2026-03-14 06:53:48 --> Form Validation Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: email_helper
INFO - 2026-03-14 06:53:48 --> Database Driver Class Initialized
DEBUG - 2026-03-14 06:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:53:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:53:48 --> Pagination Class Initialized
INFO - 2026-03-14 06:53:48 --> Input Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:53:48 --> Language Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:53:48 --> Language Class Initialized
INFO - 2026-03-14 06:53:48 --> Config Class Initialized
INFO - 2026-03-14 06:53:48 --> Config Class Initialized
INFO - 2026-03-14 06:53:48 --> Hooks Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:53:48 --> Email Class Initialized
INFO - 2026-03-14 06:53:48 --> Controller Class Initialized
DEBUG - 2026-03-14 06:53:48 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:53:48 --> Utf8 Class Initialized
ERROR - 2026-03-14 06:53:48 --> 404 Page Not Found: /index
INFO - 2026-03-14 06:53:48 --> Loader Class Initialized
INFO - 2026-03-14 06:53:48 --> URI Class Initialized
INFO - 2026-03-14 06:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:53:48 --> Helper loaded: url_helper
INFO - 2026-03-14 06:53:48 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:53:48 --> Router Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: form_helper
INFO - 2026-03-14 06:53:48 --> Helper loaded: html_helper
INFO - 2026-03-14 06:53:48 --> Upload Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: file_helper
INFO - 2026-03-14 06:53:48 --> Helper loaded: email_helper
INFO - 2026-03-14 06:53:48 --> Output Class Initialized
DEBUG - 2026-03-14 06:53:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:53:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:53:48 --> Encryption Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:53:48 --> Security Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: ssp_helper
DEBUG - 2026-03-14 06:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:53:48 --> Input Class Initialized
INFO - 2026-03-14 06:53:48 --> Language Class Initialized
INFO - 2026-03-14 06:53:48 --> Form Validation Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:53:48 --> Language Class Initialized
INFO - 2026-03-14 06:53:48 --> Config Class Initialized
INFO - 2026-03-14 06:53:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:53:48 --> Pagination Class Initialized
INFO - 2026-03-14 06:53:48 --> Database Driver Class Initialized
INFO - 2026-03-14 06:53:48 --> Loader Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:53:48 --> Email Class Initialized
INFO - 2026-03-14 06:53:48 --> Controller Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: url_helper
ERROR - 2026-03-14 06:53:48 --> 404 Page Not Found: /index
INFO - 2026-03-14 06:53:48 --> Helper loaded: form_helper
INFO - 2026-03-14 06:53:48 --> Helper loaded: html_helper
INFO - 2026-03-14 06:53:48 --> Helper loaded: file_helper
INFO - 2026-03-14 06:53:48 --> Helper loaded: email_helper
INFO - 2026-03-14 06:53:48 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:53:48 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:53:48 --> Config Class Initialized
INFO - 2026-03-14 06:53:48 --> Hooks Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:53:48 --> Database Driver Class Initialized
DEBUG - 2026-03-14 06:53:48 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:53:48 --> Utf8 Class Initialized
INFO - 2026-03-14 06:53:48 --> URI Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:53:48 --> Router Class Initialized
INFO - 2026-03-14 06:53:48 --> Output Class Initialized
INFO - 2026-03-14 06:53:48 --> Config Class Initialized
INFO - 2026-03-14 06:53:48 --> Hooks Class Initialized
INFO - 2026-03-14 06:53:48 --> Security Class Initialized
DEBUG - 2026-03-14 06:53:48 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:53:48 --> Utf8 Class Initialized
INFO - 2026-03-14 06:53:48 --> Database Driver Class Initialized
DEBUG - 2026-03-14 06:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:53:48 --> Input Class Initialized
INFO - 2026-03-14 06:53:48 --> URI Class Initialized
INFO - 2026-03-14 06:53:48 --> Language Class Initialized
INFO - 2026-03-14 06:53:48 --> Language Class Initialized
INFO - 2026-03-14 06:53:48 --> Config Class Initialized
INFO - 2026-03-14 06:53:48 --> Router Class Initialized
INFO - 2026-03-14 06:53:48 --> Output Class Initialized
INFO - 2026-03-14 06:53:48 --> Loader Class Initialized
INFO - 2026-03-14 06:53:48 --> Security Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: url_helper
DEBUG - 2026-03-14 06:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:53:48 --> Input Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: form_helper
INFO - 2026-03-14 06:53:48 --> Language Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: html_helper
INFO - 2026-03-14 06:53:48 --> Language Class Initialized
INFO - 2026-03-14 06:53:48 --> Config Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: file_helper
INFO - 2026-03-14 06:53:48 --> Helper loaded: email_helper
INFO - 2026-03-14 06:53:48 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:53:48 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:53:48 --> Loader Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:53:48 --> Helper loaded: url_helper
INFO - 2026-03-14 06:53:48 --> Helper loaded: form_helper
INFO - 2026-03-14 06:53:48 --> Helper loaded: html_helper
INFO - 2026-03-14 06:53:48 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:53:48 --> Helper loaded: file_helper
INFO - 2026-03-14 06:53:48 --> Helper loaded: email_helper
INFO - 2026-03-14 06:53:48 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:53:48 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:53:48 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:53:48 --> Database Driver Class Initialized
INFO - 2026-03-14 06:53:48 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:53:48 --> Database Driver Class Initialized
INFO - 2026-03-14 06:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:53:50 --> Upload Class Initialized
DEBUG - 2026-03-14 06:53:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:53:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:53:50 --> Encryption Class Initialized
INFO - 2026-03-14 06:53:50 --> Form Validation Class Initialized
INFO - 2026-03-14 06:53:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:53:50 --> Pagination Class Initialized
INFO - 2026-03-14 06:53:50 --> Email Class Initialized
INFO - 2026-03-14 06:53:50 --> Controller Class Initialized
DEBUG - 2026-03-14 06:53:50 --> Order MX_Controller Initialized
INFO - 2026-03-14 06:53:50 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 06:53:50 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 06:53:51 --> Model "Order_model" initialized
INFO - 2026-03-14 06:53:51 --> Model "Common_model" initialized
INFO - 2026-03-14 06:53:51 --> Model "Currency_model" initialized
INFO - 2026-03-14 06:53:51 --> Final output sent to browser
DEBUG - 2026-03-14 06:53:51 --> Total execution time: 3.3105
INFO - 2026-03-14 06:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:53:51 --> Upload Class Initialized
DEBUG - 2026-03-14 06:53:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:53:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:53:51 --> Encryption Class Initialized
INFO - 2026-03-14 06:53:51 --> Form Validation Class Initialized
INFO - 2026-03-14 06:53:51 --> Config Class Initialized
INFO - 2026-03-14 06:53:51 --> Hooks Class Initialized
INFO - 2026-03-14 06:53:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:53:51 --> Pagination Class Initialized
DEBUG - 2026-03-14 06:53:51 --> UTF-8 Support Enabled
INFO - 2026-03-14 06:53:51 --> Utf8 Class Initialized
INFO - 2026-03-14 06:53:51 --> URI Class Initialized
INFO - 2026-03-14 06:53:51 --> Router Class Initialized
INFO - 2026-03-14 06:53:51 --> Email Class Initialized
INFO - 2026-03-14 06:53:51 --> Controller Class Initialized
DEBUG - 2026-03-14 06:53:51 --> Dashboard MX_Controller Initialized
INFO - 2026-03-14 06:53:51 --> Output Class Initialized
INFO - 2026-03-14 06:53:51 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 06:53:51 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 06:53:51 --> Security Class Initialized
DEBUG - 2026-03-14 06:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 06:53:51 --> CSRF cookie sent
INFO - 2026-03-14 06:53:51 --> Input Class Initialized
INFO - 2026-03-14 06:53:51 --> Language Class Initialized
INFO - 2026-03-14 06:53:51 --> Language Class Initialized
INFO - 2026-03-14 06:53:51 --> Config Class Initialized
INFO - 2026-03-14 06:53:51 --> Loader Class Initialized
INFO - 2026-03-14 06:53:51 --> Helper loaded: url_helper
INFO - 2026-03-14 06:53:51 --> Helper loaded: form_helper
INFO - 2026-03-14 06:53:51 --> Helper loaded: html_helper
INFO - 2026-03-14 06:53:51 --> Helper loaded: file_helper
INFO - 2026-03-14 06:53:51 --> Helper loaded: email_helper
INFO - 2026-03-14 06:53:51 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 06:53:51 --> Helper loaded: ssp_helper
INFO - 2026-03-14 06:53:51 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 06:53:51 --> Helper loaded: domain_helper
INFO - 2026-03-14 06:53:51 --> Database Driver Class Initialized
INFO - 2026-03-14 06:53:52 --> Model "Dashboard_model" initialized
INFO - 2026-03-14 06:53:52 --> Final output sent to browser
DEBUG - 2026-03-14 06:53:52 --> Total execution time: 4.1609
INFO - 2026-03-14 06:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:53:52 --> Upload Class Initialized
DEBUG - 2026-03-14 06:53:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:53:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:53:52 --> Encryption Class Initialized
INFO - 2026-03-14 06:53:52 --> Form Validation Class Initialized
INFO - 2026-03-14 06:53:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:53:52 --> Pagination Class Initialized
INFO - 2026-03-14 06:53:52 --> Email Class Initialized
INFO - 2026-03-14 06:53:52 --> Controller Class Initialized
DEBUG - 2026-03-14 06:53:52 --> Dashboard MX_Controller Initialized
INFO - 2026-03-14 06:53:52 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 06:53:52 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 06:53:53 --> Model "Dashboard_model" initialized
INFO - 2026-03-14 06:53:53 --> Final output sent to browser
DEBUG - 2026-03-14 06:53:53 --> Total execution time: 4.9118
INFO - 2026-03-14 06:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:53:53 --> Upload Class Initialized
DEBUG - 2026-03-14 06:53:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:53:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:53:53 --> Encryption Class Initialized
INFO - 2026-03-14 06:53:53 --> Form Validation Class Initialized
INFO - 2026-03-14 06:53:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:53:53 --> Pagination Class Initialized
INFO - 2026-03-14 06:53:53 --> Email Class Initialized
INFO - 2026-03-14 06:53:53 --> Controller Class Initialized
DEBUG - 2026-03-14 06:53:53 --> Dashboard MX_Controller Initialized
INFO - 2026-03-14 06:53:53 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 06:53:53 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 06:53:53 --> Model "Dashboard_model" initialized
INFO - 2026-03-14 06:53:54 --> Final output sent to browser
DEBUG - 2026-03-14 06:53:54 --> Total execution time: 5.6940
INFO - 2026-03-14 06:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:53:54 --> Upload Class Initialized
DEBUG - 2026-03-14 06:53:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:53:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:53:54 --> Encryption Class Initialized
INFO - 2026-03-14 06:53:54 --> Form Validation Class Initialized
INFO - 2026-03-14 06:53:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:53:54 --> Pagination Class Initialized
INFO - 2026-03-14 06:53:54 --> Email Class Initialized
INFO - 2026-03-14 06:53:54 --> Controller Class Initialized
DEBUG - 2026-03-14 06:53:54 --> Invoice MX_Controller Initialized
INFO - 2026-03-14 06:53:54 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 06:53:54 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 06:53:54 --> Model "Billing_model" initialized
INFO - 2026-03-14 06:53:54 --> Model "Common_model" initialized
INFO - 2026-03-14 06:53:54 --> Model "Invoice_model" initialized
INFO - 2026-03-14 06:53:54 --> Model "Appsetting_model" initialized
INFO - 2026-03-14 06:53:55 --> Final output sent to browser
DEBUG - 2026-03-14 06:53:55 --> Total execution time: 6.5281
INFO - 2026-03-14 06:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:53:55 --> Upload Class Initialized
DEBUG - 2026-03-14 06:53:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:53:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:53:55 --> Encryption Class Initialized
INFO - 2026-03-14 06:53:55 --> Form Validation Class Initialized
INFO - 2026-03-14 06:53:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:53:55 --> Pagination Class Initialized
INFO - 2026-03-14 06:53:55 --> Email Class Initialized
INFO - 2026-03-14 06:53:55 --> Controller Class Initialized
DEBUG - 2026-03-14 06:53:55 --> Ticket MX_Controller Initialized
INFO - 2026-03-14 06:53:55 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 06:53:55 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 06:53:55 --> Model "Support_model" initialized
INFO - 2026-03-14 06:53:55 --> Model "Common_model" initialized
INFO - 2026-03-14 06:53:55 --> Final output sent to browser
DEBUG - 2026-03-14 06:53:55 --> Total execution time: 7.3515
INFO - 2026-03-14 06:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 06:53:55 --> Upload Class Initialized
DEBUG - 2026-03-14 06:53:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 06:53:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 06:53:55 --> Encryption Class Initialized
INFO - 2026-03-14 06:53:55 --> Form Validation Class Initialized
INFO - 2026-03-14 06:53:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 06:53:55 --> Pagination Class Initialized
INFO - 2026-03-14 06:53:55 --> Email Class Initialized
INFO - 2026-03-14 06:53:55 --> Controller Class Initialized
ERROR - 2026-03-14 06:53:55 --> 404 Page Not Found: /index
INFO - 2026-03-14 07:09:51 --> Config Class Initialized
INFO - 2026-03-14 07:09:51 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:09:51 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:09:51 --> Utf8 Class Initialized
INFO - 2026-03-14 07:09:51 --> URI Class Initialized
INFO - 2026-03-14 07:09:51 --> Router Class Initialized
INFO - 2026-03-14 07:09:51 --> Output Class Initialized
INFO - 2026-03-14 07:09:51 --> Security Class Initialized
DEBUG - 2026-03-14 07:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:09:51 --> CSRF cookie sent
INFO - 2026-03-14 07:09:51 --> Input Class Initialized
INFO - 2026-03-14 07:09:51 --> Language Class Initialized
INFO - 2026-03-14 07:09:51 --> Language Class Initialized
INFO - 2026-03-14 07:09:51 --> Config Class Initialized
INFO - 2026-03-14 07:09:51 --> Loader Class Initialized
INFO - 2026-03-14 07:09:51 --> Helper loaded: url_helper
INFO - 2026-03-14 07:09:51 --> Helper loaded: form_helper
INFO - 2026-03-14 07:09:51 --> Helper loaded: html_helper
INFO - 2026-03-14 07:09:51 --> Helper loaded: file_helper
INFO - 2026-03-14 07:09:51 --> Helper loaded: email_helper
INFO - 2026-03-14 07:09:51 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:09:51 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:09:51 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:09:51 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:09:51 --> Database Driver Class Initialized
INFO - 2026-03-14 07:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:09:53 --> Upload Class Initialized
DEBUG - 2026-03-14 07:09:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:09:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:09:53 --> Encryption Class Initialized
INFO - 2026-03-14 07:09:53 --> Form Validation Class Initialized
INFO - 2026-03-14 07:09:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:09:53 --> Pagination Class Initialized
INFO - 2026-03-14 07:09:53 --> Email Class Initialized
INFO - 2026-03-14 07:09:53 --> Controller Class Initialized
DEBUG - 2026-03-14 07:09:53 --> Dashboard MX_Controller Initialized
INFO - 2026-03-14 07:09:53 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:09:53 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:09:54 --> Model "Dashboard_model" initialized
DEBUG - 2026-03-14 07:09:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-14 07:09:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-14 07:09:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-14 07:09:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-14 07:09:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-14 07:09:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/dashboard_index.php
INFO - 2026-03-14 07:09:54 --> Final output sent to browser
DEBUG - 2026-03-14 07:09:54 --> Total execution time: 2.3948
INFO - 2026-03-14 07:09:54 --> Config Class Initialized
INFO - 2026-03-14 07:09:54 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:09:54 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:09:54 --> Utf8 Class Initialized
INFO - 2026-03-14 07:09:54 --> URI Class Initialized
INFO - 2026-03-14 07:09:54 --> Router Class Initialized
INFO - 2026-03-14 07:09:54 --> Output Class Initialized
INFO - 2026-03-14 07:09:54 --> Security Class Initialized
DEBUG - 2026-03-14 07:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:09:54 --> CSRF cookie sent
INFO - 2026-03-14 07:09:54 --> Input Class Initialized
INFO - 2026-03-14 07:09:54 --> Language Class Initialized
INFO - 2026-03-14 07:09:54 --> Language Class Initialized
INFO - 2026-03-14 07:09:54 --> Config Class Initialized
INFO - 2026-03-14 07:09:54 --> Loader Class Initialized
INFO - 2026-03-14 07:09:54 --> Helper loaded: url_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: form_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: html_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: file_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: email_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:09:54 --> Database Driver Class Initialized
INFO - 2026-03-14 07:09:54 --> Config Class Initialized
INFO - 2026-03-14 07:09:54 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:09:54 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:09:54 --> Utf8 Class Initialized
INFO - 2026-03-14 07:09:54 --> URI Class Initialized
INFO - 2026-03-14 07:09:54 --> Router Class Initialized
INFO - 2026-03-14 07:09:54 --> Output Class Initialized
INFO - 2026-03-14 07:09:54 --> Security Class Initialized
DEBUG - 2026-03-14 07:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:09:54 --> CSRF cookie sent
INFO - 2026-03-14 07:09:54 --> Input Class Initialized
INFO - 2026-03-14 07:09:54 --> Language Class Initialized
INFO - 2026-03-14 07:09:54 --> Language Class Initialized
INFO - 2026-03-14 07:09:54 --> Config Class Initialized
INFO - 2026-03-14 07:09:54 --> Loader Class Initialized
INFO - 2026-03-14 07:09:54 --> Helper loaded: url_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: form_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: html_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: file_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: email_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:09:54 --> Config Class Initialized
INFO - 2026-03-14 07:09:54 --> Hooks Class Initialized
INFO - 2026-03-14 07:09:54 --> Config Class Initialized
INFO - 2026-03-14 07:09:54 --> Hooks Class Initialized
INFO - 2026-03-14 07:09:54 --> Helper loaded: domain_helper
DEBUG - 2026-03-14 07:09:54 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:09:54 --> Utf8 Class Initialized
DEBUG - 2026-03-14 07:09:54 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:09:54 --> Utf8 Class Initialized
INFO - 2026-03-14 07:09:54 --> URI Class Initialized
INFO - 2026-03-14 07:09:54 --> URI Class Initialized
INFO - 2026-03-14 07:09:54 --> Router Class Initialized
INFO - 2026-03-14 07:09:54 --> Config Class Initialized
INFO - 2026-03-14 07:09:54 --> Hooks Class Initialized
INFO - 2026-03-14 07:09:54 --> Router Class Initialized
DEBUG - 2026-03-14 07:09:54 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:09:54 --> Utf8 Class Initialized
INFO - 2026-03-14 07:09:54 --> Output Class Initialized
INFO - 2026-03-14 07:09:54 --> Config Class Initialized
INFO - 2026-03-14 07:09:54 --> Hooks Class Initialized
INFO - 2026-03-14 07:09:54 --> URI Class Initialized
INFO - 2026-03-14 07:09:54 --> Security Class Initialized
INFO - 2026-03-14 07:09:54 --> Database Driver Class Initialized
DEBUG - 2026-03-14 07:09:54 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:09:54 --> Utf8 Class Initialized
INFO - 2026-03-14 07:09:54 --> Output Class Initialized
DEBUG - 2026-03-14 07:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:09:54 --> CSRF cookie sent
INFO - 2026-03-14 07:09:54 --> Input Class Initialized
INFO - 2026-03-14 07:09:54 --> Language Class Initialized
INFO - 2026-03-14 07:09:54 --> URI Class Initialized
INFO - 2026-03-14 07:09:54 --> Language Class Initialized
INFO - 2026-03-14 07:09:54 --> Config Class Initialized
INFO - 2026-03-14 07:09:54 --> Router Class Initialized
INFO - 2026-03-14 07:09:54 --> Security Class Initialized
INFO - 2026-03-14 07:09:54 --> Output Class Initialized
INFO - 2026-03-14 07:09:54 --> Router Class Initialized
DEBUG - 2026-03-14 07:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:09:54 --> CSRF cookie sent
INFO - 2026-03-14 07:09:54 --> Input Class Initialized
INFO - 2026-03-14 07:09:54 --> Security Class Initialized
INFO - 2026-03-14 07:09:54 --> Language Class Initialized
INFO - 2026-03-14 07:09:54 --> Loader Class Initialized
DEBUG - 2026-03-14 07:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:09:54 --> CSRF cookie sent
INFO - 2026-03-14 07:09:54 --> Input Class Initialized
INFO - 2026-03-14 07:09:54 --> Output Class Initialized
INFO - 2026-03-14 07:09:54 --> Language Class Initialized
INFO - 2026-03-14 07:09:54 --> Language Class Initialized
INFO - 2026-03-14 07:09:54 --> Config Class Initialized
INFO - 2026-03-14 07:09:54 --> Helper loaded: url_helper
INFO - 2026-03-14 07:09:54 --> Language Class Initialized
INFO - 2026-03-14 07:09:54 --> Config Class Initialized
INFO - 2026-03-14 07:09:54 --> Security Class Initialized
INFO - 2026-03-14 07:09:54 --> Helper loaded: form_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: html_helper
DEBUG - 2026-03-14 07:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:09:54 --> CSRF cookie sent
INFO - 2026-03-14 07:09:54 --> Loader Class Initialized
INFO - 2026-03-14 07:09:54 --> Helper loaded: file_helper
INFO - 2026-03-14 07:09:54 --> Input Class Initialized
INFO - 2026-03-14 07:09:54 --> Helper loaded: email_helper
INFO - 2026-03-14 07:09:54 --> Language Class Initialized
INFO - 2026-03-14 07:09:54 --> Helper loaded: url_helper
INFO - 2026-03-14 07:09:54 --> Language Class Initialized
INFO - 2026-03-14 07:09:54 --> Config Class Initialized
INFO - 2026-03-14 07:09:54 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:09:54 --> Loader Class Initialized
INFO - 2026-03-14 07:09:54 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: form_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: html_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: url_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: file_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: email_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:09:54 --> Loader Class Initialized
INFO - 2026-03-14 07:09:54 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: url_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: form_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: form_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: html_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: html_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: file_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: email_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: file_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: email_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:09:54 --> Database Driver Class Initialized
INFO - 2026-03-14 07:09:54 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:09:54 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:09:54 --> Database Driver Class Initialized
INFO - 2026-03-14 07:09:54 --> Database Driver Class Initialized
INFO - 2026-03-14 07:09:54 --> Database Driver Class Initialized
INFO - 2026-03-14 07:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:09:56 --> Upload Class Initialized
DEBUG - 2026-03-14 07:09:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:09:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:09:56 --> Encryption Class Initialized
INFO - 2026-03-14 07:09:56 --> Form Validation Class Initialized
INFO - 2026-03-14 07:09:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:09:56 --> Pagination Class Initialized
INFO - 2026-03-14 07:09:56 --> Email Class Initialized
INFO - 2026-03-14 07:09:56 --> Controller Class Initialized
ERROR - 2026-03-14 07:09:56 --> 404 Page Not Found: /index
INFO - 2026-03-14 07:09:56 --> Config Class Initialized
INFO - 2026-03-14 07:09:56 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:09:56 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:09:56 --> Utf8 Class Initialized
INFO - 2026-03-14 07:09:56 --> URI Class Initialized
INFO - 2026-03-14 07:09:56 --> Router Class Initialized
INFO - 2026-03-14 07:09:56 --> Output Class Initialized
INFO - 2026-03-14 07:09:56 --> Security Class Initialized
DEBUG - 2026-03-14 07:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:09:56 --> Input Class Initialized
INFO - 2026-03-14 07:09:56 --> Language Class Initialized
INFO - 2026-03-14 07:09:56 --> Language Class Initialized
INFO - 2026-03-14 07:09:56 --> Config Class Initialized
INFO - 2026-03-14 07:09:56 --> Loader Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: url_helper
INFO - 2026-03-14 07:09:56 --> Helper loaded: form_helper
INFO - 2026-03-14 07:09:56 --> Helper loaded: html_helper
INFO - 2026-03-14 07:09:56 --> Helper loaded: file_helper
INFO - 2026-03-14 07:09:56 --> Helper loaded: email_helper
INFO - 2026-03-14 07:09:56 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:09:56 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:09:56 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:09:56 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:09:56 --> Database Driver Class Initialized
INFO - 2026-03-14 07:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:09:56 --> Upload Class Initialized
DEBUG - 2026-03-14 07:09:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:09:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:09:56 --> Encryption Class Initialized
INFO - 2026-03-14 07:09:56 --> Form Validation Class Initialized
INFO - 2026-03-14 07:09:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:09:56 --> Pagination Class Initialized
INFO - 2026-03-14 07:09:56 --> Email Class Initialized
INFO - 2026-03-14 07:09:56 --> Controller Class Initialized
ERROR - 2026-03-14 07:09:56 --> 404 Page Not Found: /index
INFO - 2026-03-14 07:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:09:56 --> Upload Class Initialized
DEBUG - 2026-03-14 07:09:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:09:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:09:56 --> Encryption Class Initialized
INFO - 2026-03-14 07:09:56 --> Form Validation Class Initialized
INFO - 2026-03-14 07:09:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:09:56 --> Pagination Class Initialized
INFO - 2026-03-14 07:09:56 --> Email Class Initialized
INFO - 2026-03-14 07:09:56 --> Config Class Initialized
INFO - 2026-03-14 07:09:56 --> Controller Class Initialized
INFO - 2026-03-14 07:09:56 --> Hooks Class Initialized
ERROR - 2026-03-14 07:09:56 --> 404 Page Not Found: /index
INFO - 2026-03-14 07:09:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-03-14 07:09:56 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:09:56 --> Utf8 Class Initialized
INFO - 2026-03-14 07:09:56 --> URI Class Initialized
INFO - 2026-03-14 07:09:56 --> Upload Class Initialized
INFO - 2026-03-14 07:09:56 --> Router Class Initialized
DEBUG - 2026-03-14 07:09:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:09:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:09:56 --> Encryption Class Initialized
INFO - 2026-03-14 07:09:56 --> Output Class Initialized
INFO - 2026-03-14 07:09:56 --> Security Class Initialized
INFO - 2026-03-14 07:09:56 --> Form Validation Class Initialized
DEBUG - 2026-03-14 07:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:09:56 --> Input Class Initialized
INFO - 2026-03-14 07:09:56 --> Language Class Initialized
INFO - 2026-03-14 07:09:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:09:56 --> Pagination Class Initialized
INFO - 2026-03-14 07:09:56 --> Language Class Initialized
INFO - 2026-03-14 07:09:56 --> Config Class Initialized
INFO - 2026-03-14 07:09:56 --> Loader Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: url_helper
INFO - 2026-03-14 07:09:56 --> Config Class Initialized
INFO - 2026-03-14 07:09:56 --> Email Class Initialized
INFO - 2026-03-14 07:09:56 --> Hooks Class Initialized
INFO - 2026-03-14 07:09:56 --> Controller Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: form_helper
ERROR - 2026-03-14 07:09:56 --> 404 Page Not Found: /index
INFO - 2026-03-14 07:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:09:56 --> Helper loaded: html_helper
DEBUG - 2026-03-14 07:09:56 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:09:56 --> Utf8 Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: file_helper
INFO - 2026-03-14 07:09:56 --> Helper loaded: email_helper
INFO - 2026-03-14 07:09:56 --> URI Class Initialized
INFO - 2026-03-14 07:09:56 --> Upload Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:09:56 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:09:56 --> Router Class Initialized
DEBUG - 2026-03-14 07:09:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:09:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:09:56 --> Encryption Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:09:56 --> Output Class Initialized
INFO - 2026-03-14 07:09:56 --> Form Validation Class Initialized
INFO - 2026-03-14 07:09:56 --> Security Class Initialized
INFO - 2026-03-14 07:09:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:09:56 --> Pagination Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: domain_helper
DEBUG - 2026-03-14 07:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:09:56 --> Input Class Initialized
INFO - 2026-03-14 07:09:56 --> Language Class Initialized
INFO - 2026-03-14 07:09:56 --> Language Class Initialized
INFO - 2026-03-14 07:09:56 --> Config Class Initialized
INFO - 2026-03-14 07:09:56 --> Email Class Initialized
INFO - 2026-03-14 07:09:56 --> Controller Class Initialized
INFO - 2026-03-14 07:09:56 --> Config Class Initialized
INFO - 2026-03-14 07:09:56 --> Hooks Class Initialized
ERROR - 2026-03-14 07:09:56 --> 404 Page Not Found: /index
INFO - 2026-03-14 07:09:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-03-14 07:09:56 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:09:56 --> Utf8 Class Initialized
INFO - 2026-03-14 07:09:56 --> Loader Class Initialized
INFO - 2026-03-14 07:09:56 --> URI Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: url_helper
INFO - 2026-03-14 07:09:56 --> Upload Class Initialized
INFO - 2026-03-14 07:09:56 --> Database Driver Class Initialized
INFO - 2026-03-14 07:09:56 --> Router Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: form_helper
INFO - 2026-03-14 07:09:56 --> Helper loaded: html_helper
INFO - 2026-03-14 07:09:56 --> Output Class Initialized
DEBUG - 2026-03-14 07:09:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:09:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:09:56 --> Encryption Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: file_helper
INFO - 2026-03-14 07:09:56 --> Helper loaded: email_helper
INFO - 2026-03-14 07:09:56 --> Security Class Initialized
DEBUG - 2026-03-14 07:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:09:56 --> Input Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:09:56 --> Language Class Initialized
INFO - 2026-03-14 07:09:56 --> Form Validation Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:09:56 --> Language Class Initialized
INFO - 2026-03-14 07:09:56 --> Config Class Initialized
INFO - 2026-03-14 07:09:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:09:56 --> Pagination Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:09:56 --> Config Class Initialized
INFO - 2026-03-14 07:09:56 --> Hooks Class Initialized
INFO - 2026-03-14 07:09:56 --> Loader Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: url_helper
DEBUG - 2026-03-14 07:09:56 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:09:56 --> Utf8 Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:09:56 --> Helper loaded: form_helper
INFO - 2026-03-14 07:09:56 --> Email Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: html_helper
INFO - 2026-03-14 07:09:56 --> URI Class Initialized
INFO - 2026-03-14 07:09:56 --> Controller Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: file_helper
ERROR - 2026-03-14 07:09:56 --> 404 Page Not Found: /index
INFO - 2026-03-14 07:09:56 --> Helper loaded: email_helper
INFO - 2026-03-14 07:09:56 --> Router Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:09:56 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:09:56 --> Output Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:09:56 --> Security Class Initialized
DEBUG - 2026-03-14 07:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:09:56 --> Database Driver Class Initialized
INFO - 2026-03-14 07:09:56 --> Input Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:09:56 --> Language Class Initialized
INFO - 2026-03-14 07:09:56 --> Language Class Initialized
INFO - 2026-03-14 07:09:56 --> Config Class Initialized
INFO - 2026-03-14 07:09:56 --> Loader Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: url_helper
INFO - 2026-03-14 07:09:56 --> Helper loaded: form_helper
INFO - 2026-03-14 07:09:56 --> Database Driver Class Initialized
INFO - 2026-03-14 07:09:56 --> Config Class Initialized
INFO - 2026-03-14 07:09:56 --> Hooks Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: html_helper
INFO - 2026-03-14 07:09:56 --> Helper loaded: file_helper
INFO - 2026-03-14 07:09:56 --> Helper loaded: email_helper
DEBUG - 2026-03-14 07:09:56 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:09:56 --> Utf8 Class Initialized
INFO - 2026-03-14 07:09:56 --> URI Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:09:56 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:09:56 --> Router Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:09:56 --> Output Class Initialized
INFO - 2026-03-14 07:09:56 --> Security Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: domain_helper
DEBUG - 2026-03-14 07:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:09:56 --> Input Class Initialized
INFO - 2026-03-14 07:09:56 --> Language Class Initialized
INFO - 2026-03-14 07:09:56 --> Language Class Initialized
INFO - 2026-03-14 07:09:56 --> Config Class Initialized
INFO - 2026-03-14 07:09:56 --> Loader Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: url_helper
INFO - 2026-03-14 07:09:56 --> Helper loaded: form_helper
INFO - 2026-03-14 07:09:56 --> Helper loaded: html_helper
INFO - 2026-03-14 07:09:56 --> Database Driver Class Initialized
INFO - 2026-03-14 07:09:56 --> Helper loaded: file_helper
INFO - 2026-03-14 07:09:56 --> Helper loaded: email_helper
INFO - 2026-03-14 07:09:56 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:09:56 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:09:56 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:09:56 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:09:56 --> Database Driver Class Initialized
INFO - 2026-03-14 07:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:09:58 --> Upload Class Initialized
DEBUG - 2026-03-14 07:09:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:09:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:09:58 --> Encryption Class Initialized
INFO - 2026-03-14 07:09:58 --> Form Validation Class Initialized
INFO - 2026-03-14 07:09:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:09:58 --> Pagination Class Initialized
INFO - 2026-03-14 07:09:58 --> Email Class Initialized
INFO - 2026-03-14 07:09:58 --> Controller Class Initialized
DEBUG - 2026-03-14 07:09:58 --> Dashboard MX_Controller Initialized
INFO - 2026-03-14 07:09:58 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:09:58 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:09:58 --> Model "Dashboard_model" initialized
INFO - 2026-03-14 07:09:59 --> Final output sent to browser
DEBUG - 2026-03-14 07:09:59 --> Total execution time: 2.8570
INFO - 2026-03-14 07:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:09:59 --> Upload Class Initialized
DEBUG - 2026-03-14 07:09:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:09:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:09:59 --> Encryption Class Initialized
INFO - 2026-03-14 07:09:59 --> Form Validation Class Initialized
INFO - 2026-03-14 07:09:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:09:59 --> Pagination Class Initialized
INFO - 2026-03-14 07:09:59 --> Email Class Initialized
INFO - 2026-03-14 07:09:59 --> Controller Class Initialized
INFO - 2026-03-14 07:09:59 --> Config Class Initialized
INFO - 2026-03-14 07:09:59 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:09:59 --> Invoice MX_Controller Initialized
DEBUG - 2026-03-14 07:09:59 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:09:59 --> Utf8 Class Initialized
INFO - 2026-03-14 07:09:59 --> URI Class Initialized
INFO - 2026-03-14 07:09:59 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:09:59 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:09:59 --> Model "Billing_model" initialized
INFO - 2026-03-14 07:09:59 --> Model "Common_model" initialized
INFO - 2026-03-14 07:09:59 --> Router Class Initialized
INFO - 2026-03-14 07:09:59 --> Model "Invoice_model" initialized
INFO - 2026-03-14 07:09:59 --> Model "Appsetting_model" initialized
INFO - 2026-03-14 07:09:59 --> Output Class Initialized
INFO - 2026-03-14 07:09:59 --> Security Class Initialized
DEBUG - 2026-03-14 07:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:09:59 --> CSRF cookie sent
INFO - 2026-03-14 07:09:59 --> Input Class Initialized
INFO - 2026-03-14 07:09:59 --> Language Class Initialized
INFO - 2026-03-14 07:09:59 --> Language Class Initialized
INFO - 2026-03-14 07:09:59 --> Config Class Initialized
INFO - 2026-03-14 07:09:59 --> Loader Class Initialized
INFO - 2026-03-14 07:09:59 --> Helper loaded: url_helper
INFO - 2026-03-14 07:09:59 --> Helper loaded: form_helper
INFO - 2026-03-14 07:09:59 --> Helper loaded: html_helper
INFO - 2026-03-14 07:09:59 --> Helper loaded: file_helper
INFO - 2026-03-14 07:09:59 --> Helper loaded: email_helper
INFO - 2026-03-14 07:09:59 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:09:59 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:09:59 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:09:59 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:09:59 --> Database Driver Class Initialized
INFO - 2026-03-14 07:09:59 --> Final output sent to browser
DEBUG - 2026-03-14 07:09:59 --> Total execution time: 3.2682
INFO - 2026-03-14 07:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:09:59 --> Upload Class Initialized
DEBUG - 2026-03-14 07:09:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:09:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:09:59 --> Encryption Class Initialized
INFO - 2026-03-14 07:09:59 --> Form Validation Class Initialized
INFO - 2026-03-14 07:09:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:09:59 --> Pagination Class Initialized
INFO - 2026-03-14 07:09:59 --> Email Class Initialized
INFO - 2026-03-14 07:09:59 --> Controller Class Initialized
DEBUG - 2026-03-14 07:09:59 --> Order MX_Controller Initialized
INFO - 2026-03-14 07:09:59 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:09:59 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:10:00 --> Model "Order_model" initialized
INFO - 2026-03-14 07:10:00 --> Model "Common_model" initialized
INFO - 2026-03-14 07:10:00 --> Model "Currency_model" initialized
INFO - 2026-03-14 07:10:00 --> Final output sent to browser
DEBUG - 2026-03-14 07:10:00 --> Total execution time: 4.0979
INFO - 2026-03-14 07:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:10:00 --> Upload Class Initialized
DEBUG - 2026-03-14 07:10:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:10:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:10:00 --> Encryption Class Initialized
INFO - 2026-03-14 07:10:00 --> Form Validation Class Initialized
INFO - 2026-03-14 07:10:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:10:00 --> Pagination Class Initialized
INFO - 2026-03-14 07:10:00 --> Email Class Initialized
INFO - 2026-03-14 07:10:00 --> Controller Class Initialized
DEBUG - 2026-03-14 07:10:00 --> Dashboard MX_Controller Initialized
INFO - 2026-03-14 07:10:00 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:10:00 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:10:01 --> Model "Dashboard_model" initialized
INFO - 2026-03-14 07:10:01 --> Final output sent to browser
DEBUG - 2026-03-14 07:10:01 --> Total execution time: 4.8904
INFO - 2026-03-14 07:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:10:01 --> Upload Class Initialized
DEBUG - 2026-03-14 07:10:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:10:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:10:01 --> Encryption Class Initialized
INFO - 2026-03-14 07:10:01 --> Form Validation Class Initialized
INFO - 2026-03-14 07:10:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:10:01 --> Pagination Class Initialized
INFO - 2026-03-14 07:10:01 --> Email Class Initialized
INFO - 2026-03-14 07:10:01 --> Controller Class Initialized
DEBUG - 2026-03-14 07:10:01 --> Dashboard MX_Controller Initialized
INFO - 2026-03-14 07:10:01 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:10:01 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:10:01 --> Model "Dashboard_model" initialized
INFO - 2026-03-14 07:10:02 --> Final output sent to browser
DEBUG - 2026-03-14 07:10:02 --> Total execution time: 5.7037
INFO - 2026-03-14 07:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:10:02 --> Upload Class Initialized
DEBUG - 2026-03-14 07:10:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:10:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:10:02 --> Encryption Class Initialized
INFO - 2026-03-14 07:10:02 --> Form Validation Class Initialized
INFO - 2026-03-14 07:10:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:10:02 --> Pagination Class Initialized
INFO - 2026-03-14 07:10:02 --> Email Class Initialized
INFO - 2026-03-14 07:10:02 --> Controller Class Initialized
DEBUG - 2026-03-14 07:10:02 --> Ticket MX_Controller Initialized
INFO - 2026-03-14 07:10:02 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:10:02 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:10:02 --> Model "Support_model" initialized
INFO - 2026-03-14 07:10:02 --> Model "Common_model" initialized
INFO - 2026-03-14 07:10:03 --> Final output sent to browser
DEBUG - 2026-03-14 07:10:03 --> Total execution time: 6.5588
INFO - 2026-03-14 07:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:10:03 --> Upload Class Initialized
DEBUG - 2026-03-14 07:10:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:10:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:10:03 --> Encryption Class Initialized
INFO - 2026-03-14 07:10:03 --> Form Validation Class Initialized
INFO - 2026-03-14 07:10:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:10:03 --> Pagination Class Initialized
INFO - 2026-03-14 07:10:03 --> Email Class Initialized
INFO - 2026-03-14 07:10:03 --> Controller Class Initialized
ERROR - 2026-03-14 07:10:03 --> 404 Page Not Found: /index
INFO - 2026-03-14 07:12:37 --> Config Class Initialized
INFO - 2026-03-14 07:12:37 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:12:37 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:12:37 --> Utf8 Class Initialized
INFO - 2026-03-14 07:12:37 --> URI Class Initialized
INFO - 2026-03-14 07:12:37 --> Router Class Initialized
INFO - 2026-03-14 07:12:37 --> Output Class Initialized
INFO - 2026-03-14 07:12:37 --> Security Class Initialized
DEBUG - 2026-03-14 07:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:12:37 --> CSRF cookie sent
INFO - 2026-03-14 07:12:37 --> Input Class Initialized
INFO - 2026-03-14 07:12:37 --> Language Class Initialized
INFO - 2026-03-14 07:12:37 --> Language Class Initialized
INFO - 2026-03-14 07:12:37 --> Config Class Initialized
INFO - 2026-03-14 07:12:37 --> Loader Class Initialized
INFO - 2026-03-14 07:12:37 --> Helper loaded: url_helper
INFO - 2026-03-14 07:12:37 --> Helper loaded: form_helper
INFO - 2026-03-14 07:12:37 --> Helper loaded: html_helper
INFO - 2026-03-14 07:12:37 --> Helper loaded: file_helper
INFO - 2026-03-14 07:12:37 --> Helper loaded: email_helper
INFO - 2026-03-14 07:12:37 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:12:37 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:12:37 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:12:37 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:12:37 --> Database Driver Class Initialized
INFO - 2026-03-14 07:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:12:39 --> Upload Class Initialized
DEBUG - 2026-03-14 07:12:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:12:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:12:39 --> Encryption Class Initialized
INFO - 2026-03-14 07:12:39 --> Form Validation Class Initialized
INFO - 2026-03-14 07:12:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:12:39 --> Pagination Class Initialized
INFO - 2026-03-14 07:12:39 --> Email Class Initialized
INFO - 2026-03-14 07:12:39 --> Controller Class Initialized
DEBUG - 2026-03-14 07:12:39 --> Dashboard MX_Controller Initialized
INFO - 2026-03-14 07:12:39 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:12:39 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:12:40 --> Model "Dashboard_model" initialized
DEBUG - 2026-03-14 07:12:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-14 07:12:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-14 07:12:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-14 07:12:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-14 07:12:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-14 07:12:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/dashboard_index.php
INFO - 2026-03-14 07:12:40 --> Final output sent to browser
DEBUG - 2026-03-14 07:12:40 --> Total execution time: 2.5861
INFO - 2026-03-14 07:12:40 --> Config Class Initialized
INFO - 2026-03-14 07:12:40 --> Hooks Class Initialized
INFO - 2026-03-14 07:12:40 --> Config Class Initialized
INFO - 2026-03-14 07:12:40 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:12:40 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:12:40 --> Utf8 Class Initialized
DEBUG - 2026-03-14 07:12:40 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:12:40 --> Utf8 Class Initialized
INFO - 2026-03-14 07:12:40 --> URI Class Initialized
INFO - 2026-03-14 07:12:40 --> URI Class Initialized
INFO - 2026-03-14 07:12:40 --> Router Class Initialized
INFO - 2026-03-14 07:12:40 --> Router Class Initialized
INFO - 2026-03-14 07:12:40 --> Output Class Initialized
INFO - 2026-03-14 07:12:40 --> Output Class Initialized
INFO - 2026-03-14 07:12:40 --> Security Class Initialized
INFO - 2026-03-14 07:12:40 --> Security Class Initialized
DEBUG - 2026-03-14 07:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:12:40 --> Input Class Initialized
INFO - 2026-03-14 07:12:40 --> Language Class Initialized
INFO - 2026-03-14 07:12:40 --> Language Class Initialized
INFO - 2026-03-14 07:12:40 --> Config Class Initialized
DEBUG - 2026-03-14 07:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:12:40 --> Input Class Initialized
INFO - 2026-03-14 07:12:40 --> Language Class Initialized
INFO - 2026-03-14 07:12:40 --> Language Class Initialized
INFO - 2026-03-14 07:12:40 --> Config Class Initialized
INFO - 2026-03-14 07:12:40 --> Loader Class Initialized
INFO - 2026-03-14 07:12:40 --> Helper loaded: url_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: form_helper
INFO - 2026-03-14 07:12:40 --> Loader Class Initialized
INFO - 2026-03-14 07:12:40 --> Helper loaded: html_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: file_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: email_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: url_helper
INFO - 2026-03-14 07:12:40 --> Config Class Initialized
INFO - 2026-03-14 07:12:40 --> Hooks Class Initialized
INFO - 2026-03-14 07:12:40 --> Helper loaded: form_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: html_helper
DEBUG - 2026-03-14 07:12:40 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:12:40 --> Utf8 Class Initialized
INFO - 2026-03-14 07:12:40 --> Helper loaded: file_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: email_helper
INFO - 2026-03-14 07:12:40 --> URI Class Initialized
INFO - 2026-03-14 07:12:40 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:12:40 --> Router Class Initialized
INFO - 2026-03-14 07:12:40 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:12:40 --> Output Class Initialized
INFO - 2026-03-14 07:12:40 --> Database Driver Class Initialized
INFO - 2026-03-14 07:12:40 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:12:40 --> Config Class Initialized
INFO - 2026-03-14 07:12:40 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:12:40 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:12:40 --> Utf8 Class Initialized
INFO - 2026-03-14 07:12:40 --> URI Class Initialized
INFO - 2026-03-14 07:12:40 --> Database Driver Class Initialized
INFO - 2026-03-14 07:12:40 --> Router Class Initialized
INFO - 2026-03-14 07:12:40 --> Config Class Initialized
INFO - 2026-03-14 07:12:40 --> Hooks Class Initialized
INFO - 2026-03-14 07:12:40 --> Output Class Initialized
DEBUG - 2026-03-14 07:12:40 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:12:40 --> Utf8 Class Initialized
INFO - 2026-03-14 07:12:40 --> Security Class Initialized
INFO - 2026-03-14 07:12:40 --> URI Class Initialized
DEBUG - 2026-03-14 07:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:12:40 --> Input Class Initialized
INFO - 2026-03-14 07:12:40 --> Security Class Initialized
INFO - 2026-03-14 07:12:40 --> Language Class Initialized
INFO - 2026-03-14 07:12:40 --> Router Class Initialized
INFO - 2026-03-14 07:12:40 --> Language Class Initialized
INFO - 2026-03-14 07:12:40 --> Config Class Initialized
DEBUG - 2026-03-14 07:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:12:40 --> Input Class Initialized
INFO - 2026-03-14 07:12:40 --> Language Class Initialized
INFO - 2026-03-14 07:12:40 --> Output Class Initialized
INFO - 2026-03-14 07:12:40 --> Language Class Initialized
INFO - 2026-03-14 07:12:40 --> Config Class Initialized
INFO - 2026-03-14 07:12:40 --> Config Class Initialized
INFO - 2026-03-14 07:12:40 --> Hooks Class Initialized
INFO - 2026-03-14 07:12:40 --> Security Class Initialized
INFO - 2026-03-14 07:12:40 --> Loader Class Initialized
DEBUG - 2026-03-14 07:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:12:40 --> Input Class Initialized
INFO - 2026-03-14 07:12:40 --> Language Class Initialized
DEBUG - 2026-03-14 07:12:40 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:12:40 --> Utf8 Class Initialized
INFO - 2026-03-14 07:12:40 --> Language Class Initialized
INFO - 2026-03-14 07:12:40 --> Config Class Initialized
INFO - 2026-03-14 07:12:40 --> URI Class Initialized
INFO - 2026-03-14 07:12:40 --> Helper loaded: url_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: form_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: html_helper
INFO - 2026-03-14 07:12:40 --> Loader Class Initialized
INFO - 2026-03-14 07:12:40 --> Router Class Initialized
INFO - 2026-03-14 07:12:40 --> Helper loaded: file_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: email_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: url_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: form_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: html_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: file_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: email_helper
INFO - 2026-03-14 07:12:40 --> Loader Class Initialized
INFO - 2026-03-14 07:12:40 --> Helper loaded: url_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: form_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: html_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: file_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: email_helper
INFO - 2026-03-14 07:12:40 --> Output Class Initialized
INFO - 2026-03-14 07:12:40 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:12:40 --> Security Class Initialized
INFO - 2026-03-14 07:12:40 --> Helper loaded: domain_helper
DEBUG - 2026-03-14 07:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:12:40 --> Input Class Initialized
INFO - 2026-03-14 07:12:40 --> Language Class Initialized
INFO - 2026-03-14 07:12:40 --> Language Class Initialized
INFO - 2026-03-14 07:12:40 --> Config Class Initialized
INFO - 2026-03-14 07:12:40 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:12:40 --> Database Driver Class Initialized
INFO - 2026-03-14 07:12:40 --> Database Driver Class Initialized
INFO - 2026-03-14 07:12:40 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:12:40 --> Loader Class Initialized
INFO - 2026-03-14 07:12:40 --> Helper loaded: url_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: form_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: html_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: file_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: email_helper
INFO - 2026-03-14 07:12:40 --> Database Driver Class Initialized
INFO - 2026-03-14 07:12:40 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:12:40 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:12:40 --> Database Driver Class Initialized
INFO - 2026-03-14 07:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:12:42 --> Upload Class Initialized
DEBUG - 2026-03-14 07:12:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:12:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:12:42 --> Encryption Class Initialized
INFO - 2026-03-14 07:12:42 --> Form Validation Class Initialized
INFO - 2026-03-14 07:12:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:12:42 --> Pagination Class Initialized
INFO - 2026-03-14 07:12:42 --> Email Class Initialized
INFO - 2026-03-14 07:12:42 --> Controller Class Initialized
DEBUG - 2026-03-14 07:12:42 --> Ticket MX_Controller Initialized
INFO - 2026-03-14 07:12:42 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:12:42 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:12:42 --> Model "Support_model" initialized
INFO - 2026-03-14 07:12:42 --> Model "Common_model" initialized
INFO - 2026-03-14 07:12:43 --> Final output sent to browser
DEBUG - 2026-03-14 07:12:43 --> Total execution time: 2.8605
INFO - 2026-03-14 07:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:12:43 --> Upload Class Initialized
DEBUG - 2026-03-14 07:12:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:12:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:12:43 --> Encryption Class Initialized
INFO - 2026-03-14 07:12:43 --> Form Validation Class Initialized
INFO - 2026-03-14 07:12:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:12:43 --> Pagination Class Initialized
INFO - 2026-03-14 07:12:43 --> Email Class Initialized
INFO - 2026-03-14 07:12:43 --> Controller Class Initialized
DEBUG - 2026-03-14 07:12:43 --> Dashboard MX_Controller Initialized
INFO - 2026-03-14 07:12:43 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:12:43 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:12:43 --> Model "Dashboard_model" initialized
INFO - 2026-03-14 07:12:44 --> Final output sent to browser
DEBUG - 2026-03-14 07:12:44 --> Total execution time: 3.5859
INFO - 2026-03-14 07:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:12:44 --> Upload Class Initialized
DEBUG - 2026-03-14 07:12:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:12:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:12:44 --> Encryption Class Initialized
INFO - 2026-03-14 07:12:44 --> Form Validation Class Initialized
INFO - 2026-03-14 07:12:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:12:44 --> Pagination Class Initialized
INFO - 2026-03-14 07:12:44 --> Email Class Initialized
INFO - 2026-03-14 07:12:44 --> Controller Class Initialized
DEBUG - 2026-03-14 07:12:44 --> Invoice MX_Controller Initialized
INFO - 2026-03-14 07:12:44 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:12:44 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:12:44 --> Model "Billing_model" initialized
INFO - 2026-03-14 07:12:44 --> Model "Common_model" initialized
INFO - 2026-03-14 07:12:44 --> Model "Invoice_model" initialized
INFO - 2026-03-14 07:12:44 --> Model "Appsetting_model" initialized
INFO - 2026-03-14 07:12:44 --> Final output sent to browser
DEBUG - 2026-03-14 07:12:44 --> Total execution time: 4.3856
INFO - 2026-03-14 07:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:12:44 --> Upload Class Initialized
DEBUG - 2026-03-14 07:12:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:12:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:12:44 --> Encryption Class Initialized
INFO - 2026-03-14 07:12:44 --> Form Validation Class Initialized
INFO - 2026-03-14 07:12:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:12:44 --> Pagination Class Initialized
INFO - 2026-03-14 07:12:44 --> Email Class Initialized
INFO - 2026-03-14 07:12:44 --> Controller Class Initialized
DEBUG - 2026-03-14 07:12:44 --> Order MX_Controller Initialized
INFO - 2026-03-14 07:12:44 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:12:44 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:12:45 --> Model "Order_model" initialized
INFO - 2026-03-14 07:12:45 --> Model "Common_model" initialized
INFO - 2026-03-14 07:12:45 --> Model "Currency_model" initialized
INFO - 2026-03-14 07:12:45 --> Final output sent to browser
DEBUG - 2026-03-14 07:12:45 --> Total execution time: 5.2185
INFO - 2026-03-14 07:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:12:45 --> Upload Class Initialized
DEBUG - 2026-03-14 07:12:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:12:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:12:45 --> Encryption Class Initialized
INFO - 2026-03-14 07:12:45 --> Form Validation Class Initialized
INFO - 2026-03-14 07:12:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:12:45 --> Pagination Class Initialized
INFO - 2026-03-14 07:12:45 --> Email Class Initialized
INFO - 2026-03-14 07:12:45 --> Controller Class Initialized
DEBUG - 2026-03-14 07:12:45 --> Dashboard MX_Controller Initialized
INFO - 2026-03-14 07:12:45 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:12:45 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:12:46 --> Model "Dashboard_model" initialized
INFO - 2026-03-14 07:12:46 --> Final output sent to browser
DEBUG - 2026-03-14 07:12:46 --> Total execution time: 6.0196
INFO - 2026-03-14 07:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:12:46 --> Upload Class Initialized
DEBUG - 2026-03-14 07:12:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:12:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:12:46 --> Encryption Class Initialized
INFO - 2026-03-14 07:12:46 --> Form Validation Class Initialized
INFO - 2026-03-14 07:12:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:12:46 --> Pagination Class Initialized
INFO - 2026-03-14 07:12:46 --> Email Class Initialized
INFO - 2026-03-14 07:12:46 --> Controller Class Initialized
DEBUG - 2026-03-14 07:12:46 --> Dashboard MX_Controller Initialized
INFO - 2026-03-14 07:12:46 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:12:46 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:12:46 --> Model "Dashboard_model" initialized
INFO - 2026-03-14 07:12:47 --> Final output sent to browser
DEBUG - 2026-03-14 07:12:47 --> Total execution time: 6.8384
INFO - 2026-03-14 07:15:32 --> Config Class Initialized
INFO - 2026-03-14 07:15:32 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:15:32 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:15:32 --> Utf8 Class Initialized
INFO - 2026-03-14 07:15:32 --> URI Class Initialized
INFO - 2026-03-14 07:15:32 --> Router Class Initialized
INFO - 2026-03-14 07:15:32 --> Output Class Initialized
INFO - 2026-03-14 07:15:32 --> Security Class Initialized
DEBUG - 2026-03-14 07:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:15:32 --> CSRF cookie sent
INFO - 2026-03-14 07:15:32 --> Input Class Initialized
INFO - 2026-03-14 07:15:32 --> Language Class Initialized
INFO - 2026-03-14 07:15:32 --> Language Class Initialized
INFO - 2026-03-14 07:15:32 --> Config Class Initialized
INFO - 2026-03-14 07:15:32 --> Loader Class Initialized
INFO - 2026-03-14 07:15:32 --> Helper loaded: url_helper
INFO - 2026-03-14 07:15:32 --> Helper loaded: form_helper
INFO - 2026-03-14 07:15:32 --> Helper loaded: html_helper
INFO - 2026-03-14 07:15:32 --> Helper loaded: file_helper
INFO - 2026-03-14 07:15:32 --> Helper loaded: email_helper
INFO - 2026-03-14 07:15:32 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:15:32 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:15:32 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:15:32 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:15:32 --> Database Driver Class Initialized
INFO - 2026-03-14 07:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:15:34 --> Upload Class Initialized
DEBUG - 2026-03-14 07:15:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:15:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:15:34 --> Encryption Class Initialized
INFO - 2026-03-14 07:15:34 --> Form Validation Class Initialized
INFO - 2026-03-14 07:15:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:15:34 --> Pagination Class Initialized
INFO - 2026-03-14 07:15:34 --> Email Class Initialized
INFO - 2026-03-14 07:15:34 --> Controller Class Initialized
DEBUG - 2026-03-14 07:15:34 --> Company MX_Controller Initialized
INFO - 2026-03-14 07:15:34 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:15:34 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:15:34 --> Model "Company_model" initialized
INFO - 2026-03-14 07:15:34 --> Model "Common_model" initialized
DEBUG - 2026-03-14 07:15:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-14 07:15:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-14 07:15:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-14 07:15:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-14 07:15:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-14 07:15:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/company_list.php
INFO - 2026-03-14 07:15:34 --> Final output sent to browser
DEBUG - 2026-03-14 07:15:34 --> Total execution time: 2.5026
INFO - 2026-03-14 07:15:35 --> Config Class Initialized
INFO - 2026-03-14 07:15:35 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:15:35 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:15:35 --> Utf8 Class Initialized
INFO - 2026-03-14 07:15:35 --> URI Class Initialized
INFO - 2026-03-14 07:15:35 --> Router Class Initialized
INFO - 2026-03-14 07:15:35 --> Output Class Initialized
INFO - 2026-03-14 07:15:35 --> Security Class Initialized
DEBUG - 2026-03-14 07:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:15:35 --> CSRF cookie sent
INFO - 2026-03-14 07:15:35 --> Input Class Initialized
INFO - 2026-03-14 07:15:35 --> Language Class Initialized
INFO - 2026-03-14 07:15:35 --> Language Class Initialized
INFO - 2026-03-14 07:15:35 --> Config Class Initialized
INFO - 2026-03-14 07:15:35 --> Loader Class Initialized
INFO - 2026-03-14 07:15:35 --> Helper loaded: url_helper
INFO - 2026-03-14 07:15:35 --> Helper loaded: form_helper
INFO - 2026-03-14 07:15:35 --> Helper loaded: html_helper
INFO - 2026-03-14 07:15:35 --> Helper loaded: file_helper
INFO - 2026-03-14 07:15:35 --> Helper loaded: email_helper
INFO - 2026-03-14 07:15:35 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:15:35 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:15:35 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:15:35 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:15:35 --> Database Driver Class Initialized
INFO - 2026-03-14 07:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:15:37 --> Upload Class Initialized
DEBUG - 2026-03-14 07:15:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:15:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:15:37 --> Encryption Class Initialized
INFO - 2026-03-14 07:15:37 --> Form Validation Class Initialized
INFO - 2026-03-14 07:15:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:15:37 --> Pagination Class Initialized
INFO - 2026-03-14 07:15:37 --> Email Class Initialized
INFO - 2026-03-14 07:15:37 --> Controller Class Initialized
DEBUG - 2026-03-14 07:15:37 --> Company MX_Controller Initialized
INFO - 2026-03-14 07:15:37 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:15:37 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:15:37 --> Model "Company_model" initialized
INFO - 2026-03-14 07:15:37 --> Model "Common_model" initialized
INFO - 2026-03-14 07:16:41 --> Config Class Initialized
INFO - 2026-03-14 07:16:41 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:16:41 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:16:41 --> Utf8 Class Initialized
INFO - 2026-03-14 07:16:41 --> URI Class Initialized
INFO - 2026-03-14 07:16:41 --> Router Class Initialized
INFO - 2026-03-14 07:16:41 --> Output Class Initialized
INFO - 2026-03-14 07:16:41 --> Security Class Initialized
DEBUG - 2026-03-14 07:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:16:41 --> CSRF cookie sent
INFO - 2026-03-14 07:16:41 --> Input Class Initialized
INFO - 2026-03-14 07:16:41 --> Language Class Initialized
INFO - 2026-03-14 07:16:41 --> Language Class Initialized
INFO - 2026-03-14 07:16:41 --> Config Class Initialized
INFO - 2026-03-14 07:16:41 --> Loader Class Initialized
INFO - 2026-03-14 07:16:41 --> Helper loaded: url_helper
INFO - 2026-03-14 07:16:41 --> Helper loaded: form_helper
INFO - 2026-03-14 07:16:41 --> Helper loaded: html_helper
INFO - 2026-03-14 07:16:41 --> Helper loaded: file_helper
INFO - 2026-03-14 07:16:41 --> Helper loaded: email_helper
INFO - 2026-03-14 07:16:41 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:16:41 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:16:41 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:16:41 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:16:41 --> Database Driver Class Initialized
INFO - 2026-03-14 07:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:16:43 --> Upload Class Initialized
DEBUG - 2026-03-14 07:16:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:16:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:16:43 --> Encryption Class Initialized
INFO - 2026-03-14 07:16:43 --> Form Validation Class Initialized
INFO - 2026-03-14 07:16:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:16:43 --> Pagination Class Initialized
INFO - 2026-03-14 07:16:43 --> Email Class Initialized
INFO - 2026-03-14 07:16:43 --> Controller Class Initialized
DEBUG - 2026-03-14 07:16:43 --> Order MX_Controller Initialized
INFO - 2026-03-14 07:16:43 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:16:43 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:16:44 --> Model "Order_model" initialized
INFO - 2026-03-14 07:16:44 --> Model "Common_model" initialized
INFO - 2026-03-14 07:16:44 --> Model "Currency_model" initialized
DEBUG - 2026-03-14 07:16:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-14 07:16:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-14 07:16:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-14 07:16:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-14 07:16:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-14 07:16:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/order_list.php
INFO - 2026-03-14 07:16:44 --> Final output sent to browser
DEBUG - 2026-03-14 07:16:44 --> Total execution time: 2.5780
INFO - 2026-03-14 07:16:44 --> Config Class Initialized
INFO - 2026-03-14 07:16:44 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:16:44 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:16:44 --> Utf8 Class Initialized
INFO - 2026-03-14 07:16:44 --> URI Class Initialized
INFO - 2026-03-14 07:16:44 --> Router Class Initialized
INFO - 2026-03-14 07:16:44 --> Output Class Initialized
INFO - 2026-03-14 07:16:44 --> Security Class Initialized
DEBUG - 2026-03-14 07:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:16:44 --> CSRF cookie sent
INFO - 2026-03-14 07:16:44 --> Input Class Initialized
INFO - 2026-03-14 07:16:44 --> Language Class Initialized
INFO - 2026-03-14 07:16:44 --> Language Class Initialized
INFO - 2026-03-14 07:16:44 --> Config Class Initialized
INFO - 2026-03-14 07:16:44 --> Loader Class Initialized
INFO - 2026-03-14 07:16:44 --> Helper loaded: url_helper
INFO - 2026-03-14 07:16:44 --> Helper loaded: form_helper
INFO - 2026-03-14 07:16:44 --> Helper loaded: html_helper
INFO - 2026-03-14 07:16:44 --> Helper loaded: file_helper
INFO - 2026-03-14 07:16:44 --> Helper loaded: email_helper
INFO - 2026-03-14 07:16:44 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:16:44 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:16:44 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:16:44 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:16:44 --> Database Driver Class Initialized
INFO - 2026-03-14 07:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:16:46 --> Upload Class Initialized
DEBUG - 2026-03-14 07:16:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:16:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:16:46 --> Encryption Class Initialized
INFO - 2026-03-14 07:16:46 --> Form Validation Class Initialized
INFO - 2026-03-14 07:16:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:16:46 --> Pagination Class Initialized
INFO - 2026-03-14 07:16:46 --> Email Class Initialized
INFO - 2026-03-14 07:16:46 --> Controller Class Initialized
DEBUG - 2026-03-14 07:16:46 --> Order MX_Controller Initialized
INFO - 2026-03-14 07:16:46 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:16:46 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:16:46 --> Model "Order_model" initialized
INFO - 2026-03-14 07:16:46 --> Model "Common_model" initialized
INFO - 2026-03-14 07:16:46 --> Model "Currency_model" initialized
INFO - 2026-03-14 07:18:02 --> Config Class Initialized
INFO - 2026-03-14 07:18:02 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:18:02 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:18:02 --> Utf8 Class Initialized
INFO - 2026-03-14 07:18:02 --> URI Class Initialized
INFO - 2026-03-14 07:18:02 --> Router Class Initialized
INFO - 2026-03-14 07:18:02 --> Output Class Initialized
INFO - 2026-03-14 07:18:02 --> Security Class Initialized
DEBUG - 2026-03-14 07:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:18:02 --> CSRF cookie sent
INFO - 2026-03-14 07:18:02 --> Input Class Initialized
INFO - 2026-03-14 07:18:02 --> Language Class Initialized
INFO - 2026-03-14 07:18:02 --> Language Class Initialized
INFO - 2026-03-14 07:18:02 --> Config Class Initialized
INFO - 2026-03-14 07:18:02 --> Loader Class Initialized
INFO - 2026-03-14 07:18:02 --> Helper loaded: url_helper
INFO - 2026-03-14 07:18:02 --> Helper loaded: form_helper
INFO - 2026-03-14 07:18:02 --> Helper loaded: html_helper
INFO - 2026-03-14 07:18:02 --> Helper loaded: file_helper
INFO - 2026-03-14 07:18:02 --> Helper loaded: email_helper
INFO - 2026-03-14 07:18:02 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:18:02 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:18:02 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:18:02 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:18:02 --> Database Driver Class Initialized
INFO - 2026-03-14 07:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:18:04 --> Upload Class Initialized
DEBUG - 2026-03-14 07:18:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:18:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:18:04 --> Encryption Class Initialized
INFO - 2026-03-14 07:18:04 --> Form Validation Class Initialized
INFO - 2026-03-14 07:18:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:18:04 --> Pagination Class Initialized
INFO - 2026-03-14 07:18:04 --> Email Class Initialized
INFO - 2026-03-14 07:18:04 --> Controller Class Initialized
DEBUG - 2026-03-14 07:18:04 --> Service_product MX_Controller Initialized
INFO - 2026-03-14 07:18:04 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:18:04 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:18:04 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-14 07:18:04 --> Model "Common_model" initialized
DEBUG - 2026-03-14 07:18:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-14 07:18:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-14 07:18:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-14 07:18:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-14 07:18:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-14 07:18:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_list.php
INFO - 2026-03-14 07:18:04 --> Final output sent to browser
DEBUG - 2026-03-14 07:18:04 --> Total execution time: 2.4362
INFO - 2026-03-14 07:18:04 --> Config Class Initialized
INFO - 2026-03-14 07:18:04 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:18:04 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:18:04 --> Utf8 Class Initialized
INFO - 2026-03-14 07:18:04 --> URI Class Initialized
INFO - 2026-03-14 07:18:04 --> Router Class Initialized
INFO - 2026-03-14 07:18:04 --> Output Class Initialized
INFO - 2026-03-14 07:18:04 --> Security Class Initialized
DEBUG - 2026-03-14 07:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:18:04 --> CSRF cookie sent
INFO - 2026-03-14 07:18:04 --> Input Class Initialized
INFO - 2026-03-14 07:18:04 --> Language Class Initialized
INFO - 2026-03-14 07:18:04 --> Language Class Initialized
INFO - 2026-03-14 07:18:04 --> Config Class Initialized
INFO - 2026-03-14 07:18:04 --> Loader Class Initialized
INFO - 2026-03-14 07:18:04 --> Helper loaded: url_helper
INFO - 2026-03-14 07:18:04 --> Helper loaded: form_helper
INFO - 2026-03-14 07:18:04 --> Helper loaded: html_helper
INFO - 2026-03-14 07:18:04 --> Helper loaded: file_helper
INFO - 2026-03-14 07:18:04 --> Helper loaded: email_helper
INFO - 2026-03-14 07:18:04 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:18:04 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:18:04 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:18:04 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:18:04 --> Database Driver Class Initialized
INFO - 2026-03-14 07:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:18:06 --> Upload Class Initialized
DEBUG - 2026-03-14 07:18:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:18:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:18:06 --> Encryption Class Initialized
INFO - 2026-03-14 07:18:06 --> Form Validation Class Initialized
INFO - 2026-03-14 07:18:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:18:06 --> Pagination Class Initialized
INFO - 2026-03-14 07:18:06 --> Email Class Initialized
INFO - 2026-03-14 07:18:06 --> Controller Class Initialized
DEBUG - 2026-03-14 07:18:06 --> Service_product MX_Controller Initialized
INFO - 2026-03-14 07:18:06 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:18:06 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:18:06 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-14 07:18:06 --> Model "Common_model" initialized
INFO - 2026-03-14 07:18:18 --> Config Class Initialized
INFO - 2026-03-14 07:18:18 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:18:18 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:18:18 --> Utf8 Class Initialized
INFO - 2026-03-14 07:18:18 --> URI Class Initialized
INFO - 2026-03-14 07:18:18 --> Router Class Initialized
INFO - 2026-03-14 07:18:18 --> Output Class Initialized
INFO - 2026-03-14 07:18:18 --> Security Class Initialized
DEBUG - 2026-03-14 07:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:18:18 --> CSRF cookie sent
INFO - 2026-03-14 07:18:18 --> Input Class Initialized
INFO - 2026-03-14 07:18:18 --> Language Class Initialized
INFO - 2026-03-14 07:18:18 --> Language Class Initialized
INFO - 2026-03-14 07:18:18 --> Config Class Initialized
INFO - 2026-03-14 07:18:18 --> Loader Class Initialized
INFO - 2026-03-14 07:18:18 --> Helper loaded: url_helper
INFO - 2026-03-14 07:18:18 --> Helper loaded: form_helper
INFO - 2026-03-14 07:18:18 --> Helper loaded: html_helper
INFO - 2026-03-14 07:18:18 --> Helper loaded: file_helper
INFO - 2026-03-14 07:18:18 --> Helper loaded: email_helper
INFO - 2026-03-14 07:18:18 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:18:18 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:18:18 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:18:18 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:18:18 --> Database Driver Class Initialized
INFO - 2026-03-14 07:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:18:20 --> Upload Class Initialized
DEBUG - 2026-03-14 07:18:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:18:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:18:20 --> Encryption Class Initialized
INFO - 2026-03-14 07:18:20 --> Form Validation Class Initialized
INFO - 2026-03-14 07:18:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:18:20 --> Pagination Class Initialized
INFO - 2026-03-14 07:18:20 --> Email Class Initialized
INFO - 2026-03-14 07:18:20 --> Controller Class Initialized
DEBUG - 2026-03-14 07:18:20 --> Package MX_Controller Initialized
INFO - 2026-03-14 07:18:20 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:18:20 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:18:20 --> Model "Package_model" initialized
INFO - 2026-03-14 07:18:20 --> Model "Common_model" initialized
DEBUG - 2026-03-14 07:18:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-14 07:18:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-14 07:18:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-14 07:18:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-14 07:18:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-14 07:18:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/package_list.php
INFO - 2026-03-14 07:18:20 --> Final output sent to browser
DEBUG - 2026-03-14 07:18:20 --> Total execution time: 2.3672
INFO - 2026-03-14 07:18:20 --> Config Class Initialized
INFO - 2026-03-14 07:18:20 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:18:20 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:18:20 --> Utf8 Class Initialized
INFO - 2026-03-14 07:18:20 --> URI Class Initialized
INFO - 2026-03-14 07:18:20 --> Router Class Initialized
INFO - 2026-03-14 07:18:20 --> Output Class Initialized
INFO - 2026-03-14 07:18:20 --> Security Class Initialized
DEBUG - 2026-03-14 07:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:18:21 --> CSRF cookie sent
INFO - 2026-03-14 07:18:21 --> Input Class Initialized
INFO - 2026-03-14 07:18:21 --> Language Class Initialized
INFO - 2026-03-14 07:18:21 --> Language Class Initialized
INFO - 2026-03-14 07:18:21 --> Config Class Initialized
INFO - 2026-03-14 07:18:21 --> Loader Class Initialized
INFO - 2026-03-14 07:18:21 --> Helper loaded: url_helper
INFO - 2026-03-14 07:18:21 --> Helper loaded: form_helper
INFO - 2026-03-14 07:18:21 --> Helper loaded: html_helper
INFO - 2026-03-14 07:18:21 --> Helper loaded: file_helper
INFO - 2026-03-14 07:18:21 --> Helper loaded: email_helper
INFO - 2026-03-14 07:18:21 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:18:21 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:18:21 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:18:21 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:18:21 --> Database Driver Class Initialized
INFO - 2026-03-14 07:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:18:22 --> Upload Class Initialized
DEBUG - 2026-03-14 07:18:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:18:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:18:22 --> Encryption Class Initialized
INFO - 2026-03-14 07:18:22 --> Form Validation Class Initialized
INFO - 2026-03-14 07:18:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:18:22 --> Pagination Class Initialized
INFO - 2026-03-14 07:18:22 --> Email Class Initialized
INFO - 2026-03-14 07:18:22 --> Controller Class Initialized
DEBUG - 2026-03-14 07:18:22 --> Package MX_Controller Initialized
INFO - 2026-03-14 07:18:22 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:18:22 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:18:22 --> Model "Package_model" initialized
INFO - 2026-03-14 07:18:22 --> Model "Common_model" initialized
INFO - 2026-03-14 07:18:52 --> Config Class Initialized
INFO - 2026-03-14 07:18:52 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:18:52 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:18:52 --> Utf8 Class Initialized
INFO - 2026-03-14 07:18:52 --> URI Class Initialized
INFO - 2026-03-14 07:18:52 --> Router Class Initialized
INFO - 2026-03-14 07:18:52 --> Output Class Initialized
INFO - 2026-03-14 07:18:52 --> Security Class Initialized
DEBUG - 2026-03-14 07:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:18:52 --> CSRF cookie sent
INFO - 2026-03-14 07:18:52 --> Input Class Initialized
INFO - 2026-03-14 07:18:52 --> Language Class Initialized
INFO - 2026-03-14 07:18:52 --> Language Class Initialized
INFO - 2026-03-14 07:18:52 --> Config Class Initialized
INFO - 2026-03-14 07:18:52 --> Loader Class Initialized
INFO - 2026-03-14 07:18:52 --> Helper loaded: url_helper
INFO - 2026-03-14 07:18:52 --> Helper loaded: form_helper
INFO - 2026-03-14 07:18:52 --> Helper loaded: html_helper
INFO - 2026-03-14 07:18:52 --> Helper loaded: file_helper
INFO - 2026-03-14 07:18:52 --> Helper loaded: email_helper
INFO - 2026-03-14 07:18:52 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:18:52 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:18:52 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:18:52 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:18:52 --> Database Driver Class Initialized
INFO - 2026-03-14 07:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:18:54 --> Upload Class Initialized
DEBUG - 2026-03-14 07:18:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:18:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:18:54 --> Encryption Class Initialized
INFO - 2026-03-14 07:18:54 --> Form Validation Class Initialized
INFO - 2026-03-14 07:18:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:18:54 --> Pagination Class Initialized
INFO - 2026-03-14 07:18:54 --> Email Class Initialized
INFO - 2026-03-14 07:18:54 --> Controller Class Initialized
DEBUG - 2026-03-14 07:18:54 --> Service_product MX_Controller Initialized
INFO - 2026-03-14 07:18:54 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:18:54 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:18:54 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-14 07:18:54 --> Model "Common_model" initialized
DEBUG - 2026-03-14 07:18:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-14 07:18:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-14 07:18:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-14 07:18:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-14 07:18:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-14 07:18:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_list.php
INFO - 2026-03-14 07:18:54 --> Final output sent to browser
DEBUG - 2026-03-14 07:18:54 --> Total execution time: 2.3999
INFO - 2026-03-14 07:18:54 --> Config Class Initialized
INFO - 2026-03-14 07:18:54 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:18:54 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:18:54 --> Utf8 Class Initialized
INFO - 2026-03-14 07:18:54 --> URI Class Initialized
INFO - 2026-03-14 07:18:54 --> Router Class Initialized
INFO - 2026-03-14 07:18:54 --> Output Class Initialized
INFO - 2026-03-14 07:18:54 --> Security Class Initialized
DEBUG - 2026-03-14 07:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:18:54 --> CSRF cookie sent
INFO - 2026-03-14 07:18:54 --> Input Class Initialized
INFO - 2026-03-14 07:18:54 --> Language Class Initialized
INFO - 2026-03-14 07:18:54 --> Language Class Initialized
INFO - 2026-03-14 07:18:54 --> Config Class Initialized
INFO - 2026-03-14 07:18:54 --> Loader Class Initialized
INFO - 2026-03-14 07:18:54 --> Helper loaded: url_helper
INFO - 2026-03-14 07:18:54 --> Helper loaded: form_helper
INFO - 2026-03-14 07:18:54 --> Helper loaded: html_helper
INFO - 2026-03-14 07:18:54 --> Helper loaded: file_helper
INFO - 2026-03-14 07:18:54 --> Helper loaded: email_helper
INFO - 2026-03-14 07:18:54 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:18:54 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:18:54 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:18:54 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:18:54 --> Database Driver Class Initialized
INFO - 2026-03-14 07:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:18:57 --> Upload Class Initialized
DEBUG - 2026-03-14 07:18:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:18:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:18:57 --> Encryption Class Initialized
INFO - 2026-03-14 07:18:57 --> Form Validation Class Initialized
INFO - 2026-03-14 07:18:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:18:57 --> Pagination Class Initialized
INFO - 2026-03-14 07:18:57 --> Email Class Initialized
INFO - 2026-03-14 07:18:57 --> Controller Class Initialized
DEBUG - 2026-03-14 07:18:57 --> Service_product MX_Controller Initialized
INFO - 2026-03-14 07:18:57 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:18:57 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:18:57 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-14 07:18:57 --> Model "Common_model" initialized
INFO - 2026-03-14 07:19:04 --> Config Class Initialized
INFO - 2026-03-14 07:19:04 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:19:04 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:19:04 --> Utf8 Class Initialized
INFO - 2026-03-14 07:19:04 --> URI Class Initialized
INFO - 2026-03-14 07:19:04 --> Router Class Initialized
INFO - 2026-03-14 07:19:04 --> Output Class Initialized
INFO - 2026-03-14 07:19:04 --> Security Class Initialized
DEBUG - 2026-03-14 07:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:19:04 --> CSRF cookie sent
INFO - 2026-03-14 07:19:04 --> Input Class Initialized
INFO - 2026-03-14 07:19:04 --> Language Class Initialized
INFO - 2026-03-14 07:19:04 --> Language Class Initialized
INFO - 2026-03-14 07:19:04 --> Config Class Initialized
INFO - 2026-03-14 07:19:04 --> Loader Class Initialized
INFO - 2026-03-14 07:19:04 --> Helper loaded: url_helper
INFO - 2026-03-14 07:19:04 --> Helper loaded: form_helper
INFO - 2026-03-14 07:19:04 --> Helper loaded: html_helper
INFO - 2026-03-14 07:19:04 --> Helper loaded: file_helper
INFO - 2026-03-14 07:19:04 --> Helper loaded: email_helper
INFO - 2026-03-14 07:19:04 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:19:04 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:19:04 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:19:04 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:19:04 --> Database Driver Class Initialized
INFO - 2026-03-14 07:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:19:06 --> Upload Class Initialized
DEBUG - 2026-03-14 07:19:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:19:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:19:06 --> Encryption Class Initialized
INFO - 2026-03-14 07:19:06 --> Form Validation Class Initialized
INFO - 2026-03-14 07:19:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:19:06 --> Pagination Class Initialized
INFO - 2026-03-14 07:19:06 --> Email Class Initialized
INFO - 2026-03-14 07:19:06 --> Controller Class Initialized
DEBUG - 2026-03-14 07:19:06 --> Service_product MX_Controller Initialized
INFO - 2026-03-14 07:19:06 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:19:06 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:19:06 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-14 07:19:06 --> Model "Common_model" initialized
DEBUG - 2026-03-14 07:19:09 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-14 07:19:09 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-14 07:19:09 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-14 07:19:09 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-14 07:19:09 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-14 07:19:09 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_manage.php
INFO - 2026-03-14 07:19:09 --> Final output sent to browser
DEBUG - 2026-03-14 07:19:09 --> Total execution time: 5.2242
INFO - 2026-03-14 07:19:09 --> Config Class Initialized
INFO - 2026-03-14 07:19:09 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:19:09 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:19:09 --> Utf8 Class Initialized
INFO - 2026-03-14 07:19:09 --> URI Class Initialized
INFO - 2026-03-14 07:19:09 --> Router Class Initialized
INFO - 2026-03-14 07:19:09 --> Output Class Initialized
INFO - 2026-03-14 07:19:09 --> Security Class Initialized
DEBUG - 2026-03-14 07:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:19:09 --> CSRF cookie sent
INFO - 2026-03-14 07:19:09 --> Input Class Initialized
INFO - 2026-03-14 07:19:09 --> Language Class Initialized
INFO - 2026-03-14 07:19:09 --> Language Class Initialized
INFO - 2026-03-14 07:19:09 --> Config Class Initialized
INFO - 2026-03-14 07:19:09 --> Loader Class Initialized
INFO - 2026-03-14 07:19:09 --> Helper loaded: url_helper
INFO - 2026-03-14 07:19:09 --> Helper loaded: form_helper
INFO - 2026-03-14 07:19:09 --> Helper loaded: html_helper
INFO - 2026-03-14 07:19:09 --> Helper loaded: file_helper
INFO - 2026-03-14 07:19:09 --> Helper loaded: email_helper
INFO - 2026-03-14 07:19:09 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:19:09 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:19:09 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:19:09 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:19:09 --> Database Driver Class Initialized
INFO - 2026-03-14 07:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:19:11 --> Upload Class Initialized
DEBUG - 2026-03-14 07:19:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:19:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:19:11 --> Encryption Class Initialized
INFO - 2026-03-14 07:19:11 --> Form Validation Class Initialized
INFO - 2026-03-14 07:19:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:19:11 --> Pagination Class Initialized
INFO - 2026-03-14 07:19:11 --> Email Class Initialized
INFO - 2026-03-14 07:19:11 --> Controller Class Initialized
DEBUG - 2026-03-14 07:19:11 --> Service_product MX_Controller Initialized
INFO - 2026-03-14 07:19:11 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:19:11 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:19:11 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-14 07:19:11 --> Model "Common_model" initialized
INFO - 2026-03-14 07:19:25 --> Config Class Initialized
INFO - 2026-03-14 07:19:25 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:19:25 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:19:25 --> Utf8 Class Initialized
INFO - 2026-03-14 07:19:25 --> URI Class Initialized
INFO - 2026-03-14 07:19:25 --> Router Class Initialized
INFO - 2026-03-14 07:19:25 --> Output Class Initialized
INFO - 2026-03-14 07:19:25 --> Security Class Initialized
DEBUG - 2026-03-14 07:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:19:25 --> CSRF cookie sent
INFO - 2026-03-14 07:19:25 --> Input Class Initialized
INFO - 2026-03-14 07:19:25 --> Language Class Initialized
INFO - 2026-03-14 07:19:25 --> Language Class Initialized
INFO - 2026-03-14 07:19:25 --> Config Class Initialized
INFO - 2026-03-14 07:19:25 --> Loader Class Initialized
INFO - 2026-03-14 07:19:25 --> Helper loaded: url_helper
INFO - 2026-03-14 07:19:25 --> Helper loaded: form_helper
INFO - 2026-03-14 07:19:25 --> Helper loaded: html_helper
INFO - 2026-03-14 07:19:25 --> Helper loaded: file_helper
INFO - 2026-03-14 07:19:25 --> Helper loaded: email_helper
INFO - 2026-03-14 07:19:25 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:19:25 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:19:25 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:19:25 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:19:25 --> Database Driver Class Initialized
INFO - 2026-03-14 07:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:19:27 --> Upload Class Initialized
DEBUG - 2026-03-14 07:19:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:19:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:19:27 --> Encryption Class Initialized
INFO - 2026-03-14 07:19:27 --> Form Validation Class Initialized
INFO - 2026-03-14 07:19:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:19:27 --> Pagination Class Initialized
INFO - 2026-03-14 07:19:27 --> Email Class Initialized
INFO - 2026-03-14 07:19:27 --> Controller Class Initialized
DEBUG - 2026-03-14 07:19:27 --> Service_product MX_Controller Initialized
INFO - 2026-03-14 07:19:27 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:19:27 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:19:27 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-14 07:19:27 --> Model "Common_model" initialized
DEBUG - 2026-03-14 07:19:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-14 07:19:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-14 07:19:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-14 07:19:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-14 07:19:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-14 07:19:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_list.php
INFO - 2026-03-14 07:19:27 --> Final output sent to browser
DEBUG - 2026-03-14 07:19:27 --> Total execution time: 2.1990
INFO - 2026-03-14 07:19:27 --> Config Class Initialized
INFO - 2026-03-14 07:19:27 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:19:27 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:19:27 --> Utf8 Class Initialized
INFO - 2026-03-14 07:19:27 --> URI Class Initialized
INFO - 2026-03-14 07:19:27 --> Router Class Initialized
INFO - 2026-03-14 07:19:27 --> Output Class Initialized
INFO - 2026-03-14 07:19:27 --> Security Class Initialized
DEBUG - 2026-03-14 07:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:19:27 --> CSRF cookie sent
INFO - 2026-03-14 07:19:27 --> Input Class Initialized
INFO - 2026-03-14 07:19:27 --> Language Class Initialized
INFO - 2026-03-14 07:19:27 --> Language Class Initialized
INFO - 2026-03-14 07:19:27 --> Config Class Initialized
INFO - 2026-03-14 07:19:27 --> Loader Class Initialized
INFO - 2026-03-14 07:19:27 --> Helper loaded: url_helper
INFO - 2026-03-14 07:19:27 --> Helper loaded: form_helper
INFO - 2026-03-14 07:19:27 --> Helper loaded: html_helper
INFO - 2026-03-14 07:19:27 --> Helper loaded: file_helper
INFO - 2026-03-14 07:19:27 --> Helper loaded: email_helper
INFO - 2026-03-14 07:19:27 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:19:27 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:19:27 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:19:27 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:19:27 --> Database Driver Class Initialized
INFO - 2026-03-14 07:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:19:29 --> Upload Class Initialized
DEBUG - 2026-03-14 07:19:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:19:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:19:29 --> Encryption Class Initialized
INFO - 2026-03-14 07:19:29 --> Form Validation Class Initialized
INFO - 2026-03-14 07:19:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:19:29 --> Pagination Class Initialized
INFO - 2026-03-14 07:19:29 --> Email Class Initialized
INFO - 2026-03-14 07:19:29 --> Controller Class Initialized
DEBUG - 2026-03-14 07:19:29 --> Service_product MX_Controller Initialized
INFO - 2026-03-14 07:19:29 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:19:29 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:19:29 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-14 07:19:29 --> Model "Common_model" initialized
INFO - 2026-03-14 07:21:40 --> Config Class Initialized
INFO - 2026-03-14 07:21:40 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:21:40 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:21:40 --> Utf8 Class Initialized
INFO - 2026-03-14 07:21:40 --> URI Class Initialized
INFO - 2026-03-14 07:21:40 --> Router Class Initialized
INFO - 2026-03-14 07:21:40 --> Output Class Initialized
INFO - 2026-03-14 07:21:40 --> Security Class Initialized
DEBUG - 2026-03-14 07:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:21:40 --> CSRF cookie sent
INFO - 2026-03-14 07:21:40 --> Input Class Initialized
INFO - 2026-03-14 07:21:40 --> Language Class Initialized
INFO - 2026-03-14 07:21:40 --> Language Class Initialized
INFO - 2026-03-14 07:21:40 --> Config Class Initialized
INFO - 2026-03-14 07:21:40 --> Loader Class Initialized
INFO - 2026-03-14 07:21:40 --> Helper loaded: url_helper
INFO - 2026-03-14 07:21:40 --> Helper loaded: form_helper
INFO - 2026-03-14 07:21:40 --> Helper loaded: html_helper
INFO - 2026-03-14 07:21:40 --> Helper loaded: file_helper
INFO - 2026-03-14 07:21:40 --> Helper loaded: email_helper
INFO - 2026-03-14 07:21:40 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:21:40 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:21:40 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:21:40 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:21:40 --> Database Driver Class Initialized
INFO - 2026-03-14 07:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:21:42 --> Upload Class Initialized
DEBUG - 2026-03-14 07:21:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:21:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:21:42 --> Encryption Class Initialized
INFO - 2026-03-14 07:21:42 --> Form Validation Class Initialized
INFO - 2026-03-14 07:21:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:21:42 --> Pagination Class Initialized
INFO - 2026-03-14 07:21:42 --> Email Class Initialized
INFO - 2026-03-14 07:21:42 --> Controller Class Initialized
DEBUG - 2026-03-14 07:21:42 --> Domain_pricing MX_Controller Initialized
INFO - 2026-03-14 07:21:42 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:21:42 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:21:42 --> Model "Domainpricing_model" initialized
INFO - 2026-03-14 07:21:42 --> Model "Common_model" initialized
DEBUG - 2026-03-14 07:21:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-14 07:21:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-14 07:21:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-14 07:21:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-14 07:21:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-14 07:21:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/domain_pricing_list.php
INFO - 2026-03-14 07:21:43 --> Final output sent to browser
DEBUG - 2026-03-14 07:21:43 --> Total execution time: 3.5700
INFO - 2026-03-14 07:21:44 --> Config Class Initialized
INFO - 2026-03-14 07:21:44 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:21:44 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:21:44 --> Utf8 Class Initialized
INFO - 2026-03-14 07:21:44 --> URI Class Initialized
INFO - 2026-03-14 07:21:44 --> Router Class Initialized
INFO - 2026-03-14 07:21:44 --> Output Class Initialized
INFO - 2026-03-14 07:21:44 --> Security Class Initialized
DEBUG - 2026-03-14 07:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:21:44 --> CSRF cookie sent
INFO - 2026-03-14 07:21:44 --> Input Class Initialized
INFO - 2026-03-14 07:21:44 --> Language Class Initialized
INFO - 2026-03-14 07:21:44 --> Language Class Initialized
INFO - 2026-03-14 07:21:44 --> Config Class Initialized
INFO - 2026-03-14 07:21:44 --> Loader Class Initialized
INFO - 2026-03-14 07:21:44 --> Helper loaded: url_helper
INFO - 2026-03-14 07:21:44 --> Helper loaded: form_helper
INFO - 2026-03-14 07:21:44 --> Helper loaded: html_helper
INFO - 2026-03-14 07:21:44 --> Helper loaded: file_helper
INFO - 2026-03-14 07:21:44 --> Helper loaded: email_helper
INFO - 2026-03-14 07:21:44 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:21:44 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:21:44 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:21:44 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:21:44 --> Database Driver Class Initialized
INFO - 2026-03-14 07:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:21:46 --> Upload Class Initialized
DEBUG - 2026-03-14 07:21:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:21:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:21:46 --> Encryption Class Initialized
INFO - 2026-03-14 07:21:46 --> Form Validation Class Initialized
INFO - 2026-03-14 07:21:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:21:46 --> Pagination Class Initialized
INFO - 2026-03-14 07:21:46 --> Email Class Initialized
INFO - 2026-03-14 07:21:46 --> Controller Class Initialized
DEBUG - 2026-03-14 07:21:46 --> Domain_pricing MX_Controller Initialized
INFO - 2026-03-14 07:21:46 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:21:46 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:21:46 --> Model "Domainpricing_model" initialized
INFO - 2026-03-14 07:21:46 --> Model "Common_model" initialized
INFO - 2026-03-14 07:22:48 --> Config Class Initialized
INFO - 2026-03-14 07:22:48 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:22:48 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:22:48 --> Utf8 Class Initialized
INFO - 2026-03-14 07:22:48 --> URI Class Initialized
INFO - 2026-03-14 07:22:48 --> Router Class Initialized
INFO - 2026-03-14 07:22:48 --> Output Class Initialized
INFO - 2026-03-14 07:22:48 --> Security Class Initialized
DEBUG - 2026-03-14 07:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:22:48 --> CSRF cookie sent
INFO - 2026-03-14 07:22:48 --> Input Class Initialized
INFO - 2026-03-14 07:22:48 --> Language Class Initialized
INFO - 2026-03-14 07:22:48 --> Language Class Initialized
INFO - 2026-03-14 07:22:48 --> Config Class Initialized
INFO - 2026-03-14 07:22:48 --> Loader Class Initialized
INFO - 2026-03-14 07:22:48 --> Helper loaded: url_helper
INFO - 2026-03-14 07:22:48 --> Helper loaded: form_helper
INFO - 2026-03-14 07:22:48 --> Helper loaded: html_helper
INFO - 2026-03-14 07:22:48 --> Helper loaded: file_helper
INFO - 2026-03-14 07:22:48 --> Helper loaded: email_helper
INFO - 2026-03-14 07:22:48 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:22:48 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:22:48 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:22:48 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:22:48 --> Database Driver Class Initialized
INFO - 2026-03-14 07:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:22:50 --> Upload Class Initialized
DEBUG - 2026-03-14 07:22:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:22:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:22:50 --> Encryption Class Initialized
INFO - 2026-03-14 07:22:50 --> Form Validation Class Initialized
INFO - 2026-03-14 07:22:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:22:50 --> Pagination Class Initialized
INFO - 2026-03-14 07:22:50 --> Email Class Initialized
INFO - 2026-03-14 07:22:50 --> Controller Class Initialized
DEBUG - 2026-03-14 07:22:50 --> Invoice MX_Controller Initialized
INFO - 2026-03-14 07:22:50 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:22:50 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:22:50 --> Model "Billing_model" initialized
INFO - 2026-03-14 07:22:50 --> Model "Common_model" initialized
INFO - 2026-03-14 07:22:50 --> Model "Invoice_model" initialized
INFO - 2026-03-14 07:22:50 --> Model "Appsetting_model" initialized
DEBUG - 2026-03-14 07:22:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-14 07:22:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-14 07:22:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-14 07:22:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-14 07:22:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-14 07:22:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/invoice_list.php
INFO - 2026-03-14 07:22:50 --> Final output sent to browser
DEBUG - 2026-03-14 07:22:50 --> Total execution time: 2.7621
INFO - 2026-03-14 07:22:50 --> Config Class Initialized
INFO - 2026-03-14 07:22:50 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:22:50 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:22:50 --> Utf8 Class Initialized
INFO - 2026-03-14 07:22:50 --> URI Class Initialized
INFO - 2026-03-14 07:22:50 --> Router Class Initialized
INFO - 2026-03-14 07:22:50 --> Output Class Initialized
INFO - 2026-03-14 07:22:50 --> Security Class Initialized
DEBUG - 2026-03-14 07:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:22:50 --> CSRF cookie sent
INFO - 2026-03-14 07:22:50 --> Input Class Initialized
INFO - 2026-03-14 07:22:50 --> Language Class Initialized
INFO - 2026-03-14 07:22:50 --> Language Class Initialized
INFO - 2026-03-14 07:22:50 --> Config Class Initialized
INFO - 2026-03-14 07:22:50 --> Loader Class Initialized
INFO - 2026-03-14 07:22:51 --> Helper loaded: url_helper
INFO - 2026-03-14 07:22:51 --> Helper loaded: form_helper
INFO - 2026-03-14 07:22:51 --> Helper loaded: html_helper
INFO - 2026-03-14 07:22:51 --> Helper loaded: file_helper
INFO - 2026-03-14 07:22:51 --> Helper loaded: email_helper
INFO - 2026-03-14 07:22:51 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:22:51 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:22:51 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:22:51 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:22:51 --> Database Driver Class Initialized
INFO - 2026-03-14 07:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:22:52 --> Upload Class Initialized
DEBUG - 2026-03-14 07:22:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:22:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:22:52 --> Encryption Class Initialized
INFO - 2026-03-14 07:22:52 --> Form Validation Class Initialized
INFO - 2026-03-14 07:22:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:22:52 --> Pagination Class Initialized
INFO - 2026-03-14 07:22:52 --> Email Class Initialized
INFO - 2026-03-14 07:22:52 --> Controller Class Initialized
DEBUG - 2026-03-14 07:22:52 --> Invoice MX_Controller Initialized
INFO - 2026-03-14 07:22:52 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:22:52 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:22:52 --> Model "Billing_model" initialized
INFO - 2026-03-14 07:22:52 --> Model "Common_model" initialized
INFO - 2026-03-14 07:22:52 --> Model "Invoice_model" initialized
INFO - 2026-03-14 07:22:52 --> Model "Appsetting_model" initialized
INFO - 2026-03-14 07:23:41 --> Config Class Initialized
INFO - 2026-03-14 07:23:41 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:23:41 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:23:41 --> Utf8 Class Initialized
INFO - 2026-03-14 07:23:41 --> URI Class Initialized
INFO - 2026-03-14 07:23:41 --> Router Class Initialized
INFO - 2026-03-14 07:23:41 --> Output Class Initialized
INFO - 2026-03-14 07:23:41 --> Security Class Initialized
DEBUG - 2026-03-14 07:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:23:41 --> CSRF cookie sent
INFO - 2026-03-14 07:23:41 --> Input Class Initialized
INFO - 2026-03-14 07:23:41 --> Language Class Initialized
INFO - 2026-03-14 07:23:41 --> Language Class Initialized
INFO - 2026-03-14 07:23:41 --> Config Class Initialized
INFO - 2026-03-14 07:23:41 --> Loader Class Initialized
INFO - 2026-03-14 07:23:41 --> Helper loaded: url_helper
INFO - 2026-03-14 07:23:41 --> Helper loaded: form_helper
INFO - 2026-03-14 07:23:41 --> Helper loaded: html_helper
INFO - 2026-03-14 07:23:41 --> Helper loaded: file_helper
INFO - 2026-03-14 07:23:41 --> Helper loaded: email_helper
INFO - 2026-03-14 07:23:41 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:23:41 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:23:41 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:23:41 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:23:41 --> Database Driver Class Initialized
INFO - 2026-03-14 07:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:23:43 --> Upload Class Initialized
DEBUG - 2026-03-14 07:23:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:23:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:23:43 --> Encryption Class Initialized
INFO - 2026-03-14 07:23:43 --> Form Validation Class Initialized
INFO - 2026-03-14 07:23:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:23:43 --> Pagination Class Initialized
INFO - 2026-03-14 07:23:43 --> Email Class Initialized
INFO - 2026-03-14 07:23:43 --> Controller Class Initialized
DEBUG - 2026-03-14 07:23:43 --> Paymentgateway MX_Controller Initialized
INFO - 2026-03-14 07:23:43 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:23:43 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:23:43 --> Model "PaymentGateway_model" initialized
INFO - 2026-03-14 07:23:43 --> Model "Payment_model" initialized
DEBUG - 2026-03-14 07:23:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-14 07:23:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-14 07:23:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-14 07:23:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-14 07:23:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-14 07:23:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/paymentgateway_transactions.php
INFO - 2026-03-14 07:23:44 --> Final output sent to browser
DEBUG - 2026-03-14 07:23:44 --> Total execution time: 2.7666
INFO - 2026-03-14 07:23:44 --> Config Class Initialized
INFO - 2026-03-14 07:23:44 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:23:44 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:23:44 --> Utf8 Class Initialized
INFO - 2026-03-14 07:23:44 --> URI Class Initialized
INFO - 2026-03-14 07:23:44 --> Router Class Initialized
INFO - 2026-03-14 07:23:44 --> Output Class Initialized
INFO - 2026-03-14 07:23:44 --> Security Class Initialized
DEBUG - 2026-03-14 07:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:23:44 --> CSRF cookie sent
INFO - 2026-03-14 07:23:44 --> Input Class Initialized
INFO - 2026-03-14 07:23:44 --> Language Class Initialized
INFO - 2026-03-14 07:23:44 --> Language Class Initialized
INFO - 2026-03-14 07:23:44 --> Config Class Initialized
INFO - 2026-03-14 07:23:44 --> Loader Class Initialized
INFO - 2026-03-14 07:23:44 --> Helper loaded: url_helper
INFO - 2026-03-14 07:23:44 --> Helper loaded: form_helper
INFO - 2026-03-14 07:23:44 --> Helper loaded: html_helper
INFO - 2026-03-14 07:23:44 --> Helper loaded: file_helper
INFO - 2026-03-14 07:23:44 --> Helper loaded: email_helper
INFO - 2026-03-14 07:23:44 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:23:44 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:23:44 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:23:44 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:23:44 --> Database Driver Class Initialized
INFO - 2026-03-14 07:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:23:47 --> Upload Class Initialized
DEBUG - 2026-03-14 07:23:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:23:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:23:47 --> Encryption Class Initialized
INFO - 2026-03-14 07:23:47 --> Form Validation Class Initialized
INFO - 2026-03-14 07:23:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:23:47 --> Pagination Class Initialized
INFO - 2026-03-14 07:23:47 --> Email Class Initialized
INFO - 2026-03-14 07:23:47 --> Controller Class Initialized
DEBUG - 2026-03-14 07:23:47 --> Paymentgateway MX_Controller Initialized
INFO - 2026-03-14 07:23:47 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:23:47 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:23:47 --> Model "PaymentGateway_model" initialized
INFO - 2026-03-14 07:23:47 --> Model "Payment_model" initialized
INFO - 2026-03-14 07:23:49 --> Final output sent to browser
DEBUG - 2026-03-14 07:23:49 --> Total execution time: 4.8431
INFO - 2026-03-14 07:24:53 --> Config Class Initialized
INFO - 2026-03-14 07:24:53 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:24:53 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:24:53 --> Utf8 Class Initialized
INFO - 2026-03-14 07:24:53 --> URI Class Initialized
INFO - 2026-03-14 07:24:53 --> Router Class Initialized
INFO - 2026-03-14 07:24:53 --> Output Class Initialized
INFO - 2026-03-14 07:24:53 --> Security Class Initialized
DEBUG - 2026-03-14 07:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:24:53 --> CSRF cookie sent
INFO - 2026-03-14 07:24:53 --> Input Class Initialized
INFO - 2026-03-14 07:24:53 --> Language Class Initialized
INFO - 2026-03-14 07:24:53 --> Language Class Initialized
INFO - 2026-03-14 07:24:53 --> Config Class Initialized
INFO - 2026-03-14 07:24:53 --> Loader Class Initialized
INFO - 2026-03-14 07:24:53 --> Helper loaded: url_helper
INFO - 2026-03-14 07:24:53 --> Helper loaded: form_helper
INFO - 2026-03-14 07:24:53 --> Helper loaded: html_helper
INFO - 2026-03-14 07:24:53 --> Helper loaded: file_helper
INFO - 2026-03-14 07:24:53 --> Helper loaded: email_helper
INFO - 2026-03-14 07:24:53 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:24:53 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:24:53 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:24:53 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:24:53 --> Database Driver Class Initialized
INFO - 2026-03-14 07:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:24:55 --> Upload Class Initialized
DEBUG - 2026-03-14 07:24:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:24:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:24:55 --> Encryption Class Initialized
INFO - 2026-03-14 07:24:55 --> Form Validation Class Initialized
INFO - 2026-03-14 07:24:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:24:55 --> Pagination Class Initialized
INFO - 2026-03-14 07:24:55 --> Email Class Initialized
INFO - 2026-03-14 07:24:55 --> Controller Class Initialized
DEBUG - 2026-03-14 07:24:55 --> Ticket MX_Controller Initialized
INFO - 2026-03-14 07:24:55 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:24:55 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:24:55 --> Model "Support_model" initialized
INFO - 2026-03-14 07:24:55 --> Model "Common_model" initialized
DEBUG - 2026-03-14 07:24:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-14 07:24:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-14 07:24:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-14 07:24:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-14 07:24:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-14 07:24:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/ticket_list.php
INFO - 2026-03-14 07:24:56 --> Final output sent to browser
DEBUG - 2026-03-14 07:24:56 --> Total execution time: 2.9589
INFO - 2026-03-14 07:24:56 --> Config Class Initialized
INFO - 2026-03-14 07:24:56 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:24:56 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:24:56 --> Utf8 Class Initialized
INFO - 2026-03-14 07:24:56 --> URI Class Initialized
INFO - 2026-03-14 07:24:56 --> Router Class Initialized
INFO - 2026-03-14 07:24:56 --> Output Class Initialized
INFO - 2026-03-14 07:24:56 --> Security Class Initialized
DEBUG - 2026-03-14 07:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:24:56 --> CSRF cookie sent
INFO - 2026-03-14 07:24:56 --> Input Class Initialized
INFO - 2026-03-14 07:24:56 --> Language Class Initialized
INFO - 2026-03-14 07:24:56 --> Language Class Initialized
INFO - 2026-03-14 07:24:56 --> Config Class Initialized
INFO - 2026-03-14 07:24:56 --> Loader Class Initialized
INFO - 2026-03-14 07:24:56 --> Helper loaded: url_helper
INFO - 2026-03-14 07:24:56 --> Helper loaded: form_helper
INFO - 2026-03-14 07:24:56 --> Helper loaded: html_helper
INFO - 2026-03-14 07:24:56 --> Helper loaded: file_helper
INFO - 2026-03-14 07:24:56 --> Helper loaded: email_helper
INFO - 2026-03-14 07:24:56 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:24:56 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:24:56 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:24:56 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:24:56 --> Database Driver Class Initialized
INFO - 2026-03-14 07:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:24:58 --> Upload Class Initialized
DEBUG - 2026-03-14 07:24:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:24:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:24:58 --> Encryption Class Initialized
INFO - 2026-03-14 07:24:58 --> Form Validation Class Initialized
INFO - 2026-03-14 07:24:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:24:58 --> Pagination Class Initialized
INFO - 2026-03-14 07:24:58 --> Email Class Initialized
INFO - 2026-03-14 07:24:58 --> Controller Class Initialized
DEBUG - 2026-03-14 07:24:58 --> Ticket MX_Controller Initialized
INFO - 2026-03-14 07:24:58 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:24:58 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:24:58 --> Model "Support_model" initialized
INFO - 2026-03-14 07:24:58 --> Model "Common_model" initialized
INFO - 2026-03-14 07:25:55 --> Config Class Initialized
INFO - 2026-03-14 07:25:55 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:25:55 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:25:55 --> Utf8 Class Initialized
INFO - 2026-03-14 07:25:55 --> URI Class Initialized
INFO - 2026-03-14 07:25:55 --> Router Class Initialized
INFO - 2026-03-14 07:25:55 --> Output Class Initialized
INFO - 2026-03-14 07:25:55 --> Security Class Initialized
DEBUG - 2026-03-14 07:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:25:55 --> CSRF cookie sent
INFO - 2026-03-14 07:25:55 --> Input Class Initialized
INFO - 2026-03-14 07:25:55 --> Language Class Initialized
INFO - 2026-03-14 07:25:55 --> Language Class Initialized
INFO - 2026-03-14 07:25:55 --> Config Class Initialized
INFO - 2026-03-14 07:25:55 --> Loader Class Initialized
INFO - 2026-03-14 07:25:55 --> Helper loaded: url_helper
INFO - 2026-03-14 07:25:55 --> Helper loaded: form_helper
INFO - 2026-03-14 07:25:55 --> Helper loaded: html_helper
INFO - 2026-03-14 07:25:55 --> Helper loaded: file_helper
INFO - 2026-03-14 07:25:55 --> Helper loaded: email_helper
INFO - 2026-03-14 07:25:55 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:25:55 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:25:55 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:25:55 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:25:55 --> Database Driver Class Initialized
INFO - 2026-03-14 07:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:25:57 --> Upload Class Initialized
DEBUG - 2026-03-14 07:25:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:25:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:25:57 --> Encryption Class Initialized
INFO - 2026-03-14 07:25:57 --> Form Validation Class Initialized
INFO - 2026-03-14 07:25:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:25:57 --> Pagination Class Initialized
INFO - 2026-03-14 07:25:57 --> Email Class Initialized
INFO - 2026-03-14 07:25:57 --> Controller Class Initialized
DEBUG - 2026-03-14 07:25:57 --> Kb MX_Controller Initialized
INFO - 2026-03-14 07:25:57 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:25:57 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:25:57 --> Model "Kb_model" initialized
INFO - 2026-03-14 07:25:57 --> Model "Kbcat_model" initialized
DEBUG - 2026-03-14 07:25:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-14 07:25:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-14 07:25:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-14 07:25:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-14 07:25:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-14 07:25:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/kb_list.php
INFO - 2026-03-14 07:25:58 --> Final output sent to browser
DEBUG - 2026-03-14 07:25:58 --> Total execution time: 2.5918
INFO - 2026-03-14 07:25:58 --> Config Class Initialized
INFO - 2026-03-14 07:25:58 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:25:58 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:25:58 --> Utf8 Class Initialized
INFO - 2026-03-14 07:25:58 --> URI Class Initialized
INFO - 2026-03-14 07:25:58 --> Router Class Initialized
INFO - 2026-03-14 07:25:58 --> Output Class Initialized
INFO - 2026-03-14 07:25:58 --> Security Class Initialized
DEBUG - 2026-03-14 07:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:25:58 --> CSRF cookie sent
INFO - 2026-03-14 07:25:58 --> Input Class Initialized
INFO - 2026-03-14 07:25:58 --> Language Class Initialized
INFO - 2026-03-14 07:25:58 --> Language Class Initialized
INFO - 2026-03-14 07:25:58 --> Config Class Initialized
INFO - 2026-03-14 07:25:58 --> Loader Class Initialized
INFO - 2026-03-14 07:25:58 --> Helper loaded: url_helper
INFO - 2026-03-14 07:25:58 --> Helper loaded: form_helper
INFO - 2026-03-14 07:25:58 --> Helper loaded: html_helper
INFO - 2026-03-14 07:25:58 --> Helper loaded: file_helper
INFO - 2026-03-14 07:25:58 --> Helper loaded: email_helper
INFO - 2026-03-14 07:25:58 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:25:58 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:25:58 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:25:58 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:25:58 --> Database Driver Class Initialized
INFO - 2026-03-14 07:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:26:00 --> Upload Class Initialized
DEBUG - 2026-03-14 07:26:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:26:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:26:00 --> Encryption Class Initialized
INFO - 2026-03-14 07:26:00 --> Form Validation Class Initialized
INFO - 2026-03-14 07:26:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:26:00 --> Pagination Class Initialized
INFO - 2026-03-14 07:26:00 --> Email Class Initialized
INFO - 2026-03-14 07:26:00 --> Controller Class Initialized
DEBUG - 2026-03-14 07:26:00 --> Kb MX_Controller Initialized
INFO - 2026-03-14 07:26:00 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:26:00 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:26:00 --> Model "Kb_model" initialized
INFO - 2026-03-14 07:26:00 --> Model "Kbcat_model" initialized
INFO - 2026-03-14 07:26:05 --> Config Class Initialized
INFO - 2026-03-14 07:26:05 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:26:05 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:26:05 --> Utf8 Class Initialized
INFO - 2026-03-14 07:26:05 --> URI Class Initialized
INFO - 2026-03-14 07:26:05 --> Router Class Initialized
INFO - 2026-03-14 07:26:05 --> Output Class Initialized
INFO - 2026-03-14 07:26:05 --> Security Class Initialized
DEBUG - 2026-03-14 07:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:26:05 --> CSRF cookie sent
INFO - 2026-03-14 07:26:05 --> Input Class Initialized
INFO - 2026-03-14 07:26:05 --> Language Class Initialized
INFO - 2026-03-14 07:26:05 --> Language Class Initialized
INFO - 2026-03-14 07:26:05 --> Config Class Initialized
INFO - 2026-03-14 07:26:05 --> Loader Class Initialized
INFO - 2026-03-14 07:26:05 --> Helper loaded: url_helper
INFO - 2026-03-14 07:26:05 --> Helper loaded: form_helper
INFO - 2026-03-14 07:26:05 --> Helper loaded: html_helper
INFO - 2026-03-14 07:26:05 --> Helper loaded: file_helper
INFO - 2026-03-14 07:26:05 --> Helper loaded: email_helper
INFO - 2026-03-14 07:26:05 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:26:05 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:26:05 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:26:05 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:26:05 --> Database Driver Class Initialized
INFO - 2026-03-14 07:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:26:07 --> Upload Class Initialized
DEBUG - 2026-03-14 07:26:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:26:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:26:07 --> Encryption Class Initialized
INFO - 2026-03-14 07:26:07 --> Form Validation Class Initialized
INFO - 2026-03-14 07:26:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:26:07 --> Pagination Class Initialized
INFO - 2026-03-14 07:26:07 --> Email Class Initialized
INFO - 2026-03-14 07:26:07 --> Controller Class Initialized
DEBUG - 2026-03-14 07:26:07 --> Kb MX_Controller Initialized
INFO - 2026-03-14 07:26:07 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:26:07 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:26:07 --> Model "Kb_model" initialized
INFO - 2026-03-14 07:26:07 --> Model "Kbcat_model" initialized
DEBUG - 2026-03-14 07:26:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-14 07:26:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-14 07:26:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-14 07:26:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-14 07:26:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-14 07:26:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/kb_manage.php
INFO - 2026-03-14 07:26:08 --> Final output sent to browser
DEBUG - 2026-03-14 07:26:08 --> Total execution time: 3.2441
INFO - 2026-03-14 07:31:51 --> Config Class Initialized
INFO - 2026-03-14 07:31:51 --> Hooks Class Initialized
DEBUG - 2026-03-14 07:31:51 --> UTF-8 Support Enabled
INFO - 2026-03-14 07:31:51 --> Utf8 Class Initialized
INFO - 2026-03-14 07:31:51 --> URI Class Initialized
INFO - 2026-03-14 07:31:51 --> Router Class Initialized
INFO - 2026-03-14 07:31:51 --> Output Class Initialized
INFO - 2026-03-14 07:31:51 --> Security Class Initialized
DEBUG - 2026-03-14 07:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-14 07:31:51 --> CSRF cookie sent
INFO - 2026-03-14 07:31:51 --> Input Class Initialized
INFO - 2026-03-14 07:31:51 --> Language Class Initialized
INFO - 2026-03-14 07:31:51 --> Language Class Initialized
INFO - 2026-03-14 07:31:51 --> Config Class Initialized
INFO - 2026-03-14 07:31:51 --> Loader Class Initialized
INFO - 2026-03-14 07:31:51 --> Helper loaded: url_helper
INFO - 2026-03-14 07:31:51 --> Helper loaded: form_helper
INFO - 2026-03-14 07:31:51 --> Helper loaded: html_helper
INFO - 2026-03-14 07:31:51 --> Helper loaded: file_helper
INFO - 2026-03-14 07:31:51 --> Helper loaded: email_helper
INFO - 2026-03-14 07:31:51 --> Helper loaded: whmaz_helper
INFO - 2026-03-14 07:31:51 --> Helper loaded: ssp_helper
INFO - 2026-03-14 07:31:51 --> Helper loaded: cpanel_helper
INFO - 2026-03-14 07:31:51 --> Helper loaded: domain_helper
INFO - 2026-03-14 07:31:51 --> Database Driver Class Initialized
INFO - 2026-03-14 07:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-14 07:31:53 --> Upload Class Initialized
DEBUG - 2026-03-14 07:31:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-14 07:31:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-14 07:31:53 --> Encryption Class Initialized
INFO - 2026-03-14 07:31:53 --> Form Validation Class Initialized
INFO - 2026-03-14 07:31:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-14 07:31:53 --> Pagination Class Initialized
INFO - 2026-03-14 07:31:53 --> Email Class Initialized
INFO - 2026-03-14 07:31:53 --> Controller Class Initialized
DEBUG - 2026-03-14 07:31:53 --> Authenticate MX_Controller Initialized
INFO - 2026-03-14 07:31:53 --> Model "Loginattempt_model" initialized
INFO - 2026-03-14 07:31:53 --> Model "Adminauth_model" initialized
INFO - 2026-03-14 07:31:53 --> Model "Appsetting_model" initialized
DEBUG - 2026-03-14 07:31:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-14 07:31:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-14 07:31:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-03-14 07:31:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-14 07:31:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-14 07:31:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-03-14 07:31:54 --> Final output sent to browser
DEBUG - 2026-03-14 07:31:54 --> Total execution time: 2.4494

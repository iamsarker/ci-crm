<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-08-18 15:13:24 --> Config Class Initialized
INFO - 2026-08-18 15:13:24 --> Hooks Class Initialized
DEBUG - 2026-08-18 15:13:24 --> UTF-8 Support Enabled
INFO - 2026-08-18 15:13:24 --> Utf8 Class Initialized
INFO - 2026-08-18 15:13:24 --> URI Class Initialized
DEBUG - 2026-08-18 15:13:24 --> No URI present. Default controller set.
INFO - 2026-08-18 15:13:24 --> Router Class Initialized
INFO - 2026-08-18 15:13:24 --> Output Class Initialized
INFO - 2026-08-18 15:13:24 --> Security Class Initialized
DEBUG - 2026-08-18 15:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 15:13:24 --> CSRF cookie sent
INFO - 2026-08-18 15:13:24 --> Input Class Initialized
INFO - 2026-08-18 15:13:24 --> Language Class Initialized
INFO - 2026-08-18 15:13:24 --> Language Class Initialized
INFO - 2026-08-18 15:13:24 --> Config Class Initialized
INFO - 2026-08-18 15:13:24 --> Loader Class Initialized
INFO - 2026-08-18 15:13:24 --> Helper loaded: url_helper
INFO - 2026-08-18 15:13:24 --> Helper loaded: form_helper
INFO - 2026-08-18 15:13:24 --> Helper loaded: html_helper
INFO - 2026-08-18 15:13:24 --> Helper loaded: file_helper
INFO - 2026-08-18 15:13:24 --> Helper loaded: email_helper
INFO - 2026-08-18 15:13:24 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 15:13:24 --> Helper loaded: ssp_helper
INFO - 2026-08-18 15:13:24 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 15:13:24 --> Helper loaded: plesk_helper
INFO - 2026-08-18 15:13:24 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 15:13:24 --> Helper loaded: domain_helper
INFO - 2026-08-18 15:13:24 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 15:13:24 --> Database Driver Class Initialized
INFO - 2026-08-18 15:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 15:13:26 --> Upload Class Initialized
DEBUG - 2026-08-18 15:13:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 15:13:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 15:13:26 --> Encryption Class Initialized
INFO - 2026-08-18 15:13:26 --> Form Validation Class Initialized
INFO - 2026-08-18 15:13:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 15:13:26 --> Pagination Class Initialized
INFO - 2026-08-18 15:13:26 --> Email Class Initialized
INFO - 2026-08-18 15:13:26 --> Controller Class Initialized
DEBUG - 2026-08-18 15:13:26 --> Home MX_Controller Initialized
INFO - 2026-08-18 15:13:26 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 15:13:26 --> Model "Auth_model" initialized
INFO - 2026-08-18 15:13:26 --> Model "Cart_model" initialized
DEBUG - 2026-08-18 15:13:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-18 15:13:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-18 15:13:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-18 15:13:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/home/views/home_view.php
INFO - 2026-08-18 15:13:28 --> Final output sent to browser
DEBUG - 2026-08-18 15:13:28 --> Total execution time: 3.2617
INFO - 2026-08-18 15:13:36 --> Config Class Initialized
INFO - 2026-08-18 15:13:36 --> Hooks Class Initialized
DEBUG - 2026-08-18 15:13:36 --> UTF-8 Support Enabled
INFO - 2026-08-18 15:13:36 --> Utf8 Class Initialized
INFO - 2026-08-18 15:13:36 --> URI Class Initialized
INFO - 2026-08-18 15:13:36 --> Router Class Initialized
INFO - 2026-08-18 15:13:36 --> Output Class Initialized
INFO - 2026-08-18 15:13:36 --> Security Class Initialized
DEBUG - 2026-08-18 15:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 15:13:36 --> CSRF cookie sent
INFO - 2026-08-18 15:13:36 --> Input Class Initialized
INFO - 2026-08-18 15:13:36 --> Language Class Initialized
INFO - 2026-08-18 15:13:36 --> Language Class Initialized
INFO - 2026-08-18 15:13:36 --> Config Class Initialized
INFO - 2026-08-18 15:13:36 --> Loader Class Initialized
INFO - 2026-08-18 15:13:36 --> Helper loaded: url_helper
INFO - 2026-08-18 15:13:36 --> Helper loaded: form_helper
INFO - 2026-08-18 15:13:36 --> Helper loaded: html_helper
INFO - 2026-08-18 15:13:36 --> Helper loaded: file_helper
INFO - 2026-08-18 15:13:36 --> Helper loaded: email_helper
INFO - 2026-08-18 15:13:36 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 15:13:36 --> Helper loaded: ssp_helper
INFO - 2026-08-18 15:13:36 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 15:13:36 --> Helper loaded: plesk_helper
INFO - 2026-08-18 15:13:36 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 15:13:36 --> Helper loaded: domain_helper
INFO - 2026-08-18 15:13:36 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 15:13:36 --> Database Driver Class Initialized
INFO - 2026-08-18 15:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 15:13:38 --> Upload Class Initialized
DEBUG - 2026-08-18 15:13:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 15:13:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 15:13:38 --> Encryption Class Initialized
INFO - 2026-08-18 15:13:38 --> Form Validation Class Initialized
INFO - 2026-08-18 15:13:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 15:13:38 --> Pagination Class Initialized
INFO - 2026-08-18 15:13:38 --> Email Class Initialized
INFO - 2026-08-18 15:13:38 --> Controller Class Initialized
DEBUG - 2026-08-18 15:13:38 --> Invoicing MX_Controller Initialized
INFO - 2026-08-18 15:13:38 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 15:13:38 --> Model "Auth_model" initialized
INFO - 2026-08-18 15:13:38 --> Model "Cart_model" initialized
INFO - 2026-08-18 15:13:39 --> Model "Billing_model" initialized
INFO - 2026-08-18 15:13:39 --> Model "Common_model" initialized
INFO - 2026-08-18 15:13:39 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 15:13:39 --> Config Class Initialized
INFO - 2026-08-18 15:13:39 --> Hooks Class Initialized
DEBUG - 2026-08-18 15:13:39 --> UTF-8 Support Enabled
INFO - 2026-08-18 15:13:39 --> Utf8 Class Initialized
INFO - 2026-08-18 15:13:39 --> URI Class Initialized
INFO - 2026-08-18 15:13:39 --> Router Class Initialized
INFO - 2026-08-18 15:13:39 --> Output Class Initialized
INFO - 2026-08-18 15:13:39 --> Security Class Initialized
DEBUG - 2026-08-18 15:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 15:13:39 --> CSRF cookie sent
INFO - 2026-08-18 15:13:39 --> Input Class Initialized
INFO - 2026-08-18 15:13:39 --> Language Class Initialized
INFO - 2026-08-18 15:13:39 --> Language Class Initialized
INFO - 2026-08-18 15:13:39 --> Config Class Initialized
INFO - 2026-08-18 15:13:39 --> Loader Class Initialized
INFO - 2026-08-18 15:13:39 --> Helper loaded: url_helper
INFO - 2026-08-18 15:13:39 --> Helper loaded: form_helper
INFO - 2026-08-18 15:13:39 --> Helper loaded: html_helper
INFO - 2026-08-18 15:13:39 --> Helper loaded: file_helper
INFO - 2026-08-18 15:13:39 --> Helper loaded: email_helper
INFO - 2026-08-18 15:13:39 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 15:13:39 --> Helper loaded: ssp_helper
INFO - 2026-08-18 15:13:39 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 15:13:39 --> Helper loaded: plesk_helper
INFO - 2026-08-18 15:13:39 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 15:13:39 --> Helper loaded: domain_helper
INFO - 2026-08-18 15:13:39 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 15:13:39 --> Database Driver Class Initialized
INFO - 2026-08-18 15:13:40 --> Config Class Initialized
INFO - 2026-08-18 15:13:40 --> Hooks Class Initialized
DEBUG - 2026-08-18 15:13:40 --> UTF-8 Support Enabled
INFO - 2026-08-18 15:13:40 --> Utf8 Class Initialized
INFO - 2026-08-18 15:13:40 --> URI Class Initialized
INFO - 2026-08-18 15:13:40 --> Router Class Initialized
INFO - 2026-08-18 15:13:40 --> Output Class Initialized
INFO - 2026-08-18 15:13:40 --> Security Class Initialized
DEBUG - 2026-08-18 15:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 15:13:40 --> CSRF cookie sent
INFO - 2026-08-18 15:13:40 --> Input Class Initialized
INFO - 2026-08-18 15:13:40 --> Language Class Initialized
INFO - 2026-08-18 15:13:40 --> Language Class Initialized
INFO - 2026-08-18 15:13:40 --> Config Class Initialized
INFO - 2026-08-18 15:13:40 --> Loader Class Initialized
INFO - 2026-08-18 15:13:40 --> Helper loaded: url_helper
INFO - 2026-08-18 15:13:40 --> Helper loaded: form_helper
INFO - 2026-08-18 15:13:40 --> Helper loaded: html_helper
INFO - 2026-08-18 15:13:40 --> Helper loaded: file_helper
INFO - 2026-08-18 15:13:40 --> Helper loaded: email_helper
INFO - 2026-08-18 15:13:40 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 15:13:40 --> Helper loaded: ssp_helper
INFO - 2026-08-18 15:13:40 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 15:13:40 --> Helper loaded: plesk_helper
INFO - 2026-08-18 15:13:41 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 15:13:41 --> Helper loaded: domain_helper
INFO - 2026-08-18 15:13:41 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 15:13:41 --> Database Driver Class Initialized
INFO - 2026-08-18 15:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 15:13:41 --> Upload Class Initialized
DEBUG - 2026-08-18 15:13:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 15:13:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 15:13:41 --> Encryption Class Initialized
INFO - 2026-08-18 15:13:41 --> Form Validation Class Initialized
INFO - 2026-08-18 15:13:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 15:13:41 --> Pagination Class Initialized
INFO - 2026-08-18 15:13:41 --> Email Class Initialized
INFO - 2026-08-18 15:13:41 --> Controller Class Initialized
DEBUG - 2026-08-18 15:13:41 --> Invoicing MX_Controller Initialized
INFO - 2026-08-18 15:13:41 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 15:13:41 --> Model "Auth_model" initialized
INFO - 2026-08-18 15:13:41 --> Model "Cart_model" initialized
INFO - 2026-08-18 15:13:42 --> Model "Billing_model" initialized
INFO - 2026-08-18 15:13:42 --> Model "Common_model" initialized
INFO - 2026-08-18 15:13:42 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 15:13:42 --> Config Class Initialized
INFO - 2026-08-18 15:13:42 --> Hooks Class Initialized
DEBUG - 2026-08-18 15:13:42 --> UTF-8 Support Enabled
INFO - 2026-08-18 15:13:42 --> Utf8 Class Initialized
INFO - 2026-08-18 15:13:42 --> URI Class Initialized
INFO - 2026-08-18 15:13:42 --> Router Class Initialized
INFO - 2026-08-18 15:13:42 --> Output Class Initialized
INFO - 2026-08-18 15:13:42 --> Security Class Initialized
DEBUG - 2026-08-18 15:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 15:13:42 --> CSRF cookie sent
INFO - 2026-08-18 15:13:42 --> Input Class Initialized
INFO - 2026-08-18 15:13:42 --> Language Class Initialized
INFO - 2026-08-18 15:13:42 --> Language Class Initialized
INFO - 2026-08-18 15:13:42 --> Config Class Initialized
INFO - 2026-08-18 15:13:42 --> Loader Class Initialized
INFO - 2026-08-18 15:13:42 --> Helper loaded: url_helper
INFO - 2026-08-18 15:13:42 --> Helper loaded: form_helper
INFO - 2026-08-18 15:13:42 --> Helper loaded: html_helper
INFO - 2026-08-18 15:13:42 --> Helper loaded: file_helper
INFO - 2026-08-18 15:13:42 --> Helper loaded: email_helper
INFO - 2026-08-18 15:13:42 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 15:13:42 --> Helper loaded: ssp_helper
INFO - 2026-08-18 15:13:42 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 15:13:42 --> Helper loaded: plesk_helper
INFO - 2026-08-18 15:13:42 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 15:13:42 --> Helper loaded: domain_helper
INFO - 2026-08-18 15:13:42 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 15:13:42 --> Database Driver Class Initialized
INFO - 2026-08-18 15:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 15:13:42 --> Upload Class Initialized
DEBUG - 2026-08-18 15:13:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 15:13:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 15:13:42 --> Encryption Class Initialized
INFO - 2026-08-18 15:13:42 --> Form Validation Class Initialized
INFO - 2026-08-18 15:13:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 15:13:42 --> Pagination Class Initialized
INFO - 2026-08-18 15:13:42 --> Email Class Initialized
INFO - 2026-08-18 15:13:42 --> Controller Class Initialized
DEBUG - 2026-08-18 15:13:42 --> Dashboard MX_Controller Initialized
INFO - 2026-08-18 15:13:42 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 15:13:42 --> Model "Adminauth_model" initialized
INFO - 2026-08-18 15:13:42 --> Config Class Initialized
INFO - 2026-08-18 15:13:42 --> Hooks Class Initialized
DEBUG - 2026-08-18 15:13:42 --> UTF-8 Support Enabled
INFO - 2026-08-18 15:13:42 --> Utf8 Class Initialized
INFO - 2026-08-18 15:13:42 --> URI Class Initialized
INFO - 2026-08-18 15:13:42 --> Router Class Initialized
INFO - 2026-08-18 15:13:42 --> Output Class Initialized
INFO - 2026-08-18 15:13:42 --> Security Class Initialized
DEBUG - 2026-08-18 15:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 15:13:42 --> CSRF cookie sent
INFO - 2026-08-18 15:13:42 --> Input Class Initialized
INFO - 2026-08-18 15:13:42 --> Language Class Initialized
INFO - 2026-08-18 15:13:42 --> Language Class Initialized
INFO - 2026-08-18 15:13:42 --> Config Class Initialized
INFO - 2026-08-18 15:13:42 --> Loader Class Initialized
INFO - 2026-08-18 15:13:42 --> Helper loaded: url_helper
INFO - 2026-08-18 15:13:42 --> Helper loaded: form_helper
INFO - 2026-08-18 15:13:42 --> Helper loaded: html_helper
INFO - 2026-08-18 15:13:42 --> Helper loaded: file_helper
INFO - 2026-08-18 15:13:42 --> Helper loaded: email_helper
INFO - 2026-08-18 15:13:42 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 15:13:42 --> Helper loaded: ssp_helper
INFO - 2026-08-18 15:13:42 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 15:13:42 --> Helper loaded: plesk_helper
INFO - 2026-08-18 15:13:42 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 15:13:42 --> Helper loaded: domain_helper
INFO - 2026-08-18 15:13:42 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 15:13:42 --> Database Driver Class Initialized
INFO - 2026-08-18 15:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 15:13:44 --> Upload Class Initialized
DEBUG - 2026-08-18 15:13:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 15:13:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 15:13:44 --> Encryption Class Initialized
INFO - 2026-08-18 15:13:44 --> Form Validation Class Initialized
INFO - 2026-08-18 15:13:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 15:13:44 --> Pagination Class Initialized
INFO - 2026-08-18 15:13:44 --> Email Class Initialized
INFO - 2026-08-18 15:13:44 --> Controller Class Initialized
DEBUG - 2026-08-18 15:13:44 --> Invoicing MX_Controller Initialized
INFO - 2026-08-18 15:13:44 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 15:13:44 --> Model "Auth_model" initialized
INFO - 2026-08-18 15:13:44 --> Model "Cart_model" initialized
INFO - 2026-08-18 15:13:44 --> Model "Billing_model" initialized
INFO - 2026-08-18 15:13:44 --> Model "Common_model" initialized
INFO - 2026-08-18 15:13:44 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 15:13:44 --> Config Class Initialized
INFO - 2026-08-18 15:13:44 --> Hooks Class Initialized
DEBUG - 2026-08-18 15:13:44 --> UTF-8 Support Enabled
INFO - 2026-08-18 15:13:44 --> Utf8 Class Initialized
INFO - 2026-08-18 15:13:44 --> URI Class Initialized
INFO - 2026-08-18 15:13:44 --> Router Class Initialized
INFO - 2026-08-18 15:13:44 --> Output Class Initialized
INFO - 2026-08-18 15:13:44 --> Security Class Initialized
DEBUG - 2026-08-18 15:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 15:13:44 --> CSRF cookie sent
INFO - 2026-08-18 15:13:44 --> Input Class Initialized
INFO - 2026-08-18 15:13:44 --> Language Class Initialized
INFO - 2026-08-18 15:13:44 --> Language Class Initialized
INFO - 2026-08-18 15:13:44 --> Config Class Initialized
INFO - 2026-08-18 15:13:44 --> Loader Class Initialized
INFO - 2026-08-18 15:13:44 --> Helper loaded: url_helper
INFO - 2026-08-18 15:13:44 --> Helper loaded: form_helper
INFO - 2026-08-18 15:13:44 --> Helper loaded: html_helper
INFO - 2026-08-18 15:13:44 --> Helper loaded: file_helper
INFO - 2026-08-18 15:13:44 --> Helper loaded: email_helper
INFO - 2026-08-18 15:13:44 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 15:13:44 --> Helper loaded: ssp_helper
INFO - 2026-08-18 15:13:44 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 15:13:44 --> Helper loaded: plesk_helper
INFO - 2026-08-18 15:13:44 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 15:13:44 --> Helper loaded: domain_helper
INFO - 2026-08-18 15:13:44 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 15:13:44 --> Database Driver Class Initialized
INFO - 2026-08-18 15:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 15:13:45 --> Upload Class Initialized
DEBUG - 2026-08-18 15:13:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 15:13:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 15:13:45 --> Encryption Class Initialized
INFO - 2026-08-18 15:13:45 --> Form Validation Class Initialized
INFO - 2026-08-18 15:13:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 15:13:45 --> Pagination Class Initialized
INFO - 2026-08-18 15:13:45 --> Email Class Initialized
INFO - 2026-08-18 15:13:45 --> Controller Class Initialized
DEBUG - 2026-08-18 15:13:45 --> Authenticate MX_Controller Initialized
INFO - 2026-08-18 15:13:45 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 15:13:45 --> Model "Adminauth_model" initialized
INFO - 2026-08-18 15:13:45 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-18 15:13:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-08-18 15:13:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-08-18 15:13:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-08-18 15:13:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-08-18 15:13:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-08-18 15:13:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-08-18 15:13:46 --> Final output sent to browser
DEBUG - 2026-08-18 15:13:46 --> Total execution time: 3.1977
INFO - 2026-08-18 15:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 15:13:46 --> Upload Class Initialized
DEBUG - 2026-08-18 15:13:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 15:13:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 15:13:46 --> Encryption Class Initialized
INFO - 2026-08-18 15:13:46 --> Form Validation Class Initialized
INFO - 2026-08-18 15:13:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 15:13:46 --> Pagination Class Initialized
INFO - 2026-08-18 15:13:46 --> Email Class Initialized
INFO - 2026-08-18 15:13:46 --> Controller Class Initialized
DEBUG - 2026-08-18 15:13:46 --> Invoicing MX_Controller Initialized
INFO - 2026-08-18 15:13:46 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 15:13:46 --> Model "Auth_model" initialized
INFO - 2026-08-18 15:13:46 --> Model "Cart_model" initialized
INFO - 2026-08-18 15:13:46 --> Model "Billing_model" initialized
INFO - 2026-08-18 15:13:46 --> Model "Common_model" initialized
INFO - 2026-08-18 15:13:46 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 15:13:48 --> Config Class Initialized
INFO - 2026-08-18 15:13:48 --> Hooks Class Initialized
DEBUG - 2026-08-18 15:13:48 --> UTF-8 Support Enabled
INFO - 2026-08-18 15:13:48 --> Utf8 Class Initialized
INFO - 2026-08-18 15:13:48 --> URI Class Initialized
INFO - 2026-08-18 15:13:48 --> Router Class Initialized
INFO - 2026-08-18 15:13:48 --> Output Class Initialized
INFO - 2026-08-18 15:13:48 --> Security Class Initialized
DEBUG - 2026-08-18 15:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 15:13:48 --> CSRF cookie sent
INFO - 2026-08-18 15:13:48 --> Input Class Initialized
INFO - 2026-08-18 15:13:48 --> Language Class Initialized
INFO - 2026-08-18 15:13:48 --> Language Class Initialized
INFO - 2026-08-18 15:13:48 --> Config Class Initialized
INFO - 2026-08-18 15:13:48 --> Loader Class Initialized
INFO - 2026-08-18 15:13:48 --> Helper loaded: url_helper
INFO - 2026-08-18 15:13:48 --> Helper loaded: form_helper
INFO - 2026-08-18 15:13:48 --> Helper loaded: html_helper
INFO - 2026-08-18 15:13:48 --> Helper loaded: file_helper
INFO - 2026-08-18 15:13:48 --> Helper loaded: email_helper
INFO - 2026-08-18 15:13:48 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 15:13:48 --> Helper loaded: ssp_helper
INFO - 2026-08-18 15:13:48 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 15:13:48 --> Helper loaded: plesk_helper
INFO - 2026-08-18 15:13:48 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 15:13:48 --> Helper loaded: domain_helper
INFO - 2026-08-18 15:13:48 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 15:13:48 --> Database Driver Class Initialized
INFO - 2026-08-18 15:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 15:13:50 --> Upload Class Initialized
DEBUG - 2026-08-18 15:13:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 15:13:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 15:13:50 --> Encryption Class Initialized
INFO - 2026-08-18 15:13:50 --> Form Validation Class Initialized
INFO - 2026-08-18 15:13:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 15:13:50 --> Pagination Class Initialized
INFO - 2026-08-18 15:13:50 --> Email Class Initialized
INFO - 2026-08-18 15:13:50 --> Controller Class Initialized
DEBUG - 2026-08-18 15:13:50 --> Invoicing MX_Controller Initialized
INFO - 2026-08-18 15:13:50 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 15:13:50 --> Model "Auth_model" initialized
INFO - 2026-08-18 15:13:50 --> Model "Cart_model" initialized
INFO - 2026-08-18 15:13:50 --> Model "Billing_model" initialized
INFO - 2026-08-18 15:13:50 --> Model "Common_model" initialized
INFO - 2026-08-18 15:13:50 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 15:13:50 --> Config Class Initialized
INFO - 2026-08-18 15:13:50 --> Hooks Class Initialized
DEBUG - 2026-08-18 15:13:50 --> UTF-8 Support Enabled
INFO - 2026-08-18 15:13:50 --> Utf8 Class Initialized
INFO - 2026-08-18 15:13:50 --> URI Class Initialized
INFO - 2026-08-18 15:13:50 --> Router Class Initialized
INFO - 2026-08-18 15:13:50 --> Output Class Initialized
INFO - 2026-08-18 15:13:50 --> Security Class Initialized
DEBUG - 2026-08-18 15:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 15:13:50 --> CSRF cookie sent
INFO - 2026-08-18 15:13:50 --> Input Class Initialized
INFO - 2026-08-18 15:13:50 --> Language Class Initialized
INFO - 2026-08-18 15:13:50 --> Language Class Initialized
INFO - 2026-08-18 15:13:50 --> Config Class Initialized
INFO - 2026-08-18 15:13:50 --> Loader Class Initialized
INFO - 2026-08-18 15:13:50 --> Helper loaded: url_helper
INFO - 2026-08-18 15:13:50 --> Helper loaded: form_helper
INFO - 2026-08-18 15:13:50 --> Helper loaded: html_helper
INFO - 2026-08-18 15:13:50 --> Helper loaded: file_helper
INFO - 2026-08-18 15:13:50 --> Helper loaded: email_helper
INFO - 2026-08-18 15:13:50 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 15:13:50 --> Helper loaded: ssp_helper
INFO - 2026-08-18 15:13:50 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 15:13:50 --> Helper loaded: plesk_helper
INFO - 2026-08-18 15:13:50 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 15:13:50 --> Helper loaded: domain_helper
INFO - 2026-08-18 15:13:50 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 15:13:50 --> Database Driver Class Initialized
INFO - 2026-08-18 15:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 15:13:53 --> Upload Class Initialized
DEBUG - 2026-08-18 15:13:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 15:13:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 15:13:53 --> Encryption Class Initialized
INFO - 2026-08-18 15:13:53 --> Form Validation Class Initialized
INFO - 2026-08-18 15:13:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 15:13:53 --> Pagination Class Initialized
INFO - 2026-08-18 15:13:53 --> Email Class Initialized
INFO - 2026-08-18 15:13:53 --> Controller Class Initialized
DEBUG - 2026-08-18 15:13:53 --> Invoicing MX_Controller Initialized
INFO - 2026-08-18 15:13:53 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 15:13:53 --> Model "Auth_model" initialized
INFO - 2026-08-18 15:13:53 --> Model "Cart_model" initialized
INFO - 2026-08-18 15:13:53 --> Model "Billing_model" initialized
INFO - 2026-08-18 15:13:53 --> Model "Common_model" initialized
INFO - 2026-08-18 15:13:53 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 15:13:53 --> Config Class Initialized
INFO - 2026-08-18 15:13:53 --> Hooks Class Initialized
DEBUG - 2026-08-18 15:13:53 --> UTF-8 Support Enabled
INFO - 2026-08-18 15:13:53 --> Utf8 Class Initialized
INFO - 2026-08-18 15:13:53 --> URI Class Initialized
INFO - 2026-08-18 15:13:53 --> Router Class Initialized
INFO - 2026-08-18 15:13:53 --> Output Class Initialized
INFO - 2026-08-18 15:13:53 --> Security Class Initialized
DEBUG - 2026-08-18 15:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 15:13:53 --> CSRF cookie sent
INFO - 2026-08-18 15:13:53 --> Input Class Initialized
INFO - 2026-08-18 15:13:53 --> Language Class Initialized
INFO - 2026-08-18 15:13:53 --> Language Class Initialized
INFO - 2026-08-18 15:13:53 --> Config Class Initialized
INFO - 2026-08-18 15:13:53 --> Loader Class Initialized
INFO - 2026-08-18 15:13:53 --> Helper loaded: url_helper
INFO - 2026-08-18 15:13:53 --> Helper loaded: form_helper
INFO - 2026-08-18 15:13:53 --> Helper loaded: html_helper
INFO - 2026-08-18 15:13:53 --> Helper loaded: file_helper
INFO - 2026-08-18 15:13:53 --> Helper loaded: email_helper
INFO - 2026-08-18 15:13:53 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 15:13:53 --> Helper loaded: ssp_helper
INFO - 2026-08-18 15:13:53 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 15:13:53 --> Helper loaded: plesk_helper
INFO - 2026-08-18 15:13:53 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 15:13:53 --> Helper loaded: domain_helper
INFO - 2026-08-18 15:13:53 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 15:13:53 --> Database Driver Class Initialized
INFO - 2026-08-18 15:13:54 --> Config Class Initialized
INFO - 2026-08-18 15:13:54 --> Hooks Class Initialized
DEBUG - 2026-08-18 15:13:54 --> UTF-8 Support Enabled
INFO - 2026-08-18 15:13:54 --> Utf8 Class Initialized
INFO - 2026-08-18 15:13:54 --> URI Class Initialized
INFO - 2026-08-18 15:13:54 --> Router Class Initialized
INFO - 2026-08-18 15:13:54 --> Output Class Initialized
INFO - 2026-08-18 15:13:54 --> Security Class Initialized
DEBUG - 2026-08-18 15:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 15:13:54 --> CSRF cookie sent
INFO - 2026-08-18 15:13:54 --> CSRF token verified
INFO - 2026-08-18 15:13:54 --> Input Class Initialized
INFO - 2026-08-18 15:13:54 --> Language Class Initialized
INFO - 2026-08-18 15:13:54 --> Language Class Initialized
INFO - 2026-08-18 15:13:54 --> Config Class Initialized
INFO - 2026-08-18 15:13:54 --> Loader Class Initialized
INFO - 2026-08-18 15:13:54 --> Helper loaded: url_helper
INFO - 2026-08-18 15:13:54 --> Helper loaded: form_helper
INFO - 2026-08-18 15:13:54 --> Helper loaded: html_helper
INFO - 2026-08-18 15:13:54 --> Helper loaded: file_helper
INFO - 2026-08-18 15:13:54 --> Helper loaded: email_helper
INFO - 2026-08-18 15:13:54 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 15:13:54 --> Helper loaded: ssp_helper
INFO - 2026-08-18 15:13:54 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 15:13:54 --> Helper loaded: plesk_helper
INFO - 2026-08-18 15:13:54 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 15:13:54 --> Helper loaded: domain_helper
INFO - 2026-08-18 15:13:54 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 15:13:55 --> Database Driver Class Initialized
INFO - 2026-08-18 15:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 15:13:55 --> Upload Class Initialized
DEBUG - 2026-08-18 15:13:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 15:13:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 15:13:55 --> Encryption Class Initialized
INFO - 2026-08-18 15:13:55 --> Form Validation Class Initialized
INFO - 2026-08-18 15:13:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 15:13:55 --> Pagination Class Initialized
INFO - 2026-08-18 15:13:55 --> Email Class Initialized
INFO - 2026-08-18 15:13:55 --> Controller Class Initialized
DEBUG - 2026-08-18 15:13:55 --> Invoicing MX_Controller Initialized
INFO - 2026-08-18 15:13:55 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 15:13:55 --> Model "Auth_model" initialized
INFO - 2026-08-18 15:13:55 --> Model "Cart_model" initialized
INFO - 2026-08-18 15:13:56 --> Model "Billing_model" initialized
INFO - 2026-08-18 15:13:56 --> Model "Common_model" initialized
INFO - 2026-08-18 15:13:56 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 15:13:56 --> Config Class Initialized
INFO - 2026-08-18 15:13:56 --> Hooks Class Initialized
DEBUG - 2026-08-18 15:13:56 --> UTF-8 Support Enabled
INFO - 2026-08-18 15:13:56 --> Utf8 Class Initialized
INFO - 2026-08-18 15:13:56 --> URI Class Initialized
INFO - 2026-08-18 15:13:56 --> Router Class Initialized
INFO - 2026-08-18 15:13:56 --> Output Class Initialized
INFO - 2026-08-18 15:13:56 --> Security Class Initialized
DEBUG - 2026-08-18 15:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 15:13:56 --> CSRF cookie sent
INFO - 2026-08-18 15:13:56 --> Input Class Initialized
INFO - 2026-08-18 15:13:56 --> Language Class Initialized
INFO - 2026-08-18 15:13:56 --> Language Class Initialized
INFO - 2026-08-18 15:13:56 --> Config Class Initialized
INFO - 2026-08-18 15:13:56 --> Loader Class Initialized
INFO - 2026-08-18 15:13:56 --> Helper loaded: url_helper
INFO - 2026-08-18 15:13:56 --> Helper loaded: form_helper
INFO - 2026-08-18 15:13:56 --> Helper loaded: html_helper
INFO - 2026-08-18 15:13:56 --> Helper loaded: file_helper
INFO - 2026-08-18 15:13:56 --> Helper loaded: email_helper
INFO - 2026-08-18 15:13:56 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 15:13:56 --> Helper loaded: ssp_helper
INFO - 2026-08-18 15:13:56 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 15:13:56 --> Helper loaded: plesk_helper
INFO - 2026-08-18 15:13:56 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 15:13:56 --> Helper loaded: domain_helper
INFO - 2026-08-18 15:13:56 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 15:13:56 --> Database Driver Class Initialized
INFO - 2026-08-18 15:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 15:13:56 --> Upload Class Initialized
DEBUG - 2026-08-18 15:13:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 15:13:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 15:13:56 --> Encryption Class Initialized
INFO - 2026-08-18 15:13:56 --> Form Validation Class Initialized
INFO - 2026-08-18 15:13:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 15:13:56 --> Pagination Class Initialized
INFO - 2026-08-18 15:13:56 --> Email Class Initialized
INFO - 2026-08-18 15:13:56 --> Controller Class Initialized
DEBUG - 2026-08-18 15:13:56 --> Authenticate MX_Controller Initialized
INFO - 2026-08-18 15:13:56 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 15:13:56 --> Model "Adminauth_model" initialized
INFO - 2026-08-18 15:13:56 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-18 15:13:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-08-18 15:13:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-08-18 15:13:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
INFO - 2026-08-18 15:13:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-08-18 15:13:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-08-18 15:13:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-08-18 15:13:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-08-18 15:13:59 --> Final output sent to browser
DEBUG - 2026-08-18 15:13:59 --> Total execution time: 4.4211
INFO - 2026-08-18 15:13:59 --> Upload Class Initialized
DEBUG - 2026-08-18 15:13:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 15:13:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 15:13:59 --> Encryption Class Initialized
INFO - 2026-08-18 15:13:59 --> Form Validation Class Initialized
INFO - 2026-08-18 15:13:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 15:13:59 --> Pagination Class Initialized
INFO - 2026-08-18 15:13:59 --> Email Class Initialized
INFO - 2026-08-18 15:13:59 --> Controller Class Initialized
DEBUG - 2026-08-18 15:13:59 --> Invoicing MX_Controller Initialized
INFO - 2026-08-18 15:13:59 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 15:13:59 --> Model "Auth_model" initialized
INFO - 2026-08-18 15:13:59 --> Model "Cart_model" initialized
INFO - 2026-08-18 15:13:59 --> Model "Billing_model" initialized
INFO - 2026-08-18 15:13:59 --> Model "Common_model" initialized
INFO - 2026-08-18 15:13:59 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 15:13:59 --> Config Class Initialized
INFO - 2026-08-18 15:13:59 --> Hooks Class Initialized
DEBUG - 2026-08-18 15:13:59 --> UTF-8 Support Enabled
INFO - 2026-08-18 15:13:59 --> Utf8 Class Initialized
INFO - 2026-08-18 15:13:59 --> URI Class Initialized
INFO - 2026-08-18 15:13:59 --> Router Class Initialized
INFO - 2026-08-18 15:13:59 --> Output Class Initialized
INFO - 2026-08-18 15:13:59 --> Security Class Initialized
DEBUG - 2026-08-18 15:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 15:13:59 --> CSRF cookie sent
INFO - 2026-08-18 15:13:59 --> Input Class Initialized
INFO - 2026-08-18 15:13:59 --> Language Class Initialized
INFO - 2026-08-18 15:13:59 --> Language Class Initialized
INFO - 2026-08-18 15:13:59 --> Config Class Initialized
INFO - 2026-08-18 15:13:59 --> Loader Class Initialized
INFO - 2026-08-18 15:13:59 --> Helper loaded: url_helper
INFO - 2026-08-18 15:13:59 --> Helper loaded: form_helper
INFO - 2026-08-18 15:13:59 --> Helper loaded: html_helper
INFO - 2026-08-18 15:13:59 --> Helper loaded: file_helper
INFO - 2026-08-18 15:13:59 --> Helper loaded: email_helper
INFO - 2026-08-18 15:13:59 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 15:13:59 --> Helper loaded: ssp_helper
INFO - 2026-08-18 15:13:59 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 15:13:59 --> Helper loaded: plesk_helper
INFO - 2026-08-18 15:13:59 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 15:13:59 --> Helper loaded: domain_helper
INFO - 2026-08-18 15:13:59 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 15:13:59 --> Database Driver Class Initialized
INFO - 2026-08-18 15:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 15:14:01 --> Upload Class Initialized
DEBUG - 2026-08-18 15:14:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 15:14:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 15:14:01 --> Encryption Class Initialized
INFO - 2026-08-18 15:14:01 --> Form Validation Class Initialized
INFO - 2026-08-18 15:14:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 15:14:01 --> Pagination Class Initialized
INFO - 2026-08-18 15:14:01 --> Email Class Initialized
INFO - 2026-08-18 15:14:01 --> Controller Class Initialized
DEBUG - 2026-08-18 15:14:01 --> Pay MX_Controller Initialized
INFO - 2026-08-18 15:14:01 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 15:14:01 --> Model "Auth_model" initialized
INFO - 2026-08-18 15:14:01 --> Model "Cart_model" initialized
INFO - 2026-08-18 15:14:02 --> Model "Payment_model" initialized
INFO - 2026-08-18 15:14:02 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 15:14:02 --> Model "Billing_model" initialized
INFO - 2026-08-18 15:14:02 --> Model "Invoice_model" initialized
INFO - 2026-08-18 15:14:02 --> Config Class Initialized
INFO - 2026-08-18 15:14:02 --> Hooks Class Initialized
DEBUG - 2026-08-18 15:14:02 --> UTF-8 Support Enabled
INFO - 2026-08-18 15:14:02 --> Utf8 Class Initialized
INFO - 2026-08-18 15:14:02 --> URI Class Initialized
INFO - 2026-08-18 15:14:02 --> Router Class Initialized
INFO - 2026-08-18 15:14:02 --> Output Class Initialized
INFO - 2026-08-18 15:14:02 --> Security Class Initialized
DEBUG - 2026-08-18 15:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 15:14:02 --> CSRF cookie sent
INFO - 2026-08-18 15:14:02 --> Input Class Initialized
INFO - 2026-08-18 15:14:02 --> Language Class Initialized
INFO - 2026-08-18 15:14:02 --> Language Class Initialized
INFO - 2026-08-18 15:14:02 --> Config Class Initialized
INFO - 2026-08-18 15:14:02 --> Loader Class Initialized
INFO - 2026-08-18 15:14:02 --> Helper loaded: url_helper
INFO - 2026-08-18 15:14:02 --> Helper loaded: form_helper
INFO - 2026-08-18 15:14:02 --> Helper loaded: html_helper
INFO - 2026-08-18 15:14:02 --> Helper loaded: file_helper
INFO - 2026-08-18 15:14:02 --> Helper loaded: email_helper
INFO - 2026-08-18 15:14:02 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 15:14:02 --> Helper loaded: ssp_helper
INFO - 2026-08-18 15:14:02 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 15:14:02 --> Helper loaded: plesk_helper
INFO - 2026-08-18 15:14:02 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 15:14:02 --> Helper loaded: domain_helper
INFO - 2026-08-18 15:14:02 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 15:14:02 --> Database Driver Class Initialized
INFO - 2026-08-18 15:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 15:14:04 --> Upload Class Initialized
DEBUG - 2026-08-18 15:14:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 15:14:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 15:14:04 --> Encryption Class Initialized
INFO - 2026-08-18 15:14:04 --> Form Validation Class Initialized
INFO - 2026-08-18 15:14:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 15:14:04 --> Pagination Class Initialized
INFO - 2026-08-18 15:14:04 --> Email Class Initialized
INFO - 2026-08-18 15:14:04 --> Controller Class Initialized
DEBUG - 2026-08-18 15:14:04 --> Pay MX_Controller Initialized
INFO - 2026-08-18 15:14:04 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 15:14:04 --> Model "Auth_model" initialized
INFO - 2026-08-18 15:14:04 --> Model "Cart_model" initialized
INFO - 2026-08-18 15:14:04 --> Model "Payment_model" initialized
INFO - 2026-08-18 15:14:04 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 15:14:04 --> Model "Billing_model" initialized
INFO - 2026-08-18 15:14:04 --> Model "Invoice_model" initialized
INFO - 2026-08-18 15:14:04 --> Config Class Initialized
INFO - 2026-08-18 15:14:04 --> Hooks Class Initialized
DEBUG - 2026-08-18 15:14:04 --> UTF-8 Support Enabled
INFO - 2026-08-18 15:14:04 --> Utf8 Class Initialized
INFO - 2026-08-18 15:14:04 --> URI Class Initialized
INFO - 2026-08-18 15:14:04 --> Router Class Initialized
INFO - 2026-08-18 15:14:04 --> Output Class Initialized
INFO - 2026-08-18 15:14:04 --> Security Class Initialized
DEBUG - 2026-08-18 15:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 15:14:04 --> CSRF cookie sent
INFO - 2026-08-18 15:14:04 --> Input Class Initialized
INFO - 2026-08-18 15:14:04 --> Language Class Initialized
INFO - 2026-08-18 15:14:04 --> Language Class Initialized
INFO - 2026-08-18 15:14:04 --> Config Class Initialized
INFO - 2026-08-18 15:14:04 --> Loader Class Initialized
INFO - 2026-08-18 15:14:04 --> Helper loaded: url_helper
INFO - 2026-08-18 15:14:04 --> Helper loaded: form_helper
INFO - 2026-08-18 15:14:04 --> Helper loaded: html_helper
INFO - 2026-08-18 15:14:04 --> Helper loaded: file_helper
INFO - 2026-08-18 15:14:04 --> Helper loaded: email_helper
INFO - 2026-08-18 15:14:04 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 15:14:04 --> Helper loaded: ssp_helper
INFO - 2026-08-18 15:14:04 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 15:14:04 --> Helper loaded: plesk_helper
INFO - 2026-08-18 15:14:04 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 15:14:04 --> Helper loaded: domain_helper
INFO - 2026-08-18 15:14:04 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 15:14:04 --> Database Driver Class Initialized
INFO - 2026-08-18 15:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 15:14:06 --> Upload Class Initialized
DEBUG - 2026-08-18 15:14:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 15:14:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 15:14:06 --> Encryption Class Initialized
INFO - 2026-08-18 15:14:06 --> Form Validation Class Initialized
INFO - 2026-08-18 15:14:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 15:14:06 --> Pagination Class Initialized
INFO - 2026-08-18 15:14:06 --> Email Class Initialized
INFO - 2026-08-18 15:14:06 --> Controller Class Initialized
DEBUG - 2026-08-18 15:14:06 --> Pay MX_Controller Initialized
INFO - 2026-08-18 15:14:06 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 15:14:06 --> Model "Auth_model" initialized
INFO - 2026-08-18 15:14:06 --> Model "Cart_model" initialized
INFO - 2026-08-18 15:14:07 --> Model "Payment_model" initialized
INFO - 2026-08-18 15:14:07 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 15:14:07 --> Model "Billing_model" initialized
INFO - 2026-08-18 15:14:07 --> Model "Invoice_model" initialized
INFO - 2026-08-18 15:14:07 --> Config Class Initialized
INFO - 2026-08-18 15:14:07 --> Hooks Class Initialized
DEBUG - 2026-08-18 15:14:07 --> UTF-8 Support Enabled
INFO - 2026-08-18 15:14:07 --> Utf8 Class Initialized
INFO - 2026-08-18 15:14:07 --> URI Class Initialized
INFO - 2026-08-18 15:14:07 --> Router Class Initialized
INFO - 2026-08-18 15:14:07 --> Output Class Initialized
INFO - 2026-08-18 15:14:07 --> Security Class Initialized
DEBUG - 2026-08-18 15:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 15:14:07 --> CSRF cookie sent
INFO - 2026-08-18 15:14:07 --> Input Class Initialized
INFO - 2026-08-18 15:14:07 --> Language Class Initialized
INFO - 2026-08-18 15:14:07 --> Language Class Initialized
INFO - 2026-08-18 15:14:07 --> Config Class Initialized
INFO - 2026-08-18 15:14:07 --> Loader Class Initialized
INFO - 2026-08-18 15:14:07 --> Helper loaded: url_helper
INFO - 2026-08-18 15:14:07 --> Helper loaded: form_helper
INFO - 2026-08-18 15:14:07 --> Helper loaded: html_helper
INFO - 2026-08-18 15:14:07 --> Helper loaded: file_helper
INFO - 2026-08-18 15:14:07 --> Helper loaded: email_helper
INFO - 2026-08-18 15:14:07 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 15:14:07 --> Helper loaded: ssp_helper
INFO - 2026-08-18 15:14:07 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 15:14:07 --> Helper loaded: plesk_helper
INFO - 2026-08-18 15:14:07 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 15:14:07 --> Helper loaded: domain_helper
INFO - 2026-08-18 15:14:07 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 15:14:07 --> Database Driver Class Initialized
INFO - 2026-08-18 15:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 15:14:09 --> Upload Class Initialized
DEBUG - 2026-08-18 15:14:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 15:14:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 15:14:09 --> Encryption Class Initialized
INFO - 2026-08-18 15:14:09 --> Form Validation Class Initialized
INFO - 2026-08-18 15:14:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 15:14:09 --> Pagination Class Initialized
INFO - 2026-08-18 15:14:09 --> Email Class Initialized
INFO - 2026-08-18 15:14:09 --> Controller Class Initialized
DEBUG - 2026-08-18 15:14:09 --> Pay MX_Controller Initialized
INFO - 2026-08-18 15:14:09 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 15:14:09 --> Model "Auth_model" initialized
INFO - 2026-08-18 15:14:09 --> Model "Cart_model" initialized
INFO - 2026-08-18 15:14:09 --> Model "Payment_model" initialized
INFO - 2026-08-18 15:14:09 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 15:14:09 --> Model "Billing_model" initialized
INFO - 2026-08-18 15:14:09 --> Model "Invoice_model" initialized
INFO - 2026-08-18 15:14:18 --> Config Class Initialized
INFO - 2026-08-18 15:14:18 --> Hooks Class Initialized
DEBUG - 2026-08-18 15:14:18 --> UTF-8 Support Enabled
INFO - 2026-08-18 15:14:18 --> Utf8 Class Initialized
INFO - 2026-08-18 15:14:18 --> URI Class Initialized
INFO - 2026-08-18 15:14:18 --> Router Class Initialized
INFO - 2026-08-18 15:14:18 --> Output Class Initialized
INFO - 2026-08-18 15:14:18 --> Security Class Initialized
DEBUG - 2026-08-18 15:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 15:14:18 --> CSRF cookie sent
INFO - 2026-08-18 15:14:18 --> Input Class Initialized
INFO - 2026-08-18 15:14:18 --> Language Class Initialized
INFO - 2026-08-18 15:14:18 --> Language Class Initialized
INFO - 2026-08-18 15:14:18 --> Config Class Initialized
INFO - 2026-08-18 15:14:18 --> Loader Class Initialized
INFO - 2026-08-18 15:14:18 --> Helper loaded: url_helper
INFO - 2026-08-18 15:14:18 --> Helper loaded: form_helper
INFO - 2026-08-18 15:14:18 --> Helper loaded: html_helper
INFO - 2026-08-18 15:14:18 --> Helper loaded: file_helper
INFO - 2026-08-18 15:14:18 --> Helper loaded: email_helper
INFO - 2026-08-18 15:14:18 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 15:14:18 --> Helper loaded: ssp_helper
INFO - 2026-08-18 15:14:18 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 15:14:18 --> Helper loaded: plesk_helper
INFO - 2026-08-18 15:14:18 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 15:14:18 --> Helper loaded: domain_helper
INFO - 2026-08-18 15:14:18 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 15:14:18 --> Database Driver Class Initialized
INFO - 2026-08-18 15:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 15:14:20 --> Upload Class Initialized
DEBUG - 2026-08-18 15:14:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 15:14:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 15:14:20 --> Encryption Class Initialized
INFO - 2026-08-18 15:14:20 --> Form Validation Class Initialized
INFO - 2026-08-18 15:14:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 15:14:20 --> Pagination Class Initialized
INFO - 2026-08-18 15:14:20 --> Email Class Initialized
INFO - 2026-08-18 15:14:20 --> Controller Class Initialized
ERROR - 2026-08-18 15:14:20 --> 404 Page Not Found: ../modules/invoicing/controllers/Invoicing/bogus_method
INFO - 2026-08-18 15:14:20 --> Config Class Initialized
INFO - 2026-08-18 15:14:20 --> Hooks Class Initialized
DEBUG - 2026-08-18 15:14:20 --> UTF-8 Support Enabled
INFO - 2026-08-18 15:14:20 --> Utf8 Class Initialized
INFO - 2026-08-18 15:14:20 --> URI Class Initialized
INFO - 2026-08-18 15:14:20 --> Router Class Initialized
INFO - 2026-08-18 15:14:20 --> Output Class Initialized
INFO - 2026-08-18 15:14:20 --> Security Class Initialized
DEBUG - 2026-08-18 15:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 15:14:20 --> CSRF cookie sent
INFO - 2026-08-18 15:14:20 --> Input Class Initialized
INFO - 2026-08-18 15:14:20 --> Language Class Initialized
INFO - 2026-08-18 15:14:20 --> Language Class Initialized
INFO - 2026-08-18 15:14:20 --> Config Class Initialized
INFO - 2026-08-18 15:14:20 --> Loader Class Initialized
INFO - 2026-08-18 15:14:20 --> Helper loaded: url_helper
INFO - 2026-08-18 15:14:20 --> Helper loaded: form_helper
INFO - 2026-08-18 15:14:20 --> Helper loaded: html_helper
INFO - 2026-08-18 15:14:20 --> Helper loaded: file_helper
INFO - 2026-08-18 15:14:20 --> Helper loaded: email_helper
INFO - 2026-08-18 15:14:20 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 15:14:20 --> Helper loaded: ssp_helper
INFO - 2026-08-18 15:14:20 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 15:14:20 --> Helper loaded: plesk_helper
INFO - 2026-08-18 15:14:20 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 15:14:20 --> Helper loaded: domain_helper
INFO - 2026-08-18 15:14:20 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 15:14:20 --> Database Driver Class Initialized
INFO - 2026-08-18 15:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 15:14:25 --> Upload Class Initialized
DEBUG - 2026-08-18 15:14:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 15:14:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 15:14:25 --> Encryption Class Initialized
INFO - 2026-08-18 15:14:25 --> Form Validation Class Initialized
INFO - 2026-08-18 15:14:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 15:14:25 --> Pagination Class Initialized
INFO - 2026-08-18 15:14:25 --> Email Class Initialized
INFO - 2026-08-18 15:14:25 --> Controller Class Initialized
ERROR - 2026-08-18 15:14:25 --> 404 Page Not Found: ../modules/invoicing/controllers/Invoicing/bogus_method
INFO - 2026-08-18 15:14:25 --> Config Class Initialized
INFO - 2026-08-18 15:14:25 --> Hooks Class Initialized
DEBUG - 2026-08-18 15:14:25 --> UTF-8 Support Enabled
INFO - 2026-08-18 15:14:25 --> Utf8 Class Initialized
INFO - 2026-08-18 15:14:25 --> URI Class Initialized
INFO - 2026-08-18 15:14:25 --> Router Class Initialized
INFO - 2026-08-18 15:14:25 --> Output Class Initialized
INFO - 2026-08-18 15:14:25 --> Security Class Initialized
DEBUG - 2026-08-18 15:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 15:14:25 --> CSRF cookie sent
INFO - 2026-08-18 15:14:25 --> Input Class Initialized
INFO - 2026-08-18 15:14:25 --> Language Class Initialized
INFO - 2026-08-18 15:14:25 --> Language Class Initialized
INFO - 2026-08-18 15:14:25 --> Config Class Initialized
INFO - 2026-08-18 15:14:25 --> Loader Class Initialized
INFO - 2026-08-18 15:14:25 --> Helper loaded: url_helper
INFO - 2026-08-18 15:14:25 --> Helper loaded: form_helper
INFO - 2026-08-18 15:14:25 --> Helper loaded: html_helper
INFO - 2026-08-18 15:14:25 --> Helper loaded: file_helper
INFO - 2026-08-18 15:14:25 --> Helper loaded: email_helper
INFO - 2026-08-18 15:14:25 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 15:14:25 --> Helper loaded: ssp_helper
INFO - 2026-08-18 15:14:25 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 15:14:25 --> Helper loaded: plesk_helper
INFO - 2026-08-18 15:14:25 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 15:14:25 --> Helper loaded: domain_helper
INFO - 2026-08-18 15:14:25 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 15:14:25 --> Database Driver Class Initialized
INFO - 2026-08-18 15:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 15:14:28 --> Upload Class Initialized
DEBUG - 2026-08-18 15:14:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 15:14:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 15:14:28 --> Encryption Class Initialized
INFO - 2026-08-18 15:14:28 --> Form Validation Class Initialized
INFO - 2026-08-18 15:14:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 15:14:28 --> Pagination Class Initialized
INFO - 2026-08-18 15:14:28 --> Email Class Initialized
INFO - 2026-08-18 15:14:28 --> Controller Class Initialized
ERROR - 2026-08-18 15:14:28 --> 404 Page Not Found: /index
INFO - 2026-08-18 17:29:04 --> Config Class Initialized
INFO - 2026-08-18 17:29:04 --> Hooks Class Initialized
DEBUG - 2026-08-18 17:29:04 --> UTF-8 Support Enabled
INFO - 2026-08-18 17:29:04 --> Utf8 Class Initialized
INFO - 2026-08-18 17:29:04 --> URI Class Initialized
INFO - 2026-08-18 17:29:04 --> Router Class Initialized
INFO - 2026-08-18 17:29:04 --> Output Class Initialized
INFO - 2026-08-18 17:29:04 --> Security Class Initialized
DEBUG - 2026-08-18 17:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 17:29:04 --> CSRF cookie sent
INFO - 2026-08-18 17:29:04 --> Input Class Initialized
INFO - 2026-08-18 17:29:04 --> Language Class Initialized
INFO - 2026-08-18 17:29:04 --> Language Class Initialized
INFO - 2026-08-18 17:29:04 --> Config Class Initialized
INFO - 2026-08-18 17:29:04 --> Loader Class Initialized
INFO - 2026-08-18 17:29:04 --> Helper loaded: url_helper
INFO - 2026-08-18 17:29:04 --> Helper loaded: form_helper
INFO - 2026-08-18 17:29:04 --> Helper loaded: html_helper
INFO - 2026-08-18 17:29:04 --> Helper loaded: file_helper
INFO - 2026-08-18 17:29:04 --> Helper loaded: email_helper
INFO - 2026-08-18 17:29:04 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 17:29:04 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:29:04 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 17:29:04 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:29:04 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:29:04 --> Helper loaded: domain_helper
INFO - 2026-08-18 17:29:04 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 17:29:04 --> Database Driver Class Initialized
INFO - 2026-08-18 17:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:29:06 --> Upload Class Initialized
DEBUG - 2026-08-18 17:29:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:29:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:29:06 --> Encryption Class Initialized
INFO - 2026-08-18 17:29:06 --> Form Validation Class Initialized
INFO - 2026-08-18 17:29:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:29:06 --> Pagination Class Initialized
INFO - 2026-08-18 17:29:06 --> Email Class Initialized
INFO - 2026-08-18 17:29:06 --> Controller Class Initialized
DEBUG - 2026-08-18 17:29:06 --> Auth MX_Controller Initialized
INFO - 2026-08-18 17:29:06 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 17:29:06 --> Model "Auth_model" initialized
INFO - 2026-08-18 17:29:06 --> Model "Cart_model" initialized
INFO - 2026-08-18 17:29:06 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-18 17:29:06 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-18 17:29:06 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-18 17:29:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-18 17:29:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-08-18 17:29:07 --> Final output sent to browser
DEBUG - 2026-08-18 17:29:07 --> Total execution time: 2.7595
INFO - 2026-08-18 17:29:07 --> Config Class Initialized
INFO - 2026-08-18 17:29:07 --> Hooks Class Initialized
DEBUG - 2026-08-18 17:29:07 --> UTF-8 Support Enabled
INFO - 2026-08-18 17:29:07 --> Utf8 Class Initialized
INFO - 2026-08-18 17:29:07 --> URI Class Initialized
INFO - 2026-08-18 17:29:07 --> Router Class Initialized
INFO - 2026-08-18 17:29:07 --> Output Class Initialized
INFO - 2026-08-18 17:29:07 --> Security Class Initialized
DEBUG - 2026-08-18 17:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 17:29:07 --> CSRF cookie sent
INFO - 2026-08-18 17:29:07 --> Input Class Initialized
INFO - 2026-08-18 17:29:07 --> Language Class Initialized
INFO - 2026-08-18 17:29:07 --> Language Class Initialized
INFO - 2026-08-18 17:29:07 --> Config Class Initialized
INFO - 2026-08-18 17:29:07 --> Loader Class Initialized
INFO - 2026-08-18 17:29:07 --> Helper loaded: url_helper
INFO - 2026-08-18 17:29:07 --> Helper loaded: form_helper
INFO - 2026-08-18 17:29:07 --> Helper loaded: html_helper
INFO - 2026-08-18 17:29:07 --> Helper loaded: file_helper
INFO - 2026-08-18 17:29:07 --> Helper loaded: email_helper
INFO - 2026-08-18 17:29:07 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 17:29:07 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:29:07 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 17:29:07 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:29:07 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:29:07 --> Helper loaded: domain_helper
INFO - 2026-08-18 17:29:07 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 17:29:07 --> Database Driver Class Initialized
INFO - 2026-08-18 17:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:29:09 --> Upload Class Initialized
DEBUG - 2026-08-18 17:29:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:29:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:29:09 --> Encryption Class Initialized
INFO - 2026-08-18 17:29:09 --> Form Validation Class Initialized
INFO - 2026-08-18 17:29:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:29:09 --> Pagination Class Initialized
INFO - 2026-08-18 17:29:09 --> Email Class Initialized
INFO - 2026-08-18 17:29:09 --> Controller Class Initialized
DEBUG - 2026-08-18 17:29:09 --> Cart MX_Controller Initialized
INFO - 2026-08-18 17:29:09 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 17:29:09 --> Model "Auth_model" initialized
INFO - 2026-08-18 17:29:09 --> Model "Cart_model" initialized
INFO - 2026-08-18 17:29:09 --> Model "Common_model" initialized
INFO - 2026-08-18 17:29:09 --> Model "Order_model" initialized
INFO - 2026-08-18 17:29:09 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 17:29:09 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 17:29:09 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 17:29:09 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 17:29:09 --> Model "Plan_model" initialized
INFO - 2026-08-18 17:29:09 --> Model "Orderlicense_model" initialized
INFO - 2026-08-18 17:29:09 --> Final output sent to browser
DEBUG - 2026-08-18 17:29:09 --> Total execution time: 2.1130
INFO - 2026-08-18 17:32:22 --> Config Class Initialized
INFO - 2026-08-18 17:32:22 --> Hooks Class Initialized
DEBUG - 2026-08-18 17:32:22 --> UTF-8 Support Enabled
INFO - 2026-08-18 17:32:22 --> Utf8 Class Initialized
INFO - 2026-08-18 17:32:22 --> URI Class Initialized
INFO - 2026-08-18 17:32:22 --> Router Class Initialized
INFO - 2026-08-18 17:32:22 --> Output Class Initialized
INFO - 2026-08-18 17:32:22 --> Security Class Initialized
DEBUG - 2026-08-18 17:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 17:32:22 --> CSRF cookie sent
INFO - 2026-08-18 17:32:22 --> Input Class Initialized
INFO - 2026-08-18 17:32:22 --> Language Class Initialized
INFO - 2026-08-18 17:32:22 --> Language Class Initialized
INFO - 2026-08-18 17:32:22 --> Config Class Initialized
INFO - 2026-08-18 17:32:22 --> Loader Class Initialized
INFO - 2026-08-18 17:32:22 --> Helper loaded: url_helper
INFO - 2026-08-18 17:32:22 --> Helper loaded: form_helper
INFO - 2026-08-18 17:32:22 --> Helper loaded: html_helper
INFO - 2026-08-18 17:32:22 --> Helper loaded: file_helper
INFO - 2026-08-18 17:32:22 --> Helper loaded: email_helper
INFO - 2026-08-18 17:32:22 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 17:32:22 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:32:22 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 17:32:22 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:32:22 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:32:22 --> Helper loaded: domain_helper
INFO - 2026-08-18 17:32:22 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 17:32:22 --> Database Driver Class Initialized
INFO - 2026-08-18 17:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:32:27 --> Upload Class Initialized
DEBUG - 2026-08-18 17:32:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:32:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:32:27 --> Encryption Class Initialized
INFO - 2026-08-18 17:32:27 --> Form Validation Class Initialized
INFO - 2026-08-18 17:32:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:32:27 --> Pagination Class Initialized
INFO - 2026-08-18 17:32:27 --> Email Class Initialized
INFO - 2026-08-18 17:32:27 --> Controller Class Initialized
DEBUG - 2026-08-18 17:32:27 --> Authenticate MX_Controller Initialized
INFO - 2026-08-18 17:32:27 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 17:32:27 --> Model "Adminauth_model" initialized
INFO - 2026-08-18 17:32:27 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-18 17:32:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-08-18 17:32:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-08-18 17:32:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-08-18 17:32:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-08-18 17:32:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-08-18 17:32:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-08-18 17:32:28 --> Final output sent to browser
DEBUG - 2026-08-18 17:32:28 --> Total execution time: 6.0592
INFO - 2026-08-18 17:32:28 --> Config Class Initialized
INFO - 2026-08-18 17:32:28 --> Hooks Class Initialized
DEBUG - 2026-08-18 17:32:28 --> UTF-8 Support Enabled
INFO - 2026-08-18 17:32:28 --> Utf8 Class Initialized
INFO - 2026-08-18 17:32:28 --> URI Class Initialized
INFO - 2026-08-18 17:32:28 --> Router Class Initialized
INFO - 2026-08-18 17:32:28 --> Output Class Initialized
INFO - 2026-08-18 17:32:28 --> Security Class Initialized
DEBUG - 2026-08-18 17:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 17:32:28 --> CSRF cookie sent
INFO - 2026-08-18 17:32:28 --> Input Class Initialized
INFO - 2026-08-18 17:32:28 --> Language Class Initialized
INFO - 2026-08-18 17:32:28 --> Language Class Initialized
INFO - 2026-08-18 17:32:28 --> Config Class Initialized
INFO - 2026-08-18 17:32:28 --> Loader Class Initialized
INFO - 2026-08-18 17:32:28 --> Helper loaded: url_helper
INFO - 2026-08-18 17:32:28 --> Helper loaded: form_helper
INFO - 2026-08-18 17:32:28 --> Helper loaded: html_helper
INFO - 2026-08-18 17:32:28 --> Helper loaded: file_helper
INFO - 2026-08-18 17:32:28 --> Helper loaded: email_helper
INFO - 2026-08-18 17:32:28 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 17:32:28 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:32:28 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 17:32:28 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:32:28 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:32:28 --> Helper loaded: domain_helper
INFO - 2026-08-18 17:32:28 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 17:32:28 --> Database Driver Class Initialized
INFO - 2026-08-18 17:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:32:31 --> Upload Class Initialized
DEBUG - 2026-08-18 17:32:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:32:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:32:31 --> Encryption Class Initialized
INFO - 2026-08-18 17:32:31 --> Form Validation Class Initialized
INFO - 2026-08-18 17:32:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:32:31 --> Pagination Class Initialized
INFO - 2026-08-18 17:32:31 --> Email Class Initialized
INFO - 2026-08-18 17:32:31 --> Controller Class Initialized
ERROR - 2026-08-18 17:32:31 --> 404 Page Not Found: whmazadmin//index
INFO - 2026-08-18 17:34:59 --> Config Class Initialized
INFO - 2026-08-18 17:34:59 --> Hooks Class Initialized
DEBUG - 2026-08-18 17:34:59 --> UTF-8 Support Enabled
INFO - 2026-08-18 17:34:59 --> Utf8 Class Initialized
INFO - 2026-08-18 17:34:59 --> URI Class Initialized
INFO - 2026-08-18 17:34:59 --> Router Class Initialized
INFO - 2026-08-18 17:34:59 --> Output Class Initialized
INFO - 2026-08-18 17:34:59 --> Security Class Initialized
DEBUG - 2026-08-18 17:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 17:34:59 --> CSRF cookie sent
INFO - 2026-08-18 17:34:59 --> Input Class Initialized
INFO - 2026-08-18 17:34:59 --> Language Class Initialized
INFO - 2026-08-18 17:34:59 --> Language Class Initialized
INFO - 2026-08-18 17:34:59 --> Config Class Initialized
INFO - 2026-08-18 17:34:59 --> Loader Class Initialized
INFO - 2026-08-18 17:34:59 --> Helper loaded: url_helper
INFO - 2026-08-18 17:34:59 --> Helper loaded: form_helper
INFO - 2026-08-18 17:34:59 --> Helper loaded: html_helper
INFO - 2026-08-18 17:34:59 --> Helper loaded: file_helper
INFO - 2026-08-18 17:34:59 --> Helper loaded: email_helper
INFO - 2026-08-18 17:34:59 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 17:34:59 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:34:59 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 17:34:59 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:34:59 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:34:59 --> Helper loaded: domain_helper
INFO - 2026-08-18 17:34:59 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 17:34:59 --> Database Driver Class Initialized
INFO - 2026-08-18 17:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:35:00 --> Upload Class Initialized
DEBUG - 2026-08-18 17:35:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:35:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:35:00 --> Encryption Class Initialized
INFO - 2026-08-18 17:35:00 --> Form Validation Class Initialized
INFO - 2026-08-18 17:35:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:35:00 --> Pagination Class Initialized
INFO - 2026-08-18 17:35:00 --> Email Class Initialized
INFO - 2026-08-18 17:35:00 --> Controller Class Initialized
DEBUG - 2026-08-18 17:35:00 --> Auth MX_Controller Initialized
INFO - 2026-08-18 17:35:00 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 17:35:00 --> Model "Auth_model" initialized
INFO - 2026-08-18 17:35:00 --> Model "Cart_model" initialized
INFO - 2026-08-18 17:35:01 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-18 17:35:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-18 17:35:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-18 17:35:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-18 17:35:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-08-18 17:35:01 --> Final output sent to browser
DEBUG - 2026-08-18 17:35:01 --> Total execution time: 2.8481
INFO - 2026-08-18 17:35:02 --> Config Class Initialized
INFO - 2026-08-18 17:35:02 --> Hooks Class Initialized
DEBUG - 2026-08-18 17:35:02 --> UTF-8 Support Enabled
INFO - 2026-08-18 17:35:02 --> Utf8 Class Initialized
INFO - 2026-08-18 17:35:02 --> URI Class Initialized
INFO - 2026-08-18 17:35:02 --> Router Class Initialized
INFO - 2026-08-18 17:35:02 --> Output Class Initialized
INFO - 2026-08-18 17:35:02 --> Security Class Initialized
DEBUG - 2026-08-18 17:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 17:35:02 --> CSRF cookie sent
INFO - 2026-08-18 17:35:02 --> Input Class Initialized
INFO - 2026-08-18 17:35:02 --> Language Class Initialized
INFO - 2026-08-18 17:35:02 --> Language Class Initialized
INFO - 2026-08-18 17:35:02 --> Config Class Initialized
INFO - 2026-08-18 17:35:02 --> Loader Class Initialized
INFO - 2026-08-18 17:35:02 --> Helper loaded: url_helper
INFO - 2026-08-18 17:35:02 --> Helper loaded: form_helper
INFO - 2026-08-18 17:35:02 --> Helper loaded: html_helper
INFO - 2026-08-18 17:35:02 --> Helper loaded: file_helper
INFO - 2026-08-18 17:35:02 --> Helper loaded: email_helper
INFO - 2026-08-18 17:35:02 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 17:35:02 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:35:02 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 17:35:02 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:35:02 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:35:02 --> Helper loaded: domain_helper
INFO - 2026-08-18 17:35:02 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 17:35:02 --> Database Driver Class Initialized
INFO - 2026-08-18 17:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:35:04 --> Upload Class Initialized
DEBUG - 2026-08-18 17:35:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:35:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:35:04 --> Encryption Class Initialized
INFO - 2026-08-18 17:35:04 --> Form Validation Class Initialized
INFO - 2026-08-18 17:35:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:35:04 --> Pagination Class Initialized
INFO - 2026-08-18 17:35:04 --> Email Class Initialized
INFO - 2026-08-18 17:35:04 --> Controller Class Initialized
DEBUG - 2026-08-18 17:35:04 --> Cart MX_Controller Initialized
INFO - 2026-08-18 17:35:04 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 17:35:04 --> Model "Auth_model" initialized
INFO - 2026-08-18 17:35:04 --> Model "Cart_model" initialized
INFO - 2026-08-18 17:35:04 --> Model "Common_model" initialized
INFO - 2026-08-18 17:35:04 --> Model "Order_model" initialized
INFO - 2026-08-18 17:35:04 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 17:35:04 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 17:35:04 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 17:35:04 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 17:35:04 --> Model "Plan_model" initialized
INFO - 2026-08-18 17:35:04 --> Model "Orderlicense_model" initialized
INFO - 2026-08-18 17:35:04 --> Final output sent to browser
DEBUG - 2026-08-18 17:35:04 --> Total execution time: 2.0995
INFO - 2026-08-18 17:35:09 --> Config Class Initialized
INFO - 2026-08-18 17:35:09 --> Hooks Class Initialized
DEBUG - 2026-08-18 17:35:09 --> UTF-8 Support Enabled
INFO - 2026-08-18 17:35:09 --> Utf8 Class Initialized
INFO - 2026-08-18 17:35:09 --> URI Class Initialized
INFO - 2026-08-18 17:35:09 --> Router Class Initialized
INFO - 2026-08-18 17:35:09 --> Output Class Initialized
INFO - 2026-08-18 17:35:09 --> Security Class Initialized
DEBUG - 2026-08-18 17:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 17:35:09 --> CSRF cookie sent
INFO - 2026-08-18 17:35:09 --> Input Class Initialized
INFO - 2026-08-18 17:35:09 --> Language Class Initialized
INFO - 2026-08-18 17:35:09 --> Language Class Initialized
INFO - 2026-08-18 17:35:09 --> Config Class Initialized
INFO - 2026-08-18 17:35:09 --> Loader Class Initialized
INFO - 2026-08-18 17:35:09 --> Helper loaded: url_helper
INFO - 2026-08-18 17:35:09 --> Helper loaded: form_helper
INFO - 2026-08-18 17:35:09 --> Helper loaded: html_helper
INFO - 2026-08-18 17:35:09 --> Helper loaded: file_helper
INFO - 2026-08-18 17:35:09 --> Helper loaded: email_helper
INFO - 2026-08-18 17:35:09 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 17:35:09 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:35:09 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 17:35:09 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:35:09 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:35:09 --> Helper loaded: domain_helper
INFO - 2026-08-18 17:35:09 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 17:35:09 --> Database Driver Class Initialized
INFO - 2026-08-18 17:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:35:12 --> Upload Class Initialized
DEBUG - 2026-08-18 17:35:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:35:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:35:12 --> Encryption Class Initialized
INFO - 2026-08-18 17:35:12 --> Form Validation Class Initialized
INFO - 2026-08-18 17:35:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:35:12 --> Pagination Class Initialized
INFO - 2026-08-18 17:35:12 --> Email Class Initialized
INFO - 2026-08-18 17:35:12 --> Controller Class Initialized
DEBUG - 2026-08-18 17:35:12 --> Auth MX_Controller Initialized
INFO - 2026-08-18 17:35:12 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 17:35:12 --> Model "Auth_model" initialized
INFO - 2026-08-18 17:35:12 --> Model "Cart_model" initialized
INFO - 2026-08-18 17:35:12 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-18 17:35:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-18 17:35:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-18 17:35:16 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-18 17:35:16 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-08-18 17:35:16 --> Final output sent to browser
DEBUG - 2026-08-18 17:35:16 --> Total execution time: 7.0060
INFO - 2026-08-18 17:35:16 --> Config Class Initialized
INFO - 2026-08-18 17:35:16 --> Hooks Class Initialized
DEBUG - 2026-08-18 17:35:16 --> UTF-8 Support Enabled
INFO - 2026-08-18 17:35:16 --> Utf8 Class Initialized
INFO - 2026-08-18 17:35:16 --> URI Class Initialized
INFO - 2026-08-18 17:35:16 --> Router Class Initialized
INFO - 2026-08-18 17:35:16 --> Output Class Initialized
INFO - 2026-08-18 17:35:16 --> Security Class Initialized
DEBUG - 2026-08-18 17:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 17:35:16 --> CSRF cookie sent
INFO - 2026-08-18 17:35:16 --> Input Class Initialized
INFO - 2026-08-18 17:35:16 --> Language Class Initialized
INFO - 2026-08-18 17:35:16 --> Language Class Initialized
INFO - 2026-08-18 17:35:16 --> Config Class Initialized
INFO - 2026-08-18 17:35:16 --> Loader Class Initialized
INFO - 2026-08-18 17:35:16 --> Helper loaded: url_helper
INFO - 2026-08-18 17:35:16 --> Helper loaded: form_helper
INFO - 2026-08-18 17:35:16 --> Helper loaded: html_helper
INFO - 2026-08-18 17:35:16 --> Helper loaded: file_helper
INFO - 2026-08-18 17:35:16 --> Helper loaded: email_helper
INFO - 2026-08-18 17:35:16 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 17:35:16 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:35:16 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 17:35:16 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:35:16 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:35:16 --> Helper loaded: domain_helper
INFO - 2026-08-18 17:35:16 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 17:35:16 --> Database Driver Class Initialized
INFO - 2026-08-18 17:35:16 --> Config Class Initialized
INFO - 2026-08-18 17:35:16 --> Hooks Class Initialized
DEBUG - 2026-08-18 17:35:16 --> UTF-8 Support Enabled
INFO - 2026-08-18 17:35:16 --> Utf8 Class Initialized
INFO - 2026-08-18 17:35:16 --> URI Class Initialized
INFO - 2026-08-18 17:35:16 --> Router Class Initialized
INFO - 2026-08-18 17:35:16 --> Output Class Initialized
INFO - 2026-08-18 17:35:16 --> Security Class Initialized
DEBUG - 2026-08-18 17:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 17:35:16 --> CSRF cookie sent
INFO - 2026-08-18 17:35:16 --> CSRF token verified
INFO - 2026-08-18 17:35:16 --> Input Class Initialized
INFO - 2026-08-18 17:35:16 --> Language Class Initialized
INFO - 2026-08-18 17:35:16 --> Language Class Initialized
INFO - 2026-08-18 17:35:16 --> Config Class Initialized
INFO - 2026-08-18 17:35:16 --> Loader Class Initialized
INFO - 2026-08-18 17:35:16 --> Helper loaded: url_helper
INFO - 2026-08-18 17:35:16 --> Helper loaded: form_helper
INFO - 2026-08-18 17:35:16 --> Helper loaded: html_helper
INFO - 2026-08-18 17:35:16 --> Helper loaded: file_helper
INFO - 2026-08-18 17:35:16 --> Helper loaded: email_helper
INFO - 2026-08-18 17:35:16 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 17:35:16 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:35:16 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 17:35:16 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:35:16 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:35:16 --> Helper loaded: domain_helper
INFO - 2026-08-18 17:35:16 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 17:35:16 --> Database Driver Class Initialized
INFO - 2026-08-18 17:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:35:19 --> Upload Class Initialized
DEBUG - 2026-08-18 17:35:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:35:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:35:19 --> Encryption Class Initialized
INFO - 2026-08-18 17:35:19 --> Form Validation Class Initialized
INFO - 2026-08-18 17:35:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:35:19 --> Pagination Class Initialized
INFO - 2026-08-18 17:35:19 --> Email Class Initialized
INFO - 2026-08-18 17:35:19 --> Controller Class Initialized
DEBUG - 2026-08-18 17:35:19 --> Cart MX_Controller Initialized
INFO - 2026-08-18 17:35:19 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 17:35:19 --> Model "Auth_model" initialized
INFO - 2026-08-18 17:35:19 --> Model "Cart_model" initialized
INFO - 2026-08-18 17:35:19 --> Model "Common_model" initialized
INFO - 2026-08-18 17:35:19 --> Model "Order_model" initialized
INFO - 2026-08-18 17:35:19 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 17:35:19 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 17:35:19 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 17:35:19 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 17:35:19 --> Model "Plan_model" initialized
INFO - 2026-08-18 17:35:19 --> Model "Orderlicense_model" initialized
INFO - 2026-08-18 17:35:19 --> Final output sent to browser
DEBUG - 2026-08-18 17:35:19 --> Total execution time: 2.7057
INFO - 2026-08-18 17:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:35:20 --> Upload Class Initialized
DEBUG - 2026-08-18 17:35:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:35:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:35:20 --> Encryption Class Initialized
INFO - 2026-08-18 17:35:20 --> Form Validation Class Initialized
INFO - 2026-08-18 17:35:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:35:20 --> Pagination Class Initialized
INFO - 2026-08-18 17:35:20 --> Email Class Initialized
INFO - 2026-08-18 17:35:20 --> Controller Class Initialized
DEBUG - 2026-08-18 17:35:20 --> Auth MX_Controller Initialized
INFO - 2026-08-18 17:35:20 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 17:35:20 --> Model "Auth_model" initialized
INFO - 2026-08-18 17:35:20 --> Model "Cart_model" initialized
INFO - 2026-08-18 17:35:20 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 17:35:23 --> Config Class Initialized
INFO - 2026-08-18 17:35:23 --> Hooks Class Initialized
DEBUG - 2026-08-18 17:35:23 --> UTF-8 Support Enabled
INFO - 2026-08-18 17:35:23 --> Utf8 Class Initialized
INFO - 2026-08-18 17:35:23 --> URI Class Initialized
INFO - 2026-08-18 17:35:23 --> Router Class Initialized
INFO - 2026-08-18 17:35:23 --> Output Class Initialized
INFO - 2026-08-18 17:35:23 --> Security Class Initialized
DEBUG - 2026-08-18 17:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 17:35:23 --> CSRF cookie sent
INFO - 2026-08-18 17:35:23 --> Input Class Initialized
INFO - 2026-08-18 17:35:23 --> Language Class Initialized
INFO - 2026-08-18 17:35:23 --> Language Class Initialized
INFO - 2026-08-18 17:35:23 --> Config Class Initialized
INFO - 2026-08-18 17:35:23 --> Loader Class Initialized
INFO - 2026-08-18 17:35:23 --> Helper loaded: url_helper
INFO - 2026-08-18 17:35:23 --> Helper loaded: form_helper
INFO - 2026-08-18 17:35:23 --> Helper loaded: html_helper
INFO - 2026-08-18 17:35:23 --> Helper loaded: file_helper
INFO - 2026-08-18 17:35:23 --> Helper loaded: email_helper
INFO - 2026-08-18 17:35:23 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 17:35:23 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:35:23 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 17:35:23 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:35:23 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:35:23 --> Helper loaded: domain_helper
INFO - 2026-08-18 17:35:23 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 17:35:23 --> Database Driver Class Initialized
INFO - 2026-08-18 17:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:35:25 --> Upload Class Initialized
DEBUG - 2026-08-18 17:35:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:35:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:35:25 --> Encryption Class Initialized
INFO - 2026-08-18 17:35:25 --> Form Validation Class Initialized
INFO - 2026-08-18 17:35:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:35:25 --> Pagination Class Initialized
INFO - 2026-08-18 17:35:25 --> Email Class Initialized
INFO - 2026-08-18 17:35:25 --> Controller Class Initialized
DEBUG - 2026-08-18 17:35:25 --> Clientarea MX_Controller Initialized
INFO - 2026-08-18 17:35:25 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 17:35:25 --> Model "Auth_model" initialized
INFO - 2026-08-18 17:35:25 --> Model "Cart_model" initialized
INFO - 2026-08-18 17:35:25 --> Model "Clientarea_model" initialized
INFO - 2026-08-18 17:35:25 --> Model "Billing_model" initialized
INFO - 2026-08-18 17:35:25 --> Model "Common_model" initialized
INFO - 2026-08-18 17:35:25 --> Model "Order_model" initialized
INFO - 2026-08-18 17:35:25 --> Model "Support_model" initialized
INFO - 2026-08-18 17:35:25 --> Model "Subscription_model" initialized
INFO - 2026-08-18 17:35:25 --> Model "Software_model" initialized
DEBUG - 2026-08-18 17:35:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-18 17:35:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-18 17:35:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-18 17:35:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_index.php
INFO - 2026-08-18 17:35:26 --> Final output sent to browser
DEBUG - 2026-08-18 17:35:26 --> Total execution time: 3.7636
INFO - 2026-08-18 17:35:26 --> Config Class Initialized
INFO - 2026-08-18 17:35:26 --> Config Class Initialized
INFO - 2026-08-18 17:35:26 --> Hooks Class Initialized
INFO - 2026-08-18 17:35:26 --> Hooks Class Initialized
DEBUG - 2026-08-18 17:35:26 --> UTF-8 Support Enabled
DEBUG - 2026-08-18 17:35:26 --> UTF-8 Support Enabled
INFO - 2026-08-18 17:35:26 --> Utf8 Class Initialized
INFO - 2026-08-18 17:35:26 --> Utf8 Class Initialized
INFO - 2026-08-18 17:35:26 --> URI Class Initialized
INFO - 2026-08-18 17:35:26 --> URI Class Initialized
INFO - 2026-08-18 17:35:26 --> Router Class Initialized
INFO - 2026-08-18 17:35:26 --> Router Class Initialized
INFO - 2026-08-18 17:35:26 --> Output Class Initialized
INFO - 2026-08-18 17:35:26 --> Output Class Initialized
INFO - 2026-08-18 17:35:26 --> Security Class Initialized
INFO - 2026-08-18 17:35:26 --> Security Class Initialized
DEBUG - 2026-08-18 17:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-08-18 17:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 17:35:26 --> CSRF cookie sent
INFO - 2026-08-18 17:35:26 --> Input Class Initialized
INFO - 2026-08-18 17:35:26 --> CSRF cookie sent
INFO - 2026-08-18 17:35:26 --> Input Class Initialized
INFO - 2026-08-18 17:35:26 --> Language Class Initialized
INFO - 2026-08-18 17:35:26 --> Language Class Initialized
INFO - 2026-08-18 17:35:26 --> Language Class Initialized
INFO - 2026-08-18 17:35:26 --> Language Class Initialized
INFO - 2026-08-18 17:35:26 --> Config Class Initialized
INFO - 2026-08-18 17:35:26 --> Config Class Initialized
INFO - 2026-08-18 17:35:26 --> Loader Class Initialized
INFO - 2026-08-18 17:35:26 --> Loader Class Initialized
INFO - 2026-08-18 17:35:26 --> Helper loaded: url_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: url_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: form_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: form_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: html_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: html_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: file_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: file_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: email_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: email_helper
INFO - 2026-08-18 17:35:26 --> Config Class Initialized
INFO - 2026-08-18 17:35:26 --> Hooks Class Initialized
INFO - 2026-08-18 17:35:26 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: whmaz_helper
DEBUG - 2026-08-18 17:35:26 --> UTF-8 Support Enabled
INFO - 2026-08-18 17:35:26 --> Utf8 Class Initialized
INFO - 2026-08-18 17:35:26 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:35:26 --> URI Class Initialized
INFO - 2026-08-18 17:35:26 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 17:35:26 --> Config Class Initialized
INFO - 2026-08-18 17:35:26 --> Hooks Class Initialized
INFO - 2026-08-18 17:35:26 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 17:35:26 --> Router Class Initialized
INFO - 2026-08-18 17:35:26 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:35:26 --> Output Class Initialized
INFO - 2026-08-18 17:35:26 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:35:26 --> Security Class Initialized
INFO - 2026-08-18 17:35:26 --> Config Class Initialized
INFO - 2026-08-18 17:35:26 --> Hooks Class Initialized
INFO - 2026-08-18 17:35:26 --> Helper loaded: domain_helper
DEBUG - 2026-08-18 17:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 17:35:26 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 17:35:26 --> Input Class Initialized
INFO - 2026-08-18 17:35:26 --> Language Class Initialized
INFO - 2026-08-18 17:35:26 --> Language Class Initialized
INFO - 2026-08-18 17:35:26 --> Config Class Initialized
DEBUG - 2026-08-18 17:35:26 --> UTF-8 Support Enabled
INFO - 2026-08-18 17:35:26 --> Utf8 Class Initialized
INFO - 2026-08-18 17:35:26 --> Helper loaded: domain_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 17:35:26 --> URI Class Initialized
DEBUG - 2026-08-18 17:35:26 --> UTF-8 Support Enabled
INFO - 2026-08-18 17:35:26 --> Utf8 Class Initialized
INFO - 2026-08-18 17:35:26 --> Loader Class Initialized
INFO - 2026-08-18 17:35:26 --> URI Class Initialized
INFO - 2026-08-18 17:35:26 --> Helper loaded: url_helper
INFO - 2026-08-18 17:35:26 --> Router Class Initialized
INFO - 2026-08-18 17:35:26 --> Helper loaded: form_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: html_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: file_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: email_helper
INFO - 2026-08-18 17:35:26 --> Router Class Initialized
INFO - 2026-08-18 17:35:26 --> Output Class Initialized
INFO - 2026-08-18 17:35:26 --> Database Driver Class Initialized
INFO - 2026-08-18 17:35:26 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 17:35:26 --> Output Class Initialized
INFO - 2026-08-18 17:35:26 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:35:26 --> Security Class Initialized
INFO - 2026-08-18 17:35:26 --> Security Class Initialized
DEBUG - 2026-08-18 17:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 17:35:26 --> Helper loaded: cpanel_helper
DEBUG - 2026-08-18 17:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 17:35:26 --> Database Driver Class Initialized
INFO - 2026-08-18 17:35:26 --> Input Class Initialized
INFO - 2026-08-18 17:35:26 --> Input Class Initialized
INFO - 2026-08-18 17:35:26 --> Language Class Initialized
INFO - 2026-08-18 17:35:26 --> Language Class Initialized
INFO - 2026-08-18 17:35:26 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:35:26 --> Language Class Initialized
INFO - 2026-08-18 17:35:26 --> Config Class Initialized
INFO - 2026-08-18 17:35:26 --> Language Class Initialized
INFO - 2026-08-18 17:35:26 --> Config Class Initialized
INFO - 2026-08-18 17:35:26 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:35:26 --> Loader Class Initialized
INFO - 2026-08-18 17:35:26 --> Loader Class Initialized
INFO - 2026-08-18 17:35:26 --> Helper loaded: url_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: url_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: form_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: form_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: html_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: html_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: domain_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: file_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: email_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: file_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: email_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: domain_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: domain_helper
INFO - 2026-08-18 17:35:26 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 17:35:26 --> Database Driver Class Initialized
INFO - 2026-08-18 17:35:26 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 17:35:26 --> Database Driver Class Initialized
INFO - 2026-08-18 17:35:26 --> Database Driver Class Initialized
INFO - 2026-08-18 17:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:35:28 --> Upload Class Initialized
DEBUG - 2026-08-18 17:35:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:35:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:35:28 --> Encryption Class Initialized
INFO - 2026-08-18 17:35:28 --> Form Validation Class Initialized
INFO - 2026-08-18 17:35:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:35:28 --> Pagination Class Initialized
INFO - 2026-08-18 17:35:28 --> Email Class Initialized
INFO - 2026-08-18 17:35:28 --> Controller Class Initialized
DEBUG - 2026-08-18 17:35:28 --> Clientarea MX_Controller Initialized
INFO - 2026-08-18 17:35:28 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 17:35:28 --> Model "Auth_model" initialized
INFO - 2026-08-18 17:35:28 --> Model "Cart_model" initialized
INFO - 2026-08-18 17:35:28 --> Model "Clientarea_model" initialized
INFO - 2026-08-18 17:35:28 --> Model "Billing_model" initialized
INFO - 2026-08-18 17:35:28 --> Model "Common_model" initialized
INFO - 2026-08-18 17:35:28 --> Model "Order_model" initialized
INFO - 2026-08-18 17:35:28 --> Model "Support_model" initialized
INFO - 2026-08-18 17:35:29 --> Final output sent to browser
DEBUG - 2026-08-18 17:35:29 --> Total execution time: 2.5503
INFO - 2026-08-18 17:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:35:29 --> Upload Class Initialized
DEBUG - 2026-08-18 17:35:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:35:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:35:29 --> Encryption Class Initialized
INFO - 2026-08-18 17:35:29 --> Form Validation Class Initialized
INFO - 2026-08-18 17:35:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:35:29 --> Pagination Class Initialized
INFO - 2026-08-18 17:35:29 --> Email Class Initialized
INFO - 2026-08-18 17:35:29 --> Controller Class Initialized
DEBUG - 2026-08-18 17:35:29 --> Cart MX_Controller Initialized
INFO - 2026-08-18 17:35:29 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 17:35:29 --> Model "Auth_model" initialized
INFO - 2026-08-18 17:35:29 --> Model "Cart_model" initialized
INFO - 2026-08-18 17:35:29 --> Model "Common_model" initialized
INFO - 2026-08-18 17:35:29 --> Model "Order_model" initialized
INFO - 2026-08-18 17:35:29 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 17:35:29 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 17:35:29 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 17:35:29 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 17:35:29 --> Model "Plan_model" initialized
INFO - 2026-08-18 17:35:29 --> Model "Orderlicense_model" initialized
INFO - 2026-08-18 17:35:30 --> Final output sent to browser
DEBUG - 2026-08-18 17:35:30 --> Total execution time: 3.9037
INFO - 2026-08-18 17:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:35:30 --> Upload Class Initialized
DEBUG - 2026-08-18 17:35:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:35:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:35:30 --> Encryption Class Initialized
INFO - 2026-08-18 17:35:30 --> Form Validation Class Initialized
INFO - 2026-08-18 17:35:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:35:30 --> Pagination Class Initialized
INFO - 2026-08-18 17:35:30 --> Email Class Initialized
INFO - 2026-08-18 17:35:30 --> Controller Class Initialized
DEBUG - 2026-08-18 17:35:30 --> Tickets MX_Controller Initialized
INFO - 2026-08-18 17:35:30 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 17:35:30 --> Model "Auth_model" initialized
INFO - 2026-08-18 17:35:30 --> Model "Cart_model" initialized
INFO - 2026-08-18 17:35:30 --> Model "Support_model" initialized
INFO - 2026-08-18 17:35:30 --> Model "Common_model" initialized
INFO - 2026-08-18 17:35:31 --> Final output sent to browser
DEBUG - 2026-08-18 17:35:31 --> Total execution time: 4.5998
INFO - 2026-08-18 17:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:35:31 --> Upload Class Initialized
DEBUG - 2026-08-18 17:35:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:35:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:35:31 --> Encryption Class Initialized
INFO - 2026-08-18 17:35:31 --> Form Validation Class Initialized
INFO - 2026-08-18 17:35:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:35:31 --> Pagination Class Initialized
INFO - 2026-08-18 17:35:31 --> Email Class Initialized
INFO - 2026-08-18 17:35:31 --> Controller Class Initialized
DEBUG - 2026-08-18 17:35:31 --> Invoicing MX_Controller Initialized
INFO - 2026-08-18 17:35:31 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 17:35:31 --> Model "Auth_model" initialized
INFO - 2026-08-18 17:35:31 --> Model "Cart_model" initialized
INFO - 2026-08-18 17:35:31 --> Model "Billing_model" initialized
INFO - 2026-08-18 17:35:31 --> Model "Common_model" initialized
INFO - 2026-08-18 17:35:31 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 17:35:32 --> Final output sent to browser
DEBUG - 2026-08-18 17:35:32 --> Total execution time: 5.3205
INFO - 2026-08-18 17:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:35:32 --> Upload Class Initialized
DEBUG - 2026-08-18 17:35:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:35:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:35:32 --> Encryption Class Initialized
INFO - 2026-08-18 17:35:32 --> Form Validation Class Initialized
INFO - 2026-08-18 17:35:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:35:32 --> Pagination Class Initialized
INFO - 2026-08-18 17:35:32 --> Email Class Initialized
INFO - 2026-08-18 17:35:32 --> Controller Class Initialized
DEBUG - 2026-08-18 17:35:32 --> Notifications MX_Controller Initialized
INFO - 2026-08-18 17:35:32 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 17:35:32 --> Model "Auth_model" initialized
INFO - 2026-08-18 17:35:32 --> Model "Cart_model" initialized
INFO - 2026-08-18 17:35:32 --> Model "Notification_model" initialized
INFO - 2026-08-18 17:35:35 --> Config Class Initialized
INFO - 2026-08-18 17:35:35 --> Hooks Class Initialized
DEBUG - 2026-08-18 17:35:35 --> UTF-8 Support Enabled
INFO - 2026-08-18 17:35:35 --> Utf8 Class Initialized
INFO - 2026-08-18 17:35:35 --> URI Class Initialized
INFO - 2026-08-18 17:35:35 --> Router Class Initialized
INFO - 2026-08-18 17:35:35 --> Output Class Initialized
INFO - 2026-08-18 17:35:35 --> Security Class Initialized
DEBUG - 2026-08-18 17:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 17:35:35 --> CSRF cookie sent
INFO - 2026-08-18 17:35:35 --> Input Class Initialized
INFO - 2026-08-18 17:35:35 --> Language Class Initialized
INFO - 2026-08-18 17:35:35 --> Language Class Initialized
INFO - 2026-08-18 17:35:35 --> Config Class Initialized
INFO - 2026-08-18 17:35:35 --> Loader Class Initialized
INFO - 2026-08-18 17:35:35 --> Helper loaded: url_helper
INFO - 2026-08-18 17:35:35 --> Helper loaded: form_helper
INFO - 2026-08-18 17:35:35 --> Helper loaded: html_helper
INFO - 2026-08-18 17:35:35 --> Helper loaded: file_helper
INFO - 2026-08-18 17:35:35 --> Helper loaded: email_helper
INFO - 2026-08-18 17:35:35 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 17:35:35 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:35:35 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 17:35:35 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:35:35 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:35:35 --> Helper loaded: domain_helper
INFO - 2026-08-18 17:35:35 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 17:35:35 --> Database Driver Class Initialized
INFO - 2026-08-18 17:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:35:36 --> Upload Class Initialized
DEBUG - 2026-08-18 17:35:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:35:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:35:36 --> Encryption Class Initialized
INFO - 2026-08-18 17:35:36 --> Form Validation Class Initialized
INFO - 2026-08-18 17:35:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:35:36 --> Pagination Class Initialized
INFO - 2026-08-18 17:35:36 --> Email Class Initialized
INFO - 2026-08-18 17:35:36 --> Controller Class Initialized
DEBUG - 2026-08-18 17:35:36 --> Clientarea MX_Controller Initialized
INFO - 2026-08-18 17:35:36 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 17:35:36 --> Model "Auth_model" initialized
INFO - 2026-08-18 17:35:36 --> Model "Cart_model" initialized
INFO - 2026-08-18 17:35:36 --> Model "Clientarea_model" initialized
INFO - 2026-08-18 17:35:36 --> Model "Billing_model" initialized
INFO - 2026-08-18 17:35:36 --> Model "Common_model" initialized
INFO - 2026-08-18 17:35:36 --> Model "Order_model" initialized
INFO - 2026-08-18 17:35:36 --> Model "Support_model" initialized
INFO - 2026-08-18 17:35:37 --> Model "Subscription_model" initialized
INFO - 2026-08-18 17:35:37 --> Model "Software_model" initialized
DEBUG - 2026-08-18 17:35:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-18 17:35:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-18 17:35:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-18 17:35:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_index.php
INFO - 2026-08-18 17:35:38 --> Final output sent to browser
DEBUG - 2026-08-18 17:35:38 --> Total execution time: 3.6868
INFO - 2026-08-18 17:35:38 --> Config Class Initialized
INFO - 2026-08-18 17:35:38 --> Hooks Class Initialized
DEBUG - 2026-08-18 17:35:38 --> UTF-8 Support Enabled
INFO - 2026-08-18 17:35:38 --> Utf8 Class Initialized
INFO - 2026-08-18 17:35:38 --> URI Class Initialized
INFO - 2026-08-18 17:35:38 --> Config Class Initialized
INFO - 2026-08-18 17:35:38 --> Hooks Class Initialized
INFO - 2026-08-18 17:35:38 --> Router Class Initialized
DEBUG - 2026-08-18 17:35:38 --> UTF-8 Support Enabled
INFO - 2026-08-18 17:35:38 --> Utf8 Class Initialized
INFO - 2026-08-18 17:35:38 --> URI Class Initialized
INFO - 2026-08-18 17:35:38 --> Output Class Initialized
INFO - 2026-08-18 17:35:38 --> Security Class Initialized
DEBUG - 2026-08-18 17:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 17:35:38 --> CSRF cookie sent
INFO - 2026-08-18 17:35:38 --> Input Class Initialized
INFO - 2026-08-18 17:35:38 --> Language Class Initialized
INFO - 2026-08-18 17:35:38 --> Router Class Initialized
INFO - 2026-08-18 17:35:38 --> Language Class Initialized
INFO - 2026-08-18 17:35:38 --> Config Class Initialized
INFO - 2026-08-18 17:35:38 --> Output Class Initialized
INFO - 2026-08-18 17:35:38 --> Security Class Initialized
DEBUG - 2026-08-18 17:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 17:35:38 --> CSRF cookie sent
INFO - 2026-08-18 17:35:38 --> Input Class Initialized
INFO - 2026-08-18 17:35:38 --> Loader Class Initialized
INFO - 2026-08-18 17:35:38 --> Language Class Initialized
INFO - 2026-08-18 17:35:38 --> Language Class Initialized
INFO - 2026-08-18 17:35:38 --> Config Class Initialized
INFO - 2026-08-18 17:35:38 --> Helper loaded: url_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: form_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: html_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: file_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: email_helper
INFO - 2026-08-18 17:35:38 --> Loader Class Initialized
INFO - 2026-08-18 17:35:38 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: url_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: form_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: html_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: file_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: email_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:35:38 --> Config Class Initialized
INFO - 2026-08-18 17:35:38 --> Hooks Class Initialized
INFO - 2026-08-18 17:35:38 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: domain_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: entitlement_helper
DEBUG - 2026-08-18 17:35:38 --> UTF-8 Support Enabled
INFO - 2026-08-18 17:35:38 --> Utf8 Class Initialized
INFO - 2026-08-18 17:35:38 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:35:38 --> URI Class Initialized
INFO - 2026-08-18 17:35:38 --> Config Class Initialized
INFO - 2026-08-18 17:35:38 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:35:38 --> Hooks Class Initialized
INFO - 2026-08-18 17:35:38 --> Config Class Initialized
INFO - 2026-08-18 17:35:38 --> Hooks Class Initialized
INFO - 2026-08-18 17:35:38 --> Router Class Initialized
DEBUG - 2026-08-18 17:35:38 --> UTF-8 Support Enabled
INFO - 2026-08-18 17:35:38 --> Utf8 Class Initialized
DEBUG - 2026-08-18 17:35:38 --> UTF-8 Support Enabled
INFO - 2026-08-18 17:35:38 --> URI Class Initialized
INFO - 2026-08-18 17:35:38 --> Utf8 Class Initialized
INFO - 2026-08-18 17:35:38 --> Output Class Initialized
INFO - 2026-08-18 17:35:38 --> URI Class Initialized
INFO - 2026-08-18 17:35:38 --> Helper loaded: domain_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 17:35:38 --> Security Class Initialized
INFO - 2026-08-18 17:35:38 --> Database Driver Class Initialized
INFO - 2026-08-18 17:35:38 --> Router Class Initialized
DEBUG - 2026-08-18 17:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 17:35:38 --> Router Class Initialized
INFO - 2026-08-18 17:35:38 --> Input Class Initialized
INFO - 2026-08-18 17:35:38 --> Language Class Initialized
INFO - 2026-08-18 17:35:38 --> Output Class Initialized
INFO - 2026-08-18 17:35:38 --> Language Class Initialized
INFO - 2026-08-18 17:35:38 --> Config Class Initialized
INFO - 2026-08-18 17:35:38 --> Output Class Initialized
INFO - 2026-08-18 17:35:38 --> Security Class Initialized
INFO - 2026-08-18 17:35:38 --> Security Class Initialized
INFO - 2026-08-18 17:35:38 --> Loader Class Initialized
DEBUG - 2026-08-18 17:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 17:35:38 --> Helper loaded: url_helper
INFO - 2026-08-18 17:35:38 --> Input Class Initialized
DEBUG - 2026-08-18 17:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 17:35:38 --> Language Class Initialized
INFO - 2026-08-18 17:35:38 --> Helper loaded: form_helper
INFO - 2026-08-18 17:35:38 --> Input Class Initialized
INFO - 2026-08-18 17:35:38 --> Helper loaded: html_helper
INFO - 2026-08-18 17:35:38 --> Language Class Initialized
INFO - 2026-08-18 17:35:38 --> Language Class Initialized
INFO - 2026-08-18 17:35:38 --> Config Class Initialized
INFO - 2026-08-18 17:35:38 --> Helper loaded: file_helper
INFO - 2026-08-18 17:35:38 --> Database Driver Class Initialized
INFO - 2026-08-18 17:35:38 --> Helper loaded: email_helper
INFO - 2026-08-18 17:35:38 --> Language Class Initialized
INFO - 2026-08-18 17:35:38 --> Config Class Initialized
INFO - 2026-08-18 17:35:38 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:35:38 --> Loader Class Initialized
INFO - 2026-08-18 17:35:38 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 17:35:38 --> Loader Class Initialized
INFO - 2026-08-18 17:35:38 --> Helper loaded: url_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: url_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: form_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: html_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: form_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: file_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: email_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: html_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: file_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: email_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: domain_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:35:38 --> Database Driver Class Initialized
INFO - 2026-08-18 17:35:38 --> Helper loaded: domain_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: domain_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 17:35:38 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 17:35:38 --> Database Driver Class Initialized
INFO - 2026-08-18 17:35:38 --> Database Driver Class Initialized
INFO - 2026-08-18 17:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:35:40 --> Upload Class Initialized
DEBUG - 2026-08-18 17:35:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:35:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:35:40 --> Encryption Class Initialized
INFO - 2026-08-18 17:35:40 --> Form Validation Class Initialized
INFO - 2026-08-18 17:35:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:35:40 --> Pagination Class Initialized
INFO - 2026-08-18 17:35:40 --> Email Class Initialized
INFO - 2026-08-18 17:35:40 --> Controller Class Initialized
DEBUG - 2026-08-18 17:35:40 --> Clientarea MX_Controller Initialized
INFO - 2026-08-18 17:35:40 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 17:35:40 --> Model "Auth_model" initialized
INFO - 2026-08-18 17:35:40 --> Model "Cart_model" initialized
INFO - 2026-08-18 17:35:40 --> Model "Clientarea_model" initialized
INFO - 2026-08-18 17:35:40 --> Model "Billing_model" initialized
INFO - 2026-08-18 17:35:40 --> Model "Common_model" initialized
INFO - 2026-08-18 17:35:40 --> Model "Order_model" initialized
INFO - 2026-08-18 17:35:40 --> Model "Support_model" initialized
INFO - 2026-08-18 17:35:42 --> Final output sent to browser
DEBUG - 2026-08-18 17:35:42 --> Total execution time: 4.0571
INFO - 2026-08-18 17:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:35:42 --> Upload Class Initialized
DEBUG - 2026-08-18 17:35:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:35:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:35:42 --> Encryption Class Initialized
INFO - 2026-08-18 17:35:42 --> Form Validation Class Initialized
INFO - 2026-08-18 17:35:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:35:42 --> Pagination Class Initialized
INFO - 2026-08-18 17:35:42 --> Email Class Initialized
INFO - 2026-08-18 17:35:42 --> Controller Class Initialized
DEBUG - 2026-08-18 17:35:42 --> Invoicing MX_Controller Initialized
INFO - 2026-08-18 17:35:42 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 17:35:42 --> Model "Auth_model" initialized
INFO - 2026-08-18 17:35:42 --> Model "Cart_model" initialized
INFO - 2026-08-18 17:35:42 --> Model "Billing_model" initialized
INFO - 2026-08-18 17:35:42 --> Model "Common_model" initialized
INFO - 2026-08-18 17:35:42 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 17:35:44 --> Final output sent to browser
DEBUG - 2026-08-18 17:35:44 --> Total execution time: 6.0481
INFO - 2026-08-18 17:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:35:44 --> Upload Class Initialized
DEBUG - 2026-08-18 17:35:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:35:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:35:44 --> Encryption Class Initialized
INFO - 2026-08-18 17:35:44 --> Form Validation Class Initialized
INFO - 2026-08-18 17:35:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:35:44 --> Pagination Class Initialized
INFO - 2026-08-18 17:35:44 --> Email Class Initialized
INFO - 2026-08-18 17:35:44 --> Controller Class Initialized
DEBUG - 2026-08-18 17:35:44 --> Notifications MX_Controller Initialized
INFO - 2026-08-18 17:35:44 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 17:35:44 --> Model "Auth_model" initialized
INFO - 2026-08-18 17:35:44 --> Model "Cart_model" initialized
INFO - 2026-08-18 17:35:44 --> Model "Notification_model" initialized
INFO - 2026-08-18 17:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:35:46 --> Upload Class Initialized
DEBUG - 2026-08-18 17:35:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:35:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:35:46 --> Encryption Class Initialized
INFO - 2026-08-18 17:35:46 --> Form Validation Class Initialized
INFO - 2026-08-18 17:35:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:35:46 --> Pagination Class Initialized
INFO - 2026-08-18 17:35:46 --> Email Class Initialized
INFO - 2026-08-18 17:35:46 --> Controller Class Initialized
DEBUG - 2026-08-18 17:35:46 --> Tickets MX_Controller Initialized
INFO - 2026-08-18 17:35:46 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 17:35:46 --> Model "Auth_model" initialized
INFO - 2026-08-18 17:35:46 --> Model "Cart_model" initialized
INFO - 2026-08-18 17:35:46 --> Model "Support_model" initialized
INFO - 2026-08-18 17:35:46 --> Model "Common_model" initialized
INFO - 2026-08-18 17:35:47 --> Final output sent to browser
DEBUG - 2026-08-18 17:35:47 --> Total execution time: 8.2777
INFO - 2026-08-18 17:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:35:47 --> Upload Class Initialized
DEBUG - 2026-08-18 17:35:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:35:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:35:47 --> Encryption Class Initialized
INFO - 2026-08-18 17:35:47 --> Form Validation Class Initialized
INFO - 2026-08-18 17:35:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:35:47 --> Pagination Class Initialized
INFO - 2026-08-18 17:35:47 --> Email Class Initialized
INFO - 2026-08-18 17:35:47 --> Controller Class Initialized
DEBUG - 2026-08-18 17:35:47 --> Cart MX_Controller Initialized
INFO - 2026-08-18 17:35:47 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 17:35:47 --> Model "Auth_model" initialized
INFO - 2026-08-18 17:35:47 --> Model "Cart_model" initialized
INFO - 2026-08-18 17:35:47 --> Model "Common_model" initialized
INFO - 2026-08-18 17:35:47 --> Model "Order_model" initialized
INFO - 2026-08-18 17:35:47 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 17:35:47 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 17:35:47 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 17:35:47 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 17:35:47 --> Model "Plan_model" initialized
INFO - 2026-08-18 17:35:47 --> Model "Orderlicense_model" initialized
INFO - 2026-08-18 17:35:48 --> Final output sent to browser
DEBUG - 2026-08-18 17:35:48 --> Total execution time: 9.7518
INFO - 2026-08-18 17:35:50 --> Config Class Initialized
INFO - 2026-08-18 17:35:50 --> Hooks Class Initialized
DEBUG - 2026-08-18 17:35:50 --> UTF-8 Support Enabled
INFO - 2026-08-18 17:35:50 --> Utf8 Class Initialized
INFO - 2026-08-18 17:35:50 --> URI Class Initialized
INFO - 2026-08-18 17:35:50 --> Router Class Initialized
INFO - 2026-08-18 17:35:50 --> Output Class Initialized
INFO - 2026-08-18 17:35:50 --> Security Class Initialized
DEBUG - 2026-08-18 17:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 17:35:50 --> CSRF cookie sent
INFO - 2026-08-18 17:35:50 --> Input Class Initialized
INFO - 2026-08-18 17:35:50 --> Language Class Initialized
INFO - 2026-08-18 17:35:50 --> Language Class Initialized
INFO - 2026-08-18 17:35:50 --> Config Class Initialized
INFO - 2026-08-18 17:35:50 --> Loader Class Initialized
INFO - 2026-08-18 17:35:50 --> Helper loaded: url_helper
INFO - 2026-08-18 17:35:50 --> Helper loaded: form_helper
INFO - 2026-08-18 17:35:50 --> Helper loaded: html_helper
INFO - 2026-08-18 17:35:50 --> Helper loaded: file_helper
INFO - 2026-08-18 17:35:50 --> Helper loaded: email_helper
INFO - 2026-08-18 17:35:50 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 17:35:50 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:35:50 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 17:35:50 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:35:50 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:35:50 --> Helper loaded: domain_helper
INFO - 2026-08-18 17:35:50 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 17:35:50 --> Database Driver Class Initialized
INFO - 2026-08-18 17:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:35:52 --> Upload Class Initialized
DEBUG - 2026-08-18 17:35:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:35:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:35:52 --> Encryption Class Initialized
INFO - 2026-08-18 17:35:52 --> Form Validation Class Initialized
INFO - 2026-08-18 17:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:35:52 --> Pagination Class Initialized
INFO - 2026-08-18 17:35:52 --> Email Class Initialized
INFO - 2026-08-18 17:35:52 --> Controller Class Initialized
DEBUG - 2026-08-18 17:35:52 --> Invoicing MX_Controller Initialized
INFO - 2026-08-18 17:35:52 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 17:35:52 --> Model "Auth_model" initialized
INFO - 2026-08-18 17:35:52 --> Model "Cart_model" initialized
INFO - 2026-08-18 17:35:52 --> Model "Billing_model" initialized
INFO - 2026-08-18 17:35:52 --> Model "Common_model" initialized
INFO - 2026-08-18 17:35:52 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-18 17:35:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-18 17:35:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-08-18 17:35:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-18 17:35:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-18 17:35:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/invoicing/views/invoicing_invoices.php
INFO - 2026-08-18 17:35:54 --> Final output sent to browser
DEBUG - 2026-08-18 17:35:54 --> Total execution time: 3.6638
INFO - 2026-08-18 17:35:54 --> Config Class Initialized
INFO - 2026-08-18 17:35:54 --> Hooks Class Initialized
INFO - 2026-08-18 17:35:54 --> Config Class Initialized
INFO - 2026-08-18 17:35:54 --> Hooks Class Initialized
DEBUG - 2026-08-18 17:35:54 --> UTF-8 Support Enabled
INFO - 2026-08-18 17:35:54 --> Utf8 Class Initialized
INFO - 2026-08-18 17:35:54 --> URI Class Initialized
DEBUG - 2026-08-18 17:35:54 --> UTF-8 Support Enabled
INFO - 2026-08-18 17:35:54 --> Utf8 Class Initialized
INFO - 2026-08-18 17:35:54 --> URI Class Initialized
INFO - 2026-08-18 17:35:54 --> Router Class Initialized
INFO - 2026-08-18 17:35:54 --> Output Class Initialized
INFO - 2026-08-18 17:35:54 --> Router Class Initialized
INFO - 2026-08-18 17:35:54 --> Security Class Initialized
INFO - 2026-08-18 17:35:54 --> Output Class Initialized
DEBUG - 2026-08-18 17:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 17:35:54 --> CSRF cookie sent
INFO - 2026-08-18 17:35:54 --> Input Class Initialized
INFO - 2026-08-18 17:35:54 --> Language Class Initialized
INFO - 2026-08-18 17:35:54 --> Security Class Initialized
INFO - 2026-08-18 17:35:54 --> Language Class Initialized
INFO - 2026-08-18 17:35:54 --> Config Class Initialized
DEBUG - 2026-08-18 17:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 17:35:54 --> CSRF cookie sent
INFO - 2026-08-18 17:35:54 --> Input Class Initialized
INFO - 2026-08-18 17:35:54 --> Language Class Initialized
INFO - 2026-08-18 17:35:54 --> Loader Class Initialized
INFO - 2026-08-18 17:35:54 --> Language Class Initialized
INFO - 2026-08-18 17:35:54 --> Config Class Initialized
INFO - 2026-08-18 17:35:54 --> Helper loaded: url_helper
INFO - 2026-08-18 17:35:54 --> Helper loaded: form_helper
INFO - 2026-08-18 17:35:54 --> Helper loaded: html_helper
INFO - 2026-08-18 17:35:54 --> Loader Class Initialized
INFO - 2026-08-18 17:35:54 --> Helper loaded: file_helper
INFO - 2026-08-18 17:35:54 --> Helper loaded: email_helper
INFO - 2026-08-18 17:35:54 --> Helper loaded: url_helper
INFO - 2026-08-18 17:35:54 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 17:35:54 --> Helper loaded: form_helper
INFO - 2026-08-18 17:35:54 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:35:54 --> Helper loaded: html_helper
INFO - 2026-08-18 17:35:54 --> Helper loaded: file_helper
INFO - 2026-08-18 17:35:54 --> Helper loaded: email_helper
INFO - 2026-08-18 17:35:54 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 17:35:54 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 17:35:54 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:35:54 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:35:54 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:35:54 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 17:35:54 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:35:54 --> Helper loaded: domain_helper
INFO - 2026-08-18 17:35:54 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 17:35:54 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:35:54 --> Helper loaded: domain_helper
INFO - 2026-08-18 17:35:54 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 17:35:54 --> Database Driver Class Initialized
INFO - 2026-08-18 17:35:54 --> Database Driver Class Initialized
INFO - 2026-08-18 17:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:35:56 --> Upload Class Initialized
DEBUG - 2026-08-18 17:35:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:35:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:35:56 --> Encryption Class Initialized
INFO - 2026-08-18 17:35:56 --> Form Validation Class Initialized
INFO - 2026-08-18 17:35:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:35:56 --> Pagination Class Initialized
INFO - 2026-08-18 17:35:56 --> Email Class Initialized
INFO - 2026-08-18 17:35:56 --> Controller Class Initialized
DEBUG - 2026-08-18 17:35:56 --> Cart MX_Controller Initialized
INFO - 2026-08-18 17:35:56 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 17:35:56 --> Model "Auth_model" initialized
INFO - 2026-08-18 17:35:56 --> Model "Cart_model" initialized
INFO - 2026-08-18 17:35:56 --> Model "Common_model" initialized
INFO - 2026-08-18 17:35:56 --> Model "Order_model" initialized
INFO - 2026-08-18 17:35:56 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 17:35:56 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 17:35:56 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 17:35:56 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 17:35:56 --> Model "Plan_model" initialized
INFO - 2026-08-18 17:35:56 --> Model "Orderlicense_model" initialized
INFO - 2026-08-18 17:35:56 --> Final output sent to browser
DEBUG - 2026-08-18 17:35:56 --> Total execution time: 2.0798
INFO - 2026-08-18 17:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:35:56 --> Upload Class Initialized
DEBUG - 2026-08-18 17:35:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:35:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:35:56 --> Encryption Class Initialized
INFO - 2026-08-18 17:35:56 --> Form Validation Class Initialized
INFO - 2026-08-18 17:35:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:35:56 --> Pagination Class Initialized
INFO - 2026-08-18 17:35:56 --> Email Class Initialized
INFO - 2026-08-18 17:35:56 --> Controller Class Initialized
DEBUG - 2026-08-18 17:35:56 --> Notifications MX_Controller Initialized
INFO - 2026-08-18 17:35:56 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 17:35:56 --> Model "Auth_model" initialized
INFO - 2026-08-18 17:35:56 --> Model "Cart_model" initialized
INFO - 2026-08-18 17:35:56 --> Model "Notification_model" initialized
INFO - 2026-08-18 17:35:59 --> Config Class Initialized
INFO - 2026-08-18 17:35:59 --> Hooks Class Initialized
DEBUG - 2026-08-18 17:35:59 --> UTF-8 Support Enabled
INFO - 2026-08-18 17:35:59 --> Utf8 Class Initialized
INFO - 2026-08-18 17:35:59 --> URI Class Initialized
INFO - 2026-08-18 17:35:59 --> Router Class Initialized
INFO - 2026-08-18 17:35:59 --> Output Class Initialized
INFO - 2026-08-18 17:35:59 --> Security Class Initialized
DEBUG - 2026-08-18 17:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 17:35:59 --> CSRF cookie sent
INFO - 2026-08-18 17:35:59 --> Input Class Initialized
INFO - 2026-08-18 17:35:59 --> Language Class Initialized
INFO - 2026-08-18 17:35:59 --> Language Class Initialized
INFO - 2026-08-18 17:35:59 --> Config Class Initialized
INFO - 2026-08-18 17:35:59 --> Loader Class Initialized
INFO - 2026-08-18 17:35:59 --> Helper loaded: url_helper
INFO - 2026-08-18 17:35:59 --> Helper loaded: form_helper
INFO - 2026-08-18 17:35:59 --> Helper loaded: html_helper
INFO - 2026-08-18 17:35:59 --> Helper loaded: file_helper
INFO - 2026-08-18 17:35:59 --> Helper loaded: email_helper
INFO - 2026-08-18 17:35:59 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 17:35:59 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:35:59 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 17:35:59 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:35:59 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:35:59 --> Helper loaded: domain_helper
INFO - 2026-08-18 17:35:59 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 17:35:59 --> Database Driver Class Initialized
INFO - 2026-08-18 17:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:36:02 --> Upload Class Initialized
DEBUG - 2026-08-18 17:36:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:36:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:36:02 --> Encryption Class Initialized
INFO - 2026-08-18 17:36:02 --> Form Validation Class Initialized
INFO - 2026-08-18 17:36:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:36:02 --> Pagination Class Initialized
INFO - 2026-08-18 17:36:02 --> Email Class Initialized
INFO - 2026-08-18 17:36:02 --> Controller Class Initialized
DEBUG - 2026-08-18 17:36:02 --> Tickets MX_Controller Initialized
INFO - 2026-08-18 17:36:02 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 17:36:02 --> Model "Auth_model" initialized
INFO - 2026-08-18 17:36:02 --> Model "Cart_model" initialized
INFO - 2026-08-18 17:36:02 --> Model "Support_model" initialized
INFO - 2026-08-18 17:36:02 --> Model "Common_model" initialized
DEBUG - 2026-08-18 17:36:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-18 17:36:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/support_nav.php
DEBUG - 2026-08-18 17:36:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-18 17:36:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-18 17:36:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/tickets/views/tickets.php
INFO - 2026-08-18 17:36:04 --> Final output sent to browser
DEBUG - 2026-08-18 17:36:04 --> Total execution time: 4.7054
INFO - 2026-08-18 17:36:04 --> Config Class Initialized
INFO - 2026-08-18 17:36:04 --> Hooks Class Initialized
INFO - 2026-08-18 17:36:04 --> Config Class Initialized
INFO - 2026-08-18 17:36:04 --> Hooks Class Initialized
DEBUG - 2026-08-18 17:36:04 --> UTF-8 Support Enabled
INFO - 2026-08-18 17:36:04 --> Utf8 Class Initialized
INFO - 2026-08-18 17:36:04 --> URI Class Initialized
DEBUG - 2026-08-18 17:36:04 --> UTF-8 Support Enabled
INFO - 2026-08-18 17:36:04 --> Utf8 Class Initialized
INFO - 2026-08-18 17:36:04 --> URI Class Initialized
INFO - 2026-08-18 17:36:04 --> Router Class Initialized
INFO - 2026-08-18 17:36:04 --> Output Class Initialized
INFO - 2026-08-18 17:36:04 --> Router Class Initialized
INFO - 2026-08-18 17:36:04 --> Security Class Initialized
INFO - 2026-08-18 17:36:04 --> Output Class Initialized
DEBUG - 2026-08-18 17:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 17:36:04 --> CSRF cookie sent
INFO - 2026-08-18 17:36:04 --> Input Class Initialized
INFO - 2026-08-18 17:36:04 --> Language Class Initialized
INFO - 2026-08-18 17:36:04 --> Language Class Initialized
INFO - 2026-08-18 17:36:04 --> Config Class Initialized
INFO - 2026-08-18 17:36:04 --> Security Class Initialized
DEBUG - 2026-08-18 17:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 17:36:04 --> CSRF cookie sent
INFO - 2026-08-18 17:36:04 --> Input Class Initialized
INFO - 2026-08-18 17:36:04 --> Language Class Initialized
INFO - 2026-08-18 17:36:04 --> Loader Class Initialized
INFO - 2026-08-18 17:36:04 --> Helper loaded: url_helper
INFO - 2026-08-18 17:36:04 --> Language Class Initialized
INFO - 2026-08-18 17:36:04 --> Config Class Initialized
INFO - 2026-08-18 17:36:04 --> Helper loaded: form_helper
INFO - 2026-08-18 17:36:04 --> Helper loaded: html_helper
INFO - 2026-08-18 17:36:04 --> Helper loaded: file_helper
INFO - 2026-08-18 17:36:04 --> Helper loaded: email_helper
INFO - 2026-08-18 17:36:04 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 17:36:04 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:36:04 --> Loader Class Initialized
INFO - 2026-08-18 17:36:04 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 17:36:04 --> Helper loaded: url_helper
INFO - 2026-08-18 17:36:04 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:36:04 --> Helper loaded: form_helper
INFO - 2026-08-18 17:36:04 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:36:04 --> Helper loaded: html_helper
INFO - 2026-08-18 17:36:04 --> Helper loaded: file_helper
INFO - 2026-08-18 17:36:04 --> Helper loaded: email_helper
INFO - 2026-08-18 17:36:04 --> Helper loaded: domain_helper
INFO - 2026-08-18 17:36:04 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 17:36:04 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 17:36:04 --> Helper loaded: ssp_helper
INFO - 2026-08-18 17:36:04 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 17:36:04 --> Database Driver Class Initialized
INFO - 2026-08-18 17:36:04 --> Helper loaded: plesk_helper
INFO - 2026-08-18 17:36:04 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 17:36:04 --> Helper loaded: domain_helper
INFO - 2026-08-18 17:36:04 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 17:36:04 --> Database Driver Class Initialized
INFO - 2026-08-18 17:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:36:07 --> Upload Class Initialized
DEBUG - 2026-08-18 17:36:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:36:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:36:07 --> Encryption Class Initialized
INFO - 2026-08-18 17:36:07 --> Form Validation Class Initialized
INFO - 2026-08-18 17:36:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:36:07 --> Pagination Class Initialized
INFO - 2026-08-18 17:36:07 --> Email Class Initialized
INFO - 2026-08-18 17:36:07 --> Controller Class Initialized
DEBUG - 2026-08-18 17:36:07 --> Cart MX_Controller Initialized
INFO - 2026-08-18 17:36:07 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 17:36:07 --> Model "Auth_model" initialized
INFO - 2026-08-18 17:36:07 --> Model "Cart_model" initialized
INFO - 2026-08-18 17:36:07 --> Model "Common_model" initialized
INFO - 2026-08-18 17:36:07 --> Model "Order_model" initialized
INFO - 2026-08-18 17:36:07 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 17:36:07 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 17:36:07 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 17:36:07 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 17:36:07 --> Model "Plan_model" initialized
INFO - 2026-08-18 17:36:07 --> Model "Orderlicense_model" initialized
INFO - 2026-08-18 17:36:07 --> Final output sent to browser
DEBUG - 2026-08-18 17:36:07 --> Total execution time: 3.1014
INFO - 2026-08-18 17:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 17:36:07 --> Upload Class Initialized
DEBUG - 2026-08-18 17:36:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 17:36:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 17:36:07 --> Encryption Class Initialized
INFO - 2026-08-18 17:36:07 --> Form Validation Class Initialized
INFO - 2026-08-18 17:36:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 17:36:07 --> Pagination Class Initialized
INFO - 2026-08-18 17:36:07 --> Email Class Initialized
INFO - 2026-08-18 17:36:07 --> Controller Class Initialized
DEBUG - 2026-08-18 17:36:07 --> Notifications MX_Controller Initialized
INFO - 2026-08-18 17:36:07 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 17:36:07 --> Model "Auth_model" initialized
INFO - 2026-08-18 17:36:07 --> Model "Cart_model" initialized
INFO - 2026-08-18 17:36:07 --> Model "Notification_model" initialized
INFO - 2026-08-18 18:14:41 --> Config Class Initialized
INFO - 2026-08-18 18:14:41 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:14:41 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:14:41 --> Utf8 Class Initialized
INFO - 2026-08-18 18:14:41 --> URI Class Initialized
INFO - 2026-08-18 18:14:41 --> Router Class Initialized
INFO - 2026-08-18 18:14:41 --> Output Class Initialized
INFO - 2026-08-18 18:14:41 --> Security Class Initialized
DEBUG - 2026-08-18 18:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:14:41 --> CSRF cookie sent
INFO - 2026-08-18 18:14:41 --> Input Class Initialized
INFO - 2026-08-18 18:14:41 --> Language Class Initialized
INFO - 2026-08-18 18:14:41 --> Language Class Initialized
INFO - 2026-08-18 18:14:41 --> Config Class Initialized
INFO - 2026-08-18 18:14:41 --> Loader Class Initialized
INFO - 2026-08-18 18:14:41 --> Helper loaded: url_helper
INFO - 2026-08-18 18:14:41 --> Helper loaded: form_helper
INFO - 2026-08-18 18:14:41 --> Helper loaded: html_helper
INFO - 2026-08-18 18:14:41 --> Helper loaded: file_helper
INFO - 2026-08-18 18:14:41 --> Helper loaded: email_helper
INFO - 2026-08-18 18:14:41 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:14:41 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:14:41 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:14:41 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:14:41 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:14:41 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:14:41 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:14:41 --> Database Driver Class Initialized
INFO - 2026-08-18 18:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:14:43 --> Upload Class Initialized
DEBUG - 2026-08-18 18:14:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:14:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:14:43 --> Encryption Class Initialized
INFO - 2026-08-18 18:14:43 --> Form Validation Class Initialized
INFO - 2026-08-18 18:14:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:14:43 --> Pagination Class Initialized
INFO - 2026-08-18 18:14:43 --> Email Class Initialized
INFO - 2026-08-18 18:14:43 --> Controller Class Initialized
DEBUG - 2026-08-18 18:14:43 --> Auth MX_Controller Initialized
INFO - 2026-08-18 18:14:43 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:14:43 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:14:43 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:14:43 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-18 18:14:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-18 18:14:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-18 18:14:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-18 18:14:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-08-18 18:14:44 --> Final output sent to browser
DEBUG - 2026-08-18 18:14:44 --> Total execution time: 2.8230
INFO - 2026-08-18 18:14:44 --> Config Class Initialized
INFO - 2026-08-18 18:14:44 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:14:44 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:14:44 --> Utf8 Class Initialized
INFO - 2026-08-18 18:14:44 --> URI Class Initialized
INFO - 2026-08-18 18:14:44 --> Router Class Initialized
INFO - 2026-08-18 18:14:44 --> Output Class Initialized
INFO - 2026-08-18 18:14:44 --> Security Class Initialized
DEBUG - 2026-08-18 18:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:14:44 --> CSRF cookie sent
INFO - 2026-08-18 18:14:44 --> Input Class Initialized
INFO - 2026-08-18 18:14:44 --> Language Class Initialized
INFO - 2026-08-18 18:14:44 --> Language Class Initialized
INFO - 2026-08-18 18:14:44 --> Config Class Initialized
INFO - 2026-08-18 18:14:44 --> Loader Class Initialized
INFO - 2026-08-18 18:14:44 --> Helper loaded: url_helper
INFO - 2026-08-18 18:14:44 --> Helper loaded: form_helper
INFO - 2026-08-18 18:14:44 --> Helper loaded: html_helper
INFO - 2026-08-18 18:14:44 --> Helper loaded: file_helper
INFO - 2026-08-18 18:14:44 --> Helper loaded: email_helper
INFO - 2026-08-18 18:14:44 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:14:44 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:14:44 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:14:44 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:14:44 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:14:44 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:14:44 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:14:44 --> Database Driver Class Initialized
INFO - 2026-08-18 18:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:14:46 --> Upload Class Initialized
DEBUG - 2026-08-18 18:14:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:14:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:14:46 --> Encryption Class Initialized
INFO - 2026-08-18 18:14:46 --> Form Validation Class Initialized
INFO - 2026-08-18 18:14:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:14:46 --> Pagination Class Initialized
INFO - 2026-08-18 18:14:46 --> Email Class Initialized
INFO - 2026-08-18 18:14:46 --> Controller Class Initialized
DEBUG - 2026-08-18 18:14:46 --> Cart MX_Controller Initialized
INFO - 2026-08-18 18:14:46 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:14:46 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:14:46 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:14:46 --> Model "Common_model" initialized
INFO - 2026-08-18 18:14:46 --> Model "Order_model" initialized
INFO - 2026-08-18 18:14:46 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 18:14:46 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 18:14:46 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 18:14:46 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 18:14:46 --> Model "Plan_model" initialized
INFO - 2026-08-18 18:14:46 --> Model "Orderlicense_model" initialized
INFO - 2026-08-18 18:14:46 --> Final output sent to browser
DEBUG - 2026-08-18 18:14:46 --> Total execution time: 2.1295
INFO - 2026-08-18 18:14:48 --> Config Class Initialized
INFO - 2026-08-18 18:14:48 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:14:48 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:14:48 --> Utf8 Class Initialized
INFO - 2026-08-18 18:14:48 --> URI Class Initialized
INFO - 2026-08-18 18:14:48 --> Router Class Initialized
INFO - 2026-08-18 18:14:48 --> Output Class Initialized
INFO - 2026-08-18 18:14:48 --> Security Class Initialized
DEBUG - 2026-08-18 18:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:14:48 --> CSRF cookie sent
INFO - 2026-08-18 18:14:48 --> Input Class Initialized
INFO - 2026-08-18 18:14:48 --> Language Class Initialized
INFO - 2026-08-18 18:14:48 --> Language Class Initialized
INFO - 2026-08-18 18:14:48 --> Config Class Initialized
INFO - 2026-08-18 18:14:48 --> Loader Class Initialized
INFO - 2026-08-18 18:14:48 --> Helper loaded: url_helper
INFO - 2026-08-18 18:14:48 --> Helper loaded: form_helper
INFO - 2026-08-18 18:14:48 --> Helper loaded: html_helper
INFO - 2026-08-18 18:14:48 --> Helper loaded: file_helper
INFO - 2026-08-18 18:14:48 --> Helper loaded: email_helper
INFO - 2026-08-18 18:14:48 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:14:48 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:14:48 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:14:48 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:14:48 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:14:48 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:14:48 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:14:48 --> Database Driver Class Initialized
INFO - 2026-08-18 18:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:14:50 --> Upload Class Initialized
DEBUG - 2026-08-18 18:14:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:14:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:14:50 --> Encryption Class Initialized
INFO - 2026-08-18 18:14:50 --> Form Validation Class Initialized
INFO - 2026-08-18 18:14:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:14:50 --> Pagination Class Initialized
INFO - 2026-08-18 18:14:50 --> Email Class Initialized
INFO - 2026-08-18 18:14:50 --> Controller Class Initialized
DEBUG - 2026-08-18 18:14:50 --> Auth MX_Controller Initialized
INFO - 2026-08-18 18:14:50 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:14:50 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:14:50 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:14:50 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-18 18:14:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-18 18:14:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-18 18:14:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-18 18:14:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_register.php
INFO - 2026-08-18 18:14:52 --> Final output sent to browser
DEBUG - 2026-08-18 18:14:52 --> Total execution time: 3.4606
INFO - 2026-08-18 18:14:52 --> Config Class Initialized
INFO - 2026-08-18 18:14:52 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:14:52 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:14:52 --> Utf8 Class Initialized
INFO - 2026-08-18 18:14:52 --> URI Class Initialized
INFO - 2026-08-18 18:14:52 --> Router Class Initialized
INFO - 2026-08-18 18:14:52 --> Output Class Initialized
INFO - 2026-08-18 18:14:52 --> Security Class Initialized
DEBUG - 2026-08-18 18:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:14:52 --> CSRF cookie sent
INFO - 2026-08-18 18:14:52 --> Input Class Initialized
INFO - 2026-08-18 18:14:52 --> Language Class Initialized
INFO - 2026-08-18 18:14:52 --> Language Class Initialized
INFO - 2026-08-18 18:14:52 --> Config Class Initialized
INFO - 2026-08-18 18:14:52 --> Loader Class Initialized
INFO - 2026-08-18 18:14:52 --> Helper loaded: url_helper
INFO - 2026-08-18 18:14:52 --> Helper loaded: form_helper
INFO - 2026-08-18 18:14:52 --> Helper loaded: html_helper
INFO - 2026-08-18 18:14:52 --> Helper loaded: file_helper
INFO - 2026-08-18 18:14:52 --> Helper loaded: email_helper
INFO - 2026-08-18 18:14:52 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:14:52 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:14:52 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:14:52 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:14:52 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:14:52 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:14:52 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:14:52 --> Database Driver Class Initialized
INFO - 2026-08-18 18:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:14:54 --> Upload Class Initialized
DEBUG - 2026-08-18 18:14:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:14:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:14:54 --> Encryption Class Initialized
INFO - 2026-08-18 18:14:54 --> Form Validation Class Initialized
INFO - 2026-08-18 18:14:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:14:54 --> Pagination Class Initialized
INFO - 2026-08-18 18:14:54 --> Email Class Initialized
INFO - 2026-08-18 18:14:54 --> Controller Class Initialized
DEBUG - 2026-08-18 18:14:54 --> Cart MX_Controller Initialized
INFO - 2026-08-18 18:14:54 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:14:54 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:14:54 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:14:54 --> Model "Common_model" initialized
INFO - 2026-08-18 18:14:54 --> Model "Order_model" initialized
INFO - 2026-08-18 18:14:54 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 18:14:54 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 18:14:54 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 18:14:54 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 18:14:54 --> Model "Plan_model" initialized
INFO - 2026-08-18 18:14:54 --> Model "Orderlicense_model" initialized
INFO - 2026-08-18 18:14:54 --> Final output sent to browser
DEBUG - 2026-08-18 18:14:54 --> Total execution time: 2.1910
INFO - 2026-08-18 18:14:56 --> Config Class Initialized
INFO - 2026-08-18 18:14:56 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:14:56 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:14:56 --> Utf8 Class Initialized
INFO - 2026-08-18 18:14:56 --> URI Class Initialized
INFO - 2026-08-18 18:14:56 --> Router Class Initialized
INFO - 2026-08-18 18:14:56 --> Output Class Initialized
INFO - 2026-08-18 18:14:56 --> Security Class Initialized
DEBUG - 2026-08-18 18:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:14:56 --> CSRF cookie sent
INFO - 2026-08-18 18:14:56 --> Input Class Initialized
INFO - 2026-08-18 18:14:56 --> Language Class Initialized
INFO - 2026-08-18 18:14:56 --> Language Class Initialized
INFO - 2026-08-18 18:14:56 --> Config Class Initialized
INFO - 2026-08-18 18:14:56 --> Loader Class Initialized
INFO - 2026-08-18 18:14:56 --> Helper loaded: url_helper
INFO - 2026-08-18 18:14:56 --> Helper loaded: form_helper
INFO - 2026-08-18 18:14:56 --> Helper loaded: html_helper
INFO - 2026-08-18 18:14:56 --> Helper loaded: file_helper
INFO - 2026-08-18 18:14:56 --> Helper loaded: email_helper
INFO - 2026-08-18 18:14:56 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:14:56 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:14:56 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:14:56 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:14:56 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:14:56 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:14:56 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:14:56 --> Database Driver Class Initialized
INFO - 2026-08-18 18:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:14:59 --> Upload Class Initialized
DEBUG - 2026-08-18 18:14:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:14:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:14:59 --> Encryption Class Initialized
INFO - 2026-08-18 18:14:59 --> Form Validation Class Initialized
INFO - 2026-08-18 18:14:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:14:59 --> Pagination Class Initialized
INFO - 2026-08-18 18:14:59 --> Email Class Initialized
INFO - 2026-08-18 18:14:59 --> Controller Class Initialized
DEBUG - 2026-08-18 18:14:59 --> Auth MX_Controller Initialized
INFO - 2026-08-18 18:14:59 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:14:59 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:14:59 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:14:59 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-18 18:15:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-18 18:15:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-18 18:15:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-18 18:15:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-08-18 18:15:00 --> Final output sent to browser
DEBUG - 2026-08-18 18:15:00 --> Total execution time: 3.6312
INFO - 2026-08-18 18:15:00 --> Config Class Initialized
INFO - 2026-08-18 18:15:00 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:15:00 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:15:00 --> Utf8 Class Initialized
INFO - 2026-08-18 18:15:00 --> URI Class Initialized
INFO - 2026-08-18 18:15:00 --> Router Class Initialized
INFO - 2026-08-18 18:15:00 --> Output Class Initialized
INFO - 2026-08-18 18:15:00 --> Security Class Initialized
DEBUG - 2026-08-18 18:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:15:00 --> CSRF cookie sent
INFO - 2026-08-18 18:15:00 --> Input Class Initialized
INFO - 2026-08-18 18:15:00 --> Language Class Initialized
INFO - 2026-08-18 18:15:00 --> Language Class Initialized
INFO - 2026-08-18 18:15:00 --> Config Class Initialized
INFO - 2026-08-18 18:15:00 --> Loader Class Initialized
INFO - 2026-08-18 18:15:00 --> Helper loaded: url_helper
INFO - 2026-08-18 18:15:00 --> Helper loaded: form_helper
INFO - 2026-08-18 18:15:00 --> Helper loaded: html_helper
INFO - 2026-08-18 18:15:00 --> Helper loaded: file_helper
INFO - 2026-08-18 18:15:00 --> Helper loaded: email_helper
INFO - 2026-08-18 18:15:00 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:15:00 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:15:00 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:15:00 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:15:00 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:15:00 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:15:00 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:15:00 --> Database Driver Class Initialized
INFO - 2026-08-18 18:15:00 --> Config Class Initialized
INFO - 2026-08-18 18:15:00 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:15:00 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:15:00 --> Utf8 Class Initialized
INFO - 2026-08-18 18:15:00 --> URI Class Initialized
INFO - 2026-08-18 18:15:00 --> Router Class Initialized
INFO - 2026-08-18 18:15:00 --> Output Class Initialized
INFO - 2026-08-18 18:15:00 --> Security Class Initialized
DEBUG - 2026-08-18 18:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:15:00 --> CSRF cookie sent
INFO - 2026-08-18 18:15:00 --> CSRF token verified
INFO - 2026-08-18 18:15:00 --> Input Class Initialized
INFO - 2026-08-18 18:15:00 --> Language Class Initialized
INFO - 2026-08-18 18:15:00 --> Language Class Initialized
INFO - 2026-08-18 18:15:00 --> Config Class Initialized
INFO - 2026-08-18 18:15:00 --> Loader Class Initialized
INFO - 2026-08-18 18:15:00 --> Helper loaded: url_helper
INFO - 2026-08-18 18:15:00 --> Helper loaded: form_helper
INFO - 2026-08-18 18:15:00 --> Helper loaded: html_helper
INFO - 2026-08-18 18:15:00 --> Helper loaded: file_helper
INFO - 2026-08-18 18:15:00 --> Helper loaded: email_helper
INFO - 2026-08-18 18:15:00 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:15:00 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:15:00 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:15:00 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:15:00 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:15:00 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:15:00 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:15:00 --> Database Driver Class Initialized
INFO - 2026-08-18 18:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:15:02 --> Upload Class Initialized
DEBUG - 2026-08-18 18:15:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:15:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:15:02 --> Encryption Class Initialized
INFO - 2026-08-18 18:15:02 --> Form Validation Class Initialized
INFO - 2026-08-18 18:15:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:15:02 --> Pagination Class Initialized
INFO - 2026-08-18 18:15:02 --> Email Class Initialized
INFO - 2026-08-18 18:15:02 --> Controller Class Initialized
DEBUG - 2026-08-18 18:15:02 --> Cart MX_Controller Initialized
INFO - 2026-08-18 18:15:02 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:15:02 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:15:02 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:15:02 --> Model "Common_model" initialized
INFO - 2026-08-18 18:15:02 --> Model "Order_model" initialized
INFO - 2026-08-18 18:15:02 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 18:15:02 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 18:15:02 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 18:15:02 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 18:15:02 --> Model "Plan_model" initialized
INFO - 2026-08-18 18:15:02 --> Model "Orderlicense_model" initialized
INFO - 2026-08-18 18:15:02 --> Final output sent to browser
DEBUG - 2026-08-18 18:15:02 --> Total execution time: 2.0127
INFO - 2026-08-18 18:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:15:02 --> Upload Class Initialized
DEBUG - 2026-08-18 18:15:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:15:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:15:02 --> Encryption Class Initialized
INFO - 2026-08-18 18:15:02 --> Form Validation Class Initialized
INFO - 2026-08-18 18:15:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:15:02 --> Pagination Class Initialized
INFO - 2026-08-18 18:15:02 --> Email Class Initialized
INFO - 2026-08-18 18:15:02 --> Controller Class Initialized
DEBUG - 2026-08-18 18:15:02 --> Auth MX_Controller Initialized
INFO - 2026-08-18 18:15:02 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:15:02 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:15:02 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:15:02 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 18:15:05 --> Config Class Initialized
INFO - 2026-08-18 18:15:05 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:15:05 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:15:05 --> Utf8 Class Initialized
INFO - 2026-08-18 18:15:05 --> URI Class Initialized
INFO - 2026-08-18 18:15:05 --> Router Class Initialized
INFO - 2026-08-18 18:15:05 --> Output Class Initialized
INFO - 2026-08-18 18:15:05 --> Security Class Initialized
DEBUG - 2026-08-18 18:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:15:05 --> CSRF cookie sent
INFO - 2026-08-18 18:15:05 --> Input Class Initialized
INFO - 2026-08-18 18:15:05 --> Language Class Initialized
INFO - 2026-08-18 18:15:05 --> Language Class Initialized
INFO - 2026-08-18 18:15:05 --> Config Class Initialized
INFO - 2026-08-18 18:15:05 --> Loader Class Initialized
INFO - 2026-08-18 18:15:05 --> Helper loaded: url_helper
INFO - 2026-08-18 18:15:05 --> Helper loaded: form_helper
INFO - 2026-08-18 18:15:05 --> Helper loaded: html_helper
INFO - 2026-08-18 18:15:05 --> Helper loaded: file_helper
INFO - 2026-08-18 18:15:05 --> Helper loaded: email_helper
INFO - 2026-08-18 18:15:05 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:15:05 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:15:05 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:15:05 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:15:05 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:15:05 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:15:05 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:15:05 --> Database Driver Class Initialized
INFO - 2026-08-18 18:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:15:07 --> Upload Class Initialized
DEBUG - 2026-08-18 18:15:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:15:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:15:07 --> Encryption Class Initialized
INFO - 2026-08-18 18:15:07 --> Form Validation Class Initialized
INFO - 2026-08-18 18:15:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:15:07 --> Pagination Class Initialized
INFO - 2026-08-18 18:15:07 --> Email Class Initialized
INFO - 2026-08-18 18:15:07 --> Controller Class Initialized
DEBUG - 2026-08-18 18:15:07 --> Clientarea MX_Controller Initialized
INFO - 2026-08-18 18:15:07 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:15:07 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:15:07 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:15:07 --> Model "Clientarea_model" initialized
INFO - 2026-08-18 18:15:07 --> Model "Billing_model" initialized
INFO - 2026-08-18 18:15:07 --> Model "Common_model" initialized
INFO - 2026-08-18 18:15:07 --> Model "Order_model" initialized
INFO - 2026-08-18 18:15:07 --> Model "Support_model" initialized
INFO - 2026-08-18 18:15:07 --> Model "Subscription_model" initialized
INFO - 2026-08-18 18:15:07 --> Model "Software_model" initialized
DEBUG - 2026-08-18 18:15:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-18 18:15:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-18 18:15:09 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-18 18:15:09 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_index.php
INFO - 2026-08-18 18:15:09 --> Final output sent to browser
DEBUG - 2026-08-18 18:15:09 --> Total execution time: 3.6576
INFO - 2026-08-18 18:15:09 --> Config Class Initialized
INFO - 2026-08-18 18:15:09 --> Hooks Class Initialized
INFO - 2026-08-18 18:15:09 --> Config Class Initialized
INFO - 2026-08-18 18:15:09 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:15:09 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:15:09 --> Utf8 Class Initialized
DEBUG - 2026-08-18 18:15:09 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:15:09 --> Utf8 Class Initialized
INFO - 2026-08-18 18:15:09 --> URI Class Initialized
INFO - 2026-08-18 18:15:09 --> URI Class Initialized
INFO - 2026-08-18 18:15:09 --> Router Class Initialized
INFO - 2026-08-18 18:15:09 --> Router Class Initialized
INFO - 2026-08-18 18:15:09 --> Output Class Initialized
INFO - 2026-08-18 18:15:09 --> Output Class Initialized
INFO - 2026-08-18 18:15:09 --> Security Class Initialized
INFO - 2026-08-18 18:15:09 --> Security Class Initialized
DEBUG - 2026-08-18 18:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-08-18 18:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:15:09 --> CSRF cookie sent
INFO - 2026-08-18 18:15:09 --> CSRF cookie sent
INFO - 2026-08-18 18:15:09 --> Input Class Initialized
INFO - 2026-08-18 18:15:09 --> Input Class Initialized
INFO - 2026-08-18 18:15:09 --> Language Class Initialized
INFO - 2026-08-18 18:15:09 --> Language Class Initialized
INFO - 2026-08-18 18:15:09 --> Language Class Initialized
INFO - 2026-08-18 18:15:09 --> Language Class Initialized
INFO - 2026-08-18 18:15:09 --> Config Class Initialized
INFO - 2026-08-18 18:15:09 --> Config Class Initialized
INFO - 2026-08-18 18:15:09 --> Loader Class Initialized
INFO - 2026-08-18 18:15:09 --> Loader Class Initialized
INFO - 2026-08-18 18:15:09 --> Helper loaded: url_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: url_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: form_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: form_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: html_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: html_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: file_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: email_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: file_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: email_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:15:09 --> Config Class Initialized
INFO - 2026-08-18 18:15:09 --> Hooks Class Initialized
INFO - 2026-08-18 18:15:09 --> Database Driver Class Initialized
INFO - 2026-08-18 18:15:09 --> Database Driver Class Initialized
INFO - 2026-08-18 18:15:09 --> Config Class Initialized
INFO - 2026-08-18 18:15:09 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:15:09 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:15:09 --> Utf8 Class Initialized
DEBUG - 2026-08-18 18:15:09 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:15:09 --> Utf8 Class Initialized
INFO - 2026-08-18 18:15:09 --> URI Class Initialized
INFO - 2026-08-18 18:15:09 --> URI Class Initialized
INFO - 2026-08-18 18:15:09 --> Router Class Initialized
INFO - 2026-08-18 18:15:09 --> Config Class Initialized
INFO - 2026-08-18 18:15:09 --> Hooks Class Initialized
INFO - 2026-08-18 18:15:09 --> Router Class Initialized
INFO - 2026-08-18 18:15:09 --> Output Class Initialized
INFO - 2026-08-18 18:15:09 --> Output Class Initialized
DEBUG - 2026-08-18 18:15:09 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:15:09 --> Utf8 Class Initialized
INFO - 2026-08-18 18:15:09 --> Security Class Initialized
INFO - 2026-08-18 18:15:09 --> Security Class Initialized
INFO - 2026-08-18 18:15:09 --> URI Class Initialized
DEBUG - 2026-08-18 18:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-08-18 18:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:15:09 --> Input Class Initialized
INFO - 2026-08-18 18:15:09 --> Language Class Initialized
INFO - 2026-08-18 18:15:09 --> Input Class Initialized
INFO - 2026-08-18 18:15:09 --> Language Class Initialized
INFO - 2026-08-18 18:15:09 --> Language Class Initialized
INFO - 2026-08-18 18:15:09 --> Config Class Initialized
INFO - 2026-08-18 18:15:09 --> Language Class Initialized
INFO - 2026-08-18 18:15:09 --> Config Class Initialized
INFO - 2026-08-18 18:15:09 --> Router Class Initialized
INFO - 2026-08-18 18:15:09 --> Loader Class Initialized
INFO - 2026-08-18 18:15:09 --> Output Class Initialized
INFO - 2026-08-18 18:15:09 --> Loader Class Initialized
INFO - 2026-08-18 18:15:09 --> Helper loaded: url_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: url_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: form_helper
INFO - 2026-08-18 18:15:09 --> Security Class Initialized
INFO - 2026-08-18 18:15:09 --> Helper loaded: form_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: html_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: html_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: file_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: email_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: file_helper
DEBUG - 2026-08-18 18:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:15:09 --> Input Class Initialized
INFO - 2026-08-18 18:15:09 --> Helper loaded: email_helper
INFO - 2026-08-18 18:15:09 --> Language Class Initialized
INFO - 2026-08-18 18:15:09 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:15:09 --> Language Class Initialized
INFO - 2026-08-18 18:15:09 --> Config Class Initialized
INFO - 2026-08-18 18:15:09 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:15:09 --> Loader Class Initialized
INFO - 2026-08-18 18:15:09 --> Helper loaded: url_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: form_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: html_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: file_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: email_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:15:09 --> Database Driver Class Initialized
INFO - 2026-08-18 18:15:09 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:15:09 --> Database Driver Class Initialized
INFO - 2026-08-18 18:15:09 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:15:09 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:15:09 --> Database Driver Class Initialized
INFO - 2026-08-18 18:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:15:10 --> Upload Class Initialized
DEBUG - 2026-08-18 18:15:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:15:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:15:10 --> Encryption Class Initialized
INFO - 2026-08-18 18:15:10 --> Form Validation Class Initialized
INFO - 2026-08-18 18:15:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:15:10 --> Pagination Class Initialized
INFO - 2026-08-18 18:15:10 --> Email Class Initialized
INFO - 2026-08-18 18:15:10 --> Controller Class Initialized
DEBUG - 2026-08-18 18:15:10 --> Notifications MX_Controller Initialized
INFO - 2026-08-18 18:15:10 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:15:10 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:15:10 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:15:10 --> Model "Notification_model" initialized
INFO - 2026-08-18 18:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:15:11 --> Upload Class Initialized
DEBUG - 2026-08-18 18:15:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:15:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:15:11 --> Encryption Class Initialized
INFO - 2026-08-18 18:15:11 --> Form Validation Class Initialized
INFO - 2026-08-18 18:15:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:15:11 --> Pagination Class Initialized
INFO - 2026-08-18 18:15:11 --> Email Class Initialized
INFO - 2026-08-18 18:15:11 --> Controller Class Initialized
DEBUG - 2026-08-18 18:15:11 --> Cart MX_Controller Initialized
INFO - 2026-08-18 18:15:11 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:15:11 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:15:11 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:15:11 --> Model "Common_model" initialized
INFO - 2026-08-18 18:15:11 --> Model "Order_model" initialized
INFO - 2026-08-18 18:15:11 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 18:15:11 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 18:15:11 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 18:15:11 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 18:15:11 --> Model "Plan_model" initialized
INFO - 2026-08-18 18:15:11 --> Model "Orderlicense_model" initialized
INFO - 2026-08-18 18:15:11 --> Final output sent to browser
DEBUG - 2026-08-18 18:15:11 --> Total execution time: 2.7978
INFO - 2026-08-18 18:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:15:11 --> Upload Class Initialized
DEBUG - 2026-08-18 18:15:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:15:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:15:11 --> Encryption Class Initialized
INFO - 2026-08-18 18:15:11 --> Form Validation Class Initialized
INFO - 2026-08-18 18:15:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:15:11 --> Pagination Class Initialized
INFO - 2026-08-18 18:15:11 --> Email Class Initialized
INFO - 2026-08-18 18:15:11 --> Controller Class Initialized
DEBUG - 2026-08-18 18:15:11 --> Tickets MX_Controller Initialized
INFO - 2026-08-18 18:15:11 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:15:11 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:15:11 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:15:11 --> Model "Support_model" initialized
INFO - 2026-08-18 18:15:11 --> Model "Common_model" initialized
INFO - 2026-08-18 18:15:12 --> Final output sent to browser
DEBUG - 2026-08-18 18:15:12 --> Total execution time: 3.4831
INFO - 2026-08-18 18:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:15:12 --> Upload Class Initialized
DEBUG - 2026-08-18 18:15:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:15:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:15:12 --> Encryption Class Initialized
INFO - 2026-08-18 18:15:12 --> Form Validation Class Initialized
INFO - 2026-08-18 18:15:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:15:12 --> Pagination Class Initialized
INFO - 2026-08-18 18:15:12 --> Email Class Initialized
INFO - 2026-08-18 18:15:12 --> Controller Class Initialized
DEBUG - 2026-08-18 18:15:12 --> Clientarea MX_Controller Initialized
INFO - 2026-08-18 18:15:12 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:15:12 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:15:12 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:15:12 --> Model "Clientarea_model" initialized
INFO - 2026-08-18 18:15:12 --> Model "Billing_model" initialized
INFO - 2026-08-18 18:15:12 --> Model "Common_model" initialized
INFO - 2026-08-18 18:15:12 --> Model "Order_model" initialized
INFO - 2026-08-18 18:15:12 --> Model "Support_model" initialized
INFO - 2026-08-18 18:15:13 --> Final output sent to browser
DEBUG - 2026-08-18 18:15:13 --> Total execution time: 4.1409
INFO - 2026-08-18 18:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:15:13 --> Upload Class Initialized
DEBUG - 2026-08-18 18:15:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:15:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:15:13 --> Encryption Class Initialized
INFO - 2026-08-18 18:15:13 --> Form Validation Class Initialized
INFO - 2026-08-18 18:15:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:15:13 --> Pagination Class Initialized
INFO - 2026-08-18 18:15:13 --> Email Class Initialized
INFO - 2026-08-18 18:15:13 --> Controller Class Initialized
DEBUG - 2026-08-18 18:15:13 --> Invoicing MX_Controller Initialized
INFO - 2026-08-18 18:15:13 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:15:13 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:15:13 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:15:13 --> Model "Billing_model" initialized
INFO - 2026-08-18 18:15:13 --> Model "Common_model" initialized
INFO - 2026-08-18 18:15:13 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 18:15:13 --> Final output sent to browser
DEBUG - 2026-08-18 18:15:13 --> Total execution time: 4.8344
INFO - 2026-08-18 18:15:15 --> Config Class Initialized
INFO - 2026-08-18 18:15:15 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:15:15 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:15:15 --> Utf8 Class Initialized
INFO - 2026-08-18 18:15:15 --> URI Class Initialized
INFO - 2026-08-18 18:15:15 --> Router Class Initialized
INFO - 2026-08-18 18:15:15 --> Output Class Initialized
INFO - 2026-08-18 18:15:15 --> Security Class Initialized
DEBUG - 2026-08-18 18:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:15:15 --> CSRF cookie sent
INFO - 2026-08-18 18:15:15 --> Input Class Initialized
INFO - 2026-08-18 18:15:15 --> Language Class Initialized
INFO - 2026-08-18 18:15:15 --> Language Class Initialized
INFO - 2026-08-18 18:15:15 --> Config Class Initialized
INFO - 2026-08-18 18:15:15 --> Loader Class Initialized
INFO - 2026-08-18 18:15:15 --> Helper loaded: url_helper
INFO - 2026-08-18 18:15:15 --> Helper loaded: form_helper
INFO - 2026-08-18 18:15:15 --> Helper loaded: html_helper
INFO - 2026-08-18 18:15:15 --> Helper loaded: file_helper
INFO - 2026-08-18 18:15:15 --> Helper loaded: email_helper
INFO - 2026-08-18 18:15:15 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:15:15 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:15:15 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:15:15 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:15:15 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:15:15 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:15:15 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:15:15 --> Database Driver Class Initialized
INFO - 2026-08-18 18:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:15:17 --> Upload Class Initialized
DEBUG - 2026-08-18 18:15:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:15:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:15:17 --> Encryption Class Initialized
INFO - 2026-08-18 18:15:17 --> Form Validation Class Initialized
INFO - 2026-08-18 18:15:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:15:17 --> Pagination Class Initialized
INFO - 2026-08-18 18:15:17 --> Email Class Initialized
INFO - 2026-08-18 18:15:17 --> Controller Class Initialized
DEBUG - 2026-08-18 18:15:17 --> Clientarea MX_Controller Initialized
INFO - 2026-08-18 18:15:17 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:15:17 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:15:17 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:15:17 --> Model "Clientarea_model" initialized
INFO - 2026-08-18 18:15:17 --> Model "Billing_model" initialized
INFO - 2026-08-18 18:15:17 --> Model "Common_model" initialized
INFO - 2026-08-18 18:15:17 --> Model "Order_model" initialized
INFO - 2026-08-18 18:15:17 --> Model "Support_model" initialized
INFO - 2026-08-18 18:15:18 --> Model "Subscription_model" initialized
INFO - 2026-08-18 18:15:18 --> Model "Software_model" initialized
DEBUG - 2026-08-18 18:15:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-18 18:15:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-18 18:15:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-18 18:15:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_index.php
INFO - 2026-08-18 18:15:19 --> Final output sent to browser
DEBUG - 2026-08-18 18:15:19 --> Total execution time: 3.7568
INFO - 2026-08-18 18:15:19 --> Config Class Initialized
INFO - 2026-08-18 18:15:19 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:15:19 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:15:19 --> Utf8 Class Initialized
INFO - 2026-08-18 18:15:19 --> URI Class Initialized
INFO - 2026-08-18 18:15:19 --> Config Class Initialized
INFO - 2026-08-18 18:15:19 --> Hooks Class Initialized
INFO - 2026-08-18 18:15:19 --> Router Class Initialized
DEBUG - 2026-08-18 18:15:19 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:15:19 --> Utf8 Class Initialized
INFO - 2026-08-18 18:15:19 --> URI Class Initialized
INFO - 2026-08-18 18:15:19 --> Output Class Initialized
INFO - 2026-08-18 18:15:19 --> Security Class Initialized
DEBUG - 2026-08-18 18:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:15:19 --> CSRF cookie sent
INFO - 2026-08-18 18:15:19 --> Input Class Initialized
INFO - 2026-08-18 18:15:19 --> Router Class Initialized
INFO - 2026-08-18 18:15:19 --> Language Class Initialized
INFO - 2026-08-18 18:15:19 --> Language Class Initialized
INFO - 2026-08-18 18:15:19 --> Config Class Initialized
INFO - 2026-08-18 18:15:19 --> Output Class Initialized
INFO - 2026-08-18 18:15:19 --> Security Class Initialized
INFO - 2026-08-18 18:15:19 --> Loader Class Initialized
DEBUG - 2026-08-18 18:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:15:19 --> CSRF cookie sent
INFO - 2026-08-18 18:15:19 --> Input Class Initialized
INFO - 2026-08-18 18:15:19 --> Language Class Initialized
INFO - 2026-08-18 18:15:19 --> Helper loaded: url_helper
INFO - 2026-08-18 18:15:19 --> Language Class Initialized
INFO - 2026-08-18 18:15:19 --> Config Class Initialized
INFO - 2026-08-18 18:15:19 --> Helper loaded: form_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: html_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: file_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: email_helper
INFO - 2026-08-18 18:15:19 --> Loader Class Initialized
INFO - 2026-08-18 18:15:19 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: url_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: form_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: html_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: file_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: email_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:15:19 --> Config Class Initialized
INFO - 2026-08-18 18:15:19 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:15:19 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:15:19 --> Utf8 Class Initialized
INFO - 2026-08-18 18:15:19 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:15:19 --> Database Driver Class Initialized
INFO - 2026-08-18 18:15:19 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:15:19 --> URI Class Initialized
INFO - 2026-08-18 18:15:19 --> Config Class Initialized
INFO - 2026-08-18 18:15:19 --> Hooks Class Initialized
INFO - 2026-08-18 18:15:19 --> Router Class Initialized
DEBUG - 2026-08-18 18:15:19 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:15:19 --> Utf8 Class Initialized
INFO - 2026-08-18 18:15:19 --> Output Class Initialized
INFO - 2026-08-18 18:15:19 --> URI Class Initialized
INFO - 2026-08-18 18:15:19 --> Config Class Initialized
INFO - 2026-08-18 18:15:19 --> Hooks Class Initialized
INFO - 2026-08-18 18:15:19 --> Security Class Initialized
DEBUG - 2026-08-18 18:15:19 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:15:19 --> Utf8 Class Initialized
INFO - 2026-08-18 18:15:19 --> Router Class Initialized
DEBUG - 2026-08-18 18:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:15:19 --> Database Driver Class Initialized
INFO - 2026-08-18 18:15:19 --> Input Class Initialized
INFO - 2026-08-18 18:15:19 --> URI Class Initialized
INFO - 2026-08-18 18:15:19 --> Language Class Initialized
INFO - 2026-08-18 18:15:19 --> Output Class Initialized
INFO - 2026-08-18 18:15:19 --> Language Class Initialized
INFO - 2026-08-18 18:15:19 --> Config Class Initialized
INFO - 2026-08-18 18:15:19 --> Router Class Initialized
INFO - 2026-08-18 18:15:19 --> Security Class Initialized
DEBUG - 2026-08-18 18:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:15:19 --> Output Class Initialized
INFO - 2026-08-18 18:15:19 --> Input Class Initialized
INFO - 2026-08-18 18:15:19 --> Language Class Initialized
INFO - 2026-08-18 18:15:19 --> Loader Class Initialized
INFO - 2026-08-18 18:15:19 --> Security Class Initialized
INFO - 2026-08-18 18:15:19 --> Language Class Initialized
INFO - 2026-08-18 18:15:19 --> Config Class Initialized
INFO - 2026-08-18 18:15:19 --> Helper loaded: url_helper
DEBUG - 2026-08-18 18:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:15:19 --> Input Class Initialized
INFO - 2026-08-18 18:15:19 --> Language Class Initialized
INFO - 2026-08-18 18:15:19 --> Helper loaded: form_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: html_helper
INFO - 2026-08-18 18:15:19 --> Language Class Initialized
INFO - 2026-08-18 18:15:19 --> Config Class Initialized
INFO - 2026-08-18 18:15:19 --> Helper loaded: file_helper
INFO - 2026-08-18 18:15:19 --> Loader Class Initialized
INFO - 2026-08-18 18:15:19 --> Helper loaded: email_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: url_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: form_helper
INFO - 2026-08-18 18:15:19 --> Loader Class Initialized
INFO - 2026-08-18 18:15:19 --> Helper loaded: html_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: url_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: file_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: email_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: form_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: html_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: file_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: email_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:15:19 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:15:19 --> Database Driver Class Initialized
INFO - 2026-08-18 18:15:19 --> Database Driver Class Initialized
INFO - 2026-08-18 18:15:19 --> Database Driver Class Initialized
INFO - 2026-08-18 18:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:15:21 --> Upload Class Initialized
DEBUG - 2026-08-18 18:15:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:15:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:15:21 --> Encryption Class Initialized
INFO - 2026-08-18 18:15:21 --> Form Validation Class Initialized
INFO - 2026-08-18 18:15:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:15:21 --> Pagination Class Initialized
INFO - 2026-08-18 18:15:21 --> Email Class Initialized
INFO - 2026-08-18 18:15:21 --> Controller Class Initialized
DEBUG - 2026-08-18 18:15:21 --> Cart MX_Controller Initialized
INFO - 2026-08-18 18:15:21 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:15:21 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:15:21 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:15:21 --> Model "Common_model" initialized
INFO - 2026-08-18 18:15:21 --> Model "Order_model" initialized
INFO - 2026-08-18 18:15:21 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 18:15:21 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 18:15:21 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 18:15:21 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 18:15:21 --> Model "Plan_model" initialized
INFO - 2026-08-18 18:15:21 --> Model "Orderlicense_model" initialized
INFO - 2026-08-18 18:15:21 --> Final output sent to browser
DEBUG - 2026-08-18 18:15:21 --> Total execution time: 2.1631
INFO - 2026-08-18 18:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:15:22 --> Upload Class Initialized
DEBUG - 2026-08-18 18:15:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:15:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:15:22 --> Encryption Class Initialized
INFO - 2026-08-18 18:15:22 --> Form Validation Class Initialized
INFO - 2026-08-18 18:15:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:15:22 --> Pagination Class Initialized
INFO - 2026-08-18 18:15:22 --> Email Class Initialized
INFO - 2026-08-18 18:15:22 --> Controller Class Initialized
DEBUG - 2026-08-18 18:15:22 --> Tickets MX_Controller Initialized
INFO - 2026-08-18 18:15:22 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:15:22 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:15:22 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:15:22 --> Model "Support_model" initialized
INFO - 2026-08-18 18:15:22 --> Model "Common_model" initialized
INFO - 2026-08-18 18:15:25 --> Final output sent to browser
DEBUG - 2026-08-18 18:15:25 --> Total execution time: 5.8202
INFO - 2026-08-18 18:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:15:25 --> Upload Class Initialized
DEBUG - 2026-08-18 18:15:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:15:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:15:25 --> Encryption Class Initialized
INFO - 2026-08-18 18:15:25 --> Form Validation Class Initialized
INFO - 2026-08-18 18:15:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:15:25 --> Pagination Class Initialized
INFO - 2026-08-18 18:15:25 --> Email Class Initialized
INFO - 2026-08-18 18:15:25 --> Controller Class Initialized
DEBUG - 2026-08-18 18:15:25 --> Invoicing MX_Controller Initialized
INFO - 2026-08-18 18:15:25 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:15:25 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:15:25 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:15:25 --> Model "Billing_model" initialized
INFO - 2026-08-18 18:15:25 --> Model "Common_model" initialized
INFO - 2026-08-18 18:15:25 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 18:15:28 --> Final output sent to browser
DEBUG - 2026-08-18 18:15:28 --> Total execution time: 8.8110
INFO - 2026-08-18 18:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:15:28 --> Upload Class Initialized
DEBUG - 2026-08-18 18:15:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:15:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:15:28 --> Encryption Class Initialized
INFO - 2026-08-18 18:15:28 --> Form Validation Class Initialized
INFO - 2026-08-18 18:15:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:15:28 --> Pagination Class Initialized
INFO - 2026-08-18 18:15:28 --> Email Class Initialized
INFO - 2026-08-18 18:15:28 --> Controller Class Initialized
DEBUG - 2026-08-18 18:15:28 --> Clientarea MX_Controller Initialized
INFO - 2026-08-18 18:15:28 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:15:28 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:15:28 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:15:28 --> Model "Clientarea_model" initialized
INFO - 2026-08-18 18:15:28 --> Model "Billing_model" initialized
INFO - 2026-08-18 18:15:28 --> Model "Common_model" initialized
INFO - 2026-08-18 18:15:28 --> Model "Order_model" initialized
INFO - 2026-08-18 18:15:28 --> Model "Support_model" initialized
INFO - 2026-08-18 18:15:29 --> Final output sent to browser
DEBUG - 2026-08-18 18:15:29 --> Total execution time: 9.6266
INFO - 2026-08-18 18:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:15:29 --> Upload Class Initialized
DEBUG - 2026-08-18 18:15:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:15:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:15:29 --> Encryption Class Initialized
INFO - 2026-08-18 18:15:29 --> Form Validation Class Initialized
INFO - 2026-08-18 18:15:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:15:29 --> Pagination Class Initialized
INFO - 2026-08-18 18:15:29 --> Email Class Initialized
INFO - 2026-08-18 18:15:29 --> Controller Class Initialized
DEBUG - 2026-08-18 18:15:29 --> Notifications MX_Controller Initialized
INFO - 2026-08-18 18:15:29 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:15:29 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:15:29 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:15:29 --> Model "Notification_model" initialized
INFO - 2026-08-18 18:15:32 --> Config Class Initialized
INFO - 2026-08-18 18:15:32 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:15:32 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:15:32 --> Utf8 Class Initialized
INFO - 2026-08-18 18:15:32 --> URI Class Initialized
INFO - 2026-08-18 18:15:32 --> Router Class Initialized
INFO - 2026-08-18 18:15:32 --> Output Class Initialized
INFO - 2026-08-18 18:15:32 --> Security Class Initialized
DEBUG - 2026-08-18 18:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:15:32 --> CSRF cookie sent
INFO - 2026-08-18 18:15:32 --> Input Class Initialized
INFO - 2026-08-18 18:15:32 --> Language Class Initialized
INFO - 2026-08-18 18:15:32 --> Language Class Initialized
INFO - 2026-08-18 18:15:32 --> Config Class Initialized
INFO - 2026-08-18 18:15:32 --> Loader Class Initialized
INFO - 2026-08-18 18:15:32 --> Helper loaded: url_helper
INFO - 2026-08-18 18:15:32 --> Helper loaded: form_helper
INFO - 2026-08-18 18:15:32 --> Helper loaded: html_helper
INFO - 2026-08-18 18:15:32 --> Helper loaded: file_helper
INFO - 2026-08-18 18:15:32 --> Helper loaded: email_helper
INFO - 2026-08-18 18:15:32 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:15:32 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:15:32 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:15:32 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:15:32 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:15:32 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:15:32 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:15:32 --> Database Driver Class Initialized
INFO - 2026-08-18 18:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:15:35 --> Upload Class Initialized
DEBUG - 2026-08-18 18:15:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:15:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:15:35 --> Encryption Class Initialized
INFO - 2026-08-18 18:15:35 --> Form Validation Class Initialized
INFO - 2026-08-18 18:15:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:15:35 --> Pagination Class Initialized
INFO - 2026-08-18 18:15:35 --> Email Class Initialized
INFO - 2026-08-18 18:15:35 --> Controller Class Initialized
DEBUG - 2026-08-18 18:15:35 --> Invoicing MX_Controller Initialized
INFO - 2026-08-18 18:15:35 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:15:35 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:15:35 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:15:35 --> Model "Billing_model" initialized
INFO - 2026-08-18 18:15:35 --> Model "Common_model" initialized
INFO - 2026-08-18 18:15:35 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-18 18:15:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-18 18:15:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-08-18 18:15:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-18 18:15:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-18 18:15:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/invoicing/views/invoicing_invoices.php
INFO - 2026-08-18 18:15:39 --> Final output sent to browser
DEBUG - 2026-08-18 18:15:39 --> Total execution time: 7.2509
INFO - 2026-08-18 18:15:39 --> Config Class Initialized
INFO - 2026-08-18 18:15:39 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:15:39 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:15:39 --> Utf8 Class Initialized
INFO - 2026-08-18 18:15:39 --> URI Class Initialized
INFO - 2026-08-18 18:15:39 --> Config Class Initialized
INFO - 2026-08-18 18:15:39 --> Hooks Class Initialized
INFO - 2026-08-18 18:15:39 --> Router Class Initialized
INFO - 2026-08-18 18:15:39 --> Output Class Initialized
DEBUG - 2026-08-18 18:15:39 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:15:39 --> Utf8 Class Initialized
INFO - 2026-08-18 18:15:39 --> Security Class Initialized
DEBUG - 2026-08-18 18:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:15:39 --> URI Class Initialized
INFO - 2026-08-18 18:15:39 --> CSRF cookie sent
INFO - 2026-08-18 18:15:39 --> Input Class Initialized
INFO - 2026-08-18 18:15:39 --> Language Class Initialized
INFO - 2026-08-18 18:15:39 --> Language Class Initialized
INFO - 2026-08-18 18:15:39 --> Config Class Initialized
INFO - 2026-08-18 18:15:39 --> Router Class Initialized
INFO - 2026-08-18 18:15:39 --> Loader Class Initialized
INFO - 2026-08-18 18:15:39 --> Output Class Initialized
INFO - 2026-08-18 18:15:39 --> Helper loaded: url_helper
INFO - 2026-08-18 18:15:39 --> Helper loaded: form_helper
INFO - 2026-08-18 18:15:39 --> Security Class Initialized
INFO - 2026-08-18 18:15:39 --> Helper loaded: html_helper
INFO - 2026-08-18 18:15:39 --> Helper loaded: file_helper
INFO - 2026-08-18 18:15:39 --> Helper loaded: email_helper
DEBUG - 2026-08-18 18:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:15:39 --> CSRF cookie sent
INFO - 2026-08-18 18:15:39 --> Input Class Initialized
INFO - 2026-08-18 18:15:39 --> Language Class Initialized
INFO - 2026-08-18 18:15:39 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:15:39 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:15:39 --> Language Class Initialized
INFO - 2026-08-18 18:15:39 --> Config Class Initialized
INFO - 2026-08-18 18:15:39 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:15:39 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:15:39 --> Loader Class Initialized
INFO - 2026-08-18 18:15:39 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:15:39 --> Helper loaded: url_helper
INFO - 2026-08-18 18:15:39 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:15:39 --> Helper loaded: form_helper
INFO - 2026-08-18 18:15:39 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:15:39 --> Helper loaded: html_helper
INFO - 2026-08-18 18:15:39 --> Helper loaded: file_helper
INFO - 2026-08-18 18:15:39 --> Helper loaded: email_helper
INFO - 2026-08-18 18:15:39 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:15:39 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:15:39 --> Database Driver Class Initialized
INFO - 2026-08-18 18:15:39 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:15:39 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:15:39 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:15:39 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:15:39 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:15:39 --> Database Driver Class Initialized
INFO - 2026-08-18 18:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:15:41 --> Upload Class Initialized
DEBUG - 2026-08-18 18:15:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:15:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:15:41 --> Encryption Class Initialized
INFO - 2026-08-18 18:15:41 --> Form Validation Class Initialized
INFO - 2026-08-18 18:15:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:15:41 --> Pagination Class Initialized
INFO - 2026-08-18 18:15:41 --> Email Class Initialized
INFO - 2026-08-18 18:15:41 --> Controller Class Initialized
DEBUG - 2026-08-18 18:15:41 --> Notifications MX_Controller Initialized
INFO - 2026-08-18 18:15:41 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:15:41 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:15:41 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:15:41 --> Model "Notification_model" initialized
INFO - 2026-08-18 18:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:15:43 --> Upload Class Initialized
DEBUG - 2026-08-18 18:15:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:15:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:15:43 --> Encryption Class Initialized
INFO - 2026-08-18 18:15:43 --> Form Validation Class Initialized
INFO - 2026-08-18 18:15:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:15:43 --> Pagination Class Initialized
INFO - 2026-08-18 18:15:43 --> Email Class Initialized
INFO - 2026-08-18 18:15:43 --> Controller Class Initialized
DEBUG - 2026-08-18 18:15:43 --> Cart MX_Controller Initialized
INFO - 2026-08-18 18:15:43 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:15:43 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:15:43 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:15:43 --> Model "Common_model" initialized
INFO - 2026-08-18 18:15:43 --> Model "Order_model" initialized
INFO - 2026-08-18 18:15:43 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 18:15:43 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 18:15:43 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 18:15:43 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 18:15:43 --> Model "Plan_model" initialized
INFO - 2026-08-18 18:15:43 --> Model "Orderlicense_model" initialized
INFO - 2026-08-18 18:15:43 --> Final output sent to browser
DEBUG - 2026-08-18 18:15:43 --> Total execution time: 4.1496
INFO - 2026-08-18 18:15:45 --> Config Class Initialized
INFO - 2026-08-18 18:15:45 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:15:45 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:15:45 --> Utf8 Class Initialized
INFO - 2026-08-18 18:15:45 --> URI Class Initialized
INFO - 2026-08-18 18:15:45 --> Router Class Initialized
INFO - 2026-08-18 18:15:45 --> Output Class Initialized
INFO - 2026-08-18 18:15:45 --> Security Class Initialized
DEBUG - 2026-08-18 18:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:15:45 --> CSRF cookie sent
INFO - 2026-08-18 18:15:45 --> Input Class Initialized
INFO - 2026-08-18 18:15:45 --> Language Class Initialized
INFO - 2026-08-18 18:15:45 --> Language Class Initialized
INFO - 2026-08-18 18:15:45 --> Config Class Initialized
INFO - 2026-08-18 18:15:45 --> Loader Class Initialized
INFO - 2026-08-18 18:15:45 --> Helper loaded: url_helper
INFO - 2026-08-18 18:15:45 --> Helper loaded: form_helper
INFO - 2026-08-18 18:15:45 --> Helper loaded: html_helper
INFO - 2026-08-18 18:15:45 --> Helper loaded: file_helper
INFO - 2026-08-18 18:15:45 --> Helper loaded: email_helper
INFO - 2026-08-18 18:15:45 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:15:45 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:15:45 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:15:45 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:15:45 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:15:45 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:15:45 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:15:45 --> Database Driver Class Initialized
INFO - 2026-08-18 18:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:15:48 --> Upload Class Initialized
DEBUG - 2026-08-18 18:15:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:15:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:15:48 --> Encryption Class Initialized
INFO - 2026-08-18 18:15:48 --> Form Validation Class Initialized
INFO - 2026-08-18 18:15:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:15:48 --> Pagination Class Initialized
INFO - 2026-08-18 18:15:48 --> Email Class Initialized
INFO - 2026-08-18 18:15:48 --> Controller Class Initialized
DEBUG - 2026-08-18 18:15:48 --> Invoicing MX_Controller Initialized
INFO - 2026-08-18 18:15:48 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:15:48 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:15:48 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:15:48 --> Model "Billing_model" initialized
INFO - 2026-08-18 18:15:48 --> Model "Common_model" initialized
INFO - 2026-08-18 18:15:48 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-18 18:15:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-18 18:15:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-08-18 18:15:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-18 18:15:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-18 18:15:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/invoicing/views/invoicing_invoices.php
INFO - 2026-08-18 18:15:51 --> Final output sent to browser
DEBUG - 2026-08-18 18:15:51 --> Total execution time: 5.4201
INFO - 2026-08-18 18:15:51 --> Config Class Initialized
INFO - 2026-08-18 18:15:51 --> Hooks Class Initialized
INFO - 2026-08-18 18:15:51 --> Config Class Initialized
INFO - 2026-08-18 18:15:51 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:15:51 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:15:51 --> Utf8 Class Initialized
INFO - 2026-08-18 18:15:51 --> URI Class Initialized
DEBUG - 2026-08-18 18:15:51 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:15:51 --> Utf8 Class Initialized
INFO - 2026-08-18 18:15:51 --> URI Class Initialized
INFO - 2026-08-18 18:15:51 --> Router Class Initialized
INFO - 2026-08-18 18:15:51 --> Router Class Initialized
INFO - 2026-08-18 18:15:51 --> Output Class Initialized
INFO - 2026-08-18 18:15:51 --> Output Class Initialized
INFO - 2026-08-18 18:15:51 --> Security Class Initialized
INFO - 2026-08-18 18:15:51 --> Security Class Initialized
DEBUG - 2026-08-18 18:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:15:51 --> CSRF cookie sent
INFO - 2026-08-18 18:15:51 --> Input Class Initialized
INFO - 2026-08-18 18:15:51 --> Language Class Initialized
DEBUG - 2026-08-18 18:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:15:51 --> CSRF cookie sent
INFO - 2026-08-18 18:15:51 --> Input Class Initialized
INFO - 2026-08-18 18:15:51 --> Language Class Initialized
INFO - 2026-08-18 18:15:51 --> Language Class Initialized
INFO - 2026-08-18 18:15:51 --> Config Class Initialized
INFO - 2026-08-18 18:15:51 --> Language Class Initialized
INFO - 2026-08-18 18:15:51 --> Config Class Initialized
INFO - 2026-08-18 18:15:51 --> Loader Class Initialized
INFO - 2026-08-18 18:15:51 --> Loader Class Initialized
INFO - 2026-08-18 18:15:51 --> Helper loaded: url_helper
INFO - 2026-08-18 18:15:51 --> Helper loaded: url_helper
INFO - 2026-08-18 18:15:51 --> Helper loaded: form_helper
INFO - 2026-08-18 18:15:51 --> Helper loaded: html_helper
INFO - 2026-08-18 18:15:51 --> Helper loaded: form_helper
INFO - 2026-08-18 18:15:51 --> Helper loaded: html_helper
INFO - 2026-08-18 18:15:51 --> Helper loaded: file_helper
INFO - 2026-08-18 18:15:51 --> Helper loaded: email_helper
INFO - 2026-08-18 18:15:51 --> Helper loaded: file_helper
INFO - 2026-08-18 18:15:51 --> Helper loaded: email_helper
INFO - 2026-08-18 18:15:51 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:15:51 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:15:51 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:15:51 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:15:51 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:15:51 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:15:51 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:15:51 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:15:51 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:15:51 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:15:51 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:15:51 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:15:51 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:15:51 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:15:51 --> Database Driver Class Initialized
INFO - 2026-08-18 18:15:51 --> Database Driver Class Initialized
INFO - 2026-08-18 18:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:15:52 --> Upload Class Initialized
DEBUG - 2026-08-18 18:15:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:15:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:15:52 --> Encryption Class Initialized
INFO - 2026-08-18 18:15:52 --> Form Validation Class Initialized
INFO - 2026-08-18 18:15:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:15:52 --> Pagination Class Initialized
INFO - 2026-08-18 18:15:52 --> Email Class Initialized
INFO - 2026-08-18 18:15:52 --> Controller Class Initialized
DEBUG - 2026-08-18 18:15:52 --> Cart MX_Controller Initialized
INFO - 2026-08-18 18:15:52 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:15:52 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:15:52 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:15:52 --> Model "Common_model" initialized
INFO - 2026-08-18 18:15:52 --> Model "Order_model" initialized
INFO - 2026-08-18 18:15:52 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 18:15:52 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 18:15:52 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 18:15:52 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 18:15:52 --> Model "Plan_model" initialized
INFO - 2026-08-18 18:15:52 --> Model "Orderlicense_model" initialized
INFO - 2026-08-18 18:15:53 --> Final output sent to browser
DEBUG - 2026-08-18 18:15:53 --> Total execution time: 2.0229
INFO - 2026-08-18 18:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:15:53 --> Upload Class Initialized
DEBUG - 2026-08-18 18:15:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:15:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:15:53 --> Encryption Class Initialized
INFO - 2026-08-18 18:15:53 --> Form Validation Class Initialized
INFO - 2026-08-18 18:15:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:15:53 --> Pagination Class Initialized
INFO - 2026-08-18 18:15:53 --> Email Class Initialized
INFO - 2026-08-18 18:15:53 --> Controller Class Initialized
DEBUG - 2026-08-18 18:15:53 --> Notifications MX_Controller Initialized
INFO - 2026-08-18 18:15:53 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:15:53 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:15:53 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:15:53 --> Model "Notification_model" initialized
INFO - 2026-08-18 18:15:56 --> Config Class Initialized
INFO - 2026-08-18 18:15:56 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:15:56 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:15:56 --> Utf8 Class Initialized
INFO - 2026-08-18 18:15:56 --> URI Class Initialized
INFO - 2026-08-18 18:15:56 --> Router Class Initialized
INFO - 2026-08-18 18:15:56 --> Output Class Initialized
INFO - 2026-08-18 18:15:56 --> Security Class Initialized
DEBUG - 2026-08-18 18:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:15:56 --> CSRF cookie sent
INFO - 2026-08-18 18:15:56 --> Input Class Initialized
INFO - 2026-08-18 18:15:56 --> Language Class Initialized
INFO - 2026-08-18 18:15:56 --> Language Class Initialized
INFO - 2026-08-18 18:15:56 --> Config Class Initialized
INFO - 2026-08-18 18:15:56 --> Loader Class Initialized
INFO - 2026-08-18 18:15:56 --> Helper loaded: url_helper
INFO - 2026-08-18 18:15:56 --> Helper loaded: form_helper
INFO - 2026-08-18 18:15:56 --> Helper loaded: html_helper
INFO - 2026-08-18 18:15:56 --> Helper loaded: file_helper
INFO - 2026-08-18 18:15:56 --> Helper loaded: email_helper
INFO - 2026-08-18 18:15:56 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:15:56 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:15:56 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:15:56 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:15:56 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:15:56 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:15:56 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:15:56 --> Database Driver Class Initialized
INFO - 2026-08-18 18:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:16:00 --> Upload Class Initialized
DEBUG - 2026-08-18 18:16:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:16:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:16:00 --> Encryption Class Initialized
INFO - 2026-08-18 18:16:00 --> Form Validation Class Initialized
INFO - 2026-08-18 18:16:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:16:00 --> Pagination Class Initialized
INFO - 2026-08-18 18:16:00 --> Email Class Initialized
INFO - 2026-08-18 18:16:00 --> Controller Class Initialized
DEBUG - 2026-08-18 18:16:00 --> Clientarea MX_Controller Initialized
INFO - 2026-08-18 18:16:00 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:16:00 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:16:00 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:16:00 --> Model "Clientarea_model" initialized
INFO - 2026-08-18 18:16:00 --> Model "Billing_model" initialized
INFO - 2026-08-18 18:16:00 --> Model "Common_model" initialized
INFO - 2026-08-18 18:16:00 --> Model "Order_model" initialized
INFO - 2026-08-18 18:16:00 --> Model "Support_model" initialized
DEBUG - 2026-08-18 18:16:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-18 18:16:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-08-18 18:16:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-18 18:16:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-18 18:16:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_domains.php
INFO - 2026-08-18 18:16:04 --> Final output sent to browser
DEBUG - 2026-08-18 18:16:04 --> Total execution time: 7.1726
INFO - 2026-08-18 18:16:04 --> Config Class Initialized
INFO - 2026-08-18 18:16:04 --> Hooks Class Initialized
INFO - 2026-08-18 18:16:04 --> Config Class Initialized
INFO - 2026-08-18 18:16:04 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:16:04 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:16:04 --> Utf8 Class Initialized
INFO - 2026-08-18 18:16:04 --> URI Class Initialized
INFO - 2026-08-18 18:16:04 --> Router Class Initialized
DEBUG - 2026-08-18 18:16:04 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:16:04 --> Utf8 Class Initialized
INFO - 2026-08-18 18:16:04 --> Output Class Initialized
INFO - 2026-08-18 18:16:04 --> URI Class Initialized
INFO - 2026-08-18 18:16:04 --> Security Class Initialized
INFO - 2026-08-18 18:16:04 --> Router Class Initialized
DEBUG - 2026-08-18 18:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:16:04 --> CSRF cookie sent
INFO - 2026-08-18 18:16:04 --> Input Class Initialized
INFO - 2026-08-18 18:16:04 --> Language Class Initialized
INFO - 2026-08-18 18:16:04 --> Output Class Initialized
INFO - 2026-08-18 18:16:04 --> Language Class Initialized
INFO - 2026-08-18 18:16:04 --> Config Class Initialized
INFO - 2026-08-18 18:16:04 --> Security Class Initialized
INFO - 2026-08-18 18:16:04 --> Loader Class Initialized
DEBUG - 2026-08-18 18:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:16:04 --> CSRF cookie sent
INFO - 2026-08-18 18:16:04 --> Input Class Initialized
INFO - 2026-08-18 18:16:04 --> Language Class Initialized
INFO - 2026-08-18 18:16:04 --> Helper loaded: url_helper
INFO - 2026-08-18 18:16:04 --> Language Class Initialized
INFO - 2026-08-18 18:16:04 --> Config Class Initialized
INFO - 2026-08-18 18:16:04 --> Helper loaded: form_helper
INFO - 2026-08-18 18:16:04 --> Helper loaded: html_helper
INFO - 2026-08-18 18:16:04 --> Helper loaded: file_helper
INFO - 2026-08-18 18:16:04 --> Helper loaded: email_helper
INFO - 2026-08-18 18:16:04 --> Loader Class Initialized
INFO - 2026-08-18 18:16:04 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:16:04 --> Helper loaded: url_helper
INFO - 2026-08-18 18:16:04 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:16:04 --> Helper loaded: form_helper
INFO - 2026-08-18 18:16:04 --> Helper loaded: html_helper
INFO - 2026-08-18 18:16:04 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:16:04 --> Helper loaded: file_helper
INFO - 2026-08-18 18:16:04 --> Helper loaded: email_helper
INFO - 2026-08-18 18:16:04 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:16:04 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:16:04 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:16:04 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:16:04 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:16:04 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:16:04 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:16:04 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:16:04 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:16:04 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:16:04 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:16:04 --> Database Driver Class Initialized
INFO - 2026-08-18 18:16:04 --> Database Driver Class Initialized
INFO - 2026-08-18 18:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:16:05 --> Upload Class Initialized
DEBUG - 2026-08-18 18:16:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:16:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:16:05 --> Encryption Class Initialized
INFO - 2026-08-18 18:16:05 --> Form Validation Class Initialized
INFO - 2026-08-18 18:16:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:16:05 --> Pagination Class Initialized
INFO - 2026-08-18 18:16:05 --> Email Class Initialized
INFO - 2026-08-18 18:16:05 --> Controller Class Initialized
DEBUG - 2026-08-18 18:16:05 --> Notifications MX_Controller Initialized
INFO - 2026-08-18 18:16:05 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:16:05 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:16:05 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:16:05 --> Model "Notification_model" initialized
INFO - 2026-08-18 18:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:16:07 --> Upload Class Initialized
DEBUG - 2026-08-18 18:16:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:16:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:16:07 --> Encryption Class Initialized
INFO - 2026-08-18 18:16:07 --> Form Validation Class Initialized
INFO - 2026-08-18 18:16:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:16:07 --> Pagination Class Initialized
INFO - 2026-08-18 18:16:07 --> Email Class Initialized
INFO - 2026-08-18 18:16:07 --> Controller Class Initialized
DEBUG - 2026-08-18 18:16:07 --> Cart MX_Controller Initialized
INFO - 2026-08-18 18:16:07 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:16:07 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:16:07 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:16:07 --> Model "Common_model" initialized
INFO - 2026-08-18 18:16:07 --> Model "Order_model" initialized
INFO - 2026-08-18 18:16:07 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 18:16:07 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 18:16:07 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 18:16:07 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 18:16:07 --> Model "Plan_model" initialized
INFO - 2026-08-18 18:16:07 --> Model "Orderlicense_model" initialized
INFO - 2026-08-18 18:16:07 --> Final output sent to browser
DEBUG - 2026-08-18 18:16:07 --> Total execution time: 3.7626
INFO - 2026-08-18 18:16:09 --> Config Class Initialized
INFO - 2026-08-18 18:16:09 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:16:09 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:16:09 --> Utf8 Class Initialized
INFO - 2026-08-18 18:16:09 --> URI Class Initialized
INFO - 2026-08-18 18:16:09 --> Router Class Initialized
INFO - 2026-08-18 18:16:09 --> Output Class Initialized
INFO - 2026-08-18 18:16:09 --> Security Class Initialized
DEBUG - 2026-08-18 18:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:16:09 --> CSRF cookie sent
INFO - 2026-08-18 18:16:09 --> Input Class Initialized
INFO - 2026-08-18 18:16:09 --> Language Class Initialized
INFO - 2026-08-18 18:16:09 --> Language Class Initialized
INFO - 2026-08-18 18:16:09 --> Config Class Initialized
INFO - 2026-08-18 18:16:09 --> Loader Class Initialized
INFO - 2026-08-18 18:16:09 --> Helper loaded: url_helper
INFO - 2026-08-18 18:16:09 --> Helper loaded: form_helper
INFO - 2026-08-18 18:16:09 --> Helper loaded: html_helper
INFO - 2026-08-18 18:16:09 --> Helper loaded: file_helper
INFO - 2026-08-18 18:16:09 --> Helper loaded: email_helper
INFO - 2026-08-18 18:16:09 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:16:09 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:16:09 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:16:09 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:16:09 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:16:09 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:16:09 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:16:09 --> Database Driver Class Initialized
INFO - 2026-08-18 18:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:16:12 --> Upload Class Initialized
DEBUG - 2026-08-18 18:16:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:16:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:16:12 --> Encryption Class Initialized
INFO - 2026-08-18 18:16:12 --> Form Validation Class Initialized
INFO - 2026-08-18 18:16:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:16:12 --> Pagination Class Initialized
INFO - 2026-08-18 18:16:12 --> Email Class Initialized
INFO - 2026-08-18 18:16:12 --> Controller Class Initialized
DEBUG - 2026-08-18 18:16:12 --> Clientarea MX_Controller Initialized
INFO - 2026-08-18 18:16:12 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:16:12 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:16:12 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:16:12 --> Model "Clientarea_model" initialized
INFO - 2026-08-18 18:16:12 --> Model "Billing_model" initialized
INFO - 2026-08-18 18:16:12 --> Model "Common_model" initialized
INFO - 2026-08-18 18:16:12 --> Model "Order_model" initialized
INFO - 2026-08-18 18:16:12 --> Model "Support_model" initialized
DEBUG - 2026-08-18 18:16:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-18 18:16:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-08-18 18:16:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-18 18:16:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-18 18:16:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_services.php
INFO - 2026-08-18 18:16:14 --> Final output sent to browser
DEBUG - 2026-08-18 18:16:14 --> Total execution time: 5.0491
INFO - 2026-08-18 18:16:15 --> Config Class Initialized
INFO - 2026-08-18 18:16:15 --> Hooks Class Initialized
INFO - 2026-08-18 18:16:15 --> Config Class Initialized
INFO - 2026-08-18 18:16:15 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:16:15 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:16:15 --> Utf8 Class Initialized
INFO - 2026-08-18 18:16:15 --> URI Class Initialized
DEBUG - 2026-08-18 18:16:15 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:16:15 --> Utf8 Class Initialized
INFO - 2026-08-18 18:16:15 --> URI Class Initialized
INFO - 2026-08-18 18:16:15 --> Router Class Initialized
INFO - 2026-08-18 18:16:15 --> Router Class Initialized
INFO - 2026-08-18 18:16:15 --> Output Class Initialized
INFO - 2026-08-18 18:16:15 --> Output Class Initialized
INFO - 2026-08-18 18:16:15 --> Security Class Initialized
INFO - 2026-08-18 18:16:15 --> Security Class Initialized
DEBUG - 2026-08-18 18:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:16:15 --> CSRF cookie sent
INFO - 2026-08-18 18:16:15 --> Input Class Initialized
DEBUG - 2026-08-18 18:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:16:15 --> CSRF cookie sent
INFO - 2026-08-18 18:16:15 --> Input Class Initialized
INFO - 2026-08-18 18:16:15 --> Language Class Initialized
INFO - 2026-08-18 18:16:15 --> Language Class Initialized
INFO - 2026-08-18 18:16:15 --> Language Class Initialized
INFO - 2026-08-18 18:16:15 --> Language Class Initialized
INFO - 2026-08-18 18:16:15 --> Config Class Initialized
INFO - 2026-08-18 18:16:15 --> Config Class Initialized
INFO - 2026-08-18 18:16:15 --> Loader Class Initialized
INFO - 2026-08-18 18:16:15 --> Loader Class Initialized
INFO - 2026-08-18 18:16:15 --> Helper loaded: url_helper
INFO - 2026-08-18 18:16:15 --> Helper loaded: url_helper
INFO - 2026-08-18 18:16:15 --> Helper loaded: form_helper
INFO - 2026-08-18 18:16:15 --> Helper loaded: form_helper
INFO - 2026-08-18 18:16:15 --> Helper loaded: html_helper
INFO - 2026-08-18 18:16:15 --> Helper loaded: html_helper
INFO - 2026-08-18 18:16:15 --> Helper loaded: file_helper
INFO - 2026-08-18 18:16:15 --> Helper loaded: file_helper
INFO - 2026-08-18 18:16:15 --> Helper loaded: email_helper
INFO - 2026-08-18 18:16:15 --> Helper loaded: email_helper
INFO - 2026-08-18 18:16:15 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:16:15 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:16:15 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:16:15 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:16:15 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:16:15 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:16:15 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:16:15 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:16:15 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:16:15 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:16:15 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:16:15 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:16:15 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:16:15 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:16:15 --> Database Driver Class Initialized
INFO - 2026-08-18 18:16:15 --> Database Driver Class Initialized
INFO - 2026-08-18 18:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:16:16 --> Upload Class Initialized
DEBUG - 2026-08-18 18:16:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:16:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:16:16 --> Encryption Class Initialized
INFO - 2026-08-18 18:16:16 --> Form Validation Class Initialized
INFO - 2026-08-18 18:16:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:16:16 --> Pagination Class Initialized
INFO - 2026-08-18 18:16:16 --> Email Class Initialized
INFO - 2026-08-18 18:16:16 --> Controller Class Initialized
DEBUG - 2026-08-18 18:16:16 --> Notifications MX_Controller Initialized
INFO - 2026-08-18 18:16:16 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:16:16 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:16:16 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:16:16 --> Model "Notification_model" initialized
INFO - 2026-08-18 18:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:16:18 --> Upload Class Initialized
DEBUG - 2026-08-18 18:16:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:16:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:16:18 --> Encryption Class Initialized
INFO - 2026-08-18 18:16:18 --> Form Validation Class Initialized
INFO - 2026-08-18 18:16:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:16:18 --> Pagination Class Initialized
INFO - 2026-08-18 18:16:18 --> Email Class Initialized
INFO - 2026-08-18 18:16:18 --> Controller Class Initialized
DEBUG - 2026-08-18 18:16:18 --> Cart MX_Controller Initialized
INFO - 2026-08-18 18:16:18 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:16:18 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:16:18 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:16:18 --> Model "Common_model" initialized
INFO - 2026-08-18 18:16:18 --> Model "Order_model" initialized
INFO - 2026-08-18 18:16:18 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 18:16:18 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 18:16:18 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 18:16:18 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 18:16:18 --> Model "Plan_model" initialized
INFO - 2026-08-18 18:16:18 --> Model "Orderlicense_model" initialized
INFO - 2026-08-18 18:16:18 --> Final output sent to browser
DEBUG - 2026-08-18 18:16:18 --> Total execution time: 3.9369
INFO - 2026-08-18 18:16:20 --> Config Class Initialized
INFO - 2026-08-18 18:16:20 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:16:20 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:16:20 --> Utf8 Class Initialized
INFO - 2026-08-18 18:16:20 --> URI Class Initialized
INFO - 2026-08-18 18:16:20 --> Router Class Initialized
INFO - 2026-08-18 18:16:20 --> Output Class Initialized
INFO - 2026-08-18 18:16:20 --> Security Class Initialized
DEBUG - 2026-08-18 18:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:16:20 --> CSRF cookie sent
INFO - 2026-08-18 18:16:20 --> Input Class Initialized
INFO - 2026-08-18 18:16:20 --> Language Class Initialized
INFO - 2026-08-18 18:16:20 --> Language Class Initialized
INFO - 2026-08-18 18:16:20 --> Config Class Initialized
INFO - 2026-08-18 18:16:20 --> Loader Class Initialized
INFO - 2026-08-18 18:16:20 --> Helper loaded: url_helper
INFO - 2026-08-18 18:16:20 --> Helper loaded: form_helper
INFO - 2026-08-18 18:16:20 --> Helper loaded: html_helper
INFO - 2026-08-18 18:16:20 --> Helper loaded: file_helper
INFO - 2026-08-18 18:16:20 --> Helper loaded: email_helper
INFO - 2026-08-18 18:16:20 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:16:20 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:16:20 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:16:20 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:16:20 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:16:20 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:16:20 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:16:20 --> Database Driver Class Initialized
INFO - 2026-08-18 18:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:16:22 --> Upload Class Initialized
DEBUG - 2026-08-18 18:16:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:16:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:16:22 --> Encryption Class Initialized
INFO - 2026-08-18 18:16:22 --> Form Validation Class Initialized
INFO - 2026-08-18 18:16:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:16:22 --> Pagination Class Initialized
INFO - 2026-08-18 18:16:22 --> Email Class Initialized
INFO - 2026-08-18 18:16:22 --> Controller Class Initialized
DEBUG - 2026-08-18 18:16:22 --> Clientarea MX_Controller Initialized
INFO - 2026-08-18 18:16:22 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:16:22 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:16:22 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:16:22 --> Model "Clientarea_model" initialized
INFO - 2026-08-18 18:16:22 --> Model "Billing_model" initialized
INFO - 2026-08-18 18:16:22 --> Model "Common_model" initialized
INFO - 2026-08-18 18:16:22 --> Model "Order_model" initialized
INFO - 2026-08-18 18:16:22 --> Model "Support_model" initialized
DEBUG - 2026-08-18 18:16:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-18 18:16:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/service_nav.php
DEBUG - 2026-08-18 18:16:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-18 18:16:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-18 18:16:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_service_detail.php
INFO - 2026-08-18 18:16:25 --> Final output sent to browser
DEBUG - 2026-08-18 18:16:25 --> Total execution time: 4.1974
INFO - 2026-08-18 18:16:25 --> Config Class Initialized
INFO - 2026-08-18 18:16:25 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:16:25 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:16:25 --> Utf8 Class Initialized
INFO - 2026-08-18 18:16:25 --> URI Class Initialized
INFO - 2026-08-18 18:16:25 --> Config Class Initialized
INFO - 2026-08-18 18:16:25 --> Hooks Class Initialized
INFO - 2026-08-18 18:16:25 --> Router Class Initialized
DEBUG - 2026-08-18 18:16:25 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:16:25 --> Utf8 Class Initialized
INFO - 2026-08-18 18:16:25 --> Output Class Initialized
INFO - 2026-08-18 18:16:25 --> URI Class Initialized
INFO - 2026-08-18 18:16:25 --> Security Class Initialized
INFO - 2026-08-18 18:16:25 --> Router Class Initialized
DEBUG - 2026-08-18 18:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:16:25 --> CSRF cookie sent
INFO - 2026-08-18 18:16:25 --> Input Class Initialized
INFO - 2026-08-18 18:16:25 --> Language Class Initialized
INFO - 2026-08-18 18:16:25 --> Output Class Initialized
INFO - 2026-08-18 18:16:25 --> Language Class Initialized
INFO - 2026-08-18 18:16:25 --> Config Class Initialized
INFO - 2026-08-18 18:16:25 --> Security Class Initialized
DEBUG - 2026-08-18 18:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:16:25 --> CSRF cookie sent
INFO - 2026-08-18 18:16:25 --> Input Class Initialized
INFO - 2026-08-18 18:16:25 --> Language Class Initialized
INFO - 2026-08-18 18:16:25 --> Loader Class Initialized
INFO - 2026-08-18 18:16:25 --> Language Class Initialized
INFO - 2026-08-18 18:16:25 --> Config Class Initialized
INFO - 2026-08-18 18:16:25 --> Helper loaded: url_helper
INFO - 2026-08-18 18:16:25 --> Helper loaded: form_helper
INFO - 2026-08-18 18:16:25 --> Helper loaded: html_helper
INFO - 2026-08-18 18:16:25 --> Loader Class Initialized
INFO - 2026-08-18 18:16:25 --> Helper loaded: file_helper
INFO - 2026-08-18 18:16:25 --> Helper loaded: email_helper
INFO - 2026-08-18 18:16:25 --> Helper loaded: url_helper
INFO - 2026-08-18 18:16:25 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:16:25 --> Helper loaded: form_helper
INFO - 2026-08-18 18:16:25 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:16:25 --> Helper loaded: html_helper
INFO - 2026-08-18 18:16:25 --> Helper loaded: file_helper
INFO - 2026-08-18 18:16:25 --> Helper loaded: email_helper
INFO - 2026-08-18 18:16:25 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:16:25 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:16:25 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:16:25 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:16:25 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:16:25 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:16:25 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:16:25 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:16:25 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:16:25 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:16:25 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:16:25 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:16:25 --> Database Driver Class Initialized
INFO - 2026-08-18 18:16:25 --> Database Driver Class Initialized
INFO - 2026-08-18 18:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:16:26 --> Upload Class Initialized
DEBUG - 2026-08-18 18:16:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:16:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:16:26 --> Encryption Class Initialized
INFO - 2026-08-18 18:16:26 --> Form Validation Class Initialized
INFO - 2026-08-18 18:16:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:16:26 --> Pagination Class Initialized
INFO - 2026-08-18 18:16:26 --> Email Class Initialized
INFO - 2026-08-18 18:16:26 --> Controller Class Initialized
DEBUG - 2026-08-18 18:16:26 --> Cart MX_Controller Initialized
INFO - 2026-08-18 18:16:26 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:16:26 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:16:26 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:16:26 --> Model "Common_model" initialized
INFO - 2026-08-18 18:16:26 --> Model "Order_model" initialized
INFO - 2026-08-18 18:16:26 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 18:16:26 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 18:16:26 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 18:16:26 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 18:16:26 --> Model "Plan_model" initialized
INFO - 2026-08-18 18:16:26 --> Model "Orderlicense_model" initialized
INFO - 2026-08-18 18:16:27 --> Final output sent to browser
DEBUG - 2026-08-18 18:16:27 --> Total execution time: 2.0556
INFO - 2026-08-18 18:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:16:27 --> Upload Class Initialized
DEBUG - 2026-08-18 18:16:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:16:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:16:27 --> Encryption Class Initialized
INFO - 2026-08-18 18:16:27 --> Form Validation Class Initialized
INFO - 2026-08-18 18:16:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:16:27 --> Pagination Class Initialized
INFO - 2026-08-18 18:16:27 --> Email Class Initialized
INFO - 2026-08-18 18:16:27 --> Controller Class Initialized
DEBUG - 2026-08-18 18:16:27 --> Notifications MX_Controller Initialized
INFO - 2026-08-18 18:16:27 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:16:27 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:16:27 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:16:27 --> Model "Notification_model" initialized
INFO - 2026-08-18 18:16:30 --> Config Class Initialized
INFO - 2026-08-18 18:16:30 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:16:30 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:16:30 --> Utf8 Class Initialized
INFO - 2026-08-18 18:16:30 --> URI Class Initialized
INFO - 2026-08-18 18:16:30 --> Router Class Initialized
INFO - 2026-08-18 18:16:30 --> Output Class Initialized
INFO - 2026-08-18 18:16:30 --> Security Class Initialized
DEBUG - 2026-08-18 18:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:16:30 --> CSRF cookie sent
INFO - 2026-08-18 18:16:30 --> Input Class Initialized
INFO - 2026-08-18 18:16:30 --> Language Class Initialized
INFO - 2026-08-18 18:16:30 --> Language Class Initialized
INFO - 2026-08-18 18:16:30 --> Config Class Initialized
INFO - 2026-08-18 18:16:30 --> Loader Class Initialized
INFO - 2026-08-18 18:16:30 --> Helper loaded: url_helper
INFO - 2026-08-18 18:16:30 --> Helper loaded: form_helper
INFO - 2026-08-18 18:16:30 --> Helper loaded: html_helper
INFO - 2026-08-18 18:16:30 --> Helper loaded: file_helper
INFO - 2026-08-18 18:16:30 --> Helper loaded: email_helper
INFO - 2026-08-18 18:16:30 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:16:30 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:16:30 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:16:30 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:16:30 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:16:30 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:16:30 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:16:30 --> Database Driver Class Initialized
INFO - 2026-08-18 18:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:16:32 --> Upload Class Initialized
DEBUG - 2026-08-18 18:16:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:16:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:16:32 --> Encryption Class Initialized
INFO - 2026-08-18 18:16:32 --> Form Validation Class Initialized
INFO - 2026-08-18 18:16:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:16:32 --> Pagination Class Initialized
INFO - 2026-08-18 18:16:32 --> Email Class Initialized
INFO - 2026-08-18 18:16:32 --> Controller Class Initialized
DEBUG - 2026-08-18 18:16:32 --> Cart MX_Controller Initialized
INFO - 2026-08-18 18:16:32 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:16:32 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:16:32 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:16:32 --> Model "Common_model" initialized
INFO - 2026-08-18 18:16:32 --> Model "Order_model" initialized
INFO - 2026-08-18 18:16:32 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 18:16:32 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 18:16:32 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 18:16:32 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 18:16:32 --> Model "Plan_model" initialized
INFO - 2026-08-18 18:16:32 --> Model "Orderlicense_model" initialized
DEBUG - 2026-08-18 18:16:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-18 18:16:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-08-18 18:16:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-08-18 18:16:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-18 18:16:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-18 18:16:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/cart_services.php
INFO - 2026-08-18 18:16:34 --> Final output sent to browser
DEBUG - 2026-08-18 18:16:34 --> Total execution time: 3.9341
INFO - 2026-08-18 18:16:34 --> Config Class Initialized
INFO - 2026-08-18 18:16:34 --> Hooks Class Initialized
INFO - 2026-08-18 18:16:34 --> Config Class Initialized
INFO - 2026-08-18 18:16:34 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:16:34 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:16:34 --> Utf8 Class Initialized
DEBUG - 2026-08-18 18:16:34 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:16:34 --> URI Class Initialized
INFO - 2026-08-18 18:16:34 --> Utf8 Class Initialized
INFO - 2026-08-18 18:16:34 --> URI Class Initialized
INFO - 2026-08-18 18:16:34 --> Router Class Initialized
INFO - 2026-08-18 18:16:34 --> Router Class Initialized
INFO - 2026-08-18 18:16:34 --> Output Class Initialized
INFO - 2026-08-18 18:16:34 --> Output Class Initialized
INFO - 2026-08-18 18:16:34 --> Security Class Initialized
INFO - 2026-08-18 18:16:34 --> Security Class Initialized
DEBUG - 2026-08-18 18:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:16:34 --> CSRF cookie sent
INFO - 2026-08-18 18:16:34 --> Input Class Initialized
INFO - 2026-08-18 18:16:34 --> Language Class Initialized
DEBUG - 2026-08-18 18:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:16:34 --> CSRF cookie sent
INFO - 2026-08-18 18:16:34 --> Input Class Initialized
INFO - 2026-08-18 18:16:34 --> Language Class Initialized
INFO - 2026-08-18 18:16:34 --> Language Class Initialized
INFO - 2026-08-18 18:16:34 --> Config Class Initialized
INFO - 2026-08-18 18:16:34 --> Language Class Initialized
INFO - 2026-08-18 18:16:34 --> Config Class Initialized
INFO - 2026-08-18 18:16:34 --> Loader Class Initialized
INFO - 2026-08-18 18:16:34 --> Loader Class Initialized
INFO - 2026-08-18 18:16:34 --> Helper loaded: url_helper
INFO - 2026-08-18 18:16:34 --> Helper loaded: url_helper
INFO - 2026-08-18 18:16:34 --> Helper loaded: form_helper
INFO - 2026-08-18 18:16:34 --> Helper loaded: html_helper
INFO - 2026-08-18 18:16:34 --> Helper loaded: form_helper
INFO - 2026-08-18 18:16:34 --> Helper loaded: html_helper
INFO - 2026-08-18 18:16:34 --> Helper loaded: file_helper
INFO - 2026-08-18 18:16:34 --> Helper loaded: file_helper
INFO - 2026-08-18 18:16:34 --> Helper loaded: email_helper
INFO - 2026-08-18 18:16:34 --> Helper loaded: email_helper
INFO - 2026-08-18 18:16:34 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:16:34 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:16:34 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:16:34 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:16:34 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:16:34 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:16:34 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:16:34 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:16:34 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:16:34 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:16:34 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:16:34 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:16:34 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:16:34 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:16:34 --> Database Driver Class Initialized
INFO - 2026-08-18 18:16:34 --> Database Driver Class Initialized
INFO - 2026-08-18 18:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:16:35 --> Upload Class Initialized
DEBUG - 2026-08-18 18:16:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:16:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:16:35 --> Encryption Class Initialized
INFO - 2026-08-18 18:16:35 --> Form Validation Class Initialized
INFO - 2026-08-18 18:16:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:16:35 --> Pagination Class Initialized
INFO - 2026-08-18 18:16:35 --> Email Class Initialized
INFO - 2026-08-18 18:16:35 --> Controller Class Initialized
DEBUG - 2026-08-18 18:16:35 --> Notifications MX_Controller Initialized
INFO - 2026-08-18 18:16:35 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:16:35 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:16:35 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:16:35 --> Model "Notification_model" initialized
INFO - 2026-08-18 18:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:16:36 --> Upload Class Initialized
DEBUG - 2026-08-18 18:16:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:16:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:16:36 --> Encryption Class Initialized
INFO - 2026-08-18 18:16:36 --> Form Validation Class Initialized
INFO - 2026-08-18 18:16:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:16:36 --> Pagination Class Initialized
INFO - 2026-08-18 18:16:36 --> Email Class Initialized
INFO - 2026-08-18 18:16:36 --> Controller Class Initialized
DEBUG - 2026-08-18 18:16:36 --> Cart MX_Controller Initialized
INFO - 2026-08-18 18:16:36 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:16:36 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:16:36 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:16:36 --> Model "Common_model" initialized
INFO - 2026-08-18 18:16:36 --> Model "Order_model" initialized
INFO - 2026-08-18 18:16:36 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 18:16:36 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 18:16:36 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 18:16:36 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 18:16:36 --> Model "Plan_model" initialized
INFO - 2026-08-18 18:16:36 --> Model "Orderlicense_model" initialized
INFO - 2026-08-18 18:16:37 --> Final output sent to browser
DEBUG - 2026-08-18 18:16:37 --> Total execution time: 3.0459
INFO - 2026-08-18 18:16:39 --> Config Class Initialized
INFO - 2026-08-18 18:16:39 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:16:39 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:16:39 --> Utf8 Class Initialized
INFO - 2026-08-18 18:16:39 --> URI Class Initialized
INFO - 2026-08-18 18:16:39 --> Router Class Initialized
INFO - 2026-08-18 18:16:39 --> Output Class Initialized
INFO - 2026-08-18 18:16:39 --> Security Class Initialized
DEBUG - 2026-08-18 18:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:16:39 --> CSRF cookie sent
INFO - 2026-08-18 18:16:39 --> Input Class Initialized
INFO - 2026-08-18 18:16:39 --> Language Class Initialized
INFO - 2026-08-18 18:16:39 --> Language Class Initialized
INFO - 2026-08-18 18:16:39 --> Config Class Initialized
INFO - 2026-08-18 18:16:39 --> Loader Class Initialized
INFO - 2026-08-18 18:16:39 --> Helper loaded: url_helper
INFO - 2026-08-18 18:16:39 --> Helper loaded: form_helper
INFO - 2026-08-18 18:16:39 --> Helper loaded: html_helper
INFO - 2026-08-18 18:16:39 --> Helper loaded: file_helper
INFO - 2026-08-18 18:16:39 --> Helper loaded: email_helper
INFO - 2026-08-18 18:16:39 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:16:39 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:16:39 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:16:39 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:16:39 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:16:39 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:16:39 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:16:39 --> Database Driver Class Initialized
INFO - 2026-08-18 18:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:16:42 --> Upload Class Initialized
DEBUG - 2026-08-18 18:16:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:16:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:16:42 --> Encryption Class Initialized
INFO - 2026-08-18 18:16:42 --> Form Validation Class Initialized
INFO - 2026-08-18 18:16:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:16:42 --> Pagination Class Initialized
INFO - 2026-08-18 18:16:42 --> Email Class Initialized
INFO - 2026-08-18 18:16:42 --> Controller Class Initialized
DEBUG - 2026-08-18 18:16:42 --> Cart MX_Controller Initialized
INFO - 2026-08-18 18:16:42 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:16:42 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:16:42 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:16:42 --> Model "Common_model" initialized
INFO - 2026-08-18 18:16:42 --> Model "Order_model" initialized
INFO - 2026-08-18 18:16:42 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 18:16:42 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 18:16:42 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 18:16:42 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 18:16:42 --> Model "Plan_model" initialized
INFO - 2026-08-18 18:16:42 --> Model "Orderlicense_model" initialized
DEBUG - 2026-08-18 18:16:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-18 18:16:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-08-18 18:16:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-08-18 18:16:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-18 18:16:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-18 18:16:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/cart_regnewdomain.php
INFO - 2026-08-18 18:16:44 --> Final output sent to browser
DEBUG - 2026-08-18 18:16:44 --> Total execution time: 5.6966
INFO - 2026-08-18 18:16:45 --> Config Class Initialized
INFO - 2026-08-18 18:16:45 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:16:45 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:16:45 --> Utf8 Class Initialized
INFO - 2026-08-18 18:16:45 --> URI Class Initialized
INFO - 2026-08-18 18:16:45 --> Router Class Initialized
INFO - 2026-08-18 18:16:45 --> Config Class Initialized
INFO - 2026-08-18 18:16:45 --> Hooks Class Initialized
INFO - 2026-08-18 18:16:45 --> Output Class Initialized
DEBUG - 2026-08-18 18:16:45 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:16:45 --> Utf8 Class Initialized
INFO - 2026-08-18 18:16:45 --> Security Class Initialized
INFO - 2026-08-18 18:16:45 --> URI Class Initialized
DEBUG - 2026-08-18 18:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:16:45 --> CSRF cookie sent
INFO - 2026-08-18 18:16:45 --> Input Class Initialized
INFO - 2026-08-18 18:16:45 --> Language Class Initialized
INFO - 2026-08-18 18:16:45 --> Language Class Initialized
INFO - 2026-08-18 18:16:45 --> Config Class Initialized
INFO - 2026-08-18 18:16:45 --> Router Class Initialized
INFO - 2026-08-18 18:16:45 --> Loader Class Initialized
INFO - 2026-08-18 18:16:45 --> Output Class Initialized
INFO - 2026-08-18 18:16:45 --> Helper loaded: url_helper
INFO - 2026-08-18 18:16:45 --> Helper loaded: form_helper
INFO - 2026-08-18 18:16:45 --> Helper loaded: html_helper
INFO - 2026-08-18 18:16:45 --> Security Class Initialized
INFO - 2026-08-18 18:16:45 --> Helper loaded: file_helper
INFO - 2026-08-18 18:16:45 --> Helper loaded: email_helper
DEBUG - 2026-08-18 18:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:16:45 --> CSRF cookie sent
INFO - 2026-08-18 18:16:45 --> Input Class Initialized
INFO - 2026-08-18 18:16:45 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:16:45 --> Language Class Initialized
INFO - 2026-08-18 18:16:45 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:16:45 --> Language Class Initialized
INFO - 2026-08-18 18:16:45 --> Config Class Initialized
INFO - 2026-08-18 18:16:45 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:16:45 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:16:45 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:16:45 --> Loader Class Initialized
INFO - 2026-08-18 18:16:45 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:16:45 --> Helper loaded: url_helper
INFO - 2026-08-18 18:16:45 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:16:45 --> Helper loaded: form_helper
INFO - 2026-08-18 18:16:45 --> Helper loaded: html_helper
INFO - 2026-08-18 18:16:45 --> Helper loaded: file_helper
INFO - 2026-08-18 18:16:45 --> Helper loaded: email_helper
INFO - 2026-08-18 18:16:45 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:16:45 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:16:45 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:16:45 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:16:45 --> Database Driver Class Initialized
INFO - 2026-08-18 18:16:45 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:16:45 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:16:45 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:16:45 --> Database Driver Class Initialized
INFO - 2026-08-18 18:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:16:46 --> Upload Class Initialized
DEBUG - 2026-08-18 18:16:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:16:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:16:46 --> Encryption Class Initialized
INFO - 2026-08-18 18:16:46 --> Form Validation Class Initialized
INFO - 2026-08-18 18:16:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:16:46 --> Pagination Class Initialized
INFO - 2026-08-18 18:16:46 --> Email Class Initialized
INFO - 2026-08-18 18:16:46 --> Controller Class Initialized
DEBUG - 2026-08-18 18:16:46 --> Cart MX_Controller Initialized
INFO - 2026-08-18 18:16:46 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:16:46 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:16:46 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:16:46 --> Model "Common_model" initialized
INFO - 2026-08-18 18:16:46 --> Model "Order_model" initialized
INFO - 2026-08-18 18:16:46 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 18:16:46 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 18:16:46 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 18:16:46 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 18:16:46 --> Model "Plan_model" initialized
INFO - 2026-08-18 18:16:46 --> Model "Orderlicense_model" initialized
INFO - 2026-08-18 18:16:47 --> Final output sent to browser
DEBUG - 2026-08-18 18:16:47 --> Total execution time: 2.1427
INFO - 2026-08-18 18:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:16:47 --> Upload Class Initialized
DEBUG - 2026-08-18 18:16:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:16:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:16:47 --> Encryption Class Initialized
INFO - 2026-08-18 18:16:47 --> Form Validation Class Initialized
INFO - 2026-08-18 18:16:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:16:47 --> Pagination Class Initialized
INFO - 2026-08-18 18:16:47 --> Email Class Initialized
INFO - 2026-08-18 18:16:47 --> Controller Class Initialized
DEBUG - 2026-08-18 18:16:47 --> Notifications MX_Controller Initialized
INFO - 2026-08-18 18:16:47 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:16:47 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:16:47 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:16:47 --> Model "Notification_model" initialized
INFO - 2026-08-18 18:17:01 --> Config Class Initialized
INFO - 2026-08-18 18:17:01 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:17:01 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:17:01 --> Utf8 Class Initialized
INFO - 2026-08-18 18:17:01 --> URI Class Initialized
INFO - 2026-08-18 18:17:01 --> Router Class Initialized
INFO - 2026-08-18 18:17:01 --> Output Class Initialized
INFO - 2026-08-18 18:17:01 --> Security Class Initialized
DEBUG - 2026-08-18 18:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:17:01 --> CSRF cookie sent
INFO - 2026-08-18 18:17:01 --> Input Class Initialized
INFO - 2026-08-18 18:17:01 --> Language Class Initialized
INFO - 2026-08-18 18:17:01 --> Language Class Initialized
INFO - 2026-08-18 18:17:01 --> Config Class Initialized
INFO - 2026-08-18 18:17:01 --> Loader Class Initialized
INFO - 2026-08-18 18:17:01 --> Helper loaded: url_helper
INFO - 2026-08-18 18:17:01 --> Helper loaded: form_helper
INFO - 2026-08-18 18:17:01 --> Helper loaded: html_helper
INFO - 2026-08-18 18:17:01 --> Helper loaded: file_helper
INFO - 2026-08-18 18:17:01 --> Helper loaded: email_helper
INFO - 2026-08-18 18:17:01 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:17:01 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:17:01 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:17:01 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:17:01 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:17:01 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:17:01 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:17:01 --> Database Driver Class Initialized
INFO - 2026-08-18 18:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:17:04 --> Upload Class Initialized
DEBUG - 2026-08-18 18:17:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:17:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:17:04 --> Encryption Class Initialized
INFO - 2026-08-18 18:17:04 --> Form Validation Class Initialized
INFO - 2026-08-18 18:17:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:17:04 --> Pagination Class Initialized
INFO - 2026-08-18 18:17:04 --> Email Class Initialized
INFO - 2026-08-18 18:17:04 --> Controller Class Initialized
DEBUG - 2026-08-18 18:17:04 --> Cart MX_Controller Initialized
INFO - 2026-08-18 18:17:04 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:17:04 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:17:04 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:17:04 --> Model "Common_model" initialized
INFO - 2026-08-18 18:17:04 --> Model "Order_model" initialized
INFO - 2026-08-18 18:17:04 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 18:17:04 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 18:17:04 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 18:17:04 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 18:17:04 --> Model "Plan_model" initialized
INFO - 2026-08-18 18:17:04 --> Model "Orderlicense_model" initialized
DEBUG - 2026-08-18 18:17:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-18 18:17:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-08-18 18:17:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-08-18 18:17:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-18 18:17:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-18 18:17:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/view_card.php
INFO - 2026-08-18 18:17:08 --> Final output sent to browser
DEBUG - 2026-08-18 18:17:08 --> Total execution time: 7.0007
INFO - 2026-08-18 18:17:08 --> Config Class Initialized
INFO - 2026-08-18 18:17:08 --> Hooks Class Initialized
INFO - 2026-08-18 18:17:08 --> Config Class Initialized
INFO - 2026-08-18 18:17:08 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:17:08 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:17:08 --> Utf8 Class Initialized
INFO - 2026-08-18 18:17:08 --> URI Class Initialized
DEBUG - 2026-08-18 18:17:08 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:17:08 --> Utf8 Class Initialized
INFO - 2026-08-18 18:17:08 --> Router Class Initialized
INFO - 2026-08-18 18:17:08 --> URI Class Initialized
INFO - 2026-08-18 18:17:08 --> Output Class Initialized
INFO - 2026-08-18 18:17:08 --> Security Class Initialized
INFO - 2026-08-18 18:17:08 --> Router Class Initialized
DEBUG - 2026-08-18 18:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:17:08 --> CSRF cookie sent
INFO - 2026-08-18 18:17:08 --> Input Class Initialized
INFO - 2026-08-18 18:17:08 --> Language Class Initialized
INFO - 2026-08-18 18:17:08 --> Output Class Initialized
INFO - 2026-08-18 18:17:08 --> Language Class Initialized
INFO - 2026-08-18 18:17:08 --> Config Class Initialized
INFO - 2026-08-18 18:17:08 --> Security Class Initialized
INFO - 2026-08-18 18:17:08 --> Loader Class Initialized
DEBUG - 2026-08-18 18:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:17:08 --> CSRF cookie sent
INFO - 2026-08-18 18:17:08 --> Input Class Initialized
INFO - 2026-08-18 18:17:08 --> Language Class Initialized
INFO - 2026-08-18 18:17:08 --> Helper loaded: url_helper
INFO - 2026-08-18 18:17:08 --> Language Class Initialized
INFO - 2026-08-18 18:17:08 --> Config Class Initialized
INFO - 2026-08-18 18:17:08 --> Helper loaded: form_helper
INFO - 2026-08-18 18:17:08 --> Helper loaded: html_helper
INFO - 2026-08-18 18:17:08 --> Helper loaded: file_helper
INFO - 2026-08-18 18:17:08 --> Helper loaded: email_helper
INFO - 2026-08-18 18:17:08 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:17:08 --> Loader Class Initialized
INFO - 2026-08-18 18:17:08 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:17:08 --> Helper loaded: url_helper
INFO - 2026-08-18 18:17:08 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:17:08 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:17:08 --> Helper loaded: form_helper
INFO - 2026-08-18 18:17:08 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:17:08 --> Helper loaded: html_helper
INFO - 2026-08-18 18:17:08 --> Helper loaded: file_helper
INFO - 2026-08-18 18:17:08 --> Helper loaded: email_helper
INFO - 2026-08-18 18:17:08 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:17:08 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:17:08 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:17:08 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:17:08 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:17:08 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:17:08 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:17:08 --> Database Driver Class Initialized
INFO - 2026-08-18 18:17:08 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:17:08 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:17:08 --> Database Driver Class Initialized
INFO - 2026-08-18 18:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:17:10 --> Upload Class Initialized
DEBUG - 2026-08-18 18:17:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:17:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:17:10 --> Encryption Class Initialized
INFO - 2026-08-18 18:17:10 --> Form Validation Class Initialized
INFO - 2026-08-18 18:17:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:17:10 --> Pagination Class Initialized
INFO - 2026-08-18 18:17:10 --> Email Class Initialized
INFO - 2026-08-18 18:17:10 --> Controller Class Initialized
DEBUG - 2026-08-18 18:17:10 --> Cart MX_Controller Initialized
INFO - 2026-08-18 18:17:10 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:17:10 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:17:10 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:17:10 --> Model "Common_model" initialized
INFO - 2026-08-18 18:17:10 --> Model "Order_model" initialized
INFO - 2026-08-18 18:17:10 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 18:17:10 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 18:17:10 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 18:17:10 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 18:17:10 --> Model "Plan_model" initialized
INFO - 2026-08-18 18:17:10 --> Model "Orderlicense_model" initialized
INFO - 2026-08-18 18:17:10 --> Final output sent to browser
DEBUG - 2026-08-18 18:17:10 --> Total execution time: 2.0510
INFO - 2026-08-18 18:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:17:10 --> Upload Class Initialized
DEBUG - 2026-08-18 18:17:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:17:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:17:10 --> Encryption Class Initialized
INFO - 2026-08-18 18:17:10 --> Form Validation Class Initialized
INFO - 2026-08-18 18:17:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:17:10 --> Pagination Class Initialized
INFO - 2026-08-18 18:17:10 --> Email Class Initialized
INFO - 2026-08-18 18:17:10 --> Controller Class Initialized
DEBUG - 2026-08-18 18:17:10 --> Notifications MX_Controller Initialized
INFO - 2026-08-18 18:17:10 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:17:10 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:17:10 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:17:10 --> Model "Notification_model" initialized
INFO - 2026-08-18 18:17:13 --> Config Class Initialized
INFO - 2026-08-18 18:17:13 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:17:13 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:17:13 --> Utf8 Class Initialized
INFO - 2026-08-18 18:17:13 --> URI Class Initialized
INFO - 2026-08-18 18:17:13 --> Router Class Initialized
INFO - 2026-08-18 18:17:13 --> Output Class Initialized
INFO - 2026-08-18 18:17:13 --> Security Class Initialized
DEBUG - 2026-08-18 18:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:17:13 --> CSRF cookie sent
INFO - 2026-08-18 18:17:13 --> Input Class Initialized
INFO - 2026-08-18 18:17:13 --> Language Class Initialized
INFO - 2026-08-18 18:17:13 --> Language Class Initialized
INFO - 2026-08-18 18:17:13 --> Config Class Initialized
INFO - 2026-08-18 18:17:13 --> Loader Class Initialized
INFO - 2026-08-18 18:17:13 --> Helper loaded: url_helper
INFO - 2026-08-18 18:17:13 --> Helper loaded: form_helper
INFO - 2026-08-18 18:17:13 --> Helper loaded: html_helper
INFO - 2026-08-18 18:17:13 --> Helper loaded: file_helper
INFO - 2026-08-18 18:17:13 --> Helper loaded: email_helper
INFO - 2026-08-18 18:17:13 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:17:13 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:17:13 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:17:13 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:17:13 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:17:13 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:17:13 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:17:13 --> Database Driver Class Initialized
INFO - 2026-08-18 18:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:17:15 --> Upload Class Initialized
DEBUG - 2026-08-18 18:17:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:17:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:17:15 --> Encryption Class Initialized
INFO - 2026-08-18 18:17:15 --> Form Validation Class Initialized
INFO - 2026-08-18 18:17:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:17:15 --> Pagination Class Initialized
INFO - 2026-08-18 18:17:15 --> Email Class Initialized
INFO - 2026-08-18 18:17:15 --> Controller Class Initialized
DEBUG - 2026-08-18 18:17:15 --> Tickets MX_Controller Initialized
INFO - 2026-08-18 18:17:15 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:17:15 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:17:15 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:17:15 --> Model "Support_model" initialized
INFO - 2026-08-18 18:17:15 --> Model "Common_model" initialized
DEBUG - 2026-08-18 18:17:17 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-18 18:17:17 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/support_nav.php
DEBUG - 2026-08-18 18:17:17 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-18 18:17:17 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-18 18:17:17 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/tickets/views/tickets.php
INFO - 2026-08-18 18:17:17 --> Final output sent to browser
DEBUG - 2026-08-18 18:17:17 --> Total execution time: 3.4894
INFO - 2026-08-18 18:17:17 --> Config Class Initialized
INFO - 2026-08-18 18:17:17 --> Config Class Initialized
INFO - 2026-08-18 18:17:17 --> Hooks Class Initialized
INFO - 2026-08-18 18:17:17 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:17:17 --> UTF-8 Support Enabled
DEBUG - 2026-08-18 18:17:17 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:17:17 --> Utf8 Class Initialized
INFO - 2026-08-18 18:17:17 --> Utf8 Class Initialized
INFO - 2026-08-18 18:17:17 --> URI Class Initialized
INFO - 2026-08-18 18:17:17 --> URI Class Initialized
INFO - 2026-08-18 18:17:17 --> Router Class Initialized
INFO - 2026-08-18 18:17:17 --> Router Class Initialized
INFO - 2026-08-18 18:17:17 --> Output Class Initialized
INFO - 2026-08-18 18:17:17 --> Output Class Initialized
INFO - 2026-08-18 18:17:17 --> Security Class Initialized
INFO - 2026-08-18 18:17:17 --> Security Class Initialized
DEBUG - 2026-08-18 18:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-08-18 18:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:17:17 --> CSRF cookie sent
INFO - 2026-08-18 18:17:17 --> CSRF cookie sent
INFO - 2026-08-18 18:17:17 --> Input Class Initialized
INFO - 2026-08-18 18:17:17 --> Input Class Initialized
INFO - 2026-08-18 18:17:17 --> Language Class Initialized
INFO - 2026-08-18 18:17:17 --> Language Class Initialized
INFO - 2026-08-18 18:17:17 --> Language Class Initialized
INFO - 2026-08-18 18:17:17 --> Language Class Initialized
INFO - 2026-08-18 18:17:17 --> Config Class Initialized
INFO - 2026-08-18 18:17:17 --> Config Class Initialized
INFO - 2026-08-18 18:17:17 --> Loader Class Initialized
INFO - 2026-08-18 18:17:17 --> Loader Class Initialized
INFO - 2026-08-18 18:17:17 --> Helper loaded: url_helper
INFO - 2026-08-18 18:17:17 --> Helper loaded: url_helper
INFO - 2026-08-18 18:17:17 --> Helper loaded: form_helper
INFO - 2026-08-18 18:17:17 --> Helper loaded: form_helper
INFO - 2026-08-18 18:17:17 --> Helper loaded: html_helper
INFO - 2026-08-18 18:17:17 --> Helper loaded: html_helper
INFO - 2026-08-18 18:17:17 --> Helper loaded: file_helper
INFO - 2026-08-18 18:17:17 --> Helper loaded: file_helper
INFO - 2026-08-18 18:17:17 --> Helper loaded: email_helper
INFO - 2026-08-18 18:17:17 --> Helper loaded: email_helper
INFO - 2026-08-18 18:17:17 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:17:17 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:17:17 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:17:17 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:17:17 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:17:17 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:17:17 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:17:17 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:17:17 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:17:17 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:17:17 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:17:17 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:17:17 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:17:17 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:17:17 --> Database Driver Class Initialized
INFO - 2026-08-18 18:17:17 --> Database Driver Class Initialized
INFO - 2026-08-18 18:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:17:19 --> Upload Class Initialized
DEBUG - 2026-08-18 18:17:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:17:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:17:19 --> Encryption Class Initialized
INFO - 2026-08-18 18:17:19 --> Form Validation Class Initialized
INFO - 2026-08-18 18:17:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:17:19 --> Pagination Class Initialized
INFO - 2026-08-18 18:17:19 --> Email Class Initialized
INFO - 2026-08-18 18:17:19 --> Controller Class Initialized
DEBUG - 2026-08-18 18:17:19 --> Cart MX_Controller Initialized
INFO - 2026-08-18 18:17:19 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:17:19 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:17:19 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:17:19 --> Model "Common_model" initialized
INFO - 2026-08-18 18:17:19 --> Model "Order_model" initialized
INFO - 2026-08-18 18:17:19 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 18:17:19 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 18:17:19 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 18:17:19 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 18:17:19 --> Model "Plan_model" initialized
INFO - 2026-08-18 18:17:19 --> Model "Orderlicense_model" initialized
INFO - 2026-08-18 18:17:19 --> Final output sent to browser
DEBUG - 2026-08-18 18:17:19 --> Total execution time: 2.0860
INFO - 2026-08-18 18:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:17:19 --> Upload Class Initialized
DEBUG - 2026-08-18 18:17:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:17:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:17:19 --> Encryption Class Initialized
INFO - 2026-08-18 18:17:19 --> Form Validation Class Initialized
INFO - 2026-08-18 18:17:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:17:19 --> Pagination Class Initialized
INFO - 2026-08-18 18:17:19 --> Email Class Initialized
INFO - 2026-08-18 18:17:19 --> Controller Class Initialized
DEBUG - 2026-08-18 18:17:19 --> Notifications MX_Controller Initialized
INFO - 2026-08-18 18:17:19 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:17:19 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:17:19 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:17:19 --> Model "Notification_model" initialized
INFO - 2026-08-18 18:17:23 --> Config Class Initialized
INFO - 2026-08-18 18:17:23 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:17:23 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:17:23 --> Utf8 Class Initialized
INFO - 2026-08-18 18:17:23 --> URI Class Initialized
INFO - 2026-08-18 18:17:23 --> Router Class Initialized
INFO - 2026-08-18 18:17:23 --> Output Class Initialized
INFO - 2026-08-18 18:17:23 --> Security Class Initialized
DEBUG - 2026-08-18 18:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:17:23 --> CSRF cookie sent
INFO - 2026-08-18 18:17:23 --> Input Class Initialized
INFO - 2026-08-18 18:17:23 --> Language Class Initialized
INFO - 2026-08-18 18:17:23 --> Language Class Initialized
INFO - 2026-08-18 18:17:23 --> Config Class Initialized
INFO - 2026-08-18 18:17:23 --> Loader Class Initialized
INFO - 2026-08-18 18:17:23 --> Helper loaded: url_helper
INFO - 2026-08-18 18:17:23 --> Helper loaded: form_helper
INFO - 2026-08-18 18:17:23 --> Helper loaded: html_helper
INFO - 2026-08-18 18:17:23 --> Helper loaded: file_helper
INFO - 2026-08-18 18:17:23 --> Helper loaded: email_helper
INFO - 2026-08-18 18:17:23 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:17:23 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:17:23 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:17:23 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:17:23 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:17:23 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:17:23 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:17:23 --> Database Driver Class Initialized
INFO - 2026-08-18 18:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:17:27 --> Upload Class Initialized
DEBUG - 2026-08-18 18:17:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:17:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:17:27 --> Encryption Class Initialized
INFO - 2026-08-18 18:17:27 --> Form Validation Class Initialized
INFO - 2026-08-18 18:17:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:17:27 --> Pagination Class Initialized
INFO - 2026-08-18 18:17:27 --> Email Class Initialized
INFO - 2026-08-18 18:17:27 --> Controller Class Initialized
ERROR - 2026-08-18 18:17:27 --> 404 Page Not Found: ../modules/tickets/controllers/Tickets/newticket
INFO - 2026-08-18 18:17:29 --> Config Class Initialized
INFO - 2026-08-18 18:17:29 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:17:29 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:17:29 --> Utf8 Class Initialized
INFO - 2026-08-18 18:17:29 --> URI Class Initialized
INFO - 2026-08-18 18:17:29 --> Router Class Initialized
INFO - 2026-08-18 18:17:29 --> Output Class Initialized
INFO - 2026-08-18 18:17:29 --> Security Class Initialized
DEBUG - 2026-08-18 18:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:17:29 --> CSRF cookie sent
INFO - 2026-08-18 18:17:29 --> Input Class Initialized
INFO - 2026-08-18 18:17:29 --> Language Class Initialized
INFO - 2026-08-18 18:17:29 --> Language Class Initialized
INFO - 2026-08-18 18:17:29 --> Config Class Initialized
INFO - 2026-08-18 18:17:29 --> Loader Class Initialized
INFO - 2026-08-18 18:17:29 --> Helper loaded: url_helper
INFO - 2026-08-18 18:17:29 --> Helper loaded: form_helper
INFO - 2026-08-18 18:17:29 --> Helper loaded: html_helper
INFO - 2026-08-18 18:17:29 --> Helper loaded: file_helper
INFO - 2026-08-18 18:17:29 --> Helper loaded: email_helper
INFO - 2026-08-18 18:17:29 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:17:29 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:17:29 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:17:29 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:17:29 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:17:29 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:17:29 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:17:29 --> Database Driver Class Initialized
INFO - 2026-08-18 18:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:17:30 --> Upload Class Initialized
DEBUG - 2026-08-18 18:17:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:17:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:17:30 --> Encryption Class Initialized
INFO - 2026-08-18 18:17:30 --> Form Validation Class Initialized
INFO - 2026-08-18 18:17:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:17:30 --> Pagination Class Initialized
INFO - 2026-08-18 18:17:30 --> Email Class Initialized
INFO - 2026-08-18 18:17:30 --> Controller Class Initialized
DEBUG - 2026-08-18 18:17:30 --> Supports MX_Controller Initialized
INFO - 2026-08-18 18:17:30 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:17:30 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:17:30 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:17:30 --> Model "Support_model" initialized
INFO - 2026-08-18 18:17:30 --> Model "Common_model" initialized
INFO - 2026-08-18 18:17:30 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-18 18:17:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-18 18:17:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/support_nav.php
DEBUG - 2026-08-18 18:17:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-18 18:17:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-18 18:17:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/supports/views/support_kb_list.php
INFO - 2026-08-18 18:17:32 --> Final output sent to browser
DEBUG - 2026-08-18 18:17:32 --> Total execution time: 3.5760
INFO - 2026-08-18 18:17:32 --> Config Class Initialized
INFO - 2026-08-18 18:17:32 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:17:32 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:17:32 --> Utf8 Class Initialized
INFO - 2026-08-18 18:17:32 --> URI Class Initialized
INFO - 2026-08-18 18:17:32 --> Config Class Initialized
INFO - 2026-08-18 18:17:32 --> Hooks Class Initialized
INFO - 2026-08-18 18:17:32 --> Router Class Initialized
DEBUG - 2026-08-18 18:17:32 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:17:32 --> Utf8 Class Initialized
INFO - 2026-08-18 18:17:32 --> URI Class Initialized
INFO - 2026-08-18 18:17:32 --> Output Class Initialized
INFO - 2026-08-18 18:17:32 --> Router Class Initialized
INFO - 2026-08-18 18:17:32 --> Security Class Initialized
INFO - 2026-08-18 18:17:32 --> Output Class Initialized
DEBUG - 2026-08-18 18:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:17:32 --> CSRF cookie sent
INFO - 2026-08-18 18:17:32 --> Input Class Initialized
INFO - 2026-08-18 18:17:32 --> Language Class Initialized
INFO - 2026-08-18 18:17:32 --> Security Class Initialized
DEBUG - 2026-08-18 18:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:17:32 --> CSRF cookie sent
INFO - 2026-08-18 18:17:32 --> Input Class Initialized
INFO - 2026-08-18 18:17:32 --> Language Class Initialized
INFO - 2026-08-18 18:17:32 --> Language Class Initialized
INFO - 2026-08-18 18:17:32 --> Config Class Initialized
INFO - 2026-08-18 18:17:32 --> Language Class Initialized
INFO - 2026-08-18 18:17:32 --> Config Class Initialized
INFO - 2026-08-18 18:17:32 --> Loader Class Initialized
INFO - 2026-08-18 18:17:32 --> Loader Class Initialized
INFO - 2026-08-18 18:17:32 --> Helper loaded: url_helper
INFO - 2026-08-18 18:17:32 --> Helper loaded: url_helper
INFO - 2026-08-18 18:17:32 --> Helper loaded: form_helper
INFO - 2026-08-18 18:17:32 --> Helper loaded: html_helper
INFO - 2026-08-18 18:17:32 --> Helper loaded: form_helper
INFO - 2026-08-18 18:17:32 --> Helper loaded: file_helper
INFO - 2026-08-18 18:17:32 --> Helper loaded: email_helper
INFO - 2026-08-18 18:17:32 --> Helper loaded: html_helper
INFO - 2026-08-18 18:17:32 --> Helper loaded: file_helper
INFO - 2026-08-18 18:17:32 --> Helper loaded: email_helper
INFO - 2026-08-18 18:17:32 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:17:32 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:17:32 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:17:32 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:17:32 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:17:32 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:17:32 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:17:32 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:17:32 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:17:32 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:17:32 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:17:32 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:17:32 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:17:32 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:17:32 --> Database Driver Class Initialized
INFO - 2026-08-18 18:17:32 --> Database Driver Class Initialized
INFO - 2026-08-18 18:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:17:34 --> Upload Class Initialized
DEBUG - 2026-08-18 18:17:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:17:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:17:34 --> Encryption Class Initialized
INFO - 2026-08-18 18:17:34 --> Form Validation Class Initialized
INFO - 2026-08-18 18:17:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:17:34 --> Pagination Class Initialized
INFO - 2026-08-18 18:17:34 --> Email Class Initialized
INFO - 2026-08-18 18:17:34 --> Controller Class Initialized
DEBUG - 2026-08-18 18:17:34 --> Cart MX_Controller Initialized
INFO - 2026-08-18 18:17:34 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:17:34 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:17:34 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:17:34 --> Model "Common_model" initialized
INFO - 2026-08-18 18:17:34 --> Model "Order_model" initialized
INFO - 2026-08-18 18:17:34 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 18:17:34 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 18:17:34 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 18:17:34 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 18:17:34 --> Model "Plan_model" initialized
INFO - 2026-08-18 18:17:34 --> Model "Orderlicense_model" initialized
INFO - 2026-08-18 18:17:34 --> Final output sent to browser
DEBUG - 2026-08-18 18:17:34 --> Total execution time: 2.0998
INFO - 2026-08-18 18:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:17:35 --> Upload Class Initialized
DEBUG - 2026-08-18 18:17:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:17:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:17:35 --> Encryption Class Initialized
INFO - 2026-08-18 18:17:35 --> Form Validation Class Initialized
INFO - 2026-08-18 18:17:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:17:35 --> Pagination Class Initialized
INFO - 2026-08-18 18:17:35 --> Email Class Initialized
INFO - 2026-08-18 18:17:35 --> Controller Class Initialized
DEBUG - 2026-08-18 18:17:35 --> Notifications MX_Controller Initialized
INFO - 2026-08-18 18:17:35 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:17:35 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:17:35 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:17:35 --> Model "Notification_model" initialized
INFO - 2026-08-18 18:17:38 --> Config Class Initialized
INFO - 2026-08-18 18:17:38 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:17:38 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:17:38 --> Utf8 Class Initialized
INFO - 2026-08-18 18:17:38 --> URI Class Initialized
INFO - 2026-08-18 18:17:38 --> Router Class Initialized
INFO - 2026-08-18 18:17:38 --> Output Class Initialized
INFO - 2026-08-18 18:17:38 --> Security Class Initialized
DEBUG - 2026-08-18 18:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:17:38 --> CSRF cookie sent
INFO - 2026-08-18 18:17:38 --> Input Class Initialized
INFO - 2026-08-18 18:17:38 --> Language Class Initialized
INFO - 2026-08-18 18:17:38 --> Language Class Initialized
INFO - 2026-08-18 18:17:38 --> Config Class Initialized
INFO - 2026-08-18 18:17:38 --> Loader Class Initialized
INFO - 2026-08-18 18:17:38 --> Helper loaded: url_helper
INFO - 2026-08-18 18:17:38 --> Helper loaded: form_helper
INFO - 2026-08-18 18:17:38 --> Helper loaded: html_helper
INFO - 2026-08-18 18:17:38 --> Helper loaded: file_helper
INFO - 2026-08-18 18:17:38 --> Helper loaded: email_helper
INFO - 2026-08-18 18:17:38 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:17:38 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:17:38 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:17:38 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:17:38 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:17:38 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:17:38 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:17:38 --> Database Driver Class Initialized
INFO - 2026-08-18 18:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:17:40 --> Upload Class Initialized
DEBUG - 2026-08-18 18:17:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:17:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:17:40 --> Encryption Class Initialized
INFO - 2026-08-18 18:17:40 --> Form Validation Class Initialized
INFO - 2026-08-18 18:17:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:17:40 --> Pagination Class Initialized
INFO - 2026-08-18 18:17:40 --> Email Class Initialized
INFO - 2026-08-18 18:17:40 --> Controller Class Initialized
DEBUG - 2026-08-18 18:17:40 --> Supports MX_Controller Initialized
INFO - 2026-08-18 18:17:40 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:17:40 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:17:40 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:17:40 --> Model "Support_model" initialized
INFO - 2026-08-18 18:17:40 --> Model "Common_model" initialized
INFO - 2026-08-18 18:17:40 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-18 18:17:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-18 18:17:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/support_nav.php
DEBUG - 2026-08-18 18:17:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-18 18:17:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-18 18:17:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/supports/views/support_announcement_list.php
INFO - 2026-08-18 18:17:42 --> Final output sent to browser
DEBUG - 2026-08-18 18:17:42 --> Total execution time: 3.8761
INFO - 2026-08-18 18:17:42 --> Config Class Initialized
INFO - 2026-08-18 18:17:42 --> Hooks Class Initialized
INFO - 2026-08-18 18:17:42 --> Config Class Initialized
INFO - 2026-08-18 18:17:42 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:17:42 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:17:42 --> Utf8 Class Initialized
DEBUG - 2026-08-18 18:17:42 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:17:42 --> Utf8 Class Initialized
INFO - 2026-08-18 18:17:42 --> URI Class Initialized
INFO - 2026-08-18 18:17:42 --> URI Class Initialized
INFO - 2026-08-18 18:17:42 --> Router Class Initialized
INFO - 2026-08-18 18:17:42 --> Router Class Initialized
INFO - 2026-08-18 18:17:42 --> Output Class Initialized
INFO - 2026-08-18 18:17:42 --> Output Class Initialized
INFO - 2026-08-18 18:17:42 --> Security Class Initialized
INFO - 2026-08-18 18:17:42 --> Security Class Initialized
DEBUG - 2026-08-18 18:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-08-18 18:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:17:42 --> CSRF cookie sent
INFO - 2026-08-18 18:17:42 --> CSRF cookie sent
INFO - 2026-08-18 18:17:42 --> Input Class Initialized
INFO - 2026-08-18 18:17:42 --> Input Class Initialized
INFO - 2026-08-18 18:17:42 --> Language Class Initialized
INFO - 2026-08-18 18:17:42 --> Language Class Initialized
INFO - 2026-08-18 18:17:42 --> Language Class Initialized
INFO - 2026-08-18 18:17:42 --> Language Class Initialized
INFO - 2026-08-18 18:17:42 --> Config Class Initialized
INFO - 2026-08-18 18:17:42 --> Config Class Initialized
INFO - 2026-08-18 18:17:42 --> Loader Class Initialized
INFO - 2026-08-18 18:17:42 --> Loader Class Initialized
INFO - 2026-08-18 18:17:42 --> Helper loaded: url_helper
INFO - 2026-08-18 18:17:42 --> Helper loaded: url_helper
INFO - 2026-08-18 18:17:42 --> Helper loaded: form_helper
INFO - 2026-08-18 18:17:42 --> Helper loaded: form_helper
INFO - 2026-08-18 18:17:42 --> Helper loaded: html_helper
INFO - 2026-08-18 18:17:42 --> Helper loaded: html_helper
INFO - 2026-08-18 18:17:42 --> Helper loaded: file_helper
INFO - 2026-08-18 18:17:42 --> Helper loaded: file_helper
INFO - 2026-08-18 18:17:42 --> Helper loaded: email_helper
INFO - 2026-08-18 18:17:42 --> Helper loaded: email_helper
INFO - 2026-08-18 18:17:42 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:17:42 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:17:42 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:17:42 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:17:42 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:17:42 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:17:42 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:17:42 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:17:42 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:17:42 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:17:42 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:17:42 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:17:42 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:17:42 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:17:42 --> Database Driver Class Initialized
INFO - 2026-08-18 18:17:42 --> Database Driver Class Initialized
INFO - 2026-08-18 18:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:17:44 --> Upload Class Initialized
DEBUG - 2026-08-18 18:17:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:17:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:17:44 --> Encryption Class Initialized
INFO - 2026-08-18 18:17:44 --> Form Validation Class Initialized
INFO - 2026-08-18 18:17:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:17:44 --> Pagination Class Initialized
INFO - 2026-08-18 18:17:44 --> Email Class Initialized
INFO - 2026-08-18 18:17:44 --> Controller Class Initialized
DEBUG - 2026-08-18 18:17:44 --> Notifications MX_Controller Initialized
INFO - 2026-08-18 18:17:44 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:17:44 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:17:44 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:17:44 --> Model "Notification_model" initialized
INFO - 2026-08-18 18:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:17:44 --> Upload Class Initialized
DEBUG - 2026-08-18 18:17:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:17:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:17:44 --> Encryption Class Initialized
INFO - 2026-08-18 18:17:44 --> Form Validation Class Initialized
INFO - 2026-08-18 18:17:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:17:44 --> Pagination Class Initialized
INFO - 2026-08-18 18:17:44 --> Email Class Initialized
INFO - 2026-08-18 18:17:44 --> Controller Class Initialized
DEBUG - 2026-08-18 18:17:44 --> Cart MX_Controller Initialized
INFO - 2026-08-18 18:17:44 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:17:44 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:17:44 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:17:44 --> Model "Common_model" initialized
INFO - 2026-08-18 18:17:44 --> Model "Order_model" initialized
INFO - 2026-08-18 18:17:44 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 18:17:44 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 18:17:44 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 18:17:44 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 18:17:44 --> Model "Plan_model" initialized
INFO - 2026-08-18 18:17:44 --> Model "Orderlicense_model" initialized
INFO - 2026-08-18 18:17:45 --> Final output sent to browser
DEBUG - 2026-08-18 18:17:45 --> Total execution time: 2.8225
INFO - 2026-08-18 18:17:47 --> Config Class Initialized
INFO - 2026-08-18 18:17:47 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:17:47 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:17:47 --> Utf8 Class Initialized
INFO - 2026-08-18 18:17:47 --> URI Class Initialized
INFO - 2026-08-18 18:17:47 --> Router Class Initialized
INFO - 2026-08-18 18:17:47 --> Output Class Initialized
INFO - 2026-08-18 18:17:47 --> Security Class Initialized
DEBUG - 2026-08-18 18:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:17:47 --> CSRF cookie sent
INFO - 2026-08-18 18:17:47 --> Input Class Initialized
INFO - 2026-08-18 18:17:47 --> Language Class Initialized
INFO - 2026-08-18 18:17:47 --> Language Class Initialized
INFO - 2026-08-18 18:17:47 --> Config Class Initialized
INFO - 2026-08-18 18:17:47 --> Loader Class Initialized
INFO - 2026-08-18 18:17:47 --> Helper loaded: url_helper
INFO - 2026-08-18 18:17:47 --> Helper loaded: form_helper
INFO - 2026-08-18 18:17:47 --> Helper loaded: html_helper
INFO - 2026-08-18 18:17:47 --> Helper loaded: file_helper
INFO - 2026-08-18 18:17:47 --> Helper loaded: email_helper
INFO - 2026-08-18 18:17:47 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:17:47 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:17:47 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:17:47 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:17:47 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:17:47 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:17:47 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:17:47 --> Database Driver Class Initialized
INFO - 2026-08-18 18:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:17:49 --> Upload Class Initialized
DEBUG - 2026-08-18 18:17:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:17:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:17:49 --> Encryption Class Initialized
INFO - 2026-08-18 18:17:49 --> Form Validation Class Initialized
INFO - 2026-08-18 18:17:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:17:49 --> Pagination Class Initialized
INFO - 2026-08-18 18:17:49 --> Email Class Initialized
INFO - 2026-08-18 18:17:49 --> Controller Class Initialized
DEBUG - 2026-08-18 18:17:49 --> Supports MX_Controller Initialized
INFO - 2026-08-18 18:17:49 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:17:49 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:17:49 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:17:49 --> Model "Support_model" initialized
INFO - 2026-08-18 18:17:49 --> Model "Common_model" initialized
INFO - 2026-08-18 18:17:49 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-18 18:17:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-18 18:17:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-18 18:17:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-18 18:17:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/supports/views/support_contactus.php
INFO - 2026-08-18 18:17:50 --> Final output sent to browser
DEBUG - 2026-08-18 18:17:50 --> Total execution time: 3.2933
INFO - 2026-08-18 18:17:50 --> Config Class Initialized
INFO - 2026-08-18 18:17:50 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:17:50 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:17:50 --> Utf8 Class Initialized
INFO - 2026-08-18 18:17:50 --> URI Class Initialized
INFO - 2026-08-18 18:17:50 --> Config Class Initialized
INFO - 2026-08-18 18:17:50 --> Hooks Class Initialized
INFO - 2026-08-18 18:17:50 --> Router Class Initialized
DEBUG - 2026-08-18 18:17:50 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:17:50 --> Utf8 Class Initialized
INFO - 2026-08-18 18:17:50 --> URI Class Initialized
INFO - 2026-08-18 18:17:50 --> Output Class Initialized
INFO - 2026-08-18 18:17:50 --> Security Class Initialized
INFO - 2026-08-18 18:17:50 --> Router Class Initialized
DEBUG - 2026-08-18 18:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:17:50 --> CSRF cookie sent
INFO - 2026-08-18 18:17:50 --> Input Class Initialized
INFO - 2026-08-18 18:17:50 --> Language Class Initialized
INFO - 2026-08-18 18:17:50 --> Output Class Initialized
INFO - 2026-08-18 18:17:50 --> Language Class Initialized
INFO - 2026-08-18 18:17:50 --> Config Class Initialized
INFO - 2026-08-18 18:17:50 --> Security Class Initialized
DEBUG - 2026-08-18 18:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:17:50 --> CSRF cookie sent
INFO - 2026-08-18 18:17:50 --> Input Class Initialized
INFO - 2026-08-18 18:17:50 --> Language Class Initialized
INFO - 2026-08-18 18:17:50 --> Loader Class Initialized
INFO - 2026-08-18 18:17:50 --> Language Class Initialized
INFO - 2026-08-18 18:17:50 --> Config Class Initialized
INFO - 2026-08-18 18:17:50 --> Helper loaded: url_helper
INFO - 2026-08-18 18:17:50 --> Helper loaded: form_helper
INFO - 2026-08-18 18:17:50 --> Helper loaded: html_helper
INFO - 2026-08-18 18:17:50 --> Loader Class Initialized
INFO - 2026-08-18 18:17:50 --> Helper loaded: file_helper
INFO - 2026-08-18 18:17:50 --> Helper loaded: email_helper
INFO - 2026-08-18 18:17:50 --> Helper loaded: url_helper
INFO - 2026-08-18 18:17:50 --> Helper loaded: form_helper
INFO - 2026-08-18 18:17:50 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:17:50 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:17:50 --> Helper loaded: html_helper
INFO - 2026-08-18 18:17:50 --> Helper loaded: file_helper
INFO - 2026-08-18 18:17:50 --> Helper loaded: email_helper
INFO - 2026-08-18 18:17:50 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:17:50 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:17:50 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:17:50 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:17:50 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:17:50 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:17:50 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:17:50 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:17:50 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:17:50 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:17:50 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:17:50 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:17:50 --> Database Driver Class Initialized
INFO - 2026-08-18 18:17:50 --> Database Driver Class Initialized
INFO - 2026-08-18 18:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:17:52 --> Upload Class Initialized
DEBUG - 2026-08-18 18:17:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:17:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:17:52 --> Encryption Class Initialized
INFO - 2026-08-18 18:17:52 --> Form Validation Class Initialized
INFO - 2026-08-18 18:17:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:17:52 --> Pagination Class Initialized
INFO - 2026-08-18 18:17:52 --> Email Class Initialized
INFO - 2026-08-18 18:17:52 --> Controller Class Initialized
DEBUG - 2026-08-18 18:17:52 --> Cart MX_Controller Initialized
INFO - 2026-08-18 18:17:52 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:17:52 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:17:52 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:17:52 --> Model "Common_model" initialized
INFO - 2026-08-18 18:17:52 --> Model "Order_model" initialized
INFO - 2026-08-18 18:17:52 --> Model "Appsetting_model" initialized
INFO - 2026-08-18 18:17:52 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-18 18:17:52 --> Model "Promocode_model" initialized
DEBUG - 2026-08-18 18:17:52 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-18 18:17:52 --> Model "Plan_model" initialized
INFO - 2026-08-18 18:17:52 --> Model "Orderlicense_model" initialized
INFO - 2026-08-18 18:17:52 --> Final output sent to browser
DEBUG - 2026-08-18 18:17:52 --> Total execution time: 2.1776
INFO - 2026-08-18 18:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:17:53 --> Upload Class Initialized
DEBUG - 2026-08-18 18:17:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:17:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:17:53 --> Encryption Class Initialized
INFO - 2026-08-18 18:17:53 --> Form Validation Class Initialized
INFO - 2026-08-18 18:17:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:17:53 --> Pagination Class Initialized
INFO - 2026-08-18 18:17:53 --> Email Class Initialized
INFO - 2026-08-18 18:17:53 --> Controller Class Initialized
DEBUG - 2026-08-18 18:17:53 --> Notifications MX_Controller Initialized
INFO - 2026-08-18 18:17:53 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:17:53 --> Model "Auth_model" initialized
INFO - 2026-08-18 18:17:53 --> Model "Cart_model" initialized
INFO - 2026-08-18 18:17:53 --> Model "Notification_model" initialized
INFO - 2026-08-18 18:17:57 --> Config Class Initialized
INFO - 2026-08-18 18:17:57 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:17:57 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:17:57 --> Utf8 Class Initialized
INFO - 2026-08-18 18:17:57 --> URI Class Initialized
INFO - 2026-08-18 18:17:57 --> Router Class Initialized
INFO - 2026-08-18 18:17:57 --> Output Class Initialized
INFO - 2026-08-18 18:17:57 --> Security Class Initialized
DEBUG - 2026-08-18 18:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:17:57 --> CSRF cookie sent
INFO - 2026-08-18 18:17:57 --> Input Class Initialized
INFO - 2026-08-18 18:17:57 --> Language Class Initialized
INFO - 2026-08-18 18:17:57 --> Language Class Initialized
INFO - 2026-08-18 18:17:57 --> Config Class Initialized
INFO - 2026-08-18 18:17:57 --> Loader Class Initialized
INFO - 2026-08-18 18:17:57 --> Helper loaded: url_helper
INFO - 2026-08-18 18:17:57 --> Helper loaded: form_helper
INFO - 2026-08-18 18:17:57 --> Helper loaded: html_helper
INFO - 2026-08-18 18:17:57 --> Helper loaded: file_helper
INFO - 2026-08-18 18:17:57 --> Helper loaded: email_helper
INFO - 2026-08-18 18:17:57 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:17:57 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:17:57 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:17:57 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:17:57 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:17:57 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:17:57 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:17:57 --> Database Driver Class Initialized
INFO - 2026-08-18 18:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:17:59 --> Upload Class Initialized
DEBUG - 2026-08-18 18:17:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:17:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:17:59 --> Encryption Class Initialized
INFO - 2026-08-18 18:17:59 --> Form Validation Class Initialized
INFO - 2026-08-18 18:17:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:17:59 --> Pagination Class Initialized
INFO - 2026-08-18 18:17:59 --> Email Class Initialized
INFO - 2026-08-18 18:17:59 --> Controller Class Initialized
DEBUG - 2026-08-18 18:17:59 --> Authenticate MX_Controller Initialized
INFO - 2026-08-18 18:17:59 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:17:59 --> Model "Adminauth_model" initialized
INFO - 2026-08-18 18:17:59 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-18 18:17:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-08-18 18:17:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-08-18 18:17:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-08-18 18:17:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-08-18 18:17:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-08-18 18:17:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-08-18 18:17:59 --> Final output sent to browser
DEBUG - 2026-08-18 18:17:59 --> Total execution time: 2.2542
INFO - 2026-08-18 18:18:02 --> Config Class Initialized
INFO - 2026-08-18 18:18:02 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:18:02 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:18:02 --> Utf8 Class Initialized
INFO - 2026-08-18 18:18:02 --> URI Class Initialized
INFO - 2026-08-18 18:18:02 --> Router Class Initialized
INFO - 2026-08-18 18:18:02 --> Output Class Initialized
INFO - 2026-08-18 18:18:02 --> Security Class Initialized
DEBUG - 2026-08-18 18:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:18:02 --> CSRF cookie sent
INFO - 2026-08-18 18:18:02 --> Input Class Initialized
INFO - 2026-08-18 18:18:02 --> Language Class Initialized
INFO - 2026-08-18 18:18:02 --> Language Class Initialized
INFO - 2026-08-18 18:18:02 --> Config Class Initialized
INFO - 2026-08-18 18:18:02 --> Loader Class Initialized
INFO - 2026-08-18 18:18:02 --> Helper loaded: url_helper
INFO - 2026-08-18 18:18:02 --> Helper loaded: form_helper
INFO - 2026-08-18 18:18:02 --> Helper loaded: html_helper
INFO - 2026-08-18 18:18:02 --> Helper loaded: file_helper
INFO - 2026-08-18 18:18:02 --> Helper loaded: email_helper
INFO - 2026-08-18 18:18:02 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:18:02 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:18:02 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:18:02 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:18:02 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:18:02 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:18:02 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:18:02 --> Database Driver Class Initialized
INFO - 2026-08-18 18:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:18:05 --> Upload Class Initialized
DEBUG - 2026-08-18 18:18:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:18:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:18:05 --> Encryption Class Initialized
INFO - 2026-08-18 18:18:05 --> Form Validation Class Initialized
INFO - 2026-08-18 18:18:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:18:05 --> Pagination Class Initialized
INFO - 2026-08-18 18:18:05 --> Email Class Initialized
INFO - 2026-08-18 18:18:05 --> Controller Class Initialized
DEBUG - 2026-08-18 18:18:05 --> Authenticate MX_Controller Initialized
INFO - 2026-08-18 18:18:05 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:18:05 --> Model "Adminauth_model" initialized
INFO - 2026-08-18 18:18:05 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-18 18:18:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-08-18 18:18:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-08-18 18:18:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-08-18 18:18:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-08-18 18:18:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-08-18 18:18:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-08-18 18:18:05 --> Final output sent to browser
DEBUG - 2026-08-18 18:18:05 --> Total execution time: 3.5418
INFO - 2026-08-18 18:18:06 --> Config Class Initialized
INFO - 2026-08-18 18:18:06 --> Hooks Class Initialized
DEBUG - 2026-08-18 18:18:06 --> UTF-8 Support Enabled
INFO - 2026-08-18 18:18:06 --> Utf8 Class Initialized
INFO - 2026-08-18 18:18:06 --> URI Class Initialized
INFO - 2026-08-18 18:18:06 --> Router Class Initialized
INFO - 2026-08-18 18:18:06 --> Output Class Initialized
INFO - 2026-08-18 18:18:06 --> Security Class Initialized
DEBUG - 2026-08-18 18:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-18 18:18:06 --> CSRF cookie sent
INFO - 2026-08-18 18:18:06 --> CSRF token verified
INFO - 2026-08-18 18:18:06 --> Input Class Initialized
INFO - 2026-08-18 18:18:06 --> Language Class Initialized
INFO - 2026-08-18 18:18:06 --> Language Class Initialized
INFO - 2026-08-18 18:18:06 --> Config Class Initialized
INFO - 2026-08-18 18:18:06 --> Loader Class Initialized
INFO - 2026-08-18 18:18:06 --> Helper loaded: url_helper
INFO - 2026-08-18 18:18:06 --> Helper loaded: form_helper
INFO - 2026-08-18 18:18:06 --> Helper loaded: html_helper
INFO - 2026-08-18 18:18:06 --> Helper loaded: file_helper
INFO - 2026-08-18 18:18:06 --> Helper loaded: email_helper
INFO - 2026-08-18 18:18:06 --> Helper loaded: whmaz_helper
INFO - 2026-08-18 18:18:06 --> Helper loaded: ssp_helper
INFO - 2026-08-18 18:18:06 --> Helper loaded: cpanel_helper
INFO - 2026-08-18 18:18:06 --> Helper loaded: plesk_helper
INFO - 2026-08-18 18:18:06 --> Helper loaded: directadmin_helper
INFO - 2026-08-18 18:18:06 --> Helper loaded: domain_helper
INFO - 2026-08-18 18:18:06 --> Helper loaded: entitlement_helper
INFO - 2026-08-18 18:18:06 --> Database Driver Class Initialized
INFO - 2026-08-18 18:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-18 18:18:08 --> Upload Class Initialized
DEBUG - 2026-08-18 18:18:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-18 18:18:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-18 18:18:08 --> Encryption Class Initialized
INFO - 2026-08-18 18:18:08 --> Form Validation Class Initialized
INFO - 2026-08-18 18:18:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-18 18:18:08 --> Pagination Class Initialized
INFO - 2026-08-18 18:18:08 --> Email Class Initialized
INFO - 2026-08-18 18:18:08 --> Controller Class Initialized
DEBUG - 2026-08-18 18:18:08 --> Authenticate MX_Controller Initialized
INFO - 2026-08-18 18:18:08 --> Model "Loginattempt_model" initialized
INFO - 2026-08-18 18:18:08 --> Model "Adminauth_model" initialized
INFO - 2026-08-18 18:18:08 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-18 18:18:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-08-18 18:18:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-08-18 18:18:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-08-18 18:18:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-08-18 18:18:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-08-18 18:18:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-08-18 18:18:10 --> Final output sent to browser
DEBUG - 2026-08-18 18:18:10 --> Total execution time: 3.8131

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-08-19 03:00:05 --> Config Class Initialized
INFO - 2026-08-19 03:00:05 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:00:05 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:00:05 --> Utf8 Class Initialized
INFO - 2026-08-19 03:00:05 --> URI Class Initialized
DEBUG - 2026-08-19 03:00:05 --> No URI present. Default controller set.
INFO - 2026-08-19 03:00:05 --> Router Class Initialized
INFO - 2026-08-19 03:00:05 --> Output Class Initialized
INFO - 2026-08-19 03:00:05 --> Security Class Initialized
DEBUG - 2026-08-19 03:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:00:05 --> CSRF cookie sent
INFO - 2026-08-19 03:00:05 --> Input Class Initialized
INFO - 2026-08-19 03:00:05 --> Language Class Initialized
INFO - 2026-08-19 03:00:05 --> Language Class Initialized
INFO - 2026-08-19 03:00:05 --> Config Class Initialized
INFO - 2026-08-19 03:00:05 --> Loader Class Initialized
INFO - 2026-08-19 03:00:05 --> Helper loaded: url_helper
INFO - 2026-08-19 03:00:05 --> Helper loaded: form_helper
INFO - 2026-08-19 03:00:05 --> Helper loaded: html_helper
INFO - 2026-08-19 03:00:05 --> Helper loaded: file_helper
INFO - 2026-08-19 03:00:05 --> Helper loaded: email_helper
INFO - 2026-08-19 03:00:05 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:00:05 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:00:05 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:00:05 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:00:05 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:00:05 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:00:05 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:00:05 --> Database Driver Class Initialized
INFO - 2026-08-19 03:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:00:07 --> Upload Class Initialized
DEBUG - 2026-08-19 03:00:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:00:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:00:07 --> Encryption Class Initialized
INFO - 2026-08-19 03:00:07 --> Form Validation Class Initialized
INFO - 2026-08-19 03:00:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:00:07 --> Pagination Class Initialized
INFO - 2026-08-19 03:00:07 --> Email Class Initialized
INFO - 2026-08-19 03:00:07 --> Controller Class Initialized
DEBUG - 2026-08-19 03:00:07 --> Home MX_Controller Initialized
INFO - 2026-08-19 03:00:07 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:00:07 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:00:07 --> Model "Cart_model" initialized
DEBUG - 2026-08-19 03:00:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:00:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:00:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:00:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/home/views/home_view.php
INFO - 2026-08-19 03:00:08 --> Final output sent to browser
DEBUG - 2026-08-19 03:00:08 --> Total execution time: 3.8682
INFO - 2026-08-19 03:00:09 --> Config Class Initialized
INFO - 2026-08-19 03:00:09 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:00:09 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:00:09 --> Utf8 Class Initialized
INFO - 2026-08-19 03:00:09 --> URI Class Initialized
INFO - 2026-08-19 03:00:09 --> Router Class Initialized
INFO - 2026-08-19 03:00:09 --> Output Class Initialized
INFO - 2026-08-19 03:00:09 --> Security Class Initialized
DEBUG - 2026-08-19 03:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:00:09 --> CSRF cookie sent
INFO - 2026-08-19 03:00:09 --> Input Class Initialized
INFO - 2026-08-19 03:00:09 --> Language Class Initialized
INFO - 2026-08-19 03:00:09 --> Language Class Initialized
INFO - 2026-08-19 03:00:09 --> Config Class Initialized
INFO - 2026-08-19 03:00:09 --> Loader Class Initialized
INFO - 2026-08-19 03:00:09 --> Helper loaded: url_helper
INFO - 2026-08-19 03:00:09 --> Helper loaded: form_helper
INFO - 2026-08-19 03:00:09 --> Helper loaded: html_helper
INFO - 2026-08-19 03:00:09 --> Helper loaded: file_helper
INFO - 2026-08-19 03:00:09 --> Helper loaded: email_helper
INFO - 2026-08-19 03:00:09 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:00:09 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:00:09 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:00:09 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:00:09 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:00:09 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:00:09 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:00:09 --> Database Driver Class Initialized
INFO - 2026-08-19 03:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:00:10 --> Upload Class Initialized
DEBUG - 2026-08-19 03:00:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:00:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:00:10 --> Encryption Class Initialized
INFO - 2026-08-19 03:00:10 --> Form Validation Class Initialized
INFO - 2026-08-19 03:00:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:00:10 --> Pagination Class Initialized
INFO - 2026-08-19 03:00:10 --> Email Class Initialized
INFO - 2026-08-19 03:00:10 --> Controller Class Initialized
DEBUG - 2026-08-19 03:00:10 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:00:10 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:00:10 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:00:10 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:00:10 --> Model "Common_model" initialized
INFO - 2026-08-19 03:00:10 --> Model "Order_model" initialized
INFO - 2026-08-19 03:00:10 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:00:10 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:00:10 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:00:10 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:00:10 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:00:10 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:00:11 --> Final output sent to browser
DEBUG - 2026-08-19 03:00:11 --> Total execution time: 2.0232
INFO - 2026-08-19 03:01:00 --> Config Class Initialized
INFO - 2026-08-19 03:01:00 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:01:00 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:01:00 --> Utf8 Class Initialized
INFO - 2026-08-19 03:01:00 --> URI Class Initialized
DEBUG - 2026-08-19 03:01:00 --> No URI present. Default controller set.
INFO - 2026-08-19 03:01:00 --> Router Class Initialized
INFO - 2026-08-19 03:01:00 --> Output Class Initialized
INFO - 2026-08-19 03:01:00 --> Security Class Initialized
DEBUG - 2026-08-19 03:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:01:00 --> CSRF cookie sent
INFO - 2026-08-19 03:01:00 --> Input Class Initialized
INFO - 2026-08-19 03:01:00 --> Language Class Initialized
INFO - 2026-08-19 03:01:00 --> Language Class Initialized
INFO - 2026-08-19 03:01:00 --> Config Class Initialized
INFO - 2026-08-19 03:01:00 --> Loader Class Initialized
INFO - 2026-08-19 03:01:00 --> Helper loaded: url_helper
INFO - 2026-08-19 03:01:00 --> Helper loaded: form_helper
INFO - 2026-08-19 03:01:00 --> Helper loaded: html_helper
INFO - 2026-08-19 03:01:00 --> Helper loaded: file_helper
INFO - 2026-08-19 03:01:00 --> Helper loaded: email_helper
INFO - 2026-08-19 03:01:00 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:01:00 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:01:00 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:01:00 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:01:00 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:01:00 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:01:00 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:01:00 --> Database Driver Class Initialized
INFO - 2026-08-19 03:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:01:02 --> Upload Class Initialized
DEBUG - 2026-08-19 03:01:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:01:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:01:02 --> Encryption Class Initialized
INFO - 2026-08-19 03:01:02 --> Form Validation Class Initialized
INFO - 2026-08-19 03:01:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:01:02 --> Pagination Class Initialized
INFO - 2026-08-19 03:01:02 --> Email Class Initialized
INFO - 2026-08-19 03:01:02 --> Controller Class Initialized
DEBUG - 2026-08-19 03:01:02 --> Home MX_Controller Initialized
INFO - 2026-08-19 03:01:02 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:01:02 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:01:02 --> Model "Cart_model" initialized
DEBUG - 2026-08-19 03:01:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:01:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:01:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:01:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/home/views/home_view.php
INFO - 2026-08-19 03:01:03 --> Final output sent to browser
DEBUG - 2026-08-19 03:01:03 --> Total execution time: 2.2767
INFO - 2026-08-19 03:01:03 --> Config Class Initialized
INFO - 2026-08-19 03:01:03 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:01:03 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:01:03 --> Utf8 Class Initialized
INFO - 2026-08-19 03:01:03 --> URI Class Initialized
INFO - 2026-08-19 03:01:03 --> Router Class Initialized
INFO - 2026-08-19 03:01:03 --> Output Class Initialized
INFO - 2026-08-19 03:01:03 --> Security Class Initialized
DEBUG - 2026-08-19 03:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:01:03 --> CSRF cookie sent
INFO - 2026-08-19 03:01:03 --> Input Class Initialized
INFO - 2026-08-19 03:01:03 --> Language Class Initialized
INFO - 2026-08-19 03:01:03 --> Language Class Initialized
INFO - 2026-08-19 03:01:03 --> Config Class Initialized
INFO - 2026-08-19 03:01:03 --> Loader Class Initialized
INFO - 2026-08-19 03:01:03 --> Helper loaded: url_helper
INFO - 2026-08-19 03:01:03 --> Helper loaded: form_helper
INFO - 2026-08-19 03:01:03 --> Helper loaded: html_helper
INFO - 2026-08-19 03:01:03 --> Helper loaded: file_helper
INFO - 2026-08-19 03:01:03 --> Helper loaded: email_helper
INFO - 2026-08-19 03:01:03 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:01:03 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:01:03 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:01:03 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:01:03 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:01:03 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:01:03 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:01:03 --> Database Driver Class Initialized
INFO - 2026-08-19 03:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:01:05 --> Upload Class Initialized
DEBUG - 2026-08-19 03:01:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:01:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:01:05 --> Encryption Class Initialized
INFO - 2026-08-19 03:01:05 --> Form Validation Class Initialized
INFO - 2026-08-19 03:01:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:01:05 --> Pagination Class Initialized
INFO - 2026-08-19 03:01:05 --> Email Class Initialized
INFO - 2026-08-19 03:01:05 --> Controller Class Initialized
DEBUG - 2026-08-19 03:01:05 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:01:05 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:01:05 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:01:05 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:01:05 --> Model "Common_model" initialized
INFO - 2026-08-19 03:01:05 --> Model "Order_model" initialized
INFO - 2026-08-19 03:01:05 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:01:05 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:01:05 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:01:05 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:01:05 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:01:05 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:01:05 --> Final output sent to browser
DEBUG - 2026-08-19 03:01:05 --> Total execution time: 2.0980
INFO - 2026-08-19 03:01:08 --> Config Class Initialized
INFO - 2026-08-19 03:01:08 --> Hooks Class Initialized
INFO - 2026-08-19 03:01:08 --> Config Class Initialized
INFO - 2026-08-19 03:01:08 --> Hooks Class Initialized
INFO - 2026-08-19 03:01:08 --> Config Class Initialized
INFO - 2026-08-19 03:01:08 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:01:08 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:01:08 --> Utf8 Class Initialized
DEBUG - 2026-08-19 03:01:08 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:01:08 --> Utf8 Class Initialized
INFO - 2026-08-19 03:01:08 --> URI Class Initialized
INFO - 2026-08-19 03:01:08 --> URI Class Initialized
DEBUG - 2026-08-19 03:01:08 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:01:08 --> Utf8 Class Initialized
INFO - 2026-08-19 03:01:08 --> Config Class Initialized
INFO - 2026-08-19 03:01:08 --> Hooks Class Initialized
INFO - 2026-08-19 03:01:08 --> URI Class Initialized
DEBUG - 2026-08-19 03:01:08 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:01:08 --> Utf8 Class Initialized
INFO - 2026-08-19 03:01:08 --> Router Class Initialized
INFO - 2026-08-19 03:01:08 --> Router Class Initialized
INFO - 2026-08-19 03:01:08 --> URI Class Initialized
INFO - 2026-08-19 03:01:08 --> Router Class Initialized
INFO - 2026-08-19 03:01:08 --> Output Class Initialized
INFO - 2026-08-19 03:01:08 --> Output Class Initialized
INFO - 2026-08-19 03:01:08 --> Output Class Initialized
INFO - 2026-08-19 03:01:08 --> Security Class Initialized
INFO - 2026-08-19 03:01:08 --> Security Class Initialized
INFO - 2026-08-19 03:01:08 --> Security Class Initialized
INFO - 2026-08-19 03:01:08 --> Router Class Initialized
DEBUG - 2026-08-19 03:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:01:08 --> CSRF cookie sent
INFO - 2026-08-19 03:01:08 --> Input Class Initialized
DEBUG - 2026-08-19 03:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:01:08 --> Language Class Initialized
INFO - 2026-08-19 03:01:08 --> CSRF cookie sent
INFO - 2026-08-19 03:01:08 --> Input Class Initialized
DEBUG - 2026-08-19 03:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:01:08 --> CSRF cookie sent
INFO - 2026-08-19 03:01:08 --> Input Class Initialized
INFO - 2026-08-19 03:01:08 --> Language Class Initialized
INFO - 2026-08-19 03:01:08 --> Language Class Initialized
INFO - 2026-08-19 03:01:08 --> Output Class Initialized
INFO - 2026-08-19 03:01:08 --> Language Class Initialized
INFO - 2026-08-19 03:01:08 --> Config Class Initialized
INFO - 2026-08-19 03:01:08 --> Language Class Initialized
INFO - 2026-08-19 03:01:08 --> Config Class Initialized
INFO - 2026-08-19 03:01:08 --> Language Class Initialized
INFO - 2026-08-19 03:01:08 --> Config Class Initialized
INFO - 2026-08-19 03:01:08 --> Security Class Initialized
DEBUG - 2026-08-19 03:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:01:08 --> CSRF cookie sent
INFO - 2026-08-19 03:01:08 --> Input Class Initialized
INFO - 2026-08-19 03:01:08 --> Language Class Initialized
INFO - 2026-08-19 03:01:08 --> Loader Class Initialized
INFO - 2026-08-19 03:01:08 --> Loader Class Initialized
INFO - 2026-08-19 03:01:08 --> Language Class Initialized
INFO - 2026-08-19 03:01:08 --> Config Class Initialized
INFO - 2026-08-19 03:01:08 --> Helper loaded: url_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: url_helper
INFO - 2026-08-19 03:01:08 --> Config Class Initialized
INFO - 2026-08-19 03:01:08 --> Helper loaded: form_helper
INFO - 2026-08-19 03:01:08 --> Hooks Class Initialized
INFO - 2026-08-19 03:01:08 --> Helper loaded: html_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: file_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: email_helper
INFO - 2026-08-19 03:01:08 --> Loader Class Initialized
INFO - 2026-08-19 03:01:08 --> Helper loaded: form_helper
INFO - 2026-08-19 03:01:08 --> Config Class Initialized
INFO - 2026-08-19 03:01:08 --> Hooks Class Initialized
INFO - 2026-08-19 03:01:08 --> Helper loaded: html_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: url_helper
DEBUG - 2026-08-19 03:01:08 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:01:08 --> Utf8 Class Initialized
INFO - 2026-08-19 03:01:08 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: file_helper
DEBUG - 2026-08-19 03:01:08 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:01:08 --> Utf8 Class Initialized
INFO - 2026-08-19 03:01:08 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: email_helper
INFO - 2026-08-19 03:01:08 --> URI Class Initialized
INFO - 2026-08-19 03:01:08 --> Helper loaded: form_helper
INFO - 2026-08-19 03:01:08 --> Loader Class Initialized
INFO - 2026-08-19 03:01:08 --> Helper loaded: html_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: file_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: url_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: email_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: form_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: html_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: file_helper
INFO - 2026-08-19 03:01:08 --> Router Class Initialized
INFO - 2026-08-19 03:01:08 --> Helper loaded: email_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:01:08 --> Output Class Initialized
INFO - 2026-08-19 03:01:08 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:01:08 --> Security Class Initialized
INFO - 2026-08-19 03:01:08 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: entitlement_helper
DEBUG - 2026-08-19 03:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:01:08 --> CSRF cookie sent
INFO - 2026-08-19 03:01:08 --> Input Class Initialized
INFO - 2026-08-19 03:01:08 --> URI Class Initialized
INFO - 2026-08-19 03:01:08 --> Language Class Initialized
INFO - 2026-08-19 03:01:08 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:01:08 --> Database Driver Class Initialized
INFO - 2026-08-19 03:01:08 --> Language Class Initialized
INFO - 2026-08-19 03:01:08 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:01:08 --> Router Class Initialized
INFO - 2026-08-19 03:01:08 --> Output Class Initialized
INFO - 2026-08-19 03:01:08 --> Config Class Initialized
INFO - 2026-08-19 03:01:08 --> Database Driver Class Initialized
INFO - 2026-08-19 03:01:08 --> Security Class Initialized
INFO - 2026-08-19 03:01:08 --> Database Driver Class Initialized
DEBUG - 2026-08-19 03:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:01:08 --> CSRF cookie sent
INFO - 2026-08-19 03:01:08 --> Input Class Initialized
INFO - 2026-08-19 03:01:08 --> Language Class Initialized
INFO - 2026-08-19 03:01:08 --> Database Driver Class Initialized
INFO - 2026-08-19 03:01:08 --> Loader Class Initialized
INFO - 2026-08-19 03:01:08 --> Language Class Initialized
INFO - 2026-08-19 03:01:08 --> Config Class Initialized
INFO - 2026-08-19 03:01:08 --> Helper loaded: url_helper
INFO - 2026-08-19 03:01:08 --> Loader Class Initialized
INFO - 2026-08-19 03:01:08 --> Helper loaded: form_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: url_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: html_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: form_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: file_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: email_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: html_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: file_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: email_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:01:08 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:01:08 --> Database Driver Class Initialized
INFO - 2026-08-19 03:01:08 --> Database Driver Class Initialized
INFO - 2026-08-19 03:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:01:10 --> Upload Class Initialized
DEBUG - 2026-08-19 03:01:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:01:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:01:10 --> Encryption Class Initialized
INFO - 2026-08-19 03:01:10 --> Form Validation Class Initialized
INFO - 2026-08-19 03:01:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:01:10 --> Pagination Class Initialized
INFO - 2026-08-19 03:01:10 --> Email Class Initialized
INFO - 2026-08-19 03:01:10 --> Controller Class Initialized
ERROR - 2026-08-19 03:01:10 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:01:10 --> Upload Class Initialized
DEBUG - 2026-08-19 03:01:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:01:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:01:10 --> Encryption Class Initialized
INFO - 2026-08-19 03:01:10 --> Form Validation Class Initialized
INFO - 2026-08-19 03:01:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:01:10 --> Pagination Class Initialized
INFO - 2026-08-19 03:01:10 --> Email Class Initialized
INFO - 2026-08-19 03:01:10 --> Controller Class Initialized
INFO - 2026-08-19 03:01:10 --> Config Class Initialized
ERROR - 2026-08-19 03:01:10 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:01:10 --> Hooks Class Initialized
INFO - 2026-08-19 03:01:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-08-19 03:01:10 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:01:10 --> Utf8 Class Initialized
INFO - 2026-08-19 03:01:10 --> Upload Class Initialized
INFO - 2026-08-19 03:01:10 --> URI Class Initialized
DEBUG - 2026-08-19 03:01:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:01:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:01:10 --> Encryption Class Initialized
INFO - 2026-08-19 03:01:10 --> Router Class Initialized
INFO - 2026-08-19 03:01:10 --> Form Validation Class Initialized
INFO - 2026-08-19 03:01:10 --> Output Class Initialized
INFO - 2026-08-19 03:01:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:01:10 --> Pagination Class Initialized
INFO - 2026-08-19 03:01:10 --> Security Class Initialized
DEBUG - 2026-08-19 03:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:01:10 --> CSRF cookie sent
INFO - 2026-08-19 03:01:10 --> Input Class Initialized
INFO - 2026-08-19 03:01:10 --> Language Class Initialized
INFO - 2026-08-19 03:01:10 --> Language Class Initialized
INFO - 2026-08-19 03:01:10 --> Config Class Initialized
INFO - 2026-08-19 03:01:10 --> Email Class Initialized
INFO - 2026-08-19 03:01:10 --> Controller Class Initialized
ERROR - 2026-08-19 03:01:10 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:01:10 --> Loader Class Initialized
INFO - 2026-08-19 03:01:10 --> Upload Class Initialized
INFO - 2026-08-19 03:01:10 --> Helper loaded: url_helper
INFO - 2026-08-19 03:01:10 --> Helper loaded: form_helper
DEBUG - 2026-08-19 03:01:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:01:10 --> Helper loaded: html_helper
INFO - 2026-08-19 03:01:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:01:10 --> Encryption Class Initialized
INFO - 2026-08-19 03:01:10 --> Helper loaded: file_helper
INFO - 2026-08-19 03:01:10 --> Helper loaded: email_helper
INFO - 2026-08-19 03:01:10 --> Form Validation Class Initialized
INFO - 2026-08-19 03:01:10 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:01:10 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:01:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:01:10 --> Pagination Class Initialized
INFO - 2026-08-19 03:01:10 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:01:10 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:01:10 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:01:10 --> Email Class Initialized
INFO - 2026-08-19 03:01:10 --> Controller Class Initialized
ERROR - 2026-08-19 03:01:10 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:01:10 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:01:10 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:01:10 --> Database Driver Class Initialized
INFO - 2026-08-19 03:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:01:10 --> Upload Class Initialized
DEBUG - 2026-08-19 03:01:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:01:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:01:10 --> Encryption Class Initialized
INFO - 2026-08-19 03:01:10 --> Form Validation Class Initialized
INFO - 2026-08-19 03:01:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:01:10 --> Pagination Class Initialized
INFO - 2026-08-19 03:01:10 --> Email Class Initialized
INFO - 2026-08-19 03:01:10 --> Controller Class Initialized
ERROR - 2026-08-19 03:01:10 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:01:10 --> Upload Class Initialized
DEBUG - 2026-08-19 03:01:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:01:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:01:10 --> Encryption Class Initialized
INFO - 2026-08-19 03:01:10 --> Form Validation Class Initialized
INFO - 2026-08-19 03:01:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:01:10 --> Pagination Class Initialized
INFO - 2026-08-19 03:01:10 --> Email Class Initialized
INFO - 2026-08-19 03:01:10 --> Controller Class Initialized
ERROR - 2026-08-19 03:01:10 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:01:11 --> Upload Class Initialized
DEBUG - 2026-08-19 03:01:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:01:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:01:11 --> Encryption Class Initialized
INFO - 2026-08-19 03:01:11 --> Form Validation Class Initialized
INFO - 2026-08-19 03:01:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:01:11 --> Pagination Class Initialized
INFO - 2026-08-19 03:01:11 --> Email Class Initialized
INFO - 2026-08-19 03:01:11 --> Controller Class Initialized
ERROR - 2026-08-19 03:01:11 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:02:38 --> Config Class Initialized
INFO - 2026-08-19 03:02:38 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:02:38 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:02:38 --> Utf8 Class Initialized
INFO - 2026-08-19 03:02:38 --> URI Class Initialized
DEBUG - 2026-08-19 03:02:38 --> No URI present. Default controller set.
INFO - 2026-08-19 03:02:38 --> Router Class Initialized
INFO - 2026-08-19 03:02:38 --> Output Class Initialized
INFO - 2026-08-19 03:02:38 --> Security Class Initialized
DEBUG - 2026-08-19 03:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:02:38 --> CSRF cookie sent
INFO - 2026-08-19 03:02:38 --> Input Class Initialized
INFO - 2026-08-19 03:02:38 --> Language Class Initialized
INFO - 2026-08-19 03:02:38 --> Language Class Initialized
INFO - 2026-08-19 03:02:38 --> Config Class Initialized
INFO - 2026-08-19 03:02:38 --> Loader Class Initialized
INFO - 2026-08-19 03:02:38 --> Helper loaded: url_helper
INFO - 2026-08-19 03:02:38 --> Helper loaded: form_helper
INFO - 2026-08-19 03:02:38 --> Helper loaded: html_helper
INFO - 2026-08-19 03:02:38 --> Helper loaded: file_helper
INFO - 2026-08-19 03:02:38 --> Helper loaded: email_helper
INFO - 2026-08-19 03:02:38 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:02:38 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:02:38 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:02:38 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:02:38 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:02:38 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:02:38 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:02:38 --> Database Driver Class Initialized
INFO - 2026-08-19 03:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:02:40 --> Upload Class Initialized
DEBUG - 2026-08-19 03:02:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:02:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:02:40 --> Encryption Class Initialized
INFO - 2026-08-19 03:02:40 --> Form Validation Class Initialized
INFO - 2026-08-19 03:02:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:02:40 --> Pagination Class Initialized
INFO - 2026-08-19 03:02:40 --> Email Class Initialized
INFO - 2026-08-19 03:02:40 --> Controller Class Initialized
DEBUG - 2026-08-19 03:02:40 --> Home MX_Controller Initialized
INFO - 2026-08-19 03:02:40 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:02:40 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:02:40 --> Model "Cart_model" initialized
DEBUG - 2026-08-19 03:02:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:02:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:02:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:02:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/home/views/home_view.php
INFO - 2026-08-19 03:02:41 --> Final output sent to browser
DEBUG - 2026-08-19 03:02:41 --> Total execution time: 2.3036
INFO - 2026-08-19 03:02:41 --> Config Class Initialized
INFO - 2026-08-19 03:02:41 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:02:41 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:02:41 --> Utf8 Class Initialized
INFO - 2026-08-19 03:02:41 --> URI Class Initialized
INFO - 2026-08-19 03:02:41 --> Router Class Initialized
INFO - 2026-08-19 03:02:41 --> Output Class Initialized
INFO - 2026-08-19 03:02:41 --> Security Class Initialized
DEBUG - 2026-08-19 03:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:02:41 --> CSRF cookie sent
INFO - 2026-08-19 03:02:41 --> Input Class Initialized
INFO - 2026-08-19 03:02:41 --> Language Class Initialized
INFO - 2026-08-19 03:02:41 --> Language Class Initialized
INFO - 2026-08-19 03:02:41 --> Config Class Initialized
INFO - 2026-08-19 03:02:41 --> Loader Class Initialized
INFO - 2026-08-19 03:02:41 --> Helper loaded: url_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: form_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: html_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: file_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: email_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:02:41 --> Database Driver Class Initialized
INFO - 2026-08-19 03:02:41 --> Config Class Initialized
INFO - 2026-08-19 03:02:41 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:02:41 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:02:41 --> Utf8 Class Initialized
INFO - 2026-08-19 03:02:41 --> Config Class Initialized
INFO - 2026-08-19 03:02:41 --> Hooks Class Initialized
INFO - 2026-08-19 03:02:41 --> URI Class Initialized
DEBUG - 2026-08-19 03:02:41 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:02:41 --> Utf8 Class Initialized
INFO - 2026-08-19 03:02:41 --> URI Class Initialized
INFO - 2026-08-19 03:02:41 --> Router Class Initialized
INFO - 2026-08-19 03:02:41 --> Output Class Initialized
INFO - 2026-08-19 03:02:41 --> Router Class Initialized
INFO - 2026-08-19 03:02:41 --> Security Class Initialized
DEBUG - 2026-08-19 03:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:02:41 --> CSRF cookie sent
INFO - 2026-08-19 03:02:41 --> Input Class Initialized
INFO - 2026-08-19 03:02:41 --> Language Class Initialized
INFO - 2026-08-19 03:02:41 --> Output Class Initialized
INFO - 2026-08-19 03:02:41 --> Language Class Initialized
INFO - 2026-08-19 03:02:41 --> Config Class Initialized
INFO - 2026-08-19 03:02:41 --> Security Class Initialized
DEBUG - 2026-08-19 03:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:02:41 --> CSRF cookie sent
INFO - 2026-08-19 03:02:41 --> Input Class Initialized
INFO - 2026-08-19 03:02:41 --> Loader Class Initialized
INFO - 2026-08-19 03:02:41 --> Language Class Initialized
INFO - 2026-08-19 03:02:41 --> Helper loaded: url_helper
INFO - 2026-08-19 03:02:41 --> Language Class Initialized
INFO - 2026-08-19 03:02:41 --> Config Class Initialized
INFO - 2026-08-19 03:02:41 --> Helper loaded: form_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: html_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: file_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: email_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:02:41 --> Loader Class Initialized
INFO - 2026-08-19 03:02:41 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: url_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: form_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: html_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: file_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: email_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:02:41 --> Database Driver Class Initialized
INFO - 2026-08-19 03:02:41 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:02:41 --> Config Class Initialized
INFO - 2026-08-19 03:02:41 --> Hooks Class Initialized
INFO - 2026-08-19 03:02:41 --> Helper loaded: entitlement_helper
DEBUG - 2026-08-19 03:02:41 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:02:41 --> Utf8 Class Initialized
INFO - 2026-08-19 03:02:41 --> URI Class Initialized
INFO - 2026-08-19 03:02:41 --> Router Class Initialized
INFO - 2026-08-19 03:02:41 --> Output Class Initialized
INFO - 2026-08-19 03:02:41 --> Security Class Initialized
DEBUG - 2026-08-19 03:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:02:41 --> CSRF cookie sent
INFO - 2026-08-19 03:02:41 --> Input Class Initialized
INFO - 2026-08-19 03:02:41 --> Language Class Initialized
INFO - 2026-08-19 03:02:41 --> Language Class Initialized
INFO - 2026-08-19 03:02:41 --> Config Class Initialized
INFO - 2026-08-19 03:02:41 --> Database Driver Class Initialized
INFO - 2026-08-19 03:02:41 --> Loader Class Initialized
INFO - 2026-08-19 03:02:41 --> Helper loaded: url_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: form_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: html_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: file_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: email_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:02:41 --> Database Driver Class Initialized
INFO - 2026-08-19 03:02:41 --> Config Class Initialized
INFO - 2026-08-19 03:02:41 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:02:41 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:02:41 --> Utf8 Class Initialized
INFO - 2026-08-19 03:02:41 --> URI Class Initialized
INFO - 2026-08-19 03:02:41 --> Router Class Initialized
INFO - 2026-08-19 03:02:41 --> Output Class Initialized
INFO - 2026-08-19 03:02:41 --> Security Class Initialized
DEBUG - 2026-08-19 03:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:02:41 --> CSRF cookie sent
INFO - 2026-08-19 03:02:41 --> Input Class Initialized
INFO - 2026-08-19 03:02:41 --> Language Class Initialized
INFO - 2026-08-19 03:02:41 --> Config Class Initialized
INFO - 2026-08-19 03:02:41 --> Hooks Class Initialized
INFO - 2026-08-19 03:02:41 --> Language Class Initialized
INFO - 2026-08-19 03:02:41 --> Config Class Initialized
DEBUG - 2026-08-19 03:02:41 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:02:41 --> Utf8 Class Initialized
INFO - 2026-08-19 03:02:41 --> URI Class Initialized
INFO - 2026-08-19 03:02:41 --> Loader Class Initialized
INFO - 2026-08-19 03:02:41 --> Helper loaded: url_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: form_helper
INFO - 2026-08-19 03:02:41 --> Router Class Initialized
INFO - 2026-08-19 03:02:41 --> Helper loaded: html_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: file_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: email_helper
INFO - 2026-08-19 03:02:41 --> Output Class Initialized
INFO - 2026-08-19 03:02:41 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:02:41 --> Security Class Initialized
INFO - 2026-08-19 03:02:41 --> Helper loaded: ssp_helper
DEBUG - 2026-08-19 03:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:02:41 --> CSRF cookie sent
INFO - 2026-08-19 03:02:41 --> Input Class Initialized
INFO - 2026-08-19 03:02:41 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:02:41 --> Language Class Initialized
INFO - 2026-08-19 03:02:41 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:02:41 --> Language Class Initialized
INFO - 2026-08-19 03:02:41 --> Config Class Initialized
INFO - 2026-08-19 03:02:41 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:02:41 --> Loader Class Initialized
INFO - 2026-08-19 03:02:41 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: url_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: form_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: html_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: file_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: email_helper
INFO - 2026-08-19 03:02:41 --> Database Driver Class Initialized
INFO - 2026-08-19 03:02:41 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:02:41 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:02:41 --> Database Driver Class Initialized
INFO - 2026-08-19 03:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:02:43 --> Upload Class Initialized
DEBUG - 2026-08-19 03:02:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:02:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:02:43 --> Encryption Class Initialized
INFO - 2026-08-19 03:02:43 --> Form Validation Class Initialized
INFO - 2026-08-19 03:02:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:02:43 --> Pagination Class Initialized
INFO - 2026-08-19 03:02:43 --> Email Class Initialized
INFO - 2026-08-19 03:02:43 --> Controller Class Initialized
DEBUG - 2026-08-19 03:02:43 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:02:43 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:02:43 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:02:43 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:02:43 --> Model "Common_model" initialized
INFO - 2026-08-19 03:02:43 --> Model "Order_model" initialized
INFO - 2026-08-19 03:02:43 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:02:43 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:02:43 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:02:43 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:02:43 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:02:43 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:02:43 --> Final output sent to browser
DEBUG - 2026-08-19 03:02:43 --> Total execution time: 1.9552
INFO - 2026-08-19 03:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:02:43 --> Upload Class Initialized
DEBUG - 2026-08-19 03:02:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:02:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:02:43 --> Encryption Class Initialized
INFO - 2026-08-19 03:02:43 --> Form Validation Class Initialized
INFO - 2026-08-19 03:02:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:02:43 --> Pagination Class Initialized
INFO - 2026-08-19 03:02:43 --> Config Class Initialized
INFO - 2026-08-19 03:02:43 --> Hooks Class Initialized
INFO - 2026-08-19 03:02:43 --> Email Class Initialized
INFO - 2026-08-19 03:02:43 --> Controller Class Initialized
ERROR - 2026-08-19 03:02:43 --> 404 Page Not Found: /index
DEBUG - 2026-08-19 03:02:43 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:02:43 --> Utf8 Class Initialized
INFO - 2026-08-19 03:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:02:43 --> URI Class Initialized
INFO - 2026-08-19 03:02:43 --> Upload Class Initialized
INFO - 2026-08-19 03:02:43 --> Router Class Initialized
DEBUG - 2026-08-19 03:02:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:02:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:02:43 --> Encryption Class Initialized
INFO - 2026-08-19 03:02:43 --> Output Class Initialized
INFO - 2026-08-19 03:02:43 --> Security Class Initialized
DEBUG - 2026-08-19 03:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:02:43 --> CSRF cookie sent
INFO - 2026-08-19 03:02:43 --> Input Class Initialized
INFO - 2026-08-19 03:02:43 --> Form Validation Class Initialized
INFO - 2026-08-19 03:02:43 --> Language Class Initialized
INFO - 2026-08-19 03:02:43 --> Language Class Initialized
INFO - 2026-08-19 03:02:43 --> Config Class Initialized
INFO - 2026-08-19 03:02:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:02:43 --> Pagination Class Initialized
INFO - 2026-08-19 03:02:43 --> Config Class Initialized
INFO - 2026-08-19 03:02:43 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:02:43 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:02:43 --> Loader Class Initialized
INFO - 2026-08-19 03:02:43 --> Utf8 Class Initialized
INFO - 2026-08-19 03:02:43 --> Helper loaded: url_helper
INFO - 2026-08-19 03:02:43 --> URI Class Initialized
INFO - 2026-08-19 03:02:43 --> Helper loaded: form_helper
INFO - 2026-08-19 03:02:43 --> Helper loaded: html_helper
INFO - 2026-08-19 03:02:43 --> Email Class Initialized
INFO - 2026-08-19 03:02:43 --> Router Class Initialized
INFO - 2026-08-19 03:02:43 --> Controller Class Initialized
INFO - 2026-08-19 03:02:43 --> Helper loaded: file_helper
INFO - 2026-08-19 03:02:43 --> Helper loaded: email_helper
ERROR - 2026-08-19 03:02:43 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:02:43 --> Output Class Initialized
INFO - 2026-08-19 03:02:43 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:02:43 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:02:43 --> Security Class Initialized
INFO - 2026-08-19 03:02:43 --> Upload Class Initialized
INFO - 2026-08-19 03:02:43 --> Helper loaded: cpanel_helper
DEBUG - 2026-08-19 03:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:02:43 --> CSRF cookie sent
INFO - 2026-08-19 03:02:43 --> Input Class Initialized
INFO - 2026-08-19 03:02:43 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:02:43 --> Language Class Initialized
DEBUG - 2026-08-19 03:02:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:02:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:02:43 --> Encryption Class Initialized
INFO - 2026-08-19 03:02:43 --> Language Class Initialized
INFO - 2026-08-19 03:02:43 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:02:43 --> Config Class Initialized
INFO - 2026-08-19 03:02:43 --> Form Validation Class Initialized
INFO - 2026-08-19 03:02:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:02:43 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:02:43 --> Pagination Class Initialized
INFO - 2026-08-19 03:02:43 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:02:43 --> Loader Class Initialized
INFO - 2026-08-19 03:02:43 --> Helper loaded: url_helper
INFO - 2026-08-19 03:02:43 --> Helper loaded: form_helper
INFO - 2026-08-19 03:02:43 --> Email Class Initialized
INFO - 2026-08-19 03:02:43 --> Controller Class Initialized
INFO - 2026-08-19 03:02:43 --> Helper loaded: html_helper
ERROR - 2026-08-19 03:02:43 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:02:43 --> Helper loaded: file_helper
INFO - 2026-08-19 03:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:02:43 --> Database Driver Class Initialized
INFO - 2026-08-19 03:02:43 --> Helper loaded: email_helper
INFO - 2026-08-19 03:02:43 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:02:43 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:02:43 --> Upload Class Initialized
INFO - 2026-08-19 03:02:43 --> Helper loaded: cpanel_helper
DEBUG - 2026-08-19 03:02:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:02:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:02:43 --> Encryption Class Initialized
INFO - 2026-08-19 03:02:43 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:02:43 --> Form Validation Class Initialized
INFO - 2026-08-19 03:02:43 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:02:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:02:43 --> Pagination Class Initialized
INFO - 2026-08-19 03:02:43 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:02:43 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:02:43 --> Email Class Initialized
INFO - 2026-08-19 03:02:43 --> Controller Class Initialized
ERROR - 2026-08-19 03:02:43 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:02:43 --> Database Driver Class Initialized
INFO - 2026-08-19 03:02:43 --> Upload Class Initialized
DEBUG - 2026-08-19 03:02:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:02:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:02:43 --> Encryption Class Initialized
INFO - 2026-08-19 03:02:43 --> Form Validation Class Initialized
INFO - 2026-08-19 03:02:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:02:43 --> Pagination Class Initialized
INFO - 2026-08-19 03:02:43 --> Email Class Initialized
INFO - 2026-08-19 03:02:43 --> Controller Class Initialized
ERROR - 2026-08-19 03:02:43 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:02:45 --> Upload Class Initialized
DEBUG - 2026-08-19 03:02:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:02:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:02:45 --> Encryption Class Initialized
INFO - 2026-08-19 03:02:45 --> Form Validation Class Initialized
INFO - 2026-08-19 03:02:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:02:45 --> Pagination Class Initialized
INFO - 2026-08-19 03:02:45 --> Email Class Initialized
INFO - 2026-08-19 03:02:45 --> Controller Class Initialized
ERROR - 2026-08-19 03:02:45 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:02:45 --> Upload Class Initialized
DEBUG - 2026-08-19 03:02:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:02:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:02:45 --> Encryption Class Initialized
INFO - 2026-08-19 03:02:45 --> Form Validation Class Initialized
INFO - 2026-08-19 03:02:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:02:45 --> Pagination Class Initialized
INFO - 2026-08-19 03:02:45 --> Email Class Initialized
INFO - 2026-08-19 03:02:45 --> Controller Class Initialized
ERROR - 2026-08-19 03:02:45 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:11:30 --> Config Class Initialized
INFO - 2026-08-19 03:11:30 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:11:30 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:30 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:30 --> URI Class Initialized
DEBUG - 2026-08-19 03:11:30 --> No URI present. Default controller set.
INFO - 2026-08-19 03:11:30 --> Router Class Initialized
INFO - 2026-08-19 03:11:30 --> Output Class Initialized
INFO - 2026-08-19 03:11:30 --> Security Class Initialized
DEBUG - 2026-08-19 03:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:30 --> CSRF cookie sent
INFO - 2026-08-19 03:11:30 --> Input Class Initialized
INFO - 2026-08-19 03:11:30 --> Language Class Initialized
INFO - 2026-08-19 03:11:30 --> Language Class Initialized
INFO - 2026-08-19 03:11:30 --> Config Class Initialized
INFO - 2026-08-19 03:11:30 --> Loader Class Initialized
INFO - 2026-08-19 03:11:30 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:30 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:30 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:30 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:30 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:30 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:30 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:30 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:30 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:30 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:30 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:30 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:30 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:11:32 --> Upload Class Initialized
DEBUG - 2026-08-19 03:11:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:11:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:11:32 --> Encryption Class Initialized
INFO - 2026-08-19 03:11:32 --> Form Validation Class Initialized
INFO - 2026-08-19 03:11:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:11:32 --> Pagination Class Initialized
INFO - 2026-08-19 03:11:32 --> Email Class Initialized
INFO - 2026-08-19 03:11:32 --> Controller Class Initialized
DEBUG - 2026-08-19 03:11:32 --> Home MX_Controller Initialized
INFO - 2026-08-19 03:11:32 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:11:32 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:11:32 --> Model "Cart_model" initialized
DEBUG - 2026-08-19 03:11:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:11:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:11:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:11:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/home/views/home_view.php
INFO - 2026-08-19 03:11:33 --> Final output sent to browser
DEBUG - 2026-08-19 03:11:33 --> Total execution time: 2.4973
INFO - 2026-08-19 03:11:33 --> Config Class Initialized
INFO - 2026-08-19 03:11:33 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:11:33 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:33 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:33 --> URI Class Initialized
INFO - 2026-08-19 03:11:33 --> Router Class Initialized
INFO - 2026-08-19 03:11:33 --> Output Class Initialized
INFO - 2026-08-19 03:11:33 --> Security Class Initialized
DEBUG - 2026-08-19 03:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:33 --> CSRF cookie sent
INFO - 2026-08-19 03:11:33 --> Input Class Initialized
INFO - 2026-08-19 03:11:33 --> Language Class Initialized
INFO - 2026-08-19 03:11:33 --> Language Class Initialized
INFO - 2026-08-19 03:11:33 --> Config Class Initialized
INFO - 2026-08-19 03:11:33 --> Loader Class Initialized
INFO - 2026-08-19 03:11:33 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:33 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:33 --> Config Class Initialized
INFO - 2026-08-19 03:11:33 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:11:33 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:33 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:33 --> URI Class Initialized
INFO - 2026-08-19 03:11:33 --> Router Class Initialized
INFO - 2026-08-19 03:11:33 --> Output Class Initialized
INFO - 2026-08-19 03:11:33 --> Security Class Initialized
DEBUG - 2026-08-19 03:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:33 --> CSRF cookie sent
INFO - 2026-08-19 03:11:33 --> Input Class Initialized
INFO - 2026-08-19 03:11:33 --> Language Class Initialized
INFO - 2026-08-19 03:11:33 --> Language Class Initialized
INFO - 2026-08-19 03:11:33 --> Config Class Initialized
INFO - 2026-08-19 03:11:33 --> Loader Class Initialized
INFO - 2026-08-19 03:11:33 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:33 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:33 --> Config Class Initialized
INFO - 2026-08-19 03:11:33 --> Hooks Class Initialized
INFO - 2026-08-19 03:11:33 --> Config Class Initialized
INFO - 2026-08-19 03:11:33 --> Hooks Class Initialized
INFO - 2026-08-19 03:11:33 --> Config Class Initialized
INFO - 2026-08-19 03:11:33 --> Hooks Class Initialized
INFO - 2026-08-19 03:11:33 --> Config Class Initialized
INFO - 2026-08-19 03:11:33 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:11:33 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:33 --> Utf8 Class Initialized
DEBUG - 2026-08-19 03:11:33 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:33 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:33 --> URI Class Initialized
INFO - 2026-08-19 03:11:33 --> URI Class Initialized
DEBUG - 2026-08-19 03:11:33 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:33 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:33 --> Router Class Initialized
INFO - 2026-08-19 03:11:33 --> URI Class Initialized
INFO - 2026-08-19 03:11:33 --> Router Class Initialized
INFO - 2026-08-19 03:11:33 --> Output Class Initialized
DEBUG - 2026-08-19 03:11:33 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:33 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:33 --> Security Class Initialized
INFO - 2026-08-19 03:11:33 --> Output Class Initialized
INFO - 2026-08-19 03:11:33 --> URI Class Initialized
DEBUG - 2026-08-19 03:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:33 --> CSRF cookie sent
INFO - 2026-08-19 03:11:33 --> Input Class Initialized
INFO - 2026-08-19 03:11:33 --> Router Class Initialized
INFO - 2026-08-19 03:11:33 --> Language Class Initialized
INFO - 2026-08-19 03:11:33 --> Security Class Initialized
INFO - 2026-08-19 03:11:33 --> Language Class Initialized
INFO - 2026-08-19 03:11:33 --> Config Class Initialized
INFO - 2026-08-19 03:11:33 --> Output Class Initialized
INFO - 2026-08-19 03:11:33 --> Router Class Initialized
INFO - 2026-08-19 03:11:33 --> Security Class Initialized
INFO - 2026-08-19 03:11:33 --> Loader Class Initialized
DEBUG - 2026-08-19 03:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:33 --> CSRF cookie sent
INFO - 2026-08-19 03:11:33 --> Input Class Initialized
INFO - 2026-08-19 03:11:33 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:33 --> Output Class Initialized
INFO - 2026-08-19 03:11:33 --> Language Class Initialized
INFO - 2026-08-19 03:11:33 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:33 --> Language Class Initialized
INFO - 2026-08-19 03:11:33 --> Security Class Initialized
INFO - 2026-08-19 03:11:33 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:33 --> Config Class Initialized
INFO - 2026-08-19 03:11:33 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: email_helper
DEBUG - 2026-08-19 03:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:33 --> CSRF cookie sent
INFO - 2026-08-19 03:11:33 --> Input Class Initialized
INFO - 2026-08-19 03:11:33 --> Language Class Initialized
INFO - 2026-08-19 03:11:33 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:33 --> Loader Class Initialized
INFO - 2026-08-19 03:11:33 --> Language Class Initialized
INFO - 2026-08-19 03:11:33 --> Config Class Initialized
INFO - 2026-08-19 03:11:33 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: url_helper
DEBUG - 2026-08-19 03:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:33 --> CSRF cookie sent
INFO - 2026-08-19 03:11:33 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:33 --> Input Class Initialized
INFO - 2026-08-19 03:11:33 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:33 --> Language Class Initialized
INFO - 2026-08-19 03:11:33 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:33 --> Loader Class Initialized
INFO - 2026-08-19 03:11:33 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:33 --> Language Class Initialized
INFO - 2026-08-19 03:11:33 --> Config Class Initialized
INFO - 2026-08-19 03:11:33 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:33 --> Loader Class Initialized
INFO - 2026-08-19 03:11:33 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:33 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:33 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:33 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:33 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:33 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:33 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:11:34 --> Upload Class Initialized
DEBUG - 2026-08-19 03:11:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:11:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:11:34 --> Encryption Class Initialized
INFO - 2026-08-19 03:11:34 --> Form Validation Class Initialized
INFO - 2026-08-19 03:11:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:11:34 --> Pagination Class Initialized
INFO - 2026-08-19 03:11:34 --> Email Class Initialized
INFO - 2026-08-19 03:11:34 --> Controller Class Initialized
ERROR - 2026-08-19 03:11:34 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:11:34 --> Upload Class Initialized
DEBUG - 2026-08-19 03:11:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:11:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:11:34 --> Encryption Class Initialized
INFO - 2026-08-19 03:11:34 --> Form Validation Class Initialized
INFO - 2026-08-19 03:11:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:11:34 --> Pagination Class Initialized
INFO - 2026-08-19 03:11:34 --> Config Class Initialized
INFO - 2026-08-19 03:11:34 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:11:34 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:34 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:34 --> URI Class Initialized
INFO - 2026-08-19 03:11:34 --> Router Class Initialized
INFO - 2026-08-19 03:11:34 --> Email Class Initialized
INFO - 2026-08-19 03:11:34 --> Controller Class Initialized
INFO - 2026-08-19 03:11:34 --> Output Class Initialized
INFO - 2026-08-19 03:11:34 --> Security Class Initialized
DEBUG - 2026-08-19 03:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:34 --> CSRF cookie sent
INFO - 2026-08-19 03:11:34 --> Input Class Initialized
INFO - 2026-08-19 03:11:34 --> Language Class Initialized
DEBUG - 2026-08-19 03:11:34 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:11:34 --> Language Class Initialized
INFO - 2026-08-19 03:11:34 --> Config Class Initialized
INFO - 2026-08-19 03:11:34 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:11:34 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:11:34 --> Loader Class Initialized
INFO - 2026-08-19 03:11:34 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:11:34 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:34 --> Model "Common_model" initialized
INFO - 2026-08-19 03:11:34 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:34 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:34 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:34 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:34 --> Model "Order_model" initialized
INFO - 2026-08-19 03:11:34 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:11:34 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:34 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:11:34 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:34 --> Model "Promocode_model" initialized
INFO - 2026-08-19 03:11:34 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:34 --> Helper loaded: plesk_helper
DEBUG - 2026-08-19 03:11:34 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:11:34 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:11:34 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:11:34 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:34 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:34 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:34 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:35 --> Final output sent to browser
DEBUG - 2026-08-19 03:11:35 --> Total execution time: 1.8153
INFO - 2026-08-19 03:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:11:35 --> Upload Class Initialized
DEBUG - 2026-08-19 03:11:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:11:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:11:35 --> Encryption Class Initialized
INFO - 2026-08-19 03:11:35 --> Form Validation Class Initialized
INFO - 2026-08-19 03:11:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:11:35 --> Pagination Class Initialized
INFO - 2026-08-19 03:11:35 --> Email Class Initialized
INFO - 2026-08-19 03:11:35 --> Controller Class Initialized
ERROR - 2026-08-19 03:11:35 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:11:35 --> Config Class Initialized
INFO - 2026-08-19 03:11:35 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:11:35 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:35 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:35 --> Upload Class Initialized
INFO - 2026-08-19 03:11:35 --> URI Class Initialized
DEBUG - 2026-08-19 03:11:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:11:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:11:35 --> Encryption Class Initialized
INFO - 2026-08-19 03:11:35 --> Router Class Initialized
INFO - 2026-08-19 03:11:35 --> Form Validation Class Initialized
INFO - 2026-08-19 03:11:35 --> Output Class Initialized
INFO - 2026-08-19 03:11:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:11:35 --> Pagination Class Initialized
INFO - 2026-08-19 03:11:35 --> Security Class Initialized
DEBUG - 2026-08-19 03:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:35 --> CSRF cookie sent
INFO - 2026-08-19 03:11:35 --> Input Class Initialized
INFO - 2026-08-19 03:11:35 --> Language Class Initialized
INFO - 2026-08-19 03:11:35 --> Email Class Initialized
INFO - 2026-08-19 03:11:35 --> Controller Class Initialized
ERROR - 2026-08-19 03:11:35 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:11:35 --> Language Class Initialized
INFO - 2026-08-19 03:11:35 --> Config Class Initialized
INFO - 2026-08-19 03:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:11:35 --> Upload Class Initialized
INFO - 2026-08-19 03:11:35 --> Loader Class Initialized
DEBUG - 2026-08-19 03:11:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:11:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:11:35 --> Encryption Class Initialized
INFO - 2026-08-19 03:11:35 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:35 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:35 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:35 --> Form Validation Class Initialized
INFO - 2026-08-19 03:11:35 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:35 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:11:35 --> Pagination Class Initialized
INFO - 2026-08-19 03:11:35 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:35 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:35 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:35 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:35 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:35 --> Email Class Initialized
INFO - 2026-08-19 03:11:35 --> Controller Class Initialized
ERROR - 2026-08-19 03:11:35 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:11:35 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:35 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:35 --> Upload Class Initialized
DEBUG - 2026-08-19 03:11:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:11:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:11:35 --> Encryption Class Initialized
INFO - 2026-08-19 03:11:35 --> Form Validation Class Initialized
INFO - 2026-08-19 03:11:35 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:11:35 --> Pagination Class Initialized
INFO - 2026-08-19 03:11:35 --> Email Class Initialized
INFO - 2026-08-19 03:11:35 --> Controller Class Initialized
ERROR - 2026-08-19 03:11:35 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:11:36 --> Upload Class Initialized
DEBUG - 2026-08-19 03:11:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:11:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:11:36 --> Encryption Class Initialized
INFO - 2026-08-19 03:11:36 --> Form Validation Class Initialized
INFO - 2026-08-19 03:11:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:11:36 --> Pagination Class Initialized
INFO - 2026-08-19 03:11:36 --> Email Class Initialized
INFO - 2026-08-19 03:11:36 --> Controller Class Initialized
ERROR - 2026-08-19 03:11:36 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:11:36 --> Upload Class Initialized
DEBUG - 2026-08-19 03:11:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:11:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:11:36 --> Encryption Class Initialized
INFO - 2026-08-19 03:11:36 --> Form Validation Class Initialized
INFO - 2026-08-19 03:11:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:11:36 --> Pagination Class Initialized
INFO - 2026-08-19 03:11:36 --> Email Class Initialized
INFO - 2026-08-19 03:11:36 --> Controller Class Initialized
ERROR - 2026-08-19 03:11:36 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:11:40 --> Config Class Initialized
INFO - 2026-08-19 03:11:40 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:11:40 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:40 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:40 --> URI Class Initialized
INFO - 2026-08-19 03:11:40 --> Router Class Initialized
INFO - 2026-08-19 03:11:40 --> Output Class Initialized
INFO - 2026-08-19 03:11:40 --> Security Class Initialized
DEBUG - 2026-08-19 03:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:40 --> CSRF cookie sent
INFO - 2026-08-19 03:11:40 --> Input Class Initialized
INFO - 2026-08-19 03:11:40 --> Language Class Initialized
INFO - 2026-08-19 03:11:40 --> Language Class Initialized
INFO - 2026-08-19 03:11:40 --> Config Class Initialized
INFO - 2026-08-19 03:11:40 --> Loader Class Initialized
INFO - 2026-08-19 03:11:40 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:40 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:40 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:40 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:40 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:40 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:40 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:40 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:40 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:40 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:40 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:40 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:40 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:11:42 --> Upload Class Initialized
DEBUG - 2026-08-19 03:11:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:11:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:11:42 --> Encryption Class Initialized
INFO - 2026-08-19 03:11:42 --> Form Validation Class Initialized
INFO - 2026-08-19 03:11:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:11:42 --> Pagination Class Initialized
INFO - 2026-08-19 03:11:42 --> Email Class Initialized
INFO - 2026-08-19 03:11:42 --> Controller Class Initialized
DEBUG - 2026-08-19 03:11:42 --> Auth MX_Controller Initialized
INFO - 2026-08-19 03:11:42 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:11:42 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:11:42 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:11:42 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-19 03:11:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:11:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:11:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:11:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-08-19 03:11:43 --> Final output sent to browser
DEBUG - 2026-08-19 03:11:43 --> Total execution time: 2.4640
INFO - 2026-08-19 03:11:43 --> Config Class Initialized
INFO - 2026-08-19 03:11:43 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:11:43 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:43 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:43 --> URI Class Initialized
INFO - 2026-08-19 03:11:43 --> Router Class Initialized
INFO - 2026-08-19 03:11:43 --> Output Class Initialized
INFO - 2026-08-19 03:11:43 --> Security Class Initialized
DEBUG - 2026-08-19 03:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:43 --> CSRF cookie sent
INFO - 2026-08-19 03:11:43 --> Input Class Initialized
INFO - 2026-08-19 03:11:43 --> Language Class Initialized
INFO - 2026-08-19 03:11:43 --> Language Class Initialized
INFO - 2026-08-19 03:11:43 --> Config Class Initialized
INFO - 2026-08-19 03:11:43 --> Config Class Initialized
INFO - 2026-08-19 03:11:43 --> Hooks Class Initialized
INFO - 2026-08-19 03:11:43 --> Loader Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: url_helper
DEBUG - 2026-08-19 03:11:43 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:43 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:43 --> URI Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:43 --> Router Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:43 --> Output Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:43 --> Security Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: cpanel_helper
DEBUG - 2026-08-19 03:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:43 --> CSRF cookie sent
INFO - 2026-08-19 03:11:43 --> Input Class Initialized
INFO - 2026-08-19 03:11:43 --> Language Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:43 --> Language Class Initialized
INFO - 2026-08-19 03:11:43 --> Config Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:43 --> Loader Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:43 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:43 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:43 --> Config Class Initialized
INFO - 2026-08-19 03:11:43 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:11:43 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:43 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:43 --> URI Class Initialized
INFO - 2026-08-19 03:11:43 --> Router Class Initialized
INFO - 2026-08-19 03:11:43 --> Output Class Initialized
INFO - 2026-08-19 03:11:43 --> Security Class Initialized
DEBUG - 2026-08-19 03:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:43 --> CSRF cookie sent
INFO - 2026-08-19 03:11:43 --> Input Class Initialized
INFO - 2026-08-19 03:11:43 --> Language Class Initialized
INFO - 2026-08-19 03:11:43 --> Language Class Initialized
INFO - 2026-08-19 03:11:43 --> Config Class Initialized
INFO - 2026-08-19 03:11:43 --> Loader Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:43 --> Config Class Initialized
INFO - 2026-08-19 03:11:43 --> Hooks Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: ssp_helper
DEBUG - 2026-08-19 03:11:43 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:43 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:43 --> URI Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:43 --> Router Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:43 --> Output Class Initialized
INFO - 2026-08-19 03:11:43 --> Security Class Initialized
DEBUG - 2026-08-19 03:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:43 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:43 --> CSRF cookie sent
INFO - 2026-08-19 03:11:43 --> Input Class Initialized
INFO - 2026-08-19 03:11:43 --> Language Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:43 --> Language Class Initialized
INFO - 2026-08-19 03:11:43 --> Config Class Initialized
INFO - 2026-08-19 03:11:43 --> Config Class Initialized
INFO - 2026-08-19 03:11:43 --> Hooks Class Initialized
INFO - 2026-08-19 03:11:43 --> Loader Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: form_helper
DEBUG - 2026-08-19 03:11:43 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:43 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:43 --> URI Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:43 --> Config Class Initialized
INFO - 2026-08-19 03:11:43 --> Hooks Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:43 --> Router Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:43 --> Database Driver Class Initialized
DEBUG - 2026-08-19 03:11:43 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:43 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:43 --> Output Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:43 --> URI Class Initialized
INFO - 2026-08-19 03:11:43 --> Security Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: plesk_helper
DEBUG - 2026-08-19 03:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:43 --> CSRF cookie sent
INFO - 2026-08-19 03:11:43 --> Input Class Initialized
INFO - 2026-08-19 03:11:43 --> Language Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:43 --> Router Class Initialized
INFO - 2026-08-19 03:11:43 --> Language Class Initialized
INFO - 2026-08-19 03:11:43 --> Config Class Initialized
INFO - 2026-08-19 03:11:43 --> Output Class Initialized
INFO - 2026-08-19 03:11:43 --> Loader Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:43 --> Security Class Initialized
INFO - 2026-08-19 03:11:43 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: cpanel_helper
DEBUG - 2026-08-19 03:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:43 --> CSRF cookie sent
INFO - 2026-08-19 03:11:43 --> Input Class Initialized
INFO - 2026-08-19 03:11:43 --> Language Class Initialized
INFO - 2026-08-19 03:11:43 --> Language Class Initialized
INFO - 2026-08-19 03:11:43 --> Config Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:43 --> Loader Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:43 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:43 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:43 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:43 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:11:45 --> Upload Class Initialized
DEBUG - 2026-08-19 03:11:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:11:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:11:45 --> Encryption Class Initialized
INFO - 2026-08-19 03:11:45 --> Form Validation Class Initialized
INFO - 2026-08-19 03:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:11:45 --> Pagination Class Initialized
INFO - 2026-08-19 03:11:45 --> Email Class Initialized
INFO - 2026-08-19 03:11:45 --> Controller Class Initialized
ERROR - 2026-08-19 03:11:45 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:11:45 --> Upload Class Initialized
DEBUG - 2026-08-19 03:11:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:11:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:11:45 --> Encryption Class Initialized
INFO - 2026-08-19 03:11:45 --> Form Validation Class Initialized
INFO - 2026-08-19 03:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:11:45 --> Pagination Class Initialized
INFO - 2026-08-19 03:11:45 --> Email Class Initialized
INFO - 2026-08-19 03:11:45 --> Controller Class Initialized
ERROR - 2026-08-19 03:11:45 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:11:45 --> Config Class Initialized
INFO - 2026-08-19 03:11:45 --> Hooks Class Initialized
INFO - 2026-08-19 03:11:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-08-19 03:11:45 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:45 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:45 --> URI Class Initialized
INFO - 2026-08-19 03:11:45 --> Upload Class Initialized
DEBUG - 2026-08-19 03:11:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:11:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:11:45 --> Encryption Class Initialized
INFO - 2026-08-19 03:11:45 --> Router Class Initialized
INFO - 2026-08-19 03:11:45 --> Form Validation Class Initialized
INFO - 2026-08-19 03:11:45 --> Output Class Initialized
INFO - 2026-08-19 03:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:11:45 --> Pagination Class Initialized
INFO - 2026-08-19 03:11:45 --> Security Class Initialized
DEBUG - 2026-08-19 03:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:45 --> CSRF cookie sent
INFO - 2026-08-19 03:11:45 --> Input Class Initialized
INFO - 2026-08-19 03:11:45 --> Email Class Initialized
INFO - 2026-08-19 03:11:45 --> Language Class Initialized
INFO - 2026-08-19 03:11:45 --> Controller Class Initialized
INFO - 2026-08-19 03:11:45 --> Language Class Initialized
INFO - 2026-08-19 03:11:45 --> Config Class Initialized
INFO - 2026-08-19 03:11:45 --> Config Class Initialized
INFO - 2026-08-19 03:11:45 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:11:45 --> UTF-8 Support Enabled
DEBUG - 2026-08-19 03:11:45 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:11:45 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:45 --> URI Class Initialized
INFO - 2026-08-19 03:11:45 --> Loader Class Initialized
INFO - 2026-08-19 03:11:45 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:11:45 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:11:45 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:11:45 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:45 --> Model "Common_model" initialized
INFO - 2026-08-19 03:11:45 --> Router Class Initialized
INFO - 2026-08-19 03:11:45 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:45 --> Model "Order_model" initialized
INFO - 2026-08-19 03:11:45 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:11:45 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:45 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:11:45 --> Output Class Initialized
INFO - 2026-08-19 03:11:45 --> Model "Promocode_model" initialized
INFO - 2026-08-19 03:11:45 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:45 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:45 --> Security Class Initialized
DEBUG - 2026-08-19 03:11:45 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:11:45 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:11:45 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:11:45 --> Helper loaded: whmaz_helper
DEBUG - 2026-08-19 03:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:45 --> CSRF cookie sent
INFO - 2026-08-19 03:11:45 --> Input Class Initialized
INFO - 2026-08-19 03:11:45 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:45 --> Language Class Initialized
INFO - 2026-08-19 03:11:45 --> Language Class Initialized
INFO - 2026-08-19 03:11:45 --> Config Class Initialized
INFO - 2026-08-19 03:11:45 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:45 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:45 --> Loader Class Initialized
INFO - 2026-08-19 03:11:45 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:45 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:45 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:45 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:45 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:45 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:45 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:45 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:45 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:45 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:45 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:45 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:45 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:45 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:45 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:45 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:45 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:46 --> Final output sent to browser
DEBUG - 2026-08-19 03:11:46 --> Total execution time: 2.7348
INFO - 2026-08-19 03:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:11:46 --> Upload Class Initialized
DEBUG - 2026-08-19 03:11:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:11:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:11:46 --> Encryption Class Initialized
INFO - 2026-08-19 03:11:46 --> Form Validation Class Initialized
INFO - 2026-08-19 03:11:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:11:46 --> Pagination Class Initialized
INFO - 2026-08-19 03:11:46 --> Email Class Initialized
INFO - 2026-08-19 03:11:46 --> Controller Class Initialized
ERROR - 2026-08-19 03:11:46 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:11:46 --> Upload Class Initialized
DEBUG - 2026-08-19 03:11:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:11:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:11:46 --> Encryption Class Initialized
INFO - 2026-08-19 03:11:46 --> Form Validation Class Initialized
INFO - 2026-08-19 03:11:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:11:46 --> Pagination Class Initialized
INFO - 2026-08-19 03:11:46 --> Email Class Initialized
INFO - 2026-08-19 03:11:46 --> Controller Class Initialized
ERROR - 2026-08-19 03:11:46 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:11:46 --> Upload Class Initialized
DEBUG - 2026-08-19 03:11:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:11:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:11:46 --> Encryption Class Initialized
INFO - 2026-08-19 03:11:46 --> Form Validation Class Initialized
INFO - 2026-08-19 03:11:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:11:46 --> Pagination Class Initialized
INFO - 2026-08-19 03:11:46 --> Email Class Initialized
INFO - 2026-08-19 03:11:46 --> Controller Class Initialized
ERROR - 2026-08-19 03:11:46 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:11:46 --> Upload Class Initialized
DEBUG - 2026-08-19 03:11:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:11:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:11:46 --> Encryption Class Initialized
INFO - 2026-08-19 03:11:46 --> Form Validation Class Initialized
INFO - 2026-08-19 03:11:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:11:46 --> Pagination Class Initialized
INFO - 2026-08-19 03:11:46 --> Email Class Initialized
INFO - 2026-08-19 03:11:46 --> Controller Class Initialized
ERROR - 2026-08-19 03:11:46 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:11:46 --> Upload Class Initialized
DEBUG - 2026-08-19 03:11:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:11:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:11:46 --> Encryption Class Initialized
INFO - 2026-08-19 03:11:46 --> Form Validation Class Initialized
INFO - 2026-08-19 03:11:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:11:46 --> Pagination Class Initialized
INFO - 2026-08-19 03:11:46 --> Email Class Initialized
INFO - 2026-08-19 03:11:46 --> Controller Class Initialized
ERROR - 2026-08-19 03:11:46 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:11:48 --> Config Class Initialized
INFO - 2026-08-19 03:11:48 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:11:48 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:48 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:48 --> URI Class Initialized
INFO - 2026-08-19 03:11:48 --> Router Class Initialized
INFO - 2026-08-19 03:11:48 --> Output Class Initialized
INFO - 2026-08-19 03:11:48 --> Security Class Initialized
DEBUG - 2026-08-19 03:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:48 --> CSRF cookie sent
INFO - 2026-08-19 03:11:48 --> CSRF token verified
INFO - 2026-08-19 03:11:48 --> Input Class Initialized
INFO - 2026-08-19 03:11:48 --> Language Class Initialized
INFO - 2026-08-19 03:11:48 --> Language Class Initialized
INFO - 2026-08-19 03:11:48 --> Config Class Initialized
INFO - 2026-08-19 03:11:48 --> Loader Class Initialized
INFO - 2026-08-19 03:11:48 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:48 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:48 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:48 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:48 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:48 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:48 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:48 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:48 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:48 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:48 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:48 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:48 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:11:50 --> Upload Class Initialized
DEBUG - 2026-08-19 03:11:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:11:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:11:50 --> Encryption Class Initialized
INFO - 2026-08-19 03:11:50 --> Form Validation Class Initialized
INFO - 2026-08-19 03:11:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:11:50 --> Pagination Class Initialized
INFO - 2026-08-19 03:11:50 --> Email Class Initialized
INFO - 2026-08-19 03:11:50 --> Controller Class Initialized
DEBUG - 2026-08-19 03:11:50 --> Auth MX_Controller Initialized
INFO - 2026-08-19 03:11:50 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:11:50 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:11:50 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:11:50 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:11:53 --> Config Class Initialized
INFO - 2026-08-19 03:11:53 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:11:53 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:53 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:53 --> URI Class Initialized
INFO - 2026-08-19 03:11:53 --> Router Class Initialized
INFO - 2026-08-19 03:11:53 --> Output Class Initialized
INFO - 2026-08-19 03:11:53 --> Security Class Initialized
DEBUG - 2026-08-19 03:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:53 --> CSRF cookie sent
INFO - 2026-08-19 03:11:53 --> Input Class Initialized
INFO - 2026-08-19 03:11:53 --> Language Class Initialized
INFO - 2026-08-19 03:11:53 --> Language Class Initialized
INFO - 2026-08-19 03:11:53 --> Config Class Initialized
INFO - 2026-08-19 03:11:53 --> Loader Class Initialized
INFO - 2026-08-19 03:11:53 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:53 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:53 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:53 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:53 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:53 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:53 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:53 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:53 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:53 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:53 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:53 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:53 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:11:54 --> Upload Class Initialized
DEBUG - 2026-08-19 03:11:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:11:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:11:54 --> Encryption Class Initialized
INFO - 2026-08-19 03:11:54 --> Form Validation Class Initialized
INFO - 2026-08-19 03:11:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:11:54 --> Pagination Class Initialized
INFO - 2026-08-19 03:11:54 --> Email Class Initialized
INFO - 2026-08-19 03:11:54 --> Controller Class Initialized
DEBUG - 2026-08-19 03:11:54 --> Clientarea MX_Controller Initialized
INFO - 2026-08-19 03:11:54 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:11:54 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:11:54 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:11:54 --> Model "Clientarea_model" initialized
INFO - 2026-08-19 03:11:54 --> Model "Billing_model" initialized
INFO - 2026-08-19 03:11:54 --> Model "Common_model" initialized
INFO - 2026-08-19 03:11:54 --> Model "Order_model" initialized
INFO - 2026-08-19 03:11:54 --> Model "Support_model" initialized
INFO - 2026-08-19 03:11:55 --> Model "Subscription_model" initialized
INFO - 2026-08-19 03:11:55 --> Model "Software_model" initialized
DEBUG - 2026-08-19 03:11:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:11:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:11:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:11:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_index.php
INFO - 2026-08-19 03:11:56 --> Final output sent to browser
DEBUG - 2026-08-19 03:11:56 --> Total execution time: 3.3903
INFO - 2026-08-19 03:11:56 --> Config Class Initialized
INFO - 2026-08-19 03:11:56 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:11:56 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:56 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:56 --> URI Class Initialized
INFO - 2026-08-19 03:11:56 --> Router Class Initialized
INFO - 2026-08-19 03:11:56 --> Output Class Initialized
INFO - 2026-08-19 03:11:56 --> Security Class Initialized
DEBUG - 2026-08-19 03:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:56 --> CSRF cookie sent
INFO - 2026-08-19 03:11:56 --> Input Class Initialized
INFO - 2026-08-19 03:11:56 --> Language Class Initialized
INFO - 2026-08-19 03:11:56 --> Language Class Initialized
INFO - 2026-08-19 03:11:56 --> Config Class Initialized
INFO - 2026-08-19 03:11:56 --> Loader Class Initialized
INFO - 2026-08-19 03:11:56 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:56 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:56 --> Config Class Initialized
INFO - 2026-08-19 03:11:56 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:11:56 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:56 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:56 --> URI Class Initialized
INFO - 2026-08-19 03:11:56 --> Config Class Initialized
INFO - 2026-08-19 03:11:56 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:11:56 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:56 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:56 --> URI Class Initialized
INFO - 2026-08-19 03:11:56 --> Router Class Initialized
INFO - 2026-08-19 03:11:56 --> Router Class Initialized
INFO - 2026-08-19 03:11:56 --> Output Class Initialized
INFO - 2026-08-19 03:11:56 --> Config Class Initialized
INFO - 2026-08-19 03:11:56 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:11:56 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:56 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:56 --> URI Class Initialized
INFO - 2026-08-19 03:11:56 --> Router Class Initialized
INFO - 2026-08-19 03:11:56 --> Output Class Initialized
INFO - 2026-08-19 03:11:56 --> Config Class Initialized
INFO - 2026-08-19 03:11:56 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:11:56 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:56 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:56 --> URI Class Initialized
INFO - 2026-08-19 03:11:56 --> Security Class Initialized
DEBUG - 2026-08-19 03:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:56 --> CSRF cookie sent
INFO - 2026-08-19 03:11:56 --> Input Class Initialized
INFO - 2026-08-19 03:11:56 --> Language Class Initialized
INFO - 2026-08-19 03:11:56 --> Language Class Initialized
INFO - 2026-08-19 03:11:56 --> Output Class Initialized
INFO - 2026-08-19 03:11:56 --> Security Class Initialized
INFO - 2026-08-19 03:11:56 --> Config Class Initialized
INFO - 2026-08-19 03:11:56 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:11:56 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:56 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:56 --> Security Class Initialized
INFO - 2026-08-19 03:11:56 --> Config Class Initialized
INFO - 2026-08-19 03:11:56 --> Router Class Initialized
DEBUG - 2026-08-19 03:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:56 --> CSRF cookie sent
INFO - 2026-08-19 03:11:56 --> Input Class Initialized
INFO - 2026-08-19 03:11:56 --> Language Class Initialized
INFO - 2026-08-19 03:11:56 --> Language Class Initialized
INFO - 2026-08-19 03:11:56 --> Config Class Initialized
INFO - 2026-08-19 03:11:56 --> Loader Class Initialized
INFO - 2026-08-19 03:11:56 --> Output Class Initialized
INFO - 2026-08-19 03:11:56 --> Helper loaded: url_helper
DEBUG - 2026-08-19 03:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:56 --> CSRF cookie sent
INFO - 2026-08-19 03:11:56 --> Input Class Initialized
INFO - 2026-08-19 03:11:56 --> Security Class Initialized
INFO - 2026-08-19 03:11:56 --> Language Class Initialized
INFO - 2026-08-19 03:11:56 --> Loader Class Initialized
INFO - 2026-08-19 03:11:56 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:56 --> Language Class Initialized
INFO - 2026-08-19 03:11:56 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:56 --> URI Class Initialized
INFO - 2026-08-19 03:11:56 --> Helper loaded: form_helper
DEBUG - 2026-08-19 03:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:56 --> CSRF cookie sent
INFO - 2026-08-19 03:11:56 --> Input Class Initialized
INFO - 2026-08-19 03:11:56 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:56 --> Router Class Initialized
INFO - 2026-08-19 03:11:56 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:56 --> Language Class Initialized
INFO - 2026-08-19 03:11:56 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:56 --> Config Class Initialized
INFO - 2026-08-19 03:11:56 --> Language Class Initialized
INFO - 2026-08-19 03:11:56 --> Config Class Initialized
INFO - 2026-08-19 03:11:56 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:56 --> Output Class Initialized
INFO - 2026-08-19 03:11:56 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:56 --> Loader Class Initialized
INFO - 2026-08-19 03:11:56 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:56 --> Security Class Initialized
INFO - 2026-08-19 03:11:56 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: form_helper
DEBUG - 2026-08-19 03:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:56 --> CSRF cookie sent
INFO - 2026-08-19 03:11:56 --> Input Class Initialized
INFO - 2026-08-19 03:11:56 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:56 --> Language Class Initialized
INFO - 2026-08-19 03:11:56 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:56 --> Language Class Initialized
INFO - 2026-08-19 03:11:56 --> Config Class Initialized
INFO - 2026-08-19 03:11:56 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:56 --> Loader Class Initialized
INFO - 2026-08-19 03:11:56 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:56 --> Loader Class Initialized
INFO - 2026-08-19 03:11:56 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:56 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:56 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:56 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:56 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:56 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:56 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:56 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:56 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:56 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:11:58 --> Upload Class Initialized
DEBUG - 2026-08-19 03:11:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:11:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:11:58 --> Encryption Class Initialized
INFO - 2026-08-19 03:11:58 --> Form Validation Class Initialized
INFO - 2026-08-19 03:11:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:11:58 --> Pagination Class Initialized
INFO - 2026-08-19 03:11:58 --> Email Class Initialized
INFO - 2026-08-19 03:11:58 --> Controller Class Initialized
ERROR - 2026-08-19 03:11:58 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:11:58 --> Upload Class Initialized
DEBUG - 2026-08-19 03:11:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:11:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:11:58 --> Encryption Class Initialized
INFO - 2026-08-19 03:11:58 --> Form Validation Class Initialized
INFO - 2026-08-19 03:11:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:11:58 --> Pagination Class Initialized
INFO - 2026-08-19 03:11:58 --> Email Class Initialized
INFO - 2026-08-19 03:11:58 --> Controller Class Initialized
INFO - 2026-08-19 03:11:58 --> Config Class Initialized
INFO - 2026-08-19 03:11:58 --> Hooks Class Initialized
ERROR - 2026-08-19 03:11:58 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:11:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-08-19 03:11:58 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:58 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:58 --> URI Class Initialized
INFO - 2026-08-19 03:11:58 --> Upload Class Initialized
DEBUG - 2026-08-19 03:11:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:11:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:11:58 --> Encryption Class Initialized
INFO - 2026-08-19 03:11:58 --> Router Class Initialized
INFO - 2026-08-19 03:11:58 --> Output Class Initialized
INFO - 2026-08-19 03:11:58 --> Form Validation Class Initialized
INFO - 2026-08-19 03:11:58 --> Security Class Initialized
INFO - 2026-08-19 03:11:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:11:58 --> Pagination Class Initialized
DEBUG - 2026-08-19 03:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:58 --> CSRF cookie sent
INFO - 2026-08-19 03:11:58 --> Input Class Initialized
INFO - 2026-08-19 03:11:58 --> Language Class Initialized
INFO - 2026-08-19 03:11:58 --> Language Class Initialized
INFO - 2026-08-19 03:11:58 --> Config Class Initialized
INFO - 2026-08-19 03:11:58 --> Config Class Initialized
INFO - 2026-08-19 03:11:58 --> Hooks Class Initialized
INFO - 2026-08-19 03:11:58 --> Email Class Initialized
INFO - 2026-08-19 03:11:58 --> Controller Class Initialized
ERROR - 2026-08-19 03:11:58 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:11:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-08-19 03:11:58 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:58 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:58 --> Loader Class Initialized
INFO - 2026-08-19 03:11:58 --> URI Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:58 --> Upload Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:58 --> Router Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: html_helper
DEBUG - 2026-08-19 03:11:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:11:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:11:58 --> Encryption Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:58 --> Output Class Initialized
INFO - 2026-08-19 03:11:58 --> Security Class Initialized
INFO - 2026-08-19 03:11:58 --> Form Validation Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: whmaz_helper
DEBUG - 2026-08-19 03:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:58 --> CSRF cookie sent
INFO - 2026-08-19 03:11:58 --> Input Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:11:58 --> Language Class Initialized
INFO - 2026-08-19 03:11:58 --> Pagination Class Initialized
INFO - 2026-08-19 03:11:58 --> Language Class Initialized
INFO - 2026-08-19 03:11:58 --> Config Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:58 --> Loader Class Initialized
INFO - 2026-08-19 03:11:58 --> Email Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:58 --> Controller Class Initialized
INFO - 2026-08-19 03:11:58 --> Config Class Initialized
INFO - 2026-08-19 03:11:58 --> Hooks Class Initialized
ERROR - 2026-08-19 03:11:58 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:11:58 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:11:58 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: html_helper
DEBUG - 2026-08-19 03:11:58 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:58 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:58 --> URI Class Initialized
INFO - 2026-08-19 03:11:58 --> Upload Class Initialized
INFO - 2026-08-19 03:11:58 --> Router Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: whmaz_helper
DEBUG - 2026-08-19 03:11:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:11:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:11:58 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:58 --> Encryption Class Initialized
INFO - 2026-08-19 03:11:58 --> Output Class Initialized
INFO - 2026-08-19 03:11:58 --> Security Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:58 --> Form Validation Class Initialized
INFO - 2026-08-19 03:11:58 --> Database Driver Class Initialized
DEBUG - 2026-08-19 03:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:11:58 --> Pagination Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:58 --> Input Class Initialized
INFO - 2026-08-19 03:11:58 --> Language Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:58 --> Language Class Initialized
INFO - 2026-08-19 03:11:58 --> Config Class Initialized
INFO - 2026-08-19 03:11:58 --> Email Class Initialized
INFO - 2026-08-19 03:11:58 --> Config Class Initialized
INFO - 2026-08-19 03:11:58 --> Controller Class Initialized
INFO - 2026-08-19 03:11:58 --> Hooks Class Initialized
ERROR - 2026-08-19 03:11:58 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:11:58 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:58 --> Loader Class Initialized
DEBUG - 2026-08-19 03:11:58 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:58 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:58 --> URI Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:58 --> Router Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:58 --> Output Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:58 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:58 --> Security Class Initialized
DEBUG - 2026-08-19 03:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:58 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:58 --> Input Class Initialized
INFO - 2026-08-19 03:11:58 --> Language Class Initialized
INFO - 2026-08-19 03:11:58 --> Config Class Initialized
INFO - 2026-08-19 03:11:58 --> Hooks Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: plesk_helper
DEBUG - 2026-08-19 03:11:58 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:58 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:58 --> Language Class Initialized
INFO - 2026-08-19 03:11:58 --> Config Class Initialized
INFO - 2026-08-19 03:11:58 --> URI Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:58 --> Router Class Initialized
INFO - 2026-08-19 03:11:58 --> Loader Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:58 --> Output Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:58 --> Security Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: html_helper
DEBUG - 2026-08-19 03:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:58 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:58 --> Input Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:58 --> Language Class Initialized
INFO - 2026-08-19 03:11:58 --> Language Class Initialized
INFO - 2026-08-19 03:11:58 --> Config Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:58 --> Loader Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:58 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:58 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:58 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:58 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:58 --> Database Driver Class Initialized
INFO - 2026-08-19 03:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:11:59 --> Upload Class Initialized
DEBUG - 2026-08-19 03:11:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:11:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:11:59 --> Encryption Class Initialized
INFO - 2026-08-19 03:11:59 --> Form Validation Class Initialized
INFO - 2026-08-19 03:11:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:11:59 --> Pagination Class Initialized
INFO - 2026-08-19 03:11:59 --> Email Class Initialized
INFO - 2026-08-19 03:11:59 --> Controller Class Initialized
ERROR - 2026-08-19 03:11:59 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:11:59 --> Config Class Initialized
INFO - 2026-08-19 03:11:59 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:11:59 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:11:59 --> Utf8 Class Initialized
INFO - 2026-08-19 03:11:59 --> URI Class Initialized
INFO - 2026-08-19 03:11:59 --> Router Class Initialized
INFO - 2026-08-19 03:11:59 --> Output Class Initialized
INFO - 2026-08-19 03:11:59 --> Security Class Initialized
DEBUG - 2026-08-19 03:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:11:59 --> CSRF cookie sent
INFO - 2026-08-19 03:11:59 --> Input Class Initialized
INFO - 2026-08-19 03:11:59 --> Language Class Initialized
INFO - 2026-08-19 03:11:59 --> Language Class Initialized
INFO - 2026-08-19 03:11:59 --> Config Class Initialized
INFO - 2026-08-19 03:11:59 --> Loader Class Initialized
INFO - 2026-08-19 03:11:59 --> Helper loaded: url_helper
INFO - 2026-08-19 03:11:59 --> Helper loaded: form_helper
INFO - 2026-08-19 03:11:59 --> Helper loaded: html_helper
INFO - 2026-08-19 03:11:59 --> Helper loaded: file_helper
INFO - 2026-08-19 03:11:59 --> Helper loaded: email_helper
INFO - 2026-08-19 03:11:59 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:11:59 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:11:59 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:11:59 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:11:59 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:11:59 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:11:59 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:11:59 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:00 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:00 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:00 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:00 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:00 --> Email Class Initialized
INFO - 2026-08-19 03:12:00 --> Controller Class Initialized
DEBUG - 2026-08-19 03:12:00 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:12:00 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:12:00 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:12:00 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:12:00 --> Model "Common_model" initialized
INFO - 2026-08-19 03:12:00 --> Model "Order_model" initialized
INFO - 2026-08-19 03:12:00 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:12:00 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:12:00 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:12:00 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:12:00 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:12:00 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:12:00 --> Final output sent to browser
DEBUG - 2026-08-19 03:12:00 --> Total execution time: 2.1484
INFO - 2026-08-19 03:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:00 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:00 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:00 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:00 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:00 --> Email Class Initialized
INFO - 2026-08-19 03:12:00 --> Controller Class Initialized
DEBUG - 2026-08-19 03:12:00 --> Tickets MX_Controller Initialized
INFO - 2026-08-19 03:12:00 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:12:00 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:12:00 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:12:00 --> Model "Support_model" initialized
INFO - 2026-08-19 03:12:00 --> Model "Common_model" initialized
INFO - 2026-08-19 03:12:01 --> Final output sent to browser
DEBUG - 2026-08-19 03:12:01 --> Total execution time: 2.7392
INFO - 2026-08-19 03:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:01 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:01 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:01 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:01 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:01 --> Email Class Initialized
INFO - 2026-08-19 03:12:01 --> Controller Class Initialized
DEBUG - 2026-08-19 03:12:01 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:12:01 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:12:01 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:12:01 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:12:01 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:02 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:02 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:02 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:02 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:02 --> Email Class Initialized
INFO - 2026-08-19 03:12:02 --> Controller Class Initialized
ERROR - 2026-08-19 03:12:02 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:02 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:02 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:02 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:02 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:02 --> Email Class Initialized
INFO - 2026-08-19 03:12:02 --> Controller Class Initialized
DEBUG - 2026-08-19 03:12:02 --> Clientarea MX_Controller Initialized
INFO - 2026-08-19 03:12:02 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:12:02 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:12:02 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:12:02 --> Model "Clientarea_model" initialized
INFO - 2026-08-19 03:12:02 --> Model "Billing_model" initialized
INFO - 2026-08-19 03:12:02 --> Model "Common_model" initialized
INFO - 2026-08-19 03:12:02 --> Model "Order_model" initialized
INFO - 2026-08-19 03:12:02 --> Model "Support_model" initialized
INFO - 2026-08-19 03:12:02 --> Final output sent to browser
DEBUG - 2026-08-19 03:12:02 --> Total execution time: 4.2914
INFO - 2026-08-19 03:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:02 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:02 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:02 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:02 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:02 --> Email Class Initialized
INFO - 2026-08-19 03:12:02 --> Controller Class Initialized
DEBUG - 2026-08-19 03:12:02 --> Invoicing MX_Controller Initialized
INFO - 2026-08-19 03:12:02 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:12:02 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:12:02 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:12:02 --> Model "Billing_model" initialized
INFO - 2026-08-19 03:12:02 --> Model "Common_model" initialized
INFO - 2026-08-19 03:12:02 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:12:02 --> Config Class Initialized
INFO - 2026-08-19 03:12:02 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:02 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:02 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:02 --> URI Class Initialized
INFO - 2026-08-19 03:12:02 --> Router Class Initialized
INFO - 2026-08-19 03:12:02 --> Output Class Initialized
INFO - 2026-08-19 03:12:02 --> Security Class Initialized
DEBUG - 2026-08-19 03:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:02 --> CSRF cookie sent
INFO - 2026-08-19 03:12:02 --> Input Class Initialized
INFO - 2026-08-19 03:12:02 --> Language Class Initialized
INFO - 2026-08-19 03:12:02 --> Language Class Initialized
INFO - 2026-08-19 03:12:02 --> Config Class Initialized
INFO - 2026-08-19 03:12:02 --> Loader Class Initialized
INFO - 2026-08-19 03:12:02 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:02 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:02 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:02 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:02 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:02 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:02 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:02 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:02 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:02 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:02 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:02 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:02 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:03 --> Final output sent to browser
DEBUG - 2026-08-19 03:12:03 --> Total execution time: 4.9937
INFO - 2026-08-19 03:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:04 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:04 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:04 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:04 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:04 --> Email Class Initialized
INFO - 2026-08-19 03:12:04 --> Controller Class Initialized
DEBUG - 2026-08-19 03:12:04 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:12:04 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:12:04 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:12:04 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:12:04 --> Model "Common_model" initialized
INFO - 2026-08-19 03:12:04 --> Model "Order_model" initialized
INFO - 2026-08-19 03:12:04 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:12:04 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:12:04 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:12:04 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:12:04 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:12:04 --> Model "Orderlicense_model" initialized
DEBUG - 2026-08-19 03:12:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:12:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-08-19 03:12:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-08-19 03:12:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:12:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:12:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/view_card.php
INFO - 2026-08-19 03:12:07 --> Final output sent to browser
DEBUG - 2026-08-19 03:12:07 --> Total execution time: 4.6773
INFO - 2026-08-19 03:12:07 --> Config Class Initialized
INFO - 2026-08-19 03:12:07 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:07 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:07 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:07 --> URI Class Initialized
INFO - 2026-08-19 03:12:07 --> Router Class Initialized
INFO - 2026-08-19 03:12:07 --> Output Class Initialized
INFO - 2026-08-19 03:12:07 --> Security Class Initialized
DEBUG - 2026-08-19 03:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:07 --> CSRF cookie sent
INFO - 2026-08-19 03:12:07 --> Input Class Initialized
INFO - 2026-08-19 03:12:07 --> Language Class Initialized
INFO - 2026-08-19 03:12:07 --> Language Class Initialized
INFO - 2026-08-19 03:12:07 --> Config Class Initialized
INFO - 2026-08-19 03:12:07 --> Loader Class Initialized
INFO - 2026-08-19 03:12:07 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:07 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:07 --> Config Class Initialized
INFO - 2026-08-19 03:12:07 --> Hooks Class Initialized
INFO - 2026-08-19 03:12:07 --> Config Class Initialized
INFO - 2026-08-19 03:12:07 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:07 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:07 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:07 --> URI Class Initialized
INFO - 2026-08-19 03:12:07 --> Config Class Initialized
INFO - 2026-08-19 03:12:07 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:07 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:07 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:07 --> URI Class Initialized
INFO - 2026-08-19 03:12:07 --> Router Class Initialized
INFO - 2026-08-19 03:12:07 --> Output Class Initialized
INFO - 2026-08-19 03:12:07 --> Security Class Initialized
INFO - 2026-08-19 03:12:07 --> Router Class Initialized
INFO - 2026-08-19 03:12:07 --> Config Class Initialized
INFO - 2026-08-19 03:12:07 --> Hooks Class Initialized
INFO - 2026-08-19 03:12:07 --> Output Class Initialized
DEBUG - 2026-08-19 03:12:07 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:07 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:07 --> Config Class Initialized
INFO - 2026-08-19 03:12:07 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:07 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:07 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:07 --> URI Class Initialized
DEBUG - 2026-08-19 03:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:07 --> CSRF cookie sent
INFO - 2026-08-19 03:12:07 --> Input Class Initialized
INFO - 2026-08-19 03:12:07 --> Language Class Initialized
INFO - 2026-08-19 03:12:07 --> URI Class Initialized
DEBUG - 2026-08-19 03:12:07 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:07 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:07 --> Language Class Initialized
INFO - 2026-08-19 03:12:07 --> Config Class Initialized
INFO - 2026-08-19 03:12:07 --> URI Class Initialized
INFO - 2026-08-19 03:12:07 --> Router Class Initialized
INFO - 2026-08-19 03:12:07 --> Router Class Initialized
INFO - 2026-08-19 03:12:07 --> Security Class Initialized
INFO - 2026-08-19 03:12:07 --> Output Class Initialized
DEBUG - 2026-08-19 03:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:07 --> CSRF cookie sent
INFO - 2026-08-19 03:12:07 --> Input Class Initialized
INFO - 2026-08-19 03:12:07 --> Router Class Initialized
INFO - 2026-08-19 03:12:07 --> Language Class Initialized
INFO - 2026-08-19 03:12:07 --> Security Class Initialized
INFO - 2026-08-19 03:12:07 --> Language Class Initialized
INFO - 2026-08-19 03:12:07 --> Config Class Initialized
INFO - 2026-08-19 03:12:07 --> Output Class Initialized
INFO - 2026-08-19 03:12:07 --> Output Class Initialized
DEBUG - 2026-08-19 03:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:07 --> CSRF cookie sent
INFO - 2026-08-19 03:12:07 --> Input Class Initialized
INFO - 2026-08-19 03:12:07 --> Language Class Initialized
INFO - 2026-08-19 03:12:07 --> Security Class Initialized
INFO - 2026-08-19 03:12:07 --> Security Class Initialized
INFO - 2026-08-19 03:12:07 --> Language Class Initialized
INFO - 2026-08-19 03:12:07 --> Config Class Initialized
DEBUG - 2026-08-19 03:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:07 --> CSRF cookie sent
INFO - 2026-08-19 03:12:07 --> Input Class Initialized
INFO - 2026-08-19 03:12:07 --> Language Class Initialized
INFO - 2026-08-19 03:12:07 --> Loader Class Initialized
INFO - 2026-08-19 03:12:07 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:07 --> Loader Class Initialized
INFO - 2026-08-19 03:12:07 --> Language Class Initialized
INFO - 2026-08-19 03:12:07 --> Config Class Initialized
INFO - 2026-08-19 03:12:07 --> Helper loaded: url_helper
DEBUG - 2026-08-19 03:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:07 --> CSRF cookie sent
INFO - 2026-08-19 03:12:07 --> Input Class Initialized
INFO - 2026-08-19 03:12:07 --> Language Class Initialized
INFO - 2026-08-19 03:12:07 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:07 --> Loader Class Initialized
INFO - 2026-08-19 03:12:07 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:07 --> Loader Class Initialized
INFO - 2026-08-19 03:12:07 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:07 --> Language Class Initialized
INFO - 2026-08-19 03:12:07 --> Config Class Initialized
INFO - 2026-08-19 03:12:07 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:07 --> Loader Class Initialized
INFO - 2026-08-19 03:12:07 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:07 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:07 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:07 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:07 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:07 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:07 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:07 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:07 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:07 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:09 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:09 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:09 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:09 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:09 --> Email Class Initialized
INFO - 2026-08-19 03:12:09 --> Controller Class Initialized
ERROR - 2026-08-19 03:12:09 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:12:09 --> Config Class Initialized
INFO - 2026-08-19 03:12:09 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:09 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:09 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:09 --> URI Class Initialized
INFO - 2026-08-19 03:12:09 --> Router Class Initialized
INFO - 2026-08-19 03:12:09 --> Output Class Initialized
INFO - 2026-08-19 03:12:09 --> Security Class Initialized
DEBUG - 2026-08-19 03:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:09 --> CSRF cookie sent
INFO - 2026-08-19 03:12:09 --> Input Class Initialized
INFO - 2026-08-19 03:12:09 --> Language Class Initialized
INFO - 2026-08-19 03:12:09 --> Language Class Initialized
INFO - 2026-08-19 03:12:09 --> Config Class Initialized
INFO - 2026-08-19 03:12:09 --> Loader Class Initialized
INFO - 2026-08-19 03:12:09 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:09 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:09 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:09 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:09 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:09 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:09 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:09 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:09 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:09 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:09 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:09 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:09 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:09 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:09 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:09 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:09 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:09 --> Email Class Initialized
INFO - 2026-08-19 03:12:09 --> Controller Class Initialized
ERROR - 2026-08-19 03:12:09 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:12:09 --> Config Class Initialized
INFO - 2026-08-19 03:12:09 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:09 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:09 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:09 --> URI Class Initialized
INFO - 2026-08-19 03:12:09 --> Router Class Initialized
INFO - 2026-08-19 03:12:09 --> Output Class Initialized
INFO - 2026-08-19 03:12:09 --> Security Class Initialized
DEBUG - 2026-08-19 03:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:09 --> CSRF cookie sent
INFO - 2026-08-19 03:12:09 --> Input Class Initialized
INFO - 2026-08-19 03:12:09 --> Language Class Initialized
INFO - 2026-08-19 03:12:09 --> Language Class Initialized
INFO - 2026-08-19 03:12:09 --> Config Class Initialized
INFO - 2026-08-19 03:12:09 --> Loader Class Initialized
INFO - 2026-08-19 03:12:09 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:09 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:09 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:09 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:09 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:09 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:09 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:09 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:09 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:09 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:09 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:09 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:09 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:10 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:10 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:10 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:10 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:10 --> Email Class Initialized
INFO - 2026-08-19 03:12:10 --> Controller Class Initialized
ERROR - 2026-08-19 03:12:10 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:10 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:10 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:10 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:10 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:10 --> Config Class Initialized
INFO - 2026-08-19 03:12:10 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:10 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:10 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:10 --> Email Class Initialized
INFO - 2026-08-19 03:12:10 --> Controller Class Initialized
INFO - 2026-08-19 03:12:10 --> URI Class Initialized
ERROR - 2026-08-19 03:12:10 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:10 --> Router Class Initialized
INFO - 2026-08-19 03:12:10 --> Upload Class Initialized
INFO - 2026-08-19 03:12:10 --> Output Class Initialized
DEBUG - 2026-08-19 03:12:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:10 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:10 --> Security Class Initialized
DEBUG - 2026-08-19 03:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:10 --> CSRF cookie sent
INFO - 2026-08-19 03:12:10 --> Input Class Initialized
INFO - 2026-08-19 03:12:10 --> Language Class Initialized
INFO - 2026-08-19 03:12:10 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:10 --> Language Class Initialized
INFO - 2026-08-19 03:12:10 --> Config Class Initialized
INFO - 2026-08-19 03:12:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:10 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:10 --> Loader Class Initialized
INFO - 2026-08-19 03:12:10 --> Email Class Initialized
INFO - 2026-08-19 03:12:10 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:10 --> Controller Class Initialized
ERROR - 2026-08-19 03:12:10 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:10 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:10 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:10 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:10 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:10 --> Upload Class Initialized
INFO - 2026-08-19 03:12:10 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:10 --> Helper loaded: ssp_helper
DEBUG - 2026-08-19 03:12:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:10 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:10 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:10 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:10 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:10 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:10 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:10 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:10 --> Email Class Initialized
INFO - 2026-08-19 03:12:10 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:10 --> Controller Class Initialized
ERROR - 2026-08-19 03:12:10 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:12:10 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:11 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:11 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:11 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:11 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:11 --> Email Class Initialized
INFO - 2026-08-19 03:12:11 --> Controller Class Initialized
DEBUG - 2026-08-19 03:12:11 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:12:11 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:12:11 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:12:11 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:12:11 --> Model "Common_model" initialized
INFO - 2026-08-19 03:12:11 --> Model "Order_model" initialized
INFO - 2026-08-19 03:12:11 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:12:11 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:12:11 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:12:11 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:12:11 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:12:11 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:12:11 --> Final output sent to browser
DEBUG - 2026-08-19 03:12:11 --> Total execution time: 2.1481
INFO - 2026-08-19 03:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:11 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:11 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:11 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:11 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:11 --> Email Class Initialized
INFO - 2026-08-19 03:12:11 --> Controller Class Initialized
DEBUG - 2026-08-19 03:12:11 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:12:11 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:12:11 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:12:11 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:12:11 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:12 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:12 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:12 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:12 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:12 --> Email Class Initialized
INFO - 2026-08-19 03:12:12 --> Controller Class Initialized
ERROR - 2026-08-19 03:12:12 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:12:15 --> Config Class Initialized
INFO - 2026-08-19 03:12:15 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:15 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:15 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:15 --> URI Class Initialized
INFO - 2026-08-19 03:12:15 --> Router Class Initialized
INFO - 2026-08-19 03:12:15 --> Output Class Initialized
INFO - 2026-08-19 03:12:15 --> Security Class Initialized
DEBUG - 2026-08-19 03:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:15 --> CSRF cookie sent
INFO - 2026-08-19 03:12:15 --> Input Class Initialized
INFO - 2026-08-19 03:12:15 --> Language Class Initialized
INFO - 2026-08-19 03:12:15 --> Language Class Initialized
INFO - 2026-08-19 03:12:15 --> Config Class Initialized
INFO - 2026-08-19 03:12:15 --> Loader Class Initialized
INFO - 2026-08-19 03:12:15 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:15 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:15 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:15 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:15 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:15 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:15 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:15 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:15 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:15 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:15 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:15 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:15 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:17 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:17 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:17 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:17 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:17 --> Email Class Initialized
INFO - 2026-08-19 03:12:17 --> Controller Class Initialized
DEBUG - 2026-08-19 03:12:17 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:12:17 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:12:17 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:12:17 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:12:17 --> Model "Common_model" initialized
INFO - 2026-08-19 03:12:17 --> Model "Order_model" initialized
INFO - 2026-08-19 03:12:17 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:12:17 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:12:17 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:12:17 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:12:17 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:12:17 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:12:17 --> Final output sent to browser
DEBUG - 2026-08-19 03:12:17 --> Total execution time: 2.7734
INFO - 2026-08-19 03:12:18 --> Config Class Initialized
INFO - 2026-08-19 03:12:18 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:18 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:18 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:18 --> URI Class Initialized
INFO - 2026-08-19 03:12:18 --> Router Class Initialized
INFO - 2026-08-19 03:12:18 --> Output Class Initialized
INFO - 2026-08-19 03:12:18 --> Security Class Initialized
DEBUG - 2026-08-19 03:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:18 --> CSRF cookie sent
INFO - 2026-08-19 03:12:18 --> Input Class Initialized
INFO - 2026-08-19 03:12:18 --> Language Class Initialized
INFO - 2026-08-19 03:12:18 --> Language Class Initialized
INFO - 2026-08-19 03:12:18 --> Config Class Initialized
INFO - 2026-08-19 03:12:18 --> Loader Class Initialized
INFO - 2026-08-19 03:12:18 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:18 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:18 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:18 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:18 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:18 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:18 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:18 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:18 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:18 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:18 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:18 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:18 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:19 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:19 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:19 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:19 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:19 --> Email Class Initialized
INFO - 2026-08-19 03:12:19 --> Controller Class Initialized
DEBUG - 2026-08-19 03:12:19 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:12:19 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:12:19 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:12:19 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:12:19 --> Model "Common_model" initialized
INFO - 2026-08-19 03:12:19 --> Model "Order_model" initialized
INFO - 2026-08-19 03:12:19 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:12:19 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:12:19 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:12:19 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:12:19 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:12:19 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:12:20 --> Config Class Initialized
INFO - 2026-08-19 03:12:20 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:20 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:20 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:20 --> URI Class Initialized
INFO - 2026-08-19 03:12:20 --> Router Class Initialized
INFO - 2026-08-19 03:12:20 --> Output Class Initialized
INFO - 2026-08-19 03:12:20 --> Security Class Initialized
DEBUG - 2026-08-19 03:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:20 --> CSRF cookie sent
INFO - 2026-08-19 03:12:20 --> Input Class Initialized
INFO - 2026-08-19 03:12:20 --> Language Class Initialized
INFO - 2026-08-19 03:12:20 --> Language Class Initialized
INFO - 2026-08-19 03:12:20 --> Config Class Initialized
INFO - 2026-08-19 03:12:20 --> Loader Class Initialized
INFO - 2026-08-19 03:12:20 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:20 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:20 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:20 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:20 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:20 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:20 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:20 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:20 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:20 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:20 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:20 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:20 --> Database Driver Class Initialized
DEBUG - 2026-08-19 03:12:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:12:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-08-19 03:12:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-08-19 03:12:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:12:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:12:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/view_card.php
INFO - 2026-08-19 03:12:23 --> Final output sent to browser
DEBUG - 2026-08-19 03:12:23 --> Total execution time: 5.2140
INFO - 2026-08-19 03:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:23 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:23 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:23 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:23 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:23 --> Email Class Initialized
INFO - 2026-08-19 03:12:23 --> Controller Class Initialized
DEBUG - 2026-08-19 03:12:23 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:12:23 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:12:23 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:12:23 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:12:23 --> Model "Common_model" initialized
INFO - 2026-08-19 03:12:23 --> Model "Order_model" initialized
INFO - 2026-08-19 03:12:23 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:12:23 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:12:23 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:12:23 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:12:23 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:12:23 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:12:23 --> Config Class Initialized
INFO - 2026-08-19 03:12:23 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:23 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:23 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:23 --> URI Class Initialized
INFO - 2026-08-19 03:12:23 --> Router Class Initialized
INFO - 2026-08-19 03:12:23 --> Output Class Initialized
INFO - 2026-08-19 03:12:23 --> Security Class Initialized
DEBUG - 2026-08-19 03:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:23 --> CSRF cookie sent
INFO - 2026-08-19 03:12:23 --> Input Class Initialized
INFO - 2026-08-19 03:12:23 --> Language Class Initialized
INFO - 2026-08-19 03:12:23 --> Language Class Initialized
INFO - 2026-08-19 03:12:23 --> Config Class Initialized
INFO - 2026-08-19 03:12:23 --> Loader Class Initialized
INFO - 2026-08-19 03:12:23 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:23 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:23 --> Config Class Initialized
INFO - 2026-08-19 03:12:23 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:23 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:23 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:23 --> URI Class Initialized
INFO - 2026-08-19 03:12:23 --> Router Class Initialized
INFO - 2026-08-19 03:12:23 --> Output Class Initialized
INFO - 2026-08-19 03:12:23 --> Security Class Initialized
DEBUG - 2026-08-19 03:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:23 --> CSRF cookie sent
INFO - 2026-08-19 03:12:23 --> Input Class Initialized
INFO - 2026-08-19 03:12:23 --> Language Class Initialized
INFO - 2026-08-19 03:12:23 --> Language Class Initialized
INFO - 2026-08-19 03:12:23 --> Config Class Initialized
INFO - 2026-08-19 03:12:23 --> Loader Class Initialized
INFO - 2026-08-19 03:12:23 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:23 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:23 --> Config Class Initialized
INFO - 2026-08-19 03:12:23 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:23 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:23 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:23 --> URI Class Initialized
INFO - 2026-08-19 03:12:23 --> Router Class Initialized
INFO - 2026-08-19 03:12:23 --> Output Class Initialized
INFO - 2026-08-19 03:12:23 --> Security Class Initialized
DEBUG - 2026-08-19 03:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:23 --> CSRF cookie sent
INFO - 2026-08-19 03:12:23 --> Input Class Initialized
INFO - 2026-08-19 03:12:23 --> Language Class Initialized
INFO - 2026-08-19 03:12:23 --> Language Class Initialized
INFO - 2026-08-19 03:12:23 --> Config Class Initialized
INFO - 2026-08-19 03:12:23 --> Loader Class Initialized
INFO - 2026-08-19 03:12:23 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:23 --> Config Class Initialized
INFO - 2026-08-19 03:12:23 --> Hooks Class Initialized
INFO - 2026-08-19 03:12:23 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:23 --> Config Class Initialized
INFO - 2026-08-19 03:12:23 --> Hooks Class Initialized
INFO - 2026-08-19 03:12:23 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:23 --> Config Class Initialized
INFO - 2026-08-19 03:12:23 --> Hooks Class Initialized
INFO - 2026-08-19 03:12:23 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: email_helper
DEBUG - 2026-08-19 03:12:23 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:23 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:23 --> URI Class Initialized
DEBUG - 2026-08-19 03:12:23 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:23 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:23 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: ssp_helper
DEBUG - 2026-08-19 03:12:23 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:23 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:23 --> URI Class Initialized
INFO - 2026-08-19 03:12:23 --> URI Class Initialized
INFO - 2026-08-19 03:12:23 --> Router Class Initialized
INFO - 2026-08-19 03:12:23 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:23 --> Router Class Initialized
INFO - 2026-08-19 03:12:23 --> Output Class Initialized
INFO - 2026-08-19 03:12:23 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:23 --> Router Class Initialized
INFO - 2026-08-19 03:12:23 --> Output Class Initialized
INFO - 2026-08-19 03:12:23 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:23 --> Security Class Initialized
INFO - 2026-08-19 03:12:23 --> Security Class Initialized
INFO - 2026-08-19 03:12:23 --> Output Class Initialized
DEBUG - 2026-08-19 03:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:23 --> CSRF cookie sent
INFO - 2026-08-19 03:12:23 --> Input Class Initialized
DEBUG - 2026-08-19 03:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:23 --> CSRF cookie sent
INFO - 2026-08-19 03:12:23 --> Input Class Initialized
INFO - 2026-08-19 03:12:23 --> Language Class Initialized
INFO - 2026-08-19 03:12:23 --> Language Class Initialized
INFO - 2026-08-19 03:12:23 --> Security Class Initialized
INFO - 2026-08-19 03:12:23 --> Language Class Initialized
INFO - 2026-08-19 03:12:23 --> Config Class Initialized
INFO - 2026-08-19 03:12:23 --> Language Class Initialized
INFO - 2026-08-19 03:12:23 --> Config Class Initialized
DEBUG - 2026-08-19 03:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:23 --> CSRF cookie sent
INFO - 2026-08-19 03:12:23 --> Input Class Initialized
INFO - 2026-08-19 03:12:23 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:23 --> Language Class Initialized
INFO - 2026-08-19 03:12:23 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:23 --> Loader Class Initialized
INFO - 2026-08-19 03:12:23 --> Loader Class Initialized
INFO - 2026-08-19 03:12:23 --> Language Class Initialized
INFO - 2026-08-19 03:12:23 --> Config Class Initialized
INFO - 2026-08-19 03:12:23 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:23 --> Loader Class Initialized
INFO - 2026-08-19 03:12:23 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:23 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:23 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:23 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:23 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:23 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:23 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:23 --> Final output sent to browser
DEBUG - 2026-08-19 03:12:23 --> Total execution time: 3.5602
INFO - 2026-08-19 03:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:24 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:24 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:24 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:24 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:24 --> Email Class Initialized
INFO - 2026-08-19 03:12:24 --> Controller Class Initialized
ERROR - 2026-08-19 03:12:24 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:12:24 --> Config Class Initialized
INFO - 2026-08-19 03:12:24 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:24 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:24 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:24 --> URI Class Initialized
INFO - 2026-08-19 03:12:24 --> Router Class Initialized
INFO - 2026-08-19 03:12:24 --> Output Class Initialized
INFO - 2026-08-19 03:12:24 --> Security Class Initialized
DEBUG - 2026-08-19 03:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:24 --> CSRF cookie sent
INFO - 2026-08-19 03:12:24 --> Input Class Initialized
INFO - 2026-08-19 03:12:24 --> Language Class Initialized
INFO - 2026-08-19 03:12:24 --> Language Class Initialized
INFO - 2026-08-19 03:12:24 --> Config Class Initialized
INFO - 2026-08-19 03:12:24 --> Loader Class Initialized
INFO - 2026-08-19 03:12:24 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:24 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:24 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:24 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:24 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:24 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:24 --> Email Class Initialized
INFO - 2026-08-19 03:12:24 --> Controller Class Initialized
ERROR - 2026-08-19 03:12:24 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:12:24 --> Config Class Initialized
INFO - 2026-08-19 03:12:24 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:24 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:24 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:24 --> URI Class Initialized
INFO - 2026-08-19 03:12:24 --> Router Class Initialized
INFO - 2026-08-19 03:12:24 --> Output Class Initialized
INFO - 2026-08-19 03:12:24 --> Security Class Initialized
DEBUG - 2026-08-19 03:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:24 --> CSRF cookie sent
INFO - 2026-08-19 03:12:24 --> Input Class Initialized
INFO - 2026-08-19 03:12:24 --> Language Class Initialized
INFO - 2026-08-19 03:12:24 --> Language Class Initialized
INFO - 2026-08-19 03:12:24 --> Config Class Initialized
INFO - 2026-08-19 03:12:24 --> Loader Class Initialized
INFO - 2026-08-19 03:12:24 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:24 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:24 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:24 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:24 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:24 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:24 --> Email Class Initialized
INFO - 2026-08-19 03:12:24 --> Controller Class Initialized
ERROR - 2026-08-19 03:12:24 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:24 --> Upload Class Initialized
INFO - 2026-08-19 03:12:24 --> Config Class Initialized
INFO - 2026-08-19 03:12:24 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:24 --> Encryption Class Initialized
DEBUG - 2026-08-19 03:12:24 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:24 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:24 --> URI Class Initialized
INFO - 2026-08-19 03:12:24 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:24 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:24 --> Router Class Initialized
INFO - 2026-08-19 03:12:24 --> Output Class Initialized
INFO - 2026-08-19 03:12:24 --> Email Class Initialized
INFO - 2026-08-19 03:12:24 --> Controller Class Initialized
INFO - 2026-08-19 03:12:24 --> Security Class Initialized
ERROR - 2026-08-19 03:12:24 --> 404 Page Not Found: /index
DEBUG - 2026-08-19 03:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:24 --> CSRF cookie sent
INFO - 2026-08-19 03:12:24 --> Input Class Initialized
INFO - 2026-08-19 03:12:24 --> Language Class Initialized
INFO - 2026-08-19 03:12:24 --> Language Class Initialized
INFO - 2026-08-19 03:12:24 --> Config Class Initialized
INFO - 2026-08-19 03:12:24 --> Loader Class Initialized
INFO - 2026-08-19 03:12:24 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:24 --> Config Class Initialized
INFO - 2026-08-19 03:12:24 --> Hooks Class Initialized
INFO - 2026-08-19 03:12:24 --> Helper loaded: cpanel_helper
DEBUG - 2026-08-19 03:12:24 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:24 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:24 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:24 --> URI Class Initialized
INFO - 2026-08-19 03:12:24 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:24 --> Router Class Initialized
INFO - 2026-08-19 03:12:24 --> Output Class Initialized
INFO - 2026-08-19 03:12:24 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:24 --> Security Class Initialized
DEBUG - 2026-08-19 03:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:24 --> CSRF cookie sent
INFO - 2026-08-19 03:12:24 --> Input Class Initialized
INFO - 2026-08-19 03:12:24 --> Language Class Initialized
INFO - 2026-08-19 03:12:24 --> Language Class Initialized
INFO - 2026-08-19 03:12:24 --> Config Class Initialized
INFO - 2026-08-19 03:12:24 --> Loader Class Initialized
INFO - 2026-08-19 03:12:24 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:24 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:24 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:24 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:24 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:24 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:24 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:24 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:24 --> Email Class Initialized
INFO - 2026-08-19 03:12:24 --> Controller Class Initialized
ERROR - 2026-08-19 03:12:24 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:25 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:25 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:25 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:25 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:25 --> Email Class Initialized
INFO - 2026-08-19 03:12:25 --> Controller Class Initialized
ERROR - 2026-08-19 03:12:25 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:26 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:26 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:26 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:26 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:26 --> Email Class Initialized
INFO - 2026-08-19 03:12:26 --> Controller Class Initialized
DEBUG - 2026-08-19 03:12:26 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:12:26 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:12:26 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:12:26 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:12:26 --> Model "Common_model" initialized
INFO - 2026-08-19 03:12:26 --> Model "Order_model" initialized
INFO - 2026-08-19 03:12:26 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:12:26 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:12:26 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:12:26 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:12:26 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:12:26 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:12:27 --> Final output sent to browser
DEBUG - 2026-08-19 03:12:27 --> Total execution time: 2.1662
INFO - 2026-08-19 03:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:27 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:27 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:27 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:27 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:27 --> Email Class Initialized
INFO - 2026-08-19 03:12:27 --> Controller Class Initialized
DEBUG - 2026-08-19 03:12:27 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:12:27 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:12:27 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:12:27 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:12:27 --> Model "Common_model" initialized
INFO - 2026-08-19 03:12:27 --> Model "Order_model" initialized
INFO - 2026-08-19 03:12:27 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:12:27 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:12:27 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:12:27 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:12:27 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:12:27 --> Model "Orderlicense_model" initialized
DEBUG - 2026-08-19 03:12:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:12:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-08-19 03:12:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-08-19 03:12:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:12:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:12:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/cart_services.php
INFO - 2026-08-19 03:12:28 --> Final output sent to browser
DEBUG - 2026-08-19 03:12:28 --> Total execution time: 3.8977
INFO - 2026-08-19 03:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:28 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:28 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:28 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:28 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:28 --> Email Class Initialized
INFO - 2026-08-19 03:12:28 --> Controller Class Initialized
DEBUG - 2026-08-19 03:12:28 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:12:28 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:12:28 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:12:28 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:12:28 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:12:28 --> Config Class Initialized
INFO - 2026-08-19 03:12:28 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:28 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:28 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:28 --> URI Class Initialized
INFO - 2026-08-19 03:12:28 --> Router Class Initialized
INFO - 2026-08-19 03:12:28 --> Output Class Initialized
INFO - 2026-08-19 03:12:28 --> Security Class Initialized
DEBUG - 2026-08-19 03:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:28 --> CSRF cookie sent
INFO - 2026-08-19 03:12:28 --> Input Class Initialized
INFO - 2026-08-19 03:12:28 --> Language Class Initialized
INFO - 2026-08-19 03:12:28 --> Language Class Initialized
INFO - 2026-08-19 03:12:28 --> Config Class Initialized
INFO - 2026-08-19 03:12:28 --> Loader Class Initialized
INFO - 2026-08-19 03:12:28 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:28 --> Config Class Initialized
INFO - 2026-08-19 03:12:28 --> Hooks Class Initialized
INFO - 2026-08-19 03:12:28 --> Database Driver Class Initialized
DEBUG - 2026-08-19 03:12:28 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:28 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:28 --> URI Class Initialized
INFO - 2026-08-19 03:12:28 --> Router Class Initialized
INFO - 2026-08-19 03:12:28 --> Output Class Initialized
INFO - 2026-08-19 03:12:28 --> Config Class Initialized
INFO - 2026-08-19 03:12:28 --> Hooks Class Initialized
INFO - 2026-08-19 03:12:28 --> Config Class Initialized
INFO - 2026-08-19 03:12:28 --> Hooks Class Initialized
INFO - 2026-08-19 03:12:28 --> Security Class Initialized
INFO - 2026-08-19 03:12:28 --> Config Class Initialized
INFO - 2026-08-19 03:12:28 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:28 --> CSRF cookie sent
DEBUG - 2026-08-19 03:12:28 --> UTF-8 Support Enabled
DEBUG - 2026-08-19 03:12:28 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:28 --> Utf8 Class Initialized
DEBUG - 2026-08-19 03:12:28 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:28 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:28 --> URI Class Initialized
INFO - 2026-08-19 03:12:28 --> URI Class Initialized
INFO - 2026-08-19 03:12:28 --> Router Class Initialized
INFO - 2026-08-19 03:12:28 --> Router Class Initialized
INFO - 2026-08-19 03:12:28 --> Output Class Initialized
INFO - 2026-08-19 03:12:28 --> Output Class Initialized
INFO - 2026-08-19 03:12:28 --> Input Class Initialized
INFO - 2026-08-19 03:12:28 --> Language Class Initialized
INFO - 2026-08-19 03:12:28 --> Security Class Initialized
INFO - 2026-08-19 03:12:28 --> Language Class Initialized
INFO - 2026-08-19 03:12:28 --> Config Class Initialized
INFO - 2026-08-19 03:12:28 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:28 --> URI Class Initialized
INFO - 2026-08-19 03:12:28 --> Security Class Initialized
DEBUG - 2026-08-19 03:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:28 --> CSRF cookie sent
INFO - 2026-08-19 03:12:28 --> Input Class Initialized
INFO - 2026-08-19 03:12:28 --> Loader Class Initialized
INFO - 2026-08-19 03:12:28 --> Language Class Initialized
INFO - 2026-08-19 03:12:28 --> Router Class Initialized
INFO - 2026-08-19 03:12:28 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:28 --> Language Class Initialized
INFO - 2026-08-19 03:12:28 --> Config Class Initialized
INFO - 2026-08-19 03:12:28 --> Output Class Initialized
INFO - 2026-08-19 03:12:28 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:28 --> Security Class Initialized
DEBUG - 2026-08-19 03:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:28 --> CSRF cookie sent
INFO - 2026-08-19 03:12:28 --> Input Class Initialized
INFO - 2026-08-19 03:12:28 --> Language Class Initialized
INFO - 2026-08-19 03:12:28 --> Loader Class Initialized
DEBUG - 2026-08-19 03:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:28 --> CSRF cookie sent
INFO - 2026-08-19 03:12:28 --> Input Class Initialized
INFO - 2026-08-19 03:12:28 --> Language Class Initialized
INFO - 2026-08-19 03:12:28 --> Language Class Initialized
INFO - 2026-08-19 03:12:28 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:28 --> Config Class Initialized
INFO - 2026-08-19 03:12:28 --> Language Class Initialized
INFO - 2026-08-19 03:12:28 --> Config Class Initialized
INFO - 2026-08-19 03:12:28 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:28 --> Loader Class Initialized
INFO - 2026-08-19 03:12:28 --> Loader Class Initialized
INFO - 2026-08-19 03:12:28 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:28 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:28 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:28 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:28 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:28 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:28 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:29 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:29 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:29 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:29 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:29 --> Email Class Initialized
INFO - 2026-08-19 03:12:29 --> Controller Class Initialized
ERROR - 2026-08-19 03:12:29 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:12:29 --> Config Class Initialized
INFO - 2026-08-19 03:12:29 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:29 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:29 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:29 --> URI Class Initialized
INFO - 2026-08-19 03:12:29 --> Router Class Initialized
INFO - 2026-08-19 03:12:29 --> Output Class Initialized
INFO - 2026-08-19 03:12:29 --> Security Class Initialized
DEBUG - 2026-08-19 03:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:29 --> CSRF cookie sent
INFO - 2026-08-19 03:12:29 --> Input Class Initialized
INFO - 2026-08-19 03:12:29 --> Language Class Initialized
INFO - 2026-08-19 03:12:29 --> Language Class Initialized
INFO - 2026-08-19 03:12:29 --> Config Class Initialized
INFO - 2026-08-19 03:12:29 --> Loader Class Initialized
INFO - 2026-08-19 03:12:29 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:29 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:29 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:29 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:29 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:29 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:29 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:29 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:29 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:29 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:29 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:29 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:29 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:30 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:30 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:30 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:30 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:30 --> Email Class Initialized
INFO - 2026-08-19 03:12:30 --> Controller Class Initialized
ERROR - 2026-08-19 03:12:30 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:30 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:30 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:30 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:30 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:30 --> Email Class Initialized
INFO - 2026-08-19 03:12:30 --> Controller Class Initialized
INFO - 2026-08-19 03:12:30 --> Config Class Initialized
INFO - 2026-08-19 03:12:30 --> Hooks Class Initialized
ERROR - 2026-08-19 03:12:30 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:12:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-08-19 03:12:30 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:30 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:30 --> Upload Class Initialized
INFO - 2026-08-19 03:12:30 --> URI Class Initialized
DEBUG - 2026-08-19 03:12:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:30 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:30 --> Router Class Initialized
INFO - 2026-08-19 03:12:30 --> Output Class Initialized
INFO - 2026-08-19 03:12:30 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:30 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:30 --> Security Class Initialized
INFO - 2026-08-19 03:12:30 --> Config Class Initialized
INFO - 2026-08-19 03:12:30 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:30 --> CSRF cookie sent
INFO - 2026-08-19 03:12:30 --> Input Class Initialized
DEBUG - 2026-08-19 03:12:30 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:30 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:30 --> Language Class Initialized
INFO - 2026-08-19 03:12:30 --> URI Class Initialized
INFO - 2026-08-19 03:12:30 --> Language Class Initialized
INFO - 2026-08-19 03:12:30 --> Config Class Initialized
INFO - 2026-08-19 03:12:30 --> Email Class Initialized
INFO - 2026-08-19 03:12:30 --> Router Class Initialized
INFO - 2026-08-19 03:12:30 --> Controller Class Initialized
ERROR - 2026-08-19 03:12:30 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:12:30 --> Output Class Initialized
INFO - 2026-08-19 03:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:30 --> Security Class Initialized
INFO - 2026-08-19 03:12:30 --> Loader Class Initialized
DEBUG - 2026-08-19 03:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:30 --> CSRF cookie sent
INFO - 2026-08-19 03:12:30 --> Input Class Initialized
INFO - 2026-08-19 03:12:30 --> Upload Class Initialized
INFO - 2026-08-19 03:12:30 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:30 --> Language Class Initialized
INFO - 2026-08-19 03:12:30 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:30 --> Language Class Initialized
INFO - 2026-08-19 03:12:30 --> Config Class Initialized
INFO - 2026-08-19 03:12:30 --> Helper loaded: html_helper
DEBUG - 2026-08-19 03:12:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:30 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:30 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:30 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:30 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:30 --> Loader Class Initialized
INFO - 2026-08-19 03:12:30 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:30 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:30 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:30 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:30 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:30 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:30 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:30 --> Email Class Initialized
INFO - 2026-08-19 03:12:30 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:30 --> Controller Class Initialized
INFO - 2026-08-19 03:12:30 --> Helper loaded: directadmin_helper
ERROR - 2026-08-19 03:12:30 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:12:30 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:30 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:30 --> Config Class Initialized
INFO - 2026-08-19 03:12:30 --> Hooks Class Initialized
INFO - 2026-08-19 03:12:30 --> Upload Class Initialized
INFO - 2026-08-19 03:12:30 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:30 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:30 --> Helper loaded: entitlement_helper
DEBUG - 2026-08-19 03:12:30 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:30 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:30 --> Helper loaded: ssp_helper
DEBUG - 2026-08-19 03:12:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:30 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:30 --> URI Class Initialized
INFO - 2026-08-19 03:12:30 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:30 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:30 --> Router Class Initialized
INFO - 2026-08-19 03:12:30 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:30 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:30 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:30 --> Output Class Initialized
INFO - 2026-08-19 03:12:30 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:30 --> Email Class Initialized
INFO - 2026-08-19 03:12:30 --> Controller Class Initialized
INFO - 2026-08-19 03:12:30 --> Security Class Initialized
ERROR - 2026-08-19 03:12:30 --> 404 Page Not Found: /index
DEBUG - 2026-08-19 03:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:30 --> CSRF cookie sent
INFO - 2026-08-19 03:12:30 --> Input Class Initialized
INFO - 2026-08-19 03:12:30 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:30 --> Language Class Initialized
INFO - 2026-08-19 03:12:30 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:30 --> Language Class Initialized
INFO - 2026-08-19 03:12:30 --> Config Class Initialized
INFO - 2026-08-19 03:12:30 --> Loader Class Initialized
INFO - 2026-08-19 03:12:30 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:30 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:30 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:30 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:30 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:30 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:30 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:30 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:30 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:30 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:30 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:30 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:30 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:30 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:31 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:31 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:31 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:31 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:31 --> Email Class Initialized
INFO - 2026-08-19 03:12:31 --> Controller Class Initialized
DEBUG - 2026-08-19 03:12:31 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:12:31 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:12:31 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:12:31 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:12:31 --> Model "Common_model" initialized
INFO - 2026-08-19 03:12:31 --> Model "Order_model" initialized
INFO - 2026-08-19 03:12:31 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:12:31 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:12:31 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:12:31 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:12:31 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:12:31 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:12:31 --> Final output sent to browser
DEBUG - 2026-08-19 03:12:31 --> Total execution time: 2.0980
INFO - 2026-08-19 03:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:32 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:32 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:32 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:32 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:32 --> Email Class Initialized
INFO - 2026-08-19 03:12:32 --> Controller Class Initialized
DEBUG - 2026-08-19 03:12:32 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:12:32 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:12:32 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:12:32 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:12:32 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:33 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:33 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:33 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:33 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:33 --> Email Class Initialized
INFO - 2026-08-19 03:12:33 --> Controller Class Initialized
ERROR - 2026-08-19 03:12:33 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:33 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:33 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:33 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:33 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:33 --> Email Class Initialized
INFO - 2026-08-19 03:12:33 --> Controller Class Initialized
ERROR - 2026-08-19 03:12:33 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:12:41 --> Config Class Initialized
INFO - 2026-08-19 03:12:41 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:41 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:41 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:41 --> URI Class Initialized
INFO - 2026-08-19 03:12:41 --> Router Class Initialized
INFO - 2026-08-19 03:12:41 --> Output Class Initialized
INFO - 2026-08-19 03:12:41 --> Security Class Initialized
DEBUG - 2026-08-19 03:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:41 --> Input Class Initialized
INFO - 2026-08-19 03:12:41 --> Language Class Initialized
INFO - 2026-08-19 03:12:41 --> Language Class Initialized
INFO - 2026-08-19 03:12:41 --> Config Class Initialized
INFO - 2026-08-19 03:12:41 --> Loader Class Initialized
INFO - 2026-08-19 03:12:41 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:41 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:41 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:41 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:41 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:41 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:41 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:41 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:41 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:41 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:41 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:41 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:41 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:42 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:42 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:42 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:42 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:42 --> Email Class Initialized
INFO - 2026-08-19 03:12:42 --> Controller Class Initialized
DEBUG - 2026-08-19 03:12:42 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:12:42 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:12:42 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:12:42 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:12:42 --> Model "Common_model" initialized
INFO - 2026-08-19 03:12:42 --> Model "Order_model" initialized
INFO - 2026-08-19 03:12:42 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:12:42 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:12:42 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:12:43 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:12:43 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:12:43 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:12:44 --> Final output sent to browser
DEBUG - 2026-08-19 03:12:44 --> Total execution time: 3.0615
INFO - 2026-08-19 03:12:44 --> Config Class Initialized
INFO - 2026-08-19 03:12:44 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:44 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:44 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:44 --> URI Class Initialized
INFO - 2026-08-19 03:12:44 --> Router Class Initialized
INFO - 2026-08-19 03:12:44 --> Output Class Initialized
INFO - 2026-08-19 03:12:44 --> Security Class Initialized
DEBUG - 2026-08-19 03:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:44 --> Input Class Initialized
INFO - 2026-08-19 03:12:44 --> Language Class Initialized
INFO - 2026-08-19 03:12:44 --> Language Class Initialized
INFO - 2026-08-19 03:12:44 --> Config Class Initialized
INFO - 2026-08-19 03:12:44 --> Loader Class Initialized
INFO - 2026-08-19 03:12:44 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:44 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:44 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:44 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:44 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:44 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:44 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:44 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:44 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:44 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:44 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:44 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:44 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:45 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:45 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:45 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:45 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:45 --> Email Class Initialized
INFO - 2026-08-19 03:12:45 --> Controller Class Initialized
DEBUG - 2026-08-19 03:12:45 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:12:45 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:12:45 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:12:45 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:12:45 --> Model "Common_model" initialized
INFO - 2026-08-19 03:12:45 --> Model "Order_model" initialized
INFO - 2026-08-19 03:12:45 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:12:45 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:12:45 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:12:45 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:12:45 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:12:45 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:12:47 --> Final output sent to browser
DEBUG - 2026-08-19 03:12:47 --> Total execution time: 2.9548
INFO - 2026-08-19 03:12:47 --> Config Class Initialized
INFO - 2026-08-19 03:12:47 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:47 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:47 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:47 --> URI Class Initialized
INFO - 2026-08-19 03:12:47 --> Router Class Initialized
INFO - 2026-08-19 03:12:47 --> Output Class Initialized
INFO - 2026-08-19 03:12:47 --> Security Class Initialized
DEBUG - 2026-08-19 03:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:47 --> CSRF cookie sent
INFO - 2026-08-19 03:12:47 --> Input Class Initialized
INFO - 2026-08-19 03:12:47 --> Language Class Initialized
INFO - 2026-08-19 03:12:47 --> Language Class Initialized
INFO - 2026-08-19 03:12:47 --> Config Class Initialized
INFO - 2026-08-19 03:12:47 --> Loader Class Initialized
INFO - 2026-08-19 03:12:47 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:47 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:47 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:47 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:47 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:47 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:47 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:47 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:47 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:47 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:47 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:47 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:47 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:48 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:48 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:48 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:48 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:48 --> Email Class Initialized
INFO - 2026-08-19 03:12:48 --> Controller Class Initialized
DEBUG - 2026-08-19 03:12:48 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:12:48 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:12:48 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:12:48 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:12:48 --> Model "Common_model" initialized
INFO - 2026-08-19 03:12:48 --> Model "Order_model" initialized
INFO - 2026-08-19 03:12:48 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:12:48 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:12:48 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:12:48 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:12:48 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:12:48 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:12:51 --> Config Class Initialized
INFO - 2026-08-19 03:12:51 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:51 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:51 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:51 --> URI Class Initialized
INFO - 2026-08-19 03:12:51 --> Router Class Initialized
INFO - 2026-08-19 03:12:51 --> Output Class Initialized
INFO - 2026-08-19 03:12:51 --> Security Class Initialized
DEBUG - 2026-08-19 03:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:51 --> CSRF cookie sent
INFO - 2026-08-19 03:12:51 --> Input Class Initialized
INFO - 2026-08-19 03:12:51 --> Language Class Initialized
INFO - 2026-08-19 03:12:51 --> Language Class Initialized
INFO - 2026-08-19 03:12:51 --> Config Class Initialized
INFO - 2026-08-19 03:12:51 --> Loader Class Initialized
INFO - 2026-08-19 03:12:51 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:51 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:51 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:51 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:51 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:51 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:51 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:51 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:51 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:51 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:51 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:51 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:51 --> Database Driver Class Initialized
DEBUG - 2026-08-19 03:12:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:12:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-08-19 03:12:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-08-19 03:12:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:12:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:12:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/view_card.php
INFO - 2026-08-19 03:12:52 --> Final output sent to browser
DEBUG - 2026-08-19 03:12:52 --> Total execution time: 5.0993
INFO - 2026-08-19 03:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:53 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:53 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:53 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:53 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:53 --> Email Class Initialized
INFO - 2026-08-19 03:12:53 --> Controller Class Initialized
DEBUG - 2026-08-19 03:12:53 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:12:53 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:12:53 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:12:53 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:12:53 --> Model "Common_model" initialized
INFO - 2026-08-19 03:12:53 --> Model "Order_model" initialized
INFO - 2026-08-19 03:12:53 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:12:53 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:12:53 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:12:53 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:12:53 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:12:53 --> Model "Orderlicense_model" initialized
DEBUG - 2026-08-19 03:12:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:12:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-08-19 03:12:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-08-19 03:12:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:12:57 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:12:57 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/view_card.php
INFO - 2026-08-19 03:12:57 --> Final output sent to browser
DEBUG - 2026-08-19 03:12:57 --> Total execution time: 5.3579
INFO - 2026-08-19 03:12:57 --> Config Class Initialized
INFO - 2026-08-19 03:12:57 --> Config Class Initialized
INFO - 2026-08-19 03:12:57 --> Config Class Initialized
INFO - 2026-08-19 03:12:57 --> Config Class Initialized
INFO - 2026-08-19 03:12:57 --> Hooks Class Initialized
INFO - 2026-08-19 03:12:57 --> Hooks Class Initialized
INFO - 2026-08-19 03:12:57 --> Hooks Class Initialized
INFO - 2026-08-19 03:12:57 --> Config Class Initialized
INFO - 2026-08-19 03:12:57 --> Hooks Class Initialized
INFO - 2026-08-19 03:12:57 --> Config Class Initialized
INFO - 2026-08-19 03:12:57 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:57 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:57 --> Utf8 Class Initialized
DEBUG - 2026-08-19 03:12:57 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:57 --> Utf8 Class Initialized
DEBUG - 2026-08-19 03:12:57 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:57 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:57 --> URI Class Initialized
INFO - 2026-08-19 03:12:57 --> URI Class Initialized
INFO - 2026-08-19 03:12:57 --> URI Class Initialized
INFO - 2026-08-19 03:12:57 --> Router Class Initialized
INFO - 2026-08-19 03:12:57 --> Router Class Initialized
INFO - 2026-08-19 03:12:57 --> Router Class Initialized
INFO - 2026-08-19 03:12:57 --> Output Class Initialized
INFO - 2026-08-19 03:12:57 --> Output Class Initialized
INFO - 2026-08-19 03:12:57 --> Output Class Initialized
INFO - 2026-08-19 03:12:57 --> Security Class Initialized
INFO - 2026-08-19 03:12:57 --> Security Class Initialized
INFO - 2026-08-19 03:12:57 --> Security Class Initialized
DEBUG - 2026-08-19 03:12:57 --> UTF-8 Support Enabled
DEBUG - 2026-08-19 03:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:57 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:12:57 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:57 --> Utf8 Class Initialized
DEBUG - 2026-08-19 03:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:57 --> CSRF cookie sent
INFO - 2026-08-19 03:12:57 --> Input Class Initialized
DEBUG - 2026-08-19 03:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:57 --> CSRF cookie sent
INFO - 2026-08-19 03:12:57 --> Input Class Initialized
INFO - 2026-08-19 03:12:57 --> URI Class Initialized
INFO - 2026-08-19 03:12:57 --> Language Class Initialized
INFO - 2026-08-19 03:12:57 --> Language Class Initialized
INFO - 2026-08-19 03:12:57 --> Utf8 Class Initialized
DEBUG - 2026-08-19 03:12:57 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:57 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:57 --> Language Class Initialized
INFO - 2026-08-19 03:12:57 --> Language Class Initialized
INFO - 2026-08-19 03:12:57 --> Config Class Initialized
INFO - 2026-08-19 03:12:57 --> Config Class Initialized
INFO - 2026-08-19 03:12:57 --> URI Class Initialized
INFO - 2026-08-19 03:12:57 --> URI Class Initialized
INFO - 2026-08-19 03:12:57 --> Router Class Initialized
INFO - 2026-08-19 03:12:57 --> Output Class Initialized
INFO - 2026-08-19 03:12:57 --> Router Class Initialized
INFO - 2026-08-19 03:12:57 --> Router Class Initialized
INFO - 2026-08-19 03:12:57 --> Loader Class Initialized
INFO - 2026-08-19 03:12:57 --> Loader Class Initialized
INFO - 2026-08-19 03:12:57 --> Security Class Initialized
INFO - 2026-08-19 03:12:57 --> Output Class Initialized
INFO - 2026-08-19 03:12:57 --> Output Class Initialized
INFO - 2026-08-19 03:12:57 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: url_helper
DEBUG - 2026-08-19 03:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:57 --> CSRF cookie sent
INFO - 2026-08-19 03:12:57 --> Input Class Initialized
INFO - 2026-08-19 03:12:57 --> Security Class Initialized
INFO - 2026-08-19 03:12:57 --> Security Class Initialized
INFO - 2026-08-19 03:12:57 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:57 --> Language Class Initialized
INFO - 2026-08-19 03:12:57 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: html_helper
DEBUG - 2026-08-19 03:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:57 --> CSRF cookie sent
INFO - 2026-08-19 03:12:57 --> Input Class Initialized
DEBUG - 2026-08-19 03:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:57 --> CSRF cookie sent
INFO - 2026-08-19 03:12:57 --> Input Class Initialized
INFO - 2026-08-19 03:12:57 --> Language Class Initialized
INFO - 2026-08-19 03:12:57 --> Language Class Initialized
INFO - 2026-08-19 03:12:57 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:57 --> CSRF cookie sent
INFO - 2026-08-19 03:12:57 --> Config Class Initialized
INFO - 2026-08-19 03:12:57 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:57 --> Language Class Initialized
INFO - 2026-08-19 03:12:57 --> Config Class Initialized
INFO - 2026-08-19 03:12:57 --> Language Class Initialized
INFO - 2026-08-19 03:12:57 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:57 --> Language Class Initialized
INFO - 2026-08-19 03:12:57 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:57 --> Config Class Initialized
INFO - 2026-08-19 03:12:57 --> Loader Class Initialized
INFO - 2026-08-19 03:12:57 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:57 --> Loader Class Initialized
INFO - 2026-08-19 03:12:57 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:57 --> Loader Class Initialized
INFO - 2026-08-19 03:12:57 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:57 --> Input Class Initialized
INFO - 2026-08-19 03:12:57 --> Language Class Initialized
INFO - 2026-08-19 03:12:57 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:57 --> Language Class Initialized
INFO - 2026-08-19 03:12:57 --> Config Class Initialized
INFO - 2026-08-19 03:12:57 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:57 --> Loader Class Initialized
INFO - 2026-08-19 03:12:57 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:57 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:57 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:57 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:57 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:57 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:57 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:57 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:57 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:57 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:57 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:59 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:59 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:59 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:59 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:59 --> Email Class Initialized
INFO - 2026-08-19 03:12:59 --> Controller Class Initialized
ERROR - 2026-08-19 03:12:59 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:59 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:59 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:59 --> Config Class Initialized
INFO - 2026-08-19 03:12:59 --> Hooks Class Initialized
INFO - 2026-08-19 03:12:59 --> Form Validation Class Initialized
DEBUG - 2026-08-19 03:12:59 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:59 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:59 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:59 --> URI Class Initialized
INFO - 2026-08-19 03:12:59 --> Email Class Initialized
INFO - 2026-08-19 03:12:59 --> Router Class Initialized
INFO - 2026-08-19 03:12:59 --> Controller Class Initialized
ERROR - 2026-08-19 03:12:59 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:59 --> Output Class Initialized
INFO - 2026-08-19 03:12:59 --> Upload Class Initialized
INFO - 2026-08-19 03:12:59 --> Security Class Initialized
DEBUG - 2026-08-19 03:12:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:59 --> Encryption Class Initialized
DEBUG - 2026-08-19 03:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:59 --> CSRF cookie sent
INFO - 2026-08-19 03:12:59 --> Input Class Initialized
INFO - 2026-08-19 03:12:59 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:59 --> Language Class Initialized
INFO - 2026-08-19 03:12:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:59 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:59 --> Language Class Initialized
INFO - 2026-08-19 03:12:59 --> Config Class Initialized
INFO - 2026-08-19 03:12:59 --> Email Class Initialized
INFO - 2026-08-19 03:12:59 --> Controller Class Initialized
ERROR - 2026-08-19 03:12:59 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:12:59 --> Config Class Initialized
INFO - 2026-08-19 03:12:59 --> Hooks Class Initialized
INFO - 2026-08-19 03:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:59 --> Loader Class Initialized
INFO - 2026-08-19 03:12:59 --> Helper loaded: url_helper
DEBUG - 2026-08-19 03:12:59 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:59 --> Utf8 Class Initialized
INFO - 2026-08-19 03:12:59 --> Upload Class Initialized
INFO - 2026-08-19 03:12:59 --> URI Class Initialized
INFO - 2026-08-19 03:12:59 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:59 --> Helper loaded: html_helper
DEBUG - 2026-08-19 03:12:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:59 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:59 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:59 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:59 --> Router Class Initialized
INFO - 2026-08-19 03:12:59 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:59 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:59 --> Output Class Initialized
INFO - 2026-08-19 03:12:59 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:59 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:59 --> Security Class Initialized
INFO - 2026-08-19 03:12:59 --> Config Class Initialized
INFO - 2026-08-19 03:12:59 --> Hooks Class Initialized
INFO - 2026-08-19 03:12:59 --> Helper loaded: cpanel_helper
DEBUG - 2026-08-19 03:12:59 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:12:59 --> Utf8 Class Initialized
DEBUG - 2026-08-19 03:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:59 --> CSRF cookie sent
INFO - 2026-08-19 03:12:59 --> Input Class Initialized
INFO - 2026-08-19 03:12:59 --> Language Class Initialized
INFO - 2026-08-19 03:12:59 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:59 --> URI Class Initialized
INFO - 2026-08-19 03:12:59 --> Language Class Initialized
INFO - 2026-08-19 03:12:59 --> Config Class Initialized
INFO - 2026-08-19 03:12:59 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:59 --> Router Class Initialized
INFO - 2026-08-19 03:12:59 --> Email Class Initialized
INFO - 2026-08-19 03:12:59 --> Controller Class Initialized
ERROR - 2026-08-19 03:12:59 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:12:59 --> Output Class Initialized
INFO - 2026-08-19 03:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:59 --> Security Class Initialized
INFO - 2026-08-19 03:12:59 --> Loader Class Initialized
INFO - 2026-08-19 03:12:59 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:59 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:12:59 --> CSRF cookie sent
INFO - 2026-08-19 03:12:59 --> Input Class Initialized
INFO - 2026-08-19 03:12:59 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:59 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:59 --> Language Class Initialized
DEBUG - 2026-08-19 03:12:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:59 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:59 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:59 --> Language Class Initialized
INFO - 2026-08-19 03:12:59 --> Config Class Initialized
INFO - 2026-08-19 03:12:59 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:59 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:59 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:59 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:59 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:59 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:59 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:59 --> Loader Class Initialized
INFO - 2026-08-19 03:12:59 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:59 --> Helper loaded: url_helper
INFO - 2026-08-19 03:12:59 --> Email Class Initialized
INFO - 2026-08-19 03:12:59 --> Controller Class Initialized
ERROR - 2026-08-19 03:12:59 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:12:59 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:59 --> Helper loaded: form_helper
INFO - 2026-08-19 03:12:59 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:59 --> Helper loaded: html_helper
INFO - 2026-08-19 03:12:59 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:59 --> Helper loaded: file_helper
INFO - 2026-08-19 03:12:59 --> Helper loaded: email_helper
INFO - 2026-08-19 03:12:59 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:59 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:59 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:12:59 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:12:59 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:12:59 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:12:59 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:12:59 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:59 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:12:59 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:12:59 --> Upload Class Initialized
DEBUG - 2026-08-19 03:12:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:12:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:12:59 --> Encryption Class Initialized
INFO - 2026-08-19 03:12:59 --> Form Validation Class Initialized
INFO - 2026-08-19 03:12:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:12:59 --> Pagination Class Initialized
INFO - 2026-08-19 03:12:59 --> Database Driver Class Initialized
INFO - 2026-08-19 03:12:59 --> Email Class Initialized
INFO - 2026-08-19 03:12:59 --> Controller Class Initialized
ERROR - 2026-08-19 03:12:59 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:13:01 --> Upload Class Initialized
DEBUG - 2026-08-19 03:13:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:13:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:13:01 --> Encryption Class Initialized
INFO - 2026-08-19 03:13:01 --> Form Validation Class Initialized
INFO - 2026-08-19 03:13:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:13:01 --> Pagination Class Initialized
INFO - 2026-08-19 03:13:01 --> Email Class Initialized
INFO - 2026-08-19 03:13:01 --> Controller Class Initialized
DEBUG - 2026-08-19 03:13:01 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:13:01 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:13:01 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:13:01 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:13:01 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:13:01 --> Upload Class Initialized
DEBUG - 2026-08-19 03:13:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:13:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:13:01 --> Encryption Class Initialized
INFO - 2026-08-19 03:13:01 --> Form Validation Class Initialized
INFO - 2026-08-19 03:13:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:13:01 --> Pagination Class Initialized
INFO - 2026-08-19 03:13:01 --> Email Class Initialized
INFO - 2026-08-19 03:13:01 --> Controller Class Initialized
ERROR - 2026-08-19 03:13:01 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:13:01 --> Upload Class Initialized
DEBUG - 2026-08-19 03:13:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:13:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:13:01 --> Encryption Class Initialized
INFO - 2026-08-19 03:13:01 --> Form Validation Class Initialized
INFO - 2026-08-19 03:13:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:13:01 --> Pagination Class Initialized
INFO - 2026-08-19 03:13:01 --> Email Class Initialized
INFO - 2026-08-19 03:13:01 --> Controller Class Initialized
DEBUG - 2026-08-19 03:13:01 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:13:01 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:13:01 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:13:01 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:13:01 --> Model "Common_model" initialized
INFO - 2026-08-19 03:13:01 --> Model "Order_model" initialized
INFO - 2026-08-19 03:13:01 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:13:01 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:13:01 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:13:01 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:13:01 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:13:01 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:13:02 --> Final output sent to browser
DEBUG - 2026-08-19 03:13:02 --> Total execution time: 2.9842
INFO - 2026-08-19 03:13:08 --> Config Class Initialized
INFO - 2026-08-19 03:13:08 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:13:08 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:13:08 --> Utf8 Class Initialized
INFO - 2026-08-19 03:13:08 --> URI Class Initialized
INFO - 2026-08-19 03:13:08 --> Router Class Initialized
INFO - 2026-08-19 03:13:08 --> Output Class Initialized
INFO - 2026-08-19 03:13:08 --> Security Class Initialized
DEBUG - 2026-08-19 03:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:13:08 --> CSRF cookie sent
INFO - 2026-08-19 03:13:08 --> Input Class Initialized
INFO - 2026-08-19 03:13:08 --> Language Class Initialized
INFO - 2026-08-19 03:13:08 --> Language Class Initialized
INFO - 2026-08-19 03:13:08 --> Config Class Initialized
INFO - 2026-08-19 03:13:08 --> Loader Class Initialized
INFO - 2026-08-19 03:13:08 --> Helper loaded: url_helper
INFO - 2026-08-19 03:13:08 --> Helper loaded: form_helper
INFO - 2026-08-19 03:13:08 --> Helper loaded: html_helper
INFO - 2026-08-19 03:13:08 --> Helper loaded: file_helper
INFO - 2026-08-19 03:13:08 --> Helper loaded: email_helper
INFO - 2026-08-19 03:13:08 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:13:08 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:13:08 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:13:08 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:13:08 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:13:08 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:13:08 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:13:08 --> Database Driver Class Initialized
INFO - 2026-08-19 03:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:13:09 --> Upload Class Initialized
DEBUG - 2026-08-19 03:13:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:13:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:13:09 --> Encryption Class Initialized
INFO - 2026-08-19 03:13:09 --> Form Validation Class Initialized
INFO - 2026-08-19 03:13:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:13:09 --> Pagination Class Initialized
INFO - 2026-08-19 03:13:09 --> Email Class Initialized
INFO - 2026-08-19 03:13:09 --> Controller Class Initialized
DEBUG - 2026-08-19 03:13:09 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:13:09 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:13:09 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:13:09 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:13:09 --> Model "Common_model" initialized
INFO - 2026-08-19 03:13:09 --> Model "Order_model" initialized
INFO - 2026-08-19 03:13:09 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:13:09 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:13:09 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:13:09 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:13:09 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:13:09 --> Model "Orderlicense_model" initialized
DEBUG - 2026-08-19 03:13:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:13:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-08-19 03:13:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-08-19 03:13:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:13:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:13:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/cart_services.php
INFO - 2026-08-19 03:13:11 --> Final output sent to browser
DEBUG - 2026-08-19 03:13:11 --> Total execution time: 3.7714
INFO - 2026-08-19 03:13:11 --> Config Class Initialized
INFO - 2026-08-19 03:13:11 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:13:11 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:13:11 --> Utf8 Class Initialized
INFO - 2026-08-19 03:13:11 --> URI Class Initialized
INFO - 2026-08-19 03:13:11 --> Router Class Initialized
INFO - 2026-08-19 03:13:11 --> Output Class Initialized
INFO - 2026-08-19 03:13:11 --> Security Class Initialized
DEBUG - 2026-08-19 03:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:13:11 --> CSRF cookie sent
INFO - 2026-08-19 03:13:11 --> Input Class Initialized
INFO - 2026-08-19 03:13:11 --> Language Class Initialized
INFO - 2026-08-19 03:13:11 --> Language Class Initialized
INFO - 2026-08-19 03:13:11 --> Config Class Initialized
INFO - 2026-08-19 03:13:11 --> Loader Class Initialized
INFO - 2026-08-19 03:13:11 --> Helper loaded: url_helper
INFO - 2026-08-19 03:13:11 --> Helper loaded: form_helper
INFO - 2026-08-19 03:13:11 --> Helper loaded: html_helper
INFO - 2026-08-19 03:13:11 --> Helper loaded: file_helper
INFO - 2026-08-19 03:13:11 --> Helper loaded: email_helper
INFO - 2026-08-19 03:13:11 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:13:11 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:13:12 --> Database Driver Class Initialized
INFO - 2026-08-19 03:13:12 --> Config Class Initialized
INFO - 2026-08-19 03:13:12 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:13:12 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:13:12 --> Utf8 Class Initialized
INFO - 2026-08-19 03:13:12 --> URI Class Initialized
INFO - 2026-08-19 03:13:12 --> Router Class Initialized
INFO - 2026-08-19 03:13:12 --> Output Class Initialized
INFO - 2026-08-19 03:13:12 --> Security Class Initialized
DEBUG - 2026-08-19 03:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:13:12 --> CSRF cookie sent
INFO - 2026-08-19 03:13:12 --> Input Class Initialized
INFO - 2026-08-19 03:13:12 --> Language Class Initialized
INFO - 2026-08-19 03:13:12 --> Language Class Initialized
INFO - 2026-08-19 03:13:12 --> Config Class Initialized
INFO - 2026-08-19 03:13:12 --> Config Class Initialized
INFO - 2026-08-19 03:13:12 --> Hooks Class Initialized
INFO - 2026-08-19 03:13:12 --> Config Class Initialized
INFO - 2026-08-19 03:13:12 --> Hooks Class Initialized
INFO - 2026-08-19 03:13:12 --> Loader Class Initialized
INFO - 2026-08-19 03:13:12 --> Helper loaded: url_helper
DEBUG - 2026-08-19 03:13:12 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:13:12 --> Utf8 Class Initialized
INFO - 2026-08-19 03:13:12 --> Helper loaded: form_helper
INFO - 2026-08-19 03:13:12 --> URI Class Initialized
INFO - 2026-08-19 03:13:12 --> Helper loaded: html_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: file_helper
DEBUG - 2026-08-19 03:13:12 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:13:12 --> Utf8 Class Initialized
INFO - 2026-08-19 03:13:12 --> Helper loaded: email_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:13:12 --> URI Class Initialized
INFO - 2026-08-19 03:13:12 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:13:12 --> Router Class Initialized
INFO - 2026-08-19 03:13:12 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:13:12 --> Config Class Initialized
INFO - 2026-08-19 03:13:12 --> Hooks Class Initialized
INFO - 2026-08-19 03:13:12 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:13:12 --> Router Class Initialized
DEBUG - 2026-08-19 03:13:12 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:13:12 --> Utf8 Class Initialized
INFO - 2026-08-19 03:13:12 --> Output Class Initialized
INFO - 2026-08-19 03:13:12 --> Config Class Initialized
INFO - 2026-08-19 03:13:12 --> Hooks Class Initialized
INFO - 2026-08-19 03:13:12 --> Output Class Initialized
INFO - 2026-08-19 03:13:12 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:13:12 --> Security Class Initialized
DEBUG - 2026-08-19 03:13:12 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:13:12 --> Utf8 Class Initialized
INFO - 2026-08-19 03:13:12 --> URI Class Initialized
INFO - 2026-08-19 03:13:12 --> Security Class Initialized
INFO - 2026-08-19 03:13:12 --> URI Class Initialized
INFO - 2026-08-19 03:13:12 --> Database Driver Class Initialized
INFO - 2026-08-19 03:13:12 --> Router Class Initialized
DEBUG - 2026-08-19 03:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:13:12 --> CSRF cookie sent
INFO - 2026-08-19 03:13:12 --> Input Class Initialized
INFO - 2026-08-19 03:13:12 --> Language Class Initialized
DEBUG - 2026-08-19 03:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:13:12 --> CSRF cookie sent
INFO - 2026-08-19 03:13:12 --> Input Class Initialized
INFO - 2026-08-19 03:13:12 --> Output Class Initialized
INFO - 2026-08-19 03:13:12 --> Language Class Initialized
INFO - 2026-08-19 03:13:12 --> Language Class Initialized
INFO - 2026-08-19 03:13:12 --> Security Class Initialized
INFO - 2026-08-19 03:13:12 --> Config Class Initialized
INFO - 2026-08-19 03:13:12 --> Language Class Initialized
INFO - 2026-08-19 03:13:12 --> Config Class Initialized
DEBUG - 2026-08-19 03:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:13:12 --> CSRF cookie sent
INFO - 2026-08-19 03:13:12 --> Input Class Initialized
INFO - 2026-08-19 03:13:12 --> Language Class Initialized
INFO - 2026-08-19 03:13:12 --> Language Class Initialized
INFO - 2026-08-19 03:13:12 --> Config Class Initialized
INFO - 2026-08-19 03:13:12 --> Loader Class Initialized
INFO - 2026-08-19 03:13:12 --> Loader Class Initialized
INFO - 2026-08-19 03:13:12 --> Loader Class Initialized
INFO - 2026-08-19 03:13:12 --> Router Class Initialized
INFO - 2026-08-19 03:13:12 --> Helper loaded: url_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: url_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: form_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: html_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: form_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: file_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: email_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: html_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: file_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: email_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:13:12 --> Output Class Initialized
INFO - 2026-08-19 03:13:12 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:13:12 --> Security Class Initialized
INFO - 2026-08-19 03:13:12 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: plesk_helper
DEBUG - 2026-08-19 03:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:13:12 --> CSRF cookie sent
INFO - 2026-08-19 03:13:12 --> Input Class Initialized
INFO - 2026-08-19 03:13:12 --> Language Class Initialized
INFO - 2026-08-19 03:13:12 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:13:12 --> Language Class Initialized
INFO - 2026-08-19 03:13:12 --> Config Class Initialized
INFO - 2026-08-19 03:13:12 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: url_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: form_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: html_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: file_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: email_helper
INFO - 2026-08-19 03:13:12 --> Database Driver Class Initialized
INFO - 2026-08-19 03:13:12 --> Loader Class Initialized
INFO - 2026-08-19 03:13:12 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: url_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: form_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: html_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: file_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: email_helper
INFO - 2026-08-19 03:13:12 --> Database Driver Class Initialized
INFO - 2026-08-19 03:13:12 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:13:12 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:13:12 --> Database Driver Class Initialized
INFO - 2026-08-19 03:13:12 --> Database Driver Class Initialized
INFO - 2026-08-19 03:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:13:13 --> Upload Class Initialized
DEBUG - 2026-08-19 03:13:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:13:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:13:13 --> Encryption Class Initialized
INFO - 2026-08-19 03:13:13 --> Form Validation Class Initialized
INFO - 2026-08-19 03:13:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:13:13 --> Pagination Class Initialized
INFO - 2026-08-19 03:13:13 --> Email Class Initialized
INFO - 2026-08-19 03:13:13 --> Controller Class Initialized
ERROR - 2026-08-19 03:13:13 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:13:13 --> Upload Class Initialized
DEBUG - 2026-08-19 03:13:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:13:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:13:13 --> Encryption Class Initialized
INFO - 2026-08-19 03:13:13 --> Form Validation Class Initialized
INFO - 2026-08-19 03:13:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:13:13 --> Pagination Class Initialized
INFO - 2026-08-19 03:13:13 --> Email Class Initialized
INFO - 2026-08-19 03:13:13 --> Controller Class Initialized
ERROR - 2026-08-19 03:13:13 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:13:13 --> Config Class Initialized
INFO - 2026-08-19 03:13:13 --> Hooks Class Initialized
INFO - 2026-08-19 03:13:13 --> Upload Class Initialized
DEBUG - 2026-08-19 03:13:13 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:13:13 --> Utf8 Class Initialized
INFO - 2026-08-19 03:13:13 --> URI Class Initialized
DEBUG - 2026-08-19 03:13:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:13:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:13:13 --> Encryption Class Initialized
INFO - 2026-08-19 03:13:13 --> Router Class Initialized
INFO - 2026-08-19 03:13:13 --> Form Validation Class Initialized
INFO - 2026-08-19 03:13:13 --> Output Class Initialized
INFO - 2026-08-19 03:13:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:13:13 --> Pagination Class Initialized
INFO - 2026-08-19 03:13:13 --> Security Class Initialized
DEBUG - 2026-08-19 03:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:13:13 --> CSRF cookie sent
INFO - 2026-08-19 03:13:13 --> Input Class Initialized
INFO - 2026-08-19 03:13:13 --> Language Class Initialized
INFO - 2026-08-19 03:13:13 --> Config Class Initialized
INFO - 2026-08-19 03:13:13 --> Hooks Class Initialized
INFO - 2026-08-19 03:13:13 --> Email Class Initialized
INFO - 2026-08-19 03:13:13 --> Controller Class Initialized
INFO - 2026-08-19 03:13:13 --> Language Class Initialized
INFO - 2026-08-19 03:13:13 --> Config Class Initialized
ERROR - 2026-08-19 03:13:13 --> 404 Page Not Found: /index
DEBUG - 2026-08-19 03:13:13 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:13:13 --> Utf8 Class Initialized
INFO - 2026-08-19 03:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:13:13 --> URI Class Initialized
INFO - 2026-08-19 03:13:13 --> Loader Class Initialized
INFO - 2026-08-19 03:13:13 --> Upload Class Initialized
INFO - 2026-08-19 03:13:13 --> Helper loaded: url_helper
INFO - 2026-08-19 03:13:13 --> Router Class Initialized
INFO - 2026-08-19 03:13:13 --> Helper loaded: form_helper
DEBUG - 2026-08-19 03:13:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:13:13 --> Helper loaded: html_helper
INFO - 2026-08-19 03:13:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:13:13 --> Encryption Class Initialized
INFO - 2026-08-19 03:13:13 --> Helper loaded: file_helper
INFO - 2026-08-19 03:13:13 --> Helper loaded: email_helper
INFO - 2026-08-19 03:13:13 --> Output Class Initialized
INFO - 2026-08-19 03:13:13 --> Security Class Initialized
INFO - 2026-08-19 03:13:13 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:13:13 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:13:13 --> Form Validation Class Initialized
DEBUG - 2026-08-19 03:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:13:13 --> CSRF cookie sent
INFO - 2026-08-19 03:13:13 --> Input Class Initialized
INFO - 2026-08-19 03:13:13 --> Language Class Initialized
INFO - 2026-08-19 03:13:13 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:13:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:13:13 --> Pagination Class Initialized
INFO - 2026-08-19 03:13:13 --> Language Class Initialized
INFO - 2026-08-19 03:13:13 --> Config Class Initialized
INFO - 2026-08-19 03:13:13 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:13:13 --> Config Class Initialized
INFO - 2026-08-19 03:13:13 --> Hooks Class Initialized
INFO - 2026-08-19 03:13:13 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:13:13 --> Loader Class Initialized
DEBUG - 2026-08-19 03:13:13 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:13:13 --> Utf8 Class Initialized
INFO - 2026-08-19 03:13:13 --> Helper loaded: url_helper
INFO - 2026-08-19 03:13:13 --> URI Class Initialized
INFO - 2026-08-19 03:13:13 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:13:13 --> Helper loaded: form_helper
INFO - 2026-08-19 03:13:13 --> Email Class Initialized
INFO - 2026-08-19 03:13:13 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:13:13 --> Controller Class Initialized
INFO - 2026-08-19 03:13:13 --> Helper loaded: html_helper
ERROR - 2026-08-19 03:13:13 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:13:13 --> Helper loaded: file_helper
INFO - 2026-08-19 03:13:13 --> Helper loaded: email_helper
INFO - 2026-08-19 03:13:13 --> Router Class Initialized
INFO - 2026-08-19 03:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:13:13 --> Output Class Initialized
INFO - 2026-08-19 03:13:13 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:13:13 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:13:13 --> Security Class Initialized
INFO - 2026-08-19 03:13:13 --> Upload Class Initialized
DEBUG - 2026-08-19 03:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:13:13 --> CSRF cookie sent
INFO - 2026-08-19 03:13:13 --> Input Class Initialized
INFO - 2026-08-19 03:13:13 --> Language Class Initialized
DEBUG - 2026-08-19 03:13:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:13:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:13:13 --> Encryption Class Initialized
INFO - 2026-08-19 03:13:13 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:13:13 --> Language Class Initialized
INFO - 2026-08-19 03:13:13 --> Config Class Initialized
INFO - 2026-08-19 03:13:13 --> Database Driver Class Initialized
INFO - 2026-08-19 03:13:13 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:13:13 --> Form Validation Class Initialized
INFO - 2026-08-19 03:13:13 --> Loader Class Initialized
INFO - 2026-08-19 03:13:13 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:13:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:13:13 --> Pagination Class Initialized
INFO - 2026-08-19 03:13:13 --> Helper loaded: url_helper
INFO - 2026-08-19 03:13:13 --> Helper loaded: form_helper
INFO - 2026-08-19 03:13:13 --> Helper loaded: html_helper
INFO - 2026-08-19 03:13:13 --> Helper loaded: file_helper
INFO - 2026-08-19 03:13:13 --> Helper loaded: email_helper
INFO - 2026-08-19 03:13:13 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:13:13 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:13:13 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:13:13 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:13:13 --> Email Class Initialized
INFO - 2026-08-19 03:13:13 --> Controller Class Initialized
ERROR - 2026-08-19 03:13:13 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:13:13 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:13:13 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:13:13 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:13:13 --> Database Driver Class Initialized
INFO - 2026-08-19 03:13:13 --> Upload Class Initialized
INFO - 2026-08-19 03:13:13 --> Helper loaded: domain_helper
DEBUG - 2026-08-19 03:13:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:13:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:13:13 --> Encryption Class Initialized
INFO - 2026-08-19 03:13:13 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:13:13 --> Form Validation Class Initialized
INFO - 2026-08-19 03:13:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:13:13 --> Pagination Class Initialized
INFO - 2026-08-19 03:13:13 --> Email Class Initialized
INFO - 2026-08-19 03:13:13 --> Controller Class Initialized
INFO - 2026-08-19 03:13:13 --> Database Driver Class Initialized
ERROR - 2026-08-19 03:13:13 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:13:15 --> Upload Class Initialized
DEBUG - 2026-08-19 03:13:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:13:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:13:15 --> Encryption Class Initialized
INFO - 2026-08-19 03:13:15 --> Form Validation Class Initialized
INFO - 2026-08-19 03:13:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:13:15 --> Pagination Class Initialized
INFO - 2026-08-19 03:13:15 --> Email Class Initialized
INFO - 2026-08-19 03:13:15 --> Controller Class Initialized
DEBUG - 2026-08-19 03:13:15 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:13:15 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:13:15 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:13:15 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:13:15 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:13:15 --> Upload Class Initialized
DEBUG - 2026-08-19 03:13:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:13:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:13:15 --> Encryption Class Initialized
INFO - 2026-08-19 03:13:15 --> Form Validation Class Initialized
INFO - 2026-08-19 03:13:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:13:15 --> Pagination Class Initialized
INFO - 2026-08-19 03:13:15 --> Email Class Initialized
INFO - 2026-08-19 03:13:15 --> Controller Class Initialized
ERROR - 2026-08-19 03:13:15 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:13:15 --> Upload Class Initialized
DEBUG - 2026-08-19 03:13:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:13:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:13:15 --> Encryption Class Initialized
INFO - 2026-08-19 03:13:15 --> Form Validation Class Initialized
INFO - 2026-08-19 03:13:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:13:15 --> Pagination Class Initialized
INFO - 2026-08-19 03:13:15 --> Email Class Initialized
INFO - 2026-08-19 03:13:15 --> Controller Class Initialized
DEBUG - 2026-08-19 03:13:15 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:13:15 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:13:15 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:13:15 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:13:15 --> Model "Common_model" initialized
INFO - 2026-08-19 03:13:15 --> Model "Order_model" initialized
INFO - 2026-08-19 03:13:15 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:13:15 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:13:15 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:13:15 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:13:15 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:13:15 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:13:16 --> Final output sent to browser
DEBUG - 2026-08-19 03:13:16 --> Total execution time: 2.6818
INFO - 2026-08-19 03:14:12 --> Config Class Initialized
INFO - 2026-08-19 03:14:12 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:14:12 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:14:12 --> Utf8 Class Initialized
INFO - 2026-08-19 03:14:12 --> URI Class Initialized
INFO - 2026-08-19 03:14:12 --> Router Class Initialized
INFO - 2026-08-19 03:14:12 --> Output Class Initialized
INFO - 2026-08-19 03:14:12 --> Security Class Initialized
DEBUG - 2026-08-19 03:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:14:12 --> CSRF cookie sent
INFO - 2026-08-19 03:14:12 --> Input Class Initialized
INFO - 2026-08-19 03:14:12 --> Language Class Initialized
INFO - 2026-08-19 03:14:12 --> Language Class Initialized
INFO - 2026-08-19 03:14:12 --> Config Class Initialized
INFO - 2026-08-19 03:14:12 --> Loader Class Initialized
INFO - 2026-08-19 03:14:12 --> Helper loaded: url_helper
INFO - 2026-08-19 03:14:12 --> Helper loaded: form_helper
INFO - 2026-08-19 03:14:12 --> Helper loaded: html_helper
INFO - 2026-08-19 03:14:12 --> Helper loaded: file_helper
INFO - 2026-08-19 03:14:12 --> Helper loaded: email_helper
INFO - 2026-08-19 03:14:12 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:14:12 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:14:12 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:14:12 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:14:12 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:14:12 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:14:12 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:14:12 --> Database Driver Class Initialized
INFO - 2026-08-19 03:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:14:14 --> Upload Class Initialized
DEBUG - 2026-08-19 03:14:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:14:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:14:14 --> Encryption Class Initialized
INFO - 2026-08-19 03:14:14 --> Form Validation Class Initialized
INFO - 2026-08-19 03:14:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:14:14 --> Pagination Class Initialized
INFO - 2026-08-19 03:14:14 --> Email Class Initialized
INFO - 2026-08-19 03:14:14 --> Controller Class Initialized
DEBUG - 2026-08-19 03:14:14 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:14:14 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:14:14 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:14:14 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:14:14 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:15:12 --> Config Class Initialized
INFO - 2026-08-19 03:15:12 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:15:12 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:15:12 --> Utf8 Class Initialized
INFO - 2026-08-19 03:15:12 --> URI Class Initialized
INFO - 2026-08-19 03:15:12 --> Router Class Initialized
INFO - 2026-08-19 03:15:12 --> Output Class Initialized
INFO - 2026-08-19 03:15:12 --> Security Class Initialized
DEBUG - 2026-08-19 03:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:15:12 --> CSRF cookie sent
INFO - 2026-08-19 03:15:12 --> Input Class Initialized
INFO - 2026-08-19 03:15:12 --> Language Class Initialized
INFO - 2026-08-19 03:15:12 --> Language Class Initialized
INFO - 2026-08-19 03:15:12 --> Config Class Initialized
INFO - 2026-08-19 03:15:12 --> Loader Class Initialized
INFO - 2026-08-19 03:15:12 --> Helper loaded: url_helper
INFO - 2026-08-19 03:15:12 --> Helper loaded: form_helper
INFO - 2026-08-19 03:15:12 --> Helper loaded: html_helper
INFO - 2026-08-19 03:15:12 --> Helper loaded: file_helper
INFO - 2026-08-19 03:15:12 --> Helper loaded: email_helper
INFO - 2026-08-19 03:15:12 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:15:12 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:15:12 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:15:12 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:15:12 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:15:12 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:15:12 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:15:12 --> Database Driver Class Initialized
INFO - 2026-08-19 03:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:15:13 --> Upload Class Initialized
DEBUG - 2026-08-19 03:15:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:15:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:15:13 --> Encryption Class Initialized
INFO - 2026-08-19 03:15:13 --> Form Validation Class Initialized
INFO - 2026-08-19 03:15:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:15:13 --> Pagination Class Initialized
INFO - 2026-08-19 03:15:13 --> Email Class Initialized
INFO - 2026-08-19 03:15:13 --> Controller Class Initialized
DEBUG - 2026-08-19 03:15:13 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:15:13 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:15:13 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:15:13 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:15:13 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:16:12 --> Config Class Initialized
INFO - 2026-08-19 03:16:12 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:16:12 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:16:12 --> Utf8 Class Initialized
INFO - 2026-08-19 03:16:12 --> URI Class Initialized
INFO - 2026-08-19 03:16:12 --> Router Class Initialized
INFO - 2026-08-19 03:16:12 --> Output Class Initialized
INFO - 2026-08-19 03:16:12 --> Security Class Initialized
DEBUG - 2026-08-19 03:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:16:12 --> CSRF cookie sent
INFO - 2026-08-19 03:16:12 --> Input Class Initialized
INFO - 2026-08-19 03:16:12 --> Language Class Initialized
INFO - 2026-08-19 03:16:12 --> Language Class Initialized
INFO - 2026-08-19 03:16:12 --> Config Class Initialized
INFO - 2026-08-19 03:16:12 --> Loader Class Initialized
INFO - 2026-08-19 03:16:12 --> Helper loaded: url_helper
INFO - 2026-08-19 03:16:12 --> Helper loaded: form_helper
INFO - 2026-08-19 03:16:12 --> Helper loaded: html_helper
INFO - 2026-08-19 03:16:12 --> Helper loaded: file_helper
INFO - 2026-08-19 03:16:12 --> Helper loaded: email_helper
INFO - 2026-08-19 03:16:12 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:16:12 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:16:12 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:16:12 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:16:12 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:16:12 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:16:12 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:16:12 --> Database Driver Class Initialized
INFO - 2026-08-19 03:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:16:13 --> Upload Class Initialized
DEBUG - 2026-08-19 03:16:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:16:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:16:13 --> Encryption Class Initialized
INFO - 2026-08-19 03:16:13 --> Form Validation Class Initialized
INFO - 2026-08-19 03:16:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:16:13 --> Pagination Class Initialized
INFO - 2026-08-19 03:16:13 --> Email Class Initialized
INFO - 2026-08-19 03:16:13 --> Controller Class Initialized
DEBUG - 2026-08-19 03:16:13 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:16:13 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:16:13 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:16:13 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:16:13 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:17:12 --> Config Class Initialized
INFO - 2026-08-19 03:17:12 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:17:12 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:17:12 --> Utf8 Class Initialized
INFO - 2026-08-19 03:17:12 --> URI Class Initialized
INFO - 2026-08-19 03:17:12 --> Router Class Initialized
INFO - 2026-08-19 03:17:12 --> Output Class Initialized
INFO - 2026-08-19 03:17:12 --> Security Class Initialized
DEBUG - 2026-08-19 03:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:17:12 --> CSRF cookie sent
INFO - 2026-08-19 03:17:12 --> Input Class Initialized
INFO - 2026-08-19 03:17:12 --> Language Class Initialized
INFO - 2026-08-19 03:17:12 --> Language Class Initialized
INFO - 2026-08-19 03:17:12 --> Config Class Initialized
INFO - 2026-08-19 03:17:12 --> Loader Class Initialized
INFO - 2026-08-19 03:17:12 --> Helper loaded: url_helper
INFO - 2026-08-19 03:17:12 --> Helper loaded: form_helper
INFO - 2026-08-19 03:17:12 --> Helper loaded: html_helper
INFO - 2026-08-19 03:17:12 --> Helper loaded: file_helper
INFO - 2026-08-19 03:17:12 --> Helper loaded: email_helper
INFO - 2026-08-19 03:17:12 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:17:12 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:17:12 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:17:12 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:17:12 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:17:12 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:17:12 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:17:12 --> Database Driver Class Initialized
INFO - 2026-08-19 03:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:17:13 --> Upload Class Initialized
DEBUG - 2026-08-19 03:17:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:17:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:17:13 --> Encryption Class Initialized
INFO - 2026-08-19 03:17:13 --> Form Validation Class Initialized
INFO - 2026-08-19 03:17:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:17:13 --> Pagination Class Initialized
INFO - 2026-08-19 03:17:13 --> Email Class Initialized
INFO - 2026-08-19 03:17:13 --> Controller Class Initialized
DEBUG - 2026-08-19 03:17:13 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:17:13 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:17:13 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:17:13 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:17:13 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:18:12 --> Config Class Initialized
INFO - 2026-08-19 03:18:12 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:18:12 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:18:12 --> Utf8 Class Initialized
INFO - 2026-08-19 03:18:12 --> URI Class Initialized
INFO - 2026-08-19 03:18:12 --> Router Class Initialized
INFO - 2026-08-19 03:18:12 --> Output Class Initialized
INFO - 2026-08-19 03:18:12 --> Security Class Initialized
DEBUG - 2026-08-19 03:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:18:12 --> CSRF cookie sent
INFO - 2026-08-19 03:18:12 --> Input Class Initialized
INFO - 2026-08-19 03:18:12 --> Language Class Initialized
INFO - 2026-08-19 03:18:12 --> Language Class Initialized
INFO - 2026-08-19 03:18:12 --> Config Class Initialized
INFO - 2026-08-19 03:18:12 --> Loader Class Initialized
INFO - 2026-08-19 03:18:12 --> Helper loaded: url_helper
INFO - 2026-08-19 03:18:12 --> Helper loaded: form_helper
INFO - 2026-08-19 03:18:12 --> Helper loaded: html_helper
INFO - 2026-08-19 03:18:12 --> Helper loaded: file_helper
INFO - 2026-08-19 03:18:12 --> Helper loaded: email_helper
INFO - 2026-08-19 03:18:12 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:18:12 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:18:12 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:18:12 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:18:12 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:18:12 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:18:12 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:18:12 --> Database Driver Class Initialized
INFO - 2026-08-19 03:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:18:14 --> Upload Class Initialized
DEBUG - 2026-08-19 03:18:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:18:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:18:14 --> Encryption Class Initialized
INFO - 2026-08-19 03:18:14 --> Form Validation Class Initialized
INFO - 2026-08-19 03:18:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:18:14 --> Pagination Class Initialized
INFO - 2026-08-19 03:18:14 --> Email Class Initialized
INFO - 2026-08-19 03:18:14 --> Controller Class Initialized
DEBUG - 2026-08-19 03:18:14 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:18:14 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:18:14 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:18:14 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:18:14 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:19:12 --> Config Class Initialized
INFO - 2026-08-19 03:19:12 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:19:12 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:19:12 --> Utf8 Class Initialized
INFO - 2026-08-19 03:19:12 --> URI Class Initialized
INFO - 2026-08-19 03:19:12 --> Router Class Initialized
INFO - 2026-08-19 03:19:12 --> Output Class Initialized
INFO - 2026-08-19 03:19:12 --> Security Class Initialized
DEBUG - 2026-08-19 03:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:19:12 --> CSRF cookie sent
INFO - 2026-08-19 03:19:12 --> Input Class Initialized
INFO - 2026-08-19 03:19:12 --> Language Class Initialized
INFO - 2026-08-19 03:19:12 --> Language Class Initialized
INFO - 2026-08-19 03:19:12 --> Config Class Initialized
INFO - 2026-08-19 03:19:12 --> Loader Class Initialized
INFO - 2026-08-19 03:19:12 --> Helper loaded: url_helper
INFO - 2026-08-19 03:19:12 --> Helper loaded: form_helper
INFO - 2026-08-19 03:19:12 --> Helper loaded: html_helper
INFO - 2026-08-19 03:19:12 --> Helper loaded: file_helper
INFO - 2026-08-19 03:19:12 --> Helper loaded: email_helper
INFO - 2026-08-19 03:19:12 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:19:12 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:19:12 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:19:12 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:19:12 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:19:12 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:19:12 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:19:12 --> Database Driver Class Initialized
INFO - 2026-08-19 03:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:19:14 --> Upload Class Initialized
DEBUG - 2026-08-19 03:19:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:19:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:19:14 --> Encryption Class Initialized
INFO - 2026-08-19 03:19:14 --> Form Validation Class Initialized
INFO - 2026-08-19 03:19:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:19:14 --> Pagination Class Initialized
INFO - 2026-08-19 03:19:14 --> Email Class Initialized
INFO - 2026-08-19 03:19:14 --> Controller Class Initialized
DEBUG - 2026-08-19 03:19:14 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:19:14 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:19:14 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:19:14 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:19:14 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:20:12 --> Config Class Initialized
INFO - 2026-08-19 03:20:12 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:20:12 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:20:12 --> Utf8 Class Initialized
INFO - 2026-08-19 03:20:12 --> URI Class Initialized
INFO - 2026-08-19 03:20:12 --> Router Class Initialized
INFO - 2026-08-19 03:20:12 --> Output Class Initialized
INFO - 2026-08-19 03:20:12 --> Security Class Initialized
DEBUG - 2026-08-19 03:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:20:12 --> CSRF cookie sent
INFO - 2026-08-19 03:20:12 --> Input Class Initialized
INFO - 2026-08-19 03:20:12 --> Language Class Initialized
INFO - 2026-08-19 03:20:12 --> Language Class Initialized
INFO - 2026-08-19 03:20:12 --> Config Class Initialized
INFO - 2026-08-19 03:20:12 --> Loader Class Initialized
INFO - 2026-08-19 03:20:12 --> Helper loaded: url_helper
INFO - 2026-08-19 03:20:12 --> Helper loaded: form_helper
INFO - 2026-08-19 03:20:12 --> Helper loaded: html_helper
INFO - 2026-08-19 03:20:12 --> Helper loaded: file_helper
INFO - 2026-08-19 03:20:12 --> Helper loaded: email_helper
INFO - 2026-08-19 03:20:12 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:20:12 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:20:12 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:20:12 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:20:12 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:20:12 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:20:12 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:20:12 --> Database Driver Class Initialized
INFO - 2026-08-19 03:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:20:14 --> Upload Class Initialized
DEBUG - 2026-08-19 03:20:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:20:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:20:14 --> Encryption Class Initialized
INFO - 2026-08-19 03:20:14 --> Form Validation Class Initialized
INFO - 2026-08-19 03:20:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:20:14 --> Pagination Class Initialized
INFO - 2026-08-19 03:20:14 --> Email Class Initialized
INFO - 2026-08-19 03:20:14 --> Controller Class Initialized
DEBUG - 2026-08-19 03:20:14 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:20:14 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:20:14 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:20:14 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:20:14 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:20:47 --> Config Class Initialized
INFO - 2026-08-19 03:20:47 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:20:47 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:20:47 --> Utf8 Class Initialized
INFO - 2026-08-19 03:20:47 --> URI Class Initialized
INFO - 2026-08-19 03:20:47 --> Router Class Initialized
INFO - 2026-08-19 03:20:47 --> Output Class Initialized
INFO - 2026-08-19 03:20:47 --> Security Class Initialized
DEBUG - 2026-08-19 03:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:20:47 --> CSRF cookie sent
INFO - 2026-08-19 03:20:47 --> Input Class Initialized
INFO - 2026-08-19 03:20:47 --> Language Class Initialized
INFO - 2026-08-19 03:20:47 --> Language Class Initialized
INFO - 2026-08-19 03:20:47 --> Config Class Initialized
INFO - 2026-08-19 03:20:47 --> Loader Class Initialized
INFO - 2026-08-19 03:20:47 --> Helper loaded: url_helper
INFO - 2026-08-19 03:20:47 --> Helper loaded: form_helper
INFO - 2026-08-19 03:20:47 --> Helper loaded: html_helper
INFO - 2026-08-19 03:20:47 --> Helper loaded: file_helper
INFO - 2026-08-19 03:20:47 --> Helper loaded: email_helper
INFO - 2026-08-19 03:20:47 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:20:47 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:20:47 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:20:47 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:20:47 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:20:47 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:20:47 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:20:47 --> Database Driver Class Initialized
INFO - 2026-08-19 03:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:20:49 --> Upload Class Initialized
DEBUG - 2026-08-19 03:20:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:20:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:20:49 --> Encryption Class Initialized
INFO - 2026-08-19 03:20:49 --> Form Validation Class Initialized
INFO - 2026-08-19 03:20:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:20:49 --> Pagination Class Initialized
INFO - 2026-08-19 03:20:49 --> Email Class Initialized
INFO - 2026-08-19 03:20:49 --> Controller Class Initialized
DEBUG - 2026-08-19 03:20:49 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:20:49 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:20:49 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:20:49 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:20:49 --> Model "Common_model" initialized
INFO - 2026-08-19 03:20:49 --> Model "Order_model" initialized
INFO - 2026-08-19 03:20:49 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:20:49 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:20:49 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:20:49 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:20:49 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:20:49 --> Model "Orderlicense_model" initialized
DEBUG - 2026-08-19 03:20:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:20:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-08-19 03:20:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-08-19 03:20:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:20:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:20:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/cart_services.php
INFO - 2026-08-19 03:20:50 --> Final output sent to browser
DEBUG - 2026-08-19 03:20:50 --> Total execution time: 3.4815
INFO - 2026-08-19 03:20:51 --> Config Class Initialized
INFO - 2026-08-19 03:20:51 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:20:51 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:20:51 --> Utf8 Class Initialized
INFO - 2026-08-19 03:20:51 --> URI Class Initialized
INFO - 2026-08-19 03:20:51 --> Router Class Initialized
INFO - 2026-08-19 03:20:51 --> Output Class Initialized
INFO - 2026-08-19 03:20:51 --> Security Class Initialized
DEBUG - 2026-08-19 03:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:20:51 --> CSRF cookie sent
INFO - 2026-08-19 03:20:51 --> Input Class Initialized
INFO - 2026-08-19 03:20:51 --> Language Class Initialized
INFO - 2026-08-19 03:20:51 --> Language Class Initialized
INFO - 2026-08-19 03:20:51 --> Config Class Initialized
INFO - 2026-08-19 03:20:51 --> Loader Class Initialized
INFO - 2026-08-19 03:20:51 --> Helper loaded: url_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: form_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: html_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: file_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: email_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:20:51 --> Database Driver Class Initialized
INFO - 2026-08-19 03:20:51 --> Config Class Initialized
INFO - 2026-08-19 03:20:51 --> Hooks Class Initialized
INFO - 2026-08-19 03:20:51 --> Config Class Initialized
INFO - 2026-08-19 03:20:51 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:20:51 --> UTF-8 Support Enabled
DEBUG - 2026-08-19 03:20:51 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:20:51 --> Utf8 Class Initialized
INFO - 2026-08-19 03:20:51 --> Utf8 Class Initialized
INFO - 2026-08-19 03:20:51 --> URI Class Initialized
INFO - 2026-08-19 03:20:51 --> URI Class Initialized
INFO - 2026-08-19 03:20:51 --> Router Class Initialized
INFO - 2026-08-19 03:20:51 --> Output Class Initialized
INFO - 2026-08-19 03:20:51 --> Router Class Initialized
INFO - 2026-08-19 03:20:51 --> Security Class Initialized
INFO - 2026-08-19 03:20:51 --> Output Class Initialized
DEBUG - 2026-08-19 03:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:20:51 --> CSRF cookie sent
INFO - 2026-08-19 03:20:51 --> Input Class Initialized
INFO - 2026-08-19 03:20:51 --> Language Class Initialized
INFO - 2026-08-19 03:20:51 --> Security Class Initialized
INFO - 2026-08-19 03:20:51 --> Language Class Initialized
INFO - 2026-08-19 03:20:51 --> Config Class Initialized
DEBUG - 2026-08-19 03:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:20:51 --> CSRF cookie sent
INFO - 2026-08-19 03:20:51 --> Input Class Initialized
INFO - 2026-08-19 03:20:51 --> Language Class Initialized
INFO - 2026-08-19 03:20:51 --> Language Class Initialized
INFO - 2026-08-19 03:20:51 --> Config Class Initialized
INFO - 2026-08-19 03:20:51 --> Loader Class Initialized
INFO - 2026-08-19 03:20:51 --> Helper loaded: url_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: form_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: html_helper
INFO - 2026-08-19 03:20:51 --> Loader Class Initialized
INFO - 2026-08-19 03:20:51 --> Helper loaded: file_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: email_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: url_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: form_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: html_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: file_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: email_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:20:51 --> Database Driver Class Initialized
INFO - 2026-08-19 03:20:51 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:20:51 --> Database Driver Class Initialized
INFO - 2026-08-19 03:20:51 --> Config Class Initialized
INFO - 2026-08-19 03:20:51 --> Config Class Initialized
INFO - 2026-08-19 03:20:51 --> Config Class Initialized
INFO - 2026-08-19 03:20:51 --> Hooks Class Initialized
INFO - 2026-08-19 03:20:51 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:20:51 --> UTF-8 Support Enabled
DEBUG - 2026-08-19 03:20:51 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:20:51 --> Hooks Class Initialized
INFO - 2026-08-19 03:20:51 --> Utf8 Class Initialized
INFO - 2026-08-19 03:20:51 --> Utf8 Class Initialized
INFO - 2026-08-19 03:20:51 --> URI Class Initialized
DEBUG - 2026-08-19 03:20:51 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:20:51 --> Utf8 Class Initialized
INFO - 2026-08-19 03:20:51 --> URI Class Initialized
INFO - 2026-08-19 03:20:51 --> URI Class Initialized
INFO - 2026-08-19 03:20:51 --> Router Class Initialized
INFO - 2026-08-19 03:20:51 --> Router Class Initialized
INFO - 2026-08-19 03:20:51 --> Output Class Initialized
INFO - 2026-08-19 03:20:51 --> Router Class Initialized
INFO - 2026-08-19 03:20:51 --> Security Class Initialized
INFO - 2026-08-19 03:20:51 --> Output Class Initialized
INFO - 2026-08-19 03:20:51 --> Output Class Initialized
DEBUG - 2026-08-19 03:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:20:51 --> CSRF cookie sent
INFO - 2026-08-19 03:20:51 --> Input Class Initialized
INFO - 2026-08-19 03:20:51 --> Security Class Initialized
INFO - 2026-08-19 03:20:51 --> Language Class Initialized
INFO - 2026-08-19 03:20:51 --> Security Class Initialized
DEBUG - 2026-08-19 03:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:20:51 --> CSRF cookie sent
INFO - 2026-08-19 03:20:51 --> Input Class Initialized
INFO - 2026-08-19 03:20:51 --> Language Class Initialized
INFO - 2026-08-19 03:20:51 --> Config Class Initialized
INFO - 2026-08-19 03:20:51 --> Language Class Initialized
DEBUG - 2026-08-19 03:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:20:51 --> Language Class Initialized
INFO - 2026-08-19 03:20:51 --> CSRF cookie sent
INFO - 2026-08-19 03:20:51 --> Config Class Initialized
INFO - 2026-08-19 03:20:51 --> Input Class Initialized
INFO - 2026-08-19 03:20:51 --> Language Class Initialized
INFO - 2026-08-19 03:20:51 --> Language Class Initialized
INFO - 2026-08-19 03:20:51 --> Loader Class Initialized
INFO - 2026-08-19 03:20:51 --> Config Class Initialized
INFO - 2026-08-19 03:20:51 --> Helper loaded: url_helper
INFO - 2026-08-19 03:20:51 --> Loader Class Initialized
INFO - 2026-08-19 03:20:51 --> Helper loaded: form_helper
INFO - 2026-08-19 03:20:51 --> Loader Class Initialized
INFO - 2026-08-19 03:20:51 --> Helper loaded: html_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: file_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: url_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: email_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: url_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: form_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: form_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: html_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: file_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: html_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: email_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: file_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: email_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:20:51 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:20:51 --> Database Driver Class Initialized
INFO - 2026-08-19 03:20:51 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:20:51 --> Database Driver Class Initialized
INFO - 2026-08-19 03:20:51 --> Database Driver Class Initialized
INFO - 2026-08-19 03:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:20:52 --> Upload Class Initialized
DEBUG - 2026-08-19 03:20:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:20:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:20:52 --> Encryption Class Initialized
INFO - 2026-08-19 03:20:52 --> Form Validation Class Initialized
INFO - 2026-08-19 03:20:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:20:52 --> Pagination Class Initialized
INFO - 2026-08-19 03:20:52 --> Email Class Initialized
INFO - 2026-08-19 03:20:52 --> Controller Class Initialized
ERROR - 2026-08-19 03:20:52 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:20:52 --> Upload Class Initialized
DEBUG - 2026-08-19 03:20:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:20:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:20:52 --> Encryption Class Initialized
INFO - 2026-08-19 03:20:52 --> Form Validation Class Initialized
INFO - 2026-08-19 03:20:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:20:52 --> Pagination Class Initialized
INFO - 2026-08-19 03:20:52 --> Config Class Initialized
INFO - 2026-08-19 03:20:52 --> Email Class Initialized
INFO - 2026-08-19 03:20:52 --> Hooks Class Initialized
INFO - 2026-08-19 03:20:52 --> Controller Class Initialized
ERROR - 2026-08-19 03:20:52 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:20:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-08-19 03:20:52 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:20:52 --> Utf8 Class Initialized
INFO - 2026-08-19 03:20:52 --> URI Class Initialized
INFO - 2026-08-19 03:20:52 --> Upload Class Initialized
DEBUG - 2026-08-19 03:20:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:20:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:20:52 --> Encryption Class Initialized
INFO - 2026-08-19 03:20:52 --> Router Class Initialized
INFO - 2026-08-19 03:20:52 --> Output Class Initialized
INFO - 2026-08-19 03:20:52 --> Form Validation Class Initialized
INFO - 2026-08-19 03:20:52 --> Security Class Initialized
INFO - 2026-08-19 03:20:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:20:52 --> Pagination Class Initialized
DEBUG - 2026-08-19 03:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:20:52 --> CSRF cookie sent
INFO - 2026-08-19 03:20:52 --> Input Class Initialized
INFO - 2026-08-19 03:20:52 --> Language Class Initialized
INFO - 2026-08-19 03:20:52 --> Language Class Initialized
INFO - 2026-08-19 03:20:52 --> Config Class Initialized
INFO - 2026-08-19 03:20:52 --> Loader Class Initialized
INFO - 2026-08-19 03:20:52 --> Email Class Initialized
INFO - 2026-08-19 03:20:52 --> Controller Class Initialized
INFO - 2026-08-19 03:20:52 --> Helper loaded: url_helper
ERROR - 2026-08-19 03:20:52 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:20:52 --> Config Class Initialized
INFO - 2026-08-19 03:20:52 --> Hooks Class Initialized
INFO - 2026-08-19 03:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:20:52 --> Helper loaded: form_helper
INFO - 2026-08-19 03:20:52 --> Helper loaded: html_helper
DEBUG - 2026-08-19 03:20:52 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:20:52 --> Utf8 Class Initialized
INFO - 2026-08-19 03:20:52 --> Helper loaded: file_helper
INFO - 2026-08-19 03:20:52 --> Helper loaded: email_helper
INFO - 2026-08-19 03:20:52 --> URI Class Initialized
INFO - 2026-08-19 03:20:52 --> Upload Class Initialized
INFO - 2026-08-19 03:20:52 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:20:52 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:20:52 --> Router Class Initialized
DEBUG - 2026-08-19 03:20:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:20:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:20:52 --> Encryption Class Initialized
INFO - 2026-08-19 03:20:52 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:20:52 --> Output Class Initialized
INFO - 2026-08-19 03:20:52 --> Form Validation Class Initialized
INFO - 2026-08-19 03:20:52 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:20:52 --> Security Class Initialized
INFO - 2026-08-19 03:20:52 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:20:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:20:52 --> Pagination Class Initialized
DEBUG - 2026-08-19 03:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:20:52 --> CSRF cookie sent
INFO - 2026-08-19 03:20:52 --> Input Class Initialized
INFO - 2026-08-19 03:20:52 --> Language Class Initialized
INFO - 2026-08-19 03:20:52 --> Language Class Initialized
INFO - 2026-08-19 03:20:52 --> Config Class Initialized
INFO - 2026-08-19 03:20:52 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:20:52 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:20:52 --> Email Class Initialized
INFO - 2026-08-19 03:20:52 --> Controller Class Initialized
ERROR - 2026-08-19 03:20:52 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:20:52 --> Loader Class Initialized
INFO - 2026-08-19 03:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:20:52 --> Helper loaded: url_helper
INFO - 2026-08-19 03:20:52 --> Upload Class Initialized
INFO - 2026-08-19 03:20:52 --> Helper loaded: form_helper
INFO - 2026-08-19 03:20:52 --> Helper loaded: html_helper
INFO - 2026-08-19 03:20:52 --> Helper loaded: file_helper
INFO - 2026-08-19 03:20:52 --> Helper loaded: email_helper
DEBUG - 2026-08-19 03:20:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:20:52 --> Config Class Initialized
INFO - 2026-08-19 03:20:52 --> Hooks Class Initialized
INFO - 2026-08-19 03:20:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:20:52 --> Encryption Class Initialized
INFO - 2026-08-19 03:20:52 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:20:52 --> Helper loaded: ssp_helper
DEBUG - 2026-08-19 03:20:52 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:20:52 --> Utf8 Class Initialized
INFO - 2026-08-19 03:20:52 --> Form Validation Class Initialized
INFO - 2026-08-19 03:20:52 --> Database Driver Class Initialized
INFO - 2026-08-19 03:20:52 --> URI Class Initialized
INFO - 2026-08-19 03:20:52 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:20:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:20:52 --> Pagination Class Initialized
INFO - 2026-08-19 03:20:52 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:20:52 --> Router Class Initialized
INFO - 2026-08-19 03:20:52 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:20:52 --> Output Class Initialized
INFO - 2026-08-19 03:20:52 --> Email Class Initialized
INFO - 2026-08-19 03:20:52 --> Controller Class Initialized
ERROR - 2026-08-19 03:20:52 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:20:52 --> Security Class Initialized
INFO - 2026-08-19 03:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:20:52 --> Helper loaded: domain_helper
DEBUG - 2026-08-19 03:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:20:52 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:20:52 --> CSRF cookie sent
INFO - 2026-08-19 03:20:52 --> Input Class Initialized
INFO - 2026-08-19 03:20:52 --> Language Class Initialized
INFO - 2026-08-19 03:20:52 --> Language Class Initialized
INFO - 2026-08-19 03:20:52 --> Upload Class Initialized
INFO - 2026-08-19 03:20:52 --> Config Class Initialized
DEBUG - 2026-08-19 03:20:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:20:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:20:52 --> Encryption Class Initialized
INFO - 2026-08-19 03:20:52 --> Loader Class Initialized
INFO - 2026-08-19 03:20:52 --> Helper loaded: url_helper
INFO - 2026-08-19 03:20:52 --> Form Validation Class Initialized
INFO - 2026-08-19 03:20:52 --> Helper loaded: form_helper
INFO - 2026-08-19 03:20:52 --> Database Driver Class Initialized
INFO - 2026-08-19 03:20:52 --> Helper loaded: html_helper
INFO - 2026-08-19 03:20:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:20:52 --> Pagination Class Initialized
INFO - 2026-08-19 03:20:52 --> Helper loaded: file_helper
INFO - 2026-08-19 03:20:52 --> Helper loaded: email_helper
INFO - 2026-08-19 03:20:52 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:20:52 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:20:52 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:20:52 --> Email Class Initialized
INFO - 2026-08-19 03:20:52 --> Controller Class Initialized
ERROR - 2026-08-19 03:20:52 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:20:52 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:20:52 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:20:52 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:20:52 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:20:52 --> Database Driver Class Initialized
INFO - 2026-08-19 03:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:20:54 --> Upload Class Initialized
DEBUG - 2026-08-19 03:20:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:20:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:20:54 --> Encryption Class Initialized
INFO - 2026-08-19 03:20:54 --> Form Validation Class Initialized
INFO - 2026-08-19 03:20:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:20:54 --> Pagination Class Initialized
INFO - 2026-08-19 03:20:54 --> Email Class Initialized
INFO - 2026-08-19 03:20:54 --> Controller Class Initialized
DEBUG - 2026-08-19 03:20:54 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:20:54 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:20:54 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:20:54 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:20:54 --> Model "Common_model" initialized
INFO - 2026-08-19 03:20:54 --> Model "Order_model" initialized
INFO - 2026-08-19 03:20:54 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:20:54 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:20:54 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:20:54 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:20:54 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:20:54 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:20:54 --> Final output sent to browser
DEBUG - 2026-08-19 03:20:54 --> Total execution time: 2.0555
INFO - 2026-08-19 03:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:20:54 --> Upload Class Initialized
DEBUG - 2026-08-19 03:20:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:20:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:20:54 --> Encryption Class Initialized
INFO - 2026-08-19 03:20:54 --> Form Validation Class Initialized
INFO - 2026-08-19 03:20:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:20:54 --> Pagination Class Initialized
INFO - 2026-08-19 03:20:54 --> Email Class Initialized
INFO - 2026-08-19 03:20:54 --> Controller Class Initialized
ERROR - 2026-08-19 03:20:54 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:20:54 --> Upload Class Initialized
DEBUG - 2026-08-19 03:20:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:20:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:20:54 --> Encryption Class Initialized
INFO - 2026-08-19 03:20:54 --> Form Validation Class Initialized
INFO - 2026-08-19 03:20:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:20:54 --> Pagination Class Initialized
INFO - 2026-08-19 03:20:54 --> Email Class Initialized
INFO - 2026-08-19 03:20:54 --> Controller Class Initialized
DEBUG - 2026-08-19 03:20:54 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:20:54 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:20:54 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:20:54 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:20:54 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:21:00 --> Config Class Initialized
INFO - 2026-08-19 03:21:00 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:21:00 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:21:00 --> Utf8 Class Initialized
INFO - 2026-08-19 03:21:00 --> URI Class Initialized
INFO - 2026-08-19 03:21:00 --> Router Class Initialized
INFO - 2026-08-19 03:21:00 --> Output Class Initialized
INFO - 2026-08-19 03:21:00 --> Security Class Initialized
DEBUG - 2026-08-19 03:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:21:00 --> Input Class Initialized
INFO - 2026-08-19 03:21:00 --> Language Class Initialized
INFO - 2026-08-19 03:21:00 --> Language Class Initialized
INFO - 2026-08-19 03:21:00 --> Config Class Initialized
INFO - 2026-08-19 03:21:00 --> Loader Class Initialized
INFO - 2026-08-19 03:21:00 --> Helper loaded: url_helper
INFO - 2026-08-19 03:21:00 --> Helper loaded: form_helper
INFO - 2026-08-19 03:21:00 --> Helper loaded: html_helper
INFO - 2026-08-19 03:21:00 --> Helper loaded: file_helper
INFO - 2026-08-19 03:21:00 --> Helper loaded: email_helper
INFO - 2026-08-19 03:21:00 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:21:00 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:21:00 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:21:00 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:21:00 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:21:00 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:21:00 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:21:00 --> Database Driver Class Initialized
INFO - 2026-08-19 03:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:21:02 --> Upload Class Initialized
DEBUG - 2026-08-19 03:21:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:21:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:21:02 --> Encryption Class Initialized
INFO - 2026-08-19 03:21:02 --> Form Validation Class Initialized
INFO - 2026-08-19 03:21:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:21:02 --> Pagination Class Initialized
INFO - 2026-08-19 03:21:02 --> Email Class Initialized
INFO - 2026-08-19 03:21:02 --> Controller Class Initialized
DEBUG - 2026-08-19 03:21:02 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:21:02 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:21:02 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:21:02 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:21:02 --> Model "Common_model" initialized
INFO - 2026-08-19 03:21:02 --> Model "Order_model" initialized
INFO - 2026-08-19 03:21:02 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:21:02 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:21:02 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:21:02 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:21:02 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:21:02 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:21:03 --> Final output sent to browser
DEBUG - 2026-08-19 03:21:03 --> Total execution time: 2.9112
INFO - 2026-08-19 03:21:03 --> Config Class Initialized
INFO - 2026-08-19 03:21:03 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:21:03 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:21:03 --> Utf8 Class Initialized
INFO - 2026-08-19 03:21:03 --> URI Class Initialized
INFO - 2026-08-19 03:21:03 --> Router Class Initialized
INFO - 2026-08-19 03:21:03 --> Output Class Initialized
INFO - 2026-08-19 03:21:03 --> Security Class Initialized
DEBUG - 2026-08-19 03:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:21:03 --> Input Class Initialized
INFO - 2026-08-19 03:21:03 --> Language Class Initialized
INFO - 2026-08-19 03:21:03 --> Language Class Initialized
INFO - 2026-08-19 03:21:03 --> Config Class Initialized
INFO - 2026-08-19 03:21:03 --> Loader Class Initialized
INFO - 2026-08-19 03:21:03 --> Helper loaded: url_helper
INFO - 2026-08-19 03:21:03 --> Helper loaded: form_helper
INFO - 2026-08-19 03:21:03 --> Helper loaded: html_helper
INFO - 2026-08-19 03:21:03 --> Helper loaded: file_helper
INFO - 2026-08-19 03:21:03 --> Helper loaded: email_helper
INFO - 2026-08-19 03:21:03 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:21:03 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:21:03 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:21:03 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:21:03 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:21:03 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:21:03 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:21:03 --> Database Driver Class Initialized
INFO - 2026-08-19 03:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:21:05 --> Upload Class Initialized
DEBUG - 2026-08-19 03:21:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:21:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:21:05 --> Encryption Class Initialized
INFO - 2026-08-19 03:21:05 --> Form Validation Class Initialized
INFO - 2026-08-19 03:21:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:21:05 --> Pagination Class Initialized
INFO - 2026-08-19 03:21:05 --> Email Class Initialized
INFO - 2026-08-19 03:21:05 --> Controller Class Initialized
DEBUG - 2026-08-19 03:21:05 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:21:05 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:21:05 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:21:05 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:21:05 --> Model "Common_model" initialized
INFO - 2026-08-19 03:21:05 --> Model "Order_model" initialized
INFO - 2026-08-19 03:21:05 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:21:05 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:21:05 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:21:05 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:21:05 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:21:05 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:21:06 --> Final output sent to browser
DEBUG - 2026-08-19 03:21:06 --> Total execution time: 3.2608
INFO - 2026-08-19 03:21:06 --> Config Class Initialized
INFO - 2026-08-19 03:21:06 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:21:06 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:21:06 --> Utf8 Class Initialized
INFO - 2026-08-19 03:21:06 --> URI Class Initialized
INFO - 2026-08-19 03:21:06 --> Router Class Initialized
INFO - 2026-08-19 03:21:06 --> Output Class Initialized
INFO - 2026-08-19 03:21:06 --> Security Class Initialized
DEBUG - 2026-08-19 03:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:21:06 --> CSRF cookie sent
INFO - 2026-08-19 03:21:06 --> Input Class Initialized
INFO - 2026-08-19 03:21:06 --> Language Class Initialized
INFO - 2026-08-19 03:21:06 --> Language Class Initialized
INFO - 2026-08-19 03:21:06 --> Config Class Initialized
INFO - 2026-08-19 03:21:06 --> Loader Class Initialized
INFO - 2026-08-19 03:21:06 --> Helper loaded: url_helper
INFO - 2026-08-19 03:21:06 --> Helper loaded: form_helper
INFO - 2026-08-19 03:21:06 --> Helper loaded: html_helper
INFO - 2026-08-19 03:21:06 --> Helper loaded: file_helper
INFO - 2026-08-19 03:21:06 --> Helper loaded: email_helper
INFO - 2026-08-19 03:21:06 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:21:06 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:21:06 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:21:06 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:21:06 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:21:06 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:21:06 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:21:06 --> Database Driver Class Initialized
INFO - 2026-08-19 03:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:21:08 --> Upload Class Initialized
DEBUG - 2026-08-19 03:21:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:21:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:21:08 --> Encryption Class Initialized
INFO - 2026-08-19 03:21:08 --> Form Validation Class Initialized
INFO - 2026-08-19 03:21:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:21:08 --> Pagination Class Initialized
INFO - 2026-08-19 03:21:08 --> Email Class Initialized
INFO - 2026-08-19 03:21:08 --> Controller Class Initialized
DEBUG - 2026-08-19 03:21:08 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:21:08 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:21:08 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:21:08 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:21:08 --> Model "Common_model" initialized
INFO - 2026-08-19 03:21:08 --> Model "Order_model" initialized
INFO - 2026-08-19 03:21:08 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:21:08 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:21:08 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:21:08 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:21:08 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:21:08 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:21:10 --> Config Class Initialized
INFO - 2026-08-19 03:21:10 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:21:10 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:21:10 --> Utf8 Class Initialized
INFO - 2026-08-19 03:21:10 --> URI Class Initialized
INFO - 2026-08-19 03:21:10 --> Router Class Initialized
INFO - 2026-08-19 03:21:10 --> Output Class Initialized
INFO - 2026-08-19 03:21:10 --> Security Class Initialized
DEBUG - 2026-08-19 03:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:21:10 --> CSRF cookie sent
INFO - 2026-08-19 03:21:10 --> Input Class Initialized
INFO - 2026-08-19 03:21:10 --> Language Class Initialized
INFO - 2026-08-19 03:21:10 --> Language Class Initialized
INFO - 2026-08-19 03:21:10 --> Config Class Initialized
INFO - 2026-08-19 03:21:10 --> Loader Class Initialized
INFO - 2026-08-19 03:21:10 --> Helper loaded: url_helper
INFO - 2026-08-19 03:21:10 --> Helper loaded: form_helper
INFO - 2026-08-19 03:21:10 --> Helper loaded: html_helper
INFO - 2026-08-19 03:21:10 --> Helper loaded: file_helper
INFO - 2026-08-19 03:21:10 --> Helper loaded: email_helper
INFO - 2026-08-19 03:21:10 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:21:10 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:21:10 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:21:11 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:21:11 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:21:11 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:21:11 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:21:11 --> Database Driver Class Initialized
DEBUG - 2026-08-19 03:21:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:21:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-08-19 03:21:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-08-19 03:21:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:21:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:21:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/view_card.php
INFO - 2026-08-19 03:21:12 --> Final output sent to browser
DEBUG - 2026-08-19 03:21:12 --> Total execution time: 5.2974
INFO - 2026-08-19 03:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:21:13 --> Upload Class Initialized
DEBUG - 2026-08-19 03:21:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:21:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:21:13 --> Encryption Class Initialized
INFO - 2026-08-19 03:21:13 --> Form Validation Class Initialized
INFO - 2026-08-19 03:21:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:21:13 --> Pagination Class Initialized
INFO - 2026-08-19 03:21:13 --> Email Class Initialized
INFO - 2026-08-19 03:21:13 --> Controller Class Initialized
DEBUG - 2026-08-19 03:21:13 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:21:13 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:21:13 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:21:13 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:21:13 --> Model "Common_model" initialized
INFO - 2026-08-19 03:21:13 --> Model "Order_model" initialized
INFO - 2026-08-19 03:21:13 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:21:13 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:21:13 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:21:13 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:21:13 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:21:13 --> Model "Orderlicense_model" initialized
DEBUG - 2026-08-19 03:21:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:21:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-08-19 03:21:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-08-19 03:21:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:21:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:21:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/cart_services.php
INFO - 2026-08-19 03:21:15 --> Final output sent to browser
DEBUG - 2026-08-19 03:21:15 --> Total execution time: 4.0905
INFO - 2026-08-19 03:21:15 --> Config Class Initialized
INFO - 2026-08-19 03:21:15 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:21:15 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:21:15 --> Utf8 Class Initialized
INFO - 2026-08-19 03:21:15 --> URI Class Initialized
INFO - 2026-08-19 03:21:15 --> Router Class Initialized
INFO - 2026-08-19 03:21:15 --> Output Class Initialized
INFO - 2026-08-19 03:21:15 --> Security Class Initialized
DEBUG - 2026-08-19 03:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:21:15 --> CSRF cookie sent
INFO - 2026-08-19 03:21:15 --> Input Class Initialized
INFO - 2026-08-19 03:21:15 --> Language Class Initialized
INFO - 2026-08-19 03:21:15 --> Language Class Initialized
INFO - 2026-08-19 03:21:15 --> Config Class Initialized
INFO - 2026-08-19 03:21:15 --> Loader Class Initialized
INFO - 2026-08-19 03:21:15 --> Helper loaded: url_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: form_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: html_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: file_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: email_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:21:15 --> Database Driver Class Initialized
INFO - 2026-08-19 03:21:15 --> Config Class Initialized
INFO - 2026-08-19 03:21:15 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:21:15 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:21:15 --> Utf8 Class Initialized
INFO - 2026-08-19 03:21:15 --> URI Class Initialized
INFO - 2026-08-19 03:21:15 --> Router Class Initialized
INFO - 2026-08-19 03:21:15 --> Output Class Initialized
INFO - 2026-08-19 03:21:15 --> Security Class Initialized
DEBUG - 2026-08-19 03:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:21:15 --> CSRF cookie sent
INFO - 2026-08-19 03:21:15 --> Input Class Initialized
INFO - 2026-08-19 03:21:15 --> Language Class Initialized
INFO - 2026-08-19 03:21:15 --> Config Class Initialized
INFO - 2026-08-19 03:21:15 --> Hooks Class Initialized
INFO - 2026-08-19 03:21:15 --> Language Class Initialized
INFO - 2026-08-19 03:21:15 --> Config Class Initialized
INFO - 2026-08-19 03:21:15 --> Config Class Initialized
INFO - 2026-08-19 03:21:15 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:21:15 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:21:15 --> Utf8 Class Initialized
INFO - 2026-08-19 03:21:15 --> URI Class Initialized
DEBUG - 2026-08-19 03:21:15 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:21:15 --> Utf8 Class Initialized
INFO - 2026-08-19 03:21:15 --> Loader Class Initialized
INFO - 2026-08-19 03:21:15 --> URI Class Initialized
INFO - 2026-08-19 03:21:15 --> Config Class Initialized
INFO - 2026-08-19 03:21:15 --> Hooks Class Initialized
INFO - 2026-08-19 03:21:15 --> Router Class Initialized
INFO - 2026-08-19 03:21:15 --> Helper loaded: url_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: form_helper
INFO - 2026-08-19 03:21:15 --> Router Class Initialized
INFO - 2026-08-19 03:21:15 --> Output Class Initialized
DEBUG - 2026-08-19 03:21:15 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:21:15 --> Utf8 Class Initialized
INFO - 2026-08-19 03:21:15 --> Helper loaded: html_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: file_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: email_helper
INFO - 2026-08-19 03:21:15 --> URI Class Initialized
INFO - 2026-08-19 03:21:15 --> Output Class Initialized
INFO - 2026-08-19 03:21:15 --> Security Class Initialized
INFO - 2026-08-19 03:21:15 --> Security Class Initialized
DEBUG - 2026-08-19 03:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:21:15 --> CSRF cookie sent
INFO - 2026-08-19 03:21:15 --> Input Class Initialized
INFO - 2026-08-19 03:21:15 --> Language Class Initialized
DEBUG - 2026-08-19 03:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:21:15 --> CSRF cookie sent
INFO - 2026-08-19 03:21:15 --> Input Class Initialized
INFO - 2026-08-19 03:21:15 --> Language Class Initialized
INFO - 2026-08-19 03:21:15 --> Router Class Initialized
INFO - 2026-08-19 03:21:15 --> Language Class Initialized
INFO - 2026-08-19 03:21:15 --> Config Class Initialized
INFO - 2026-08-19 03:21:15 --> Language Class Initialized
INFO - 2026-08-19 03:21:15 --> Config Class Initialized
INFO - 2026-08-19 03:21:15 --> Output Class Initialized
INFO - 2026-08-19 03:21:15 --> Loader Class Initialized
INFO - 2026-08-19 03:21:15 --> Helper loaded: url_helper
INFO - 2026-08-19 03:21:15 --> Security Class Initialized
INFO - 2026-08-19 03:21:15 --> Helper loaded: form_helper
INFO - 2026-08-19 03:21:15 --> Loader Class Initialized
INFO - 2026-08-19 03:21:15 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: html_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: url_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: file_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: email_helper
DEBUG - 2026-08-19 03:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:21:15 --> CSRF cookie sent
INFO - 2026-08-19 03:21:15 --> Input Class Initialized
INFO - 2026-08-19 03:21:15 --> Language Class Initialized
INFO - 2026-08-19 03:21:15 --> Helper loaded: form_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: html_helper
INFO - 2026-08-19 03:21:15 --> Language Class Initialized
INFO - 2026-08-19 03:21:15 --> Config Class Initialized
INFO - 2026-08-19 03:21:15 --> Helper loaded: file_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: email_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:21:15 --> Loader Class Initialized
INFO - 2026-08-19 03:21:15 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: url_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: form_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: html_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: file_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: email_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:21:15 --> Database Driver Class Initialized
INFO - 2026-08-19 03:21:15 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:21:15 --> Database Driver Class Initialized
INFO - 2026-08-19 03:21:15 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:21:15 --> Config Class Initialized
INFO - 2026-08-19 03:21:15 --> Hooks Class Initialized
INFO - 2026-08-19 03:21:15 --> Helper loaded: directadmin_helper
DEBUG - 2026-08-19 03:21:15 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:21:15 --> Utf8 Class Initialized
INFO - 2026-08-19 03:21:15 --> URI Class Initialized
INFO - 2026-08-19 03:21:15 --> Database Driver Class Initialized
INFO - 2026-08-19 03:21:15 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:21:15 --> Router Class Initialized
INFO - 2026-08-19 03:21:15 --> Output Class Initialized
INFO - 2026-08-19 03:21:15 --> Security Class Initialized
DEBUG - 2026-08-19 03:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:21:15 --> CSRF cookie sent
INFO - 2026-08-19 03:21:15 --> Input Class Initialized
INFO - 2026-08-19 03:21:15 --> Language Class Initialized
INFO - 2026-08-19 03:21:15 --> Database Driver Class Initialized
INFO - 2026-08-19 03:21:15 --> Language Class Initialized
INFO - 2026-08-19 03:21:15 --> Config Class Initialized
INFO - 2026-08-19 03:21:15 --> Loader Class Initialized
INFO - 2026-08-19 03:21:15 --> Helper loaded: url_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: form_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: html_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: file_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: email_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:21:15 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:21:15 --> Database Driver Class Initialized
INFO - 2026-08-19 03:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:21:17 --> Upload Class Initialized
DEBUG - 2026-08-19 03:21:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:21:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:21:17 --> Encryption Class Initialized
INFO - 2026-08-19 03:21:17 --> Form Validation Class Initialized
INFO - 2026-08-19 03:21:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:21:17 --> Pagination Class Initialized
INFO - 2026-08-19 03:21:17 --> Email Class Initialized
INFO - 2026-08-19 03:21:17 --> Controller Class Initialized
ERROR - 2026-08-19 03:21:17 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:21:17 --> Upload Class Initialized
DEBUG - 2026-08-19 03:21:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:21:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:21:17 --> Encryption Class Initialized
INFO - 2026-08-19 03:21:17 --> Form Validation Class Initialized
INFO - 2026-08-19 03:21:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:21:17 --> Pagination Class Initialized
INFO - 2026-08-19 03:21:17 --> Email Class Initialized
INFO - 2026-08-19 03:21:17 --> Controller Class Initialized
ERROR - 2026-08-19 03:21:17 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:21:17 --> Upload Class Initialized
DEBUG - 2026-08-19 03:21:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:21:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:21:17 --> Encryption Class Initialized
INFO - 2026-08-19 03:21:17 --> Config Class Initialized
INFO - 2026-08-19 03:21:17 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:21:17 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:21:17 --> Utf8 Class Initialized
INFO - 2026-08-19 03:21:17 --> Form Validation Class Initialized
INFO - 2026-08-19 03:21:17 --> URI Class Initialized
INFO - 2026-08-19 03:21:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:21:17 --> Pagination Class Initialized
INFO - 2026-08-19 03:21:17 --> Router Class Initialized
INFO - 2026-08-19 03:21:17 --> Email Class Initialized
INFO - 2026-08-19 03:21:17 --> Controller Class Initialized
ERROR - 2026-08-19 03:21:17 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:21:17 --> Output Class Initialized
INFO - 2026-08-19 03:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:21:17 --> Security Class Initialized
INFO - 2026-08-19 03:21:17 --> Config Class Initialized
INFO - 2026-08-19 03:21:17 --> Hooks Class Initialized
INFO - 2026-08-19 03:21:17 --> Upload Class Initialized
DEBUG - 2026-08-19 03:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:21:17 --> CSRF cookie sent
INFO - 2026-08-19 03:21:17 --> Input Class Initialized
DEBUG - 2026-08-19 03:21:17 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:21:17 --> Utf8 Class Initialized
INFO - 2026-08-19 03:21:17 --> Language Class Initialized
DEBUG - 2026-08-19 03:21:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:21:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:21:17 --> Encryption Class Initialized
INFO - 2026-08-19 03:21:17 --> URI Class Initialized
INFO - 2026-08-19 03:21:17 --> Language Class Initialized
INFO - 2026-08-19 03:21:17 --> Config Class Initialized
INFO - 2026-08-19 03:21:17 --> Form Validation Class Initialized
INFO - 2026-08-19 03:21:17 --> Router Class Initialized
INFO - 2026-08-19 03:21:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:21:17 --> Pagination Class Initialized
INFO - 2026-08-19 03:21:17 --> Loader Class Initialized
INFO - 2026-08-19 03:21:17 --> Output Class Initialized
INFO - 2026-08-19 03:21:17 --> Helper loaded: url_helper
INFO - 2026-08-19 03:21:17 --> Security Class Initialized
INFO - 2026-08-19 03:21:17 --> Email Class Initialized
INFO - 2026-08-19 03:21:17 --> Controller Class Initialized
INFO - 2026-08-19 03:21:17 --> Helper loaded: form_helper
ERROR - 2026-08-19 03:21:17 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:21:17 --> Helper loaded: html_helper
INFO - 2026-08-19 03:21:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-08-19 03:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:21:17 --> CSRF cookie sent
INFO - 2026-08-19 03:21:17 --> Input Class Initialized
INFO - 2026-08-19 03:21:17 --> Language Class Initialized
INFO - 2026-08-19 03:21:17 --> Helper loaded: file_helper
INFO - 2026-08-19 03:21:17 --> Helper loaded: email_helper
INFO - 2026-08-19 03:21:17 --> Upload Class Initialized
INFO - 2026-08-19 03:21:17 --> Language Class Initialized
INFO - 2026-08-19 03:21:17 --> Config Class Initialized
DEBUG - 2026-08-19 03:21:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:21:17 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:21:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:21:17 --> Encryption Class Initialized
INFO - 2026-08-19 03:21:17 --> Config Class Initialized
INFO - 2026-08-19 03:21:17 --> Hooks Class Initialized
INFO - 2026-08-19 03:21:17 --> Helper loaded: ssp_helper
DEBUG - 2026-08-19 03:21:17 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:21:17 --> Utf8 Class Initialized
INFO - 2026-08-19 03:21:17 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:21:17 --> Form Validation Class Initialized
INFO - 2026-08-19 03:21:17 --> Loader Class Initialized
INFO - 2026-08-19 03:21:17 --> URI Class Initialized
INFO - 2026-08-19 03:21:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:21:17 --> Pagination Class Initialized
INFO - 2026-08-19 03:21:17 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:21:17 --> Helper loaded: url_helper
INFO - 2026-08-19 03:21:17 --> Router Class Initialized
INFO - 2026-08-19 03:21:17 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:21:17 --> Helper loaded: form_helper
INFO - 2026-08-19 03:21:17 --> Helper loaded: html_helper
INFO - 2026-08-19 03:21:17 --> Output Class Initialized
INFO - 2026-08-19 03:21:17 --> Email Class Initialized
INFO - 2026-08-19 03:21:17 --> Helper loaded: file_helper
INFO - 2026-08-19 03:21:17 --> Controller Class Initialized
INFO - 2026-08-19 03:21:17 --> Helper loaded: email_helper
ERROR - 2026-08-19 03:21:17 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:21:17 --> Security Class Initialized
INFO - 2026-08-19 03:21:17 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:21:17 --> Helper loaded: entitlement_helper
DEBUG - 2026-08-19 03:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:21:17 --> CSRF cookie sent
INFO - 2026-08-19 03:21:17 --> Input Class Initialized
INFO - 2026-08-19 03:21:17 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:21:17 --> Language Class Initialized
INFO - 2026-08-19 03:21:17 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:21:17 --> Language Class Initialized
INFO - 2026-08-19 03:21:17 --> Config Class Initialized
INFO - 2026-08-19 03:21:17 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:21:17 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:21:17 --> Loader Class Initialized
INFO - 2026-08-19 03:21:17 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:21:17 --> Helper loaded: url_helper
INFO - 2026-08-19 03:21:17 --> Upload Class Initialized
INFO - 2026-08-19 03:21:17 --> Database Driver Class Initialized
INFO - 2026-08-19 03:21:17 --> Helper loaded: form_helper
DEBUG - 2026-08-19 03:21:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:21:17 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:21:17 --> Helper loaded: html_helper
INFO - 2026-08-19 03:21:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:21:17 --> Encryption Class Initialized
INFO - 2026-08-19 03:21:17 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:21:17 --> Helper loaded: file_helper
INFO - 2026-08-19 03:21:17 --> Helper loaded: email_helper
INFO - 2026-08-19 03:21:17 --> Config Class Initialized
INFO - 2026-08-19 03:21:17 --> Hooks Class Initialized
INFO - 2026-08-19 03:21:17 --> Form Validation Class Initialized
DEBUG - 2026-08-19 03:21:17 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:21:17 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:21:17 --> Utf8 Class Initialized
INFO - 2026-08-19 03:21:17 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:21:17 --> URI Class Initialized
INFO - 2026-08-19 03:21:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:21:17 --> Pagination Class Initialized
INFO - 2026-08-19 03:21:17 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:21:17 --> Router Class Initialized
INFO - 2026-08-19 03:21:17 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:21:17 --> Database Driver Class Initialized
INFO - 2026-08-19 03:21:17 --> Output Class Initialized
INFO - 2026-08-19 03:21:17 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:21:17 --> Security Class Initialized
INFO - 2026-08-19 03:21:17 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:21:17 --> Email Class Initialized
INFO - 2026-08-19 03:21:17 --> Controller Class Initialized
INFO - 2026-08-19 03:21:17 --> Helper loaded: entitlement_helper
ERROR - 2026-08-19 03:21:17 --> 404 Page Not Found: /index
DEBUG - 2026-08-19 03:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:21:17 --> CSRF cookie sent
INFO - 2026-08-19 03:21:17 --> Input Class Initialized
INFO - 2026-08-19 03:21:17 --> Language Class Initialized
INFO - 2026-08-19 03:21:17 --> Language Class Initialized
INFO - 2026-08-19 03:21:17 --> Config Class Initialized
INFO - 2026-08-19 03:21:17 --> Database Driver Class Initialized
INFO - 2026-08-19 03:21:17 --> Loader Class Initialized
INFO - 2026-08-19 03:21:17 --> Helper loaded: url_helper
INFO - 2026-08-19 03:21:17 --> Helper loaded: form_helper
INFO - 2026-08-19 03:21:17 --> Helper loaded: html_helper
INFO - 2026-08-19 03:21:17 --> Helper loaded: file_helper
INFO - 2026-08-19 03:21:17 --> Helper loaded: email_helper
INFO - 2026-08-19 03:21:17 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:21:17 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:21:17 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:21:17 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:21:17 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:21:17 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:21:17 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:21:17 --> Database Driver Class Initialized
INFO - 2026-08-19 03:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:21:18 --> Upload Class Initialized
DEBUG - 2026-08-19 03:21:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:21:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:21:18 --> Encryption Class Initialized
INFO - 2026-08-19 03:21:18 --> Form Validation Class Initialized
INFO - 2026-08-19 03:21:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:21:18 --> Pagination Class Initialized
INFO - 2026-08-19 03:21:18 --> Email Class Initialized
INFO - 2026-08-19 03:21:18 --> Controller Class Initialized
DEBUG - 2026-08-19 03:21:18 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:21:18 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:21:18 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:21:18 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:21:18 --> Model "Common_model" initialized
INFO - 2026-08-19 03:21:18 --> Model "Order_model" initialized
INFO - 2026-08-19 03:21:18 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:21:18 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:21:18 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:21:18 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:21:18 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:21:18 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:21:19 --> Final output sent to browser
DEBUG - 2026-08-19 03:21:19 --> Total execution time: 2.1568
INFO - 2026-08-19 03:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:21:19 --> Upload Class Initialized
DEBUG - 2026-08-19 03:21:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:21:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:21:19 --> Encryption Class Initialized
INFO - 2026-08-19 03:21:19 --> Form Validation Class Initialized
INFO - 2026-08-19 03:21:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:21:19 --> Pagination Class Initialized
INFO - 2026-08-19 03:21:19 --> Email Class Initialized
INFO - 2026-08-19 03:21:19 --> Controller Class Initialized
ERROR - 2026-08-19 03:21:19 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:21:19 --> Upload Class Initialized
DEBUG - 2026-08-19 03:21:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:21:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:21:19 --> Encryption Class Initialized
INFO - 2026-08-19 03:21:19 --> Form Validation Class Initialized
INFO - 2026-08-19 03:21:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:21:19 --> Pagination Class Initialized
INFO - 2026-08-19 03:21:19 --> Email Class Initialized
INFO - 2026-08-19 03:21:19 --> Controller Class Initialized
DEBUG - 2026-08-19 03:21:19 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:21:19 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:21:19 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:21:19 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:21:19 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:21:19 --> Upload Class Initialized
DEBUG - 2026-08-19 03:21:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:21:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:21:19 --> Encryption Class Initialized
INFO - 2026-08-19 03:21:19 --> Form Validation Class Initialized
INFO - 2026-08-19 03:21:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:21:19 --> Pagination Class Initialized
INFO - 2026-08-19 03:21:19 --> Email Class Initialized
INFO - 2026-08-19 03:21:19 --> Controller Class Initialized
DEBUG - 2026-08-19 03:21:19 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:21:19 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:21:19 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:21:19 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:21:19 --> Model "Common_model" initialized
INFO - 2026-08-19 03:21:19 --> Model "Order_model" initialized
INFO - 2026-08-19 03:21:19 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:21:19 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:21:19 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:21:19 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:21:19 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:21:19 --> Model "Orderlicense_model" initialized
DEBUG - 2026-08-19 03:21:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:21:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-08-19 03:21:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-08-19 03:21:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:21:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:21:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/view_card.php
INFO - 2026-08-19 03:21:23 --> Final output sent to browser
DEBUG - 2026-08-19 03:21:23 --> Total execution time: 6.2562
INFO - 2026-08-19 03:21:23 --> Config Class Initialized
INFO - 2026-08-19 03:21:23 --> Config Class Initialized
INFO - 2026-08-19 03:21:23 --> Hooks Class Initialized
INFO - 2026-08-19 03:21:23 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:21:23 --> UTF-8 Support Enabled
DEBUG - 2026-08-19 03:21:23 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:21:23 --> Utf8 Class Initialized
INFO - 2026-08-19 03:21:23 --> Utf8 Class Initialized
INFO - 2026-08-19 03:21:23 --> URI Class Initialized
INFO - 2026-08-19 03:21:23 --> URI Class Initialized
INFO - 2026-08-19 03:21:23 --> Router Class Initialized
INFO - 2026-08-19 03:21:23 --> Router Class Initialized
INFO - 2026-08-19 03:21:23 --> Output Class Initialized
INFO - 2026-08-19 03:21:23 --> Output Class Initialized
INFO - 2026-08-19 03:21:23 --> Security Class Initialized
INFO - 2026-08-19 03:21:23 --> Security Class Initialized
DEBUG - 2026-08-19 03:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-08-19 03:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:21:23 --> CSRF cookie sent
INFO - 2026-08-19 03:21:23 --> CSRF cookie sent
INFO - 2026-08-19 03:21:23 --> Input Class Initialized
INFO - 2026-08-19 03:21:23 --> Input Class Initialized
INFO - 2026-08-19 03:21:23 --> Language Class Initialized
INFO - 2026-08-19 03:21:23 --> Language Class Initialized
INFO - 2026-08-19 03:21:23 --> Language Class Initialized
INFO - 2026-08-19 03:21:23 --> Language Class Initialized
INFO - 2026-08-19 03:21:23 --> Config Class Initialized
INFO - 2026-08-19 03:21:23 --> Config Class Initialized
INFO - 2026-08-19 03:21:23 --> Loader Class Initialized
INFO - 2026-08-19 03:21:23 --> Loader Class Initialized
INFO - 2026-08-19 03:21:23 --> Helper loaded: url_helper
INFO - 2026-08-19 03:21:23 --> Helper loaded: url_helper
INFO - 2026-08-19 03:21:23 --> Helper loaded: form_helper
INFO - 2026-08-19 03:21:23 --> Helper loaded: form_helper
INFO - 2026-08-19 03:21:23 --> Helper loaded: html_helper
INFO - 2026-08-19 03:21:23 --> Helper loaded: html_helper
INFO - 2026-08-19 03:21:23 --> Helper loaded: file_helper
INFO - 2026-08-19 03:21:23 --> Helper loaded: email_helper
INFO - 2026-08-19 03:21:23 --> Helper loaded: file_helper
INFO - 2026-08-19 03:21:23 --> Helper loaded: email_helper
INFO - 2026-08-19 03:21:23 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:21:23 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:21:23 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:21:23 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:21:23 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:21:23 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:21:23 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:21:23 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:21:23 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:21:23 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:21:23 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:21:23 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:21:23 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:21:23 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:21:23 --> Database Driver Class Initialized
INFO - 2026-08-19 03:21:23 --> Database Driver Class Initialized
INFO - 2026-08-19 03:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:21:25 --> Upload Class Initialized
DEBUG - 2026-08-19 03:21:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:21:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:21:25 --> Encryption Class Initialized
INFO - 2026-08-19 03:21:25 --> Form Validation Class Initialized
INFO - 2026-08-19 03:21:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:21:25 --> Pagination Class Initialized
INFO - 2026-08-19 03:21:25 --> Email Class Initialized
INFO - 2026-08-19 03:21:25 --> Controller Class Initialized
DEBUG - 2026-08-19 03:21:25 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:21:25 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:21:25 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:21:25 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:21:25 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:21:26 --> Upload Class Initialized
DEBUG - 2026-08-19 03:21:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:21:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:21:26 --> Encryption Class Initialized
INFO - 2026-08-19 03:21:26 --> Form Validation Class Initialized
INFO - 2026-08-19 03:21:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:21:26 --> Pagination Class Initialized
INFO - 2026-08-19 03:21:26 --> Email Class Initialized
INFO - 2026-08-19 03:21:26 --> Controller Class Initialized
DEBUG - 2026-08-19 03:21:26 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:21:26 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:21:26 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:21:26 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:21:26 --> Model "Common_model" initialized
INFO - 2026-08-19 03:21:26 --> Model "Order_model" initialized
INFO - 2026-08-19 03:21:26 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:21:26 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:21:26 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:21:26 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:21:26 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:21:26 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:21:26 --> Final output sent to browser
DEBUG - 2026-08-19 03:21:26 --> Total execution time: 3.1363
INFO - 2026-08-19 03:21:46 --> Config Class Initialized
INFO - 2026-08-19 03:21:46 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:21:46 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:21:46 --> Utf8 Class Initialized
INFO - 2026-08-19 03:21:46 --> URI Class Initialized
INFO - 2026-08-19 03:21:46 --> Router Class Initialized
INFO - 2026-08-19 03:21:46 --> Output Class Initialized
INFO - 2026-08-19 03:21:46 --> Security Class Initialized
DEBUG - 2026-08-19 03:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:21:46 --> CSRF cookie sent
INFO - 2026-08-19 03:21:46 --> Input Class Initialized
INFO - 2026-08-19 03:21:46 --> Language Class Initialized
INFO - 2026-08-19 03:21:46 --> Language Class Initialized
INFO - 2026-08-19 03:21:46 --> Config Class Initialized
INFO - 2026-08-19 03:21:46 --> Loader Class Initialized
INFO - 2026-08-19 03:21:46 --> Helper loaded: url_helper
INFO - 2026-08-19 03:21:46 --> Helper loaded: form_helper
INFO - 2026-08-19 03:21:46 --> Helper loaded: html_helper
INFO - 2026-08-19 03:21:46 --> Helper loaded: file_helper
INFO - 2026-08-19 03:21:46 --> Helper loaded: email_helper
INFO - 2026-08-19 03:21:46 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:21:46 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:21:46 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:21:46 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:21:46 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:21:46 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:21:46 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:21:46 --> Database Driver Class Initialized
INFO - 2026-08-19 03:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:21:48 --> Upload Class Initialized
DEBUG - 2026-08-19 03:21:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:21:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:21:48 --> Encryption Class Initialized
INFO - 2026-08-19 03:21:48 --> Form Validation Class Initialized
INFO - 2026-08-19 03:21:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:21:48 --> Pagination Class Initialized
INFO - 2026-08-19 03:21:48 --> Email Class Initialized
INFO - 2026-08-19 03:21:48 --> Controller Class Initialized
DEBUG - 2026-08-19 03:21:48 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:21:48 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:21:48 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:21:48 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:21:48 --> Model "Common_model" initialized
INFO - 2026-08-19 03:21:48 --> Model "Order_model" initialized
INFO - 2026-08-19 03:21:48 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:21:48 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:21:48 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:21:48 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:21:48 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:21:48 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:21:49 --> Final output sent to browser
DEBUG - 2026-08-19 03:21:49 --> Total execution time: 2.8771
INFO - 2026-08-19 03:21:49 --> Config Class Initialized
INFO - 2026-08-19 03:21:49 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:21:49 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:21:49 --> Utf8 Class Initialized
INFO - 2026-08-19 03:21:49 --> URI Class Initialized
INFO - 2026-08-19 03:21:49 --> Router Class Initialized
INFO - 2026-08-19 03:21:49 --> Output Class Initialized
INFO - 2026-08-19 03:21:49 --> Security Class Initialized
DEBUG - 2026-08-19 03:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:21:49 --> CSRF cookie sent
INFO - 2026-08-19 03:21:49 --> Input Class Initialized
INFO - 2026-08-19 03:21:49 --> Language Class Initialized
INFO - 2026-08-19 03:21:49 --> Language Class Initialized
INFO - 2026-08-19 03:21:49 --> Config Class Initialized
INFO - 2026-08-19 03:21:49 --> Loader Class Initialized
INFO - 2026-08-19 03:21:49 --> Helper loaded: url_helper
INFO - 2026-08-19 03:21:49 --> Helper loaded: form_helper
INFO - 2026-08-19 03:21:49 --> Helper loaded: html_helper
INFO - 2026-08-19 03:21:49 --> Helper loaded: file_helper
INFO - 2026-08-19 03:21:49 --> Helper loaded: email_helper
INFO - 2026-08-19 03:21:49 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:21:49 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:21:49 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:21:49 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:21:49 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:21:49 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:21:49 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:21:49 --> Database Driver Class Initialized
INFO - 2026-08-19 03:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:21:51 --> Upload Class Initialized
DEBUG - 2026-08-19 03:21:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:21:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:21:51 --> Encryption Class Initialized
INFO - 2026-08-19 03:21:51 --> Form Validation Class Initialized
INFO - 2026-08-19 03:21:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:21:51 --> Pagination Class Initialized
INFO - 2026-08-19 03:21:51 --> Email Class Initialized
INFO - 2026-08-19 03:21:51 --> Controller Class Initialized
DEBUG - 2026-08-19 03:21:51 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:21:51 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:21:51 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:21:51 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:21:51 --> Model "Common_model" initialized
INFO - 2026-08-19 03:21:51 --> Model "Order_model" initialized
INFO - 2026-08-19 03:21:51 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:21:51 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:21:51 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:21:51 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:21:51 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:21:51 --> Model "Orderlicense_model" initialized
DEBUG - 2026-08-19 03:21:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:21:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-08-19 03:21:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-08-19 03:21:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:21:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:21:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/view_card.php
INFO - 2026-08-19 03:21:54 --> Final output sent to browser
DEBUG - 2026-08-19 03:21:54 --> Total execution time: 5.5076
INFO - 2026-08-19 03:21:54 --> Config Class Initialized
INFO - 2026-08-19 03:21:54 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:21:54 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:21:54 --> Utf8 Class Initialized
INFO - 2026-08-19 03:21:54 --> URI Class Initialized
INFO - 2026-08-19 03:21:54 --> Config Class Initialized
INFO - 2026-08-19 03:21:54 --> Hooks Class Initialized
INFO - 2026-08-19 03:21:54 --> Router Class Initialized
DEBUG - 2026-08-19 03:21:54 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:21:54 --> Utf8 Class Initialized
INFO - 2026-08-19 03:21:54 --> Output Class Initialized
INFO - 2026-08-19 03:21:54 --> URI Class Initialized
INFO - 2026-08-19 03:21:54 --> Security Class Initialized
DEBUG - 2026-08-19 03:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:21:54 --> CSRF cookie sent
INFO - 2026-08-19 03:21:54 --> Input Class Initialized
INFO - 2026-08-19 03:21:54 --> Language Class Initialized
INFO - 2026-08-19 03:21:54 --> Router Class Initialized
INFO - 2026-08-19 03:21:54 --> Language Class Initialized
INFO - 2026-08-19 03:21:54 --> Config Class Initialized
INFO - 2026-08-19 03:21:54 --> Output Class Initialized
INFO - 2026-08-19 03:21:54 --> Loader Class Initialized
INFO - 2026-08-19 03:21:54 --> Helper loaded: url_helper
INFO - 2026-08-19 03:21:54 --> Security Class Initialized
INFO - 2026-08-19 03:21:54 --> Helper loaded: form_helper
INFO - 2026-08-19 03:21:54 --> Helper loaded: html_helper
DEBUG - 2026-08-19 03:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:21:54 --> CSRF cookie sent
INFO - 2026-08-19 03:21:54 --> Input Class Initialized
INFO - 2026-08-19 03:21:54 --> Helper loaded: file_helper
INFO - 2026-08-19 03:21:54 --> Helper loaded: email_helper
INFO - 2026-08-19 03:21:54 --> Language Class Initialized
INFO - 2026-08-19 03:21:54 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:21:54 --> Language Class Initialized
INFO - 2026-08-19 03:21:54 --> Config Class Initialized
INFO - 2026-08-19 03:21:54 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:21:54 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:21:54 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:21:54 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:21:54 --> Loader Class Initialized
INFO - 2026-08-19 03:21:54 --> Helper loaded: url_helper
INFO - 2026-08-19 03:21:54 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:21:54 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:21:54 --> Helper loaded: form_helper
INFO - 2026-08-19 03:21:54 --> Helper loaded: html_helper
INFO - 2026-08-19 03:21:54 --> Helper loaded: file_helper
INFO - 2026-08-19 03:21:54 --> Helper loaded: email_helper
INFO - 2026-08-19 03:21:54 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:21:54 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:21:54 --> Database Driver Class Initialized
INFO - 2026-08-19 03:21:54 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:21:54 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:21:54 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:21:54 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:21:54 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:21:54 --> Database Driver Class Initialized
INFO - 2026-08-19 03:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:21:56 --> Upload Class Initialized
DEBUG - 2026-08-19 03:21:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:21:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:21:56 --> Encryption Class Initialized
INFO - 2026-08-19 03:21:56 --> Form Validation Class Initialized
INFO - 2026-08-19 03:21:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:21:56 --> Pagination Class Initialized
INFO - 2026-08-19 03:21:56 --> Email Class Initialized
INFO - 2026-08-19 03:21:56 --> Controller Class Initialized
DEBUG - 2026-08-19 03:21:56 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:21:56 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:21:56 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:21:56 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:21:56 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:21:57 --> Upload Class Initialized
DEBUG - 2026-08-19 03:21:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:21:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:21:57 --> Encryption Class Initialized
INFO - 2026-08-19 03:21:57 --> Form Validation Class Initialized
INFO - 2026-08-19 03:21:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:21:57 --> Pagination Class Initialized
INFO - 2026-08-19 03:21:57 --> Email Class Initialized
INFO - 2026-08-19 03:21:57 --> Controller Class Initialized
DEBUG - 2026-08-19 03:21:57 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:21:57 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:21:57 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:21:57 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:21:57 --> Model "Common_model" initialized
INFO - 2026-08-19 03:21:57 --> Model "Order_model" initialized
INFO - 2026-08-19 03:21:57 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:21:57 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:21:57 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:21:57 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:21:57 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:21:57 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:21:57 --> Final output sent to browser
DEBUG - 2026-08-19 03:21:57 --> Total execution time: 3.0825
INFO - 2026-08-19 03:22:16 --> Config Class Initialized
INFO - 2026-08-19 03:22:16 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:22:16 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:22:16 --> Utf8 Class Initialized
INFO - 2026-08-19 03:22:16 --> URI Class Initialized
INFO - 2026-08-19 03:22:16 --> Router Class Initialized
INFO - 2026-08-19 03:22:16 --> Output Class Initialized
INFO - 2026-08-19 03:22:16 --> Security Class Initialized
DEBUG - 2026-08-19 03:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:22:16 --> CSRF cookie sent
INFO - 2026-08-19 03:22:16 --> Input Class Initialized
INFO - 2026-08-19 03:22:16 --> Language Class Initialized
INFO - 2026-08-19 03:22:16 --> Language Class Initialized
INFO - 2026-08-19 03:22:16 --> Config Class Initialized
INFO - 2026-08-19 03:22:16 --> Loader Class Initialized
INFO - 2026-08-19 03:22:16 --> Helper loaded: url_helper
INFO - 2026-08-19 03:22:16 --> Helper loaded: form_helper
INFO - 2026-08-19 03:22:16 --> Helper loaded: html_helper
INFO - 2026-08-19 03:22:16 --> Helper loaded: file_helper
INFO - 2026-08-19 03:22:16 --> Helper loaded: email_helper
INFO - 2026-08-19 03:22:16 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:22:16 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:22:16 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:22:16 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:22:16 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:22:16 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:22:16 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:22:16 --> Database Driver Class Initialized
INFO - 2026-08-19 03:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:22:18 --> Upload Class Initialized
DEBUG - 2026-08-19 03:22:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:22:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:22:18 --> Encryption Class Initialized
INFO - 2026-08-19 03:22:18 --> Form Validation Class Initialized
INFO - 2026-08-19 03:22:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:22:18 --> Pagination Class Initialized
INFO - 2026-08-19 03:22:18 --> Email Class Initialized
INFO - 2026-08-19 03:22:18 --> Controller Class Initialized
DEBUG - 2026-08-19 03:22:18 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:22:18 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:22:18 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:22:18 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:22:18 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:22:39 --> Config Class Initialized
INFO - 2026-08-19 03:22:39 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:22:39 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:22:39 --> Utf8 Class Initialized
INFO - 2026-08-19 03:22:39 --> URI Class Initialized
INFO - 2026-08-19 03:22:39 --> Router Class Initialized
INFO - 2026-08-19 03:22:39 --> Output Class Initialized
INFO - 2026-08-19 03:22:39 --> Security Class Initialized
DEBUG - 2026-08-19 03:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:22:39 --> CSRF cookie sent
INFO - 2026-08-19 03:22:39 --> Input Class Initialized
INFO - 2026-08-19 03:22:39 --> Language Class Initialized
INFO - 2026-08-19 03:22:39 --> Language Class Initialized
INFO - 2026-08-19 03:22:39 --> Config Class Initialized
INFO - 2026-08-19 03:22:39 --> Loader Class Initialized
INFO - 2026-08-19 03:22:39 --> Helper loaded: url_helper
INFO - 2026-08-19 03:22:39 --> Helper loaded: form_helper
INFO - 2026-08-19 03:22:39 --> Helper loaded: html_helper
INFO - 2026-08-19 03:22:39 --> Helper loaded: file_helper
INFO - 2026-08-19 03:22:39 --> Helper loaded: email_helper
INFO - 2026-08-19 03:22:39 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:22:39 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:22:39 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:22:39 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:22:39 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:22:39 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:22:39 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:22:39 --> Database Driver Class Initialized
INFO - 2026-08-19 03:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:22:41 --> Upload Class Initialized
DEBUG - 2026-08-19 03:22:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:22:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:22:41 --> Encryption Class Initialized
INFO - 2026-08-19 03:22:41 --> Form Validation Class Initialized
INFO - 2026-08-19 03:22:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:22:41 --> Pagination Class Initialized
INFO - 2026-08-19 03:22:41 --> Email Class Initialized
INFO - 2026-08-19 03:22:41 --> Controller Class Initialized
DEBUG - 2026-08-19 03:22:41 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:22:41 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:22:41 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:22:41 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:22:41 --> Model "Common_model" initialized
INFO - 2026-08-19 03:22:41 --> Model "Order_model" initialized
INFO - 2026-08-19 03:22:41 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:22:41 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:22:41 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:22:41 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:22:41 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:22:41 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:22:42 --> Final output sent to browser
DEBUG - 2026-08-19 03:22:42 --> Total execution time: 2.8455
INFO - 2026-08-19 03:22:42 --> Config Class Initialized
INFO - 2026-08-19 03:22:42 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:22:42 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:22:42 --> Utf8 Class Initialized
INFO - 2026-08-19 03:22:42 --> URI Class Initialized
INFO - 2026-08-19 03:22:42 --> Router Class Initialized
INFO - 2026-08-19 03:22:42 --> Output Class Initialized
INFO - 2026-08-19 03:22:42 --> Security Class Initialized
DEBUG - 2026-08-19 03:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:22:42 --> CSRF cookie sent
INFO - 2026-08-19 03:22:42 --> Input Class Initialized
INFO - 2026-08-19 03:22:42 --> Language Class Initialized
INFO - 2026-08-19 03:22:42 --> Language Class Initialized
INFO - 2026-08-19 03:22:42 --> Config Class Initialized
INFO - 2026-08-19 03:22:42 --> Loader Class Initialized
INFO - 2026-08-19 03:22:42 --> Helper loaded: url_helper
INFO - 2026-08-19 03:22:42 --> Helper loaded: form_helper
INFO - 2026-08-19 03:22:42 --> Helper loaded: html_helper
INFO - 2026-08-19 03:22:42 --> Helper loaded: file_helper
INFO - 2026-08-19 03:22:42 --> Helper loaded: email_helper
INFO - 2026-08-19 03:22:42 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:22:42 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:22:42 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:22:42 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:22:42 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:22:42 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:22:42 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:22:42 --> Database Driver Class Initialized
INFO - 2026-08-19 03:22:42 --> Config Class Initialized
INFO - 2026-08-19 03:22:42 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:22:42 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:22:42 --> Utf8 Class Initialized
INFO - 2026-08-19 03:22:42 --> URI Class Initialized
INFO - 2026-08-19 03:22:42 --> Router Class Initialized
INFO - 2026-08-19 03:22:42 --> Output Class Initialized
INFO - 2026-08-19 03:22:42 --> Security Class Initialized
DEBUG - 2026-08-19 03:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:22:42 --> CSRF cookie sent
INFO - 2026-08-19 03:22:42 --> Input Class Initialized
INFO - 2026-08-19 03:22:42 --> Language Class Initialized
INFO - 2026-08-19 03:22:42 --> Language Class Initialized
INFO - 2026-08-19 03:22:42 --> Config Class Initialized
INFO - 2026-08-19 03:22:42 --> Loader Class Initialized
INFO - 2026-08-19 03:22:42 --> Helper loaded: url_helper
INFO - 2026-08-19 03:22:42 --> Helper loaded: form_helper
INFO - 2026-08-19 03:22:42 --> Helper loaded: html_helper
INFO - 2026-08-19 03:22:42 --> Helper loaded: file_helper
INFO - 2026-08-19 03:22:42 --> Helper loaded: email_helper
INFO - 2026-08-19 03:22:42 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:22:42 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:22:42 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:22:42 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:22:42 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:22:42 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:22:42 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:22:42 --> Database Driver Class Initialized
INFO - 2026-08-19 03:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:22:44 --> Upload Class Initialized
DEBUG - 2026-08-19 03:22:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:22:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:22:44 --> Encryption Class Initialized
INFO - 2026-08-19 03:22:44 --> Form Validation Class Initialized
INFO - 2026-08-19 03:22:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:22:44 --> Pagination Class Initialized
INFO - 2026-08-19 03:22:44 --> Email Class Initialized
INFO - 2026-08-19 03:22:44 --> Controller Class Initialized
DEBUG - 2026-08-19 03:22:44 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:22:44 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:22:44 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:22:44 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:22:44 --> Model "Common_model" initialized
INFO - 2026-08-19 03:22:44 --> Model "Order_model" initialized
INFO - 2026-08-19 03:22:44 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:22:44 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:22:44 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:22:44 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:22:44 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:22:44 --> Model "Orderlicense_model" initialized
DEBUG - 2026-08-19 03:22:47 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:22:47 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-08-19 03:22:47 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-08-19 03:22:47 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:22:47 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:22:47 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/view_card.php
INFO - 2026-08-19 03:22:47 --> Final output sent to browser
DEBUG - 2026-08-19 03:22:47 --> Total execution time: 5.3023
INFO - 2026-08-19 03:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:22:47 --> Upload Class Initialized
DEBUG - 2026-08-19 03:22:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:22:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:22:47 --> Encryption Class Initialized
INFO - 2026-08-19 03:22:47 --> Form Validation Class Initialized
INFO - 2026-08-19 03:22:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:22:47 --> Pagination Class Initialized
INFO - 2026-08-19 03:22:47 --> Email Class Initialized
INFO - 2026-08-19 03:22:47 --> Controller Class Initialized
DEBUG - 2026-08-19 03:22:47 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:22:47 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:22:47 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:22:47 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:22:47 --> Model "Common_model" initialized
INFO - 2026-08-19 03:22:47 --> Model "Order_model" initialized
INFO - 2026-08-19 03:22:47 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:22:47 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:22:47 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:22:47 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:22:47 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:22:47 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:22:47 --> Config Class Initialized
INFO - 2026-08-19 03:22:47 --> Hooks Class Initialized
INFO - 2026-08-19 03:22:47 --> Config Class Initialized
INFO - 2026-08-19 03:22:47 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:22:47 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:22:47 --> Utf8 Class Initialized
INFO - 2026-08-19 03:22:47 --> URI Class Initialized
DEBUG - 2026-08-19 03:22:47 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:22:47 --> Utf8 Class Initialized
INFO - 2026-08-19 03:22:47 --> URI Class Initialized
INFO - 2026-08-19 03:22:47 --> Router Class Initialized
INFO - 2026-08-19 03:22:47 --> Router Class Initialized
INFO - 2026-08-19 03:22:47 --> Output Class Initialized
INFO - 2026-08-19 03:22:47 --> Security Class Initialized
INFO - 2026-08-19 03:22:47 --> Output Class Initialized
DEBUG - 2026-08-19 03:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:22:47 --> CSRF cookie sent
INFO - 2026-08-19 03:22:47 --> Input Class Initialized
INFO - 2026-08-19 03:22:47 --> Language Class Initialized
INFO - 2026-08-19 03:22:47 --> Security Class Initialized
DEBUG - 2026-08-19 03:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:22:47 --> CSRF cookie sent
INFO - 2026-08-19 03:22:47 --> Language Class Initialized
INFO - 2026-08-19 03:22:47 --> Input Class Initialized
INFO - 2026-08-19 03:22:47 --> Config Class Initialized
INFO - 2026-08-19 03:22:47 --> Language Class Initialized
INFO - 2026-08-19 03:22:47 --> Language Class Initialized
INFO - 2026-08-19 03:22:47 --> Config Class Initialized
INFO - 2026-08-19 03:22:47 --> Loader Class Initialized
INFO - 2026-08-19 03:22:47 --> Helper loaded: url_helper
INFO - 2026-08-19 03:22:47 --> Loader Class Initialized
INFO - 2026-08-19 03:22:47 --> Helper loaded: form_helper
INFO - 2026-08-19 03:22:47 --> Helper loaded: url_helper
INFO - 2026-08-19 03:22:47 --> Helper loaded: html_helper
INFO - 2026-08-19 03:22:47 --> Helper loaded: file_helper
INFO - 2026-08-19 03:22:47 --> Helper loaded: form_helper
INFO - 2026-08-19 03:22:47 --> Helper loaded: email_helper
INFO - 2026-08-19 03:22:47 --> Helper loaded: html_helper
INFO - 2026-08-19 03:22:47 --> Helper loaded: file_helper
INFO - 2026-08-19 03:22:47 --> Helper loaded: email_helper
INFO - 2026-08-19 03:22:47 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:22:47 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:22:47 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:22:47 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:22:47 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:22:47 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:22:47 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:22:47 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:22:47 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:22:47 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:22:47 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:22:47 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:22:47 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:22:47 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:22:47 --> Database Driver Class Initialized
INFO - 2026-08-19 03:22:47 --> Database Driver Class Initialized
DEBUG - 2026-08-19 03:22:48 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:22:48 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-08-19 03:22:48 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-08-19 03:22:48 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:22:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:22:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/cart_services.php
INFO - 2026-08-19 03:22:49 --> Final output sent to browser
DEBUG - 2026-08-19 03:22:49 --> Total execution time: 7.0413
INFO - 2026-08-19 03:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:22:49 --> Upload Class Initialized
DEBUG - 2026-08-19 03:22:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:22:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:22:49 --> Encryption Class Initialized
INFO - 2026-08-19 03:22:49 --> Form Validation Class Initialized
INFO - 2026-08-19 03:22:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:22:49 --> Pagination Class Initialized
INFO - 2026-08-19 03:22:49 --> Email Class Initialized
INFO - 2026-08-19 03:22:49 --> Controller Class Initialized
DEBUG - 2026-08-19 03:22:49 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:22:49 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:22:49 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:22:49 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:22:49 --> Model "Common_model" initialized
INFO - 2026-08-19 03:22:49 --> Model "Order_model" initialized
INFO - 2026-08-19 03:22:49 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:22:49 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:22:49 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:22:49 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:22:49 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:22:49 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:22:49 --> Config Class Initialized
INFO - 2026-08-19 03:22:49 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:22:49 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:22:49 --> Utf8 Class Initialized
INFO - 2026-08-19 03:22:49 --> URI Class Initialized
INFO - 2026-08-19 03:22:49 --> Router Class Initialized
INFO - 2026-08-19 03:22:49 --> Output Class Initialized
INFO - 2026-08-19 03:22:49 --> Security Class Initialized
DEBUG - 2026-08-19 03:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:22:49 --> CSRF cookie sent
INFO - 2026-08-19 03:22:49 --> Input Class Initialized
INFO - 2026-08-19 03:22:49 --> Language Class Initialized
INFO - 2026-08-19 03:22:49 --> Language Class Initialized
INFO - 2026-08-19 03:22:49 --> Config Class Initialized
INFO - 2026-08-19 03:22:49 --> Loader Class Initialized
INFO - 2026-08-19 03:22:49 --> Helper loaded: url_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: form_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: html_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: file_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: email_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:22:49 --> Database Driver Class Initialized
INFO - 2026-08-19 03:22:49 --> Final output sent to browser
DEBUG - 2026-08-19 03:22:49 --> Total execution time: 2.1870
INFO - 2026-08-19 03:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:22:49 --> Upload Class Initialized
DEBUG - 2026-08-19 03:22:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:22:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:22:49 --> Encryption Class Initialized
INFO - 2026-08-19 03:22:49 --> Form Validation Class Initialized
INFO - 2026-08-19 03:22:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:22:49 --> Pagination Class Initialized
INFO - 2026-08-19 03:22:49 --> Email Class Initialized
INFO - 2026-08-19 03:22:49 --> Config Class Initialized
INFO - 2026-08-19 03:22:49 --> Hooks Class Initialized
INFO - 2026-08-19 03:22:49 --> Controller Class Initialized
DEBUG - 2026-08-19 03:22:49 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:22:49 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:22:49 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:22:49 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:22:49 --> Model "Notification_model" initialized
DEBUG - 2026-08-19 03:22:49 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:22:49 --> Utf8 Class Initialized
INFO - 2026-08-19 03:22:49 --> URI Class Initialized
INFO - 2026-08-19 03:22:49 --> Router Class Initialized
INFO - 2026-08-19 03:22:49 --> Output Class Initialized
INFO - 2026-08-19 03:22:49 --> Security Class Initialized
DEBUG - 2026-08-19 03:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:22:49 --> CSRF cookie sent
INFO - 2026-08-19 03:22:49 --> Input Class Initialized
INFO - 2026-08-19 03:22:49 --> Language Class Initialized
INFO - 2026-08-19 03:22:49 --> Language Class Initialized
INFO - 2026-08-19 03:22:49 --> Config Class Initialized
INFO - 2026-08-19 03:22:49 --> Loader Class Initialized
INFO - 2026-08-19 03:22:49 --> Helper loaded: url_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: form_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: html_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: file_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: email_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:22:49 --> Config Class Initialized
INFO - 2026-08-19 03:22:49 --> Hooks Class Initialized
INFO - 2026-08-19 03:22:49 --> Database Driver Class Initialized
INFO - 2026-08-19 03:22:49 --> Config Class Initialized
INFO - 2026-08-19 03:22:49 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:22:49 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:22:49 --> Utf8 Class Initialized
INFO - 2026-08-19 03:22:49 --> URI Class Initialized
DEBUG - 2026-08-19 03:22:49 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:22:49 --> Utf8 Class Initialized
INFO - 2026-08-19 03:22:49 --> Config Class Initialized
INFO - 2026-08-19 03:22:49 --> Hooks Class Initialized
INFO - 2026-08-19 03:22:49 --> Router Class Initialized
INFO - 2026-08-19 03:22:49 --> URI Class Initialized
DEBUG - 2026-08-19 03:22:49 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:22:49 --> Utf8 Class Initialized
INFO - 2026-08-19 03:22:49 --> URI Class Initialized
INFO - 2026-08-19 03:22:49 --> Router Class Initialized
INFO - 2026-08-19 03:22:49 --> Router Class Initialized
INFO - 2026-08-19 03:22:49 --> Output Class Initialized
INFO - 2026-08-19 03:22:49 --> Output Class Initialized
INFO - 2026-08-19 03:22:49 --> Security Class Initialized
INFO - 2026-08-19 03:22:49 --> Output Class Initialized
DEBUG - 2026-08-19 03:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:22:49 --> Security Class Initialized
INFO - 2026-08-19 03:22:49 --> CSRF cookie sent
INFO - 2026-08-19 03:22:49 --> Input Class Initialized
INFO - 2026-08-19 03:22:49 --> Security Class Initialized
INFO - 2026-08-19 03:22:49 --> Language Class Initialized
DEBUG - 2026-08-19 03:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:22:49 --> CSRF cookie sent
INFO - 2026-08-19 03:22:49 --> Input Class Initialized
DEBUG - 2026-08-19 03:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:22:49 --> CSRF cookie sent
INFO - 2026-08-19 03:22:49 --> Input Class Initialized
INFO - 2026-08-19 03:22:49 --> Language Class Initialized
INFO - 2026-08-19 03:22:49 --> Language Class Initialized
INFO - 2026-08-19 03:22:49 --> Config Class Initialized
INFO - 2026-08-19 03:22:49 --> Language Class Initialized
INFO - 2026-08-19 03:22:49 --> Language Class Initialized
INFO - 2026-08-19 03:22:49 --> Config Class Initialized
INFO - 2026-08-19 03:22:49 --> Language Class Initialized
INFO - 2026-08-19 03:22:49 --> Config Class Initialized
INFO - 2026-08-19 03:22:49 --> Loader Class Initialized
INFO - 2026-08-19 03:22:49 --> Loader Class Initialized
INFO - 2026-08-19 03:22:49 --> Helper loaded: url_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: url_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: form_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: html_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: form_helper
INFO - 2026-08-19 03:22:49 --> Loader Class Initialized
INFO - 2026-08-19 03:22:49 --> Helper loaded: file_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: email_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: html_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: file_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: url_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: email_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: form_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: html_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: file_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: email_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:22:49 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:22:49 --> Database Driver Class Initialized
INFO - 2026-08-19 03:22:49 --> Database Driver Class Initialized
INFO - 2026-08-19 03:22:49 --> Database Driver Class Initialized
INFO - 2026-08-19 03:22:50 --> Config Class Initialized
INFO - 2026-08-19 03:22:50 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:22:50 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:22:50 --> Utf8 Class Initialized
INFO - 2026-08-19 03:22:50 --> URI Class Initialized
INFO - 2026-08-19 03:22:50 --> Router Class Initialized
INFO - 2026-08-19 03:22:50 --> Output Class Initialized
INFO - 2026-08-19 03:22:50 --> Security Class Initialized
DEBUG - 2026-08-19 03:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:22:50 --> CSRF cookie sent
INFO - 2026-08-19 03:22:50 --> Input Class Initialized
INFO - 2026-08-19 03:22:50 --> Language Class Initialized
INFO - 2026-08-19 03:22:50 --> Language Class Initialized
INFO - 2026-08-19 03:22:50 --> Config Class Initialized
INFO - 2026-08-19 03:22:50 --> Loader Class Initialized
INFO - 2026-08-19 03:22:50 --> Helper loaded: url_helper
INFO - 2026-08-19 03:22:50 --> Helper loaded: form_helper
INFO - 2026-08-19 03:22:50 --> Helper loaded: html_helper
INFO - 2026-08-19 03:22:50 --> Helper loaded: file_helper
INFO - 2026-08-19 03:22:50 --> Helper loaded: email_helper
INFO - 2026-08-19 03:22:50 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:22:50 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:22:50 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:22:50 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:22:50 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:22:50 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:22:50 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:22:50 --> Database Driver Class Initialized
INFO - 2026-08-19 03:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:22:51 --> Upload Class Initialized
DEBUG - 2026-08-19 03:22:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:22:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:22:51 --> Encryption Class Initialized
INFO - 2026-08-19 03:22:51 --> Form Validation Class Initialized
INFO - 2026-08-19 03:22:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:22:51 --> Pagination Class Initialized
INFO - 2026-08-19 03:22:51 --> Email Class Initialized
INFO - 2026-08-19 03:22:51 --> Controller Class Initialized
ERROR - 2026-08-19 03:22:51 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:22:51 --> Upload Class Initialized
DEBUG - 2026-08-19 03:22:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:22:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:22:51 --> Encryption Class Initialized
INFO - 2026-08-19 03:22:51 --> Form Validation Class Initialized
INFO - 2026-08-19 03:22:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:22:51 --> Pagination Class Initialized
INFO - 2026-08-19 03:22:51 --> Config Class Initialized
INFO - 2026-08-19 03:22:51 --> Email Class Initialized
INFO - 2026-08-19 03:22:51 --> Hooks Class Initialized
INFO - 2026-08-19 03:22:51 --> Controller Class Initialized
ERROR - 2026-08-19 03:22:51 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:22:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-08-19 03:22:51 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:22:51 --> Utf8 Class Initialized
INFO - 2026-08-19 03:22:51 --> URI Class Initialized
INFO - 2026-08-19 03:22:51 --> Upload Class Initialized
INFO - 2026-08-19 03:22:51 --> Router Class Initialized
DEBUG - 2026-08-19 03:22:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:22:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:22:51 --> Encryption Class Initialized
INFO - 2026-08-19 03:22:51 --> Output Class Initialized
INFO - 2026-08-19 03:22:51 --> Form Validation Class Initialized
INFO - 2026-08-19 03:22:51 --> Security Class Initialized
INFO - 2026-08-19 03:22:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:22:51 --> Pagination Class Initialized
DEBUG - 2026-08-19 03:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:22:51 --> CSRF cookie sent
INFO - 2026-08-19 03:22:51 --> Input Class Initialized
INFO - 2026-08-19 03:22:51 --> Language Class Initialized
INFO - 2026-08-19 03:22:51 --> Language Class Initialized
INFO - 2026-08-19 03:22:51 --> Config Class Initialized
INFO - 2026-08-19 03:22:51 --> Email Class Initialized
INFO - 2026-08-19 03:22:51 --> Controller Class Initialized
ERROR - 2026-08-19 03:22:51 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:22:51 --> Loader Class Initialized
INFO - 2026-08-19 03:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:22:51 --> Helper loaded: url_helper
INFO - 2026-08-19 03:22:51 --> Config Class Initialized
INFO - 2026-08-19 03:22:51 --> Hooks Class Initialized
INFO - 2026-08-19 03:22:51 --> Upload Class Initialized
INFO - 2026-08-19 03:22:51 --> Helper loaded: form_helper
DEBUG - 2026-08-19 03:22:51 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:22:51 --> Utf8 Class Initialized
INFO - 2026-08-19 03:22:51 --> Helper loaded: html_helper
INFO - 2026-08-19 03:22:51 --> URI Class Initialized
DEBUG - 2026-08-19 03:22:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:22:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:22:51 --> Encryption Class Initialized
INFO - 2026-08-19 03:22:51 --> Helper loaded: file_helper
INFO - 2026-08-19 03:22:51 --> Helper loaded: email_helper
INFO - 2026-08-19 03:22:51 --> Router Class Initialized
INFO - 2026-08-19 03:22:51 --> Form Validation Class Initialized
INFO - 2026-08-19 03:22:51 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:22:51 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:22:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:22:51 --> Output Class Initialized
INFO - 2026-08-19 03:22:51 --> Pagination Class Initialized
INFO - 2026-08-19 03:22:51 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:22:51 --> Security Class Initialized
INFO - 2026-08-19 03:22:51 --> Helper loaded: plesk_helper
DEBUG - 2026-08-19 03:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:22:51 --> CSRF cookie sent
INFO - 2026-08-19 03:22:51 --> Input Class Initialized
INFO - 2026-08-19 03:22:51 --> Language Class Initialized
INFO - 2026-08-19 03:22:51 --> Email Class Initialized
INFO - 2026-08-19 03:22:51 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:22:51 --> Controller Class Initialized
INFO - 2026-08-19 03:22:51 --> Language Class Initialized
INFO - 2026-08-19 03:22:51 --> Config Class Initialized
ERROR - 2026-08-19 03:22:51 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:22:51 --> Config Class Initialized
INFO - 2026-08-19 03:22:51 --> Hooks Class Initialized
INFO - 2026-08-19 03:22:51 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:22:51 --> Upload Class Initialized
INFO - 2026-08-19 03:22:51 --> Loader Class Initialized
INFO - 2026-08-19 03:22:51 --> Helper loaded: entitlement_helper
DEBUG - 2026-08-19 03:22:51 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:22:51 --> Utf8 Class Initialized
INFO - 2026-08-19 03:22:51 --> Helper loaded: url_helper
DEBUG - 2026-08-19 03:22:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:22:51 --> URI Class Initialized
INFO - 2026-08-19 03:22:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:22:51 --> Encryption Class Initialized
INFO - 2026-08-19 03:22:51 --> Helper loaded: form_helper
INFO - 2026-08-19 03:22:51 --> Helper loaded: html_helper
INFO - 2026-08-19 03:22:51 --> Form Validation Class Initialized
INFO - 2026-08-19 03:22:51 --> Router Class Initialized
INFO - 2026-08-19 03:22:51 --> Helper loaded: file_helper
INFO - 2026-08-19 03:22:51 --> Helper loaded: email_helper
INFO - 2026-08-19 03:22:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:22:51 --> Pagination Class Initialized
INFO - 2026-08-19 03:22:51 --> Output Class Initialized
INFO - 2026-08-19 03:22:51 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:22:51 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:22:51 --> Database Driver Class Initialized
INFO - 2026-08-19 03:22:51 --> Security Class Initialized
INFO - 2026-08-19 03:22:51 --> Email Class Initialized
INFO - 2026-08-19 03:22:51 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:22:51 --> Controller Class Initialized
ERROR - 2026-08-19 03:22:51 --> 404 Page Not Found: /index
DEBUG - 2026-08-19 03:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:22:51 --> CSRF cookie sent
INFO - 2026-08-19 03:22:51 --> Input Class Initialized
INFO - 2026-08-19 03:22:51 --> Language Class Initialized
INFO - 2026-08-19 03:22:51 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:22:51 --> Language Class Initialized
INFO - 2026-08-19 03:22:51 --> Config Class Initialized
INFO - 2026-08-19 03:22:51 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:22:51 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:22:51 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:22:51 --> Loader Class Initialized
INFO - 2026-08-19 03:22:51 --> Helper loaded: url_helper
INFO - 2026-08-19 03:22:51 --> Helper loaded: form_helper
INFO - 2026-08-19 03:22:51 --> Helper loaded: html_helper
INFO - 2026-08-19 03:22:51 --> Helper loaded: file_helper
INFO - 2026-08-19 03:22:51 --> Helper loaded: email_helper
INFO - 2026-08-19 03:22:51 --> Database Driver Class Initialized
INFO - 2026-08-19 03:22:51 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:22:51 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:22:51 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:22:51 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:22:51 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:22:51 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:22:51 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:22:51 --> Database Driver Class Initialized
INFO - 2026-08-19 03:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:22:52 --> Upload Class Initialized
DEBUG - 2026-08-19 03:22:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:22:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:22:52 --> Encryption Class Initialized
INFO - 2026-08-19 03:22:52 --> Form Validation Class Initialized
INFO - 2026-08-19 03:22:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:22:52 --> Pagination Class Initialized
INFO - 2026-08-19 03:22:52 --> Email Class Initialized
INFO - 2026-08-19 03:22:52 --> Controller Class Initialized
DEBUG - 2026-08-19 03:22:52 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:22:52 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:22:52 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:22:52 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:22:52 --> Model "Common_model" initialized
INFO - 2026-08-19 03:22:52 --> Model "Order_model" initialized
INFO - 2026-08-19 03:22:52 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:22:52 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:22:52 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:22:52 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:22:52 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:22:52 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:22:52 --> Final output sent to browser
DEBUG - 2026-08-19 03:22:52 --> Total execution time: 2.1394
INFO - 2026-08-19 03:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:22:53 --> Upload Class Initialized
DEBUG - 2026-08-19 03:22:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:22:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:22:53 --> Encryption Class Initialized
INFO - 2026-08-19 03:22:53 --> Form Validation Class Initialized
INFO - 2026-08-19 03:22:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:22:53 --> Pagination Class Initialized
INFO - 2026-08-19 03:22:53 --> Email Class Initialized
INFO - 2026-08-19 03:22:53 --> Controller Class Initialized
ERROR - 2026-08-19 03:22:53 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:22:53 --> Upload Class Initialized
DEBUG - 2026-08-19 03:22:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:22:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:22:53 --> Encryption Class Initialized
INFO - 2026-08-19 03:22:53 --> Form Validation Class Initialized
INFO - 2026-08-19 03:22:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:22:53 --> Pagination Class Initialized
INFO - 2026-08-19 03:22:53 --> Email Class Initialized
INFO - 2026-08-19 03:22:53 --> Controller Class Initialized
ERROR - 2026-08-19 03:22:53 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:22:53 --> Upload Class Initialized
DEBUG - 2026-08-19 03:22:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:22:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:22:53 --> Encryption Class Initialized
INFO - 2026-08-19 03:22:53 --> Form Validation Class Initialized
INFO - 2026-08-19 03:22:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:22:53 --> Pagination Class Initialized
INFO - 2026-08-19 03:22:53 --> Email Class Initialized
INFO - 2026-08-19 03:22:53 --> Controller Class Initialized
DEBUG - 2026-08-19 03:22:53 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:22:53 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:22:53 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:22:53 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:22:53 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:23:03 --> Config Class Initialized
INFO - 2026-08-19 03:23:03 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:23:03 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:03 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:03 --> URI Class Initialized
INFO - 2026-08-19 03:23:03 --> Router Class Initialized
INFO - 2026-08-19 03:23:03 --> Output Class Initialized
INFO - 2026-08-19 03:23:03 --> Security Class Initialized
DEBUG - 2026-08-19 03:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:03 --> Input Class Initialized
INFO - 2026-08-19 03:23:03 --> Language Class Initialized
INFO - 2026-08-19 03:23:03 --> Language Class Initialized
INFO - 2026-08-19 03:23:03 --> Config Class Initialized
INFO - 2026-08-19 03:23:03 --> Loader Class Initialized
INFO - 2026-08-19 03:23:03 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:03 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:03 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:03 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:03 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:03 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:03 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:03 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:03 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:03 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:03 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:03 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:03 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:05 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:05 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:05 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:05 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:05 --> Email Class Initialized
INFO - 2026-08-19 03:23:05 --> Controller Class Initialized
DEBUG - 2026-08-19 03:23:05 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:23:05 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:23:05 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:23:05 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:23:05 --> Model "Common_model" initialized
INFO - 2026-08-19 03:23:05 --> Model "Order_model" initialized
INFO - 2026-08-19 03:23:05 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:23:05 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:23:05 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:23:05 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:23:05 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:23:05 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:23:06 --> Final output sent to browser
DEBUG - 2026-08-19 03:23:06 --> Total execution time: 2.7570
INFO - 2026-08-19 03:23:06 --> Config Class Initialized
INFO - 2026-08-19 03:23:06 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:23:06 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:06 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:06 --> URI Class Initialized
INFO - 2026-08-19 03:23:06 --> Router Class Initialized
INFO - 2026-08-19 03:23:06 --> Output Class Initialized
INFO - 2026-08-19 03:23:06 --> Security Class Initialized
DEBUG - 2026-08-19 03:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:06 --> Input Class Initialized
INFO - 2026-08-19 03:23:06 --> Language Class Initialized
INFO - 2026-08-19 03:23:06 --> Language Class Initialized
INFO - 2026-08-19 03:23:06 --> Config Class Initialized
INFO - 2026-08-19 03:23:06 --> Loader Class Initialized
INFO - 2026-08-19 03:23:06 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:06 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:06 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:06 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:06 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:06 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:06 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:06 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:06 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:06 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:06 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:06 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:06 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:08 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:08 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:08 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:08 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:08 --> Email Class Initialized
INFO - 2026-08-19 03:23:08 --> Controller Class Initialized
DEBUG - 2026-08-19 03:23:08 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:23:08 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:23:08 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:23:08 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:23:08 --> Model "Common_model" initialized
INFO - 2026-08-19 03:23:08 --> Model "Order_model" initialized
INFO - 2026-08-19 03:23:08 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:23:08 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:23:08 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:23:08 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:23:08 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:23:08 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:23:09 --> Final output sent to browser
DEBUG - 2026-08-19 03:23:09 --> Total execution time: 3.0663
INFO - 2026-08-19 03:23:09 --> Config Class Initialized
INFO - 2026-08-19 03:23:09 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:23:09 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:09 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:09 --> URI Class Initialized
INFO - 2026-08-19 03:23:09 --> Router Class Initialized
INFO - 2026-08-19 03:23:09 --> Output Class Initialized
INFO - 2026-08-19 03:23:09 --> Security Class Initialized
DEBUG - 2026-08-19 03:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:09 --> CSRF cookie sent
INFO - 2026-08-19 03:23:09 --> Input Class Initialized
INFO - 2026-08-19 03:23:09 --> Language Class Initialized
INFO - 2026-08-19 03:23:09 --> Language Class Initialized
INFO - 2026-08-19 03:23:09 --> Config Class Initialized
INFO - 2026-08-19 03:23:09 --> Loader Class Initialized
INFO - 2026-08-19 03:23:09 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:09 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:09 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:09 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:09 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:09 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:09 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:09 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:09 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:09 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:09 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:09 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:09 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:11 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:11 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:11 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:11 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:11 --> Email Class Initialized
INFO - 2026-08-19 03:23:11 --> Controller Class Initialized
DEBUG - 2026-08-19 03:23:11 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:23:11 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:23:11 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:23:11 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:23:11 --> Model "Common_model" initialized
INFO - 2026-08-19 03:23:11 --> Model "Order_model" initialized
INFO - 2026-08-19 03:23:11 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:23:11 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:23:11 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:23:11 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:23:11 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:23:11 --> Model "Orderlicense_model" initialized
DEBUG - 2026-08-19 03:23:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:23:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-08-19 03:23:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-08-19 03:23:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:23:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:23:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/view_card.php
INFO - 2026-08-19 03:23:14 --> Final output sent to browser
DEBUG - 2026-08-19 03:23:14 --> Total execution time: 5.0998
INFO - 2026-08-19 03:23:14 --> Config Class Initialized
INFO - 2026-08-19 03:23:14 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:23:14 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:14 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:14 --> URI Class Initialized
INFO - 2026-08-19 03:23:14 --> Router Class Initialized
INFO - 2026-08-19 03:23:14 --> Output Class Initialized
INFO - 2026-08-19 03:23:14 --> Security Class Initialized
DEBUG - 2026-08-19 03:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:14 --> CSRF cookie sent
INFO - 2026-08-19 03:23:14 --> Input Class Initialized
INFO - 2026-08-19 03:23:14 --> Language Class Initialized
INFO - 2026-08-19 03:23:14 --> Language Class Initialized
INFO - 2026-08-19 03:23:14 --> Config Class Initialized
INFO - 2026-08-19 03:23:14 --> Loader Class Initialized
INFO - 2026-08-19 03:23:14 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:14 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:14 --> Config Class Initialized
INFO - 2026-08-19 03:23:14 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:23:14 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:14 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:14 --> URI Class Initialized
INFO - 2026-08-19 03:23:14 --> Router Class Initialized
INFO - 2026-08-19 03:23:14 --> Output Class Initialized
INFO - 2026-08-19 03:23:14 --> Security Class Initialized
DEBUG - 2026-08-19 03:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:14 --> CSRF cookie sent
INFO - 2026-08-19 03:23:14 --> Input Class Initialized
INFO - 2026-08-19 03:23:14 --> Language Class Initialized
INFO - 2026-08-19 03:23:14 --> Language Class Initialized
INFO - 2026-08-19 03:23:14 --> Config Class Initialized
INFO - 2026-08-19 03:23:14 --> Loader Class Initialized
INFO - 2026-08-19 03:23:14 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:14 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:14 --> Config Class Initialized
INFO - 2026-08-19 03:23:14 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:23:14 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:14 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:14 --> URI Class Initialized
INFO - 2026-08-19 03:23:14 --> Config Class Initialized
INFO - 2026-08-19 03:23:14 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:23:14 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:14 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:14 --> URI Class Initialized
INFO - 2026-08-19 03:23:14 --> Router Class Initialized
INFO - 2026-08-19 03:23:14 --> Config Class Initialized
INFO - 2026-08-19 03:23:14 --> Hooks Class Initialized
INFO - 2026-08-19 03:23:14 --> Output Class Initialized
DEBUG - 2026-08-19 03:23:14 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:14 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:14 --> Security Class Initialized
INFO - 2026-08-19 03:23:14 --> URI Class Initialized
DEBUG - 2026-08-19 03:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:14 --> CSRF cookie sent
INFO - 2026-08-19 03:23:14 --> Input Class Initialized
INFO - 2026-08-19 03:23:14 --> Language Class Initialized
INFO - 2026-08-19 03:23:14 --> Config Class Initialized
INFO - 2026-08-19 03:23:14 --> Hooks Class Initialized
INFO - 2026-08-19 03:23:14 --> Language Class Initialized
INFO - 2026-08-19 03:23:14 --> Config Class Initialized
INFO - 2026-08-19 03:23:14 --> Router Class Initialized
INFO - 2026-08-19 03:23:14 --> Output Class Initialized
INFO - 2026-08-19 03:23:14 --> Router Class Initialized
INFO - 2026-08-19 03:23:14 --> Security Class Initialized
INFO - 2026-08-19 03:23:14 --> Output Class Initialized
DEBUG - 2026-08-19 03:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:14 --> Loader Class Initialized
INFO - 2026-08-19 03:23:14 --> Security Class Initialized
INFO - 2026-08-19 03:23:14 --> CSRF cookie sent
INFO - 2026-08-19 03:23:14 --> Input Class Initialized
INFO - 2026-08-19 03:23:14 --> Language Class Initialized
DEBUG - 2026-08-19 03:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:14 --> CSRF cookie sent
INFO - 2026-08-19 03:23:14 --> Input Class Initialized
INFO - 2026-08-19 03:23:14 --> Language Class Initialized
INFO - 2026-08-19 03:23:14 --> Language Class Initialized
INFO - 2026-08-19 03:23:14 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:14 --> Language Class Initialized
INFO - 2026-08-19 03:23:14 --> Config Class Initialized
INFO - 2026-08-19 03:23:14 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:14 --> Config Class Initialized
INFO - 2026-08-19 03:23:14 --> Loader Class Initialized
INFO - 2026-08-19 03:23:14 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:14 --> Loader Class Initialized
INFO - 2026-08-19 03:23:14 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: ssp_helper
DEBUG - 2026-08-19 03:23:14 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:14 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:14 --> URI Class Initialized
INFO - 2026-08-19 03:23:14 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:14 --> Router Class Initialized
INFO - 2026-08-19 03:23:14 --> Output Class Initialized
INFO - 2026-08-19 03:23:14 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:14 --> Security Class Initialized
DEBUG - 2026-08-19 03:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:14 --> CSRF cookie sent
INFO - 2026-08-19 03:23:14 --> Input Class Initialized
INFO - 2026-08-19 03:23:14 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:14 --> Language Class Initialized
INFO - 2026-08-19 03:23:14 --> Language Class Initialized
INFO - 2026-08-19 03:23:14 --> Config Class Initialized
INFO - 2026-08-19 03:23:14 --> Loader Class Initialized
INFO - 2026-08-19 03:23:14 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:14 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:14 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:14 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:14 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:14 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:14 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:14 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:14 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:16 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:16 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:16 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:16 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:16 --> Email Class Initialized
INFO - 2026-08-19 03:23:16 --> Controller Class Initialized
ERROR - 2026-08-19 03:23:16 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:23:16 --> Config Class Initialized
INFO - 2026-08-19 03:23:16 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:23:16 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:16 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:16 --> URI Class Initialized
INFO - 2026-08-19 03:23:16 --> Router Class Initialized
INFO - 2026-08-19 03:23:16 --> Output Class Initialized
INFO - 2026-08-19 03:23:16 --> Security Class Initialized
DEBUG - 2026-08-19 03:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:16 --> CSRF cookie sent
INFO - 2026-08-19 03:23:16 --> Input Class Initialized
INFO - 2026-08-19 03:23:16 --> Language Class Initialized
INFO - 2026-08-19 03:23:16 --> Language Class Initialized
INFO - 2026-08-19 03:23:16 --> Config Class Initialized
INFO - 2026-08-19 03:23:16 --> Loader Class Initialized
INFO - 2026-08-19 03:23:16 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:16 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:16 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:16 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:16 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:16 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:16 --> Email Class Initialized
INFO - 2026-08-19 03:23:16 --> Controller Class Initialized
ERROR - 2026-08-19 03:23:16 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:16 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:16 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:16 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:16 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:16 --> Config Class Initialized
INFO - 2026-08-19 03:23:16 --> Hooks Class Initialized
INFO - 2026-08-19 03:23:16 --> Email Class Initialized
INFO - 2026-08-19 03:23:16 --> Controller Class Initialized
ERROR - 2026-08-19 03:23:16 --> 404 Page Not Found: /index
DEBUG - 2026-08-19 03:23:16 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:16 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:16 --> URI Class Initialized
INFO - 2026-08-19 03:23:16 --> Router Class Initialized
INFO - 2026-08-19 03:23:16 --> Output Class Initialized
INFO - 2026-08-19 03:23:16 --> Security Class Initialized
DEBUG - 2026-08-19 03:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:16 --> CSRF cookie sent
INFO - 2026-08-19 03:23:16 --> Input Class Initialized
INFO - 2026-08-19 03:23:16 --> Language Class Initialized
INFO - 2026-08-19 03:23:16 --> Language Class Initialized
INFO - 2026-08-19 03:23:16 --> Config Class Initialized
INFO - 2026-08-19 03:23:16 --> Config Class Initialized
INFO - 2026-08-19 03:23:16 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:23:16 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:16 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:16 --> Loader Class Initialized
INFO - 2026-08-19 03:23:16 --> URI Class Initialized
INFO - 2026-08-19 03:23:16 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:16 --> Router Class Initialized
INFO - 2026-08-19 03:23:16 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:16 --> Output Class Initialized
INFO - 2026-08-19 03:23:16 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:16 --> Security Class Initialized
INFO - 2026-08-19 03:23:16 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: ssp_helper
DEBUG - 2026-08-19 03:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:16 --> CSRF cookie sent
INFO - 2026-08-19 03:23:16 --> Input Class Initialized
INFO - 2026-08-19 03:23:16 --> Language Class Initialized
INFO - 2026-08-19 03:23:16 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:16 --> Language Class Initialized
INFO - 2026-08-19 03:23:16 --> Config Class Initialized
INFO - 2026-08-19 03:23:16 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:16 --> Loader Class Initialized
INFO - 2026-08-19 03:23:16 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:16 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:16 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:16 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:16 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:16 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:16 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:16 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:16 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:16 --> Email Class Initialized
INFO - 2026-08-19 03:23:16 --> Controller Class Initialized
ERROR - 2026-08-19 03:23:16 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:17 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:17 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:17 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:17 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:17 --> Email Class Initialized
INFO - 2026-08-19 03:23:17 --> Controller Class Initialized
ERROR - 2026-08-19 03:23:17 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:17 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:17 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:17 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:17 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:17 --> Email Class Initialized
INFO - 2026-08-19 03:23:17 --> Controller Class Initialized
ERROR - 2026-08-19 03:23:17 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:17 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:17 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:17 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:17 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:17 --> Email Class Initialized
INFO - 2026-08-19 03:23:17 --> Controller Class Initialized
DEBUG - 2026-08-19 03:23:17 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:23:17 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:23:17 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:23:17 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:23:17 --> Model "Common_model" initialized
INFO - 2026-08-19 03:23:17 --> Model "Order_model" initialized
INFO - 2026-08-19 03:23:17 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:23:17 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:23:17 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:23:17 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:23:17 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:23:17 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:23:18 --> Final output sent to browser
DEBUG - 2026-08-19 03:23:18 --> Total execution time: 1.8764
INFO - 2026-08-19 03:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:18 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:18 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:18 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:18 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:18 --> Email Class Initialized
INFO - 2026-08-19 03:23:18 --> Controller Class Initialized
DEBUG - 2026-08-19 03:23:18 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:23:18 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:23:18 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:23:18 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:23:18 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:18 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:18 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:18 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:18 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:19 --> Email Class Initialized
INFO - 2026-08-19 03:23:19 --> Controller Class Initialized
ERROR - 2026-08-19 03:23:19 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:23:35 --> Config Class Initialized
INFO - 2026-08-19 03:23:35 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:23:35 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:35 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:35 --> URI Class Initialized
INFO - 2026-08-19 03:23:35 --> Router Class Initialized
INFO - 2026-08-19 03:23:35 --> Output Class Initialized
INFO - 2026-08-19 03:23:35 --> Security Class Initialized
DEBUG - 2026-08-19 03:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:35 --> CSRF cookie sent
INFO - 2026-08-19 03:23:35 --> Input Class Initialized
INFO - 2026-08-19 03:23:35 --> Language Class Initialized
INFO - 2026-08-19 03:23:35 --> Language Class Initialized
INFO - 2026-08-19 03:23:35 --> Config Class Initialized
INFO - 2026-08-19 03:23:35 --> Loader Class Initialized
INFO - 2026-08-19 03:23:35 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:35 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:35 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:35 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:35 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:35 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:35 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:35 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:35 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:35 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:35 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:35 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:35 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:37 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:37 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:37 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:37 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:37 --> Email Class Initialized
INFO - 2026-08-19 03:23:37 --> Controller Class Initialized
DEBUG - 2026-08-19 03:23:37 --> Invoicing MX_Controller Initialized
INFO - 2026-08-19 03:23:37 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:23:37 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:23:37 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:23:37 --> Model "Billing_model" initialized
INFO - 2026-08-19 03:23:37 --> Model "Common_model" initialized
INFO - 2026-08-19 03:23:37 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-19 03:23:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:23:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-08-19 03:23:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:23:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:23:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/invoicing/views/invoicing_invoices.php
INFO - 2026-08-19 03:23:39 --> Final output sent to browser
DEBUG - 2026-08-19 03:23:39 --> Total execution time: 3.8703
INFO - 2026-08-19 03:23:39 --> Config Class Initialized
INFO - 2026-08-19 03:23:39 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:23:39 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:39 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:39 --> URI Class Initialized
INFO - 2026-08-19 03:23:39 --> Router Class Initialized
INFO - 2026-08-19 03:23:39 --> Output Class Initialized
INFO - 2026-08-19 03:23:39 --> Security Class Initialized
DEBUG - 2026-08-19 03:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:39 --> CSRF cookie sent
INFO - 2026-08-19 03:23:39 --> Input Class Initialized
INFO - 2026-08-19 03:23:39 --> Language Class Initialized
INFO - 2026-08-19 03:23:39 --> Language Class Initialized
INFO - 2026-08-19 03:23:39 --> Config Class Initialized
INFO - 2026-08-19 03:23:39 --> Loader Class Initialized
INFO - 2026-08-19 03:23:39 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:39 --> Config Class Initialized
INFO - 2026-08-19 03:23:39 --> Hooks Class Initialized
INFO - 2026-08-19 03:23:39 --> Helper loaded: cpanel_helper
DEBUG - 2026-08-19 03:23:39 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:39 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:39 --> URI Class Initialized
INFO - 2026-08-19 03:23:39 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:39 --> Config Class Initialized
INFO - 2026-08-19 03:23:39 --> Hooks Class Initialized
INFO - 2026-08-19 03:23:39 --> Helper loaded: directadmin_helper
DEBUG - 2026-08-19 03:23:39 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:39 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:39 --> Router Class Initialized
INFO - 2026-08-19 03:23:39 --> URI Class Initialized
INFO - 2026-08-19 03:23:39 --> Router Class Initialized
INFO - 2026-08-19 03:23:39 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:39 --> Output Class Initialized
INFO - 2026-08-19 03:23:39 --> Output Class Initialized
INFO - 2026-08-19 03:23:39 --> Security Class Initialized
INFO - 2026-08-19 03:23:39 --> Security Class Initialized
DEBUG - 2026-08-19 03:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:39 --> CSRF cookie sent
INFO - 2026-08-19 03:23:39 --> Input Class Initialized
INFO - 2026-08-19 03:23:39 --> Language Class Initialized
DEBUG - 2026-08-19 03:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:39 --> CSRF cookie sent
INFO - 2026-08-19 03:23:39 --> Input Class Initialized
INFO - 2026-08-19 03:23:39 --> Language Class Initialized
INFO - 2026-08-19 03:23:39 --> Language Class Initialized
INFO - 2026-08-19 03:23:39 --> Config Class Initialized
INFO - 2026-08-19 03:23:39 --> Language Class Initialized
INFO - 2026-08-19 03:23:39 --> Config Class Initialized
INFO - 2026-08-19 03:23:39 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:39 --> Loader Class Initialized
INFO - 2026-08-19 03:23:39 --> Loader Class Initialized
INFO - 2026-08-19 03:23:39 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:39 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:39 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:39 --> Config Class Initialized
INFO - 2026-08-19 03:23:39 --> Config Class Initialized
INFO - 2026-08-19 03:23:39 --> Hooks Class Initialized
INFO - 2026-08-19 03:23:39 --> Config Class Initialized
INFO - 2026-08-19 03:23:39 --> Hooks Class Initialized
INFO - 2026-08-19 03:23:39 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:23:39 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:39 --> Utf8 Class Initialized
DEBUG - 2026-08-19 03:23:39 --> UTF-8 Support Enabled
DEBUG - 2026-08-19 03:23:39 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:39 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:39 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:39 --> URI Class Initialized
INFO - 2026-08-19 03:23:39 --> URI Class Initialized
INFO - 2026-08-19 03:23:39 --> URI Class Initialized
INFO - 2026-08-19 03:23:39 --> Router Class Initialized
INFO - 2026-08-19 03:23:39 --> Router Class Initialized
INFO - 2026-08-19 03:23:39 --> Output Class Initialized
INFO - 2026-08-19 03:23:39 --> Router Class Initialized
INFO - 2026-08-19 03:23:39 --> Security Class Initialized
INFO - 2026-08-19 03:23:39 --> Output Class Initialized
DEBUG - 2026-08-19 03:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:39 --> Output Class Initialized
INFO - 2026-08-19 03:23:39 --> CSRF cookie sent
INFO - 2026-08-19 03:23:39 --> Input Class Initialized
INFO - 2026-08-19 03:23:39 --> Security Class Initialized
INFO - 2026-08-19 03:23:39 --> Language Class Initialized
DEBUG - 2026-08-19 03:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:39 --> CSRF cookie sent
INFO - 2026-08-19 03:23:39 --> Security Class Initialized
INFO - 2026-08-19 03:23:39 --> Input Class Initialized
INFO - 2026-08-19 03:23:39 --> Language Class Initialized
INFO - 2026-08-19 03:23:39 --> Config Class Initialized
INFO - 2026-08-19 03:23:39 --> Language Class Initialized
DEBUG - 2026-08-19 03:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:39 --> CSRF cookie sent
INFO - 2026-08-19 03:23:39 --> Input Class Initialized
INFO - 2026-08-19 03:23:39 --> Language Class Initialized
INFO - 2026-08-19 03:23:39 --> Config Class Initialized
INFO - 2026-08-19 03:23:39 --> Language Class Initialized
INFO - 2026-08-19 03:23:39 --> Loader Class Initialized
INFO - 2026-08-19 03:23:39 --> Language Class Initialized
INFO - 2026-08-19 03:23:39 --> Config Class Initialized
INFO - 2026-08-19 03:23:39 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:39 --> Loader Class Initialized
INFO - 2026-08-19 03:23:39 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:39 --> Loader Class Initialized
INFO - 2026-08-19 03:23:39 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:39 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:39 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:39 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:39 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:39 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:41 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:41 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:41 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:41 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:41 --> Email Class Initialized
INFO - 2026-08-19 03:23:41 --> Controller Class Initialized
ERROR - 2026-08-19 03:23:41 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:41 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:41 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:41 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:41 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:41 --> Email Class Initialized
INFO - 2026-08-19 03:23:41 --> Controller Class Initialized
ERROR - 2026-08-19 03:23:41 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:41 --> Config Class Initialized
INFO - 2026-08-19 03:23:41 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:23:41 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:41 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:41 --> Upload Class Initialized
INFO - 2026-08-19 03:23:41 --> URI Class Initialized
DEBUG - 2026-08-19 03:23:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:41 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:41 --> Router Class Initialized
INFO - 2026-08-19 03:23:41 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:41 --> Output Class Initialized
INFO - 2026-08-19 03:23:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:41 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:41 --> Config Class Initialized
INFO - 2026-08-19 03:23:41 --> Hooks Class Initialized
INFO - 2026-08-19 03:23:41 --> Security Class Initialized
DEBUG - 2026-08-19 03:23:41 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:41 --> Utf8 Class Initialized
DEBUG - 2026-08-19 03:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:41 --> CSRF cookie sent
INFO - 2026-08-19 03:23:41 --> Input Class Initialized
INFO - 2026-08-19 03:23:41 --> Language Class Initialized
INFO - 2026-08-19 03:23:41 --> URI Class Initialized
INFO - 2026-08-19 03:23:41 --> Language Class Initialized
INFO - 2026-08-19 03:23:41 --> Config Class Initialized
INFO - 2026-08-19 03:23:41 --> Email Class Initialized
INFO - 2026-08-19 03:23:41 --> Router Class Initialized
INFO - 2026-08-19 03:23:41 --> Controller Class Initialized
ERROR - 2026-08-19 03:23:41 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:23:41 --> Output Class Initialized
INFO - 2026-08-19 03:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:41 --> Security Class Initialized
INFO - 2026-08-19 03:23:41 --> Loader Class Initialized
INFO - 2026-08-19 03:23:41 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:41 --> CSRF cookie sent
INFO - 2026-08-19 03:23:41 --> Input Class Initialized
INFO - 2026-08-19 03:23:41 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:41 --> Language Class Initialized
DEBUG - 2026-08-19 03:23:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:41 --> Language Class Initialized
INFO - 2026-08-19 03:23:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:41 --> Config Class Initialized
INFO - 2026-08-19 03:23:41 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:41 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:41 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:41 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:41 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:41 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:41 --> Loader Class Initialized
INFO - 2026-08-19 03:23:41 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:41 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:41 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:41 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:41 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:41 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:41 --> Email Class Initialized
INFO - 2026-08-19 03:23:41 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:41 --> Controller Class Initialized
INFO - 2026-08-19 03:23:41 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:41 --> Helper loaded: email_helper
ERROR - 2026-08-19 03:23:41 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:23:41 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:41 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:41 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:41 --> Config Class Initialized
INFO - 2026-08-19 03:23:41 --> Hooks Class Initialized
INFO - 2026-08-19 03:23:41 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:41 --> Helper loaded: cpanel_helper
DEBUG - 2026-08-19 03:23:41 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:41 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:41 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:41 --> URI Class Initialized
INFO - 2026-08-19 03:23:41 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:41 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:41 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:41 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:41 --> Router Class Initialized
INFO - 2026-08-19 03:23:41 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:41 --> Output Class Initialized
INFO - 2026-08-19 03:23:41 --> Security Class Initialized
DEBUG - 2026-08-19 03:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:41 --> CSRF cookie sent
INFO - 2026-08-19 03:23:41 --> Input Class Initialized
INFO - 2026-08-19 03:23:41 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:41 --> Language Class Initialized
INFO - 2026-08-19 03:23:41 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:41 --> Language Class Initialized
INFO - 2026-08-19 03:23:41 --> Config Class Initialized
INFO - 2026-08-19 03:23:41 --> Loader Class Initialized
INFO - 2026-08-19 03:23:41 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:41 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:41 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:41 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:41 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:41 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:41 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:41 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:41 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:41 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:41 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:41 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:41 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:41 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:41 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:41 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:41 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:41 --> Email Class Initialized
INFO - 2026-08-19 03:23:41 --> Controller Class Initialized
ERROR - 2026-08-19 03:23:41 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:41 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:41 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:41 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:41 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:41 --> Email Class Initialized
INFO - 2026-08-19 03:23:41 --> Controller Class Initialized
ERROR - 2026-08-19 03:23:41 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:42 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:42 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:42 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:42 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:42 --> Email Class Initialized
INFO - 2026-08-19 03:23:42 --> Controller Class Initialized
DEBUG - 2026-08-19 03:23:42 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:23:42 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:23:42 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:23:42 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:23:42 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:23:42 --> Config Class Initialized
INFO - 2026-08-19 03:23:42 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:23:42 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:42 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:42 --> URI Class Initialized
INFO - 2026-08-19 03:23:42 --> Router Class Initialized
INFO - 2026-08-19 03:23:42 --> Output Class Initialized
INFO - 2026-08-19 03:23:42 --> Security Class Initialized
DEBUG - 2026-08-19 03:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:42 --> CSRF cookie sent
INFO - 2026-08-19 03:23:42 --> Input Class Initialized
INFO - 2026-08-19 03:23:42 --> Language Class Initialized
INFO - 2026-08-19 03:23:42 --> Language Class Initialized
INFO - 2026-08-19 03:23:42 --> Config Class Initialized
INFO - 2026-08-19 03:23:42 --> Loader Class Initialized
INFO - 2026-08-19 03:23:42 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:42 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:42 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:42 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:42 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:42 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:42 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:42 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:42 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:42 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:42 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:42 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:42 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:43 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:43 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:43 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:43 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:43 --> Email Class Initialized
INFO - 2026-08-19 03:23:43 --> Controller Class Initialized
ERROR - 2026-08-19 03:23:43 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:43 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:43 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:43 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:43 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:43 --> Email Class Initialized
INFO - 2026-08-19 03:23:43 --> Controller Class Initialized
DEBUG - 2026-08-19 03:23:43 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:23:43 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:23:43 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:23:43 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:23:43 --> Model "Common_model" initialized
INFO - 2026-08-19 03:23:43 --> Model "Order_model" initialized
INFO - 2026-08-19 03:23:43 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:23:43 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:23:43 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:23:43 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:23:43 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:23:43 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:23:43 --> Final output sent to browser
DEBUG - 2026-08-19 03:23:43 --> Total execution time: 2.7726
INFO - 2026-08-19 03:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:44 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:44 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:44 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:44 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:44 --> Email Class Initialized
INFO - 2026-08-19 03:23:44 --> Controller Class Initialized
DEBUG - 2026-08-19 03:23:44 --> Invoicing MX_Controller Initialized
INFO - 2026-08-19 03:23:44 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:23:44 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:23:44 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:23:44 --> Model "Billing_model" initialized
INFO - 2026-08-19 03:23:44 --> Model "Common_model" initialized
INFO - 2026-08-19 03:23:44 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-19 03:23:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/invoicing/views/invoicing_invoice_pdf_html.php
DEBUG - 2026-08-19 03:23:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:23:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-08-19 03:23:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:23:47 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:23:47 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/invoicing/views/invoicing_viewinvoice.php
INFO - 2026-08-19 03:23:47 --> Final output sent to browser
DEBUG - 2026-08-19 03:23:47 --> Total execution time: 4.2209
INFO - 2026-08-19 03:23:47 --> Config Class Initialized
INFO - 2026-08-19 03:23:47 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:23:47 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:47 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:47 --> URI Class Initialized
INFO - 2026-08-19 03:23:47 --> Router Class Initialized
INFO - 2026-08-19 03:23:47 --> Output Class Initialized
INFO - 2026-08-19 03:23:47 --> Security Class Initialized
DEBUG - 2026-08-19 03:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:47 --> CSRF cookie sent
INFO - 2026-08-19 03:23:47 --> Input Class Initialized
INFO - 2026-08-19 03:23:47 --> Language Class Initialized
INFO - 2026-08-19 03:23:47 --> Language Class Initialized
INFO - 2026-08-19 03:23:47 --> Config Class Initialized
INFO - 2026-08-19 03:23:47 --> Loader Class Initialized
INFO - 2026-08-19 03:23:47 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:47 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:47 --> Config Class Initialized
INFO - 2026-08-19 03:23:47 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:23:47 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:47 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:47 --> URI Class Initialized
INFO - 2026-08-19 03:23:47 --> Config Class Initialized
INFO - 2026-08-19 03:23:47 --> Hooks Class Initialized
INFO - 2026-08-19 03:23:47 --> Router Class Initialized
INFO - 2026-08-19 03:23:47 --> Output Class Initialized
DEBUG - 2026-08-19 03:23:47 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:47 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:47 --> URI Class Initialized
INFO - 2026-08-19 03:23:47 --> Security Class Initialized
DEBUG - 2026-08-19 03:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:47 --> CSRF cookie sent
INFO - 2026-08-19 03:23:47 --> Input Class Initialized
INFO - 2026-08-19 03:23:47 --> Language Class Initialized
INFO - 2026-08-19 03:23:47 --> Language Class Initialized
INFO - 2026-08-19 03:23:47 --> Config Class Initialized
INFO - 2026-08-19 03:23:47 --> Config Class Initialized
INFO - 2026-08-19 03:23:47 --> Hooks Class Initialized
INFO - 2026-08-19 03:23:47 --> Loader Class Initialized
INFO - 2026-08-19 03:23:47 --> Router Class Initialized
DEBUG - 2026-08-19 03:23:47 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:47 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:47 --> Output Class Initialized
INFO - 2026-08-19 03:23:47 --> URI Class Initialized
INFO - 2026-08-19 03:23:47 --> Security Class Initialized
INFO - 2026-08-19 03:23:47 --> Config Class Initialized
INFO - 2026-08-19 03:23:47 --> Hooks Class Initialized
INFO - 2026-08-19 03:23:47 --> Router Class Initialized
DEBUG - 2026-08-19 03:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:47 --> CSRF cookie sent
INFO - 2026-08-19 03:23:47 --> Input Class Initialized
INFO - 2026-08-19 03:23:47 --> Language Class Initialized
DEBUG - 2026-08-19 03:23:47 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:47 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:47 --> Output Class Initialized
INFO - 2026-08-19 03:23:47 --> Language Class Initialized
INFO - 2026-08-19 03:23:47 --> Config Class Initialized
INFO - 2026-08-19 03:23:47 --> URI Class Initialized
INFO - 2026-08-19 03:23:47 --> Security Class Initialized
INFO - 2026-08-19 03:23:47 --> Helper loaded: url_helper
DEBUG - 2026-08-19 03:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:47 --> CSRF cookie sent
INFO - 2026-08-19 03:23:47 --> Input Class Initialized
INFO - 2026-08-19 03:23:47 --> Router Class Initialized
INFO - 2026-08-19 03:23:47 --> Language Class Initialized
INFO - 2026-08-19 03:23:47 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:47 --> Language Class Initialized
INFO - 2026-08-19 03:23:47 --> Config Class Initialized
INFO - 2026-08-19 03:23:47 --> Output Class Initialized
INFO - 2026-08-19 03:23:47 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:47 --> Loader Class Initialized
INFO - 2026-08-19 03:23:47 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:47 --> Loader Class Initialized
INFO - 2026-08-19 03:23:47 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:47 --> Security Class Initialized
INFO - 2026-08-19 03:23:47 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: whmaz_helper
DEBUG - 2026-08-19 03:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:47 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:47 --> CSRF cookie sent
INFO - 2026-08-19 03:23:47 --> Input Class Initialized
INFO - 2026-08-19 03:23:47 --> Language Class Initialized
INFO - 2026-08-19 03:23:47 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:47 --> Language Class Initialized
INFO - 2026-08-19 03:23:47 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:47 --> Config Class Initialized
INFO - 2026-08-19 03:23:47 --> Hooks Class Initialized
INFO - 2026-08-19 03:23:47 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: entitlement_helper
DEBUG - 2026-08-19 03:23:47 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:47 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:47 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:47 --> URI Class Initialized
INFO - 2026-08-19 03:23:47 --> Config Class Initialized
INFO - 2026-08-19 03:23:47 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:47 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:47 --> Loader Class Initialized
INFO - 2026-08-19 03:23:47 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:47 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:47 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:47 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:47 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:47 --> Router Class Initialized
INFO - 2026-08-19 03:23:47 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:47 --> Output Class Initialized
INFO - 2026-08-19 03:23:47 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:47 --> Security Class Initialized
INFO - 2026-08-19 03:23:47 --> Helper loaded: cpanel_helper
DEBUG - 2026-08-19 03:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:47 --> CSRF cookie sent
INFO - 2026-08-19 03:23:47 --> Input Class Initialized
INFO - 2026-08-19 03:23:47 --> Language Class Initialized
INFO - 2026-08-19 03:23:47 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:47 --> Language Class Initialized
INFO - 2026-08-19 03:23:47 --> Config Class Initialized
INFO - 2026-08-19 03:23:47 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:47 --> Loader Class Initialized
INFO - 2026-08-19 03:23:47 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:47 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:47 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:47 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:47 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:48 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:48 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:48 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:48 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:48 --> Email Class Initialized
INFO - 2026-08-19 03:23:48 --> Controller Class Initialized
ERROR - 2026-08-19 03:23:48 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:48 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:48 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:48 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:48 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:48 --> Config Class Initialized
INFO - 2026-08-19 03:23:48 --> Email Class Initialized
INFO - 2026-08-19 03:23:48 --> Hooks Class Initialized
INFO - 2026-08-19 03:23:48 --> Controller Class Initialized
ERROR - 2026-08-19 03:23:48 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:23:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-08-19 03:23:48 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:48 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:48 --> URI Class Initialized
INFO - 2026-08-19 03:23:48 --> Upload Class Initialized
INFO - 2026-08-19 03:23:48 --> Router Class Initialized
DEBUG - 2026-08-19 03:23:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:48 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:48 --> Output Class Initialized
INFO - 2026-08-19 03:23:48 --> Security Class Initialized
DEBUG - 2026-08-19 03:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:48 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:48 --> CSRF cookie sent
INFO - 2026-08-19 03:23:48 --> Input Class Initialized
INFO - 2026-08-19 03:23:48 --> Language Class Initialized
INFO - 2026-08-19 03:23:48 --> Config Class Initialized
INFO - 2026-08-19 03:23:48 --> Hooks Class Initialized
INFO - 2026-08-19 03:23:48 --> Language Class Initialized
INFO - 2026-08-19 03:23:48 --> Config Class Initialized
INFO - 2026-08-19 03:23:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:48 --> Pagination Class Initialized
DEBUG - 2026-08-19 03:23:48 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:48 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:48 --> URI Class Initialized
INFO - 2026-08-19 03:23:48 --> Loader Class Initialized
INFO - 2026-08-19 03:23:48 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:48 --> Router Class Initialized
INFO - 2026-08-19 03:23:48 --> Email Class Initialized
INFO - 2026-08-19 03:23:48 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:48 --> Controller Class Initialized
INFO - 2026-08-19 03:23:48 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:48 --> Output Class Initialized
ERROR - 2026-08-19 03:23:48 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:23:48 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:48 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:48 --> Security Class Initialized
INFO - 2026-08-19 03:23:48 --> Helper loaded: whmaz_helper
DEBUG - 2026-08-19 03:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:48 --> CSRF cookie sent
INFO - 2026-08-19 03:23:48 --> Input Class Initialized
INFO - 2026-08-19 03:23:48 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:48 --> Language Class Initialized
INFO - 2026-08-19 03:23:48 --> Upload Class Initialized
INFO - 2026-08-19 03:23:48 --> Language Class Initialized
INFO - 2026-08-19 03:23:48 --> Config Class Initialized
INFO - 2026-08-19 03:23:48 --> Helper loaded: cpanel_helper
DEBUG - 2026-08-19 03:23:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:48 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:48 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:48 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:48 --> Loader Class Initialized
INFO - 2026-08-19 03:23:48 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:48 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:48 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:48 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:48 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:48 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:48 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:48 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:48 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:48 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:48 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:48 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:48 --> Config Class Initialized
INFO - 2026-08-19 03:23:48 --> Hooks Class Initialized
INFO - 2026-08-19 03:23:48 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:48 --> Email Class Initialized
INFO - 2026-08-19 03:23:48 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:48 --> Controller Class Initialized
INFO - 2026-08-19 03:23:48 --> Helper loaded: directadmin_helper
DEBUG - 2026-08-19 03:23:48 --> UTF-8 Support Enabled
DEBUG - 2026-08-19 03:23:48 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:23:48 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:48 --> URI Class Initialized
INFO - 2026-08-19 03:23:48 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:48 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:48 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:23:48 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:23:48 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:23:48 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:23:48 --> Router Class Initialized
INFO - 2026-08-19 03:23:48 --> Output Class Initialized
INFO - 2026-08-19 03:23:48 --> Security Class Initialized
INFO - 2026-08-19 03:23:48 --> Database Driver Class Initialized
DEBUG - 2026-08-19 03:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:48 --> CSRF cookie sent
INFO - 2026-08-19 03:23:48 --> Input Class Initialized
INFO - 2026-08-19 03:23:48 --> Language Class Initialized
INFO - 2026-08-19 03:23:48 --> Language Class Initialized
INFO - 2026-08-19 03:23:48 --> Config Class Initialized
INFO - 2026-08-19 03:23:48 --> Loader Class Initialized
INFO - 2026-08-19 03:23:48 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:48 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:48 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:48 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:48 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:48 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:48 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:48 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:48 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:48 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:48 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:48 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:48 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:49 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:49 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:49 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:49 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:49 --> Email Class Initialized
INFO - 2026-08-19 03:23:49 --> Config Class Initialized
INFO - 2026-08-19 03:23:49 --> Controller Class Initialized
INFO - 2026-08-19 03:23:49 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:23:49 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:49 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:49 --> URI Class Initialized
DEBUG - 2026-08-19 03:23:49 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:23:49 --> Router Class Initialized
INFO - 2026-08-19 03:23:49 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:23:49 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:23:49 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:23:49 --> Output Class Initialized
INFO - 2026-08-19 03:23:49 --> Model "Common_model" initialized
INFO - 2026-08-19 03:23:49 --> Security Class Initialized
DEBUG - 2026-08-19 03:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:49 --> Model "Order_model" initialized
INFO - 2026-08-19 03:23:49 --> CSRF cookie sent
INFO - 2026-08-19 03:23:49 --> Input Class Initialized
INFO - 2026-08-19 03:23:49 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:23:49 --> Language Class Initialized
INFO - 2026-08-19 03:23:49 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:23:49 --> Language Class Initialized
INFO - 2026-08-19 03:23:49 --> Config Class Initialized
INFO - 2026-08-19 03:23:49 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:23:49 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:23:49 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:23:49 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:23:49 --> Loader Class Initialized
INFO - 2026-08-19 03:23:49 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:49 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:49 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:49 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:49 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:49 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:49 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:49 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:49 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:49 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:49 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:49 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:49 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:50 --> Final output sent to browser
DEBUG - 2026-08-19 03:23:50 --> Total execution time: 2.9925
INFO - 2026-08-19 03:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:50 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:50 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:50 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:50 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:50 --> Email Class Initialized
INFO - 2026-08-19 03:23:50 --> Controller Class Initialized
ERROR - 2026-08-19 03:23:50 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:50 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:50 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:50 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:50 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:50 --> Email Class Initialized
INFO - 2026-08-19 03:23:50 --> Controller Class Initialized
ERROR - 2026-08-19 03:23:50 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:50 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:50 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:50 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:50 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:50 --> Email Class Initialized
INFO - 2026-08-19 03:23:50 --> Controller Class Initialized
ERROR - 2026-08-19 03:23:50 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:50 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:50 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:50 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:50 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:50 --> Email Class Initialized
INFO - 2026-08-19 03:23:50 --> Controller Class Initialized
ERROR - 2026-08-19 03:23:50 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:51 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:51 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:51 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:51 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:51 --> Email Class Initialized
INFO - 2026-08-19 03:23:51 --> Controller Class Initialized
DEBUG - 2026-08-19 03:23:51 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:23:51 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:23:51 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:23:51 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:23:51 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:23:55 --> Config Class Initialized
INFO - 2026-08-19 03:23:55 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:23:55 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:23:55 --> Utf8 Class Initialized
INFO - 2026-08-19 03:23:55 --> URI Class Initialized
INFO - 2026-08-19 03:23:55 --> Router Class Initialized
INFO - 2026-08-19 03:23:55 --> Output Class Initialized
INFO - 2026-08-19 03:23:55 --> Security Class Initialized
DEBUG - 2026-08-19 03:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:23:55 --> CSRF cookie sent
INFO - 2026-08-19 03:23:55 --> Input Class Initialized
INFO - 2026-08-19 03:23:55 --> Language Class Initialized
INFO - 2026-08-19 03:23:55 --> Language Class Initialized
INFO - 2026-08-19 03:23:55 --> Config Class Initialized
INFO - 2026-08-19 03:23:55 --> Loader Class Initialized
INFO - 2026-08-19 03:23:55 --> Helper loaded: url_helper
INFO - 2026-08-19 03:23:55 --> Helper loaded: form_helper
INFO - 2026-08-19 03:23:55 --> Helper loaded: html_helper
INFO - 2026-08-19 03:23:55 --> Helper loaded: file_helper
INFO - 2026-08-19 03:23:55 --> Helper loaded: email_helper
INFO - 2026-08-19 03:23:55 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:23:55 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:23:55 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:23:55 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:23:55 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:23:55 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:23:55 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:23:55 --> Database Driver Class Initialized
INFO - 2026-08-19 03:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:23:57 --> Upload Class Initialized
DEBUG - 2026-08-19 03:23:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:23:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:23:57 --> Encryption Class Initialized
INFO - 2026-08-19 03:23:57 --> Form Validation Class Initialized
INFO - 2026-08-19 03:23:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:23:57 --> Pagination Class Initialized
INFO - 2026-08-19 03:23:57 --> Email Class Initialized
INFO - 2026-08-19 03:23:57 --> Controller Class Initialized
DEBUG - 2026-08-19 03:23:57 --> Invoicing MX_Controller Initialized
INFO - 2026-08-19 03:23:57 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:23:57 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:23:57 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:23:57 --> Model "Billing_model" initialized
INFO - 2026-08-19 03:23:57 --> Model "Common_model" initialized
INFO - 2026-08-19 03:23:57 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-19 03:23:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/invoicing/views/invoicing_invoice_pdf_html.php
DEBUG - 2026-08-19 03:23:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:23:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-08-19 03:23:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:24:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:24:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/invoicing/views/invoicing_viewinvoice.php
INFO - 2026-08-19 03:24:00 --> Final output sent to browser
DEBUG - 2026-08-19 03:24:00 --> Total execution time: 4.7168
INFO - 2026-08-19 03:24:00 --> Config Class Initialized
INFO - 2026-08-19 03:24:00 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:24:00 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:24:00 --> Utf8 Class Initialized
INFO - 2026-08-19 03:24:00 --> URI Class Initialized
INFO - 2026-08-19 03:24:00 --> Router Class Initialized
INFO - 2026-08-19 03:24:00 --> Output Class Initialized
INFO - 2026-08-19 03:24:00 --> Security Class Initialized
DEBUG - 2026-08-19 03:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:24:00 --> CSRF cookie sent
INFO - 2026-08-19 03:24:00 --> Input Class Initialized
INFO - 2026-08-19 03:24:00 --> Language Class Initialized
INFO - 2026-08-19 03:24:00 --> Language Class Initialized
INFO - 2026-08-19 03:24:00 --> Config Class Initialized
INFO - 2026-08-19 03:24:00 --> Loader Class Initialized
INFO - 2026-08-19 03:24:00 --> Helper loaded: url_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: form_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: html_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: file_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: email_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:24:00 --> Database Driver Class Initialized
INFO - 2026-08-19 03:24:00 --> Config Class Initialized
INFO - 2026-08-19 03:24:00 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:24:00 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:24:00 --> Utf8 Class Initialized
INFO - 2026-08-19 03:24:00 --> URI Class Initialized
INFO - 2026-08-19 03:24:00 --> Router Class Initialized
INFO - 2026-08-19 03:24:00 --> Output Class Initialized
INFO - 2026-08-19 03:24:00 --> Security Class Initialized
INFO - 2026-08-19 03:24:00 --> Config Class Initialized
INFO - 2026-08-19 03:24:00 --> Hooks Class Initialized
INFO - 2026-08-19 03:24:00 --> Config Class Initialized
DEBUG - 2026-08-19 03:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:24:00 --> Hooks Class Initialized
INFO - 2026-08-19 03:24:00 --> CSRF cookie sent
INFO - 2026-08-19 03:24:00 --> Input Class Initialized
INFO - 2026-08-19 03:24:00 --> Language Class Initialized
DEBUG - 2026-08-19 03:24:00 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:24:00 --> Utf8 Class Initialized
INFO - 2026-08-19 03:24:00 --> Language Class Initialized
INFO - 2026-08-19 03:24:00 --> Config Class Initialized
INFO - 2026-08-19 03:24:00 --> URI Class Initialized
INFO - 2026-08-19 03:24:00 --> Config Class Initialized
INFO - 2026-08-19 03:24:00 --> Hooks Class Initialized
INFO - 2026-08-19 03:24:00 --> Router Class Initialized
INFO - 2026-08-19 03:24:00 --> Loader Class Initialized
DEBUG - 2026-08-19 03:24:00 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:24:00 --> Utf8 Class Initialized
INFO - 2026-08-19 03:24:00 --> URI Class Initialized
INFO - 2026-08-19 03:24:00 --> Helper loaded: url_helper
INFO - 2026-08-19 03:24:00 --> Output Class Initialized
INFO - 2026-08-19 03:24:00 --> Config Class Initialized
INFO - 2026-08-19 03:24:00 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:24:00 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:24:00 --> Utf8 Class Initialized
INFO - 2026-08-19 03:24:00 --> Security Class Initialized
INFO - 2026-08-19 03:24:00 --> URI Class Initialized
INFO - 2026-08-19 03:24:00 --> Router Class Initialized
DEBUG - 2026-08-19 03:24:00 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:24:00 --> Utf8 Class Initialized
DEBUG - 2026-08-19 03:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:24:00 --> CSRF cookie sent
INFO - 2026-08-19 03:24:00 --> Input Class Initialized
INFO - 2026-08-19 03:24:00 --> Language Class Initialized
INFO - 2026-08-19 03:24:00 --> Output Class Initialized
INFO - 2026-08-19 03:24:00 --> URI Class Initialized
INFO - 2026-08-19 03:24:00 --> Router Class Initialized
INFO - 2026-08-19 03:24:00 --> Language Class Initialized
INFO - 2026-08-19 03:24:00 --> Config Class Initialized
INFO - 2026-08-19 03:24:00 --> Security Class Initialized
INFO - 2026-08-19 03:24:00 --> Router Class Initialized
DEBUG - 2026-08-19 03:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:24:00 --> CSRF cookie sent
INFO - 2026-08-19 03:24:00 --> Input Class Initialized
INFO - 2026-08-19 03:24:00 --> Output Class Initialized
INFO - 2026-08-19 03:24:00 --> Language Class Initialized
INFO - 2026-08-19 03:24:00 --> Language Class Initialized
INFO - 2026-08-19 03:24:00 --> Config Class Initialized
INFO - 2026-08-19 03:24:00 --> Output Class Initialized
INFO - 2026-08-19 03:24:00 --> Security Class Initialized
INFO - 2026-08-19 03:24:00 --> Loader Class Initialized
DEBUG - 2026-08-19 03:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:24:00 --> Helper loaded: url_helper
INFO - 2026-08-19 03:24:00 --> CSRF cookie sent
INFO - 2026-08-19 03:24:00 --> Input Class Initialized
INFO - 2026-08-19 03:24:00 --> Helper loaded: form_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: html_helper
INFO - 2026-08-19 03:24:00 --> Loader Class Initialized
INFO - 2026-08-19 03:24:00 --> Helper loaded: form_helper
INFO - 2026-08-19 03:24:00 --> Security Class Initialized
INFO - 2026-08-19 03:24:00 --> Helper loaded: file_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: url_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: html_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: email_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: file_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: email_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: form_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: html_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: whmaz_helper
DEBUG - 2026-08-19 03:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:24:00 --> CSRF cookie sent
INFO - 2026-08-19 03:24:00 --> Input Class Initialized
INFO - 2026-08-19 03:24:00 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:24:00 --> Language Class Initialized
INFO - 2026-08-19 03:24:00 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: file_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: email_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:24:00 --> Language Class Initialized
INFO - 2026-08-19 03:24:00 --> Config Class Initialized
INFO - 2026-08-19 03:24:00 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:24:00 --> Loader Class Initialized
INFO - 2026-08-19 03:24:00 --> Language Class Initialized
INFO - 2026-08-19 03:24:00 --> Helper loaded: url_helper
INFO - 2026-08-19 03:24:00 --> Language Class Initialized
INFO - 2026-08-19 03:24:00 --> Config Class Initialized
INFO - 2026-08-19 03:24:00 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: form_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: html_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: file_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: email_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:24:00 --> Loader Class Initialized
INFO - 2026-08-19 03:24:00 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: url_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: form_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:24:00 --> Database Driver Class Initialized
INFO - 2026-08-19 03:24:00 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: html_helper
INFO - 2026-08-19 03:24:00 --> Database Driver Class Initialized
INFO - 2026-08-19 03:24:00 --> Helper loaded: file_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: email_helper
INFO - 2026-08-19 03:24:00 --> Database Driver Class Initialized
INFO - 2026-08-19 03:24:00 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:24:00 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:24:00 --> Database Driver Class Initialized
INFO - 2026-08-19 03:24:00 --> Database Driver Class Initialized
INFO - 2026-08-19 03:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:24:02 --> Upload Class Initialized
DEBUG - 2026-08-19 03:24:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:24:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:24:02 --> Encryption Class Initialized
INFO - 2026-08-19 03:24:02 --> Form Validation Class Initialized
INFO - 2026-08-19 03:24:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:24:02 --> Pagination Class Initialized
INFO - 2026-08-19 03:24:02 --> Email Class Initialized
INFO - 2026-08-19 03:24:02 --> Controller Class Initialized
ERROR - 2026-08-19 03:24:02 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:24:02 --> Upload Class Initialized
DEBUG - 2026-08-19 03:24:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:24:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:24:02 --> Encryption Class Initialized
INFO - 2026-08-19 03:24:02 --> Form Validation Class Initialized
INFO - 2026-08-19 03:24:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:24:02 --> Pagination Class Initialized
INFO - 2026-08-19 03:24:02 --> Config Class Initialized
INFO - 2026-08-19 03:24:02 --> Hooks Class Initialized
INFO - 2026-08-19 03:24:02 --> Email Class Initialized
INFO - 2026-08-19 03:24:02 --> Controller Class Initialized
ERROR - 2026-08-19 03:24:02 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:24:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-08-19 03:24:02 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:24:02 --> Utf8 Class Initialized
INFO - 2026-08-19 03:24:02 --> URI Class Initialized
INFO - 2026-08-19 03:24:02 --> Upload Class Initialized
DEBUG - 2026-08-19 03:24:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:24:02 --> Router Class Initialized
INFO - 2026-08-19 03:24:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:24:02 --> Encryption Class Initialized
INFO - 2026-08-19 03:24:02 --> Output Class Initialized
INFO - 2026-08-19 03:24:02 --> Form Validation Class Initialized
INFO - 2026-08-19 03:24:02 --> Security Class Initialized
INFO - 2026-08-19 03:24:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:24:02 --> Pagination Class Initialized
DEBUG - 2026-08-19 03:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:24:02 --> CSRF cookie sent
INFO - 2026-08-19 03:24:02 --> Input Class Initialized
INFO - 2026-08-19 03:24:02 --> Language Class Initialized
INFO - 2026-08-19 03:24:02 --> Language Class Initialized
INFO - 2026-08-19 03:24:02 --> Config Class Initialized
INFO - 2026-08-19 03:24:02 --> Email Class Initialized
INFO - 2026-08-19 03:24:02 --> Controller Class Initialized
ERROR - 2026-08-19 03:24:02 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:24:02 --> Config Class Initialized
INFO - 2026-08-19 03:24:02 --> Hooks Class Initialized
INFO - 2026-08-19 03:24:02 --> Loader Class Initialized
DEBUG - 2026-08-19 03:24:02 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:24:02 --> Utf8 Class Initialized
INFO - 2026-08-19 03:24:02 --> Helper loaded: url_helper
INFO - 2026-08-19 03:24:02 --> URI Class Initialized
INFO - 2026-08-19 03:24:02 --> Helper loaded: form_helper
INFO - 2026-08-19 03:24:02 --> Router Class Initialized
INFO - 2026-08-19 03:24:02 --> Helper loaded: html_helper
INFO - 2026-08-19 03:24:02 --> Helper loaded: file_helper
INFO - 2026-08-19 03:24:02 --> Helper loaded: email_helper
INFO - 2026-08-19 03:24:02 --> Output Class Initialized
INFO - 2026-08-19 03:24:02 --> Security Class Initialized
INFO - 2026-08-19 03:24:02 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:24:02 --> Helper loaded: ssp_helper
DEBUG - 2026-08-19 03:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:24:02 --> CSRF cookie sent
INFO - 2026-08-19 03:24:02 --> Input Class Initialized
INFO - 2026-08-19 03:24:02 --> Language Class Initialized
INFO - 2026-08-19 03:24:02 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:24:02 --> Language Class Initialized
INFO - 2026-08-19 03:24:02 --> Config Class Initialized
INFO - 2026-08-19 03:24:02 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:24:02 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:24:02 --> Loader Class Initialized
INFO - 2026-08-19 03:24:02 --> Helper loaded: url_helper
INFO - 2026-08-19 03:24:02 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:24:02 --> Config Class Initialized
INFO - 2026-08-19 03:24:02 --> Hooks Class Initialized
INFO - 2026-08-19 03:24:02 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:24:02 --> Helper loaded: form_helper
INFO - 2026-08-19 03:24:02 --> Helper loaded: html_helper
DEBUG - 2026-08-19 03:24:02 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:24:02 --> Utf8 Class Initialized
INFO - 2026-08-19 03:24:02 --> URI Class Initialized
INFO - 2026-08-19 03:24:02 --> Helper loaded: file_helper
INFO - 2026-08-19 03:24:02 --> Helper loaded: email_helper
INFO - 2026-08-19 03:24:02 --> Router Class Initialized
INFO - 2026-08-19 03:24:02 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:24:02 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:24:02 --> Output Class Initialized
INFO - 2026-08-19 03:24:02 --> Security Class Initialized
INFO - 2026-08-19 03:24:02 --> Database Driver Class Initialized
INFO - 2026-08-19 03:24:02 --> Helper loaded: cpanel_helper
DEBUG - 2026-08-19 03:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:24:02 --> CSRF cookie sent
INFO - 2026-08-19 03:24:02 --> Input Class Initialized
INFO - 2026-08-19 03:24:02 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:24:02 --> Language Class Initialized
INFO - 2026-08-19 03:24:02 --> Language Class Initialized
INFO - 2026-08-19 03:24:02 --> Config Class Initialized
INFO - 2026-08-19 03:24:02 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:24:02 --> Loader Class Initialized
INFO - 2026-08-19 03:24:02 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:24:02 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:24:02 --> Helper loaded: url_helper
INFO - 2026-08-19 03:24:02 --> Helper loaded: form_helper
INFO - 2026-08-19 03:24:02 --> Helper loaded: html_helper
INFO - 2026-08-19 03:24:02 --> Helper loaded: file_helper
INFO - 2026-08-19 03:24:02 --> Helper loaded: email_helper
INFO - 2026-08-19 03:24:02 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:24:02 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:24:02 --> Database Driver Class Initialized
INFO - 2026-08-19 03:24:02 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:24:02 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:24:02 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:24:02 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:24:02 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:24:02 --> Database Driver Class Initialized
INFO - 2026-08-19 03:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:24:02 --> Upload Class Initialized
DEBUG - 2026-08-19 03:24:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:24:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:24:02 --> Encryption Class Initialized
INFO - 2026-08-19 03:24:02 --> Form Validation Class Initialized
INFO - 2026-08-19 03:24:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:24:02 --> Pagination Class Initialized
INFO - 2026-08-19 03:24:02 --> Email Class Initialized
INFO - 2026-08-19 03:24:02 --> Controller Class Initialized
ERROR - 2026-08-19 03:24:02 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:24:03 --> Upload Class Initialized
DEBUG - 2026-08-19 03:24:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:24:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:24:03 --> Encryption Class Initialized
INFO - 2026-08-19 03:24:03 --> Form Validation Class Initialized
INFO - 2026-08-19 03:24:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:24:03 --> Pagination Class Initialized
INFO - 2026-08-19 03:24:03 --> Email Class Initialized
INFO - 2026-08-19 03:24:03 --> Controller Class Initialized
ERROR - 2026-08-19 03:24:03 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:24:03 --> Upload Class Initialized
DEBUG - 2026-08-19 03:24:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:24:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:24:03 --> Encryption Class Initialized
INFO - 2026-08-19 03:24:03 --> Form Validation Class Initialized
INFO - 2026-08-19 03:24:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:24:03 --> Pagination Class Initialized
INFO - 2026-08-19 03:24:03 --> Email Class Initialized
INFO - 2026-08-19 03:24:03 --> Controller Class Initialized
ERROR - 2026-08-19 03:24:03 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:24:04 --> Upload Class Initialized
DEBUG - 2026-08-19 03:24:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:24:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:24:04 --> Encryption Class Initialized
INFO - 2026-08-19 03:24:04 --> Form Validation Class Initialized
INFO - 2026-08-19 03:24:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:24:04 --> Pagination Class Initialized
INFO - 2026-08-19 03:24:04 --> Email Class Initialized
INFO - 2026-08-19 03:24:04 --> Controller Class Initialized
DEBUG - 2026-08-19 03:24:04 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:24:04 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:24:04 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:24:04 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:24:04 --> Model "Common_model" initialized
INFO - 2026-08-19 03:24:04 --> Model "Order_model" initialized
INFO - 2026-08-19 03:24:04 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:24:04 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:24:04 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:24:04 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:24:04 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:24:04 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:24:04 --> Final output sent to browser
DEBUG - 2026-08-19 03:24:04 --> Total execution time: 2.1390
INFO - 2026-08-19 03:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:24:04 --> Upload Class Initialized
DEBUG - 2026-08-19 03:24:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:24:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:24:04 --> Encryption Class Initialized
INFO - 2026-08-19 03:24:04 --> Form Validation Class Initialized
INFO - 2026-08-19 03:24:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:24:04 --> Pagination Class Initialized
INFO - 2026-08-19 03:24:04 --> Email Class Initialized
INFO - 2026-08-19 03:24:04 --> Controller Class Initialized
ERROR - 2026-08-19 03:24:04 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:24:04 --> Upload Class Initialized
DEBUG - 2026-08-19 03:24:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:24:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:24:04 --> Encryption Class Initialized
INFO - 2026-08-19 03:24:04 --> Form Validation Class Initialized
INFO - 2026-08-19 03:24:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:24:04 --> Pagination Class Initialized
INFO - 2026-08-19 03:24:04 --> Email Class Initialized
INFO - 2026-08-19 03:24:04 --> Controller Class Initialized
DEBUG - 2026-08-19 03:24:04 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:24:04 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:24:04 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:24:04 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:24:04 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:24:12 --> Config Class Initialized
INFO - 2026-08-19 03:24:12 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:24:12 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:24:12 --> Utf8 Class Initialized
INFO - 2026-08-19 03:24:12 --> URI Class Initialized
INFO - 2026-08-19 03:24:12 --> Router Class Initialized
INFO - 2026-08-19 03:24:12 --> Output Class Initialized
INFO - 2026-08-19 03:24:12 --> Security Class Initialized
DEBUG - 2026-08-19 03:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:24:12 --> CSRF cookie sent
INFO - 2026-08-19 03:24:12 --> Input Class Initialized
INFO - 2026-08-19 03:24:12 --> Language Class Initialized
INFO - 2026-08-19 03:24:12 --> Language Class Initialized
INFO - 2026-08-19 03:24:12 --> Config Class Initialized
INFO - 2026-08-19 03:24:12 --> Loader Class Initialized
INFO - 2026-08-19 03:24:12 --> Helper loaded: url_helper
INFO - 2026-08-19 03:24:12 --> Helper loaded: form_helper
INFO - 2026-08-19 03:24:12 --> Helper loaded: html_helper
INFO - 2026-08-19 03:24:12 --> Helper loaded: file_helper
INFO - 2026-08-19 03:24:12 --> Helper loaded: email_helper
INFO - 2026-08-19 03:24:12 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:24:12 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:24:12 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:24:12 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:24:12 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:24:12 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:24:12 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:24:12 --> Database Driver Class Initialized
INFO - 2026-08-19 03:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:24:14 --> Upload Class Initialized
DEBUG - 2026-08-19 03:24:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:24:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:24:14 --> Encryption Class Initialized
INFO - 2026-08-19 03:24:14 --> Form Validation Class Initialized
INFO - 2026-08-19 03:24:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:24:14 --> Pagination Class Initialized
INFO - 2026-08-19 03:24:14 --> Email Class Initialized
INFO - 2026-08-19 03:24:14 --> Controller Class Initialized
DEBUG - 2026-08-19 03:24:14 --> Invoicing MX_Controller Initialized
INFO - 2026-08-19 03:24:14 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:24:14 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:24:14 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:24:14 --> Model "Billing_model" initialized
INFO - 2026-08-19 03:24:14 --> Model "Common_model" initialized
INFO - 2026-08-19 03:24:14 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-19 03:24:16 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/invoicing/views/invoicing_invoice_pdf_html.php
INFO - 2026-08-19 03:24:17 --> Final output sent to browser
DEBUG - 2026-08-19 03:24:17 --> Total execution time: 4.3494
INFO - 2026-08-19 03:24:48 --> Config Class Initialized
INFO - 2026-08-19 03:24:48 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:24:48 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:24:48 --> Utf8 Class Initialized
INFO - 2026-08-19 03:24:48 --> URI Class Initialized
INFO - 2026-08-19 03:24:48 --> Router Class Initialized
INFO - 2026-08-19 03:24:48 --> Output Class Initialized
INFO - 2026-08-19 03:24:48 --> Security Class Initialized
DEBUG - 2026-08-19 03:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:24:48 --> CSRF cookie sent
INFO - 2026-08-19 03:24:48 --> Input Class Initialized
INFO - 2026-08-19 03:24:48 --> Language Class Initialized
INFO - 2026-08-19 03:24:48 --> Language Class Initialized
INFO - 2026-08-19 03:24:48 --> Config Class Initialized
INFO - 2026-08-19 03:24:48 --> Loader Class Initialized
INFO - 2026-08-19 03:24:48 --> Helper loaded: url_helper
INFO - 2026-08-19 03:24:48 --> Helper loaded: form_helper
INFO - 2026-08-19 03:24:48 --> Helper loaded: html_helper
INFO - 2026-08-19 03:24:48 --> Helper loaded: file_helper
INFO - 2026-08-19 03:24:48 --> Helper loaded: email_helper
INFO - 2026-08-19 03:24:48 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:24:48 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:24:48 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:24:48 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:24:48 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:24:48 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:24:48 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:24:48 --> Database Driver Class Initialized
INFO - 2026-08-19 03:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:24:49 --> Upload Class Initialized
DEBUG - 2026-08-19 03:24:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:24:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:24:49 --> Encryption Class Initialized
INFO - 2026-08-19 03:24:49 --> Form Validation Class Initialized
INFO - 2026-08-19 03:24:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:24:49 --> Pagination Class Initialized
INFO - 2026-08-19 03:24:49 --> Email Class Initialized
INFO - 2026-08-19 03:24:49 --> Controller Class Initialized
DEBUG - 2026-08-19 03:24:49 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:24:49 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:24:49 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:24:49 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:24:49 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:25:00 --> Config Class Initialized
INFO - 2026-08-19 03:25:00 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:25:00 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:25:00 --> Utf8 Class Initialized
INFO - 2026-08-19 03:25:00 --> URI Class Initialized
INFO - 2026-08-19 03:25:00 --> Router Class Initialized
INFO - 2026-08-19 03:25:00 --> Output Class Initialized
INFO - 2026-08-19 03:25:00 --> Security Class Initialized
DEBUG - 2026-08-19 03:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:25:00 --> CSRF cookie sent
INFO - 2026-08-19 03:25:00 --> Input Class Initialized
INFO - 2026-08-19 03:25:00 --> Language Class Initialized
INFO - 2026-08-19 03:25:00 --> Language Class Initialized
INFO - 2026-08-19 03:25:00 --> Config Class Initialized
INFO - 2026-08-19 03:25:00 --> Loader Class Initialized
INFO - 2026-08-19 03:25:00 --> Helper loaded: url_helper
INFO - 2026-08-19 03:25:00 --> Helper loaded: form_helper
INFO - 2026-08-19 03:25:00 --> Helper loaded: html_helper
INFO - 2026-08-19 03:25:00 --> Helper loaded: file_helper
INFO - 2026-08-19 03:25:00 --> Helper loaded: email_helper
INFO - 2026-08-19 03:25:00 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:25:00 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:25:00 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:25:00 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:25:00 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:25:00 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:25:00 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:25:00 --> Database Driver Class Initialized
INFO - 2026-08-19 03:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:25:02 --> Upload Class Initialized
DEBUG - 2026-08-19 03:25:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:25:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:25:02 --> Encryption Class Initialized
INFO - 2026-08-19 03:25:02 --> Form Validation Class Initialized
INFO - 2026-08-19 03:25:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:25:02 --> Pagination Class Initialized
INFO - 2026-08-19 03:25:02 --> Email Class Initialized
INFO - 2026-08-19 03:25:02 --> Controller Class Initialized
DEBUG - 2026-08-19 03:25:02 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:25:02 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:25:02 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:25:02 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:25:02 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:25:48 --> Config Class Initialized
INFO - 2026-08-19 03:25:48 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:25:48 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:25:48 --> Utf8 Class Initialized
INFO - 2026-08-19 03:25:48 --> URI Class Initialized
INFO - 2026-08-19 03:25:48 --> Router Class Initialized
INFO - 2026-08-19 03:25:48 --> Output Class Initialized
INFO - 2026-08-19 03:25:48 --> Security Class Initialized
DEBUG - 2026-08-19 03:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:25:48 --> CSRF cookie sent
INFO - 2026-08-19 03:25:48 --> Input Class Initialized
INFO - 2026-08-19 03:25:48 --> Language Class Initialized
INFO - 2026-08-19 03:25:48 --> Language Class Initialized
INFO - 2026-08-19 03:25:48 --> Config Class Initialized
INFO - 2026-08-19 03:25:48 --> Loader Class Initialized
INFO - 2026-08-19 03:25:48 --> Helper loaded: url_helper
INFO - 2026-08-19 03:25:48 --> Helper loaded: form_helper
INFO - 2026-08-19 03:25:48 --> Helper loaded: html_helper
INFO - 2026-08-19 03:25:48 --> Helper loaded: file_helper
INFO - 2026-08-19 03:25:48 --> Helper loaded: email_helper
INFO - 2026-08-19 03:25:48 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:25:48 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:25:48 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:25:48 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:25:48 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:25:48 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:25:48 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:25:48 --> Database Driver Class Initialized
INFO - 2026-08-19 03:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:25:49 --> Upload Class Initialized
DEBUG - 2026-08-19 03:25:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:25:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:25:49 --> Encryption Class Initialized
INFO - 2026-08-19 03:25:49 --> Form Validation Class Initialized
INFO - 2026-08-19 03:25:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:25:49 --> Pagination Class Initialized
INFO - 2026-08-19 03:25:49 --> Email Class Initialized
INFO - 2026-08-19 03:25:49 --> Controller Class Initialized
DEBUG - 2026-08-19 03:25:49 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:25:49 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:25:49 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:25:49 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:25:49 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:26:00 --> Config Class Initialized
INFO - 2026-08-19 03:26:00 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:26:00 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:26:00 --> Utf8 Class Initialized
INFO - 2026-08-19 03:26:00 --> URI Class Initialized
INFO - 2026-08-19 03:26:00 --> Router Class Initialized
INFO - 2026-08-19 03:26:00 --> Output Class Initialized
INFO - 2026-08-19 03:26:00 --> Security Class Initialized
DEBUG - 2026-08-19 03:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:26:00 --> CSRF cookie sent
INFO - 2026-08-19 03:26:00 --> Input Class Initialized
INFO - 2026-08-19 03:26:00 --> Language Class Initialized
INFO - 2026-08-19 03:26:00 --> Language Class Initialized
INFO - 2026-08-19 03:26:00 --> Config Class Initialized
INFO - 2026-08-19 03:26:00 --> Loader Class Initialized
INFO - 2026-08-19 03:26:00 --> Helper loaded: url_helper
INFO - 2026-08-19 03:26:00 --> Helper loaded: form_helper
INFO - 2026-08-19 03:26:00 --> Helper loaded: html_helper
INFO - 2026-08-19 03:26:00 --> Helper loaded: file_helper
INFO - 2026-08-19 03:26:00 --> Helper loaded: email_helper
INFO - 2026-08-19 03:26:00 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:26:00 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:26:00 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:26:00 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:26:00 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:26:00 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:26:00 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:26:00 --> Database Driver Class Initialized
INFO - 2026-08-19 03:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:26:02 --> Upload Class Initialized
DEBUG - 2026-08-19 03:26:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:26:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:26:02 --> Encryption Class Initialized
INFO - 2026-08-19 03:26:02 --> Form Validation Class Initialized
INFO - 2026-08-19 03:26:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:26:02 --> Pagination Class Initialized
INFO - 2026-08-19 03:26:02 --> Email Class Initialized
INFO - 2026-08-19 03:26:02 --> Controller Class Initialized
DEBUG - 2026-08-19 03:26:02 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:26:02 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:26:02 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:26:02 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:26:02 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:26:48 --> Config Class Initialized
INFO - 2026-08-19 03:26:48 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:26:48 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:26:48 --> Utf8 Class Initialized
INFO - 2026-08-19 03:26:48 --> URI Class Initialized
INFO - 2026-08-19 03:26:48 --> Router Class Initialized
INFO - 2026-08-19 03:26:48 --> Output Class Initialized
INFO - 2026-08-19 03:26:48 --> Security Class Initialized
DEBUG - 2026-08-19 03:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:26:48 --> CSRF cookie sent
INFO - 2026-08-19 03:26:48 --> Input Class Initialized
INFO - 2026-08-19 03:26:48 --> Language Class Initialized
INFO - 2026-08-19 03:26:48 --> Language Class Initialized
INFO - 2026-08-19 03:26:48 --> Config Class Initialized
INFO - 2026-08-19 03:26:48 --> Loader Class Initialized
INFO - 2026-08-19 03:26:48 --> Helper loaded: url_helper
INFO - 2026-08-19 03:26:48 --> Helper loaded: form_helper
INFO - 2026-08-19 03:26:48 --> Helper loaded: html_helper
INFO - 2026-08-19 03:26:48 --> Helper loaded: file_helper
INFO - 2026-08-19 03:26:48 --> Helper loaded: email_helper
INFO - 2026-08-19 03:26:48 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:26:48 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:26:48 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:26:48 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:26:48 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:26:48 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:26:48 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:26:48 --> Database Driver Class Initialized
INFO - 2026-08-19 03:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:26:49 --> Upload Class Initialized
DEBUG - 2026-08-19 03:26:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:26:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:26:49 --> Encryption Class Initialized
INFO - 2026-08-19 03:26:49 --> Form Validation Class Initialized
INFO - 2026-08-19 03:26:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:26:49 --> Pagination Class Initialized
INFO - 2026-08-19 03:26:49 --> Email Class Initialized
INFO - 2026-08-19 03:26:49 --> Controller Class Initialized
DEBUG - 2026-08-19 03:26:49 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:26:49 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:26:49 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:26:49 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:26:49 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:27:00 --> Config Class Initialized
INFO - 2026-08-19 03:27:00 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:27:00 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:27:00 --> Utf8 Class Initialized
INFO - 2026-08-19 03:27:00 --> URI Class Initialized
INFO - 2026-08-19 03:27:00 --> Router Class Initialized
INFO - 2026-08-19 03:27:00 --> Output Class Initialized
INFO - 2026-08-19 03:27:00 --> Security Class Initialized
DEBUG - 2026-08-19 03:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:27:00 --> CSRF cookie sent
INFO - 2026-08-19 03:27:00 --> Input Class Initialized
INFO - 2026-08-19 03:27:00 --> Language Class Initialized
INFO - 2026-08-19 03:27:00 --> Language Class Initialized
INFO - 2026-08-19 03:27:00 --> Config Class Initialized
INFO - 2026-08-19 03:27:00 --> Loader Class Initialized
INFO - 2026-08-19 03:27:00 --> Helper loaded: url_helper
INFO - 2026-08-19 03:27:00 --> Helper loaded: form_helper
INFO - 2026-08-19 03:27:00 --> Helper loaded: html_helper
INFO - 2026-08-19 03:27:00 --> Helper loaded: file_helper
INFO - 2026-08-19 03:27:00 --> Helper loaded: email_helper
INFO - 2026-08-19 03:27:00 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:27:00 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:27:00 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:27:00 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:27:00 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:27:00 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:27:00 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:27:00 --> Database Driver Class Initialized
INFO - 2026-08-19 03:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:27:02 --> Upload Class Initialized
DEBUG - 2026-08-19 03:27:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:27:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:27:02 --> Encryption Class Initialized
INFO - 2026-08-19 03:27:02 --> Form Validation Class Initialized
INFO - 2026-08-19 03:27:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:27:02 --> Pagination Class Initialized
INFO - 2026-08-19 03:27:02 --> Email Class Initialized
INFO - 2026-08-19 03:27:02 --> Controller Class Initialized
DEBUG - 2026-08-19 03:27:02 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:27:02 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:27:02 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:27:02 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:27:02 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:27:48 --> Config Class Initialized
INFO - 2026-08-19 03:27:48 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:27:48 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:27:48 --> Utf8 Class Initialized
INFO - 2026-08-19 03:27:48 --> URI Class Initialized
INFO - 2026-08-19 03:27:48 --> Router Class Initialized
INFO - 2026-08-19 03:27:48 --> Output Class Initialized
INFO - 2026-08-19 03:27:48 --> Security Class Initialized
DEBUG - 2026-08-19 03:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:27:48 --> CSRF cookie sent
INFO - 2026-08-19 03:27:48 --> Input Class Initialized
INFO - 2026-08-19 03:27:48 --> Language Class Initialized
INFO - 2026-08-19 03:27:48 --> Language Class Initialized
INFO - 2026-08-19 03:27:48 --> Config Class Initialized
INFO - 2026-08-19 03:27:48 --> Loader Class Initialized
INFO - 2026-08-19 03:27:48 --> Helper loaded: url_helper
INFO - 2026-08-19 03:27:48 --> Helper loaded: form_helper
INFO - 2026-08-19 03:27:48 --> Helper loaded: html_helper
INFO - 2026-08-19 03:27:48 --> Helper loaded: file_helper
INFO - 2026-08-19 03:27:48 --> Helper loaded: email_helper
INFO - 2026-08-19 03:27:48 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:27:48 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:27:48 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:27:48 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:27:48 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:27:48 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:27:48 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:27:48 --> Database Driver Class Initialized
INFO - 2026-08-19 03:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:27:49 --> Upload Class Initialized
DEBUG - 2026-08-19 03:27:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:27:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:27:49 --> Encryption Class Initialized
INFO - 2026-08-19 03:27:49 --> Form Validation Class Initialized
INFO - 2026-08-19 03:27:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:27:49 --> Pagination Class Initialized
INFO - 2026-08-19 03:27:49 --> Email Class Initialized
INFO - 2026-08-19 03:27:49 --> Controller Class Initialized
DEBUG - 2026-08-19 03:27:49 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:27:49 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:27:49 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:27:49 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:27:49 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:28:00 --> Config Class Initialized
INFO - 2026-08-19 03:28:00 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:28:00 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:28:00 --> Utf8 Class Initialized
INFO - 2026-08-19 03:28:00 --> URI Class Initialized
INFO - 2026-08-19 03:28:00 --> Router Class Initialized
INFO - 2026-08-19 03:28:00 --> Output Class Initialized
INFO - 2026-08-19 03:28:00 --> Security Class Initialized
DEBUG - 2026-08-19 03:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:28:00 --> CSRF cookie sent
INFO - 2026-08-19 03:28:00 --> Input Class Initialized
INFO - 2026-08-19 03:28:00 --> Language Class Initialized
INFO - 2026-08-19 03:28:00 --> Language Class Initialized
INFO - 2026-08-19 03:28:00 --> Config Class Initialized
INFO - 2026-08-19 03:28:00 --> Loader Class Initialized
INFO - 2026-08-19 03:28:00 --> Helper loaded: url_helper
INFO - 2026-08-19 03:28:00 --> Helper loaded: form_helper
INFO - 2026-08-19 03:28:00 --> Helper loaded: html_helper
INFO - 2026-08-19 03:28:00 --> Helper loaded: file_helper
INFO - 2026-08-19 03:28:00 --> Helper loaded: email_helper
INFO - 2026-08-19 03:28:00 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:28:00 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:28:00 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:28:00 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:28:00 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:28:00 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:28:00 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:28:00 --> Database Driver Class Initialized
INFO - 2026-08-19 03:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:28:02 --> Upload Class Initialized
DEBUG - 2026-08-19 03:28:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:28:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:28:02 --> Encryption Class Initialized
INFO - 2026-08-19 03:28:02 --> Form Validation Class Initialized
INFO - 2026-08-19 03:28:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:28:02 --> Pagination Class Initialized
INFO - 2026-08-19 03:28:02 --> Email Class Initialized
INFO - 2026-08-19 03:28:02 --> Controller Class Initialized
DEBUG - 2026-08-19 03:28:02 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:28:02 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:28:02 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:28:02 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:28:02 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:28:06 --> Config Class Initialized
INFO - 2026-08-19 03:28:06 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:28:06 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:28:06 --> Utf8 Class Initialized
INFO - 2026-08-19 03:28:06 --> URI Class Initialized
INFO - 2026-08-19 03:28:06 --> Router Class Initialized
INFO - 2026-08-19 03:28:06 --> Output Class Initialized
INFO - 2026-08-19 03:28:06 --> Security Class Initialized
DEBUG - 2026-08-19 03:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:28:06 --> CSRF cookie sent
INFO - 2026-08-19 03:28:06 --> Input Class Initialized
INFO - 2026-08-19 03:28:06 --> Language Class Initialized
INFO - 2026-08-19 03:28:06 --> Language Class Initialized
INFO - 2026-08-19 03:28:06 --> Config Class Initialized
INFO - 2026-08-19 03:28:06 --> Loader Class Initialized
INFO - 2026-08-19 03:28:06 --> Helper loaded: url_helper
INFO - 2026-08-19 03:28:06 --> Helper loaded: form_helper
INFO - 2026-08-19 03:28:06 --> Helper loaded: html_helper
INFO - 2026-08-19 03:28:06 --> Helper loaded: file_helper
INFO - 2026-08-19 03:28:06 --> Helper loaded: email_helper
INFO - 2026-08-19 03:28:06 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:28:06 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:28:06 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:28:06 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:28:06 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:28:06 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:28:06 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:28:06 --> Database Driver Class Initialized
INFO - 2026-08-19 03:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:28:08 --> Upload Class Initialized
DEBUG - 2026-08-19 03:28:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:28:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:28:08 --> Encryption Class Initialized
INFO - 2026-08-19 03:28:08 --> Form Validation Class Initialized
INFO - 2026-08-19 03:28:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:28:08 --> Pagination Class Initialized
INFO - 2026-08-19 03:28:08 --> Email Class Initialized
INFO - 2026-08-19 03:28:08 --> Controller Class Initialized
DEBUG - 2026-08-19 03:28:08 --> Invoicing MX_Controller Initialized
INFO - 2026-08-19 03:28:08 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:28:08 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:28:08 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:28:08 --> Model "Billing_model" initialized
INFO - 2026-08-19 03:28:08 --> Model "Common_model" initialized
INFO - 2026-08-19 03:28:08 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-19 03:28:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/invoicing/views/invoicing_invoice_pdf_html.php
DEBUG - 2026-08-19 03:28:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:28:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-08-19 03:28:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:28:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:28:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/invoicing/views/invoicing_viewinvoice.php
INFO - 2026-08-19 03:28:11 --> Final output sent to browser
DEBUG - 2026-08-19 03:28:11 --> Total execution time: 4.5925
INFO - 2026-08-19 03:28:11 --> Config Class Initialized
INFO - 2026-08-19 03:28:11 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:28:11 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:28:11 --> Utf8 Class Initialized
INFO - 2026-08-19 03:28:11 --> URI Class Initialized
INFO - 2026-08-19 03:28:11 --> Router Class Initialized
INFO - 2026-08-19 03:28:11 --> Output Class Initialized
INFO - 2026-08-19 03:28:11 --> Security Class Initialized
DEBUG - 2026-08-19 03:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:28:11 --> CSRF cookie sent
INFO - 2026-08-19 03:28:11 --> Input Class Initialized
INFO - 2026-08-19 03:28:11 --> Language Class Initialized
INFO - 2026-08-19 03:28:11 --> Language Class Initialized
INFO - 2026-08-19 03:28:11 --> Config Class Initialized
INFO - 2026-08-19 03:28:11 --> Loader Class Initialized
INFO - 2026-08-19 03:28:11 --> Helper loaded: url_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: form_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: html_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: file_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: email_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:28:11 --> Database Driver Class Initialized
INFO - 2026-08-19 03:28:11 --> Config Class Initialized
INFO - 2026-08-19 03:28:11 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:28:11 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:28:11 --> Utf8 Class Initialized
INFO - 2026-08-19 03:28:11 --> URI Class Initialized
INFO - 2026-08-19 03:28:11 --> Router Class Initialized
INFO - 2026-08-19 03:28:11 --> Output Class Initialized
INFO - 2026-08-19 03:28:11 --> Security Class Initialized
DEBUG - 2026-08-19 03:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:28:11 --> CSRF cookie sent
INFO - 2026-08-19 03:28:11 --> Input Class Initialized
INFO - 2026-08-19 03:28:11 --> Language Class Initialized
INFO - 2026-08-19 03:28:11 --> Language Class Initialized
INFO - 2026-08-19 03:28:11 --> Config Class Initialized
INFO - 2026-08-19 03:28:11 --> Loader Class Initialized
INFO - 2026-08-19 03:28:11 --> Helper loaded: url_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: form_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: html_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: file_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: email_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:28:11 --> Database Driver Class Initialized
INFO - 2026-08-19 03:28:11 --> Config Class Initialized
INFO - 2026-08-19 03:28:11 --> Config Class Initialized
INFO - 2026-08-19 03:28:11 --> Hooks Class Initialized
INFO - 2026-08-19 03:28:11 --> Config Class Initialized
INFO - 2026-08-19 03:28:11 --> Config Class Initialized
INFO - 2026-08-19 03:28:11 --> Hooks Class Initialized
INFO - 2026-08-19 03:28:11 --> Hooks Class Initialized
INFO - 2026-08-19 03:28:11 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:28:11 --> UTF-8 Support Enabled
DEBUG - 2026-08-19 03:28:11 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:28:11 --> Utf8 Class Initialized
INFO - 2026-08-19 03:28:11 --> Utf8 Class Initialized
DEBUG - 2026-08-19 03:28:11 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:28:11 --> Utf8 Class Initialized
DEBUG - 2026-08-19 03:28:11 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:28:11 --> Utf8 Class Initialized
INFO - 2026-08-19 03:28:11 --> URI Class Initialized
INFO - 2026-08-19 03:28:11 --> URI Class Initialized
INFO - 2026-08-19 03:28:11 --> URI Class Initialized
INFO - 2026-08-19 03:28:11 --> URI Class Initialized
INFO - 2026-08-19 03:28:11 --> Router Class Initialized
INFO - 2026-08-19 03:28:11 --> Router Class Initialized
INFO - 2026-08-19 03:28:11 --> Router Class Initialized
INFO - 2026-08-19 03:28:11 --> Router Class Initialized
INFO - 2026-08-19 03:28:11 --> Output Class Initialized
INFO - 2026-08-19 03:28:11 --> Output Class Initialized
INFO - 2026-08-19 03:28:11 --> Security Class Initialized
INFO - 2026-08-19 03:28:11 --> Security Class Initialized
INFO - 2026-08-19 03:28:11 --> Output Class Initialized
INFO - 2026-08-19 03:28:11 --> Output Class Initialized
DEBUG - 2026-08-19 03:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:28:11 --> CSRF cookie sent
INFO - 2026-08-19 03:28:11 --> Input Class Initialized
DEBUG - 2026-08-19 03:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:28:11 --> CSRF cookie sent
INFO - 2026-08-19 03:28:11 --> Input Class Initialized
INFO - 2026-08-19 03:28:11 --> Language Class Initialized
INFO - 2026-08-19 03:28:11 --> Language Class Initialized
INFO - 2026-08-19 03:28:11 --> Security Class Initialized
INFO - 2026-08-19 03:28:11 --> Security Class Initialized
INFO - 2026-08-19 03:28:11 --> Language Class Initialized
INFO - 2026-08-19 03:28:11 --> Config Class Initialized
INFO - 2026-08-19 03:28:11 --> Language Class Initialized
INFO - 2026-08-19 03:28:11 --> Config Class Initialized
DEBUG - 2026-08-19 03:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-08-19 03:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:28:11 --> CSRF cookie sent
INFO - 2026-08-19 03:28:11 --> CSRF cookie sent
INFO - 2026-08-19 03:28:11 --> Input Class Initialized
INFO - 2026-08-19 03:28:11 --> Input Class Initialized
INFO - 2026-08-19 03:28:11 --> Language Class Initialized
INFO - 2026-08-19 03:28:11 --> Language Class Initialized
INFO - 2026-08-19 03:28:11 --> Loader Class Initialized
INFO - 2026-08-19 03:28:11 --> Loader Class Initialized
INFO - 2026-08-19 03:28:11 --> Language Class Initialized
INFO - 2026-08-19 03:28:11 --> Language Class Initialized
INFO - 2026-08-19 03:28:11 --> Config Class Initialized
INFO - 2026-08-19 03:28:11 --> Config Class Initialized
INFO - 2026-08-19 03:28:11 --> Helper loaded: url_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: url_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: form_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: html_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: form_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: file_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: email_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: html_helper
INFO - 2026-08-19 03:28:11 --> Loader Class Initialized
INFO - 2026-08-19 03:28:11 --> Loader Class Initialized
INFO - 2026-08-19 03:28:11 --> Helper loaded: file_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: email_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: url_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: url_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: form_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: form_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: html_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: html_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: file_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: file_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: email_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: email_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:28:11 --> Database Driver Class Initialized
INFO - 2026-08-19 03:28:11 --> Database Driver Class Initialized
INFO - 2026-08-19 03:28:11 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:28:11 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:28:11 --> Database Driver Class Initialized
INFO - 2026-08-19 03:28:11 --> Database Driver Class Initialized
INFO - 2026-08-19 03:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:28:13 --> Upload Class Initialized
DEBUG - 2026-08-19 03:28:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:28:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:28:13 --> Encryption Class Initialized
INFO - 2026-08-19 03:28:13 --> Form Validation Class Initialized
INFO - 2026-08-19 03:28:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:28:13 --> Pagination Class Initialized
INFO - 2026-08-19 03:28:13 --> Email Class Initialized
INFO - 2026-08-19 03:28:13 --> Controller Class Initialized
ERROR - 2026-08-19 03:28:13 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:28:13 --> Upload Class Initialized
DEBUG - 2026-08-19 03:28:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:28:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:28:13 --> Encryption Class Initialized
INFO - 2026-08-19 03:28:13 --> Form Validation Class Initialized
INFO - 2026-08-19 03:28:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:28:13 --> Pagination Class Initialized
INFO - 2026-08-19 03:28:13 --> Config Class Initialized
INFO - 2026-08-19 03:28:13 --> Hooks Class Initialized
INFO - 2026-08-19 03:28:13 --> Email Class Initialized
INFO - 2026-08-19 03:28:13 --> Controller Class Initialized
DEBUG - 2026-08-19 03:28:13 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:28:13 --> Utf8 Class Initialized
ERROR - 2026-08-19 03:28:13 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:28:13 --> URI Class Initialized
INFO - 2026-08-19 03:28:13 --> Upload Class Initialized
INFO - 2026-08-19 03:28:13 --> Router Class Initialized
DEBUG - 2026-08-19 03:28:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:28:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:28:13 --> Encryption Class Initialized
INFO - 2026-08-19 03:28:13 --> Output Class Initialized
INFO - 2026-08-19 03:28:13 --> Security Class Initialized
INFO - 2026-08-19 03:28:13 --> Form Validation Class Initialized
DEBUG - 2026-08-19 03:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:28:13 --> CSRF cookie sent
INFO - 2026-08-19 03:28:13 --> Input Class Initialized
INFO - 2026-08-19 03:28:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:28:13 --> Pagination Class Initialized
INFO - 2026-08-19 03:28:13 --> Language Class Initialized
INFO - 2026-08-19 03:28:13 --> Config Class Initialized
INFO - 2026-08-19 03:28:13 --> Hooks Class Initialized
INFO - 2026-08-19 03:28:13 --> Language Class Initialized
INFO - 2026-08-19 03:28:13 --> Config Class Initialized
DEBUG - 2026-08-19 03:28:13 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:28:13 --> Utf8 Class Initialized
INFO - 2026-08-19 03:28:13 --> URI Class Initialized
INFO - 2026-08-19 03:28:13 --> Email Class Initialized
INFO - 2026-08-19 03:28:13 --> Router Class Initialized
INFO - 2026-08-19 03:28:13 --> Controller Class Initialized
ERROR - 2026-08-19 03:28:13 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:28:13 --> Loader Class Initialized
INFO - 2026-08-19 03:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:28:13 --> Output Class Initialized
INFO - 2026-08-19 03:28:13 --> Helper loaded: url_helper
INFO - 2026-08-19 03:28:13 --> Security Class Initialized
INFO - 2026-08-19 03:28:13 --> Upload Class Initialized
INFO - 2026-08-19 03:28:13 --> Helper loaded: form_helper
DEBUG - 2026-08-19 03:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:28:13 --> CSRF cookie sent
INFO - 2026-08-19 03:28:13 --> Input Class Initialized
INFO - 2026-08-19 03:28:13 --> Language Class Initialized
INFO - 2026-08-19 03:28:13 --> Helper loaded: html_helper
INFO - 2026-08-19 03:28:13 --> Helper loaded: file_helper
INFO - 2026-08-19 03:28:13 --> Helper loaded: email_helper
INFO - 2026-08-19 03:28:13 --> Language Class Initialized
INFO - 2026-08-19 03:28:13 --> Config Class Initialized
DEBUG - 2026-08-19 03:28:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:28:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:28:13 --> Encryption Class Initialized
INFO - 2026-08-19 03:28:13 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:28:13 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:28:13 --> Form Validation Class Initialized
INFO - 2026-08-19 03:28:13 --> Loader Class Initialized
INFO - 2026-08-19 03:28:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:28:13 --> Pagination Class Initialized
INFO - 2026-08-19 03:28:13 --> Helper loaded: url_helper
INFO - 2026-08-19 03:28:13 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:28:13 --> Helper loaded: form_helper
INFO - 2026-08-19 03:28:13 --> Helper loaded: html_helper
INFO - 2026-08-19 03:28:13 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:28:13 --> Helper loaded: file_helper
INFO - 2026-08-19 03:28:13 --> Helper loaded: email_helper
INFO - 2026-08-19 03:28:13 --> Email Class Initialized
INFO - 2026-08-19 03:28:13 --> Controller Class Initialized
ERROR - 2026-08-19 03:28:13 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:28:13 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:28:13 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:28:13 --> Config Class Initialized
INFO - 2026-08-19 03:28:13 --> Hooks Class Initialized
INFO - 2026-08-19 03:28:13 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:28:13 --> Upload Class Initialized
INFO - 2026-08-19 03:28:13 --> Helper loaded: cpanel_helper
DEBUG - 2026-08-19 03:28:13 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:28:13 --> Utf8 Class Initialized
INFO - 2026-08-19 03:28:13 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:28:13 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:28:13 --> URI Class Initialized
INFO - 2026-08-19 03:28:13 --> Helper loaded: entitlement_helper
DEBUG - 2026-08-19 03:28:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:28:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:28:13 --> Encryption Class Initialized
INFO - 2026-08-19 03:28:13 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:28:13 --> Router Class Initialized
INFO - 2026-08-19 03:28:13 --> Form Validation Class Initialized
INFO - 2026-08-19 03:28:13 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:28:13 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:28:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:28:13 --> Pagination Class Initialized
INFO - 2026-08-19 03:28:13 --> Output Class Initialized
INFO - 2026-08-19 03:28:13 --> Security Class Initialized
DEBUG - 2026-08-19 03:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:28:13 --> CSRF cookie sent
INFO - 2026-08-19 03:28:13 --> Input Class Initialized
INFO - 2026-08-19 03:28:13 --> Email Class Initialized
INFO - 2026-08-19 03:28:13 --> Language Class Initialized
INFO - 2026-08-19 03:28:13 --> Controller Class Initialized
INFO - 2026-08-19 03:28:13 --> Database Driver Class Initialized
ERROR - 2026-08-19 03:28:13 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:28:13 --> Database Driver Class Initialized
INFO - 2026-08-19 03:28:13 --> Language Class Initialized
INFO - 2026-08-19 03:28:13 --> Config Class Initialized
INFO - 2026-08-19 03:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:28:13 --> Upload Class Initialized
DEBUG - 2026-08-19 03:28:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:28:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:28:13 --> Encryption Class Initialized
INFO - 2026-08-19 03:28:13 --> Loader Class Initialized
INFO - 2026-08-19 03:28:13 --> Helper loaded: url_helper
INFO - 2026-08-19 03:28:13 --> Form Validation Class Initialized
INFO - 2026-08-19 03:28:13 --> Helper loaded: form_helper
INFO - 2026-08-19 03:28:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:28:13 --> Pagination Class Initialized
INFO - 2026-08-19 03:28:13 --> Helper loaded: html_helper
INFO - 2026-08-19 03:28:13 --> Helper loaded: file_helper
INFO - 2026-08-19 03:28:13 --> Helper loaded: email_helper
INFO - 2026-08-19 03:28:13 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:28:13 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:28:13 --> Email Class Initialized
INFO - 2026-08-19 03:28:13 --> Controller Class Initialized
ERROR - 2026-08-19 03:28:13 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:28:13 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:28:13 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:28:13 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:28:13 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:28:13 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:28:13 --> Database Driver Class Initialized
INFO - 2026-08-19 03:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:28:15 --> Upload Class Initialized
DEBUG - 2026-08-19 03:28:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:28:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:28:15 --> Encryption Class Initialized
INFO - 2026-08-19 03:28:15 --> Form Validation Class Initialized
INFO - 2026-08-19 03:28:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:28:15 --> Pagination Class Initialized
INFO - 2026-08-19 03:28:15 --> Email Class Initialized
INFO - 2026-08-19 03:28:15 --> Controller Class Initialized
DEBUG - 2026-08-19 03:28:15 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:28:15 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:28:15 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:28:15 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:28:15 --> Model "Common_model" initialized
INFO - 2026-08-19 03:28:15 --> Model "Order_model" initialized
INFO - 2026-08-19 03:28:15 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:28:15 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:28:15 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:28:15 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:28:15 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:28:15 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:28:15 --> Final output sent to browser
DEBUG - 2026-08-19 03:28:15 --> Total execution time: 2.0462
INFO - 2026-08-19 03:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:28:15 --> Upload Class Initialized
DEBUG - 2026-08-19 03:28:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:28:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:28:15 --> Encryption Class Initialized
INFO - 2026-08-19 03:28:15 --> Form Validation Class Initialized
INFO - 2026-08-19 03:28:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:28:15 --> Pagination Class Initialized
INFO - 2026-08-19 03:28:15 --> Email Class Initialized
INFO - 2026-08-19 03:28:15 --> Controller Class Initialized
DEBUG - 2026-08-19 03:28:15 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:28:15 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:28:15 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:28:15 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:28:15 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:28:16 --> Upload Class Initialized
DEBUG - 2026-08-19 03:28:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:28:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:28:16 --> Encryption Class Initialized
INFO - 2026-08-19 03:28:16 --> Form Validation Class Initialized
INFO - 2026-08-19 03:28:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:28:16 --> Pagination Class Initialized
INFO - 2026-08-19 03:28:16 --> Email Class Initialized
INFO - 2026-08-19 03:28:16 --> Controller Class Initialized
ERROR - 2026-08-19 03:28:16 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:28:27 --> Config Class Initialized
INFO - 2026-08-19 03:28:27 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:28:27 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:28:27 --> Utf8 Class Initialized
INFO - 2026-08-19 03:28:27 --> URI Class Initialized
INFO - 2026-08-19 03:28:27 --> Router Class Initialized
INFO - 2026-08-19 03:28:27 --> Output Class Initialized
INFO - 2026-08-19 03:28:27 --> Security Class Initialized
DEBUG - 2026-08-19 03:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:28:27 --> CSRF cookie sent
INFO - 2026-08-19 03:28:27 --> Input Class Initialized
INFO - 2026-08-19 03:28:27 --> Language Class Initialized
INFO - 2026-08-19 03:28:27 --> Language Class Initialized
INFO - 2026-08-19 03:28:27 --> Config Class Initialized
INFO - 2026-08-19 03:28:27 --> Loader Class Initialized
INFO - 2026-08-19 03:28:27 --> Helper loaded: url_helper
INFO - 2026-08-19 03:28:27 --> Helper loaded: form_helper
INFO - 2026-08-19 03:28:27 --> Helper loaded: html_helper
INFO - 2026-08-19 03:28:27 --> Helper loaded: file_helper
INFO - 2026-08-19 03:28:27 --> Helper loaded: email_helper
INFO - 2026-08-19 03:28:27 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:28:27 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:28:27 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:28:27 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:28:27 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:28:27 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:28:27 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:28:27 --> Database Driver Class Initialized
INFO - 2026-08-19 03:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:28:29 --> Upload Class Initialized
DEBUG - 2026-08-19 03:28:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:28:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:28:29 --> Encryption Class Initialized
INFO - 2026-08-19 03:28:29 --> Form Validation Class Initialized
INFO - 2026-08-19 03:28:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:28:29 --> Pagination Class Initialized
INFO - 2026-08-19 03:28:29 --> Email Class Initialized
INFO - 2026-08-19 03:28:29 --> Controller Class Initialized
DEBUG - 2026-08-19 03:28:29 --> Invoicing MX_Controller Initialized
INFO - 2026-08-19 03:28:29 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:28:29 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:28:29 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:28:29 --> Model "Billing_model" initialized
INFO - 2026-08-19 03:28:29 --> Model "Common_model" initialized
INFO - 2026-08-19 03:28:29 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-19 03:28:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/invoicing/views/invoicing_invoice_pdf_html.php
INFO - 2026-08-19 03:28:31 --> Final output sent to browser
DEBUG - 2026-08-19 03:28:31 --> Total execution time: 3.5763
INFO - 2026-08-19 03:28:45 --> Config Class Initialized
INFO - 2026-08-19 03:28:45 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:28:45 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:28:45 --> Utf8 Class Initialized
INFO - 2026-08-19 03:28:45 --> URI Class Initialized
INFO - 2026-08-19 03:28:45 --> Router Class Initialized
INFO - 2026-08-19 03:28:45 --> Output Class Initialized
INFO - 2026-08-19 03:28:45 --> Security Class Initialized
DEBUG - 2026-08-19 03:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:28:45 --> CSRF cookie sent
INFO - 2026-08-19 03:28:45 --> Input Class Initialized
INFO - 2026-08-19 03:28:45 --> Language Class Initialized
INFO - 2026-08-19 03:28:45 --> Language Class Initialized
INFO - 2026-08-19 03:28:45 --> Config Class Initialized
INFO - 2026-08-19 03:28:45 --> Loader Class Initialized
INFO - 2026-08-19 03:28:45 --> Helper loaded: url_helper
INFO - 2026-08-19 03:28:45 --> Helper loaded: form_helper
INFO - 2026-08-19 03:28:45 --> Helper loaded: html_helper
INFO - 2026-08-19 03:28:45 --> Helper loaded: file_helper
INFO - 2026-08-19 03:28:45 --> Helper loaded: email_helper
INFO - 2026-08-19 03:28:45 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:28:45 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:28:45 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:28:45 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:28:45 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:28:45 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:28:45 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:28:45 --> Database Driver Class Initialized
INFO - 2026-08-19 03:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:28:47 --> Upload Class Initialized
DEBUG - 2026-08-19 03:28:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:28:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:28:47 --> Encryption Class Initialized
INFO - 2026-08-19 03:28:47 --> Form Validation Class Initialized
INFO - 2026-08-19 03:28:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:28:47 --> Pagination Class Initialized
INFO - 2026-08-19 03:28:47 --> Email Class Initialized
INFO - 2026-08-19 03:28:47 --> Controller Class Initialized
DEBUG - 2026-08-19 03:28:47 --> Invoicing MX_Controller Initialized
INFO - 2026-08-19 03:28:47 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:28:47 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:28:47 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:28:47 --> Model "Billing_model" initialized
INFO - 2026-08-19 03:28:47 --> Model "Common_model" initialized
INFO - 2026-08-19 03:28:47 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:28:48 --> Config Class Initialized
INFO - 2026-08-19 03:28:48 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:28:48 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:28:48 --> Utf8 Class Initialized
INFO - 2026-08-19 03:28:48 --> URI Class Initialized
INFO - 2026-08-19 03:28:48 --> Router Class Initialized
INFO - 2026-08-19 03:28:48 --> Output Class Initialized
INFO - 2026-08-19 03:28:48 --> Security Class Initialized
DEBUG - 2026-08-19 03:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:28:48 --> CSRF cookie sent
INFO - 2026-08-19 03:28:48 --> Input Class Initialized
INFO - 2026-08-19 03:28:48 --> Language Class Initialized
INFO - 2026-08-19 03:28:48 --> Language Class Initialized
INFO - 2026-08-19 03:28:48 --> Config Class Initialized
INFO - 2026-08-19 03:28:48 --> Loader Class Initialized
INFO - 2026-08-19 03:28:48 --> Helper loaded: url_helper
INFO - 2026-08-19 03:28:48 --> Helper loaded: form_helper
INFO - 2026-08-19 03:28:48 --> Helper loaded: html_helper
INFO - 2026-08-19 03:28:48 --> Helper loaded: file_helper
INFO - 2026-08-19 03:28:48 --> Helper loaded: email_helper
INFO - 2026-08-19 03:28:48 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:28:48 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:28:48 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:28:48 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:28:48 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:28:48 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:28:48 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:28:48 --> Database Driver Class Initialized
DEBUG - 2026-08-19 03:28:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:28:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-08-19 03:28:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:28:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:28:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/invoicing/views/invoicing_invoices.php
INFO - 2026-08-19 03:28:50 --> Final output sent to browser
DEBUG - 2026-08-19 03:28:50 --> Total execution time: 4.3707
INFO - 2026-08-19 03:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:28:50 --> Upload Class Initialized
DEBUG - 2026-08-19 03:28:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:28:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:28:50 --> Encryption Class Initialized
INFO - 2026-08-19 03:28:50 --> Form Validation Class Initialized
INFO - 2026-08-19 03:28:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:28:50 --> Pagination Class Initialized
INFO - 2026-08-19 03:28:50 --> Email Class Initialized
INFO - 2026-08-19 03:28:50 --> Controller Class Initialized
DEBUG - 2026-08-19 03:28:50 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:28:50 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:28:50 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:28:50 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:28:50 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:28:50 --> Config Class Initialized
INFO - 2026-08-19 03:28:50 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:28:50 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:28:50 --> Utf8 Class Initialized
INFO - 2026-08-19 03:28:50 --> URI Class Initialized
INFO - 2026-08-19 03:28:50 --> Router Class Initialized
INFO - 2026-08-19 03:28:50 --> Output Class Initialized
INFO - 2026-08-19 03:28:50 --> Security Class Initialized
DEBUG - 2026-08-19 03:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:28:50 --> CSRF cookie sent
INFO - 2026-08-19 03:28:50 --> Input Class Initialized
INFO - 2026-08-19 03:28:50 --> Language Class Initialized
INFO - 2026-08-19 03:28:50 --> Language Class Initialized
INFO - 2026-08-19 03:28:50 --> Config Class Initialized
INFO - 2026-08-19 03:28:50 --> Loader Class Initialized
INFO - 2026-08-19 03:28:50 --> Helper loaded: url_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: form_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: html_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: file_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: email_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:28:50 --> Database Driver Class Initialized
INFO - 2026-08-19 03:28:50 --> Config Class Initialized
INFO - 2026-08-19 03:28:50 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:28:50 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:28:50 --> Utf8 Class Initialized
INFO - 2026-08-19 03:28:50 --> URI Class Initialized
INFO - 2026-08-19 03:28:50 --> Router Class Initialized
INFO - 2026-08-19 03:28:50 --> Output Class Initialized
INFO - 2026-08-19 03:28:50 --> Security Class Initialized
DEBUG - 2026-08-19 03:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:28:50 --> CSRF cookie sent
INFO - 2026-08-19 03:28:50 --> Input Class Initialized
INFO - 2026-08-19 03:28:50 --> Language Class Initialized
INFO - 2026-08-19 03:28:50 --> Language Class Initialized
INFO - 2026-08-19 03:28:50 --> Config Class Initialized
INFO - 2026-08-19 03:28:50 --> Loader Class Initialized
INFO - 2026-08-19 03:28:50 --> Helper loaded: url_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: form_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: html_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: file_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: email_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:28:50 --> Config Class Initialized
INFO - 2026-08-19 03:28:50 --> Hooks Class Initialized
INFO - 2026-08-19 03:28:50 --> Helper loaded: directadmin_helper
DEBUG - 2026-08-19 03:28:50 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:28:50 --> Utf8 Class Initialized
INFO - 2026-08-19 03:28:50 --> URI Class Initialized
INFO - 2026-08-19 03:28:50 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:28:50 --> Router Class Initialized
INFO - 2026-08-19 03:28:50 --> Output Class Initialized
INFO - 2026-08-19 03:28:50 --> Security Class Initialized
INFO - 2026-08-19 03:28:50 --> Database Driver Class Initialized
DEBUG - 2026-08-19 03:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:28:50 --> CSRF cookie sent
INFO - 2026-08-19 03:28:50 --> Input Class Initialized
INFO - 2026-08-19 03:28:50 --> Language Class Initialized
INFO - 2026-08-19 03:28:50 --> Language Class Initialized
INFO - 2026-08-19 03:28:50 --> Config Class Initialized
INFO - 2026-08-19 03:28:50 --> Loader Class Initialized
INFO - 2026-08-19 03:28:50 --> Helper loaded: url_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: form_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: html_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: file_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: email_helper
INFO - 2026-08-19 03:28:50 --> Config Class Initialized
INFO - 2026-08-19 03:28:50 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:28:50 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:28:50 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:28:50 --> Utf8 Class Initialized
INFO - 2026-08-19 03:28:50 --> URI Class Initialized
INFO - 2026-08-19 03:28:50 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:28:50 --> Config Class Initialized
INFO - 2026-08-19 03:28:50 --> Hooks Class Initialized
INFO - 2026-08-19 03:28:50 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:28:50 --> Router Class Initialized
DEBUG - 2026-08-19 03:28:50 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:28:50 --> Utf8 Class Initialized
INFO - 2026-08-19 03:28:50 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:28:50 --> URI Class Initialized
INFO - 2026-08-19 03:28:50 --> Output Class Initialized
INFO - 2026-08-19 03:28:50 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:28:50 --> Security Class Initialized
INFO - 2026-08-19 03:28:50 --> Router Class Initialized
DEBUG - 2026-08-19 03:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:28:50 --> CSRF cookie sent
INFO - 2026-08-19 03:28:50 --> Input Class Initialized
INFO - 2026-08-19 03:28:50 --> Language Class Initialized
INFO - 2026-08-19 03:28:50 --> Output Class Initialized
INFO - 2026-08-19 03:28:50 --> Language Class Initialized
INFO - 2026-08-19 03:28:50 --> Config Class Initialized
INFO - 2026-08-19 03:28:50 --> Security Class Initialized
DEBUG - 2026-08-19 03:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:28:50 --> CSRF cookie sent
INFO - 2026-08-19 03:28:50 --> Database Driver Class Initialized
INFO - 2026-08-19 03:28:50 --> Input Class Initialized
INFO - 2026-08-19 03:28:50 --> Language Class Initialized
INFO - 2026-08-19 03:28:50 --> Language Class Initialized
INFO - 2026-08-19 03:28:50 --> Config Class Initialized
INFO - 2026-08-19 03:28:50 --> Loader Class Initialized
INFO - 2026-08-19 03:28:50 --> Helper loaded: url_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: form_helper
INFO - 2026-08-19 03:28:50 --> Loader Class Initialized
INFO - 2026-08-19 03:28:50 --> Helper loaded: html_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: file_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: url_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: email_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: form_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: html_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: file_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: email_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:28:50 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:28:50 --> Database Driver Class Initialized
INFO - 2026-08-19 03:28:50 --> Database Driver Class Initialized
INFO - 2026-08-19 03:28:51 --> Config Class Initialized
INFO - 2026-08-19 03:28:51 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:28:51 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:28:51 --> Utf8 Class Initialized
INFO - 2026-08-19 03:28:51 --> URI Class Initialized
INFO - 2026-08-19 03:28:51 --> Router Class Initialized
INFO - 2026-08-19 03:28:51 --> Output Class Initialized
INFO - 2026-08-19 03:28:51 --> Security Class Initialized
DEBUG - 2026-08-19 03:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:28:51 --> CSRF cookie sent
INFO - 2026-08-19 03:28:51 --> Input Class Initialized
INFO - 2026-08-19 03:28:51 --> Language Class Initialized
INFO - 2026-08-19 03:28:51 --> Language Class Initialized
INFO - 2026-08-19 03:28:51 --> Config Class Initialized
INFO - 2026-08-19 03:28:51 --> Loader Class Initialized
INFO - 2026-08-19 03:28:51 --> Helper loaded: url_helper
INFO - 2026-08-19 03:28:51 --> Helper loaded: form_helper
INFO - 2026-08-19 03:28:51 --> Helper loaded: html_helper
INFO - 2026-08-19 03:28:51 --> Helper loaded: file_helper
INFO - 2026-08-19 03:28:51 --> Helper loaded: email_helper
INFO - 2026-08-19 03:28:51 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:28:51 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:28:51 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:28:51 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:28:51 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:28:51 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:28:51 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:28:51 --> Database Driver Class Initialized
INFO - 2026-08-19 03:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:28:52 --> Upload Class Initialized
DEBUG - 2026-08-19 03:28:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:28:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:28:52 --> Encryption Class Initialized
INFO - 2026-08-19 03:28:52 --> Form Validation Class Initialized
INFO - 2026-08-19 03:28:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:28:52 --> Pagination Class Initialized
INFO - 2026-08-19 03:28:52 --> Email Class Initialized
INFO - 2026-08-19 03:28:52 --> Controller Class Initialized
ERROR - 2026-08-19 03:28:52 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:28:52 --> Config Class Initialized
INFO - 2026-08-19 03:28:52 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:28:52 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:28:52 --> Utf8 Class Initialized
INFO - 2026-08-19 03:28:52 --> URI Class Initialized
INFO - 2026-08-19 03:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:28:52 --> Upload Class Initialized
INFO - 2026-08-19 03:28:52 --> Router Class Initialized
INFO - 2026-08-19 03:28:52 --> Output Class Initialized
DEBUG - 2026-08-19 03:28:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:28:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:28:52 --> Encryption Class Initialized
INFO - 2026-08-19 03:28:52 --> Security Class Initialized
INFO - 2026-08-19 03:28:52 --> Form Validation Class Initialized
DEBUG - 2026-08-19 03:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:28:52 --> CSRF cookie sent
INFO - 2026-08-19 03:28:52 --> Input Class Initialized
INFO - 2026-08-19 03:28:52 --> Language Class Initialized
INFO - 2026-08-19 03:28:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:28:52 --> Pagination Class Initialized
INFO - 2026-08-19 03:28:52 --> Language Class Initialized
INFO - 2026-08-19 03:28:52 --> Config Class Initialized
INFO - 2026-08-19 03:28:52 --> Loader Class Initialized
INFO - 2026-08-19 03:28:52 --> Email Class Initialized
INFO - 2026-08-19 03:28:52 --> Helper loaded: url_helper
INFO - 2026-08-19 03:28:52 --> Controller Class Initialized
ERROR - 2026-08-19 03:28:52 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:28:52 --> Helper loaded: form_helper
INFO - 2026-08-19 03:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:28:52 --> Helper loaded: html_helper
INFO - 2026-08-19 03:28:52 --> Helper loaded: file_helper
INFO - 2026-08-19 03:28:52 --> Helper loaded: email_helper
INFO - 2026-08-19 03:28:52 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:28:52 --> Upload Class Initialized
INFO - 2026-08-19 03:28:52 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:28:52 --> Helper loaded: cpanel_helper
DEBUG - 2026-08-19 03:28:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:28:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:28:52 --> Encryption Class Initialized
INFO - 2026-08-19 03:28:52 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:28:52 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:28:52 --> Form Validation Class Initialized
INFO - 2026-08-19 03:28:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:28:52 --> Pagination Class Initialized
INFO - 2026-08-19 03:28:52 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:28:52 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:28:52 --> Config Class Initialized
INFO - 2026-08-19 03:28:52 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:28:52 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:28:52 --> Utf8 Class Initialized
INFO - 2026-08-19 03:28:52 --> URI Class Initialized
INFO - 2026-08-19 03:28:52 --> Email Class Initialized
INFO - 2026-08-19 03:28:52 --> Controller Class Initialized
INFO - 2026-08-19 03:28:52 --> Router Class Initialized
ERROR - 2026-08-19 03:28:52 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:28:52 --> Database Driver Class Initialized
INFO - 2026-08-19 03:28:52 --> Output Class Initialized
INFO - 2026-08-19 03:28:52 --> Upload Class Initialized
INFO - 2026-08-19 03:28:52 --> Security Class Initialized
DEBUG - 2026-08-19 03:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:28:52 --> CSRF cookie sent
DEBUG - 2026-08-19 03:28:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:28:52 --> Input Class Initialized
INFO - 2026-08-19 03:28:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:28:52 --> Encryption Class Initialized
INFO - 2026-08-19 03:28:52 --> Language Class Initialized
INFO - 2026-08-19 03:28:52 --> Language Class Initialized
INFO - 2026-08-19 03:28:52 --> Config Class Initialized
INFO - 2026-08-19 03:28:52 --> Form Validation Class Initialized
INFO - 2026-08-19 03:28:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:28:52 --> Pagination Class Initialized
INFO - 2026-08-19 03:28:52 --> Loader Class Initialized
INFO - 2026-08-19 03:28:52 --> Email Class Initialized
INFO - 2026-08-19 03:28:52 --> Controller Class Initialized
INFO - 2026-08-19 03:28:52 --> Helper loaded: url_helper
INFO - 2026-08-19 03:28:52 --> Config Class Initialized
INFO - 2026-08-19 03:28:52 --> Hooks Class Initialized
INFO - 2026-08-19 03:28:52 --> Helper loaded: form_helper
DEBUG - 2026-08-19 03:28:52 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:28:52 --> Helper loaded: html_helper
INFO - 2026-08-19 03:28:52 --> Helper loaded: file_helper
DEBUG - 2026-08-19 03:28:52 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:28:52 --> Helper loaded: email_helper
INFO - 2026-08-19 03:28:52 --> Utf8 Class Initialized
INFO - 2026-08-19 03:28:52 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:28:52 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:28:52 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:28:52 --> URI Class Initialized
INFO - 2026-08-19 03:28:52 --> Model "Common_model" initialized
INFO - 2026-08-19 03:28:52 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:28:52 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:28:52 --> Model "Order_model" initialized
INFO - 2026-08-19 03:28:52 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:28:52 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:28:52 --> Router Class Initialized
INFO - 2026-08-19 03:28:52 --> Model "Promocode_model" initialized
INFO - 2026-08-19 03:28:52 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:28:52 --> Output Class Initialized
DEBUG - 2026-08-19 03:28:52 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:28:52 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:28:52 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:28:52 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:28:52 --> Security Class Initialized
INFO - 2026-08-19 03:28:52 --> Helper loaded: directadmin_helper
DEBUG - 2026-08-19 03:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:28:52 --> CSRF cookie sent
INFO - 2026-08-19 03:28:52 --> Input Class Initialized
INFO - 2026-08-19 03:28:52 --> Language Class Initialized
INFO - 2026-08-19 03:28:52 --> Language Class Initialized
INFO - 2026-08-19 03:28:52 --> Config Class Initialized
INFO - 2026-08-19 03:28:52 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:28:52 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:28:52 --> Loader Class Initialized
INFO - 2026-08-19 03:28:52 --> Helper loaded: url_helper
INFO - 2026-08-19 03:28:52 --> Helper loaded: form_helper
INFO - 2026-08-19 03:28:52 --> Helper loaded: html_helper
INFO - 2026-08-19 03:28:52 --> Helper loaded: file_helper
INFO - 2026-08-19 03:28:52 --> Helper loaded: email_helper
INFO - 2026-08-19 03:28:52 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:28:52 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:28:52 --> Database Driver Class Initialized
INFO - 2026-08-19 03:28:52 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:28:52 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:28:52 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:28:52 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:28:52 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:28:52 --> Database Driver Class Initialized
INFO - 2026-08-19 03:28:52 --> Final output sent to browser
DEBUG - 2026-08-19 03:28:52 --> Total execution time: 2.0023
INFO - 2026-08-19 03:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:28:52 --> Upload Class Initialized
DEBUG - 2026-08-19 03:28:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:28:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:28:52 --> Encryption Class Initialized
INFO - 2026-08-19 03:28:52 --> Form Validation Class Initialized
INFO - 2026-08-19 03:28:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:28:52 --> Pagination Class Initialized
INFO - 2026-08-19 03:28:52 --> Email Class Initialized
INFO - 2026-08-19 03:28:52 --> Controller Class Initialized
ERROR - 2026-08-19 03:28:52 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:28:52 --> Upload Class Initialized
DEBUG - 2026-08-19 03:28:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:28:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:28:52 --> Encryption Class Initialized
INFO - 2026-08-19 03:28:52 --> Form Validation Class Initialized
INFO - 2026-08-19 03:28:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:28:52 --> Pagination Class Initialized
INFO - 2026-08-19 03:28:52 --> Email Class Initialized
INFO - 2026-08-19 03:28:52 --> Controller Class Initialized
DEBUG - 2026-08-19 03:28:52 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:28:52 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:28:52 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:28:52 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:28:52 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:28:53 --> Upload Class Initialized
DEBUG - 2026-08-19 03:28:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:28:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:28:53 --> Encryption Class Initialized
INFO - 2026-08-19 03:28:53 --> Form Validation Class Initialized
INFO - 2026-08-19 03:28:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:28:53 --> Pagination Class Initialized
INFO - 2026-08-19 03:28:53 --> Email Class Initialized
INFO - 2026-08-19 03:28:53 --> Controller Class Initialized
ERROR - 2026-08-19 03:28:53 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:28:54 --> Upload Class Initialized
DEBUG - 2026-08-19 03:28:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:28:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:28:54 --> Encryption Class Initialized
INFO - 2026-08-19 03:28:54 --> Form Validation Class Initialized
INFO - 2026-08-19 03:28:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:28:54 --> Pagination Class Initialized
INFO - 2026-08-19 03:28:54 --> Email Class Initialized
INFO - 2026-08-19 03:28:54 --> Controller Class Initialized
ERROR - 2026-08-19 03:28:54 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:28:54 --> Upload Class Initialized
DEBUG - 2026-08-19 03:28:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:28:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:28:54 --> Encryption Class Initialized
INFO - 2026-08-19 03:28:54 --> Form Validation Class Initialized
INFO - 2026-08-19 03:28:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:28:54 --> Pagination Class Initialized
INFO - 2026-08-19 03:28:54 --> Email Class Initialized
INFO - 2026-08-19 03:28:54 --> Controller Class Initialized
ERROR - 2026-08-19 03:28:54 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:28:54 --> Config Class Initialized
INFO - 2026-08-19 03:28:54 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:28:54 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:28:54 --> Utf8 Class Initialized
INFO - 2026-08-19 03:28:54 --> URI Class Initialized
INFO - 2026-08-19 03:28:54 --> Router Class Initialized
INFO - 2026-08-19 03:28:54 --> Output Class Initialized
INFO - 2026-08-19 03:28:54 --> Security Class Initialized
DEBUG - 2026-08-19 03:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:28:54 --> CSRF cookie sent
INFO - 2026-08-19 03:28:54 --> Input Class Initialized
INFO - 2026-08-19 03:28:54 --> Language Class Initialized
INFO - 2026-08-19 03:28:54 --> Language Class Initialized
INFO - 2026-08-19 03:28:54 --> Config Class Initialized
INFO - 2026-08-19 03:28:54 --> Loader Class Initialized
INFO - 2026-08-19 03:28:54 --> Helper loaded: url_helper
INFO - 2026-08-19 03:28:54 --> Helper loaded: form_helper
INFO - 2026-08-19 03:28:54 --> Helper loaded: html_helper
INFO - 2026-08-19 03:28:54 --> Helper loaded: file_helper
INFO - 2026-08-19 03:28:54 --> Helper loaded: email_helper
INFO - 2026-08-19 03:28:54 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:28:54 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:28:54 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:28:54 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:28:54 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:28:54 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:28:54 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:28:54 --> Database Driver Class Initialized
INFO - 2026-08-19 03:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:28:56 --> Upload Class Initialized
DEBUG - 2026-08-19 03:28:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:28:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:28:56 --> Encryption Class Initialized
INFO - 2026-08-19 03:28:56 --> Form Validation Class Initialized
INFO - 2026-08-19 03:28:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:28:56 --> Pagination Class Initialized
INFO - 2026-08-19 03:28:56 --> Email Class Initialized
INFO - 2026-08-19 03:28:56 --> Controller Class Initialized
DEBUG - 2026-08-19 03:28:56 --> Pay MX_Controller Initialized
INFO - 2026-08-19 03:28:56 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:28:56 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:28:56 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:28:56 --> Model "Payment_model" initialized
INFO - 2026-08-19 03:28:56 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:28:56 --> Model "Billing_model" initialized
INFO - 2026-08-19 03:28:56 --> Model "Invoice_model" initialized
DEBUG - 2026-08-19 03:29:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:29:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:29:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:29:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/invoicing/views/invoicing_pay.php
INFO - 2026-08-19 03:29:00 --> Final output sent to browser
DEBUG - 2026-08-19 03:29:00 --> Total execution time: 5.5312
INFO - 2026-08-19 03:29:00 --> Config Class Initialized
INFO - 2026-08-19 03:29:00 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:29:00 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:29:00 --> Utf8 Class Initialized
INFO - 2026-08-19 03:29:00 --> URI Class Initialized
INFO - 2026-08-19 03:29:00 --> Router Class Initialized
INFO - 2026-08-19 03:29:00 --> Output Class Initialized
INFO - 2026-08-19 03:29:00 --> Security Class Initialized
DEBUG - 2026-08-19 03:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:29:00 --> CSRF cookie sent
INFO - 2026-08-19 03:29:00 --> Input Class Initialized
INFO - 2026-08-19 03:29:00 --> Language Class Initialized
INFO - 2026-08-19 03:29:00 --> Language Class Initialized
INFO - 2026-08-19 03:29:00 --> Config Class Initialized
INFO - 2026-08-19 03:29:00 --> Loader Class Initialized
INFO - 2026-08-19 03:29:00 --> Helper loaded: url_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: form_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: html_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: file_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: email_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:29:00 --> Database Driver Class Initialized
INFO - 2026-08-19 03:29:00 --> Config Class Initialized
INFO - 2026-08-19 03:29:00 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:29:00 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:29:00 --> Utf8 Class Initialized
INFO - 2026-08-19 03:29:00 --> URI Class Initialized
INFO - 2026-08-19 03:29:00 --> Router Class Initialized
INFO - 2026-08-19 03:29:00 --> Output Class Initialized
INFO - 2026-08-19 03:29:00 --> Security Class Initialized
DEBUG - 2026-08-19 03:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:29:00 --> CSRF cookie sent
INFO - 2026-08-19 03:29:00 --> Input Class Initialized
INFO - 2026-08-19 03:29:00 --> Language Class Initialized
INFO - 2026-08-19 03:29:00 --> Language Class Initialized
INFO - 2026-08-19 03:29:00 --> Config Class Initialized
INFO - 2026-08-19 03:29:00 --> Loader Class Initialized
INFO - 2026-08-19 03:29:00 --> Helper loaded: url_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: form_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: html_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: file_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: email_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:29:00 --> Database Driver Class Initialized
INFO - 2026-08-19 03:29:00 --> Config Class Initialized
INFO - 2026-08-19 03:29:00 --> Hooks Class Initialized
INFO - 2026-08-19 03:29:00 --> Config Class Initialized
INFO - 2026-08-19 03:29:00 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:29:00 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:29:00 --> Config Class Initialized
DEBUG - 2026-08-19 03:29:00 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:29:00 --> Hooks Class Initialized
INFO - 2026-08-19 03:29:00 --> Utf8 Class Initialized
INFO - 2026-08-19 03:29:00 --> URI Class Initialized
DEBUG - 2026-08-19 03:29:00 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:29:00 --> Utf8 Class Initialized
INFO - 2026-08-19 03:29:00 --> URI Class Initialized
INFO - 2026-08-19 03:29:00 --> Router Class Initialized
INFO - 2026-08-19 03:29:00 --> Router Class Initialized
INFO - 2026-08-19 03:29:00 --> Output Class Initialized
INFO - 2026-08-19 03:29:00 --> Security Class Initialized
INFO - 2026-08-19 03:29:00 --> Output Class Initialized
INFO - 2026-08-19 03:29:00 --> Utf8 Class Initialized
DEBUG - 2026-08-19 03:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:29:00 --> CSRF cookie sent
INFO - 2026-08-19 03:29:00 --> Input Class Initialized
INFO - 2026-08-19 03:29:00 --> URI Class Initialized
INFO - 2026-08-19 03:29:00 --> Language Class Initialized
INFO - 2026-08-19 03:29:00 --> Language Class Initialized
INFO - 2026-08-19 03:29:00 --> Config Class Initialized
INFO - 2026-08-19 03:29:00 --> Router Class Initialized
INFO - 2026-08-19 03:29:00 --> Config Class Initialized
INFO - 2026-08-19 03:29:00 --> Hooks Class Initialized
INFO - 2026-08-19 03:29:00 --> Output Class Initialized
DEBUG - 2026-08-19 03:29:00 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:29:00 --> Utf8 Class Initialized
INFO - 2026-08-19 03:29:00 --> URI Class Initialized
INFO - 2026-08-19 03:29:00 --> Security Class Initialized
DEBUG - 2026-08-19 03:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:29:00 --> CSRF cookie sent
INFO - 2026-08-19 03:29:00 --> Security Class Initialized
INFO - 2026-08-19 03:29:00 --> Router Class Initialized
INFO - 2026-08-19 03:29:00 --> Input Class Initialized
INFO - 2026-08-19 03:29:00 --> Language Class Initialized
INFO - 2026-08-19 03:29:00 --> Loader Class Initialized
INFO - 2026-08-19 03:29:00 --> Language Class Initialized
INFO - 2026-08-19 03:29:00 --> Output Class Initialized
DEBUG - 2026-08-19 03:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:29:00 --> Config Class Initialized
INFO - 2026-08-19 03:29:00 --> CSRF cookie sent
INFO - 2026-08-19 03:29:00 --> Input Class Initialized
INFO - 2026-08-19 03:29:00 --> Language Class Initialized
INFO - 2026-08-19 03:29:00 --> Helper loaded: url_helper
INFO - 2026-08-19 03:29:00 --> Language Class Initialized
INFO - 2026-08-19 03:29:00 --> Config Class Initialized
INFO - 2026-08-19 03:29:00 --> Helper loaded: form_helper
INFO - 2026-08-19 03:29:00 --> Loader Class Initialized
INFO - 2026-08-19 03:29:00 --> Helper loaded: html_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: file_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: url_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: email_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: form_helper
INFO - 2026-08-19 03:29:00 --> Security Class Initialized
INFO - 2026-08-19 03:29:00 --> Helper loaded: html_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: file_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: email_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: ssp_helper
DEBUG - 2026-08-19 03:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:29:00 --> CSRF cookie sent
INFO - 2026-08-19 03:29:00 --> Input Class Initialized
INFO - 2026-08-19 03:29:00 --> Language Class Initialized
INFO - 2026-08-19 03:29:00 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:29:00 --> Language Class Initialized
INFO - 2026-08-19 03:29:00 --> Config Class Initialized
INFO - 2026-08-19 03:29:00 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:29:00 --> Loader Class Initialized
INFO - 2026-08-19 03:29:00 --> Helper loaded: url_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: form_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:29:00 --> Loader Class Initialized
INFO - 2026-08-19 03:29:00 --> Helper loaded: html_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: file_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: url_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: email_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: form_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: html_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: file_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: email_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:29:00 --> Database Driver Class Initialized
INFO - 2026-08-19 03:29:00 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:29:00 --> Database Driver Class Initialized
INFO - 2026-08-19 03:29:00 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:29:00 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:29:00 --> Database Driver Class Initialized
INFO - 2026-08-19 03:29:00 --> Database Driver Class Initialized
INFO - 2026-08-19 03:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:29:02 --> Upload Class Initialized
DEBUG - 2026-08-19 03:29:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:29:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:29:02 --> Encryption Class Initialized
INFO - 2026-08-19 03:29:02 --> Form Validation Class Initialized
INFO - 2026-08-19 03:29:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:29:02 --> Pagination Class Initialized
INFO - 2026-08-19 03:29:02 --> Email Class Initialized
INFO - 2026-08-19 03:29:02 --> Controller Class Initialized
ERROR - 2026-08-19 03:29:02 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:29:02 --> Config Class Initialized
INFO - 2026-08-19 03:29:02 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:29:02 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:29:02 --> Utf8 Class Initialized
INFO - 2026-08-19 03:29:02 --> URI Class Initialized
INFO - 2026-08-19 03:29:02 --> Router Class Initialized
INFO - 2026-08-19 03:29:02 --> Output Class Initialized
INFO - 2026-08-19 03:29:02 --> Security Class Initialized
DEBUG - 2026-08-19 03:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:29:02 --> CSRF cookie sent
INFO - 2026-08-19 03:29:02 --> Input Class Initialized
INFO - 2026-08-19 03:29:02 --> Language Class Initialized
INFO - 2026-08-19 03:29:02 --> Language Class Initialized
INFO - 2026-08-19 03:29:02 --> Config Class Initialized
INFO - 2026-08-19 03:29:02 --> Loader Class Initialized
INFO - 2026-08-19 03:29:02 --> Helper loaded: url_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: form_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: html_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: file_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: email_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:29:02 --> Database Driver Class Initialized
INFO - 2026-08-19 03:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:29:02 --> Upload Class Initialized
DEBUG - 2026-08-19 03:29:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:29:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:29:02 --> Encryption Class Initialized
INFO - 2026-08-19 03:29:02 --> Form Validation Class Initialized
INFO - 2026-08-19 03:29:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:29:02 --> Pagination Class Initialized
INFO - 2026-08-19 03:29:02 --> Email Class Initialized
INFO - 2026-08-19 03:29:02 --> Controller Class Initialized
ERROR - 2026-08-19 03:29:02 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:29:02 --> Config Class Initialized
INFO - 2026-08-19 03:29:02 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:29:02 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:29:02 --> Utf8 Class Initialized
INFO - 2026-08-19 03:29:02 --> URI Class Initialized
INFO - 2026-08-19 03:29:02 --> Router Class Initialized
INFO - 2026-08-19 03:29:02 --> Output Class Initialized
INFO - 2026-08-19 03:29:02 --> Security Class Initialized
DEBUG - 2026-08-19 03:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:29:02 --> CSRF cookie sent
INFO - 2026-08-19 03:29:02 --> Input Class Initialized
INFO - 2026-08-19 03:29:02 --> Language Class Initialized
INFO - 2026-08-19 03:29:02 --> Language Class Initialized
INFO - 2026-08-19 03:29:02 --> Config Class Initialized
INFO - 2026-08-19 03:29:02 --> Loader Class Initialized
INFO - 2026-08-19 03:29:02 --> Helper loaded: url_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: form_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: html_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: file_helper
INFO - 2026-08-19 03:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:29:02 --> Helper loaded: email_helper
INFO - 2026-08-19 03:29:02 --> Upload Class Initialized
INFO - 2026-08-19 03:29:02 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: ssp_helper
DEBUG - 2026-08-19 03:29:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:29:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:29:02 --> Encryption Class Initialized
INFO - 2026-08-19 03:29:02 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:29:02 --> Form Validation Class Initialized
INFO - 2026-08-19 03:29:02 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:29:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:29:02 --> Pagination Class Initialized
INFO - 2026-08-19 03:29:02 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:29:02 --> Email Class Initialized
INFO - 2026-08-19 03:29:02 --> Controller Class Initialized
ERROR - 2026-08-19 03:29:02 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:29:02 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:29:02 --> Database Driver Class Initialized
INFO - 2026-08-19 03:29:02 --> Config Class Initialized
INFO - 2026-08-19 03:29:02 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:29:02 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:29:02 --> Utf8 Class Initialized
INFO - 2026-08-19 03:29:02 --> URI Class Initialized
INFO - 2026-08-19 03:29:02 --> Router Class Initialized
INFO - 2026-08-19 03:29:02 --> Output Class Initialized
INFO - 2026-08-19 03:29:02 --> Security Class Initialized
DEBUG - 2026-08-19 03:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:29:02 --> CSRF cookie sent
INFO - 2026-08-19 03:29:02 --> Input Class Initialized
INFO - 2026-08-19 03:29:02 --> Language Class Initialized
INFO - 2026-08-19 03:29:02 --> Language Class Initialized
INFO - 2026-08-19 03:29:02 --> Config Class Initialized
INFO - 2026-08-19 03:29:02 --> Loader Class Initialized
INFO - 2026-08-19 03:29:02 --> Helper loaded: url_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: form_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: html_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: file_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: email_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:29:02 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:29:02 --> Database Driver Class Initialized
INFO - 2026-08-19 03:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:29:03 --> Upload Class Initialized
DEBUG - 2026-08-19 03:29:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:29:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:29:03 --> Encryption Class Initialized
INFO - 2026-08-19 03:29:03 --> Form Validation Class Initialized
INFO - 2026-08-19 03:29:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:29:03 --> Pagination Class Initialized
INFO - 2026-08-19 03:29:03 --> Email Class Initialized
INFO - 2026-08-19 03:29:03 --> Controller Class Initialized
ERROR - 2026-08-19 03:29:03 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:29:03 --> Upload Class Initialized
DEBUG - 2026-08-19 03:29:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:29:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:29:03 --> Encryption Class Initialized
INFO - 2026-08-19 03:29:03 --> Form Validation Class Initialized
INFO - 2026-08-19 03:29:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:29:03 --> Pagination Class Initialized
INFO - 2026-08-19 03:29:03 --> Email Class Initialized
INFO - 2026-08-19 03:29:03 --> Controller Class Initialized
ERROR - 2026-08-19 03:29:03 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:29:03 --> Upload Class Initialized
DEBUG - 2026-08-19 03:29:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:29:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:29:03 --> Encryption Class Initialized
INFO - 2026-08-19 03:29:03 --> Form Validation Class Initialized
INFO - 2026-08-19 03:29:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:29:03 --> Pagination Class Initialized
INFO - 2026-08-19 03:29:03 --> Email Class Initialized
INFO - 2026-08-19 03:29:03 --> Controller Class Initialized
ERROR - 2026-08-19 03:29:03 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:29:03 --> Upload Class Initialized
DEBUG - 2026-08-19 03:29:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:29:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:29:03 --> Encryption Class Initialized
INFO - 2026-08-19 03:29:03 --> Form Validation Class Initialized
INFO - 2026-08-19 03:29:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:29:03 --> Pagination Class Initialized
INFO - 2026-08-19 03:29:03 --> Email Class Initialized
INFO - 2026-08-19 03:29:03 --> Controller Class Initialized
DEBUG - 2026-08-19 03:29:03 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:29:03 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:29:03 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:29:03 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:29:03 --> Model "Common_model" initialized
INFO - 2026-08-19 03:29:03 --> Model "Order_model" initialized
INFO - 2026-08-19 03:29:03 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:29:03 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:29:03 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:29:03 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:29:03 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:29:03 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:29:04 --> Final output sent to browser
DEBUG - 2026-08-19 03:29:04 --> Total execution time: 1.8104
INFO - 2026-08-19 03:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:29:04 --> Upload Class Initialized
DEBUG - 2026-08-19 03:29:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:29:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:29:04 --> Encryption Class Initialized
INFO - 2026-08-19 03:29:04 --> Form Validation Class Initialized
INFO - 2026-08-19 03:29:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:29:04 --> Pagination Class Initialized
INFO - 2026-08-19 03:29:04 --> Email Class Initialized
INFO - 2026-08-19 03:29:04 --> Controller Class Initialized
ERROR - 2026-08-19 03:29:04 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:29:04 --> Upload Class Initialized
DEBUG - 2026-08-19 03:29:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:29:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:29:04 --> Encryption Class Initialized
INFO - 2026-08-19 03:29:04 --> Form Validation Class Initialized
INFO - 2026-08-19 03:29:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:29:04 --> Pagination Class Initialized
INFO - 2026-08-19 03:29:04 --> Email Class Initialized
INFO - 2026-08-19 03:29:04 --> Controller Class Initialized
DEBUG - 2026-08-19 03:29:04 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:29:04 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:29:04 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:29:04 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:29:04 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:29:25 --> Config Class Initialized
INFO - 2026-08-19 03:29:25 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:29:25 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:29:25 --> Utf8 Class Initialized
INFO - 2026-08-19 03:29:25 --> URI Class Initialized
INFO - 2026-08-19 03:29:25 --> Router Class Initialized
INFO - 2026-08-19 03:29:25 --> Output Class Initialized
INFO - 2026-08-19 03:29:25 --> Security Class Initialized
DEBUG - 2026-08-19 03:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:29:25 --> CSRF cookie sent
INFO - 2026-08-19 03:29:25 --> CSRF token verified
INFO - 2026-08-19 03:29:25 --> Input Class Initialized
INFO - 2026-08-19 03:29:25 --> Language Class Initialized
INFO - 2026-08-19 03:29:25 --> Language Class Initialized
INFO - 2026-08-19 03:29:25 --> Config Class Initialized
INFO - 2026-08-19 03:29:25 --> Loader Class Initialized
INFO - 2026-08-19 03:29:25 --> Helper loaded: url_helper
INFO - 2026-08-19 03:29:25 --> Helper loaded: form_helper
INFO - 2026-08-19 03:29:25 --> Helper loaded: html_helper
INFO - 2026-08-19 03:29:25 --> Helper loaded: file_helper
INFO - 2026-08-19 03:29:25 --> Helper loaded: email_helper
INFO - 2026-08-19 03:29:25 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:29:25 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:29:25 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:29:25 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:29:25 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:29:25 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:29:25 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:29:25 --> Database Driver Class Initialized
INFO - 2026-08-19 03:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:29:27 --> Upload Class Initialized
DEBUG - 2026-08-19 03:29:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:29:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:29:27 --> Encryption Class Initialized
INFO - 2026-08-19 03:29:27 --> Form Validation Class Initialized
INFO - 2026-08-19 03:29:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:29:27 --> Pagination Class Initialized
INFO - 2026-08-19 03:29:27 --> Email Class Initialized
INFO - 2026-08-19 03:29:27 --> Controller Class Initialized
DEBUG - 2026-08-19 03:29:27 --> Pay MX_Controller Initialized
INFO - 2026-08-19 03:29:27 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:29:27 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:29:27 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:29:27 --> Model "Payment_model" initialized
INFO - 2026-08-19 03:29:27 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:29:27 --> Model "Billing_model" initialized
INFO - 2026-08-19 03:29:27 --> Model "Invoice_model" initialized
INFO - 2026-08-19 03:29:32 --> Final output sent to browser
DEBUG - 2026-08-19 03:29:32 --> Total execution time: 6.3855
INFO - 2026-08-19 03:29:49 --> Config Class Initialized
INFO - 2026-08-19 03:29:49 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:29:49 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:29:49 --> Utf8 Class Initialized
INFO - 2026-08-19 03:29:49 --> URI Class Initialized
INFO - 2026-08-19 03:29:49 --> Router Class Initialized
INFO - 2026-08-19 03:29:49 --> Output Class Initialized
INFO - 2026-08-19 03:29:49 --> Security Class Initialized
DEBUG - 2026-08-19 03:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:29:49 --> CSRF cookie sent
INFO - 2026-08-19 03:29:49 --> Input Class Initialized
INFO - 2026-08-19 03:29:49 --> Language Class Initialized
INFO - 2026-08-19 03:29:49 --> Language Class Initialized
INFO - 2026-08-19 03:29:49 --> Config Class Initialized
INFO - 2026-08-19 03:29:49 --> Loader Class Initialized
INFO - 2026-08-19 03:29:49 --> Helper loaded: url_helper
INFO - 2026-08-19 03:29:49 --> Helper loaded: form_helper
INFO - 2026-08-19 03:29:49 --> Helper loaded: html_helper
INFO - 2026-08-19 03:29:49 --> Helper loaded: file_helper
INFO - 2026-08-19 03:29:49 --> Helper loaded: email_helper
INFO - 2026-08-19 03:29:49 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:29:49 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:29:49 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:29:49 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:29:49 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:29:49 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:29:49 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:29:49 --> Database Driver Class Initialized
INFO - 2026-08-19 03:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:29:50 --> Upload Class Initialized
DEBUG - 2026-08-19 03:29:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:29:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:29:50 --> Encryption Class Initialized
INFO - 2026-08-19 03:29:50 --> Form Validation Class Initialized
INFO - 2026-08-19 03:29:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:29:50 --> Pagination Class Initialized
INFO - 2026-08-19 03:29:50 --> Email Class Initialized
INFO - 2026-08-19 03:29:50 --> Controller Class Initialized
DEBUG - 2026-08-19 03:29:50 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:29:50 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:29:50 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:29:50 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:29:50 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:29:54 --> Config Class Initialized
INFO - 2026-08-19 03:29:54 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:29:54 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:29:54 --> Utf8 Class Initialized
INFO - 2026-08-19 03:29:54 --> URI Class Initialized
INFO - 2026-08-19 03:29:54 --> Router Class Initialized
INFO - 2026-08-19 03:29:54 --> Output Class Initialized
INFO - 2026-08-19 03:29:54 --> Security Class Initialized
DEBUG - 2026-08-19 03:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:29:54 --> Input Class Initialized
INFO - 2026-08-19 03:29:54 --> Language Class Initialized
INFO - 2026-08-19 03:29:54 --> Language Class Initialized
INFO - 2026-08-19 03:29:54 --> Config Class Initialized
INFO - 2026-08-19 03:29:54 --> Loader Class Initialized
INFO - 2026-08-19 03:29:54 --> Helper loaded: url_helper
INFO - 2026-08-19 03:29:54 --> Helper loaded: form_helper
INFO - 2026-08-19 03:29:54 --> Helper loaded: html_helper
INFO - 2026-08-19 03:29:54 --> Helper loaded: file_helper
INFO - 2026-08-19 03:29:54 --> Helper loaded: email_helper
INFO - 2026-08-19 03:29:54 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:29:54 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:29:54 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:29:54 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:29:54 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:29:54 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:29:54 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:29:54 --> Database Driver Class Initialized
INFO - 2026-08-19 03:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:29:56 --> Upload Class Initialized
DEBUG - 2026-08-19 03:29:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:29:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:29:56 --> Encryption Class Initialized
INFO - 2026-08-19 03:29:56 --> Form Validation Class Initialized
INFO - 2026-08-19 03:29:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:29:56 --> Pagination Class Initialized
INFO - 2026-08-19 03:29:56 --> Email Class Initialized
INFO - 2026-08-19 03:29:56 --> Controller Class Initialized
DEBUG - 2026-08-19 03:29:56 --> Pay MX_Controller Initialized
INFO - 2026-08-19 03:29:56 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:29:56 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:29:56 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:29:56 --> Model "Payment_model" initialized
INFO - 2026-08-19 03:29:56 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:29:56 --> Model "Billing_model" initialized
INFO - 2026-08-19 03:29:56 --> Model "Invoice_model" initialized
INFO - 2026-08-19 03:30:01 --> Model "Provisioning_model" initialized
INFO - 2026-08-19 03:30:02 --> Provisioning: Renewing service #801
INFO - 2026-08-19 03:30:02 --> Service renewed: #801, Actions: 
INFO - 2026-08-19 03:30:04 --> Provisioning: Renewing domain kandyleaftea.com
INFO - 2026-08-19 03:30:05 --> Provisioning completed for invoice #804 - Total: 2, Success: 1, Failed: 1
INFO - 2026-08-19 03:30:05 --> provisionPaidServices completed for invoice #804 - Success: 1/2
INFO - 2026-08-19 03:30:14 --> Model "Syscnf_model" initialized
INFO - 2026-08-19 03:30:21 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:30:22 --> Payment confirmation emails sent for transaction #11 - Customer: Yes, Admin: Yes
INFO - 2026-08-19 03:30:22 --> Invoice #804 marked as PAID. Total: 55.94, Paid: 55.94
INFO - 2026-08-19 03:30:24 --> Config Class Initialized
INFO - 2026-08-19 03:30:24 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:30:24 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:30:24 --> Utf8 Class Initialized
INFO - 2026-08-19 03:30:24 --> URI Class Initialized
INFO - 2026-08-19 03:30:24 --> Router Class Initialized
INFO - 2026-08-19 03:30:24 --> Output Class Initialized
INFO - 2026-08-19 03:30:24 --> Security Class Initialized
DEBUG - 2026-08-19 03:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:30:24 --> CSRF cookie sent
INFO - 2026-08-19 03:30:24 --> Input Class Initialized
INFO - 2026-08-19 03:30:24 --> Language Class Initialized
INFO - 2026-08-19 03:30:24 --> Language Class Initialized
INFO - 2026-08-19 03:30:24 --> Config Class Initialized
INFO - 2026-08-19 03:30:24 --> Loader Class Initialized
INFO - 2026-08-19 03:30:24 --> Helper loaded: url_helper
INFO - 2026-08-19 03:30:24 --> Helper loaded: form_helper
INFO - 2026-08-19 03:30:24 --> Helper loaded: html_helper
INFO - 2026-08-19 03:30:24 --> Helper loaded: file_helper
INFO - 2026-08-19 03:30:24 --> Helper loaded: email_helper
INFO - 2026-08-19 03:30:24 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:30:24 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:30:24 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:30:24 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:30:24 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:30:24 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:30:24 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:30:24 --> Database Driver Class Initialized
INFO - 2026-08-19 03:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:30:26 --> Upload Class Initialized
DEBUG - 2026-08-19 03:30:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:30:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:30:26 --> Encryption Class Initialized
INFO - 2026-08-19 03:30:26 --> Form Validation Class Initialized
INFO - 2026-08-19 03:30:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:30:26 --> Pagination Class Initialized
INFO - 2026-08-19 03:30:26 --> Email Class Initialized
INFO - 2026-08-19 03:30:26 --> Controller Class Initialized
DEBUG - 2026-08-19 03:30:26 --> Invoicing MX_Controller Initialized
INFO - 2026-08-19 03:30:26 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:30:26 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:30:26 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:30:26 --> Model "Billing_model" initialized
INFO - 2026-08-19 03:30:26 --> Model "Common_model" initialized
INFO - 2026-08-19 03:30:26 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-19 03:30:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/invoicing/views/invoicing_invoice_pdf_html.php
DEBUG - 2026-08-19 03:30:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:30:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-08-19 03:30:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:30:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:30:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/invoicing/views/invoicing_viewinvoice.php
INFO - 2026-08-19 03:30:28 --> Final output sent to browser
DEBUG - 2026-08-19 03:30:28 --> Total execution time: 4.0920
INFO - 2026-08-19 03:30:28 --> Config Class Initialized
INFO - 2026-08-19 03:30:28 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:30:28 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:30:28 --> Utf8 Class Initialized
INFO - 2026-08-19 03:30:28 --> URI Class Initialized
INFO - 2026-08-19 03:30:28 --> Router Class Initialized
INFO - 2026-08-19 03:30:28 --> Output Class Initialized
INFO - 2026-08-19 03:30:28 --> Security Class Initialized
DEBUG - 2026-08-19 03:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:30:28 --> CSRF cookie sent
INFO - 2026-08-19 03:30:28 --> Input Class Initialized
INFO - 2026-08-19 03:30:28 --> Language Class Initialized
INFO - 2026-08-19 03:30:28 --> Language Class Initialized
INFO - 2026-08-19 03:30:28 --> Config Class Initialized
INFO - 2026-08-19 03:30:28 --> Loader Class Initialized
INFO - 2026-08-19 03:30:28 --> Helper loaded: url_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: form_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: html_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: file_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: email_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:30:28 --> Config Class Initialized
INFO - 2026-08-19 03:30:28 --> Hooks Class Initialized
INFO - 2026-08-19 03:30:28 --> Helper loaded: cpanel_helper
DEBUG - 2026-08-19 03:30:28 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:30:28 --> Utf8 Class Initialized
INFO - 2026-08-19 03:30:28 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:30:28 --> URI Class Initialized
INFO - 2026-08-19 03:30:28 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:30:28 --> Router Class Initialized
INFO - 2026-08-19 03:30:28 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:30:28 --> Output Class Initialized
INFO - 2026-08-19 03:30:28 --> Security Class Initialized
DEBUG - 2026-08-19 03:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:30:28 --> CSRF cookie sent
INFO - 2026-08-19 03:30:28 --> Input Class Initialized
INFO - 2026-08-19 03:30:28 --> Language Class Initialized
INFO - 2026-08-19 03:30:28 --> Language Class Initialized
INFO - 2026-08-19 03:30:28 --> Config Class Initialized
INFO - 2026-08-19 03:30:28 --> Database Driver Class Initialized
INFO - 2026-08-19 03:30:28 --> Loader Class Initialized
INFO - 2026-08-19 03:30:28 --> Helper loaded: url_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: form_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: html_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: file_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: email_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:30:28 --> Database Driver Class Initialized
INFO - 2026-08-19 03:30:28 --> Config Class Initialized
INFO - 2026-08-19 03:30:28 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:30:28 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:30:28 --> Utf8 Class Initialized
INFO - 2026-08-19 03:30:28 --> URI Class Initialized
INFO - 2026-08-19 03:30:28 --> Config Class Initialized
INFO - 2026-08-19 03:30:28 --> Hooks Class Initialized
INFO - 2026-08-19 03:30:28 --> Router Class Initialized
DEBUG - 2026-08-19 03:30:28 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:30:28 --> Utf8 Class Initialized
INFO - 2026-08-19 03:30:28 --> URI Class Initialized
INFO - 2026-08-19 03:30:28 --> Output Class Initialized
INFO - 2026-08-19 03:30:28 --> Security Class Initialized
INFO - 2026-08-19 03:30:28 --> Router Class Initialized
INFO - 2026-08-19 03:30:28 --> Config Class Initialized
INFO - 2026-08-19 03:30:28 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:30:28 --> CSRF cookie sent
INFO - 2026-08-19 03:30:28 --> Input Class Initialized
INFO - 2026-08-19 03:30:28 --> Output Class Initialized
INFO - 2026-08-19 03:30:28 --> Language Class Initialized
DEBUG - 2026-08-19 03:30:28 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:30:28 --> Utf8 Class Initialized
INFO - 2026-08-19 03:30:28 --> URI Class Initialized
INFO - 2026-08-19 03:30:28 --> Router Class Initialized
INFO - 2026-08-19 03:30:28 --> Output Class Initialized
INFO - 2026-08-19 03:30:28 --> Language Class Initialized
INFO - 2026-08-19 03:30:28 --> Security Class Initialized
INFO - 2026-08-19 03:30:28 --> Config Class Initialized
INFO - 2026-08-19 03:30:28 --> Security Class Initialized
DEBUG - 2026-08-19 03:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:30:28 --> CSRF cookie sent
INFO - 2026-08-19 03:30:28 --> Input Class Initialized
INFO - 2026-08-19 03:30:28 --> Language Class Initialized
INFO - 2026-08-19 03:30:28 --> Loader Class Initialized
DEBUG - 2026-08-19 03:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:30:28 --> CSRF cookie sent
INFO - 2026-08-19 03:30:28 --> Input Class Initialized
INFO - 2026-08-19 03:30:28 --> Language Class Initialized
INFO - 2026-08-19 03:30:28 --> Language Class Initialized
INFO - 2026-08-19 03:30:28 --> Config Class Initialized
INFO - 2026-08-19 03:30:28 --> Helper loaded: url_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: form_helper
INFO - 2026-08-19 03:30:28 --> Language Class Initialized
INFO - 2026-08-19 03:30:28 --> Config Class Initialized
INFO - 2026-08-19 03:30:28 --> Helper loaded: html_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: file_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: email_helper
INFO - 2026-08-19 03:30:28 --> Loader Class Initialized
INFO - 2026-08-19 03:30:28 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:30:28 --> Loader Class Initialized
INFO - 2026-08-19 03:30:28 --> Helper loaded: url_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: url_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: form_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: html_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: form_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: file_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: html_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: email_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: file_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: email_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:30:28 --> Database Driver Class Initialized
INFO - 2026-08-19 03:30:28 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:30:28 --> Config Class Initialized
INFO - 2026-08-19 03:30:28 --> Hooks Class Initialized
INFO - 2026-08-19 03:30:28 --> Database Driver Class Initialized
DEBUG - 2026-08-19 03:30:28 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:30:28 --> Utf8 Class Initialized
INFO - 2026-08-19 03:30:28 --> URI Class Initialized
INFO - 2026-08-19 03:30:28 --> Database Driver Class Initialized
INFO - 2026-08-19 03:30:28 --> Router Class Initialized
INFO - 2026-08-19 03:30:28 --> Output Class Initialized
INFO - 2026-08-19 03:30:28 --> Security Class Initialized
DEBUG - 2026-08-19 03:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:30:28 --> CSRF cookie sent
INFO - 2026-08-19 03:30:28 --> Input Class Initialized
INFO - 2026-08-19 03:30:28 --> Language Class Initialized
INFO - 2026-08-19 03:30:28 --> Language Class Initialized
INFO - 2026-08-19 03:30:28 --> Config Class Initialized
INFO - 2026-08-19 03:30:28 --> Loader Class Initialized
INFO - 2026-08-19 03:30:28 --> Helper loaded: url_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: form_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: html_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: file_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: email_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:30:28 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:30:28 --> Database Driver Class Initialized
INFO - 2026-08-19 03:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:30:30 --> Upload Class Initialized
DEBUG - 2026-08-19 03:30:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:30:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:30:30 --> Encryption Class Initialized
INFO - 2026-08-19 03:30:30 --> Form Validation Class Initialized
INFO - 2026-08-19 03:30:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:30:30 --> Pagination Class Initialized
INFO - 2026-08-19 03:30:30 --> Email Class Initialized
INFO - 2026-08-19 03:30:30 --> Controller Class Initialized
ERROR - 2026-08-19 03:30:30 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:30:30 --> Upload Class Initialized
DEBUG - 2026-08-19 03:30:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:30:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:30:30 --> Encryption Class Initialized
INFO - 2026-08-19 03:30:30 --> Form Validation Class Initialized
INFO - 2026-08-19 03:30:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:30:30 --> Pagination Class Initialized
INFO - 2026-08-19 03:30:30 --> Config Class Initialized
INFO - 2026-08-19 03:30:30 --> Hooks Class Initialized
INFO - 2026-08-19 03:30:30 --> Email Class Initialized
INFO - 2026-08-19 03:30:30 --> Controller Class Initialized
DEBUG - 2026-08-19 03:30:30 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:30:30 --> Utf8 Class Initialized
INFO - 2026-08-19 03:30:30 --> URI Class Initialized
INFO - 2026-08-19 03:30:30 --> Router Class Initialized
INFO - 2026-08-19 03:30:30 --> Output Class Initialized
DEBUG - 2026-08-19 03:30:30 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:30:30 --> Security Class Initialized
INFO - 2026-08-19 03:30:30 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:30:30 --> Model "Auth_model" initialized
DEBUG - 2026-08-19 03:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:30:30 --> CSRF cookie sent
INFO - 2026-08-19 03:30:30 --> Input Class Initialized
INFO - 2026-08-19 03:30:30 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:30:30 --> Language Class Initialized
INFO - 2026-08-19 03:30:30 --> Model "Common_model" initialized
INFO - 2026-08-19 03:30:30 --> Language Class Initialized
INFO - 2026-08-19 03:30:30 --> Config Class Initialized
INFO - 2026-08-19 03:30:30 --> Model "Order_model" initialized
INFO - 2026-08-19 03:30:30 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:30:30 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:30:30 --> Model "Promocode_model" initialized
INFO - 2026-08-19 03:30:30 --> Loader Class Initialized
INFO - 2026-08-19 03:30:30 --> Helper loaded: url_helper
DEBUG - 2026-08-19 03:30:30 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:30:30 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:30:30 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:30:30 --> Helper loaded: form_helper
INFO - 2026-08-19 03:30:30 --> Helper loaded: html_helper
INFO - 2026-08-19 03:30:30 --> Helper loaded: file_helper
INFO - 2026-08-19 03:30:30 --> Helper loaded: email_helper
INFO - 2026-08-19 03:30:30 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:30:30 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:30:30 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:30:30 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:30:30 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:30:30 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:30:30 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:30:30 --> Database Driver Class Initialized
INFO - 2026-08-19 03:30:30 --> Final output sent to browser
DEBUG - 2026-08-19 03:30:30 --> Total execution time: 1.9024
INFO - 2026-08-19 03:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:30:30 --> Upload Class Initialized
DEBUG - 2026-08-19 03:30:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:30:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:30:30 --> Encryption Class Initialized
INFO - 2026-08-19 03:30:30 --> Form Validation Class Initialized
INFO - 2026-08-19 03:30:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:30:30 --> Pagination Class Initialized
INFO - 2026-08-19 03:30:30 --> Email Class Initialized
INFO - 2026-08-19 03:30:30 --> Controller Class Initialized
DEBUG - 2026-08-19 03:30:30 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:30:30 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:30:30 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:30:30 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:30:30 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:30:30 --> Config Class Initialized
INFO - 2026-08-19 03:30:30 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:30:30 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:30:30 --> Utf8 Class Initialized
INFO - 2026-08-19 03:30:30 --> URI Class Initialized
INFO - 2026-08-19 03:30:30 --> Router Class Initialized
INFO - 2026-08-19 03:30:30 --> Output Class Initialized
INFO - 2026-08-19 03:30:30 --> Security Class Initialized
DEBUG - 2026-08-19 03:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:30:30 --> CSRF cookie sent
INFO - 2026-08-19 03:30:30 --> Input Class Initialized
INFO - 2026-08-19 03:30:30 --> Language Class Initialized
INFO - 2026-08-19 03:30:30 --> Language Class Initialized
INFO - 2026-08-19 03:30:30 --> Config Class Initialized
INFO - 2026-08-19 03:30:30 --> Loader Class Initialized
INFO - 2026-08-19 03:30:30 --> Helper loaded: url_helper
INFO - 2026-08-19 03:30:30 --> Helper loaded: form_helper
INFO - 2026-08-19 03:30:30 --> Helper loaded: html_helper
INFO - 2026-08-19 03:30:30 --> Helper loaded: file_helper
INFO - 2026-08-19 03:30:30 --> Helper loaded: email_helper
INFO - 2026-08-19 03:30:30 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:30:30 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:30:30 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:30:30 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:30:30 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:30:30 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:30:30 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:30:30 --> Database Driver Class Initialized
INFO - 2026-08-19 03:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:30:31 --> Upload Class Initialized
DEBUG - 2026-08-19 03:30:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:30:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:30:31 --> Encryption Class Initialized
INFO - 2026-08-19 03:30:31 --> Form Validation Class Initialized
INFO - 2026-08-19 03:30:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:30:31 --> Pagination Class Initialized
INFO - 2026-08-19 03:30:31 --> Email Class Initialized
INFO - 2026-08-19 03:30:31 --> Controller Class Initialized
INFO - 2026-08-19 03:30:31 --> Config Class Initialized
INFO - 2026-08-19 03:30:31 --> Hooks Class Initialized
ERROR - 2026-08-19 03:30:31 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:30:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-08-19 03:30:31 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:30:31 --> Utf8 Class Initialized
INFO - 2026-08-19 03:30:31 --> URI Class Initialized
INFO - 2026-08-19 03:30:31 --> Upload Class Initialized
DEBUG - 2026-08-19 03:30:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:30:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:30:31 --> Router Class Initialized
INFO - 2026-08-19 03:30:31 --> Encryption Class Initialized
INFO - 2026-08-19 03:30:31 --> Output Class Initialized
INFO - 2026-08-19 03:30:31 --> Form Validation Class Initialized
INFO - 2026-08-19 03:30:31 --> Security Class Initialized
INFO - 2026-08-19 03:30:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:30:31 --> Pagination Class Initialized
DEBUG - 2026-08-19 03:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:30:31 --> CSRF cookie sent
INFO - 2026-08-19 03:30:31 --> Input Class Initialized
INFO - 2026-08-19 03:30:31 --> Language Class Initialized
INFO - 2026-08-19 03:30:31 --> Language Class Initialized
INFO - 2026-08-19 03:30:31 --> Config Class Initialized
INFO - 2026-08-19 03:30:31 --> Email Class Initialized
INFO - 2026-08-19 03:30:31 --> Controller Class Initialized
INFO - 2026-08-19 03:30:31 --> Loader Class Initialized
ERROR - 2026-08-19 03:30:31 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:30:31 --> Helper loaded: url_helper
INFO - 2026-08-19 03:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:30:31 --> Helper loaded: form_helper
INFO - 2026-08-19 03:30:31 --> Helper loaded: html_helper
INFO - 2026-08-19 03:30:31 --> Upload Class Initialized
INFO - 2026-08-19 03:30:31 --> Helper loaded: file_helper
INFO - 2026-08-19 03:30:31 --> Helper loaded: email_helper
DEBUG - 2026-08-19 03:30:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:30:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:30:31 --> Encryption Class Initialized
INFO - 2026-08-19 03:30:31 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:30:31 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:30:31 --> Form Validation Class Initialized
INFO - 2026-08-19 03:30:31 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:30:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:30:31 --> Pagination Class Initialized
INFO - 2026-08-19 03:30:31 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:30:31 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:30:31 --> Email Class Initialized
INFO - 2026-08-19 03:30:31 --> Controller Class Initialized
ERROR - 2026-08-19 03:30:31 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:30:31 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:30:31 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:30:31 --> Database Driver Class Initialized
INFO - 2026-08-19 03:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:30:32 --> Upload Class Initialized
DEBUG - 2026-08-19 03:30:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:30:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:30:32 --> Encryption Class Initialized
INFO - 2026-08-19 03:30:32 --> Form Validation Class Initialized
INFO - 2026-08-19 03:30:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:30:32 --> Pagination Class Initialized
INFO - 2026-08-19 03:30:32 --> Email Class Initialized
INFO - 2026-08-19 03:30:32 --> Controller Class Initialized
ERROR - 2026-08-19 03:30:32 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:30:32 --> Upload Class Initialized
DEBUG - 2026-08-19 03:30:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:30:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:30:32 --> Encryption Class Initialized
INFO - 2026-08-19 03:30:32 --> Form Validation Class Initialized
INFO - 2026-08-19 03:30:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:30:32 --> Pagination Class Initialized
INFO - 2026-08-19 03:30:32 --> Email Class Initialized
INFO - 2026-08-19 03:30:32 --> Controller Class Initialized
ERROR - 2026-08-19 03:30:32 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:30:33 --> Upload Class Initialized
DEBUG - 2026-08-19 03:30:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:30:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:30:33 --> Encryption Class Initialized
INFO - 2026-08-19 03:30:33 --> Form Validation Class Initialized
INFO - 2026-08-19 03:30:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:30:33 --> Pagination Class Initialized
INFO - 2026-08-19 03:30:33 --> Email Class Initialized
INFO - 2026-08-19 03:30:33 --> Controller Class Initialized
ERROR - 2026-08-19 03:30:33 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:30:36 --> Config Class Initialized
INFO - 2026-08-19 03:30:36 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:30:36 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:30:36 --> Utf8 Class Initialized
INFO - 2026-08-19 03:30:36 --> URI Class Initialized
INFO - 2026-08-19 03:30:36 --> Router Class Initialized
INFO - 2026-08-19 03:30:36 --> Output Class Initialized
INFO - 2026-08-19 03:30:36 --> Security Class Initialized
DEBUG - 2026-08-19 03:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:30:36 --> CSRF cookie sent
INFO - 2026-08-19 03:30:36 --> Input Class Initialized
INFO - 2026-08-19 03:30:36 --> Language Class Initialized
INFO - 2026-08-19 03:30:36 --> Language Class Initialized
INFO - 2026-08-19 03:30:36 --> Config Class Initialized
INFO - 2026-08-19 03:30:36 --> Loader Class Initialized
INFO - 2026-08-19 03:30:36 --> Helper loaded: url_helper
INFO - 2026-08-19 03:30:36 --> Helper loaded: form_helper
INFO - 2026-08-19 03:30:36 --> Helper loaded: html_helper
INFO - 2026-08-19 03:30:36 --> Helper loaded: file_helper
INFO - 2026-08-19 03:30:36 --> Helper loaded: email_helper
INFO - 2026-08-19 03:30:36 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:30:36 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:30:36 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:30:36 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:30:36 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:30:36 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:30:36 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:30:36 --> Database Driver Class Initialized
INFO - 2026-08-19 03:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:30:38 --> Upload Class Initialized
DEBUG - 2026-08-19 03:30:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:30:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:30:38 --> Encryption Class Initialized
INFO - 2026-08-19 03:30:38 --> Form Validation Class Initialized
INFO - 2026-08-19 03:30:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:30:38 --> Pagination Class Initialized
INFO - 2026-08-19 03:30:38 --> Email Class Initialized
INFO - 2026-08-19 03:30:38 --> Controller Class Initialized
DEBUG - 2026-08-19 03:30:38 --> Invoicing MX_Controller Initialized
INFO - 2026-08-19 03:30:38 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:30:38 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:30:38 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:30:38 --> Model "Billing_model" initialized
INFO - 2026-08-19 03:30:38 --> Model "Common_model" initialized
INFO - 2026-08-19 03:30:38 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-19 03:30:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:30:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-08-19 03:30:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:30:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:30:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/invoicing/views/invoicing_invoices.php
INFO - 2026-08-19 03:30:40 --> Final output sent to browser
DEBUG - 2026-08-19 03:30:40 --> Total execution time: 3.7144
INFO - 2026-08-19 03:30:40 --> Config Class Initialized
INFO - 2026-08-19 03:30:40 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:30:40 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:30:40 --> Utf8 Class Initialized
INFO - 2026-08-19 03:30:40 --> URI Class Initialized
INFO - 2026-08-19 03:30:40 --> Router Class Initialized
INFO - 2026-08-19 03:30:40 --> Output Class Initialized
INFO - 2026-08-19 03:30:40 --> Security Class Initialized
DEBUG - 2026-08-19 03:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:30:40 --> CSRF cookie sent
INFO - 2026-08-19 03:30:40 --> Input Class Initialized
INFO - 2026-08-19 03:30:40 --> Language Class Initialized
INFO - 2026-08-19 03:30:40 --> Language Class Initialized
INFO - 2026-08-19 03:30:40 --> Config Class Initialized
INFO - 2026-08-19 03:30:40 --> Loader Class Initialized
INFO - 2026-08-19 03:30:40 --> Helper loaded: url_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: form_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: html_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: file_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: email_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:30:40 --> Database Driver Class Initialized
INFO - 2026-08-19 03:30:40 --> Config Class Initialized
INFO - 2026-08-19 03:30:40 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:30:40 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:30:40 --> Utf8 Class Initialized
INFO - 2026-08-19 03:30:40 --> URI Class Initialized
INFO - 2026-08-19 03:30:40 --> Router Class Initialized
INFO - 2026-08-19 03:30:40 --> Output Class Initialized
INFO - 2026-08-19 03:30:40 --> Security Class Initialized
DEBUG - 2026-08-19 03:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:30:40 --> CSRF cookie sent
INFO - 2026-08-19 03:30:40 --> Input Class Initialized
INFO - 2026-08-19 03:30:40 --> Language Class Initialized
INFO - 2026-08-19 03:30:40 --> Language Class Initialized
INFO - 2026-08-19 03:30:40 --> Config Class Initialized
INFO - 2026-08-19 03:30:40 --> Loader Class Initialized
INFO - 2026-08-19 03:30:40 --> Helper loaded: url_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: form_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: html_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: file_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: email_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:30:40 --> Database Driver Class Initialized
INFO - 2026-08-19 03:30:40 --> Config Class Initialized
INFO - 2026-08-19 03:30:40 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:30:40 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:30:40 --> Utf8 Class Initialized
INFO - 2026-08-19 03:30:40 --> URI Class Initialized
INFO - 2026-08-19 03:30:40 --> Router Class Initialized
INFO - 2026-08-19 03:30:40 --> Output Class Initialized
INFO - 2026-08-19 03:30:40 --> Security Class Initialized
DEBUG - 2026-08-19 03:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:30:40 --> CSRF cookie sent
INFO - 2026-08-19 03:30:40 --> Input Class Initialized
INFO - 2026-08-19 03:30:40 --> Language Class Initialized
INFO - 2026-08-19 03:30:40 --> Language Class Initialized
INFO - 2026-08-19 03:30:40 --> Config Class Initialized
INFO - 2026-08-19 03:30:40 --> Config Class Initialized
INFO - 2026-08-19 03:30:40 --> Hooks Class Initialized
INFO - 2026-08-19 03:30:40 --> Loader Class Initialized
DEBUG - 2026-08-19 03:30:40 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:30:40 --> Utf8 Class Initialized
INFO - 2026-08-19 03:30:40 --> Helper loaded: url_helper
INFO - 2026-08-19 03:30:40 --> URI Class Initialized
INFO - 2026-08-19 03:30:40 --> Helper loaded: form_helper
INFO - 2026-08-19 03:30:40 --> Router Class Initialized
INFO - 2026-08-19 03:30:40 --> Helper loaded: html_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: file_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: email_helper
INFO - 2026-08-19 03:30:40 --> Output Class Initialized
INFO - 2026-08-19 03:30:40 --> Security Class Initialized
INFO - 2026-08-19 03:30:40 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: ssp_helper
DEBUG - 2026-08-19 03:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:30:40 --> CSRF cookie sent
INFO - 2026-08-19 03:30:40 --> Input Class Initialized
INFO - 2026-08-19 03:30:40 --> Language Class Initialized
INFO - 2026-08-19 03:30:40 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:30:40 --> Language Class Initialized
INFO - 2026-08-19 03:30:40 --> Config Class Initialized
INFO - 2026-08-19 03:30:40 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:30:40 --> Loader Class Initialized
INFO - 2026-08-19 03:30:40 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: url_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: form_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: html_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: file_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: email_helper
INFO - 2026-08-19 03:30:40 --> Config Class Initialized
INFO - 2026-08-19 03:30:40 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:30:40 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:30:40 --> Utf8 Class Initialized
INFO - 2026-08-19 03:30:40 --> URI Class Initialized
INFO - 2026-08-19 03:30:40 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:30:40 --> Config Class Initialized
INFO - 2026-08-19 03:30:40 --> Hooks Class Initialized
INFO - 2026-08-19 03:30:40 --> Router Class Initialized
DEBUG - 2026-08-19 03:30:40 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:30:40 --> Utf8 Class Initialized
INFO - 2026-08-19 03:30:40 --> Database Driver Class Initialized
INFO - 2026-08-19 03:30:40 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:30:40 --> Output Class Initialized
INFO - 2026-08-19 03:30:40 --> URI Class Initialized
INFO - 2026-08-19 03:30:40 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:30:40 --> Security Class Initialized
INFO - 2026-08-19 03:30:40 --> Helper loaded: directadmin_helper
DEBUG - 2026-08-19 03:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:30:40 --> CSRF cookie sent
INFO - 2026-08-19 03:30:40 --> Input Class Initialized
INFO - 2026-08-19 03:30:40 --> Language Class Initialized
INFO - 2026-08-19 03:30:40 --> Router Class Initialized
INFO - 2026-08-19 03:30:40 --> Language Class Initialized
INFO - 2026-08-19 03:30:40 --> Config Class Initialized
INFO - 2026-08-19 03:30:40 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:30:40 --> Output Class Initialized
INFO - 2026-08-19 03:30:40 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:30:40 --> Security Class Initialized
INFO - 2026-08-19 03:30:40 --> Loader Class Initialized
DEBUG - 2026-08-19 03:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:30:40 --> Helper loaded: url_helper
INFO - 2026-08-19 03:30:40 --> CSRF cookie sent
INFO - 2026-08-19 03:30:40 --> Input Class Initialized
INFO - 2026-08-19 03:30:40 --> Language Class Initialized
INFO - 2026-08-19 03:30:40 --> Helper loaded: form_helper
INFO - 2026-08-19 03:30:40 --> Language Class Initialized
INFO - 2026-08-19 03:30:40 --> Helper loaded: html_helper
INFO - 2026-08-19 03:30:40 --> Config Class Initialized
INFO - 2026-08-19 03:30:40 --> Helper loaded: file_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: email_helper
INFO - 2026-08-19 03:30:40 --> Database Driver Class Initialized
INFO - 2026-08-19 03:30:40 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:30:40 --> Loader Class Initialized
INFO - 2026-08-19 03:30:40 --> Helper loaded: url_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: form_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: html_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: file_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: email_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:30:40 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:30:40 --> Database Driver Class Initialized
INFO - 2026-08-19 03:30:40 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:30:40 --> Database Driver Class Initialized
INFO - 2026-08-19 03:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:30:42 --> Upload Class Initialized
DEBUG - 2026-08-19 03:30:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:30:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:30:42 --> Encryption Class Initialized
INFO - 2026-08-19 03:30:42 --> Form Validation Class Initialized
INFO - 2026-08-19 03:30:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:30:42 --> Pagination Class Initialized
INFO - 2026-08-19 03:30:42 --> Email Class Initialized
INFO - 2026-08-19 03:30:42 --> Controller Class Initialized
ERROR - 2026-08-19 03:30:42 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:30:42 --> Upload Class Initialized
DEBUG - 2026-08-19 03:30:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:30:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:30:42 --> Encryption Class Initialized
INFO - 2026-08-19 03:30:42 --> Form Validation Class Initialized
INFO - 2026-08-19 03:30:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:30:42 --> Pagination Class Initialized
INFO - 2026-08-19 03:30:42 --> Email Class Initialized
INFO - 2026-08-19 03:30:42 --> Controller Class Initialized
INFO - 2026-08-19 03:30:42 --> Config Class Initialized
INFO - 2026-08-19 03:30:42 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:30:42 --> Cart MX_Controller Initialized
DEBUG - 2026-08-19 03:30:42 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:30:42 --> Utf8 Class Initialized
INFO - 2026-08-19 03:30:42 --> URI Class Initialized
INFO - 2026-08-19 03:30:42 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:30:42 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:30:42 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:30:42 --> Router Class Initialized
INFO - 2026-08-19 03:30:42 --> Model "Common_model" initialized
INFO - 2026-08-19 03:30:42 --> Output Class Initialized
INFO - 2026-08-19 03:30:42 --> Model "Order_model" initialized
INFO - 2026-08-19 03:30:42 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:30:42 --> Security Class Initialized
INFO - 2026-08-19 03:30:42 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:30:42 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:30:42 --> CSRF cookie sent
INFO - 2026-08-19 03:30:42 --> Input Class Initialized
INFO - 2026-08-19 03:30:42 --> Language Class Initialized
INFO - 2026-08-19 03:30:42 --> Language Class Initialized
DEBUG - 2026-08-19 03:30:42 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:30:42 --> Config Class Initialized
INFO - 2026-08-19 03:30:42 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:30:42 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:30:42 --> Loader Class Initialized
INFO - 2026-08-19 03:30:42 --> Helper loaded: url_helper
INFO - 2026-08-19 03:30:42 --> Helper loaded: form_helper
INFO - 2026-08-19 03:30:42 --> Helper loaded: html_helper
INFO - 2026-08-19 03:30:42 --> Helper loaded: file_helper
INFO - 2026-08-19 03:30:42 --> Helper loaded: email_helper
INFO - 2026-08-19 03:30:42 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:30:42 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:30:42 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:30:42 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:30:42 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:30:42 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:30:42 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:30:42 --> Database Driver Class Initialized
INFO - 2026-08-19 03:30:42 --> Final output sent to browser
DEBUG - 2026-08-19 03:30:42 --> Total execution time: 1.9887
INFO - 2026-08-19 03:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:30:42 --> Upload Class Initialized
DEBUG - 2026-08-19 03:30:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:30:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:30:42 --> Encryption Class Initialized
INFO - 2026-08-19 03:30:42 --> Form Validation Class Initialized
INFO - 2026-08-19 03:30:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:30:42 --> Pagination Class Initialized
INFO - 2026-08-19 03:30:42 --> Config Class Initialized
INFO - 2026-08-19 03:30:42 --> Hooks Class Initialized
INFO - 2026-08-19 03:30:42 --> Email Class Initialized
INFO - 2026-08-19 03:30:42 --> Controller Class Initialized
DEBUG - 2026-08-19 03:30:42 --> Notifications MX_Controller Initialized
DEBUG - 2026-08-19 03:30:42 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:30:42 --> Utf8 Class Initialized
INFO - 2026-08-19 03:30:42 --> URI Class Initialized
INFO - 2026-08-19 03:30:42 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:30:42 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:30:42 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:30:42 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:30:42 --> Router Class Initialized
INFO - 2026-08-19 03:30:42 --> Output Class Initialized
INFO - 2026-08-19 03:30:42 --> Security Class Initialized
DEBUG - 2026-08-19 03:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:30:42 --> CSRF cookie sent
INFO - 2026-08-19 03:30:42 --> Input Class Initialized
INFO - 2026-08-19 03:30:42 --> Language Class Initialized
INFO - 2026-08-19 03:30:42 --> Language Class Initialized
INFO - 2026-08-19 03:30:42 --> Config Class Initialized
INFO - 2026-08-19 03:30:42 --> Loader Class Initialized
INFO - 2026-08-19 03:30:42 --> Helper loaded: url_helper
INFO - 2026-08-19 03:30:42 --> Helper loaded: form_helper
INFO - 2026-08-19 03:30:42 --> Helper loaded: html_helper
INFO - 2026-08-19 03:30:42 --> Helper loaded: file_helper
INFO - 2026-08-19 03:30:42 --> Helper loaded: email_helper
INFO - 2026-08-19 03:30:42 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:30:42 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:30:42 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:30:42 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:30:42 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:30:42 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:30:42 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:30:42 --> Database Driver Class Initialized
INFO - 2026-08-19 03:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:30:43 --> Upload Class Initialized
DEBUG - 2026-08-19 03:30:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:30:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:30:43 --> Encryption Class Initialized
INFO - 2026-08-19 03:30:43 --> Form Validation Class Initialized
INFO - 2026-08-19 03:30:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:30:43 --> Pagination Class Initialized
INFO - 2026-08-19 03:30:43 --> Config Class Initialized
INFO - 2026-08-19 03:30:43 --> Hooks Class Initialized
INFO - 2026-08-19 03:30:43 --> Email Class Initialized
DEBUG - 2026-08-19 03:30:43 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:30:43 --> Utf8 Class Initialized
INFO - 2026-08-19 03:30:43 --> Controller Class Initialized
ERROR - 2026-08-19 03:30:43 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:30:43 --> URI Class Initialized
INFO - 2026-08-19 03:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:30:43 --> Upload Class Initialized
INFO - 2026-08-19 03:30:43 --> Router Class Initialized
DEBUG - 2026-08-19 03:30:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:30:43 --> Output Class Initialized
INFO - 2026-08-19 03:30:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:30:43 --> Encryption Class Initialized
INFO - 2026-08-19 03:30:43 --> Security Class Initialized
INFO - 2026-08-19 03:30:43 --> Form Validation Class Initialized
DEBUG - 2026-08-19 03:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:30:43 --> CSRF cookie sent
INFO - 2026-08-19 03:30:43 --> Input Class Initialized
INFO - 2026-08-19 03:30:43 --> Language Class Initialized
INFO - 2026-08-19 03:30:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:30:43 --> Pagination Class Initialized
INFO - 2026-08-19 03:30:43 --> Language Class Initialized
INFO - 2026-08-19 03:30:43 --> Config Class Initialized
INFO - 2026-08-19 03:30:43 --> Loader Class Initialized
INFO - 2026-08-19 03:30:43 --> Email Class Initialized
INFO - 2026-08-19 03:30:43 --> Helper loaded: url_helper
INFO - 2026-08-19 03:30:43 --> Controller Class Initialized
ERROR - 2026-08-19 03:30:43 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:30:43 --> Helper loaded: form_helper
INFO - 2026-08-19 03:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:30:43 --> Helper loaded: html_helper
INFO - 2026-08-19 03:30:43 --> Helper loaded: file_helper
INFO - 2026-08-19 03:30:43 --> Helper loaded: email_helper
INFO - 2026-08-19 03:30:43 --> Upload Class Initialized
INFO - 2026-08-19 03:30:43 --> Helper loaded: whmaz_helper
DEBUG - 2026-08-19 03:30:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:30:43 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:30:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:30:43 --> Encryption Class Initialized
INFO - 2026-08-19 03:30:43 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:30:43 --> Form Validation Class Initialized
INFO - 2026-08-19 03:30:43 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:30:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:30:43 --> Pagination Class Initialized
INFO - 2026-08-19 03:30:43 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:30:43 --> Email Class Initialized
INFO - 2026-08-19 03:30:43 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:30:43 --> Controller Class Initialized
INFO - 2026-08-19 03:30:43 --> Helper loaded: entitlement_helper
ERROR - 2026-08-19 03:30:43 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:30:43 --> Database Driver Class Initialized
INFO - 2026-08-19 03:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:30:44 --> Upload Class Initialized
DEBUG - 2026-08-19 03:30:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:30:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:30:44 --> Encryption Class Initialized
INFO - 2026-08-19 03:30:44 --> Form Validation Class Initialized
INFO - 2026-08-19 03:30:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:30:44 --> Pagination Class Initialized
INFO - 2026-08-19 03:30:44 --> Email Class Initialized
INFO - 2026-08-19 03:30:44 --> Controller Class Initialized
ERROR - 2026-08-19 03:30:44 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:30:45 --> Upload Class Initialized
DEBUG - 2026-08-19 03:30:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:30:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:30:45 --> Encryption Class Initialized
INFO - 2026-08-19 03:30:45 --> Form Validation Class Initialized
INFO - 2026-08-19 03:30:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:30:45 --> Pagination Class Initialized
INFO - 2026-08-19 03:30:45 --> Email Class Initialized
INFO - 2026-08-19 03:30:45 --> Controller Class Initialized
ERROR - 2026-08-19 03:30:45 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:30:45 --> Upload Class Initialized
DEBUG - 2026-08-19 03:30:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:30:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:30:45 --> Encryption Class Initialized
INFO - 2026-08-19 03:30:45 --> Form Validation Class Initialized
INFO - 2026-08-19 03:30:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:30:45 --> Pagination Class Initialized
INFO - 2026-08-19 03:30:45 --> Email Class Initialized
INFO - 2026-08-19 03:30:45 --> Controller Class Initialized
ERROR - 2026-08-19 03:30:45 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:30:47 --> Config Class Initialized
INFO - 2026-08-19 03:30:47 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:30:47 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:30:47 --> Utf8 Class Initialized
INFO - 2026-08-19 03:30:47 --> URI Class Initialized
INFO - 2026-08-19 03:30:47 --> Router Class Initialized
INFO - 2026-08-19 03:30:47 --> Output Class Initialized
INFO - 2026-08-19 03:30:47 --> Security Class Initialized
DEBUG - 2026-08-19 03:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:30:47 --> CSRF cookie sent
INFO - 2026-08-19 03:30:47 --> Input Class Initialized
INFO - 2026-08-19 03:30:47 --> Language Class Initialized
INFO - 2026-08-19 03:30:47 --> Language Class Initialized
INFO - 2026-08-19 03:30:47 --> Config Class Initialized
INFO - 2026-08-19 03:30:47 --> Loader Class Initialized
INFO - 2026-08-19 03:30:47 --> Helper loaded: url_helper
INFO - 2026-08-19 03:30:47 --> Helper loaded: form_helper
INFO - 2026-08-19 03:30:47 --> Helper loaded: html_helper
INFO - 2026-08-19 03:30:47 --> Helper loaded: file_helper
INFO - 2026-08-19 03:30:47 --> Helper loaded: email_helper
INFO - 2026-08-19 03:30:47 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:30:47 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:30:47 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:30:47 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:30:47 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:30:47 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:30:47 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:30:47 --> Database Driver Class Initialized
INFO - 2026-08-19 03:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:30:49 --> Upload Class Initialized
DEBUG - 2026-08-19 03:30:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:30:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:30:49 --> Encryption Class Initialized
INFO - 2026-08-19 03:30:49 --> Form Validation Class Initialized
INFO - 2026-08-19 03:30:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:30:49 --> Pagination Class Initialized
INFO - 2026-08-19 03:30:49 --> Email Class Initialized
INFO - 2026-08-19 03:30:49 --> Controller Class Initialized
DEBUG - 2026-08-19 03:30:49 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:30:49 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:30:49 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:30:49 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:30:49 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:30:50 --> Config Class Initialized
INFO - 2026-08-19 03:30:50 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:30:50 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:30:50 --> Utf8 Class Initialized
INFO - 2026-08-19 03:30:50 --> URI Class Initialized
INFO - 2026-08-19 03:30:50 --> Router Class Initialized
INFO - 2026-08-19 03:30:50 --> Output Class Initialized
INFO - 2026-08-19 03:30:50 --> Security Class Initialized
DEBUG - 2026-08-19 03:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:30:50 --> CSRF cookie sent
INFO - 2026-08-19 03:30:50 --> Input Class Initialized
INFO - 2026-08-19 03:30:50 --> Language Class Initialized
INFO - 2026-08-19 03:30:50 --> Language Class Initialized
INFO - 2026-08-19 03:30:50 --> Config Class Initialized
INFO - 2026-08-19 03:30:50 --> Loader Class Initialized
INFO - 2026-08-19 03:30:50 --> Helper loaded: url_helper
INFO - 2026-08-19 03:30:50 --> Helper loaded: form_helper
INFO - 2026-08-19 03:30:50 --> Helper loaded: html_helper
INFO - 2026-08-19 03:30:50 --> Helper loaded: file_helper
INFO - 2026-08-19 03:30:50 --> Helper loaded: email_helper
INFO - 2026-08-19 03:30:50 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:30:50 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:30:50 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:30:50 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:30:50 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:30:50 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:30:50 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:30:50 --> Database Driver Class Initialized
INFO - 2026-08-19 03:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:30:51 --> Upload Class Initialized
DEBUG - 2026-08-19 03:30:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:30:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:30:51 --> Encryption Class Initialized
INFO - 2026-08-19 03:30:51 --> Form Validation Class Initialized
INFO - 2026-08-19 03:30:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:30:51 --> Pagination Class Initialized
INFO - 2026-08-19 03:30:51 --> Email Class Initialized
INFO - 2026-08-19 03:30:51 --> Controller Class Initialized
DEBUG - 2026-08-19 03:30:51 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:30:51 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:30:51 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:30:51 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:30:51 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:30:54 --> Config Class Initialized
INFO - 2026-08-19 03:30:54 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:30:54 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:30:54 --> Utf8 Class Initialized
INFO - 2026-08-19 03:30:54 --> URI Class Initialized
INFO - 2026-08-19 03:30:54 --> Router Class Initialized
INFO - 2026-08-19 03:30:54 --> Output Class Initialized
INFO - 2026-08-19 03:30:54 --> Security Class Initialized
DEBUG - 2026-08-19 03:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:30:54 --> CSRF cookie sent
INFO - 2026-08-19 03:30:54 --> CSRF token verified
INFO - 2026-08-19 03:30:54 --> Input Class Initialized
INFO - 2026-08-19 03:30:54 --> Language Class Initialized
INFO - 2026-08-19 03:30:54 --> Language Class Initialized
INFO - 2026-08-19 03:30:54 --> Config Class Initialized
INFO - 2026-08-19 03:30:54 --> Loader Class Initialized
INFO - 2026-08-19 03:30:54 --> Helper loaded: url_helper
INFO - 2026-08-19 03:30:54 --> Helper loaded: form_helper
INFO - 2026-08-19 03:30:54 --> Helper loaded: html_helper
INFO - 2026-08-19 03:30:54 --> Helper loaded: file_helper
INFO - 2026-08-19 03:30:54 --> Helper loaded: email_helper
INFO - 2026-08-19 03:30:54 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:30:54 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:30:54 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:30:54 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:30:54 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:30:54 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:30:54 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:30:54 --> Database Driver Class Initialized
INFO - 2026-08-19 03:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:30:56 --> Upload Class Initialized
DEBUG - 2026-08-19 03:30:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:30:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:30:56 --> Encryption Class Initialized
INFO - 2026-08-19 03:30:56 --> Form Validation Class Initialized
INFO - 2026-08-19 03:30:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:30:56 --> Pagination Class Initialized
INFO - 2026-08-19 03:30:56 --> Email Class Initialized
INFO - 2026-08-19 03:30:56 --> Controller Class Initialized
DEBUG - 2026-08-19 03:30:56 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:30:56 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:30:56 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:30:56 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:30:56 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:30:56 --> Config Class Initialized
INFO - 2026-08-19 03:30:56 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:30:56 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:30:56 --> Utf8 Class Initialized
INFO - 2026-08-19 03:30:56 --> URI Class Initialized
INFO - 2026-08-19 03:30:56 --> Router Class Initialized
INFO - 2026-08-19 03:30:56 --> Output Class Initialized
INFO - 2026-08-19 03:30:56 --> Security Class Initialized
DEBUG - 2026-08-19 03:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:30:56 --> CSRF cookie sent
INFO - 2026-08-19 03:30:56 --> CSRF token verified
INFO - 2026-08-19 03:30:56 --> Input Class Initialized
INFO - 2026-08-19 03:30:56 --> Language Class Initialized
INFO - 2026-08-19 03:30:56 --> Language Class Initialized
INFO - 2026-08-19 03:30:56 --> Config Class Initialized
INFO - 2026-08-19 03:30:56 --> Loader Class Initialized
INFO - 2026-08-19 03:30:56 --> Helper loaded: url_helper
INFO - 2026-08-19 03:30:56 --> Helper loaded: form_helper
INFO - 2026-08-19 03:30:56 --> Helper loaded: html_helper
INFO - 2026-08-19 03:30:56 --> Helper loaded: file_helper
INFO - 2026-08-19 03:30:56 --> Helper loaded: email_helper
INFO - 2026-08-19 03:30:56 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:30:56 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:30:56 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:30:56 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:30:56 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:30:56 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:30:56 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:30:56 --> Database Driver Class Initialized
INFO - 2026-08-19 03:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:30:58 --> Upload Class Initialized
DEBUG - 2026-08-19 03:30:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:30:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:30:58 --> Encryption Class Initialized
INFO - 2026-08-19 03:30:58 --> Form Validation Class Initialized
INFO - 2026-08-19 03:30:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:30:58 --> Pagination Class Initialized
INFO - 2026-08-19 03:30:58 --> Email Class Initialized
INFO - 2026-08-19 03:30:58 --> Controller Class Initialized
DEBUG - 2026-08-19 03:30:58 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:30:58 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:30:58 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:30:58 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:30:58 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:31:02 --> Config Class Initialized
INFO - 2026-08-19 03:31:02 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:31:02 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:31:02 --> Utf8 Class Initialized
INFO - 2026-08-19 03:31:02 --> URI Class Initialized
INFO - 2026-08-19 03:31:02 --> Router Class Initialized
INFO - 2026-08-19 03:31:02 --> Output Class Initialized
INFO - 2026-08-19 03:31:02 --> Security Class Initialized
DEBUG - 2026-08-19 03:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:31:02 --> CSRF cookie sent
INFO - 2026-08-19 03:31:02 --> Input Class Initialized
INFO - 2026-08-19 03:31:02 --> Language Class Initialized
INFO - 2026-08-19 03:31:02 --> Language Class Initialized
INFO - 2026-08-19 03:31:02 --> Config Class Initialized
INFO - 2026-08-19 03:31:02 --> Loader Class Initialized
INFO - 2026-08-19 03:31:02 --> Helper loaded: url_helper
INFO - 2026-08-19 03:31:02 --> Helper loaded: form_helper
INFO - 2026-08-19 03:31:02 --> Helper loaded: html_helper
INFO - 2026-08-19 03:31:02 --> Helper loaded: file_helper
INFO - 2026-08-19 03:31:02 --> Helper loaded: email_helper
INFO - 2026-08-19 03:31:02 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:31:02 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:31:02 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:31:02 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:31:02 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:31:02 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:31:02 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:31:02 --> Database Driver Class Initialized
INFO - 2026-08-19 03:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:31:04 --> Upload Class Initialized
DEBUG - 2026-08-19 03:31:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:31:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:31:04 --> Encryption Class Initialized
INFO - 2026-08-19 03:31:04 --> Form Validation Class Initialized
INFO - 2026-08-19 03:31:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:31:04 --> Pagination Class Initialized
INFO - 2026-08-19 03:31:04 --> Email Class Initialized
INFO - 2026-08-19 03:31:04 --> Controller Class Initialized
DEBUG - 2026-08-19 03:31:04 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:31:04 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:31:04 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:31:04 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:31:04 --> Model "Common_model" initialized
INFO - 2026-08-19 03:31:04 --> Model "Order_model" initialized
INFO - 2026-08-19 03:31:04 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:31:04 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:31:04 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:31:04 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:31:04 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:31:04 --> Model "Orderlicense_model" initialized
DEBUG - 2026-08-19 03:31:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:31:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-08-19 03:31:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-08-19 03:31:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:31:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:31:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/view_card.php
INFO - 2026-08-19 03:31:07 --> Final output sent to browser
DEBUG - 2026-08-19 03:31:07 --> Total execution time: 5.3254
INFO - 2026-08-19 03:31:07 --> Config Class Initialized
INFO - 2026-08-19 03:31:07 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:31:07 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:31:07 --> Utf8 Class Initialized
INFO - 2026-08-19 03:31:07 --> URI Class Initialized
INFO - 2026-08-19 03:31:07 --> Router Class Initialized
INFO - 2026-08-19 03:31:07 --> Output Class Initialized
INFO - 2026-08-19 03:31:07 --> Security Class Initialized
DEBUG - 2026-08-19 03:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:31:07 --> CSRF cookie sent
INFO - 2026-08-19 03:31:07 --> Input Class Initialized
INFO - 2026-08-19 03:31:07 --> Language Class Initialized
INFO - 2026-08-19 03:31:07 --> Language Class Initialized
INFO - 2026-08-19 03:31:07 --> Config Class Initialized
INFO - 2026-08-19 03:31:07 --> Loader Class Initialized
INFO - 2026-08-19 03:31:07 --> Helper loaded: url_helper
INFO - 2026-08-19 03:31:07 --> Helper loaded: form_helper
INFO - 2026-08-19 03:31:07 --> Helper loaded: html_helper
INFO - 2026-08-19 03:31:07 --> Helper loaded: file_helper
INFO - 2026-08-19 03:31:07 --> Helper loaded: email_helper
INFO - 2026-08-19 03:31:07 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:31:07 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:31:07 --> Config Class Initialized
INFO - 2026-08-19 03:31:07 --> Hooks Class Initialized
INFO - 2026-08-19 03:31:07 --> Helper loaded: cpanel_helper
DEBUG - 2026-08-19 03:31:07 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:31:07 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:31:07 --> Utf8 Class Initialized
INFO - 2026-08-19 03:31:07 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:31:07 --> URI Class Initialized
INFO - 2026-08-19 03:31:07 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:31:07 --> Router Class Initialized
INFO - 2026-08-19 03:31:07 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:31:07 --> Output Class Initialized
INFO - 2026-08-19 03:31:07 --> Security Class Initialized
INFO - 2026-08-19 03:31:07 --> Config Class Initialized
INFO - 2026-08-19 03:31:07 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:31:07 --> CSRF cookie sent
INFO - 2026-08-19 03:31:07 --> Input Class Initialized
INFO - 2026-08-19 03:31:07 --> Language Class Initialized
INFO - 2026-08-19 03:31:07 --> Language Class Initialized
INFO - 2026-08-19 03:31:07 --> Config Class Initialized
INFO - 2026-08-19 03:31:07 --> Database Driver Class Initialized
DEBUG - 2026-08-19 03:31:07 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:31:07 --> Utf8 Class Initialized
INFO - 2026-08-19 03:31:07 --> URI Class Initialized
INFO - 2026-08-19 03:31:07 --> Loader Class Initialized
INFO - 2026-08-19 03:31:07 --> Router Class Initialized
INFO - 2026-08-19 03:31:07 --> Helper loaded: url_helper
INFO - 2026-08-19 03:31:07 --> Helper loaded: form_helper
INFO - 2026-08-19 03:31:07 --> Helper loaded: html_helper
INFO - 2026-08-19 03:31:07 --> Config Class Initialized
INFO - 2026-08-19 03:31:07 --> Hooks Class Initialized
INFO - 2026-08-19 03:31:07 --> Config Class Initialized
INFO - 2026-08-19 03:31:07 --> Hooks Class Initialized
INFO - 2026-08-19 03:31:07 --> Helper loaded: file_helper
INFO - 2026-08-19 03:31:07 --> Helper loaded: email_helper
DEBUG - 2026-08-19 03:31:07 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:31:07 --> Utf8 Class Initialized
DEBUG - 2026-08-19 03:31:07 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:31:07 --> Utf8 Class Initialized
INFO - 2026-08-19 03:31:07 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:31:07 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:31:07 --> URI Class Initialized
INFO - 2026-08-19 03:31:07 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:31:07 --> Router Class Initialized
INFO - 2026-08-19 03:31:07 --> URI Class Initialized
INFO - 2026-08-19 03:31:07 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:31:07 --> Output Class Initialized
INFO - 2026-08-19 03:31:07 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:31:07 --> Security Class Initialized
DEBUG - 2026-08-19 03:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:31:07 --> CSRF cookie sent
INFO - 2026-08-19 03:31:07 --> Input Class Initialized
INFO - 2026-08-19 03:31:07 --> Language Class Initialized
INFO - 2026-08-19 03:31:07 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:31:07 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:31:07 --> Language Class Initialized
INFO - 2026-08-19 03:31:07 --> Config Class Initialized
INFO - 2026-08-19 03:31:07 --> Output Class Initialized
INFO - 2026-08-19 03:31:07 --> Router Class Initialized
INFO - 2026-08-19 03:31:07 --> Security Class Initialized
INFO - 2026-08-19 03:31:07 --> Output Class Initialized
DEBUG - 2026-08-19 03:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:31:07 --> CSRF cookie sent
INFO - 2026-08-19 03:31:07 --> Input Class Initialized
INFO - 2026-08-19 03:31:07 --> Language Class Initialized
INFO - 2026-08-19 03:31:07 --> Language Class Initialized
INFO - 2026-08-19 03:31:07 --> Config Class Initialized
INFO - 2026-08-19 03:31:07 --> Security Class Initialized
INFO - 2026-08-19 03:31:07 --> Database Driver Class Initialized
DEBUG - 2026-08-19 03:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:31:07 --> Loader Class Initialized
INFO - 2026-08-19 03:31:07 --> CSRF cookie sent
INFO - 2026-08-19 03:31:07 --> Input Class Initialized
INFO - 2026-08-19 03:31:07 --> Language Class Initialized
INFO - 2026-08-19 03:31:07 --> Language Class Initialized
INFO - 2026-08-19 03:31:07 --> Config Class Initialized
INFO - 2026-08-19 03:31:07 --> Config Class Initialized
INFO - 2026-08-19 03:31:07 --> Hooks Class Initialized
INFO - 2026-08-19 03:31:07 --> Helper loaded: url_helper
DEBUG - 2026-08-19 03:31:07 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:31:07 --> Utf8 Class Initialized
INFO - 2026-08-19 03:31:07 --> Helper loaded: form_helper
INFO - 2026-08-19 03:31:07 --> URI Class Initialized
INFO - 2026-08-19 03:31:07 --> Helper loaded: html_helper
INFO - 2026-08-19 03:31:07 --> Helper loaded: file_helper
INFO - 2026-08-19 03:31:07 --> Helper loaded: email_helper
INFO - 2026-08-19 03:31:07 --> Router Class Initialized
INFO - 2026-08-19 03:31:07 --> Loader Class Initialized
INFO - 2026-08-19 03:31:07 --> Helper loaded: url_helper
INFO - 2026-08-19 03:31:07 --> Helper loaded: form_helper
INFO - 2026-08-19 03:31:07 --> Output Class Initialized
INFO - 2026-08-19 03:31:07 --> Helper loaded: html_helper
INFO - 2026-08-19 03:31:07 --> Helper loaded: file_helper
INFO - 2026-08-19 03:31:07 --> Helper loaded: email_helper
INFO - 2026-08-19 03:31:07 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:31:07 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:31:07 --> Security Class Initialized
DEBUG - 2026-08-19 03:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:31:07 --> CSRF cookie sent
INFO - 2026-08-19 03:31:07 --> Input Class Initialized
INFO - 2026-08-19 03:31:07 --> Language Class Initialized
INFO - 2026-08-19 03:31:07 --> Language Class Initialized
INFO - 2026-08-19 03:31:07 --> Config Class Initialized
INFO - 2026-08-19 03:31:07 --> Loader Class Initialized
INFO - 2026-08-19 03:31:08 --> Helper loaded: url_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: form_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:31:08 --> Loader Class Initialized
INFO - 2026-08-19 03:31:08 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: html_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: url_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: file_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: email_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: form_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: html_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: file_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: email_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:31:08 --> Database Driver Class Initialized
INFO - 2026-08-19 03:31:08 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:31:08 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:31:08 --> Database Driver Class Initialized
INFO - 2026-08-19 03:31:08 --> Database Driver Class Initialized
INFO - 2026-08-19 03:31:08 --> Database Driver Class Initialized
INFO - 2026-08-19 03:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:31:09 --> Upload Class Initialized
DEBUG - 2026-08-19 03:31:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:31:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:31:09 --> Encryption Class Initialized
INFO - 2026-08-19 03:31:09 --> Form Validation Class Initialized
INFO - 2026-08-19 03:31:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:31:09 --> Pagination Class Initialized
INFO - 2026-08-19 03:31:09 --> Email Class Initialized
INFO - 2026-08-19 03:31:09 --> Controller Class Initialized
ERROR - 2026-08-19 03:31:09 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:31:09 --> Upload Class Initialized
DEBUG - 2026-08-19 03:31:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:31:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:31:09 --> Encryption Class Initialized
INFO - 2026-08-19 03:31:09 --> Form Validation Class Initialized
INFO - 2026-08-19 03:31:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:31:09 --> Pagination Class Initialized
INFO - 2026-08-19 03:31:09 --> Config Class Initialized
INFO - 2026-08-19 03:31:09 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:31:09 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:31:09 --> Utf8 Class Initialized
INFO - 2026-08-19 03:31:09 --> URI Class Initialized
INFO - 2026-08-19 03:31:09 --> Email Class Initialized
INFO - 2026-08-19 03:31:09 --> Controller Class Initialized
ERROR - 2026-08-19 03:31:09 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:31:09 --> Router Class Initialized
INFO - 2026-08-19 03:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:31:09 --> Output Class Initialized
INFO - 2026-08-19 03:31:09 --> Upload Class Initialized
INFO - 2026-08-19 03:31:09 --> Security Class Initialized
DEBUG - 2026-08-19 03:31:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:31:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:31:09 --> Encryption Class Initialized
DEBUG - 2026-08-19 03:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:31:09 --> CSRF cookie sent
INFO - 2026-08-19 03:31:09 --> Input Class Initialized
INFO - 2026-08-19 03:31:09 --> Language Class Initialized
INFO - 2026-08-19 03:31:09 --> Form Validation Class Initialized
INFO - 2026-08-19 03:31:09 --> Language Class Initialized
INFO - 2026-08-19 03:31:09 --> Config Class Initialized
INFO - 2026-08-19 03:31:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:31:09 --> Pagination Class Initialized
INFO - 2026-08-19 03:31:09 --> Loader Class Initialized
INFO - 2026-08-19 03:31:09 --> Helper loaded: url_helper
INFO - 2026-08-19 03:31:09 --> Email Class Initialized
INFO - 2026-08-19 03:31:09 --> Controller Class Initialized
ERROR - 2026-08-19 03:31:09 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:31:09 --> Helper loaded: form_helper
INFO - 2026-08-19 03:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:31:09 --> Helper loaded: html_helper
INFO - 2026-08-19 03:31:09 --> Helper loaded: file_helper
INFO - 2026-08-19 03:31:09 --> Helper loaded: email_helper
INFO - 2026-08-19 03:31:09 --> Config Class Initialized
INFO - 2026-08-19 03:31:09 --> Hooks Class Initialized
INFO - 2026-08-19 03:31:09 --> Upload Class Initialized
INFO - 2026-08-19 03:31:09 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:31:09 --> Helper loaded: ssp_helper
DEBUG - 2026-08-19 03:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2026-08-19 03:31:09 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:31:09 --> Utf8 Class Initialized
INFO - 2026-08-19 03:31:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:31:09 --> Encryption Class Initialized
INFO - 2026-08-19 03:31:09 --> URI Class Initialized
INFO - 2026-08-19 03:31:09 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:31:09 --> Form Validation Class Initialized
INFO - 2026-08-19 03:31:09 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:31:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:31:09 --> Pagination Class Initialized
INFO - 2026-08-19 03:31:09 --> Router Class Initialized
INFO - 2026-08-19 03:31:09 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:31:09 --> Config Class Initialized
INFO - 2026-08-19 03:31:09 --> Hooks Class Initialized
INFO - 2026-08-19 03:31:09 --> Output Class Initialized
INFO - 2026-08-19 03:31:09 --> Email Class Initialized
INFO - 2026-08-19 03:31:09 --> Controller Class Initialized
INFO - 2026-08-19 03:31:09 --> Helper loaded: domain_helper
DEBUG - 2026-08-19 03:31:09 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:31:09 --> Utf8 Class Initialized
INFO - 2026-08-19 03:31:09 --> Helper loaded: entitlement_helper
ERROR - 2026-08-19 03:31:09 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:31:09 --> Security Class Initialized
INFO - 2026-08-19 03:31:09 --> URI Class Initialized
INFO - 2026-08-19 03:31:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-08-19 03:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:31:09 --> CSRF cookie sent
INFO - 2026-08-19 03:31:09 --> Input Class Initialized
INFO - 2026-08-19 03:31:09 --> Router Class Initialized
INFO - 2026-08-19 03:31:09 --> Language Class Initialized
INFO - 2026-08-19 03:31:09 --> Upload Class Initialized
DEBUG - 2026-08-19 03:31:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:31:09 --> Language Class Initialized
INFO - 2026-08-19 03:31:09 --> Config Class Initialized
INFO - 2026-08-19 03:31:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:31:09 --> Encryption Class Initialized
INFO - 2026-08-19 03:31:09 --> Output Class Initialized
INFO - 2026-08-19 03:31:09 --> Security Class Initialized
INFO - 2026-08-19 03:31:09 --> Database Driver Class Initialized
INFO - 2026-08-19 03:31:09 --> Form Validation Class Initialized
DEBUG - 2026-08-19 03:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:31:09 --> CSRF cookie sent
INFO - 2026-08-19 03:31:09 --> Input Class Initialized
INFO - 2026-08-19 03:31:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:31:09 --> Pagination Class Initialized
INFO - 2026-08-19 03:31:09 --> Language Class Initialized
INFO - 2026-08-19 03:31:09 --> Loader Class Initialized
INFO - 2026-08-19 03:31:09 --> Language Class Initialized
INFO - 2026-08-19 03:31:09 --> Config Class Initialized
INFO - 2026-08-19 03:31:09 --> Helper loaded: url_helper
INFO - 2026-08-19 03:31:09 --> Helper loaded: form_helper
INFO - 2026-08-19 03:31:09 --> Loader Class Initialized
INFO - 2026-08-19 03:31:09 --> Email Class Initialized
INFO - 2026-08-19 03:31:09 --> Helper loaded: html_helper
INFO - 2026-08-19 03:31:09 --> Controller Class Initialized
INFO - 2026-08-19 03:31:09 --> Helper loaded: url_helper
ERROR - 2026-08-19 03:31:09 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:31:09 --> Helper loaded: file_helper
INFO - 2026-08-19 03:31:09 --> Helper loaded: email_helper
INFO - 2026-08-19 03:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:31:09 --> Helper loaded: form_helper
INFO - 2026-08-19 03:31:09 --> Helper loaded: html_helper
INFO - 2026-08-19 03:31:09 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:31:09 --> Helper loaded: file_helper
INFO - 2026-08-19 03:31:09 --> Helper loaded: email_helper
INFO - 2026-08-19 03:31:09 --> Upload Class Initialized
INFO - 2026-08-19 03:31:09 --> Helper loaded: ssp_helper
DEBUG - 2026-08-19 03:31:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:31:09 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:31:09 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:31:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:31:09 --> Encryption Class Initialized
INFO - 2026-08-19 03:31:09 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:31:09 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:31:09 --> Form Validation Class Initialized
INFO - 2026-08-19 03:31:09 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:31:09 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:31:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:31:09 --> Pagination Class Initialized
INFO - 2026-08-19 03:31:09 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:31:09 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:31:09 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:31:09 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:31:09 --> Email Class Initialized
INFO - 2026-08-19 03:31:09 --> Controller Class Initialized
ERROR - 2026-08-19 03:31:09 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:31:09 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:31:09 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:31:09 --> Database Driver Class Initialized
INFO - 2026-08-19 03:31:09 --> Database Driver Class Initialized
INFO - 2026-08-19 03:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:31:11 --> Upload Class Initialized
DEBUG - 2026-08-19 03:31:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:31:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:31:11 --> Encryption Class Initialized
INFO - 2026-08-19 03:31:11 --> Form Validation Class Initialized
INFO - 2026-08-19 03:31:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:31:11 --> Pagination Class Initialized
INFO - 2026-08-19 03:31:11 --> Email Class Initialized
INFO - 2026-08-19 03:31:11 --> Controller Class Initialized
DEBUG - 2026-08-19 03:31:11 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:31:11 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:31:11 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:31:11 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:31:11 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:31:12 --> Upload Class Initialized
DEBUG - 2026-08-19 03:31:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:31:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:31:12 --> Encryption Class Initialized
INFO - 2026-08-19 03:31:12 --> Form Validation Class Initialized
INFO - 2026-08-19 03:31:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:31:12 --> Pagination Class Initialized
INFO - 2026-08-19 03:31:12 --> Email Class Initialized
INFO - 2026-08-19 03:31:12 --> Controller Class Initialized
ERROR - 2026-08-19 03:31:12 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:31:12 --> Upload Class Initialized
DEBUG - 2026-08-19 03:31:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:31:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:31:12 --> Encryption Class Initialized
INFO - 2026-08-19 03:31:12 --> Form Validation Class Initialized
INFO - 2026-08-19 03:31:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:31:12 --> Pagination Class Initialized
INFO - 2026-08-19 03:31:12 --> Email Class Initialized
INFO - 2026-08-19 03:31:12 --> Controller Class Initialized
DEBUG - 2026-08-19 03:31:12 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:31:12 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:31:12 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:31:12 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:31:12 --> Model "Common_model" initialized
INFO - 2026-08-19 03:31:12 --> Model "Order_model" initialized
INFO - 2026-08-19 03:31:12 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:31:12 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:31:12 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:31:12 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:31:12 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:31:12 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:31:12 --> Final output sent to browser
DEBUG - 2026-08-19 03:31:12 --> Total execution time: 2.7803
INFO - 2026-08-19 03:31:13 --> Config Class Initialized
INFO - 2026-08-19 03:31:13 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:31:13 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:31:13 --> Utf8 Class Initialized
INFO - 2026-08-19 03:31:13 --> URI Class Initialized
INFO - 2026-08-19 03:31:13 --> Router Class Initialized
INFO - 2026-08-19 03:31:13 --> Output Class Initialized
INFO - 2026-08-19 03:31:13 --> Security Class Initialized
DEBUG - 2026-08-19 03:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:31:13 --> CSRF cookie sent
INFO - 2026-08-19 03:31:13 --> Input Class Initialized
INFO - 2026-08-19 03:31:13 --> Language Class Initialized
INFO - 2026-08-19 03:31:13 --> Language Class Initialized
INFO - 2026-08-19 03:31:13 --> Config Class Initialized
INFO - 2026-08-19 03:31:13 --> Loader Class Initialized
INFO - 2026-08-19 03:31:13 --> Helper loaded: url_helper
INFO - 2026-08-19 03:31:13 --> Helper loaded: form_helper
INFO - 2026-08-19 03:31:13 --> Helper loaded: html_helper
INFO - 2026-08-19 03:31:13 --> Helper loaded: file_helper
INFO - 2026-08-19 03:31:13 --> Helper loaded: email_helper
INFO - 2026-08-19 03:31:13 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:31:13 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:31:13 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:31:13 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:31:13 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:31:13 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:31:13 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:31:13 --> Database Driver Class Initialized
INFO - 2026-08-19 03:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:31:14 --> Upload Class Initialized
DEBUG - 2026-08-19 03:31:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:31:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:31:14 --> Encryption Class Initialized
INFO - 2026-08-19 03:31:14 --> Form Validation Class Initialized
INFO - 2026-08-19 03:31:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:31:14 --> Pagination Class Initialized
INFO - 2026-08-19 03:31:14 --> Email Class Initialized
INFO - 2026-08-19 03:31:14 --> Controller Class Initialized
DEBUG - 2026-08-19 03:31:14 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:31:14 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:31:14 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:31:14 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:31:14 --> Model "Common_model" initialized
INFO - 2026-08-19 03:31:14 --> Model "Order_model" initialized
INFO - 2026-08-19 03:31:14 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:31:14 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:31:14 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:31:14 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:31:14 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:31:14 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:31:15 --> Final output sent to browser
DEBUG - 2026-08-19 03:31:15 --> Total execution time: 2.7498
INFO - 2026-08-19 03:31:15 --> Config Class Initialized
INFO - 2026-08-19 03:31:15 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:31:15 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:31:15 --> Utf8 Class Initialized
INFO - 2026-08-19 03:31:15 --> URI Class Initialized
INFO - 2026-08-19 03:31:15 --> Router Class Initialized
INFO - 2026-08-19 03:31:15 --> Output Class Initialized
INFO - 2026-08-19 03:31:15 --> Security Class Initialized
DEBUG - 2026-08-19 03:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:31:15 --> CSRF cookie sent
INFO - 2026-08-19 03:31:15 --> Input Class Initialized
INFO - 2026-08-19 03:31:15 --> Language Class Initialized
INFO - 2026-08-19 03:31:15 --> Language Class Initialized
INFO - 2026-08-19 03:31:15 --> Config Class Initialized
INFO - 2026-08-19 03:31:15 --> Loader Class Initialized
INFO - 2026-08-19 03:31:15 --> Helper loaded: url_helper
INFO - 2026-08-19 03:31:15 --> Helper loaded: form_helper
INFO - 2026-08-19 03:31:15 --> Helper loaded: html_helper
INFO - 2026-08-19 03:31:15 --> Helper loaded: file_helper
INFO - 2026-08-19 03:31:15 --> Helper loaded: email_helper
INFO - 2026-08-19 03:31:15 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:31:15 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:31:15 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:31:15 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:31:15 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:31:15 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:31:15 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:31:15 --> Database Driver Class Initialized
INFO - 2026-08-19 03:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:31:17 --> Upload Class Initialized
DEBUG - 2026-08-19 03:31:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:31:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:31:17 --> Encryption Class Initialized
INFO - 2026-08-19 03:31:17 --> Form Validation Class Initialized
INFO - 2026-08-19 03:31:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:31:17 --> Pagination Class Initialized
INFO - 2026-08-19 03:31:17 --> Email Class Initialized
INFO - 2026-08-19 03:31:17 --> Controller Class Initialized
DEBUG - 2026-08-19 03:31:17 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:31:17 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:31:17 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:31:17 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:31:17 --> Model "Common_model" initialized
INFO - 2026-08-19 03:31:17 --> Model "Order_model" initialized
INFO - 2026-08-19 03:31:17 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:31:17 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:31:17 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:31:17 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:31:17 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:31:17 --> Model "Orderlicense_model" initialized
DEBUG - 2026-08-19 03:31:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:31:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-08-19 03:31:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-08-19 03:31:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:31:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:31:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/view_card.php
INFO - 2026-08-19 03:31:20 --> Final output sent to browser
DEBUG - 2026-08-19 03:31:20 --> Total execution time: 4.6981
INFO - 2026-08-19 03:31:20 --> Config Class Initialized
INFO - 2026-08-19 03:31:20 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:31:20 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:31:20 --> Utf8 Class Initialized
INFO - 2026-08-19 03:31:20 --> URI Class Initialized
INFO - 2026-08-19 03:31:20 --> Router Class Initialized
INFO - 2026-08-19 03:31:20 --> Output Class Initialized
INFO - 2026-08-19 03:31:20 --> Security Class Initialized
DEBUG - 2026-08-19 03:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:31:20 --> CSRF cookie sent
INFO - 2026-08-19 03:31:20 --> Input Class Initialized
INFO - 2026-08-19 03:31:20 --> Language Class Initialized
INFO - 2026-08-19 03:31:20 --> Language Class Initialized
INFO - 2026-08-19 03:31:20 --> Config Class Initialized
INFO - 2026-08-19 03:31:20 --> Loader Class Initialized
INFO - 2026-08-19 03:31:20 --> Helper loaded: url_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: form_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: html_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: file_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: email_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:31:20 --> Database Driver Class Initialized
INFO - 2026-08-19 03:31:20 --> Config Class Initialized
INFO - 2026-08-19 03:31:20 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:31:20 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:31:20 --> Utf8 Class Initialized
INFO - 2026-08-19 03:31:20 --> URI Class Initialized
INFO - 2026-08-19 03:31:20 --> Router Class Initialized
INFO - 2026-08-19 03:31:20 --> Output Class Initialized
INFO - 2026-08-19 03:31:20 --> Security Class Initialized
DEBUG - 2026-08-19 03:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:31:20 --> CSRF cookie sent
INFO - 2026-08-19 03:31:20 --> Input Class Initialized
INFO - 2026-08-19 03:31:20 --> Language Class Initialized
INFO - 2026-08-19 03:31:20 --> Language Class Initialized
INFO - 2026-08-19 03:31:20 --> Config Class Initialized
INFO - 2026-08-19 03:31:20 --> Loader Class Initialized
INFO - 2026-08-19 03:31:20 --> Helper loaded: url_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: form_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: html_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: file_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: email_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:31:20 --> Database Driver Class Initialized
INFO - 2026-08-19 03:31:20 --> Config Class Initialized
INFO - 2026-08-19 03:31:20 --> Hooks Class Initialized
INFO - 2026-08-19 03:31:20 --> Config Class Initialized
INFO - 2026-08-19 03:31:20 --> Config Class Initialized
INFO - 2026-08-19 03:31:20 --> Hooks Class Initialized
INFO - 2026-08-19 03:31:20 --> Config Class Initialized
INFO - 2026-08-19 03:31:20 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:31:20 --> UTF-8 Support Enabled
DEBUG - 2026-08-19 03:31:20 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:31:20 --> Hooks Class Initialized
INFO - 2026-08-19 03:31:20 --> Utf8 Class Initialized
INFO - 2026-08-19 03:31:20 --> Utf8 Class Initialized
DEBUG - 2026-08-19 03:31:20 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:31:20 --> Utf8 Class Initialized
INFO - 2026-08-19 03:31:20 --> URI Class Initialized
INFO - 2026-08-19 03:31:20 --> URI Class Initialized
INFO - 2026-08-19 03:31:20 --> URI Class Initialized
DEBUG - 2026-08-19 03:31:20 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:31:20 --> Utf8 Class Initialized
INFO - 2026-08-19 03:31:20 --> URI Class Initialized
INFO - 2026-08-19 03:31:20 --> Router Class Initialized
INFO - 2026-08-19 03:31:20 --> Router Class Initialized
INFO - 2026-08-19 03:31:20 --> Router Class Initialized
INFO - 2026-08-19 03:31:20 --> Output Class Initialized
INFO - 2026-08-19 03:31:20 --> Output Class Initialized
INFO - 2026-08-19 03:31:20 --> Output Class Initialized
INFO - 2026-08-19 03:31:20 --> Router Class Initialized
INFO - 2026-08-19 03:31:20 --> Security Class Initialized
DEBUG - 2026-08-19 03:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:31:20 --> CSRF cookie sent
INFO - 2026-08-19 03:31:20 --> Security Class Initialized
INFO - 2026-08-19 03:31:20 --> Security Class Initialized
INFO - 2026-08-19 03:31:20 --> Output Class Initialized
INFO - 2026-08-19 03:31:20 --> Input Class Initialized
INFO - 2026-08-19 03:31:20 --> Language Class Initialized
DEBUG - 2026-08-19 03:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-08-19 03:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:31:20 --> CSRF cookie sent
INFO - 2026-08-19 03:31:20 --> CSRF cookie sent
INFO - 2026-08-19 03:31:20 --> Input Class Initialized
INFO - 2026-08-19 03:31:20 --> Input Class Initialized
INFO - 2026-08-19 03:31:20 --> Language Class Initialized
INFO - 2026-08-19 03:31:20 --> Language Class Initialized
INFO - 2026-08-19 03:31:20 --> Config Class Initialized
INFO - 2026-08-19 03:31:20 --> Language Class Initialized
INFO - 2026-08-19 03:31:20 --> Security Class Initialized
INFO - 2026-08-19 03:31:20 --> Language Class Initialized
INFO - 2026-08-19 03:31:20 --> Language Class Initialized
INFO - 2026-08-19 03:31:20 --> Config Class Initialized
INFO - 2026-08-19 03:31:20 --> Config Class Initialized
DEBUG - 2026-08-19 03:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:31:20 --> CSRF cookie sent
INFO - 2026-08-19 03:31:20 --> Input Class Initialized
INFO - 2026-08-19 03:31:20 --> Loader Class Initialized
INFO - 2026-08-19 03:31:20 --> Language Class Initialized
INFO - 2026-08-19 03:31:20 --> Helper loaded: url_helper
INFO - 2026-08-19 03:31:20 --> Language Class Initialized
INFO - 2026-08-19 03:31:20 --> Config Class Initialized
INFO - 2026-08-19 03:31:20 --> Helper loaded: form_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: html_helper
INFO - 2026-08-19 03:31:20 --> Loader Class Initialized
INFO - 2026-08-19 03:31:20 --> Loader Class Initialized
INFO - 2026-08-19 03:31:20 --> Helper loaded: file_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: email_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: url_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: url_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:31:20 --> Loader Class Initialized
INFO - 2026-08-19 03:31:20 --> Helper loaded: form_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: form_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: html_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: html_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: url_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: file_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: file_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: email_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: email_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: form_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: html_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: file_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: email_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:31:20 --> Database Driver Class Initialized
INFO - 2026-08-19 03:31:20 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:31:20 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:31:20 --> Database Driver Class Initialized
INFO - 2026-08-19 03:31:20 --> Database Driver Class Initialized
INFO - 2026-08-19 03:31:20 --> Database Driver Class Initialized
INFO - 2026-08-19 03:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:31:22 --> Upload Class Initialized
DEBUG - 2026-08-19 03:31:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:31:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:31:22 --> Encryption Class Initialized
INFO - 2026-08-19 03:31:22 --> Form Validation Class Initialized
INFO - 2026-08-19 03:31:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:31:22 --> Pagination Class Initialized
INFO - 2026-08-19 03:31:22 --> Email Class Initialized
INFO - 2026-08-19 03:31:22 --> Controller Class Initialized
ERROR - 2026-08-19 03:31:22 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:31:22 --> Upload Class Initialized
DEBUG - 2026-08-19 03:31:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:31:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:31:22 --> Encryption Class Initialized
INFO - 2026-08-19 03:31:22 --> Form Validation Class Initialized
INFO - 2026-08-19 03:31:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:31:22 --> Pagination Class Initialized
INFO - 2026-08-19 03:31:22 --> Config Class Initialized
INFO - 2026-08-19 03:31:22 --> Hooks Class Initialized
INFO - 2026-08-19 03:31:22 --> Email Class Initialized
INFO - 2026-08-19 03:31:22 --> Controller Class Initialized
DEBUG - 2026-08-19 03:31:22 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:31:22 --> Utf8 Class Initialized
ERROR - 2026-08-19 03:31:22 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:31:22 --> URI Class Initialized
INFO - 2026-08-19 03:31:22 --> Upload Class Initialized
INFO - 2026-08-19 03:31:22 --> Router Class Initialized
DEBUG - 2026-08-19 03:31:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:31:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:31:22 --> Encryption Class Initialized
INFO - 2026-08-19 03:31:22 --> Output Class Initialized
INFO - 2026-08-19 03:31:22 --> Form Validation Class Initialized
INFO - 2026-08-19 03:31:22 --> Security Class Initialized
INFO - 2026-08-19 03:31:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:31:22 --> Pagination Class Initialized
DEBUG - 2026-08-19 03:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:31:22 --> CSRF cookie sent
INFO - 2026-08-19 03:31:22 --> Input Class Initialized
INFO - 2026-08-19 03:31:22 --> Language Class Initialized
INFO - 2026-08-19 03:31:22 --> Email Class Initialized
INFO - 2026-08-19 03:31:22 --> Language Class Initialized
INFO - 2026-08-19 03:31:22 --> Config Class Initialized
INFO - 2026-08-19 03:31:22 --> Controller Class Initialized
INFO - 2026-08-19 03:31:22 --> Config Class Initialized
ERROR - 2026-08-19 03:31:22 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:31:22 --> Hooks Class Initialized
INFO - 2026-08-19 03:31:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-08-19 03:31:22 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:31:22 --> Utf8 Class Initialized
INFO - 2026-08-19 03:31:22 --> Upload Class Initialized
INFO - 2026-08-19 03:31:22 --> URI Class Initialized
INFO - 2026-08-19 03:31:22 --> Loader Class Initialized
DEBUG - 2026-08-19 03:31:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:31:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:31:22 --> Encryption Class Initialized
INFO - 2026-08-19 03:31:22 --> Helper loaded: url_helper
INFO - 2026-08-19 03:31:22 --> Router Class Initialized
INFO - 2026-08-19 03:31:22 --> Form Validation Class Initialized
INFO - 2026-08-19 03:31:22 --> Helper loaded: form_helper
INFO - 2026-08-19 03:31:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:31:22 --> Pagination Class Initialized
INFO - 2026-08-19 03:31:22 --> Helper loaded: html_helper
INFO - 2026-08-19 03:31:22 --> Output Class Initialized
INFO - 2026-08-19 03:31:22 --> Helper loaded: file_helper
INFO - 2026-08-19 03:31:22 --> Helper loaded: email_helper
INFO - 2026-08-19 03:31:22 --> Security Class Initialized
DEBUG - 2026-08-19 03:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:31:22 --> CSRF cookie sent
INFO - 2026-08-19 03:31:22 --> Input Class Initialized
INFO - 2026-08-19 03:31:22 --> Email Class Initialized
INFO - 2026-08-19 03:31:22 --> Language Class Initialized
INFO - 2026-08-19 03:31:22 --> Controller Class Initialized
ERROR - 2026-08-19 03:31:22 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:31:22 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:31:22 --> Language Class Initialized
INFO - 2026-08-19 03:31:22 --> Config Class Initialized
INFO - 2026-08-19 03:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:31:22 --> Config Class Initialized
INFO - 2026-08-19 03:31:22 --> Hooks Class Initialized
INFO - 2026-08-19 03:31:22 --> Helper loaded: ssp_helper
DEBUG - 2026-08-19 03:31:22 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:31:22 --> Utf8 Class Initialized
INFO - 2026-08-19 03:31:22 --> URI Class Initialized
INFO - 2026-08-19 03:31:22 --> Upload Class Initialized
INFO - 2026-08-19 03:31:22 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:31:22 --> Loader Class Initialized
DEBUG - 2026-08-19 03:31:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:31:22 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:31:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:31:22 --> Encryption Class Initialized
INFO - 2026-08-19 03:31:22 --> Router Class Initialized
INFO - 2026-08-19 03:31:22 --> Helper loaded: url_helper
INFO - 2026-08-19 03:31:22 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:31:22 --> Output Class Initialized
INFO - 2026-08-19 03:31:22 --> Helper loaded: form_helper
INFO - 2026-08-19 03:31:22 --> Form Validation Class Initialized
INFO - 2026-08-19 03:31:22 --> Security Class Initialized
INFO - 2026-08-19 03:31:22 --> Helper loaded: html_helper
DEBUG - 2026-08-19 03:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:31:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:31:22 --> CSRF cookie sent
INFO - 2026-08-19 03:31:22 --> Input Class Initialized
INFO - 2026-08-19 03:31:22 --> Pagination Class Initialized
INFO - 2026-08-19 03:31:22 --> Language Class Initialized
INFO - 2026-08-19 03:31:22 --> Helper loaded: file_helper
INFO - 2026-08-19 03:31:22 --> Helper loaded: email_helper
INFO - 2026-08-19 03:31:22 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:31:22 --> Language Class Initialized
INFO - 2026-08-19 03:31:22 --> Config Class Initialized
INFO - 2026-08-19 03:31:22 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:31:22 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:31:22 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:31:22 --> Loader Class Initialized
INFO - 2026-08-19 03:31:22 --> Email Class Initialized
INFO - 2026-08-19 03:31:22 --> Controller Class Initialized
INFO - 2026-08-19 03:31:22 --> Helper loaded: url_helper
ERROR - 2026-08-19 03:31:22 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:31:22 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:31:22 --> Helper loaded: form_helper
INFO - 2026-08-19 03:31:22 --> Helper loaded: html_helper
INFO - 2026-08-19 03:31:22 --> Helper loaded: file_helper
INFO - 2026-08-19 03:31:22 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:31:22 --> Helper loaded: email_helper
INFO - 2026-08-19 03:31:22 --> Upload Class Initialized
INFO - 2026-08-19 03:31:22 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:31:22 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:31:22 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:31:22 --> Database Driver Class Initialized
DEBUG - 2026-08-19 03:31:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:31:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:31:22 --> Encryption Class Initialized
INFO - 2026-08-19 03:31:22 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:31:22 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:31:22 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:31:22 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:31:22 --> Form Validation Class Initialized
INFO - 2026-08-19 03:31:22 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:31:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:31:22 --> Pagination Class Initialized
INFO - 2026-08-19 03:31:22 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:31:22 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:31:22 --> Email Class Initialized
INFO - 2026-08-19 03:31:22 --> Controller Class Initialized
ERROR - 2026-08-19 03:31:22 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:31:22 --> Database Driver Class Initialized
INFO - 2026-08-19 03:31:22 --> Database Driver Class Initialized
INFO - 2026-08-19 03:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:31:24 --> Upload Class Initialized
DEBUG - 2026-08-19 03:31:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:31:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:31:24 --> Encryption Class Initialized
INFO - 2026-08-19 03:31:24 --> Form Validation Class Initialized
INFO - 2026-08-19 03:31:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:31:24 --> Pagination Class Initialized
INFO - 2026-08-19 03:31:24 --> Email Class Initialized
INFO - 2026-08-19 03:31:24 --> Controller Class Initialized
DEBUG - 2026-08-19 03:31:24 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:31:24 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:31:24 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:31:24 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:31:24 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:31:24 --> Upload Class Initialized
DEBUG - 2026-08-19 03:31:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:31:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:31:24 --> Encryption Class Initialized
INFO - 2026-08-19 03:31:24 --> Form Validation Class Initialized
INFO - 2026-08-19 03:31:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:31:24 --> Pagination Class Initialized
INFO - 2026-08-19 03:31:24 --> Email Class Initialized
INFO - 2026-08-19 03:31:24 --> Controller Class Initialized
ERROR - 2026-08-19 03:31:24 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:31:24 --> Upload Class Initialized
DEBUG - 2026-08-19 03:31:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:31:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:31:24 --> Encryption Class Initialized
INFO - 2026-08-19 03:31:24 --> Form Validation Class Initialized
INFO - 2026-08-19 03:31:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:31:24 --> Pagination Class Initialized
INFO - 2026-08-19 03:31:24 --> Email Class Initialized
INFO - 2026-08-19 03:31:24 --> Controller Class Initialized
DEBUG - 2026-08-19 03:31:24 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:31:24 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:31:24 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:31:24 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:31:24 --> Model "Common_model" initialized
INFO - 2026-08-19 03:31:24 --> Model "Order_model" initialized
INFO - 2026-08-19 03:31:24 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:31:24 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:31:24 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:31:24 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:31:24 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:31:24 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:31:25 --> Final output sent to browser
DEBUG - 2026-08-19 03:31:25 --> Total execution time: 2.8482
INFO - 2026-08-19 03:31:48 --> Config Class Initialized
INFO - 2026-08-19 03:31:48 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:31:48 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:31:48 --> Utf8 Class Initialized
INFO - 2026-08-19 03:31:48 --> URI Class Initialized
INFO - 2026-08-19 03:31:48 --> Router Class Initialized
INFO - 2026-08-19 03:31:48 --> Output Class Initialized
INFO - 2026-08-19 03:31:48 --> Security Class Initialized
DEBUG - 2026-08-19 03:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:31:48 --> CSRF cookie sent
INFO - 2026-08-19 03:31:48 --> Input Class Initialized
INFO - 2026-08-19 03:31:48 --> Language Class Initialized
INFO - 2026-08-19 03:31:48 --> Language Class Initialized
INFO - 2026-08-19 03:31:48 --> Config Class Initialized
INFO - 2026-08-19 03:31:48 --> Loader Class Initialized
INFO - 2026-08-19 03:31:48 --> Helper loaded: url_helper
INFO - 2026-08-19 03:31:48 --> Helper loaded: form_helper
INFO - 2026-08-19 03:31:48 --> Helper loaded: html_helper
INFO - 2026-08-19 03:31:48 --> Helper loaded: file_helper
INFO - 2026-08-19 03:31:48 --> Helper loaded: email_helper
INFO - 2026-08-19 03:31:48 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:31:48 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:31:48 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:31:48 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:31:48 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:31:48 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:31:48 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:31:48 --> Database Driver Class Initialized
INFO - 2026-08-19 03:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:31:49 --> Upload Class Initialized
DEBUG - 2026-08-19 03:31:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:31:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:31:49 --> Encryption Class Initialized
INFO - 2026-08-19 03:31:49 --> Form Validation Class Initialized
INFO - 2026-08-19 03:31:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:31:49 --> Pagination Class Initialized
INFO - 2026-08-19 03:31:49 --> Email Class Initialized
INFO - 2026-08-19 03:31:49 --> Controller Class Initialized
DEBUG - 2026-08-19 03:31:49 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:31:49 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:31:49 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:31:49 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:31:49 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:32:21 --> Config Class Initialized
INFO - 2026-08-19 03:32:21 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:32:21 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:32:21 --> Utf8 Class Initialized
INFO - 2026-08-19 03:32:21 --> URI Class Initialized
INFO - 2026-08-19 03:32:21 --> Router Class Initialized
INFO - 2026-08-19 03:32:21 --> Output Class Initialized
INFO - 2026-08-19 03:32:21 --> Security Class Initialized
DEBUG - 2026-08-19 03:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:32:21 --> CSRF cookie sent
INFO - 2026-08-19 03:32:21 --> Input Class Initialized
INFO - 2026-08-19 03:32:21 --> Language Class Initialized
INFO - 2026-08-19 03:32:21 --> Language Class Initialized
INFO - 2026-08-19 03:32:21 --> Config Class Initialized
INFO - 2026-08-19 03:32:21 --> Loader Class Initialized
INFO - 2026-08-19 03:32:21 --> Helper loaded: url_helper
INFO - 2026-08-19 03:32:21 --> Helper loaded: form_helper
INFO - 2026-08-19 03:32:21 --> Helper loaded: html_helper
INFO - 2026-08-19 03:32:21 --> Helper loaded: file_helper
INFO - 2026-08-19 03:32:21 --> Helper loaded: email_helper
INFO - 2026-08-19 03:32:21 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:32:21 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:32:21 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:32:21 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:32:21 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:32:21 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:32:21 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:32:21 --> Database Driver Class Initialized
INFO - 2026-08-19 03:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:32:22 --> Upload Class Initialized
DEBUG - 2026-08-19 03:32:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:32:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:32:22 --> Encryption Class Initialized
INFO - 2026-08-19 03:32:22 --> Form Validation Class Initialized
INFO - 2026-08-19 03:32:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:32:22 --> Pagination Class Initialized
INFO - 2026-08-19 03:32:22 --> Email Class Initialized
INFO - 2026-08-19 03:32:22 --> Controller Class Initialized
DEBUG - 2026-08-19 03:32:22 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:32:22 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:32:22 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:32:22 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:32:22 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:32:48 --> Config Class Initialized
INFO - 2026-08-19 03:32:48 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:32:48 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:32:48 --> Utf8 Class Initialized
INFO - 2026-08-19 03:32:48 --> URI Class Initialized
INFO - 2026-08-19 03:32:48 --> Router Class Initialized
INFO - 2026-08-19 03:32:48 --> Output Class Initialized
INFO - 2026-08-19 03:32:48 --> Security Class Initialized
DEBUG - 2026-08-19 03:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:32:48 --> CSRF cookie sent
INFO - 2026-08-19 03:32:48 --> Input Class Initialized
INFO - 2026-08-19 03:32:48 --> Language Class Initialized
INFO - 2026-08-19 03:32:48 --> Language Class Initialized
INFO - 2026-08-19 03:32:48 --> Config Class Initialized
INFO - 2026-08-19 03:32:48 --> Loader Class Initialized
INFO - 2026-08-19 03:32:48 --> Helper loaded: url_helper
INFO - 2026-08-19 03:32:48 --> Helper loaded: form_helper
INFO - 2026-08-19 03:32:48 --> Helper loaded: html_helper
INFO - 2026-08-19 03:32:48 --> Helper loaded: file_helper
INFO - 2026-08-19 03:32:48 --> Helper loaded: email_helper
INFO - 2026-08-19 03:32:48 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:32:48 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:32:48 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:32:48 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:32:48 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:32:48 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:32:48 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:32:48 --> Database Driver Class Initialized
INFO - 2026-08-19 03:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:32:49 --> Upload Class Initialized
DEBUG - 2026-08-19 03:32:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:32:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:32:49 --> Encryption Class Initialized
INFO - 2026-08-19 03:32:49 --> Form Validation Class Initialized
INFO - 2026-08-19 03:32:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:32:49 --> Pagination Class Initialized
INFO - 2026-08-19 03:32:49 --> Email Class Initialized
INFO - 2026-08-19 03:32:49 --> Controller Class Initialized
DEBUG - 2026-08-19 03:32:49 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:32:49 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:32:49 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:32:49 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:32:49 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:33:21 --> Config Class Initialized
INFO - 2026-08-19 03:33:21 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:33:21 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:33:21 --> Utf8 Class Initialized
INFO - 2026-08-19 03:33:21 --> URI Class Initialized
INFO - 2026-08-19 03:33:21 --> Router Class Initialized
INFO - 2026-08-19 03:33:21 --> Output Class Initialized
INFO - 2026-08-19 03:33:21 --> Security Class Initialized
DEBUG - 2026-08-19 03:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:33:21 --> CSRF cookie sent
INFO - 2026-08-19 03:33:21 --> Input Class Initialized
INFO - 2026-08-19 03:33:21 --> Language Class Initialized
INFO - 2026-08-19 03:33:21 --> Language Class Initialized
INFO - 2026-08-19 03:33:21 --> Config Class Initialized
INFO - 2026-08-19 03:33:21 --> Loader Class Initialized
INFO - 2026-08-19 03:33:21 --> Helper loaded: url_helper
INFO - 2026-08-19 03:33:21 --> Helper loaded: form_helper
INFO - 2026-08-19 03:33:21 --> Helper loaded: html_helper
INFO - 2026-08-19 03:33:21 --> Helper loaded: file_helper
INFO - 2026-08-19 03:33:21 --> Helper loaded: email_helper
INFO - 2026-08-19 03:33:21 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:33:21 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:33:21 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:33:21 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:33:21 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:33:21 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:33:21 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:33:21 --> Database Driver Class Initialized
INFO - 2026-08-19 03:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:33:22 --> Upload Class Initialized
DEBUG - 2026-08-19 03:33:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:33:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:33:22 --> Encryption Class Initialized
INFO - 2026-08-19 03:33:22 --> Form Validation Class Initialized
INFO - 2026-08-19 03:33:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:33:22 --> Pagination Class Initialized
INFO - 2026-08-19 03:33:22 --> Email Class Initialized
INFO - 2026-08-19 03:33:22 --> Controller Class Initialized
DEBUG - 2026-08-19 03:33:22 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:33:22 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:33:22 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:33:22 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:33:22 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:33:48 --> Config Class Initialized
INFO - 2026-08-19 03:33:48 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:33:48 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:33:48 --> Utf8 Class Initialized
INFO - 2026-08-19 03:33:48 --> URI Class Initialized
INFO - 2026-08-19 03:33:48 --> Router Class Initialized
INFO - 2026-08-19 03:33:48 --> Output Class Initialized
INFO - 2026-08-19 03:33:48 --> Security Class Initialized
DEBUG - 2026-08-19 03:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:33:48 --> CSRF cookie sent
INFO - 2026-08-19 03:33:48 --> Input Class Initialized
INFO - 2026-08-19 03:33:48 --> Language Class Initialized
INFO - 2026-08-19 03:33:48 --> Language Class Initialized
INFO - 2026-08-19 03:33:48 --> Config Class Initialized
INFO - 2026-08-19 03:33:48 --> Loader Class Initialized
INFO - 2026-08-19 03:33:48 --> Helper loaded: url_helper
INFO - 2026-08-19 03:33:48 --> Helper loaded: form_helper
INFO - 2026-08-19 03:33:48 --> Helper loaded: html_helper
INFO - 2026-08-19 03:33:48 --> Helper loaded: file_helper
INFO - 2026-08-19 03:33:48 --> Helper loaded: email_helper
INFO - 2026-08-19 03:33:48 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:33:48 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:33:48 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:33:48 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:33:48 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:33:48 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:33:48 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:33:48 --> Database Driver Class Initialized
INFO - 2026-08-19 03:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:33:50 --> Upload Class Initialized
DEBUG - 2026-08-19 03:33:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:33:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:33:50 --> Encryption Class Initialized
INFO - 2026-08-19 03:33:50 --> Form Validation Class Initialized
INFO - 2026-08-19 03:33:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:33:50 --> Pagination Class Initialized
INFO - 2026-08-19 03:33:50 --> Email Class Initialized
INFO - 2026-08-19 03:33:50 --> Controller Class Initialized
DEBUG - 2026-08-19 03:33:50 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:33:50 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:33:50 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:33:50 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:33:50 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:34:21 --> Config Class Initialized
INFO - 2026-08-19 03:34:21 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:34:21 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:34:21 --> Utf8 Class Initialized
INFO - 2026-08-19 03:34:21 --> URI Class Initialized
INFO - 2026-08-19 03:34:21 --> Router Class Initialized
INFO - 2026-08-19 03:34:21 --> Output Class Initialized
INFO - 2026-08-19 03:34:21 --> Security Class Initialized
DEBUG - 2026-08-19 03:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:34:21 --> CSRF cookie sent
INFO - 2026-08-19 03:34:21 --> Input Class Initialized
INFO - 2026-08-19 03:34:21 --> Language Class Initialized
INFO - 2026-08-19 03:34:21 --> Language Class Initialized
INFO - 2026-08-19 03:34:21 --> Config Class Initialized
INFO - 2026-08-19 03:34:21 --> Loader Class Initialized
INFO - 2026-08-19 03:34:21 --> Helper loaded: url_helper
INFO - 2026-08-19 03:34:21 --> Helper loaded: form_helper
INFO - 2026-08-19 03:34:21 --> Helper loaded: html_helper
INFO - 2026-08-19 03:34:21 --> Helper loaded: file_helper
INFO - 2026-08-19 03:34:21 --> Helper loaded: email_helper
INFO - 2026-08-19 03:34:21 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:34:21 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:34:21 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:34:21 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:34:21 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:34:21 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:34:21 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:34:21 --> Database Driver Class Initialized
INFO - 2026-08-19 03:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:34:23 --> Upload Class Initialized
DEBUG - 2026-08-19 03:34:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:34:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:34:23 --> Encryption Class Initialized
INFO - 2026-08-19 03:34:23 --> Form Validation Class Initialized
INFO - 2026-08-19 03:34:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:34:23 --> Pagination Class Initialized
INFO - 2026-08-19 03:34:23 --> Email Class Initialized
INFO - 2026-08-19 03:34:23 --> Controller Class Initialized
DEBUG - 2026-08-19 03:34:23 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:34:23 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:34:23 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:34:23 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:34:23 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:34:48 --> Config Class Initialized
INFO - 2026-08-19 03:34:48 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:34:48 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:34:48 --> Utf8 Class Initialized
INFO - 2026-08-19 03:34:48 --> URI Class Initialized
INFO - 2026-08-19 03:34:48 --> Router Class Initialized
INFO - 2026-08-19 03:34:48 --> Output Class Initialized
INFO - 2026-08-19 03:34:48 --> Security Class Initialized
DEBUG - 2026-08-19 03:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:34:48 --> CSRF cookie sent
INFO - 2026-08-19 03:34:48 --> Input Class Initialized
INFO - 2026-08-19 03:34:48 --> Language Class Initialized
INFO - 2026-08-19 03:34:48 --> Language Class Initialized
INFO - 2026-08-19 03:34:48 --> Config Class Initialized
INFO - 2026-08-19 03:34:48 --> Loader Class Initialized
INFO - 2026-08-19 03:34:48 --> Helper loaded: url_helper
INFO - 2026-08-19 03:34:48 --> Helper loaded: form_helper
INFO - 2026-08-19 03:34:48 --> Helper loaded: html_helper
INFO - 2026-08-19 03:34:48 --> Helper loaded: file_helper
INFO - 2026-08-19 03:34:48 --> Helper loaded: email_helper
INFO - 2026-08-19 03:34:48 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:34:48 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:34:48 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:34:48 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:34:48 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:34:48 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:34:48 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:34:48 --> Database Driver Class Initialized
INFO - 2026-08-19 03:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:34:50 --> Upload Class Initialized
DEBUG - 2026-08-19 03:34:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:34:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:34:50 --> Encryption Class Initialized
INFO - 2026-08-19 03:34:50 --> Form Validation Class Initialized
INFO - 2026-08-19 03:34:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:34:50 --> Pagination Class Initialized
INFO - 2026-08-19 03:34:50 --> Email Class Initialized
INFO - 2026-08-19 03:34:50 --> Controller Class Initialized
DEBUG - 2026-08-19 03:34:50 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:34:50 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:34:50 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:34:50 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:34:50 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:35:21 --> Config Class Initialized
INFO - 2026-08-19 03:35:21 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:35:21 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:35:21 --> Utf8 Class Initialized
INFO - 2026-08-19 03:35:21 --> URI Class Initialized
INFO - 2026-08-19 03:35:21 --> Router Class Initialized
INFO - 2026-08-19 03:35:21 --> Output Class Initialized
INFO - 2026-08-19 03:35:21 --> Security Class Initialized
DEBUG - 2026-08-19 03:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:35:21 --> CSRF cookie sent
INFO - 2026-08-19 03:35:21 --> Input Class Initialized
INFO - 2026-08-19 03:35:21 --> Language Class Initialized
INFO - 2026-08-19 03:35:21 --> Language Class Initialized
INFO - 2026-08-19 03:35:21 --> Config Class Initialized
INFO - 2026-08-19 03:35:21 --> Loader Class Initialized
INFO - 2026-08-19 03:35:21 --> Helper loaded: url_helper
INFO - 2026-08-19 03:35:21 --> Helper loaded: form_helper
INFO - 2026-08-19 03:35:21 --> Helper loaded: html_helper
INFO - 2026-08-19 03:35:21 --> Helper loaded: file_helper
INFO - 2026-08-19 03:35:21 --> Helper loaded: email_helper
INFO - 2026-08-19 03:35:21 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:35:21 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:35:21 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:35:21 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:35:21 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:35:21 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:35:21 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:35:21 --> Database Driver Class Initialized
INFO - 2026-08-19 03:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:35:22 --> Upload Class Initialized
DEBUG - 2026-08-19 03:35:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:35:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:35:22 --> Encryption Class Initialized
INFO - 2026-08-19 03:35:22 --> Form Validation Class Initialized
INFO - 2026-08-19 03:35:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:35:22 --> Pagination Class Initialized
INFO - 2026-08-19 03:35:22 --> Email Class Initialized
INFO - 2026-08-19 03:35:22 --> Controller Class Initialized
DEBUG - 2026-08-19 03:35:22 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:35:22 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:35:22 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:35:22 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:35:22 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:35:48 --> Config Class Initialized
INFO - 2026-08-19 03:35:48 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:35:48 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:35:48 --> Utf8 Class Initialized
INFO - 2026-08-19 03:35:48 --> URI Class Initialized
INFO - 2026-08-19 03:35:48 --> Router Class Initialized
INFO - 2026-08-19 03:35:48 --> Output Class Initialized
INFO - 2026-08-19 03:35:48 --> Security Class Initialized
DEBUG - 2026-08-19 03:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:35:48 --> CSRF cookie sent
INFO - 2026-08-19 03:35:48 --> Input Class Initialized
INFO - 2026-08-19 03:35:48 --> Language Class Initialized
INFO - 2026-08-19 03:35:48 --> Language Class Initialized
INFO - 2026-08-19 03:35:48 --> Config Class Initialized
INFO - 2026-08-19 03:35:48 --> Loader Class Initialized
INFO - 2026-08-19 03:35:48 --> Helper loaded: url_helper
INFO - 2026-08-19 03:35:48 --> Helper loaded: form_helper
INFO - 2026-08-19 03:35:48 --> Helper loaded: html_helper
INFO - 2026-08-19 03:35:48 --> Helper loaded: file_helper
INFO - 2026-08-19 03:35:48 --> Helper loaded: email_helper
INFO - 2026-08-19 03:35:48 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:35:48 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:35:48 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:35:48 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:35:48 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:35:48 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:35:48 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:35:48 --> Database Driver Class Initialized
INFO - 2026-08-19 03:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:35:49 --> Upload Class Initialized
DEBUG - 2026-08-19 03:35:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:35:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:35:49 --> Encryption Class Initialized
INFO - 2026-08-19 03:35:49 --> Form Validation Class Initialized
INFO - 2026-08-19 03:35:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:35:49 --> Pagination Class Initialized
INFO - 2026-08-19 03:35:49 --> Email Class Initialized
INFO - 2026-08-19 03:35:49 --> Controller Class Initialized
DEBUG - 2026-08-19 03:35:49 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:35:49 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:35:49 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:35:49 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:35:49 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:36:21 --> Config Class Initialized
INFO - 2026-08-19 03:36:21 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:36:21 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:36:21 --> Utf8 Class Initialized
INFO - 2026-08-19 03:36:21 --> URI Class Initialized
INFO - 2026-08-19 03:36:21 --> Router Class Initialized
INFO - 2026-08-19 03:36:21 --> Output Class Initialized
INFO - 2026-08-19 03:36:21 --> Security Class Initialized
DEBUG - 2026-08-19 03:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:36:21 --> CSRF cookie sent
INFO - 2026-08-19 03:36:21 --> Input Class Initialized
INFO - 2026-08-19 03:36:21 --> Language Class Initialized
INFO - 2026-08-19 03:36:21 --> Language Class Initialized
INFO - 2026-08-19 03:36:21 --> Config Class Initialized
INFO - 2026-08-19 03:36:21 --> Loader Class Initialized
INFO - 2026-08-19 03:36:21 --> Helper loaded: url_helper
INFO - 2026-08-19 03:36:21 --> Helper loaded: form_helper
INFO - 2026-08-19 03:36:21 --> Helper loaded: html_helper
INFO - 2026-08-19 03:36:21 --> Helper loaded: file_helper
INFO - 2026-08-19 03:36:21 --> Helper loaded: email_helper
INFO - 2026-08-19 03:36:21 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:36:21 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:36:21 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:36:21 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:36:21 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:36:21 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:36:21 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:36:21 --> Database Driver Class Initialized
INFO - 2026-08-19 03:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:36:22 --> Upload Class Initialized
DEBUG - 2026-08-19 03:36:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:36:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:36:22 --> Encryption Class Initialized
INFO - 2026-08-19 03:36:22 --> Form Validation Class Initialized
INFO - 2026-08-19 03:36:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:36:22 --> Pagination Class Initialized
INFO - 2026-08-19 03:36:22 --> Email Class Initialized
INFO - 2026-08-19 03:36:22 --> Controller Class Initialized
DEBUG - 2026-08-19 03:36:22 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:36:22 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:36:22 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:36:22 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:36:22 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:36:49 --> Config Class Initialized
INFO - 2026-08-19 03:36:49 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:36:49 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:36:49 --> Utf8 Class Initialized
INFO - 2026-08-19 03:36:49 --> URI Class Initialized
INFO - 2026-08-19 03:36:49 --> Router Class Initialized
INFO - 2026-08-19 03:36:49 --> Output Class Initialized
INFO - 2026-08-19 03:36:49 --> Security Class Initialized
DEBUG - 2026-08-19 03:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:36:49 --> CSRF cookie sent
INFO - 2026-08-19 03:36:49 --> Input Class Initialized
INFO - 2026-08-19 03:36:49 --> Language Class Initialized
INFO - 2026-08-19 03:36:49 --> Language Class Initialized
INFO - 2026-08-19 03:36:49 --> Config Class Initialized
INFO - 2026-08-19 03:36:49 --> Loader Class Initialized
INFO - 2026-08-19 03:36:49 --> Helper loaded: url_helper
INFO - 2026-08-19 03:36:49 --> Helper loaded: form_helper
INFO - 2026-08-19 03:36:49 --> Helper loaded: html_helper
INFO - 2026-08-19 03:36:49 --> Helper loaded: file_helper
INFO - 2026-08-19 03:36:49 --> Helper loaded: email_helper
INFO - 2026-08-19 03:36:49 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:36:49 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:36:49 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:36:49 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:36:49 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:36:49 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:36:49 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:36:49 --> Database Driver Class Initialized
INFO - 2026-08-19 03:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:36:51 --> Upload Class Initialized
DEBUG - 2026-08-19 03:36:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:36:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:36:51 --> Encryption Class Initialized
INFO - 2026-08-19 03:36:51 --> Form Validation Class Initialized
INFO - 2026-08-19 03:36:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:36:51 --> Pagination Class Initialized
INFO - 2026-08-19 03:36:51 --> Email Class Initialized
INFO - 2026-08-19 03:36:51 --> Controller Class Initialized
DEBUG - 2026-08-19 03:36:51 --> Notifications MX_Controller Initialized
INFO - 2026-08-19 03:36:51 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:36:51 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:36:51 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:36:51 --> Model "Notification_model" initialized
INFO - 2026-08-19 03:47:38 --> Config Class Initialized
INFO - 2026-08-19 03:47:38 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:47:38 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:47:38 --> Utf8 Class Initialized
INFO - 2026-08-19 03:47:38 --> URI Class Initialized
INFO - 2026-08-19 03:47:38 --> Router Class Initialized
INFO - 2026-08-19 03:47:38 --> Output Class Initialized
INFO - 2026-08-19 03:47:38 --> Security Class Initialized
DEBUG - 2026-08-19 03:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:47:38 --> CSRF cookie sent
INFO - 2026-08-19 03:47:38 --> Input Class Initialized
INFO - 2026-08-19 03:47:38 --> Language Class Initialized
INFO - 2026-08-19 03:47:38 --> Language Class Initialized
INFO - 2026-08-19 03:47:38 --> Config Class Initialized
INFO - 2026-08-19 03:47:38 --> Loader Class Initialized
INFO - 2026-08-19 03:47:38 --> Helper loaded: url_helper
INFO - 2026-08-19 03:47:38 --> Helper loaded: form_helper
INFO - 2026-08-19 03:47:38 --> Helper loaded: html_helper
INFO - 2026-08-19 03:47:38 --> Helper loaded: file_helper
INFO - 2026-08-19 03:47:38 --> Helper loaded: email_helper
INFO - 2026-08-19 03:47:38 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:47:38 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:47:38 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:47:38 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:47:38 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:47:38 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:47:38 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:47:38 --> Database Driver Class Initialized
INFO - 2026-08-19 03:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:47:39 --> Upload Class Initialized
DEBUG - 2026-08-19 03:47:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:47:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:47:39 --> Encryption Class Initialized
INFO - 2026-08-19 03:47:39 --> Form Validation Class Initialized
INFO - 2026-08-19 03:47:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:47:39 --> Pagination Class Initialized
INFO - 2026-08-19 03:47:39 --> Email Class Initialized
INFO - 2026-08-19 03:47:39 --> Controller Class Initialized
DEBUG - 2026-08-19 03:47:39 --> Dashboard MX_Controller Initialized
INFO - 2026-08-19 03:47:39 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:47:39 --> Model "Adminauth_model" initialized
INFO - 2026-08-19 03:47:39 --> Config Class Initialized
INFO - 2026-08-19 03:47:39 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:47:39 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:47:39 --> Utf8 Class Initialized
INFO - 2026-08-19 03:47:39 --> URI Class Initialized
INFO - 2026-08-19 03:47:39 --> Router Class Initialized
INFO - 2026-08-19 03:47:39 --> Output Class Initialized
INFO - 2026-08-19 03:47:39 --> Security Class Initialized
DEBUG - 2026-08-19 03:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:47:39 --> CSRF cookie sent
INFO - 2026-08-19 03:47:39 --> Input Class Initialized
INFO - 2026-08-19 03:47:39 --> Language Class Initialized
INFO - 2026-08-19 03:47:39 --> Language Class Initialized
INFO - 2026-08-19 03:47:39 --> Config Class Initialized
INFO - 2026-08-19 03:47:39 --> Loader Class Initialized
INFO - 2026-08-19 03:47:39 --> Helper loaded: url_helper
INFO - 2026-08-19 03:47:39 --> Helper loaded: form_helper
INFO - 2026-08-19 03:47:39 --> Helper loaded: html_helper
INFO - 2026-08-19 03:47:39 --> Helper loaded: file_helper
INFO - 2026-08-19 03:47:39 --> Helper loaded: email_helper
INFO - 2026-08-19 03:47:39 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:47:39 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:47:39 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:47:40 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:47:40 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:47:40 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:47:40 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:47:40 --> Database Driver Class Initialized
INFO - 2026-08-19 03:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:47:41 --> Upload Class Initialized
DEBUG - 2026-08-19 03:47:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:47:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:47:41 --> Encryption Class Initialized
INFO - 2026-08-19 03:47:41 --> Form Validation Class Initialized
INFO - 2026-08-19 03:47:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:47:41 --> Pagination Class Initialized
INFO - 2026-08-19 03:47:41 --> Email Class Initialized
INFO - 2026-08-19 03:47:41 --> Controller Class Initialized
DEBUG - 2026-08-19 03:47:41 --> Authenticate MX_Controller Initialized
INFO - 2026-08-19 03:47:41 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:47:41 --> Model "Adminauth_model" initialized
INFO - 2026-08-19 03:47:41 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-19 03:47:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-08-19 03:47:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-08-19 03:47:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-08-19 03:47:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-08-19 03:47:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-08-19 03:47:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-08-19 03:47:41 --> Final output sent to browser
DEBUG - 2026-08-19 03:47:41 --> Total execution time: 2.0085
INFO - 2026-08-19 03:47:47 --> Config Class Initialized
INFO - 2026-08-19 03:47:47 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:47:47 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:47:47 --> Utf8 Class Initialized
INFO - 2026-08-19 03:47:47 --> URI Class Initialized
INFO - 2026-08-19 03:47:47 --> Router Class Initialized
INFO - 2026-08-19 03:47:47 --> Output Class Initialized
INFO - 2026-08-19 03:47:47 --> Security Class Initialized
DEBUG - 2026-08-19 03:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:47:47 --> CSRF cookie sent
INFO - 2026-08-19 03:47:47 --> Input Class Initialized
INFO - 2026-08-19 03:47:47 --> Language Class Initialized
INFO - 2026-08-19 03:47:47 --> Language Class Initialized
INFO - 2026-08-19 03:47:47 --> Config Class Initialized
INFO - 2026-08-19 03:47:47 --> Loader Class Initialized
INFO - 2026-08-19 03:47:47 --> Helper loaded: url_helper
INFO - 2026-08-19 03:47:47 --> Helper loaded: form_helper
INFO - 2026-08-19 03:47:47 --> Helper loaded: html_helper
INFO - 2026-08-19 03:47:47 --> Helper loaded: file_helper
INFO - 2026-08-19 03:47:47 --> Helper loaded: email_helper
INFO - 2026-08-19 03:47:47 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:47:47 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:47:47 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:47:47 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:47:47 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:47:47 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:47:47 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:47:47 --> Database Driver Class Initialized
INFO - 2026-08-19 03:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:47:49 --> Upload Class Initialized
DEBUG - 2026-08-19 03:47:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:47:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:47:49 --> Encryption Class Initialized
INFO - 2026-08-19 03:47:49 --> Form Validation Class Initialized
INFO - 2026-08-19 03:47:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:47:49 --> Pagination Class Initialized
INFO - 2026-08-19 03:47:49 --> Email Class Initialized
INFO - 2026-08-19 03:47:49 --> Controller Class Initialized
DEBUG - 2026-08-19 03:47:49 --> Authenticate MX_Controller Initialized
INFO - 2026-08-19 03:47:49 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:47:49 --> Model "Adminauth_model" initialized
INFO - 2026-08-19 03:47:49 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-19 03:47:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-08-19 03:47:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-08-19 03:47:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-08-19 03:47:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-08-19 03:47:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-08-19 03:47:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-08-19 03:47:49 --> Final output sent to browser
DEBUG - 2026-08-19 03:47:49 --> Total execution time: 2.5912
INFO - 2026-08-19 03:49:39 --> Config Class Initialized
INFO - 2026-08-19 03:49:39 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:49:39 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:49:39 --> Utf8 Class Initialized
INFO - 2026-08-19 03:49:39 --> URI Class Initialized
INFO - 2026-08-19 03:49:39 --> Router Class Initialized
INFO - 2026-08-19 03:49:39 --> Output Class Initialized
INFO - 2026-08-19 03:49:39 --> Security Class Initialized
DEBUG - 2026-08-19 03:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:49:39 --> CSRF cookie sent
INFO - 2026-08-19 03:49:39 --> Input Class Initialized
INFO - 2026-08-19 03:49:39 --> Language Class Initialized
INFO - 2026-08-19 03:49:39 --> Language Class Initialized
INFO - 2026-08-19 03:49:39 --> Config Class Initialized
INFO - 2026-08-19 03:49:39 --> Loader Class Initialized
INFO - 2026-08-19 03:49:39 --> Helper loaded: url_helper
INFO - 2026-08-19 03:49:39 --> Helper loaded: form_helper
INFO - 2026-08-19 03:49:39 --> Helper loaded: html_helper
INFO - 2026-08-19 03:49:39 --> Helper loaded: file_helper
INFO - 2026-08-19 03:49:39 --> Helper loaded: email_helper
INFO - 2026-08-19 03:49:39 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:49:39 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:49:39 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:49:39 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:49:39 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:49:39 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:49:39 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:49:39 --> Database Driver Class Initialized
INFO - 2026-08-19 03:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:49:41 --> Upload Class Initialized
DEBUG - 2026-08-19 03:49:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:49:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:49:41 --> Encryption Class Initialized
INFO - 2026-08-19 03:49:41 --> Form Validation Class Initialized
INFO - 2026-08-19 03:49:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:49:41 --> Pagination Class Initialized
INFO - 2026-08-19 03:49:41 --> Email Class Initialized
INFO - 2026-08-19 03:49:41 --> Controller Class Initialized
DEBUG - 2026-08-19 03:49:41 --> Authenticate MX_Controller Initialized
INFO - 2026-08-19 03:49:41 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:49:41 --> Model "Adminauth_model" initialized
INFO - 2026-08-19 03:49:41 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-19 03:49:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-08-19 03:49:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-08-19 03:49:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-08-19 03:49:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-08-19 03:49:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-08-19 03:49:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-08-19 03:49:42 --> Final output sent to browser
DEBUG - 2026-08-19 03:49:42 --> Total execution time: 2.3969
INFO - 2026-08-19 03:50:33 --> Config Class Initialized
INFO - 2026-08-19 03:50:33 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:50:33 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:50:33 --> Utf8 Class Initialized
INFO - 2026-08-19 03:50:33 --> URI Class Initialized
DEBUG - 2026-08-19 03:50:33 --> No URI present. Default controller set.
INFO - 2026-08-19 03:50:33 --> Router Class Initialized
INFO - 2026-08-19 03:50:33 --> Output Class Initialized
INFO - 2026-08-19 03:50:33 --> Security Class Initialized
DEBUG - 2026-08-19 03:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:50:33 --> CSRF cookie sent
INFO - 2026-08-19 03:50:33 --> Input Class Initialized
INFO - 2026-08-19 03:50:33 --> Language Class Initialized
INFO - 2026-08-19 03:50:33 --> Language Class Initialized
INFO - 2026-08-19 03:50:33 --> Config Class Initialized
INFO - 2026-08-19 03:50:33 --> Loader Class Initialized
INFO - 2026-08-19 03:50:33 --> Helper loaded: url_helper
INFO - 2026-08-19 03:50:33 --> Helper loaded: form_helper
INFO - 2026-08-19 03:50:33 --> Helper loaded: html_helper
INFO - 2026-08-19 03:50:33 --> Helper loaded: file_helper
INFO - 2026-08-19 03:50:33 --> Helper loaded: email_helper
INFO - 2026-08-19 03:50:33 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:50:33 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:50:33 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:50:33 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:50:33 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:50:33 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:50:33 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:50:33 --> Database Driver Class Initialized
INFO - 2026-08-19 03:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:50:34 --> Upload Class Initialized
DEBUG - 2026-08-19 03:50:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:50:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:50:34 --> Encryption Class Initialized
INFO - 2026-08-19 03:50:34 --> Form Validation Class Initialized
INFO - 2026-08-19 03:50:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:50:34 --> Pagination Class Initialized
INFO - 2026-08-19 03:50:34 --> Email Class Initialized
INFO - 2026-08-19 03:50:34 --> Controller Class Initialized
DEBUG - 2026-08-19 03:50:34 --> Home MX_Controller Initialized
INFO - 2026-08-19 03:50:34 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:50:34 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:50:34 --> Model "Cart_model" initialized
DEBUG - 2026-08-19 03:50:35 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:50:35 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:50:36 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:50:36 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/home/views/home_view.php
INFO - 2026-08-19 03:50:36 --> Final output sent to browser
DEBUG - 2026-08-19 03:50:36 --> Total execution time: 2.9649
INFO - 2026-08-19 03:50:36 --> Config Class Initialized
INFO - 2026-08-19 03:50:36 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:50:36 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:50:36 --> Utf8 Class Initialized
INFO - 2026-08-19 03:50:36 --> URI Class Initialized
INFO - 2026-08-19 03:50:36 --> Router Class Initialized
INFO - 2026-08-19 03:50:36 --> Output Class Initialized
INFO - 2026-08-19 03:50:36 --> Security Class Initialized
DEBUG - 2026-08-19 03:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:50:36 --> CSRF cookie sent
INFO - 2026-08-19 03:50:36 --> Input Class Initialized
INFO - 2026-08-19 03:50:36 --> Language Class Initialized
INFO - 2026-08-19 03:50:36 --> Language Class Initialized
INFO - 2026-08-19 03:50:36 --> Config Class Initialized
INFO - 2026-08-19 03:50:36 --> Loader Class Initialized
INFO - 2026-08-19 03:50:36 --> Helper loaded: url_helper
INFO - 2026-08-19 03:50:36 --> Helper loaded: form_helper
INFO - 2026-08-19 03:50:36 --> Helper loaded: html_helper
INFO - 2026-08-19 03:50:36 --> Helper loaded: file_helper
INFO - 2026-08-19 03:50:36 --> Helper loaded: email_helper
INFO - 2026-08-19 03:50:36 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:50:36 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:50:36 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:50:36 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:50:36 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:50:36 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:50:36 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:50:36 --> Database Driver Class Initialized
INFO - 2026-08-19 03:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:50:38 --> Upload Class Initialized
DEBUG - 2026-08-19 03:50:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:50:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:50:38 --> Encryption Class Initialized
INFO - 2026-08-19 03:50:38 --> Form Validation Class Initialized
INFO - 2026-08-19 03:50:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:50:38 --> Pagination Class Initialized
INFO - 2026-08-19 03:50:38 --> Email Class Initialized
INFO - 2026-08-19 03:50:38 --> Controller Class Initialized
DEBUG - 2026-08-19 03:50:38 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:50:38 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:50:38 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:50:38 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:50:38 --> Model "Common_model" initialized
INFO - 2026-08-19 03:50:38 --> Model "Order_model" initialized
INFO - 2026-08-19 03:50:38 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:50:38 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:50:38 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:50:38 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:50:38 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:50:38 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:50:38 --> Final output sent to browser
DEBUG - 2026-08-19 03:50:38 --> Total execution time: 1.9002
INFO - 2026-08-19 03:50:41 --> Config Class Initialized
INFO - 2026-08-19 03:50:41 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:50:41 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:50:41 --> Utf8 Class Initialized
INFO - 2026-08-19 03:50:41 --> URI Class Initialized
INFO - 2026-08-19 03:50:41 --> Router Class Initialized
INFO - 2026-08-19 03:50:41 --> Output Class Initialized
INFO - 2026-08-19 03:50:41 --> Security Class Initialized
DEBUG - 2026-08-19 03:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:50:41 --> CSRF cookie sent
INFO - 2026-08-19 03:50:41 --> Input Class Initialized
INFO - 2026-08-19 03:50:41 --> Language Class Initialized
INFO - 2026-08-19 03:50:41 --> Language Class Initialized
INFO - 2026-08-19 03:50:41 --> Config Class Initialized
INFO - 2026-08-19 03:50:41 --> Loader Class Initialized
INFO - 2026-08-19 03:50:41 --> Helper loaded: url_helper
INFO - 2026-08-19 03:50:41 --> Helper loaded: form_helper
INFO - 2026-08-19 03:50:41 --> Helper loaded: html_helper
INFO - 2026-08-19 03:50:41 --> Helper loaded: file_helper
INFO - 2026-08-19 03:50:41 --> Helper loaded: email_helper
INFO - 2026-08-19 03:50:41 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:50:41 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:50:41 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:50:41 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:50:41 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:50:41 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:50:41 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:50:41 --> Database Driver Class Initialized
INFO - 2026-08-19 03:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:50:43 --> Upload Class Initialized
DEBUG - 2026-08-19 03:50:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:50:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:50:43 --> Encryption Class Initialized
INFO - 2026-08-19 03:50:43 --> Form Validation Class Initialized
INFO - 2026-08-19 03:50:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:50:43 --> Pagination Class Initialized
INFO - 2026-08-19 03:50:43 --> Email Class Initialized
INFO - 2026-08-19 03:50:43 --> Controller Class Initialized
DEBUG - 2026-08-19 03:50:43 --> Auth MX_Controller Initialized
INFO - 2026-08-19 03:50:43 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:50:43 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:50:43 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:50:43 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-19 03:50:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-19 03:50:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-19 03:50:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-19 03:50:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-08-19 03:50:44 --> Final output sent to browser
DEBUG - 2026-08-19 03:50:44 --> Total execution time: 2.7900
INFO - 2026-08-19 03:50:44 --> Config Class Initialized
INFO - 2026-08-19 03:50:44 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:50:44 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:50:44 --> Utf8 Class Initialized
INFO - 2026-08-19 03:50:44 --> URI Class Initialized
INFO - 2026-08-19 03:50:44 --> Router Class Initialized
INFO - 2026-08-19 03:50:44 --> Output Class Initialized
INFO - 2026-08-19 03:50:44 --> Security Class Initialized
DEBUG - 2026-08-19 03:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:50:44 --> CSRF cookie sent
INFO - 2026-08-19 03:50:44 --> Input Class Initialized
INFO - 2026-08-19 03:50:44 --> Language Class Initialized
INFO - 2026-08-19 03:50:44 --> Language Class Initialized
INFO - 2026-08-19 03:50:44 --> Config Class Initialized
INFO - 2026-08-19 03:50:44 --> Loader Class Initialized
INFO - 2026-08-19 03:50:44 --> Helper loaded: url_helper
INFO - 2026-08-19 03:50:44 --> Helper loaded: form_helper
INFO - 2026-08-19 03:50:44 --> Helper loaded: html_helper
INFO - 2026-08-19 03:50:44 --> Helper loaded: file_helper
INFO - 2026-08-19 03:50:44 --> Helper loaded: email_helper
INFO - 2026-08-19 03:50:44 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:50:44 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:50:44 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:50:44 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:50:44 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:50:44 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:50:44 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:50:44 --> Database Driver Class Initialized
INFO - 2026-08-19 03:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:50:46 --> Upload Class Initialized
DEBUG - 2026-08-19 03:50:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:50:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:50:46 --> Encryption Class Initialized
INFO - 2026-08-19 03:50:46 --> Form Validation Class Initialized
INFO - 2026-08-19 03:50:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:50:46 --> Pagination Class Initialized
INFO - 2026-08-19 03:50:46 --> Email Class Initialized
INFO - 2026-08-19 03:50:46 --> Controller Class Initialized
DEBUG - 2026-08-19 03:50:46 --> Cart MX_Controller Initialized
INFO - 2026-08-19 03:50:46 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:50:46 --> Model "Auth_model" initialized
INFO - 2026-08-19 03:50:46 --> Model "Cart_model" initialized
INFO - 2026-08-19 03:50:46 --> Model "Common_model" initialized
INFO - 2026-08-19 03:50:46 --> Model "Order_model" initialized
INFO - 2026-08-19 03:50:46 --> Model "Appsetting_model" initialized
INFO - 2026-08-19 03:50:46 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-19 03:50:46 --> Model "Promocode_model" initialized
DEBUG - 2026-08-19 03:50:46 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-19 03:50:46 --> Model "Plan_model" initialized
INFO - 2026-08-19 03:50:46 --> Model "Orderlicense_model" initialized
INFO - 2026-08-19 03:50:46 --> Final output sent to browser
DEBUG - 2026-08-19 03:50:46 --> Total execution time: 2.0669
INFO - 2026-08-19 03:50:53 --> Config Class Initialized
INFO - 2026-08-19 03:50:53 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:50:53 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:50:53 --> Utf8 Class Initialized
INFO - 2026-08-19 03:50:53 --> URI Class Initialized
INFO - 2026-08-19 03:50:53 --> Router Class Initialized
INFO - 2026-08-19 03:50:53 --> Output Class Initialized
INFO - 2026-08-19 03:50:53 --> Security Class Initialized
DEBUG - 2026-08-19 03:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:50:53 --> CSRF cookie sent
INFO - 2026-08-19 03:50:53 --> Input Class Initialized
INFO - 2026-08-19 03:50:53 --> Language Class Initialized
INFO - 2026-08-19 03:50:53 --> Language Class Initialized
INFO - 2026-08-19 03:50:53 --> Config Class Initialized
INFO - 2026-08-19 03:50:53 --> Loader Class Initialized
INFO - 2026-08-19 03:50:53 --> Helper loaded: url_helper
INFO - 2026-08-19 03:50:53 --> Helper loaded: form_helper
INFO - 2026-08-19 03:50:53 --> Helper loaded: html_helper
INFO - 2026-08-19 03:50:53 --> Helper loaded: file_helper
INFO - 2026-08-19 03:50:53 --> Helper loaded: email_helper
INFO - 2026-08-19 03:50:53 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:50:53 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:50:53 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:50:53 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:50:53 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:50:53 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:50:53 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:50:53 --> Database Driver Class Initialized
INFO - 2026-08-19 03:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:50:55 --> Upload Class Initialized
DEBUG - 2026-08-19 03:50:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:50:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:50:55 --> Encryption Class Initialized
INFO - 2026-08-19 03:50:55 --> Form Validation Class Initialized
INFO - 2026-08-19 03:50:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:50:55 --> Pagination Class Initialized
INFO - 2026-08-19 03:50:55 --> Email Class Initialized
INFO - 2026-08-19 03:50:55 --> Controller Class Initialized
DEBUG - 2026-08-19 03:50:55 --> Dashboard MX_Controller Initialized
INFO - 2026-08-19 03:50:55 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:50:55 --> Model "Adminauth_model" initialized
INFO - 2026-08-19 03:50:55 --> Config Class Initialized
INFO - 2026-08-19 03:50:55 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:50:55 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:50:55 --> Utf8 Class Initialized
INFO - 2026-08-19 03:50:55 --> URI Class Initialized
INFO - 2026-08-19 03:50:55 --> Router Class Initialized
INFO - 2026-08-19 03:50:55 --> Output Class Initialized
INFO - 2026-08-19 03:50:55 --> Security Class Initialized
DEBUG - 2026-08-19 03:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:50:55 --> CSRF cookie sent
INFO - 2026-08-19 03:50:55 --> Input Class Initialized
INFO - 2026-08-19 03:50:55 --> Language Class Initialized
INFO - 2026-08-19 03:50:55 --> Language Class Initialized
INFO - 2026-08-19 03:50:55 --> Config Class Initialized
INFO - 2026-08-19 03:50:55 --> Loader Class Initialized
INFO - 2026-08-19 03:50:55 --> Helper loaded: url_helper
INFO - 2026-08-19 03:50:55 --> Helper loaded: form_helper
INFO - 2026-08-19 03:50:55 --> Helper loaded: html_helper
INFO - 2026-08-19 03:50:55 --> Helper loaded: file_helper
INFO - 2026-08-19 03:50:55 --> Helper loaded: email_helper
INFO - 2026-08-19 03:50:55 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:50:55 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:50:55 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:50:55 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:50:55 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:50:55 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:50:55 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:50:55 --> Database Driver Class Initialized
INFO - 2026-08-19 03:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:50:56 --> Upload Class Initialized
DEBUG - 2026-08-19 03:50:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:50:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:50:56 --> Encryption Class Initialized
INFO - 2026-08-19 03:50:56 --> Form Validation Class Initialized
INFO - 2026-08-19 03:50:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:50:56 --> Pagination Class Initialized
INFO - 2026-08-19 03:50:56 --> Email Class Initialized
INFO - 2026-08-19 03:50:56 --> Controller Class Initialized
DEBUG - 2026-08-19 03:50:56 --> Authenticate MX_Controller Initialized
INFO - 2026-08-19 03:50:56 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:50:56 --> Model "Adminauth_model" initialized
INFO - 2026-08-19 03:50:56 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-19 03:50:57 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-08-19 03:50:57 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-08-19 03:50:57 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-08-19 03:50:57 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-08-19 03:50:57 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-08-19 03:50:57 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-08-19 03:50:57 --> Final output sent to browser
DEBUG - 2026-08-19 03:50:57 --> Total execution time: 2.1160
INFO - 2026-08-19 03:51:10 --> Config Class Initialized
INFO - 2026-08-19 03:51:10 --> Config Class Initialized
INFO - 2026-08-19 03:51:10 --> Config Class Initialized
INFO - 2026-08-19 03:51:10 --> Hooks Class Initialized
INFO - 2026-08-19 03:51:10 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:51:10 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:51:10 --> Utf8 Class Initialized
DEBUG - 2026-08-19 03:51:10 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:51:10 --> Config Class Initialized
INFO - 2026-08-19 03:51:10 --> Utf8 Class Initialized
INFO - 2026-08-19 03:51:10 --> Hooks Class Initialized
INFO - 2026-08-19 03:51:10 --> URI Class Initialized
INFO - 2026-08-19 03:51:10 --> URI Class Initialized
DEBUG - 2026-08-19 03:51:10 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:51:10 --> Utf8 Class Initialized
INFO - 2026-08-19 03:51:10 --> Router Class Initialized
INFO - 2026-08-19 03:51:10 --> Config Class Initialized
INFO - 2026-08-19 03:51:10 --> Hooks Class Initialized
INFO - 2026-08-19 03:51:10 --> Router Class Initialized
INFO - 2026-08-19 03:51:10 --> Config Class Initialized
INFO - 2026-08-19 03:51:10 --> Hooks Class Initialized
INFO - 2026-08-19 03:51:10 --> Output Class Initialized
INFO - 2026-08-19 03:51:10 --> URI Class Initialized
DEBUG - 2026-08-19 03:51:10 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:51:10 --> Utf8 Class Initialized
INFO - 2026-08-19 03:51:10 --> Output Class Initialized
INFO - 2026-08-19 03:51:10 --> URI Class Initialized
INFO - 2026-08-19 03:51:10 --> Security Class Initialized
DEBUG - 2026-08-19 03:51:10 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:51:10 --> Security Class Initialized
INFO - 2026-08-19 03:51:10 --> Utf8 Class Initialized
INFO - 2026-08-19 03:51:10 --> Router Class Initialized
DEBUG - 2026-08-19 03:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:51:10 --> CSRF cookie sent
INFO - 2026-08-19 03:51:10 --> Input Class Initialized
INFO - 2026-08-19 03:51:10 --> URI Class Initialized
INFO - 2026-08-19 03:51:10 --> Language Class Initialized
INFO - 2026-08-19 03:51:10 --> Router Class Initialized
DEBUG - 2026-08-19 03:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:51:10 --> CSRF cookie sent
INFO - 2026-08-19 03:51:10 --> Input Class Initialized
INFO - 2026-08-19 03:51:10 --> Language Class Initialized
INFO - 2026-08-19 03:51:10 --> Output Class Initialized
INFO - 2026-08-19 03:51:10 --> Output Class Initialized
INFO - 2026-08-19 03:51:10 --> Language Class Initialized
INFO - 2026-08-19 03:51:10 --> Config Class Initialized
INFO - 2026-08-19 03:51:10 --> Router Class Initialized
INFO - 2026-08-19 03:51:10 --> Language Class Initialized
INFO - 2026-08-19 03:51:10 --> Hooks Class Initialized
INFO - 2026-08-19 03:51:10 --> Security Class Initialized
INFO - 2026-08-19 03:51:10 --> Config Class Initialized
INFO - 2026-08-19 03:51:10 --> Output Class Initialized
DEBUG - 2026-08-19 03:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:51:10 --> Security Class Initialized
INFO - 2026-08-19 03:51:10 --> CSRF cookie sent
INFO - 2026-08-19 03:51:10 --> Input Class Initialized
INFO - 2026-08-19 03:51:10 --> Loader Class Initialized
INFO - 2026-08-19 03:51:10 --> Language Class Initialized
INFO - 2026-08-19 03:51:10 --> Security Class Initialized
DEBUG - 2026-08-19 03:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:51:10 --> CSRF cookie sent
INFO - 2026-08-19 03:51:10 --> Input Class Initialized
INFO - 2026-08-19 03:51:10 --> Language Class Initialized
INFO - 2026-08-19 03:51:10 --> Config Class Initialized
INFO - 2026-08-19 03:51:10 --> Language Class Initialized
DEBUG - 2026-08-19 03:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:51:10 --> CSRF cookie sent
INFO - 2026-08-19 03:51:10 --> Input Class Initialized
INFO - 2026-08-19 03:51:10 --> Helper loaded: url_helper
INFO - 2026-08-19 03:51:10 --> Language Class Initialized
INFO - 2026-08-19 03:51:10 --> Language Class Initialized
INFO - 2026-08-19 03:51:10 --> Config Class Initialized
INFO - 2026-08-19 03:51:10 --> Loader Class Initialized
INFO - 2026-08-19 03:51:10 --> Language Class Initialized
INFO - 2026-08-19 03:51:10 --> Config Class Initialized
INFO - 2026-08-19 03:51:10 --> Helper loaded: form_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: url_helper
INFO - 2026-08-19 03:51:10 --> Loader Class Initialized
INFO - 2026-08-19 03:51:10 --> Helper loaded: html_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: form_helper
DEBUG - 2026-08-19 03:51:10 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:51:10 --> Helper loaded: file_helper
INFO - 2026-08-19 03:51:10 --> Utf8 Class Initialized
INFO - 2026-08-19 03:51:10 --> Helper loaded: url_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: email_helper
INFO - 2026-08-19 03:51:10 --> Loader Class Initialized
INFO - 2026-08-19 03:51:10 --> URI Class Initialized
INFO - 2026-08-19 03:51:10 --> Helper loaded: url_helper
INFO - 2026-08-19 03:51:10 --> Loader Class Initialized
INFO - 2026-08-19 03:51:10 --> Helper loaded: form_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: html_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: url_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: form_helper
INFO - 2026-08-19 03:51:10 --> Router Class Initialized
INFO - 2026-08-19 03:51:10 --> Helper loaded: file_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: email_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: html_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: form_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: file_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: email_helper
INFO - 2026-08-19 03:51:10 --> Output Class Initialized
INFO - 2026-08-19 03:51:10 --> Helper loaded: html_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: file_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: email_helper
INFO - 2026-08-19 03:51:10 --> Security Class Initialized
INFO - 2026-08-19 03:51:10 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: html_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: file_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: email_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: directadmin_helper
DEBUG - 2026-08-19 03:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:51:10 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:51:10 --> CSRF cookie sent
INFO - 2026-08-19 03:51:10 --> Input Class Initialized
INFO - 2026-08-19 03:51:10 --> Language Class Initialized
INFO - 2026-08-19 03:51:10 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:51:10 --> Language Class Initialized
INFO - 2026-08-19 03:51:10 --> Config Class Initialized
INFO - 2026-08-19 03:51:10 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:51:10 --> Database Driver Class Initialized
INFO - 2026-08-19 03:51:10 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:51:10 --> Database Driver Class Initialized
INFO - 2026-08-19 03:51:10 --> Loader Class Initialized
INFO - 2026-08-19 03:51:10 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: url_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: form_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: html_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: file_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: email_helper
INFO - 2026-08-19 03:51:10 --> Database Driver Class Initialized
INFO - 2026-08-19 03:51:10 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:51:10 --> Database Driver Class Initialized
INFO - 2026-08-19 03:51:10 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:51:10 --> Database Driver Class Initialized
INFO - 2026-08-19 03:51:10 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:51:10 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:51:10 --> Database Driver Class Initialized
INFO - 2026-08-19 03:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:51:12 --> Upload Class Initialized
DEBUG - 2026-08-19 03:51:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:51:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:51:12 --> Encryption Class Initialized
INFO - 2026-08-19 03:51:12 --> Form Validation Class Initialized
INFO - 2026-08-19 03:51:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:51:12 --> Pagination Class Initialized
INFO - 2026-08-19 03:51:12 --> Email Class Initialized
INFO - 2026-08-19 03:51:12 --> Controller Class Initialized
ERROR - 2026-08-19 03:51:12 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:51:12 --> Upload Class Initialized
DEBUG - 2026-08-19 03:51:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:51:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:51:12 --> Encryption Class Initialized
INFO - 2026-08-19 03:51:12 --> Form Validation Class Initialized
INFO - 2026-08-19 03:51:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:51:12 --> Pagination Class Initialized
INFO - 2026-08-19 03:51:12 --> Config Class Initialized
INFO - 2026-08-19 03:51:12 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:51:12 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:51:12 --> Email Class Initialized
INFO - 2026-08-19 03:51:12 --> Utf8 Class Initialized
INFO - 2026-08-19 03:51:12 --> Controller Class Initialized
ERROR - 2026-08-19 03:51:12 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:51:12 --> URI Class Initialized
INFO - 2026-08-19 03:51:12 --> Router Class Initialized
INFO - 2026-08-19 03:51:12 --> Output Class Initialized
INFO - 2026-08-19 03:51:12 --> Security Class Initialized
DEBUG - 2026-08-19 03:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:51:12 --> CSRF cookie sent
INFO - 2026-08-19 03:51:12 --> Input Class Initialized
INFO - 2026-08-19 03:51:12 --> Language Class Initialized
INFO - 2026-08-19 03:51:12 --> Language Class Initialized
INFO - 2026-08-19 03:51:12 --> Config Class Initialized
INFO - 2026-08-19 03:51:12 --> Loader Class Initialized
INFO - 2026-08-19 03:51:12 --> Helper loaded: url_helper
INFO - 2026-08-19 03:51:12 --> Helper loaded: form_helper
INFO - 2026-08-19 03:51:12 --> Helper loaded: html_helper
INFO - 2026-08-19 03:51:12 --> Helper loaded: file_helper
INFO - 2026-08-19 03:51:12 --> Helper loaded: email_helper
INFO - 2026-08-19 03:51:12 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:51:12 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:51:12 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:51:12 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:51:12 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:51:12 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:51:12 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:51:12 --> Database Driver Class Initialized
INFO - 2026-08-19 03:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:51:12 --> Upload Class Initialized
DEBUG - 2026-08-19 03:51:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:51:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:51:12 --> Encryption Class Initialized
INFO - 2026-08-19 03:51:12 --> Form Validation Class Initialized
INFO - 2026-08-19 03:51:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:51:12 --> Pagination Class Initialized
INFO - 2026-08-19 03:51:12 --> Email Class Initialized
INFO - 2026-08-19 03:51:12 --> Controller Class Initialized
ERROR - 2026-08-19 03:51:12 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:51:13 --> Upload Class Initialized
DEBUG - 2026-08-19 03:51:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:51:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:51:13 --> Encryption Class Initialized
INFO - 2026-08-19 03:51:13 --> Form Validation Class Initialized
INFO - 2026-08-19 03:51:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:51:13 --> Pagination Class Initialized
INFO - 2026-08-19 03:51:13 --> Email Class Initialized
INFO - 2026-08-19 03:51:13 --> Controller Class Initialized
ERROR - 2026-08-19 03:51:13 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:51:13 --> Upload Class Initialized
DEBUG - 2026-08-19 03:51:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:51:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:51:13 --> Encryption Class Initialized
INFO - 2026-08-19 03:51:13 --> Form Validation Class Initialized
INFO - 2026-08-19 03:51:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:51:13 --> Pagination Class Initialized
INFO - 2026-08-19 03:51:13 --> Email Class Initialized
INFO - 2026-08-19 03:51:13 --> Controller Class Initialized
ERROR - 2026-08-19 03:51:13 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:51:13 --> Upload Class Initialized
DEBUG - 2026-08-19 03:51:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:51:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:51:13 --> Encryption Class Initialized
INFO - 2026-08-19 03:51:13 --> Form Validation Class Initialized
INFO - 2026-08-19 03:51:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:51:13 --> Pagination Class Initialized
INFO - 2026-08-19 03:51:13 --> Email Class Initialized
INFO - 2026-08-19 03:51:13 --> Controller Class Initialized
ERROR - 2026-08-19 03:51:13 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:51:14 --> Upload Class Initialized
DEBUG - 2026-08-19 03:51:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:51:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:51:14 --> Encryption Class Initialized
INFO - 2026-08-19 03:51:14 --> Form Validation Class Initialized
INFO - 2026-08-19 03:51:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:51:14 --> Pagination Class Initialized
INFO - 2026-08-19 03:51:14 --> Email Class Initialized
INFO - 2026-08-19 03:51:14 --> Controller Class Initialized
ERROR - 2026-08-19 03:51:14 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:51:51 --> Config Class Initialized
INFO - 2026-08-19 03:51:51 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:51:51 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:51:51 --> Utf8 Class Initialized
INFO - 2026-08-19 03:51:51 --> URI Class Initialized
INFO - 2026-08-19 03:51:51 --> Router Class Initialized
INFO - 2026-08-19 03:51:51 --> Output Class Initialized
INFO - 2026-08-19 03:51:51 --> Security Class Initialized
DEBUG - 2026-08-19 03:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:51:51 --> CSRF cookie sent
INFO - 2026-08-19 03:51:51 --> Input Class Initialized
INFO - 2026-08-19 03:51:51 --> Language Class Initialized
INFO - 2026-08-19 03:51:51 --> Language Class Initialized
INFO - 2026-08-19 03:51:51 --> Config Class Initialized
INFO - 2026-08-19 03:51:51 --> Loader Class Initialized
INFO - 2026-08-19 03:51:51 --> Helper loaded: url_helper
INFO - 2026-08-19 03:51:51 --> Helper loaded: form_helper
INFO - 2026-08-19 03:51:51 --> Helper loaded: html_helper
INFO - 2026-08-19 03:51:51 --> Helper loaded: file_helper
INFO - 2026-08-19 03:51:51 --> Helper loaded: email_helper
INFO - 2026-08-19 03:51:51 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:51:51 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:51:51 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:51:51 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:51:51 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:51:51 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:51:51 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:51:51 --> Database Driver Class Initialized
INFO - 2026-08-19 03:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:51:53 --> Upload Class Initialized
DEBUG - 2026-08-19 03:51:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:51:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:51:53 --> Encryption Class Initialized
INFO - 2026-08-19 03:51:53 --> Form Validation Class Initialized
INFO - 2026-08-19 03:51:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:51:53 --> Pagination Class Initialized
INFO - 2026-08-19 03:51:53 --> Email Class Initialized
INFO - 2026-08-19 03:51:53 --> Controller Class Initialized
DEBUG - 2026-08-19 03:51:53 --> Authenticate MX_Controller Initialized
INFO - 2026-08-19 03:51:53 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:51:53 --> Model "Adminauth_model" initialized
INFO - 2026-08-19 03:51:53 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-19 03:51:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-08-19 03:51:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-08-19 03:51:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-08-19 03:51:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-08-19 03:51:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-08-19 03:51:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-08-19 03:51:53 --> Final output sent to browser
DEBUG - 2026-08-19 03:51:53 --> Total execution time: 2.0478
INFO - 2026-08-19 03:52:05 --> Config Class Initialized
INFO - 2026-08-19 03:52:05 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:52:05 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:52:05 --> Utf8 Class Initialized
INFO - 2026-08-19 03:52:05 --> Config Class Initialized
INFO - 2026-08-19 03:52:05 --> Config Class Initialized
INFO - 2026-08-19 03:52:05 --> Hooks Class Initialized
INFO - 2026-08-19 03:52:05 --> URI Class Initialized
DEBUG - 2026-08-19 03:52:05 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:52:05 --> Utf8 Class Initialized
INFO - 2026-08-19 03:52:05 --> Router Class Initialized
INFO - 2026-08-19 03:52:05 --> URI Class Initialized
INFO - 2026-08-19 03:52:05 --> Output Class Initialized
INFO - 2026-08-19 03:52:05 --> Router Class Initialized
INFO - 2026-08-19 03:52:05 --> Security Class Initialized
DEBUG - 2026-08-19 03:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:52:05 --> CSRF cookie sent
INFO - 2026-08-19 03:52:05 --> Output Class Initialized
INFO - 2026-08-19 03:52:05 --> Input Class Initialized
INFO - 2026-08-19 03:52:05 --> Language Class Initialized
INFO - 2026-08-19 03:52:05 --> Language Class Initialized
INFO - 2026-08-19 03:52:05 --> Security Class Initialized
INFO - 2026-08-19 03:52:05 --> Config Class Initialized
DEBUG - 2026-08-19 03:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:52:05 --> CSRF cookie sent
INFO - 2026-08-19 03:52:05 --> Input Class Initialized
INFO - 2026-08-19 03:52:05 --> Language Class Initialized
INFO - 2026-08-19 03:52:05 --> Loader Class Initialized
INFO - 2026-08-19 03:52:05 --> Language Class Initialized
INFO - 2026-08-19 03:52:05 --> Config Class Initialized
INFO - 2026-08-19 03:52:05 --> Helper loaded: url_helper
INFO - 2026-08-19 03:52:05 --> Config Class Initialized
INFO - 2026-08-19 03:52:05 --> Hooks Class Initialized
INFO - 2026-08-19 03:52:05 --> Helper loaded: form_helper
DEBUG - 2026-08-19 03:52:05 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:52:05 --> Utf8 Class Initialized
INFO - 2026-08-19 03:52:05 --> Helper loaded: html_helper
INFO - 2026-08-19 03:52:05 --> Config Class Initialized
INFO - 2026-08-19 03:52:05 --> Hooks Class Initialized
INFO - 2026-08-19 03:52:05 --> URI Class Initialized
INFO - 2026-08-19 03:52:05 --> Loader Class Initialized
INFO - 2026-08-19 03:52:05 --> Hooks Class Initialized
INFO - 2026-08-19 03:52:05 --> Helper loaded: file_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: email_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: url_helper
INFO - 2026-08-19 03:52:05 --> Router Class Initialized
DEBUG - 2026-08-19 03:52:05 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:52:05 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: form_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: html_helper
INFO - 2026-08-19 03:52:05 --> Output Class Initialized
INFO - 2026-08-19 03:52:05 --> Config Class Initialized
INFO - 2026-08-19 03:52:05 --> Hooks Class Initialized
INFO - 2026-08-19 03:52:05 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: file_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: email_helper
INFO - 2026-08-19 03:52:05 --> Security Class Initialized
INFO - 2026-08-19 03:52:05 --> Helper loaded: plesk_helper
DEBUG - 2026-08-19 03:52:05 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:52:05 --> Utf8 Class Initialized
DEBUG - 2026-08-19 03:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:52:05 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:52:05 --> URI Class Initialized
INFO - 2026-08-19 03:52:05 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:52:05 --> Utf8 Class Initialized
INFO - 2026-08-19 03:52:05 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:52:05 --> URI Class Initialized
INFO - 2026-08-19 03:52:05 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:52:05 --> Router Class Initialized
INFO - 2026-08-19 03:52:05 --> Database Driver Class Initialized
INFO - 2026-08-19 03:52:05 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:52:05 --> Output Class Initialized
INFO - 2026-08-19 03:52:05 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:52:05 --> Security Class Initialized
DEBUG - 2026-08-19 03:52:05 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:52:05 --> Utf8 Class Initialized
INFO - 2026-08-19 03:52:05 --> URI Class Initialized
INFO - 2026-08-19 03:52:05 --> Router Class Initialized
INFO - 2026-08-19 03:52:05 --> Database Driver Class Initialized
INFO - 2026-08-19 03:52:05 --> Output Class Initialized
INFO - 2026-08-19 03:52:05 --> CSRF cookie sent
INFO - 2026-08-19 03:52:05 --> Router Class Initialized
DEBUG - 2026-08-19 03:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:52:05 --> Input Class Initialized
INFO - 2026-08-19 03:52:05 --> CSRF cookie sent
INFO - 2026-08-19 03:52:05 --> Input Class Initialized
INFO - 2026-08-19 03:52:05 --> Language Class Initialized
INFO - 2026-08-19 03:52:05 --> Language Class Initialized
INFO - 2026-08-19 03:52:05 --> Language Class Initialized
INFO - 2026-08-19 03:52:05 --> Config Class Initialized
INFO - 2026-08-19 03:52:05 --> Output Class Initialized
INFO - 2026-08-19 03:52:05 --> Security Class Initialized
INFO - 2026-08-19 03:52:05 --> Loader Class Initialized
DEBUG - 2026-08-19 03:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:52:05 --> CSRF cookie sent
INFO - 2026-08-19 03:52:05 --> Input Class Initialized
INFO - 2026-08-19 03:52:05 --> Language Class Initialized
INFO - 2026-08-19 03:52:05 --> Helper loaded: url_helper
INFO - 2026-08-19 03:52:05 --> Language Class Initialized
INFO - 2026-08-19 03:52:05 --> Config Class Initialized
INFO - 2026-08-19 03:52:05 --> Security Class Initialized
DEBUG - 2026-08-19 03:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:52:05 --> CSRF cookie sent
INFO - 2026-08-19 03:52:05 --> Input Class Initialized
INFO - 2026-08-19 03:52:05 --> Language Class Initialized
INFO - 2026-08-19 03:52:05 --> Loader Class Initialized
INFO - 2026-08-19 03:52:05 --> Language Class Initialized
INFO - 2026-08-19 03:52:05 --> Config Class Initialized
INFO - 2026-08-19 03:52:05 --> Helper loaded: url_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: form_helper
INFO - 2026-08-19 03:52:05 --> Language Class Initialized
INFO - 2026-08-19 03:52:05 --> Config Class Initialized
INFO - 2026-08-19 03:52:05 --> Helper loaded: html_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: file_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: email_helper
INFO - 2026-08-19 03:52:05 --> Loader Class Initialized
INFO - 2026-08-19 03:52:05 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: url_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: form_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: html_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: file_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: email_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: form_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: html_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: file_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: email_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:52:05 --> Loader Class Initialized
INFO - 2026-08-19 03:52:05 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: url_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: form_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: html_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: file_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: email_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:52:05 --> Database Driver Class Initialized
INFO - 2026-08-19 03:52:05 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:52:05 --> Database Driver Class Initialized
INFO - 2026-08-19 03:52:05 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:52:05 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:52:05 --> Database Driver Class Initialized
INFO - 2026-08-19 03:52:05 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:52:05 --> Database Driver Class Initialized
INFO - 2026-08-19 03:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:52:07 --> Upload Class Initialized
DEBUG - 2026-08-19 03:52:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:52:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:52:07 --> Encryption Class Initialized
INFO - 2026-08-19 03:52:07 --> Form Validation Class Initialized
INFO - 2026-08-19 03:52:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:52:07 --> Pagination Class Initialized
INFO - 2026-08-19 03:52:07 --> Email Class Initialized
INFO - 2026-08-19 03:52:07 --> Controller Class Initialized
ERROR - 2026-08-19 03:52:07 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:52:07 --> Upload Class Initialized
DEBUG - 2026-08-19 03:52:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:52:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:52:07 --> Encryption Class Initialized
INFO - 2026-08-19 03:52:07 --> Form Validation Class Initialized
INFO - 2026-08-19 03:52:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:52:07 --> Pagination Class Initialized
INFO - 2026-08-19 03:52:07 --> Email Class Initialized
INFO - 2026-08-19 03:52:07 --> Controller Class Initialized
INFO - 2026-08-19 03:52:07 --> Config Class Initialized
INFO - 2026-08-19 03:52:07 --> Hooks Class Initialized
ERROR - 2026-08-19 03:52:07 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:52:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-08-19 03:52:07 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:52:07 --> Utf8 Class Initialized
INFO - 2026-08-19 03:52:07 --> URI Class Initialized
INFO - 2026-08-19 03:52:07 --> Upload Class Initialized
DEBUG - 2026-08-19 03:52:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:52:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:52:07 --> Encryption Class Initialized
INFO - 2026-08-19 03:52:07 --> Router Class Initialized
INFO - 2026-08-19 03:52:07 --> Output Class Initialized
INFO - 2026-08-19 03:52:07 --> Form Validation Class Initialized
INFO - 2026-08-19 03:52:07 --> Security Class Initialized
INFO - 2026-08-19 03:52:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:52:07 --> Pagination Class Initialized
DEBUG - 2026-08-19 03:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:52:07 --> CSRF cookie sent
INFO - 2026-08-19 03:52:07 --> Input Class Initialized
INFO - 2026-08-19 03:52:07 --> Language Class Initialized
INFO - 2026-08-19 03:52:07 --> Language Class Initialized
INFO - 2026-08-19 03:52:07 --> Config Class Initialized
INFO - 2026-08-19 03:52:07 --> Email Class Initialized
INFO - 2026-08-19 03:52:07 --> Controller Class Initialized
ERROR - 2026-08-19 03:52:07 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:52:07 --> Loader Class Initialized
INFO - 2026-08-19 03:52:07 --> Helper loaded: url_helper
INFO - 2026-08-19 03:52:07 --> Upload Class Initialized
INFO - 2026-08-19 03:52:07 --> Helper loaded: form_helper
DEBUG - 2026-08-19 03:52:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:52:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:52:07 --> Encryption Class Initialized
INFO - 2026-08-19 03:52:07 --> Helper loaded: html_helper
INFO - 2026-08-19 03:52:07 --> Helper loaded: file_helper
INFO - 2026-08-19 03:52:07 --> Helper loaded: email_helper
INFO - 2026-08-19 03:52:07 --> Form Validation Class Initialized
INFO - 2026-08-19 03:52:07 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:52:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:52:07 --> Pagination Class Initialized
INFO - 2026-08-19 03:52:07 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:52:07 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:52:07 --> Email Class Initialized
INFO - 2026-08-19 03:52:07 --> Controller Class Initialized
INFO - 2026-08-19 03:52:07 --> Helper loaded: plesk_helper
ERROR - 2026-08-19 03:52:07 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:52:07 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:52:07 --> Upload Class Initialized
INFO - 2026-08-19 03:52:07 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:52:07 --> Helper loaded: entitlement_helper
DEBUG - 2026-08-19 03:52:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:52:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:52:07 --> Encryption Class Initialized
INFO - 2026-08-19 03:52:07 --> Form Validation Class Initialized
INFO - 2026-08-19 03:52:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:52:07 --> Pagination Class Initialized
INFO - 2026-08-19 03:52:07 --> Database Driver Class Initialized
INFO - 2026-08-19 03:52:07 --> Email Class Initialized
INFO - 2026-08-19 03:52:07 --> Controller Class Initialized
ERROR - 2026-08-19 03:52:07 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:52:07 --> Upload Class Initialized
DEBUG - 2026-08-19 03:52:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:52:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:52:07 --> Encryption Class Initialized
INFO - 2026-08-19 03:52:07 --> Form Validation Class Initialized
INFO - 2026-08-19 03:52:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:52:07 --> Pagination Class Initialized
INFO - 2026-08-19 03:52:07 --> Email Class Initialized
INFO - 2026-08-19 03:52:07 --> Controller Class Initialized
ERROR - 2026-08-19 03:52:07 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:52:09 --> Upload Class Initialized
DEBUG - 2026-08-19 03:52:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:52:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:52:09 --> Encryption Class Initialized
INFO - 2026-08-19 03:52:09 --> Form Validation Class Initialized
INFO - 2026-08-19 03:52:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:52:09 --> Pagination Class Initialized
INFO - 2026-08-19 03:52:09 --> Email Class Initialized
INFO - 2026-08-19 03:52:09 --> Controller Class Initialized
ERROR - 2026-08-19 03:52:09 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:53:40 --> Config Class Initialized
INFO - 2026-08-19 03:53:40 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:53:40 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:53:40 --> Utf8 Class Initialized
INFO - 2026-08-19 03:53:40 --> URI Class Initialized
INFO - 2026-08-19 03:53:40 --> Router Class Initialized
INFO - 2026-08-19 03:53:40 --> Output Class Initialized
INFO - 2026-08-19 03:53:40 --> Security Class Initialized
DEBUG - 2026-08-19 03:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:53:40 --> CSRF cookie sent
INFO - 2026-08-19 03:53:40 --> Input Class Initialized
INFO - 2026-08-19 03:53:40 --> Language Class Initialized
INFO - 2026-08-19 03:53:40 --> Language Class Initialized
INFO - 2026-08-19 03:53:40 --> Config Class Initialized
INFO - 2026-08-19 03:53:40 --> Loader Class Initialized
INFO - 2026-08-19 03:53:40 --> Helper loaded: url_helper
INFO - 2026-08-19 03:53:40 --> Helper loaded: form_helper
INFO - 2026-08-19 03:53:40 --> Helper loaded: html_helper
INFO - 2026-08-19 03:53:40 --> Helper loaded: file_helper
INFO - 2026-08-19 03:53:40 --> Helper loaded: email_helper
INFO - 2026-08-19 03:53:40 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:53:40 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:53:40 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:53:40 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:53:40 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:53:40 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:53:40 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:53:40 --> Database Driver Class Initialized
INFO - 2026-08-19 03:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:53:42 --> Upload Class Initialized
DEBUG - 2026-08-19 03:53:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:53:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:53:42 --> Encryption Class Initialized
INFO - 2026-08-19 03:53:42 --> Form Validation Class Initialized
INFO - 2026-08-19 03:53:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:53:42 --> Pagination Class Initialized
INFO - 2026-08-19 03:53:42 --> Email Class Initialized
INFO - 2026-08-19 03:53:42 --> Controller Class Initialized
DEBUG - 2026-08-19 03:53:42 --> Authenticate MX_Controller Initialized
INFO - 2026-08-19 03:53:42 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:53:42 --> Model "Adminauth_model" initialized
INFO - 2026-08-19 03:53:42 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-19 03:53:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-08-19 03:53:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-08-19 03:53:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-08-19 03:53:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-08-19 03:53:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-08-19 03:53:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-08-19 03:53:42 --> Final output sent to browser
DEBUG - 2026-08-19 03:53:42 --> Total execution time: 2.5800
INFO - 2026-08-19 03:53:42 --> Config Class Initialized
INFO - 2026-08-19 03:53:42 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:53:42 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:53:42 --> Utf8 Class Initialized
INFO - 2026-08-19 03:53:42 --> URI Class Initialized
INFO - 2026-08-19 03:53:42 --> Router Class Initialized
INFO - 2026-08-19 03:53:42 --> Output Class Initialized
INFO - 2026-08-19 03:53:42 --> Security Class Initialized
DEBUG - 2026-08-19 03:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:53:42 --> CSRF cookie sent
INFO - 2026-08-19 03:53:42 --> Input Class Initialized
INFO - 2026-08-19 03:53:42 --> Language Class Initialized
INFO - 2026-08-19 03:53:42 --> Language Class Initialized
INFO - 2026-08-19 03:53:42 --> Config Class Initialized
INFO - 2026-08-19 03:53:42 --> Loader Class Initialized
INFO - 2026-08-19 03:53:42 --> Helper loaded: url_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: form_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: html_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: file_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: email_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:53:42 --> Database Driver Class Initialized
INFO - 2026-08-19 03:53:42 --> Config Class Initialized
INFO - 2026-08-19 03:53:42 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:53:42 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:53:42 --> Utf8 Class Initialized
INFO - 2026-08-19 03:53:42 --> URI Class Initialized
INFO - 2026-08-19 03:53:42 --> Router Class Initialized
INFO - 2026-08-19 03:53:42 --> Output Class Initialized
INFO - 2026-08-19 03:53:42 --> Security Class Initialized
DEBUG - 2026-08-19 03:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:53:42 --> CSRF cookie sent
INFO - 2026-08-19 03:53:42 --> Input Class Initialized
INFO - 2026-08-19 03:53:42 --> Language Class Initialized
INFO - 2026-08-19 03:53:42 --> Language Class Initialized
INFO - 2026-08-19 03:53:42 --> Config Class Initialized
INFO - 2026-08-19 03:53:42 --> Loader Class Initialized
INFO - 2026-08-19 03:53:42 --> Helper loaded: url_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: form_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: html_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: file_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: email_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:53:42 --> Config Class Initialized
INFO - 2026-08-19 03:53:42 --> Hooks Class Initialized
INFO - 2026-08-19 03:53:42 --> Database Driver Class Initialized
DEBUG - 2026-08-19 03:53:42 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:53:42 --> Utf8 Class Initialized
INFO - 2026-08-19 03:53:42 --> URI Class Initialized
INFO - 2026-08-19 03:53:42 --> Router Class Initialized
INFO - 2026-08-19 03:53:42 --> Output Class Initialized
INFO - 2026-08-19 03:53:42 --> Security Class Initialized
DEBUG - 2026-08-19 03:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:53:42 --> CSRF cookie sent
INFO - 2026-08-19 03:53:42 --> Input Class Initialized
INFO - 2026-08-19 03:53:42 --> Language Class Initialized
INFO - 2026-08-19 03:53:42 --> Config Class Initialized
INFO - 2026-08-19 03:53:42 --> Hooks Class Initialized
INFO - 2026-08-19 03:53:42 --> Language Class Initialized
INFO - 2026-08-19 03:53:42 --> Config Class Initialized
DEBUG - 2026-08-19 03:53:42 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:53:42 --> Utf8 Class Initialized
INFO - 2026-08-19 03:53:42 --> Config Class Initialized
INFO - 2026-08-19 03:53:42 --> Hooks Class Initialized
INFO - 2026-08-19 03:53:42 --> URI Class Initialized
DEBUG - 2026-08-19 03:53:42 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:53:42 --> Utf8 Class Initialized
INFO - 2026-08-19 03:53:42 --> Config Class Initialized
INFO - 2026-08-19 03:53:42 --> Hooks Class Initialized
INFO - 2026-08-19 03:53:42 --> URI Class Initialized
INFO - 2026-08-19 03:53:42 --> Loader Class Initialized
INFO - 2026-08-19 03:53:42 --> Helper loaded: url_helper
DEBUG - 2026-08-19 03:53:42 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:53:42 --> Utf8 Class Initialized
INFO - 2026-08-19 03:53:42 --> Router Class Initialized
INFO - 2026-08-19 03:53:42 --> Helper loaded: form_helper
INFO - 2026-08-19 03:53:42 --> Router Class Initialized
INFO - 2026-08-19 03:53:42 --> Helper loaded: html_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: file_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: email_helper
INFO - 2026-08-19 03:53:42 --> Output Class Initialized
INFO - 2026-08-19 03:53:42 --> Output Class Initialized
INFO - 2026-08-19 03:53:42 --> Security Class Initialized
INFO - 2026-08-19 03:53:42 --> Security Class Initialized
INFO - 2026-08-19 03:53:42 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: ssp_helper
DEBUG - 2026-08-19 03:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-08-19 03:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:53:42 --> CSRF cookie sent
INFO - 2026-08-19 03:53:42 --> CSRF cookie sent
INFO - 2026-08-19 03:53:42 --> Input Class Initialized
INFO - 2026-08-19 03:53:42 --> Language Class Initialized
INFO - 2026-08-19 03:53:42 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:53:42 --> URI Class Initialized
INFO - 2026-08-19 03:53:42 --> Language Class Initialized
INFO - 2026-08-19 03:53:42 --> Config Class Initialized
INFO - 2026-08-19 03:53:42 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:53:42 --> Router Class Initialized
INFO - 2026-08-19 03:53:42 --> Loader Class Initialized
INFO - 2026-08-19 03:53:42 --> Output Class Initialized
INFO - 2026-08-19 03:53:42 --> Helper loaded: url_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:53:42 --> Input Class Initialized
INFO - 2026-08-19 03:53:42 --> Language Class Initialized
INFO - 2026-08-19 03:53:42 --> Language Class Initialized
INFO - 2026-08-19 03:53:42 --> Config Class Initialized
INFO - 2026-08-19 03:53:42 --> Security Class Initialized
DEBUG - 2026-08-19 03:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:53:42 --> Loader Class Initialized
INFO - 2026-08-19 03:53:42 --> CSRF cookie sent
INFO - 2026-08-19 03:53:42 --> Input Class Initialized
INFO - 2026-08-19 03:53:42 --> Language Class Initialized
INFO - 2026-08-19 03:53:42 --> Helper loaded: url_helper
INFO - 2026-08-19 03:53:42 --> Database Driver Class Initialized
INFO - 2026-08-19 03:53:42 --> Language Class Initialized
INFO - 2026-08-19 03:53:42 --> Config Class Initialized
INFO - 2026-08-19 03:53:42 --> Helper loaded: form_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: html_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: file_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: email_helper
INFO - 2026-08-19 03:53:42 --> Loader Class Initialized
INFO - 2026-08-19 03:53:42 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: url_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: form_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: html_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: form_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: file_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: email_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: html_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: file_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: email_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:53:42 --> Database Driver Class Initialized
INFO - 2026-08-19 03:53:42 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:53:42 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:53:42 --> Database Driver Class Initialized
INFO - 2026-08-19 03:53:42 --> Database Driver Class Initialized
INFO - 2026-08-19 03:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:53:44 --> Upload Class Initialized
DEBUG - 2026-08-19 03:53:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:53:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:53:44 --> Encryption Class Initialized
INFO - 2026-08-19 03:53:44 --> Form Validation Class Initialized
INFO - 2026-08-19 03:53:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:53:44 --> Pagination Class Initialized
INFO - 2026-08-19 03:53:44 --> Email Class Initialized
INFO - 2026-08-19 03:53:44 --> Controller Class Initialized
ERROR - 2026-08-19 03:53:44 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:53:44 --> Upload Class Initialized
DEBUG - 2026-08-19 03:53:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:53:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:53:44 --> Encryption Class Initialized
INFO - 2026-08-19 03:53:44 --> Form Validation Class Initialized
INFO - 2026-08-19 03:53:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:53:44 --> Pagination Class Initialized
INFO - 2026-08-19 03:53:44 --> Email Class Initialized
INFO - 2026-08-19 03:53:44 --> Controller Class Initialized
ERROR - 2026-08-19 03:53:44 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:53:44 --> Config Class Initialized
INFO - 2026-08-19 03:53:44 --> Hooks Class Initialized
INFO - 2026-08-19 03:53:44 --> Upload Class Initialized
DEBUG - 2026-08-19 03:53:44 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:53:44 --> Utf8 Class Initialized
INFO - 2026-08-19 03:53:44 --> URI Class Initialized
DEBUG - 2026-08-19 03:53:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:53:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:53:44 --> Encryption Class Initialized
INFO - 2026-08-19 03:53:44 --> Router Class Initialized
INFO - 2026-08-19 03:53:44 --> Form Validation Class Initialized
INFO - 2026-08-19 03:53:44 --> Output Class Initialized
INFO - 2026-08-19 03:53:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:53:44 --> Pagination Class Initialized
INFO - 2026-08-19 03:53:44 --> Security Class Initialized
DEBUG - 2026-08-19 03:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:53:44 --> CSRF cookie sent
INFO - 2026-08-19 03:53:44 --> Input Class Initialized
INFO - 2026-08-19 03:53:44 --> Language Class Initialized
INFO - 2026-08-19 03:53:44 --> Email Class Initialized
INFO - 2026-08-19 03:53:44 --> Language Class Initialized
INFO - 2026-08-19 03:53:44 --> Controller Class Initialized
INFO - 2026-08-19 03:53:44 --> Config Class Initialized
ERROR - 2026-08-19 03:53:44 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:53:44 --> Upload Class Initialized
INFO - 2026-08-19 03:53:44 --> Loader Class Initialized
INFO - 2026-08-19 03:53:44 --> Helper loaded: url_helper
DEBUG - 2026-08-19 03:53:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:53:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:53:44 --> Encryption Class Initialized
INFO - 2026-08-19 03:53:44 --> Helper loaded: form_helper
INFO - 2026-08-19 03:53:44 --> Helper loaded: html_helper
INFO - 2026-08-19 03:53:44 --> Helper loaded: file_helper
INFO - 2026-08-19 03:53:44 --> Helper loaded: email_helper
INFO - 2026-08-19 03:53:44 --> Form Validation Class Initialized
INFO - 2026-08-19 03:53:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:53:44 --> Pagination Class Initialized
INFO - 2026-08-19 03:53:44 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:53:44 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:53:44 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:53:44 --> Email Class Initialized
INFO - 2026-08-19 03:53:44 --> Controller Class Initialized
INFO - 2026-08-19 03:53:44 --> Helper loaded: plesk_helper
ERROR - 2026-08-19 03:53:44 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:53:44 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:53:44 --> Upload Class Initialized
INFO - 2026-08-19 03:53:44 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:53:44 --> Helper loaded: entitlement_helper
DEBUG - 2026-08-19 03:53:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:53:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:53:44 --> Encryption Class Initialized
INFO - 2026-08-19 03:53:44 --> Form Validation Class Initialized
INFO - 2026-08-19 03:53:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:53:44 --> Pagination Class Initialized
INFO - 2026-08-19 03:53:44 --> Database Driver Class Initialized
INFO - 2026-08-19 03:53:44 --> Email Class Initialized
INFO - 2026-08-19 03:53:44 --> Controller Class Initialized
ERROR - 2026-08-19 03:53:44 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:53:44 --> Upload Class Initialized
DEBUG - 2026-08-19 03:53:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:53:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:53:44 --> Encryption Class Initialized
INFO - 2026-08-19 03:53:44 --> Form Validation Class Initialized
INFO - 2026-08-19 03:53:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:53:44 --> Pagination Class Initialized
INFO - 2026-08-19 03:53:44 --> Email Class Initialized
INFO - 2026-08-19 03:53:44 --> Controller Class Initialized
ERROR - 2026-08-19 03:53:44 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:53:46 --> Upload Class Initialized
DEBUG - 2026-08-19 03:53:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:53:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:53:46 --> Encryption Class Initialized
INFO - 2026-08-19 03:53:46 --> Form Validation Class Initialized
INFO - 2026-08-19 03:53:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:53:46 --> Pagination Class Initialized
INFO - 2026-08-19 03:53:46 --> Email Class Initialized
INFO - 2026-08-19 03:53:46 --> Controller Class Initialized
ERROR - 2026-08-19 03:53:46 --> 404 Page Not Found: /index
INFO - 2026-08-19 03:53:56 --> Config Class Initialized
INFO - 2026-08-19 03:53:56 --> Hooks Class Initialized
DEBUG - 2026-08-19 03:53:56 --> UTF-8 Support Enabled
INFO - 2026-08-19 03:53:56 --> Utf8 Class Initialized
INFO - 2026-08-19 03:53:56 --> URI Class Initialized
INFO - 2026-08-19 03:53:56 --> Router Class Initialized
INFO - 2026-08-19 03:53:56 --> Output Class Initialized
INFO - 2026-08-19 03:53:56 --> Security Class Initialized
DEBUG - 2026-08-19 03:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-19 03:53:56 --> CSRF cookie sent
INFO - 2026-08-19 03:53:56 --> CSRF token verified
INFO - 2026-08-19 03:53:56 --> Input Class Initialized
INFO - 2026-08-19 03:53:56 --> Language Class Initialized
INFO - 2026-08-19 03:53:56 --> Language Class Initialized
INFO - 2026-08-19 03:53:56 --> Config Class Initialized
INFO - 2026-08-19 03:53:56 --> Loader Class Initialized
INFO - 2026-08-19 03:53:56 --> Helper loaded: url_helper
INFO - 2026-08-19 03:53:56 --> Helper loaded: form_helper
INFO - 2026-08-19 03:53:56 --> Helper loaded: html_helper
INFO - 2026-08-19 03:53:56 --> Helper loaded: file_helper
INFO - 2026-08-19 03:53:56 --> Helper loaded: email_helper
INFO - 2026-08-19 03:53:56 --> Helper loaded: whmaz_helper
INFO - 2026-08-19 03:53:56 --> Helper loaded: ssp_helper
INFO - 2026-08-19 03:53:56 --> Helper loaded: cpanel_helper
INFO - 2026-08-19 03:53:56 --> Helper loaded: plesk_helper
INFO - 2026-08-19 03:53:56 --> Helper loaded: directadmin_helper
INFO - 2026-08-19 03:53:56 --> Helper loaded: domain_helper
INFO - 2026-08-19 03:53:56 --> Helper loaded: entitlement_helper
INFO - 2026-08-19 03:53:56 --> Database Driver Class Initialized
INFO - 2026-08-19 03:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-19 03:53:58 --> Upload Class Initialized
DEBUG - 2026-08-19 03:53:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-19 03:53:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-19 03:53:58 --> Encryption Class Initialized
INFO - 2026-08-19 03:53:58 --> Form Validation Class Initialized
INFO - 2026-08-19 03:53:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-19 03:53:58 --> Pagination Class Initialized
INFO - 2026-08-19 03:53:58 --> Email Class Initialized
INFO - 2026-08-19 03:53:58 --> Controller Class Initialized
DEBUG - 2026-08-19 03:53:58 --> Authenticate MX_Controller Initialized
INFO - 2026-08-19 03:53:58 --> Model "Loginattempt_model" initialized
INFO - 2026-08-19 03:53:58 --> Model "Adminauth_model" initialized
INFO - 2026-08-19 03:53:58 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-19 03:54:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-08-19 03:54:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-08-19 03:54:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-08-19 03:54:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-08-19 03:54:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-08-19 03:54:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-08-19 03:54:00 --> Final output sent to browser
DEBUG - 2026-08-19 03:54:00 --> Total execution time: 3.3600

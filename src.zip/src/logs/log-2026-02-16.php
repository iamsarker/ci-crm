<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-02-16 02:10:20 --> Config Class Initialized
INFO - 2026-02-16 02:10:20 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:10:20 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:10:20 --> Utf8 Class Initialized
INFO - 2026-02-16 02:10:20 --> URI Class Initialized
DEBUG - 2026-02-16 02:10:20 --> No URI present. Default controller set.
INFO - 2026-02-16 02:10:20 --> Router Class Initialized
INFO - 2026-02-16 02:10:20 --> Output Class Initialized
INFO - 2026-02-16 02:10:20 --> Security Class Initialized
DEBUG - 2026-02-16 02:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:10:20 --> CSRF cookie sent
INFO - 2026-02-16 02:10:20 --> Input Class Initialized
INFO - 2026-02-16 02:10:20 --> Language Class Initialized
INFO - 2026-02-16 02:10:20 --> Language Class Initialized
INFO - 2026-02-16 02:10:20 --> Config Class Initialized
INFO - 2026-02-16 02:10:20 --> Loader Class Initialized
INFO - 2026-02-16 02:10:20 --> Helper loaded: url_helper
INFO - 2026-02-16 02:10:20 --> Helper loaded: form_helper
INFO - 2026-02-16 02:10:20 --> Helper loaded: html_helper
INFO - 2026-02-16 02:10:20 --> Helper loaded: file_helper
INFO - 2026-02-16 02:10:20 --> Helper loaded: email_helper
INFO - 2026-02-16 02:10:20 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:10:20 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:10:20 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:10:20 --> Database Driver Class Initialized
INFO - 2026-02-16 02:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:10:23 --> Upload Class Initialized
DEBUG - 2026-02-16 02:10:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:10:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:10:23 --> Encryption Class Initialized
INFO - 2026-02-16 02:10:23 --> Form Validation Class Initialized
INFO - 2026-02-16 02:10:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:10:23 --> Pagination Class Initialized
INFO - 2026-02-16 02:10:23 --> Email Class Initialized
INFO - 2026-02-16 02:10:23 --> Controller Class Initialized
DEBUG - 2026-02-16 02:10:23 --> Auth MX_Controller Initialized
INFO - 2026-02-16 02:10:23 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:10:23 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:10:23 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:10:23 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 02:10:23 --> Config Class Initialized
INFO - 2026-02-16 02:10:23 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:10:23 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:10:23 --> Utf8 Class Initialized
INFO - 2026-02-16 02:10:23 --> URI Class Initialized
INFO - 2026-02-16 02:10:23 --> Router Class Initialized
INFO - 2026-02-16 02:10:23 --> Output Class Initialized
INFO - 2026-02-16 02:10:23 --> Security Class Initialized
DEBUG - 2026-02-16 02:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:10:23 --> CSRF cookie sent
INFO - 2026-02-16 02:10:23 --> Input Class Initialized
INFO - 2026-02-16 02:10:23 --> Language Class Initialized
INFO - 2026-02-16 02:10:23 --> Language Class Initialized
INFO - 2026-02-16 02:10:23 --> Config Class Initialized
INFO - 2026-02-16 02:10:23 --> Loader Class Initialized
INFO - 2026-02-16 02:10:23 --> Helper loaded: url_helper
INFO - 2026-02-16 02:10:23 --> Helper loaded: form_helper
INFO - 2026-02-16 02:10:23 --> Helper loaded: html_helper
INFO - 2026-02-16 02:10:23 --> Helper loaded: file_helper
INFO - 2026-02-16 02:10:23 --> Helper loaded: email_helper
INFO - 2026-02-16 02:10:23 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:10:23 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:10:23 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:10:23 --> Database Driver Class Initialized
INFO - 2026-02-16 02:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:10:25 --> Upload Class Initialized
DEBUG - 2026-02-16 02:10:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:10:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:10:25 --> Encryption Class Initialized
INFO - 2026-02-16 02:10:25 --> Form Validation Class Initialized
INFO - 2026-02-16 02:10:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:10:25 --> Pagination Class Initialized
INFO - 2026-02-16 02:10:25 --> Email Class Initialized
INFO - 2026-02-16 02:10:25 --> Controller Class Initialized
DEBUG - 2026-02-16 02:10:25 --> Auth MX_Controller Initialized
INFO - 2026-02-16 02:10:25 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:10:25 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:10:25 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:10:25 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-16 02:10:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-16 02:10:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-16 02:10:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-16 02:10:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-02-16 02:10:25 --> Final output sent to browser
DEBUG - 2026-02-16 02:10:25 --> Total execution time: 2.0414
INFO - 2026-02-16 02:10:26 --> Config Class Initialized
INFO - 2026-02-16 02:10:26 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:10:26 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:10:26 --> Utf8 Class Initialized
INFO - 2026-02-16 02:10:26 --> URI Class Initialized
INFO - 2026-02-16 02:10:26 --> Router Class Initialized
INFO - 2026-02-16 02:10:26 --> Output Class Initialized
INFO - 2026-02-16 02:10:26 --> Security Class Initialized
DEBUG - 2026-02-16 02:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:10:26 --> CSRF cookie sent
INFO - 2026-02-16 02:10:26 --> Input Class Initialized
INFO - 2026-02-16 02:10:26 --> Language Class Initialized
INFO - 2026-02-16 02:10:26 --> Language Class Initialized
INFO - 2026-02-16 02:10:26 --> Config Class Initialized
INFO - 2026-02-16 02:10:26 --> Loader Class Initialized
INFO - 2026-02-16 02:10:26 --> Helper loaded: url_helper
INFO - 2026-02-16 02:10:26 --> Helper loaded: form_helper
INFO - 2026-02-16 02:10:26 --> Helper loaded: html_helper
INFO - 2026-02-16 02:10:26 --> Helper loaded: file_helper
INFO - 2026-02-16 02:10:26 --> Helper loaded: email_helper
INFO - 2026-02-16 02:10:26 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:10:26 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:10:26 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:10:26 --> Database Driver Class Initialized
INFO - 2026-02-16 02:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:10:27 --> Upload Class Initialized
DEBUG - 2026-02-16 02:10:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:10:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:10:27 --> Encryption Class Initialized
INFO - 2026-02-16 02:10:27 --> Form Validation Class Initialized
INFO - 2026-02-16 02:10:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:10:27 --> Pagination Class Initialized
INFO - 2026-02-16 02:10:27 --> Email Class Initialized
INFO - 2026-02-16 02:10:27 --> Controller Class Initialized
DEBUG - 2026-02-16 02:10:27 --> Cart MX_Controller Initialized
INFO - 2026-02-16 02:10:27 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:10:27 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:10:27 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:10:27 --> Model "Common_model" initialized
INFO - 2026-02-16 02:10:27 --> Model "Order_model" initialized
INFO - 2026-02-16 02:10:27 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 02:10:28 --> Final output sent to browser
DEBUG - 2026-02-16 02:10:28 --> Total execution time: 2.0510
INFO - 2026-02-16 02:10:53 --> Config Class Initialized
INFO - 2026-02-16 02:10:53 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:10:53 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:10:53 --> Utf8 Class Initialized
INFO - 2026-02-16 02:10:53 --> URI Class Initialized
INFO - 2026-02-16 02:10:53 --> Router Class Initialized
INFO - 2026-02-16 02:10:53 --> Output Class Initialized
INFO - 2026-02-16 02:10:53 --> Security Class Initialized
DEBUG - 2026-02-16 02:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:10:53 --> CSRF cookie sent
INFO - 2026-02-16 02:10:53 --> Input Class Initialized
INFO - 2026-02-16 02:10:53 --> Language Class Initialized
INFO - 2026-02-16 02:10:53 --> Language Class Initialized
INFO - 2026-02-16 02:10:53 --> Config Class Initialized
INFO - 2026-02-16 02:10:53 --> Loader Class Initialized
INFO - 2026-02-16 02:10:53 --> Helper loaded: url_helper
INFO - 2026-02-16 02:10:53 --> Helper loaded: form_helper
INFO - 2026-02-16 02:10:53 --> Helper loaded: html_helper
INFO - 2026-02-16 02:10:53 --> Helper loaded: file_helper
INFO - 2026-02-16 02:10:53 --> Helper loaded: email_helper
INFO - 2026-02-16 02:10:53 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:10:53 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:10:53 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:10:53 --> Database Driver Class Initialized
INFO - 2026-02-16 02:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:10:56 --> Upload Class Initialized
DEBUG - 2026-02-16 02:10:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:10:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:10:56 --> Encryption Class Initialized
INFO - 2026-02-16 02:10:56 --> Form Validation Class Initialized
INFO - 2026-02-16 02:10:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:10:56 --> Pagination Class Initialized
INFO - 2026-02-16 02:10:56 --> Email Class Initialized
INFO - 2026-02-16 02:10:56 --> Controller Class Initialized
DEBUG - 2026-02-16 02:10:56 --> Auth MX_Controller Initialized
INFO - 2026-02-16 02:10:56 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:10:56 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:10:56 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:10:56 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-16 02:10:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-16 02:10:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-16 02:10:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-16 02:10:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-02-16 02:10:56 --> Final output sent to browser
DEBUG - 2026-02-16 02:10:56 --> Total execution time: 3.0004
INFO - 2026-02-16 02:11:18 --> Config Class Initialized
INFO - 2026-02-16 02:11:18 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:11:18 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:18 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:18 --> URI Class Initialized
INFO - 2026-02-16 02:11:18 --> Config Class Initialized
INFO - 2026-02-16 02:11:18 --> Hooks Class Initialized
INFO - 2026-02-16 02:11:18 --> Router Class Initialized
DEBUG - 2026-02-16 02:11:18 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:18 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:18 --> Output Class Initialized
INFO - 2026-02-16 02:11:18 --> URI Class Initialized
INFO - 2026-02-16 02:11:18 --> Security Class Initialized
INFO - 2026-02-16 02:11:18 --> Router Class Initialized
DEBUG - 2026-02-16 02:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:18 --> CSRF cookie sent
INFO - 2026-02-16 02:11:18 --> Input Class Initialized
INFO - 2026-02-16 02:11:18 --> Language Class Initialized
INFO - 2026-02-16 02:11:18 --> Output Class Initialized
INFO - 2026-02-16 02:11:18 --> Language Class Initialized
INFO - 2026-02-16 02:11:18 --> Security Class Initialized
DEBUG - 2026-02-16 02:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:18 --> CSRF cookie sent
INFO - 2026-02-16 02:11:18 --> Input Class Initialized
INFO - 2026-02-16 02:11:18 --> Language Class Initialized
INFO - 2026-02-16 02:11:18 --> Language Class Initialized
INFO - 2026-02-16 02:11:18 --> Config Class Initialized
INFO - 2026-02-16 02:11:18 --> Config Class Initialized
INFO - 2026-02-16 02:11:18 --> Loader Class Initialized
INFO - 2026-02-16 02:11:18 --> Loader Class Initialized
INFO - 2026-02-16 02:11:18 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:18 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:18 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:18 --> Config Class Initialized
INFO - 2026-02-16 02:11:18 --> Hooks Class Initialized
INFO - 2026-02-16 02:11:18 --> Database Driver Class Initialized
DEBUG - 2026-02-16 02:11:18 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:18 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:18 --> URI Class Initialized
INFO - 2026-02-16 02:11:18 --> Router Class Initialized
INFO - 2026-02-16 02:11:18 --> Output Class Initialized
INFO - 2026-02-16 02:11:18 --> Security Class Initialized
DEBUG - 2026-02-16 02:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:18 --> CSRF cookie sent
INFO - 2026-02-16 02:11:18 --> Input Class Initialized
INFO - 2026-02-16 02:11:18 --> Language Class Initialized
INFO - 2026-02-16 02:11:18 --> Config Class Initialized
INFO - 2026-02-16 02:11:18 --> Hooks Class Initialized
INFO - 2026-02-16 02:11:18 --> Language Class Initialized
INFO - 2026-02-16 02:11:18 --> Config Class Initialized
DEBUG - 2026-02-16 02:11:18 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:18 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:18 --> Loader Class Initialized
INFO - 2026-02-16 02:11:18 --> URI Class Initialized
INFO - 2026-02-16 02:11:18 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:18 --> Config Class Initialized
INFO - 2026-02-16 02:11:18 --> Hooks Class Initialized
INFO - 2026-02-16 02:11:18 --> Router Class Initialized
INFO - 2026-02-16 02:11:18 --> Helper loaded: form_helper
DEBUG - 2026-02-16 02:11:18 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:18 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:18 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:18 --> Output Class Initialized
INFO - 2026-02-16 02:11:18 --> URI Class Initialized
INFO - 2026-02-16 02:11:18 --> Security Class Initialized
INFO - 2026-02-16 02:11:18 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:18 --> Router Class Initialized
INFO - 2026-02-16 02:11:18 --> Helper loaded: ssp_helper
DEBUG - 2026-02-16 02:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:18 --> CSRF cookie sent
INFO - 2026-02-16 02:11:18 --> Input Class Initialized
INFO - 2026-02-16 02:11:18 --> Output Class Initialized
INFO - 2026-02-16 02:11:18 --> Language Class Initialized
INFO - 2026-02-16 02:11:18 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:18 --> Language Class Initialized
INFO - 2026-02-16 02:11:18 --> Config Class Initialized
INFO - 2026-02-16 02:11:18 --> Config Class Initialized
INFO - 2026-02-16 02:11:18 --> Security Class Initialized
INFO - 2026-02-16 02:11:18 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:18 --> CSRF cookie sent
INFO - 2026-02-16 02:11:18 --> Input Class Initialized
DEBUG - 2026-02-16 02:11:18 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:18 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:18 --> Language Class Initialized
INFO - 2026-02-16 02:11:18 --> URI Class Initialized
INFO - 2026-02-16 02:11:18 --> Language Class Initialized
INFO - 2026-02-16 02:11:18 --> Config Class Initialized
INFO - 2026-02-16 02:11:18 --> Loader Class Initialized
INFO - 2026-02-16 02:11:18 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:18 --> Router Class Initialized
INFO - 2026-02-16 02:11:18 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:18 --> Loader Class Initialized
INFO - 2026-02-16 02:11:18 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:18 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:18 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:18 --> Output Class Initialized
INFO - 2026-02-16 02:11:18 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:18 --> Security Class Initialized
INFO - 2026-02-16 02:11:18 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: email_helper
DEBUG - 2026-02-16 02:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:18 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:18 --> CSRF cookie sent
INFO - 2026-02-16 02:11:18 --> Input Class Initialized
INFO - 2026-02-16 02:11:18 --> Language Class Initialized
INFO - 2026-02-16 02:11:18 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:18 --> Language Class Initialized
INFO - 2026-02-16 02:11:18 --> Config Class Initialized
INFO - 2026-02-16 02:11:18 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:18 --> Loader Class Initialized
INFO - 2026-02-16 02:11:18 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:18 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:18 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:18 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:18 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:18 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:18 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:20 --> Upload Class Initialized
DEBUG - 2026-02-16 02:11:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:20 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:20 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:20 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:20 --> Email Class Initialized
INFO - 2026-02-16 02:11:20 --> Controller Class Initialized
ERROR - 2026-02-16 02:11:20 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:11:20 --> Config Class Initialized
INFO - 2026-02-16 02:11:20 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:11:20 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:20 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:20 --> URI Class Initialized
INFO - 2026-02-16 02:11:20 --> Router Class Initialized
INFO - 2026-02-16 02:11:20 --> Output Class Initialized
INFO - 2026-02-16 02:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:20 --> Security Class Initialized
INFO - 2026-02-16 02:11:20 --> Upload Class Initialized
DEBUG - 2026-02-16 02:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:20 --> CSRF cookie sent
INFO - 2026-02-16 02:11:20 --> Input Class Initialized
INFO - 2026-02-16 02:11:20 --> Language Class Initialized
DEBUG - 2026-02-16 02:11:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:20 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:20 --> Language Class Initialized
INFO - 2026-02-16 02:11:20 --> Config Class Initialized
INFO - 2026-02-16 02:11:20 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:20 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:20 --> Loader Class Initialized
INFO - 2026-02-16 02:11:20 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:20 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:20 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:20 --> Email Class Initialized
INFO - 2026-02-16 02:11:20 --> Controller Class Initialized
INFO - 2026-02-16 02:11:20 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:20 --> Helper loaded: email_helper
ERROR - 2026-02-16 02:11:20 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:11:20 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:20 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:20 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:20 --> Upload Class Initialized
INFO - 2026-02-16 02:11:20 --> Config Class Initialized
INFO - 2026-02-16 02:11:20 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:11:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:20 --> Encryption Class Initialized
DEBUG - 2026-02-16 02:11:20 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:20 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:20 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:20 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:20 --> URI Class Initialized
INFO - 2026-02-16 02:11:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:20 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:20 --> Router Class Initialized
INFO - 2026-02-16 02:11:20 --> Output Class Initialized
INFO - 2026-02-16 02:11:20 --> Security Class Initialized
INFO - 2026-02-16 02:11:20 --> Email Class Initialized
DEBUG - 2026-02-16 02:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:20 --> CSRF cookie sent
INFO - 2026-02-16 02:11:20 --> Input Class Initialized
INFO - 2026-02-16 02:11:20 --> Controller Class Initialized
INFO - 2026-02-16 02:11:20 --> Language Class Initialized
ERROR - 2026-02-16 02:11:20 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:20 --> Language Class Initialized
INFO - 2026-02-16 02:11:20 --> Config Class Initialized
INFO - 2026-02-16 02:11:20 --> Upload Class Initialized
INFO - 2026-02-16 02:11:20 --> Loader Class Initialized
DEBUG - 2026-02-16 02:11:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:20 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:20 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:20 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:20 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:20 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:20 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:20 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:20 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:20 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:20 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:20 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:20 --> Email Class Initialized
INFO - 2026-02-16 02:11:20 --> Controller Class Initialized
ERROR - 2026-02-16 02:11:20 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:20 --> Upload Class Initialized
DEBUG - 2026-02-16 02:11:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:20 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:20 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:20 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:20 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:20 --> Email Class Initialized
INFO - 2026-02-16 02:11:20 --> Controller Class Initialized
ERROR - 2026-02-16 02:11:20 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:20 --> Upload Class Initialized
DEBUG - 2026-02-16 02:11:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:20 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:20 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:20 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:20 --> Email Class Initialized
INFO - 2026-02-16 02:11:20 --> Controller Class Initialized
ERROR - 2026-02-16 02:11:20 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:11:20 --> Config Class Initialized
INFO - 2026-02-16 02:11:20 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:11:20 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:20 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:20 --> URI Class Initialized
INFO - 2026-02-16 02:11:20 --> Router Class Initialized
INFO - 2026-02-16 02:11:20 --> Output Class Initialized
INFO - 2026-02-16 02:11:20 --> Security Class Initialized
DEBUG - 2026-02-16 02:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:20 --> CSRF cookie sent
INFO - 2026-02-16 02:11:20 --> Input Class Initialized
INFO - 2026-02-16 02:11:20 --> Language Class Initialized
INFO - 2026-02-16 02:11:20 --> Language Class Initialized
INFO - 2026-02-16 02:11:20 --> Config Class Initialized
INFO - 2026-02-16 02:11:20 --> Loader Class Initialized
INFO - 2026-02-16 02:11:20 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:20 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:20 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:20 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:20 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:20 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:20 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:20 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:20 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:22 --> Upload Class Initialized
DEBUG - 2026-02-16 02:11:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:22 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:22 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:22 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:22 --> Email Class Initialized
INFO - 2026-02-16 02:11:22 --> Controller Class Initialized
DEBUG - 2026-02-16 02:11:22 --> Auth MX_Controller Initialized
INFO - 2026-02-16 02:11:22 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:11:22 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:11:22 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:11:22 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-16 02:11:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-16 02:11:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-16 02:11:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-16 02:11:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-02-16 02:11:22 --> Final output sent to browser
DEBUG - 2026-02-16 02:11:22 --> Total execution time: 2.2079
INFO - 2026-02-16 02:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:22 --> Upload Class Initialized
DEBUG - 2026-02-16 02:11:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:22 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:22 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:22 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:22 --> Email Class Initialized
INFO - 2026-02-16 02:11:22 --> Controller Class Initialized
ERROR - 2026-02-16 02:11:22 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:22 --> Upload Class Initialized
DEBUG - 2026-02-16 02:11:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:22 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:22 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:22 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:22 --> Email Class Initialized
INFO - 2026-02-16 02:11:22 --> Controller Class Initialized
ERROR - 2026-02-16 02:11:22 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:11:23 --> Config Class Initialized
INFO - 2026-02-16 02:11:23 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:11:23 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:23 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:23 --> URI Class Initialized
INFO - 2026-02-16 02:11:23 --> Router Class Initialized
INFO - 2026-02-16 02:11:23 --> Output Class Initialized
INFO - 2026-02-16 02:11:23 --> Security Class Initialized
DEBUG - 2026-02-16 02:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:23 --> CSRF cookie sent
INFO - 2026-02-16 02:11:23 --> Input Class Initialized
INFO - 2026-02-16 02:11:23 --> Language Class Initialized
INFO - 2026-02-16 02:11:23 --> Language Class Initialized
INFO - 2026-02-16 02:11:23 --> Config Class Initialized
INFO - 2026-02-16 02:11:23 --> Loader Class Initialized
INFO - 2026-02-16 02:11:23 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:23 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:23 --> Config Class Initialized
INFO - 2026-02-16 02:11:23 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:11:23 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:23 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:23 --> URI Class Initialized
INFO - 2026-02-16 02:11:23 --> Router Class Initialized
INFO - 2026-02-16 02:11:23 --> Output Class Initialized
INFO - 2026-02-16 02:11:23 --> Security Class Initialized
DEBUG - 2026-02-16 02:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:23 --> CSRF cookie sent
INFO - 2026-02-16 02:11:23 --> Input Class Initialized
INFO - 2026-02-16 02:11:23 --> Language Class Initialized
INFO - 2026-02-16 02:11:23 --> Language Class Initialized
INFO - 2026-02-16 02:11:23 --> Config Class Initialized
INFO - 2026-02-16 02:11:23 --> Loader Class Initialized
INFO - 2026-02-16 02:11:23 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:23 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:23 --> Config Class Initialized
INFO - 2026-02-16 02:11:23 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:11:23 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:23 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:23 --> URI Class Initialized
INFO - 2026-02-16 02:11:23 --> Config Class Initialized
INFO - 2026-02-16 02:11:23 --> Hooks Class Initialized
INFO - 2026-02-16 02:11:23 --> Router Class Initialized
DEBUG - 2026-02-16 02:11:23 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:23 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:23 --> Output Class Initialized
INFO - 2026-02-16 02:11:23 --> URI Class Initialized
INFO - 2026-02-16 02:11:23 --> Security Class Initialized
INFO - 2026-02-16 02:11:23 --> Router Class Initialized
DEBUG - 2026-02-16 02:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:23 --> CSRF cookie sent
INFO - 2026-02-16 02:11:23 --> Input Class Initialized
INFO - 2026-02-16 02:11:23 --> Language Class Initialized
INFO - 2026-02-16 02:11:23 --> Output Class Initialized
INFO - 2026-02-16 02:11:23 --> Language Class Initialized
INFO - 2026-02-16 02:11:23 --> Config Class Initialized
INFO - 2026-02-16 02:11:23 --> Security Class Initialized
DEBUG - 2026-02-16 02:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:23 --> CSRF cookie sent
INFO - 2026-02-16 02:11:23 --> Input Class Initialized
INFO - 2026-02-16 02:11:23 --> Language Class Initialized
INFO - 2026-02-16 02:11:23 --> Loader Class Initialized
INFO - 2026-02-16 02:11:23 --> Language Class Initialized
INFO - 2026-02-16 02:11:23 --> Config Class Initialized
INFO - 2026-02-16 02:11:23 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:23 --> Loader Class Initialized
INFO - 2026-02-16 02:11:23 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:23 --> Config Class Initialized
INFO - 2026-02-16 02:11:23 --> Hooks Class Initialized
INFO - 2026-02-16 02:11:23 --> Config Class Initialized
INFO - 2026-02-16 02:11:23 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:11:23 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:23 --> Utf8 Class Initialized
DEBUG - 2026-02-16 02:11:23 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:23 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:23 --> URI Class Initialized
INFO - 2026-02-16 02:11:23 --> URI Class Initialized
INFO - 2026-02-16 02:11:23 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:23 --> Router Class Initialized
INFO - 2026-02-16 02:11:23 --> Router Class Initialized
INFO - 2026-02-16 02:11:23 --> Output Class Initialized
INFO - 2026-02-16 02:11:23 --> Output Class Initialized
INFO - 2026-02-16 02:11:23 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:23 --> Security Class Initialized
INFO - 2026-02-16 02:11:23 --> Security Class Initialized
DEBUG - 2026-02-16 02:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:23 --> CSRF cookie sent
INFO - 2026-02-16 02:11:23 --> Input Class Initialized
INFO - 2026-02-16 02:11:23 --> Language Class Initialized
DEBUG - 2026-02-16 02:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:23 --> CSRF cookie sent
INFO - 2026-02-16 02:11:23 --> Input Class Initialized
INFO - 2026-02-16 02:11:23 --> Language Class Initialized
INFO - 2026-02-16 02:11:23 --> Language Class Initialized
INFO - 2026-02-16 02:11:23 --> Config Class Initialized
INFO - 2026-02-16 02:11:23 --> Language Class Initialized
INFO - 2026-02-16 02:11:23 --> Config Class Initialized
INFO - 2026-02-16 02:11:23 --> Loader Class Initialized
INFO - 2026-02-16 02:11:23 --> Loader Class Initialized
INFO - 2026-02-16 02:11:23 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:23 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:23 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:23 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:25 --> Upload Class Initialized
DEBUG - 2026-02-16 02:11:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:25 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:25 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:25 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:25 --> Email Class Initialized
INFO - 2026-02-16 02:11:25 --> Controller Class Initialized
ERROR - 2026-02-16 02:11:25 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:11:25 --> Config Class Initialized
INFO - 2026-02-16 02:11:25 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:11:25 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:25 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:25 --> URI Class Initialized
INFO - 2026-02-16 02:11:25 --> Router Class Initialized
INFO - 2026-02-16 02:11:25 --> Output Class Initialized
INFO - 2026-02-16 02:11:25 --> Security Class Initialized
DEBUG - 2026-02-16 02:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:25 --> CSRF cookie sent
INFO - 2026-02-16 02:11:25 --> Input Class Initialized
INFO - 2026-02-16 02:11:25 --> Language Class Initialized
INFO - 2026-02-16 02:11:25 --> Language Class Initialized
INFO - 2026-02-16 02:11:25 --> Config Class Initialized
INFO - 2026-02-16 02:11:25 --> Loader Class Initialized
INFO - 2026-02-16 02:11:25 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:25 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:25 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:25 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:25 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:25 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:25 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:25 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:25 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:25 --> Upload Class Initialized
DEBUG - 2026-02-16 02:11:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:25 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:25 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:25 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:25 --> Email Class Initialized
INFO - 2026-02-16 02:11:25 --> Controller Class Initialized
ERROR - 2026-02-16 02:11:25 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:11:25 --> Config Class Initialized
INFO - 2026-02-16 02:11:25 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:11:25 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:25 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:25 --> URI Class Initialized
INFO - 2026-02-16 02:11:25 --> Router Class Initialized
INFO - 2026-02-16 02:11:25 --> Output Class Initialized
INFO - 2026-02-16 02:11:25 --> Security Class Initialized
DEBUG - 2026-02-16 02:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:25 --> CSRF cookie sent
INFO - 2026-02-16 02:11:25 --> Input Class Initialized
INFO - 2026-02-16 02:11:25 --> Language Class Initialized
INFO - 2026-02-16 02:11:25 --> Language Class Initialized
INFO - 2026-02-16 02:11:25 --> Config Class Initialized
INFO - 2026-02-16 02:11:25 --> Loader Class Initialized
INFO - 2026-02-16 02:11:25 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:25 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:25 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:25 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:25 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:25 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:25 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:25 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:25 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:26 --> Upload Class Initialized
DEBUG - 2026-02-16 02:11:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:26 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:26 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:26 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:26 --> Email Class Initialized
INFO - 2026-02-16 02:11:26 --> Controller Class Initialized
ERROR - 2026-02-16 02:11:26 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:11:26 --> Config Class Initialized
INFO - 2026-02-16 02:11:26 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:11:26 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:26 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:26 --> URI Class Initialized
INFO - 2026-02-16 02:11:26 --> Router Class Initialized
INFO - 2026-02-16 02:11:26 --> Output Class Initialized
INFO - 2026-02-16 02:11:26 --> Security Class Initialized
DEBUG - 2026-02-16 02:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:26 --> CSRF cookie sent
INFO - 2026-02-16 02:11:26 --> Input Class Initialized
INFO - 2026-02-16 02:11:26 --> Language Class Initialized
INFO - 2026-02-16 02:11:26 --> Language Class Initialized
INFO - 2026-02-16 02:11:26 --> Config Class Initialized
INFO - 2026-02-16 02:11:26 --> Loader Class Initialized
INFO - 2026-02-16 02:11:26 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:26 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:26 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:26 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:26 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:26 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:26 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:26 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:26 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:27 --> Upload Class Initialized
DEBUG - 2026-02-16 02:11:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:27 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:27 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:27 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:27 --> Email Class Initialized
INFO - 2026-02-16 02:11:27 --> Controller Class Initialized
ERROR - 2026-02-16 02:11:27 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:27 --> Upload Class Initialized
DEBUG - 2026-02-16 02:11:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:27 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:27 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:27 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:27 --> Email Class Initialized
INFO - 2026-02-16 02:11:27 --> Controller Class Initialized
ERROR - 2026-02-16 02:11:27 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:27 --> Upload Class Initialized
DEBUG - 2026-02-16 02:11:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:27 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:27 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:27 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:27 --> Email Class Initialized
INFO - 2026-02-16 02:11:27 --> Controller Class Initialized
DEBUG - 2026-02-16 02:11:27 --> Cart MX_Controller Initialized
INFO - 2026-02-16 02:11:27 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:11:27 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:11:27 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:11:27 --> Model "Common_model" initialized
INFO - 2026-02-16 02:11:27 --> Model "Order_model" initialized
INFO - 2026-02-16 02:11:27 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 02:11:28 --> Final output sent to browser
DEBUG - 2026-02-16 02:11:28 --> Total execution time: 3.0617
INFO - 2026-02-16 02:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:28 --> Upload Class Initialized
DEBUG - 2026-02-16 02:11:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:28 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:28 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:28 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:28 --> Email Class Initialized
INFO - 2026-02-16 02:11:28 --> Controller Class Initialized
ERROR - 2026-02-16 02:11:28 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:29 --> Upload Class Initialized
DEBUG - 2026-02-16 02:11:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:29 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:29 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:29 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:29 --> Email Class Initialized
INFO - 2026-02-16 02:11:29 --> Controller Class Initialized
ERROR - 2026-02-16 02:11:29 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:29 --> Upload Class Initialized
DEBUG - 2026-02-16 02:11:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:29 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:29 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:29 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:29 --> Email Class Initialized
INFO - 2026-02-16 02:11:29 --> Controller Class Initialized
ERROR - 2026-02-16 02:11:29 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:11:29 --> Config Class Initialized
INFO - 2026-02-16 02:11:29 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:11:29 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:29 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:29 --> URI Class Initialized
INFO - 2026-02-16 02:11:29 --> Router Class Initialized
INFO - 2026-02-16 02:11:29 --> Output Class Initialized
INFO - 2026-02-16 02:11:29 --> Security Class Initialized
DEBUG - 2026-02-16 02:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:29 --> CSRF cookie sent
INFO - 2026-02-16 02:11:29 --> CSRF token verified
INFO - 2026-02-16 02:11:29 --> Input Class Initialized
INFO - 2026-02-16 02:11:29 --> Language Class Initialized
INFO - 2026-02-16 02:11:29 --> Language Class Initialized
INFO - 2026-02-16 02:11:29 --> Config Class Initialized
INFO - 2026-02-16 02:11:29 --> Loader Class Initialized
INFO - 2026-02-16 02:11:29 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:29 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:29 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:29 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:29 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:29 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:29 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:29 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:29 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:33 --> Upload Class Initialized
DEBUG - 2026-02-16 02:11:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:33 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:33 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:33 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:33 --> Email Class Initialized
INFO - 2026-02-16 02:11:33 --> Controller Class Initialized
DEBUG - 2026-02-16 02:11:33 --> Auth MX_Controller Initialized
INFO - 2026-02-16 02:11:33 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:11:33 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:11:33 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:11:33 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-16 02:11:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-16 02:11:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-16 02:11:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-16 02:11:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-02-16 02:11:39 --> Final output sent to browser
DEBUG - 2026-02-16 02:11:39 --> Total execution time: 9.2905
INFO - 2026-02-16 02:11:39 --> Config Class Initialized
INFO - 2026-02-16 02:11:39 --> Config Class Initialized
INFO - 2026-02-16 02:11:39 --> Hooks Class Initialized
INFO - 2026-02-16 02:11:39 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:11:39 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:39 --> Utf8 Class Initialized
DEBUG - 2026-02-16 02:11:39 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:39 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:39 --> URI Class Initialized
INFO - 2026-02-16 02:11:39 --> URI Class Initialized
INFO - 2026-02-16 02:11:39 --> Router Class Initialized
INFO - 2026-02-16 02:11:39 --> Output Class Initialized
INFO - 2026-02-16 02:11:39 --> Router Class Initialized
INFO - 2026-02-16 02:11:39 --> Security Class Initialized
INFO - 2026-02-16 02:11:39 --> Output Class Initialized
DEBUG - 2026-02-16 02:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:39 --> CSRF cookie sent
INFO - 2026-02-16 02:11:39 --> Input Class Initialized
INFO - 2026-02-16 02:11:39 --> Language Class Initialized
INFO - 2026-02-16 02:11:39 --> Security Class Initialized
INFO - 2026-02-16 02:11:39 --> Language Class Initialized
INFO - 2026-02-16 02:11:39 --> Config Class Initialized
DEBUG - 2026-02-16 02:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:39 --> CSRF cookie sent
INFO - 2026-02-16 02:11:39 --> Input Class Initialized
INFO - 2026-02-16 02:11:39 --> Language Class Initialized
INFO - 2026-02-16 02:11:39 --> Language Class Initialized
INFO - 2026-02-16 02:11:39 --> Config Class Initialized
INFO - 2026-02-16 02:11:39 --> Loader Class Initialized
INFO - 2026-02-16 02:11:39 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:39 --> Loader Class Initialized
INFO - 2026-02-16 02:11:39 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:39 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:39 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:39 --> Config Class Initialized
INFO - 2026-02-16 02:11:39 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:11:39 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:39 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:39 --> URI Class Initialized
INFO - 2026-02-16 02:11:39 --> Router Class Initialized
INFO - 2026-02-16 02:11:39 --> Output Class Initialized
INFO - 2026-02-16 02:11:39 --> Security Class Initialized
DEBUG - 2026-02-16 02:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:39 --> CSRF cookie sent
INFO - 2026-02-16 02:11:39 --> Input Class Initialized
INFO - 2026-02-16 02:11:39 --> Language Class Initialized
INFO - 2026-02-16 02:11:39 --> Language Class Initialized
INFO - 2026-02-16 02:11:39 --> Config Class Initialized
INFO - 2026-02-16 02:11:39 --> Loader Class Initialized
INFO - 2026-02-16 02:11:39 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:39 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:39 --> Config Class Initialized
INFO - 2026-02-16 02:11:39 --> Hooks Class Initialized
INFO - 2026-02-16 02:11:39 --> Config Class Initialized
INFO - 2026-02-16 02:11:39 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:11:39 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:39 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:39 --> URI Class Initialized
DEBUG - 2026-02-16 02:11:39 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:39 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:39 --> URI Class Initialized
INFO - 2026-02-16 02:11:39 --> Router Class Initialized
INFO - 2026-02-16 02:11:39 --> Router Class Initialized
INFO - 2026-02-16 02:11:39 --> Output Class Initialized
INFO - 2026-02-16 02:11:39 --> Security Class Initialized
INFO - 2026-02-16 02:11:39 --> Output Class Initialized
DEBUG - 2026-02-16 02:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:39 --> CSRF cookie sent
INFO - 2026-02-16 02:11:39 --> Input Class Initialized
INFO - 2026-02-16 02:11:39 --> Language Class Initialized
INFO - 2026-02-16 02:11:39 --> Security Class Initialized
INFO - 2026-02-16 02:11:39 --> Language Class Initialized
INFO - 2026-02-16 02:11:39 --> Config Class Initialized
DEBUG - 2026-02-16 02:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:39 --> CSRF cookie sent
INFO - 2026-02-16 02:11:39 --> Input Class Initialized
INFO - 2026-02-16 02:11:39 --> Language Class Initialized
INFO - 2026-02-16 02:11:39 --> Language Class Initialized
INFO - 2026-02-16 02:11:39 --> Config Class Initialized
INFO - 2026-02-16 02:11:39 --> Loader Class Initialized
INFO - 2026-02-16 02:11:39 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:39 --> Loader Class Initialized
INFO - 2026-02-16 02:11:39 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:39 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:39 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:39 --> Config Class Initialized
INFO - 2026-02-16 02:11:39 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:11:39 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:39 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:39 --> URI Class Initialized
INFO - 2026-02-16 02:11:39 --> Router Class Initialized
INFO - 2026-02-16 02:11:39 --> Output Class Initialized
INFO - 2026-02-16 02:11:39 --> Security Class Initialized
DEBUG - 2026-02-16 02:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:39 --> CSRF cookie sent
INFO - 2026-02-16 02:11:39 --> Input Class Initialized
INFO - 2026-02-16 02:11:39 --> Language Class Initialized
INFO - 2026-02-16 02:11:39 --> Language Class Initialized
INFO - 2026-02-16 02:11:39 --> Config Class Initialized
INFO - 2026-02-16 02:11:39 --> Loader Class Initialized
INFO - 2026-02-16 02:11:39 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:39 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:39 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:40 --> Upload Class Initialized
DEBUG - 2026-02-16 02:11:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:40 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:40 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:40 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:40 --> Email Class Initialized
INFO - 2026-02-16 02:11:40 --> Controller Class Initialized
ERROR - 2026-02-16 02:11:40 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:40 --> Upload Class Initialized
DEBUG - 2026-02-16 02:11:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:40 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:40 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:40 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:40 --> Email Class Initialized
INFO - 2026-02-16 02:11:40 --> Controller Class Initialized
INFO - 2026-02-16 02:11:40 --> Config Class Initialized
INFO - 2026-02-16 02:11:40 --> Hooks Class Initialized
ERROR - 2026-02-16 02:11:40 --> 404 Page Not Found: /index
DEBUG - 2026-02-16 02:11:40 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:40 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:40 --> URI Class Initialized
INFO - 2026-02-16 02:11:40 --> Router Class Initialized
INFO - 2026-02-16 02:11:40 --> Output Class Initialized
INFO - 2026-02-16 02:11:40 --> Security Class Initialized
DEBUG - 2026-02-16 02:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:40 --> CSRF cookie sent
INFO - 2026-02-16 02:11:40 --> Input Class Initialized
INFO - 2026-02-16 02:11:40 --> Language Class Initialized
INFO - 2026-02-16 02:11:40 --> Language Class Initialized
INFO - 2026-02-16 02:11:40 --> Config Class Initialized
INFO - 2026-02-16 02:11:40 --> Config Class Initialized
INFO - 2026-02-16 02:11:40 --> Hooks Class Initialized
INFO - 2026-02-16 02:11:40 --> Loader Class Initialized
DEBUG - 2026-02-16 02:11:40 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:40 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:40 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:40 --> URI Class Initialized
INFO - 2026-02-16 02:11:40 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:40 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:40 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:40 --> Router Class Initialized
INFO - 2026-02-16 02:11:40 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:40 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:40 --> Output Class Initialized
INFO - 2026-02-16 02:11:40 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:40 --> Security Class Initialized
INFO - 2026-02-16 02:11:40 --> Helper loaded: cpanel_helper
DEBUG - 2026-02-16 02:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:40 --> CSRF cookie sent
INFO - 2026-02-16 02:11:40 --> Input Class Initialized
INFO - 2026-02-16 02:11:40 --> Language Class Initialized
INFO - 2026-02-16 02:11:40 --> Language Class Initialized
INFO - 2026-02-16 02:11:40 --> Config Class Initialized
INFO - 2026-02-16 02:11:40 --> Loader Class Initialized
INFO - 2026-02-16 02:11:40 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:40 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:40 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:40 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:40 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:40 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:40 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:40 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:40 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:40 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:41 --> Upload Class Initialized
DEBUG - 2026-02-16 02:11:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:41 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:41 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:41 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:41 --> Email Class Initialized
INFO - 2026-02-16 02:11:41 --> Controller Class Initialized
ERROR - 2026-02-16 02:11:41 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:41 --> Upload Class Initialized
DEBUG - 2026-02-16 02:11:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:41 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:41 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:41 --> Config Class Initialized
INFO - 2026-02-16 02:11:41 --> Hooks Class Initialized
INFO - 2026-02-16 02:11:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:41 --> Pagination Class Initialized
DEBUG - 2026-02-16 02:11:41 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:41 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:41 --> URI Class Initialized
INFO - 2026-02-16 02:11:41 --> Email Class Initialized
INFO - 2026-02-16 02:11:41 --> Controller Class Initialized
INFO - 2026-02-16 02:11:41 --> Router Class Initialized
ERROR - 2026-02-16 02:11:41 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:41 --> Output Class Initialized
INFO - 2026-02-16 02:11:41 --> Upload Class Initialized
INFO - 2026-02-16 02:11:41 --> Security Class Initialized
DEBUG - 2026-02-16 02:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:41 --> CSRF cookie sent
INFO - 2026-02-16 02:11:41 --> Input Class Initialized
DEBUG - 2026-02-16 02:11:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:41 --> Language Class Initialized
INFO - 2026-02-16 02:11:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:41 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:41 --> Language Class Initialized
INFO - 2026-02-16 02:11:41 --> Config Class Initialized
INFO - 2026-02-16 02:11:41 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:41 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:41 --> Loader Class Initialized
INFO - 2026-02-16 02:11:41 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:41 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:41 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:41 --> Email Class Initialized
INFO - 2026-02-16 02:11:41 --> Controller Class Initialized
INFO - 2026-02-16 02:11:41 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:41 --> Helper loaded: email_helper
ERROR - 2026-02-16 02:11:41 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:11:41 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:41 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:41 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:41 --> Upload Class Initialized
DEBUG - 2026-02-16 02:11:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:41 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:41 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:41 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:41 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:41 --> Email Class Initialized
INFO - 2026-02-16 02:11:41 --> Controller Class Initialized
ERROR - 2026-02-16 02:11:41 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:42 --> Upload Class Initialized
DEBUG - 2026-02-16 02:11:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:42 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:42 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:42 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:42 --> Email Class Initialized
INFO - 2026-02-16 02:11:42 --> Controller Class Initialized
ERROR - 2026-02-16 02:11:42 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:42 --> Upload Class Initialized
DEBUG - 2026-02-16 02:11:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:42 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:42 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:42 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:42 --> Email Class Initialized
INFO - 2026-02-16 02:11:42 --> Controller Class Initialized
DEBUG - 2026-02-16 02:11:42 --> Cart MX_Controller Initialized
INFO - 2026-02-16 02:11:42 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:11:42 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:11:42 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:11:42 --> Model "Common_model" initialized
INFO - 2026-02-16 02:11:42 --> Model "Order_model" initialized
INFO - 2026-02-16 02:11:42 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 02:11:42 --> Final output sent to browser
DEBUG - 2026-02-16 02:11:42 --> Total execution time: 2.0701
INFO - 2026-02-16 02:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:42 --> Upload Class Initialized
DEBUG - 2026-02-16 02:11:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:42 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:42 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:42 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:42 --> Email Class Initialized
INFO - 2026-02-16 02:11:42 --> Controller Class Initialized
ERROR - 2026-02-16 02:11:42 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:11:53 --> Config Class Initialized
INFO - 2026-02-16 02:11:53 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:11:53 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:53 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:53 --> URI Class Initialized
INFO - 2026-02-16 02:11:53 --> Router Class Initialized
INFO - 2026-02-16 02:11:53 --> Output Class Initialized
INFO - 2026-02-16 02:11:53 --> Security Class Initialized
DEBUG - 2026-02-16 02:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:53 --> CSRF cookie sent
INFO - 2026-02-16 02:11:53 --> CSRF token verified
INFO - 2026-02-16 02:11:53 --> Input Class Initialized
INFO - 2026-02-16 02:11:53 --> Language Class Initialized
INFO - 2026-02-16 02:11:53 --> Language Class Initialized
INFO - 2026-02-16 02:11:53 --> Config Class Initialized
INFO - 2026-02-16 02:11:53 --> Loader Class Initialized
INFO - 2026-02-16 02:11:53 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:53 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:53 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:53 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:53 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:53 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:53 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:53 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:54 --> Database Driver Class Initialized
INFO - 2026-02-16 02:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:11:55 --> Upload Class Initialized
DEBUG - 2026-02-16 02:11:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:11:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:11:55 --> Encryption Class Initialized
INFO - 2026-02-16 02:11:55 --> Form Validation Class Initialized
INFO - 2026-02-16 02:11:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:11:55 --> Pagination Class Initialized
INFO - 2026-02-16 02:11:55 --> Email Class Initialized
INFO - 2026-02-16 02:11:55 --> Controller Class Initialized
DEBUG - 2026-02-16 02:11:55 --> Auth MX_Controller Initialized
INFO - 2026-02-16 02:11:55 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:11:55 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:11:55 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:11:55 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 02:11:59 --> Config Class Initialized
INFO - 2026-02-16 02:11:59 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:11:59 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:11:59 --> Utf8 Class Initialized
INFO - 2026-02-16 02:11:59 --> URI Class Initialized
INFO - 2026-02-16 02:11:59 --> Router Class Initialized
INFO - 2026-02-16 02:11:59 --> Output Class Initialized
INFO - 2026-02-16 02:11:59 --> Security Class Initialized
DEBUG - 2026-02-16 02:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:11:59 --> CSRF cookie sent
INFO - 2026-02-16 02:11:59 --> Input Class Initialized
INFO - 2026-02-16 02:11:59 --> Language Class Initialized
INFO - 2026-02-16 02:11:59 --> Language Class Initialized
INFO - 2026-02-16 02:11:59 --> Config Class Initialized
INFO - 2026-02-16 02:11:59 --> Loader Class Initialized
INFO - 2026-02-16 02:11:59 --> Helper loaded: url_helper
INFO - 2026-02-16 02:11:59 --> Helper loaded: form_helper
INFO - 2026-02-16 02:11:59 --> Helper loaded: html_helper
INFO - 2026-02-16 02:11:59 --> Helper loaded: file_helper
INFO - 2026-02-16 02:11:59 --> Helper loaded: email_helper
INFO - 2026-02-16 02:11:59 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:11:59 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:11:59 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:11:59 --> Database Driver Class Initialized
INFO - 2026-02-16 02:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:12:01 --> Upload Class Initialized
DEBUG - 2026-02-16 02:12:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:12:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:12:01 --> Encryption Class Initialized
INFO - 2026-02-16 02:12:01 --> Form Validation Class Initialized
INFO - 2026-02-16 02:12:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:12:01 --> Pagination Class Initialized
INFO - 2026-02-16 02:12:01 --> Email Class Initialized
INFO - 2026-02-16 02:12:01 --> Controller Class Initialized
DEBUG - 2026-02-16 02:12:01 --> Clientarea MX_Controller Initialized
INFO - 2026-02-16 02:12:01 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:12:01 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:12:01 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:12:01 --> Model "Clientarea_model" initialized
INFO - 2026-02-16 02:12:01 --> Model "Billing_model" initialized
INFO - 2026-02-16 02:12:01 --> Model "Common_model" initialized
INFO - 2026-02-16 02:12:01 --> Model "Order_model" initialized
INFO - 2026-02-16 02:12:01 --> Model "Support_model" initialized
DEBUG - 2026-02-16 02:12:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-16 02:12:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-16 02:12:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-16 02:12:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_index.php
INFO - 2026-02-16 02:12:01 --> Final output sent to browser
DEBUG - 2026-02-16 02:12:01 --> Total execution time: 2.1103
INFO - 2026-02-16 02:12:01 --> Config Class Initialized
INFO - 2026-02-16 02:12:01 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:12:01 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:12:01 --> Utf8 Class Initialized
INFO - 2026-02-16 02:12:01 --> Config Class Initialized
INFO - 2026-02-16 02:12:01 --> Hooks Class Initialized
INFO - 2026-02-16 02:12:01 --> URI Class Initialized
DEBUG - 2026-02-16 02:12:01 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:12:01 --> Utf8 Class Initialized
INFO - 2026-02-16 02:12:01 --> URI Class Initialized
INFO - 2026-02-16 02:12:01 --> Router Class Initialized
INFO - 2026-02-16 02:12:01 --> Output Class Initialized
INFO - 2026-02-16 02:12:01 --> Router Class Initialized
INFO - 2026-02-16 02:12:01 --> Config Class Initialized
INFO - 2026-02-16 02:12:01 --> Hooks Class Initialized
INFO - 2026-02-16 02:12:01 --> Output Class Initialized
DEBUG - 2026-02-16 02:12:01 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:12:01 --> Utf8 Class Initialized
INFO - 2026-02-16 02:12:01 --> Security Class Initialized
INFO - 2026-02-16 02:12:01 --> URI Class Initialized
INFO - 2026-02-16 02:12:01 --> Security Class Initialized
DEBUG - 2026-02-16 02:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:12:01 --> CSRF cookie sent
INFO - 2026-02-16 02:12:01 --> Input Class Initialized
INFO - 2026-02-16 02:12:01 --> Language Class Initialized
INFO - 2026-02-16 02:12:01 --> Router Class Initialized
DEBUG - 2026-02-16 02:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:12:01 --> CSRF cookie sent
INFO - 2026-02-16 02:12:01 --> Input Class Initialized
INFO - 2026-02-16 02:12:01 --> Output Class Initialized
INFO - 2026-02-16 02:12:01 --> Language Class Initialized
INFO - 2026-02-16 02:12:01 --> Config Class Initialized
INFO - 2026-02-16 02:12:01 --> Security Class Initialized
INFO - 2026-02-16 02:12:01 --> Language Class Initialized
DEBUG - 2026-02-16 02:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:12:01 --> CSRF cookie sent
INFO - 2026-02-16 02:12:01 --> Input Class Initialized
INFO - 2026-02-16 02:12:01 --> Language Class Initialized
INFO - 2026-02-16 02:12:01 --> Language Class Initialized
INFO - 2026-02-16 02:12:01 --> Config Class Initialized
INFO - 2026-02-16 02:12:01 --> Loader Class Initialized
INFO - 2026-02-16 02:12:01 --> Language Class Initialized
INFO - 2026-02-16 02:12:01 --> Config Class Initialized
INFO - 2026-02-16 02:12:01 --> Helper loaded: url_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: form_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: html_helper
INFO - 2026-02-16 02:12:01 --> Loader Class Initialized
INFO - 2026-02-16 02:12:01 --> Helper loaded: file_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: email_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: url_helper
INFO - 2026-02-16 02:12:01 --> Config Class Initialized
INFO - 2026-02-16 02:12:01 --> Hooks Class Initialized
INFO - 2026-02-16 02:12:01 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: form_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: html_helper
INFO - 2026-02-16 02:12:01 --> Loader Class Initialized
INFO - 2026-02-16 02:12:01 --> Helper loaded: file_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: email_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:12:01 --> Config Class Initialized
INFO - 2026-02-16 02:12:01 --> Hooks Class Initialized
INFO - 2026-02-16 02:12:01 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: url_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: form_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: html_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: file_helper
DEBUG - 2026-02-16 02:12:01 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:12:01 --> Utf8 Class Initialized
INFO - 2026-02-16 02:12:01 --> Helper loaded: email_helper
INFO - 2026-02-16 02:12:01 --> URI Class Initialized
INFO - 2026-02-16 02:12:01 --> Config Class Initialized
INFO - 2026-02-16 02:12:01 --> Hooks Class Initialized
INFO - 2026-02-16 02:12:01 --> Database Driver Class Initialized
INFO - 2026-02-16 02:12:01 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:12:01 --> Router Class Initialized
DEBUG - 2026-02-16 02:12:01 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:12:01 --> Utf8 Class Initialized
INFO - 2026-02-16 02:12:01 --> URI Class Initialized
DEBUG - 2026-02-16 02:12:01 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:12:01 --> Utf8 Class Initialized
INFO - 2026-02-16 02:12:01 --> Output Class Initialized
INFO - 2026-02-16 02:12:01 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:12:01 --> Database Driver Class Initialized
INFO - 2026-02-16 02:12:01 --> URI Class Initialized
INFO - 2026-02-16 02:12:01 --> Router Class Initialized
INFO - 2026-02-16 02:12:01 --> Output Class Initialized
INFO - 2026-02-16 02:12:01 --> Router Class Initialized
INFO - 2026-02-16 02:12:01 --> Security Class Initialized
INFO - 2026-02-16 02:12:01 --> Output Class Initialized
DEBUG - 2026-02-16 02:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:12:01 --> CSRF cookie sent
INFO - 2026-02-16 02:12:01 --> Input Class Initialized
INFO - 2026-02-16 02:12:01 --> Security Class Initialized
INFO - 2026-02-16 02:12:01 --> Language Class Initialized
INFO - 2026-02-16 02:12:01 --> Language Class Initialized
INFO - 2026-02-16 02:12:01 --> Config Class Initialized
DEBUG - 2026-02-16 02:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:12:01 --> CSRF cookie sent
INFO - 2026-02-16 02:12:01 --> Input Class Initialized
INFO - 2026-02-16 02:12:01 --> Language Class Initialized
INFO - 2026-02-16 02:12:01 --> Security Class Initialized
INFO - 2026-02-16 02:12:01 --> Language Class Initialized
INFO - 2026-02-16 02:12:01 --> Config Class Initialized
DEBUG - 2026-02-16 02:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:12:01 --> CSRF cookie sent
INFO - 2026-02-16 02:12:01 --> Input Class Initialized
INFO - 2026-02-16 02:12:01 --> Loader Class Initialized
INFO - 2026-02-16 02:12:01 --> Language Class Initialized
INFO - 2026-02-16 02:12:01 --> Helper loaded: url_helper
INFO - 2026-02-16 02:12:01 --> Language Class Initialized
INFO - 2026-02-16 02:12:01 --> Config Class Initialized
INFO - 2026-02-16 02:12:01 --> Loader Class Initialized
INFO - 2026-02-16 02:12:01 --> Helper loaded: form_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: url_helper
INFO - 2026-02-16 02:12:01 --> Database Driver Class Initialized
INFO - 2026-02-16 02:12:01 --> Helper loaded: html_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: file_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: email_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: form_helper
INFO - 2026-02-16 02:12:01 --> Loader Class Initialized
INFO - 2026-02-16 02:12:01 --> Helper loaded: html_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: file_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: url_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: email_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: form_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: html_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: file_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: email_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:12:01 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:12:01 --> Database Driver Class Initialized
INFO - 2026-02-16 02:12:01 --> Database Driver Class Initialized
INFO - 2026-02-16 02:12:01 --> Database Driver Class Initialized
INFO - 2026-02-16 02:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:12:03 --> Upload Class Initialized
DEBUG - 2026-02-16 02:12:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:12:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:12:03 --> Encryption Class Initialized
INFO - 2026-02-16 02:12:03 --> Form Validation Class Initialized
INFO - 2026-02-16 02:12:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:12:03 --> Pagination Class Initialized
INFO - 2026-02-16 02:12:03 --> Email Class Initialized
INFO - 2026-02-16 02:12:03 --> Controller Class Initialized
ERROR - 2026-02-16 02:12:03 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:12:03 --> Upload Class Initialized
DEBUG - 2026-02-16 02:12:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:12:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:12:03 --> Encryption Class Initialized
INFO - 2026-02-16 02:12:03 --> Form Validation Class Initialized
INFO - 2026-02-16 02:12:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:12:03 --> Pagination Class Initialized
INFO - 2026-02-16 02:12:03 --> Config Class Initialized
INFO - 2026-02-16 02:12:03 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:12:03 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:12:03 --> Utf8 Class Initialized
INFO - 2026-02-16 02:12:03 --> URI Class Initialized
INFO - 2026-02-16 02:12:03 --> Email Class Initialized
INFO - 2026-02-16 02:12:03 --> Controller Class Initialized
ERROR - 2026-02-16 02:12:03 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:12:03 --> Router Class Initialized
INFO - 2026-02-16 02:12:03 --> Output Class Initialized
INFO - 2026-02-16 02:12:03 --> Security Class Initialized
DEBUG - 2026-02-16 02:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:12:03 --> CSRF cookie sent
INFO - 2026-02-16 02:12:03 --> Input Class Initialized
INFO - 2026-02-16 02:12:03 --> Language Class Initialized
INFO - 2026-02-16 02:12:03 --> Language Class Initialized
INFO - 2026-02-16 02:12:03 --> Config Class Initialized
INFO - 2026-02-16 02:12:03 --> Loader Class Initialized
INFO - 2026-02-16 02:12:03 --> Helper loaded: url_helper
INFO - 2026-02-16 02:12:03 --> Helper loaded: form_helper
INFO - 2026-02-16 02:12:03 --> Helper loaded: html_helper
INFO - 2026-02-16 02:12:03 --> Helper loaded: file_helper
INFO - 2026-02-16 02:12:03 --> Helper loaded: email_helper
INFO - 2026-02-16 02:12:03 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:12:03 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:12:03 --> Config Class Initialized
INFO - 2026-02-16 02:12:03 --> Hooks Class Initialized
INFO - 2026-02-16 02:12:03 --> Helper loaded: cpanel_helper
DEBUG - 2026-02-16 02:12:03 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:12:03 --> Utf8 Class Initialized
INFO - 2026-02-16 02:12:03 --> URI Class Initialized
INFO - 2026-02-16 02:12:03 --> Router Class Initialized
INFO - 2026-02-16 02:12:03 --> Output Class Initialized
INFO - 2026-02-16 02:12:03 --> Database Driver Class Initialized
INFO - 2026-02-16 02:12:03 --> Security Class Initialized
DEBUG - 2026-02-16 02:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:12:03 --> Input Class Initialized
INFO - 2026-02-16 02:12:03 --> Language Class Initialized
INFO - 2026-02-16 02:12:03 --> Language Class Initialized
INFO - 2026-02-16 02:12:03 --> Config Class Initialized
INFO - 2026-02-16 02:12:03 --> Loader Class Initialized
INFO - 2026-02-16 02:12:03 --> Helper loaded: url_helper
INFO - 2026-02-16 02:12:03 --> Helper loaded: form_helper
INFO - 2026-02-16 02:12:03 --> Helper loaded: html_helper
INFO - 2026-02-16 02:12:03 --> Helper loaded: file_helper
INFO - 2026-02-16 02:12:03 --> Helper loaded: email_helper
INFO - 2026-02-16 02:12:03 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:12:03 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:12:03 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:12:03 --> Database Driver Class Initialized
INFO - 2026-02-16 02:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:12:04 --> Upload Class Initialized
DEBUG - 2026-02-16 02:12:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:12:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:12:04 --> Encryption Class Initialized
INFO - 2026-02-16 02:12:04 --> Form Validation Class Initialized
INFO - 2026-02-16 02:12:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:12:04 --> Pagination Class Initialized
INFO - 2026-02-16 02:12:04 --> Email Class Initialized
INFO - 2026-02-16 02:12:04 --> Controller Class Initialized
ERROR - 2026-02-16 02:12:04 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:12:04 --> Upload Class Initialized
DEBUG - 2026-02-16 02:12:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:12:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:12:04 --> Encryption Class Initialized
INFO - 2026-02-16 02:12:04 --> Form Validation Class Initialized
INFO - 2026-02-16 02:12:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:12:04 --> Pagination Class Initialized
INFO - 2026-02-16 02:12:04 --> Config Class Initialized
INFO - 2026-02-16 02:12:04 --> Hooks Class Initialized
INFO - 2026-02-16 02:12:04 --> Email Class Initialized
INFO - 2026-02-16 02:12:04 --> Controller Class Initialized
ERROR - 2026-02-16 02:12:04 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:12:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-02-16 02:12:04 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:12:04 --> Utf8 Class Initialized
INFO - 2026-02-16 02:12:04 --> URI Class Initialized
INFO - 2026-02-16 02:12:04 --> Upload Class Initialized
INFO - 2026-02-16 02:12:04 --> Router Class Initialized
DEBUG - 2026-02-16 02:12:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:12:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:12:04 --> Encryption Class Initialized
INFO - 2026-02-16 02:12:04 --> Output Class Initialized
INFO - 2026-02-16 02:12:04 --> Form Validation Class Initialized
INFO - 2026-02-16 02:12:04 --> Security Class Initialized
INFO - 2026-02-16 02:12:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:12:04 --> Pagination Class Initialized
DEBUG - 2026-02-16 02:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:12:04 --> Input Class Initialized
INFO - 2026-02-16 02:12:04 --> Language Class Initialized
INFO - 2026-02-16 02:12:04 --> Language Class Initialized
INFO - 2026-02-16 02:12:04 --> Config Class Initialized
INFO - 2026-02-16 02:12:04 --> Email Class Initialized
INFO - 2026-02-16 02:12:04 --> Controller Class Initialized
ERROR - 2026-02-16 02:12:04 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:12:04 --> Loader Class Initialized
INFO - 2026-02-16 02:12:04 --> Helper loaded: url_helper
INFO - 2026-02-16 02:12:04 --> Helper loaded: form_helper
INFO - 2026-02-16 02:12:04 --> Helper loaded: html_helper
INFO - 2026-02-16 02:12:04 --> Helper loaded: file_helper
INFO - 2026-02-16 02:12:04 --> Helper loaded: email_helper
INFO - 2026-02-16 02:12:04 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:12:04 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:12:04 --> Config Class Initialized
INFO - 2026-02-16 02:12:04 --> Hooks Class Initialized
INFO - 2026-02-16 02:12:04 --> Helper loaded: cpanel_helper
DEBUG - 2026-02-16 02:12:04 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:12:04 --> Utf8 Class Initialized
INFO - 2026-02-16 02:12:04 --> Database Driver Class Initialized
INFO - 2026-02-16 02:12:04 --> URI Class Initialized
INFO - 2026-02-16 02:12:04 --> Router Class Initialized
INFO - 2026-02-16 02:12:04 --> Output Class Initialized
INFO - 2026-02-16 02:12:04 --> Config Class Initialized
INFO - 2026-02-16 02:12:04 --> Hooks Class Initialized
INFO - 2026-02-16 02:12:04 --> Security Class Initialized
DEBUG - 2026-02-16 02:12:04 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:12:04 --> Utf8 Class Initialized
INFO - 2026-02-16 02:12:04 --> URI Class Initialized
DEBUG - 2026-02-16 02:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:12:04 --> Input Class Initialized
INFO - 2026-02-16 02:12:04 --> Router Class Initialized
INFO - 2026-02-16 02:12:04 --> Language Class Initialized
INFO - 2026-02-16 02:12:04 --> Output Class Initialized
INFO - 2026-02-16 02:12:04 --> Language Class Initialized
INFO - 2026-02-16 02:12:04 --> Config Class Initialized
INFO - 2026-02-16 02:12:04 --> Security Class Initialized
DEBUG - 2026-02-16 02:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:12:04 --> CSRF cookie sent
INFO - 2026-02-16 02:12:04 --> Input Class Initialized
INFO - 2026-02-16 02:12:04 --> Language Class Initialized
INFO - 2026-02-16 02:12:04 --> Loader Class Initialized
INFO - 2026-02-16 02:12:04 --> Language Class Initialized
INFO - 2026-02-16 02:12:04 --> Config Class Initialized
INFO - 2026-02-16 02:12:04 --> Helper loaded: url_helper
INFO - 2026-02-16 02:12:04 --> Loader Class Initialized
INFO - 2026-02-16 02:12:04 --> Helper loaded: form_helper
INFO - 2026-02-16 02:12:04 --> Helper loaded: url_helper
INFO - 2026-02-16 02:12:04 --> Helper loaded: html_helper
INFO - 2026-02-16 02:12:04 --> Helper loaded: file_helper
INFO - 2026-02-16 02:12:04 --> Helper loaded: form_helper
INFO - 2026-02-16 02:12:04 --> Helper loaded: email_helper
INFO - 2026-02-16 02:12:04 --> Helper loaded: html_helper
INFO - 2026-02-16 02:12:04 --> Helper loaded: file_helper
INFO - 2026-02-16 02:12:04 --> Helper loaded: email_helper
INFO - 2026-02-16 02:12:04 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:12:04 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:12:04 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:12:04 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:12:04 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:12:04 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:12:04 --> Database Driver Class Initialized
INFO - 2026-02-16 02:12:04 --> Database Driver Class Initialized
INFO - 2026-02-16 02:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:12:05 --> Upload Class Initialized
DEBUG - 2026-02-16 02:12:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:12:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:12:05 --> Encryption Class Initialized
INFO - 2026-02-16 02:12:05 --> Form Validation Class Initialized
INFO - 2026-02-16 02:12:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:12:05 --> Pagination Class Initialized
INFO - 2026-02-16 02:12:05 --> Email Class Initialized
INFO - 2026-02-16 02:12:05 --> Controller Class Initialized
DEBUG - 2026-02-16 02:12:05 --> Clientarea MX_Controller Initialized
INFO - 2026-02-16 02:12:05 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:12:05 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:12:05 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:12:05 --> Model "Clientarea_model" initialized
INFO - 2026-02-16 02:12:05 --> Model "Billing_model" initialized
INFO - 2026-02-16 02:12:05 --> Model "Common_model" initialized
INFO - 2026-02-16 02:12:05 --> Model "Order_model" initialized
INFO - 2026-02-16 02:12:05 --> Model "Support_model" initialized
INFO - 2026-02-16 02:12:06 --> Final output sent to browser
DEBUG - 2026-02-16 02:12:06 --> Total execution time: 2.5422
INFO - 2026-02-16 02:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:12:06 --> Upload Class Initialized
DEBUG - 2026-02-16 02:12:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:12:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:12:06 --> Encryption Class Initialized
INFO - 2026-02-16 02:12:06 --> Form Validation Class Initialized
INFO - 2026-02-16 02:12:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:12:06 --> Pagination Class Initialized
INFO - 2026-02-16 02:12:06 --> Config Class Initialized
INFO - 2026-02-16 02:12:06 --> Hooks Class Initialized
INFO - 2026-02-16 02:12:06 --> Email Class Initialized
INFO - 2026-02-16 02:12:06 --> Controller Class Initialized
ERROR - 2026-02-16 02:12:06 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:12:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-02-16 02:12:06 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:12:06 --> Utf8 Class Initialized
INFO - 2026-02-16 02:12:06 --> URI Class Initialized
INFO - 2026-02-16 02:12:06 --> Upload Class Initialized
INFO - 2026-02-16 02:12:06 --> Router Class Initialized
DEBUG - 2026-02-16 02:12:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:12:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:12:06 --> Encryption Class Initialized
INFO - 2026-02-16 02:12:06 --> Output Class Initialized
INFO - 2026-02-16 02:12:06 --> Security Class Initialized
INFO - 2026-02-16 02:12:06 --> Form Validation Class Initialized
DEBUG - 2026-02-16 02:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:12:06 --> CSRF cookie sent
INFO - 2026-02-16 02:12:06 --> Input Class Initialized
INFO - 2026-02-16 02:12:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:12:06 --> Language Class Initialized
INFO - 2026-02-16 02:12:06 --> Pagination Class Initialized
INFO - 2026-02-16 02:12:06 --> Language Class Initialized
INFO - 2026-02-16 02:12:06 --> Config Class Initialized
INFO - 2026-02-16 02:12:06 --> Loader Class Initialized
INFO - 2026-02-16 02:12:06 --> Email Class Initialized
INFO - 2026-02-16 02:12:06 --> Controller Class Initialized
INFO - 2026-02-16 02:12:06 --> Helper loaded: url_helper
INFO - 2026-02-16 02:12:06 --> Helper loaded: form_helper
DEBUG - 2026-02-16 02:12:06 --> Cart MX_Controller Initialized
INFO - 2026-02-16 02:12:06 --> Helper loaded: html_helper
INFO - 2026-02-16 02:12:06 --> Helper loaded: file_helper
INFO - 2026-02-16 02:12:06 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:12:06 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:12:06 --> Helper loaded: email_helper
INFO - 2026-02-16 02:12:06 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:12:06 --> Model "Common_model" initialized
INFO - 2026-02-16 02:12:06 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:12:06 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:12:06 --> Model "Order_model" initialized
INFO - 2026-02-16 02:12:06 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 02:12:06 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:12:06 --> Database Driver Class Initialized
INFO - 2026-02-16 02:12:06 --> Final output sent to browser
DEBUG - 2026-02-16 02:12:06 --> Total execution time: 2.9600
INFO - 2026-02-16 02:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:12:07 --> Upload Class Initialized
DEBUG - 2026-02-16 02:12:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:12:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:12:07 --> Encryption Class Initialized
INFO - 2026-02-16 02:12:07 --> Form Validation Class Initialized
INFO - 2026-02-16 02:12:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:12:07 --> Pagination Class Initialized
INFO - 2026-02-16 02:12:07 --> Email Class Initialized
INFO - 2026-02-16 02:12:07 --> Controller Class Initialized
DEBUG - 2026-02-16 02:12:07 --> Tickets MX_Controller Initialized
INFO - 2026-02-16 02:12:07 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:12:07 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:12:07 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:12:07 --> Model "Support_model" initialized
INFO - 2026-02-16 02:12:07 --> Model "Common_model" initialized
INFO - 2026-02-16 02:12:07 --> Final output sent to browser
DEBUG - 2026-02-16 02:12:07 --> Total execution time: 3.3575
INFO - 2026-02-16 02:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:12:07 --> Upload Class Initialized
DEBUG - 2026-02-16 02:12:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:12:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:12:07 --> Encryption Class Initialized
INFO - 2026-02-16 02:12:07 --> Form Validation Class Initialized
INFO - 2026-02-16 02:12:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:12:07 --> Pagination Class Initialized
INFO - 2026-02-16 02:12:07 --> Email Class Initialized
INFO - 2026-02-16 02:12:07 --> Controller Class Initialized
DEBUG - 2026-02-16 02:12:07 --> Billing MX_Controller Initialized
INFO - 2026-02-16 02:12:07 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:12:07 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:12:07 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:12:07 --> Model "Billing_model" initialized
INFO - 2026-02-16 02:12:07 --> Model "Common_model" initialized
INFO - 2026-02-16 02:12:07 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 02:12:08 --> Final output sent to browser
DEBUG - 2026-02-16 02:12:08 --> Total execution time: 4.1664
INFO - 2026-02-16 02:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:12:08 --> Upload Class Initialized
DEBUG - 2026-02-16 02:12:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:12:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:12:08 --> Encryption Class Initialized
INFO - 2026-02-16 02:12:08 --> Form Validation Class Initialized
INFO - 2026-02-16 02:12:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:12:08 --> Pagination Class Initialized
INFO - 2026-02-16 02:12:08 --> Email Class Initialized
INFO - 2026-02-16 02:12:08 --> Controller Class Initialized
ERROR - 2026-02-16 02:12:08 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:12:10 --> Upload Class Initialized
DEBUG - 2026-02-16 02:12:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:12:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:12:10 --> Encryption Class Initialized
INFO - 2026-02-16 02:12:10 --> Form Validation Class Initialized
INFO - 2026-02-16 02:12:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:12:10 --> Pagination Class Initialized
INFO - 2026-02-16 02:12:10 --> Email Class Initialized
INFO - 2026-02-16 02:12:10 --> Controller Class Initialized
ERROR - 2026-02-16 02:12:10 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:12:45 --> Config Class Initialized
INFO - 2026-02-16 02:12:45 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:12:45 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:12:45 --> Utf8 Class Initialized
INFO - 2026-02-16 02:12:45 --> URI Class Initialized
INFO - 2026-02-16 02:12:45 --> Router Class Initialized
INFO - 2026-02-16 02:12:45 --> Output Class Initialized
INFO - 2026-02-16 02:12:45 --> Security Class Initialized
DEBUG - 2026-02-16 02:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:12:45 --> CSRF cookie sent
INFO - 2026-02-16 02:12:45 --> Input Class Initialized
INFO - 2026-02-16 02:12:45 --> Language Class Initialized
INFO - 2026-02-16 02:12:45 --> Language Class Initialized
INFO - 2026-02-16 02:12:45 --> Config Class Initialized
INFO - 2026-02-16 02:12:45 --> Loader Class Initialized
INFO - 2026-02-16 02:12:45 --> Helper loaded: url_helper
INFO - 2026-02-16 02:12:45 --> Helper loaded: form_helper
INFO - 2026-02-16 02:12:45 --> Helper loaded: html_helper
INFO - 2026-02-16 02:12:45 --> Helper loaded: file_helper
INFO - 2026-02-16 02:12:45 --> Helper loaded: email_helper
INFO - 2026-02-16 02:12:45 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:12:45 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:12:45 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:12:45 --> Database Driver Class Initialized
INFO - 2026-02-16 02:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:12:47 --> Upload Class Initialized
DEBUG - 2026-02-16 02:12:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:12:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:12:47 --> Encryption Class Initialized
INFO - 2026-02-16 02:12:47 --> Form Validation Class Initialized
INFO - 2026-02-16 02:12:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:12:47 --> Pagination Class Initialized
INFO - 2026-02-16 02:12:47 --> Email Class Initialized
INFO - 2026-02-16 02:12:47 --> Controller Class Initialized
DEBUG - 2026-02-16 02:12:47 --> Billing MX_Controller Initialized
INFO - 2026-02-16 02:12:47 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:12:47 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:12:47 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:12:47 --> Model "Billing_model" initialized
INFO - 2026-02-16 02:12:47 --> Model "Common_model" initialized
INFO - 2026-02-16 02:12:47 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 02:12:47 --> Config Class Initialized
INFO - 2026-02-16 02:12:47 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:12:47 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:12:47 --> Utf8 Class Initialized
INFO - 2026-02-16 02:12:47 --> URI Class Initialized
INFO - 2026-02-16 02:12:47 --> Router Class Initialized
INFO - 2026-02-16 02:12:47 --> Output Class Initialized
INFO - 2026-02-16 02:12:47 --> Security Class Initialized
DEBUG - 2026-02-16 02:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:12:47 --> CSRF cookie sent
INFO - 2026-02-16 02:12:47 --> Input Class Initialized
INFO - 2026-02-16 02:12:47 --> Language Class Initialized
INFO - 2026-02-16 02:12:47 --> Language Class Initialized
INFO - 2026-02-16 02:12:47 --> Config Class Initialized
INFO - 2026-02-16 02:12:47 --> Loader Class Initialized
INFO - 2026-02-16 02:12:47 --> Helper loaded: url_helper
INFO - 2026-02-16 02:12:47 --> Helper loaded: form_helper
INFO - 2026-02-16 02:12:47 --> Helper loaded: html_helper
INFO - 2026-02-16 02:12:47 --> Helper loaded: file_helper
INFO - 2026-02-16 02:12:47 --> Helper loaded: email_helper
INFO - 2026-02-16 02:12:47 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:12:47 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:12:47 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:12:47 --> Database Driver Class Initialized
DEBUG - 2026-02-16 02:12:48 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-16 02:12:48 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-02-16 02:12:48 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-16 02:12:48 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-16 02:12:48 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_invoices.php
INFO - 2026-02-16 02:12:48 --> Final output sent to browser
DEBUG - 2026-02-16 02:12:48 --> Total execution time: 3.3133
INFO - 2026-02-16 02:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:12:49 --> Upload Class Initialized
DEBUG - 2026-02-16 02:12:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:12:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:12:49 --> Encryption Class Initialized
INFO - 2026-02-16 02:12:49 --> Form Validation Class Initialized
INFO - 2026-02-16 02:12:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:12:49 --> Pagination Class Initialized
INFO - 2026-02-16 02:12:49 --> Email Class Initialized
INFO - 2026-02-16 02:12:49 --> Controller Class Initialized
DEBUG - 2026-02-16 02:12:49 --> Billing MX_Controller Initialized
INFO - 2026-02-16 02:12:49 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:12:49 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:12:49 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:12:49 --> Model "Billing_model" initialized
INFO - 2026-02-16 02:12:49 --> Model "Common_model" initialized
INFO - 2026-02-16 02:12:49 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-16 02:12:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-16 02:12:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-02-16 02:12:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-16 02:12:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-16 02:12:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_invoices.php
INFO - 2026-02-16 02:12:50 --> Final output sent to browser
DEBUG - 2026-02-16 02:12:50 --> Total execution time: 3.1894
INFO - 2026-02-16 02:12:50 --> Config Class Initialized
INFO - 2026-02-16 02:12:50 --> Hooks Class Initialized
INFO - 2026-02-16 02:12:50 --> Config Class Initialized
INFO - 2026-02-16 02:12:50 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:12:50 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:12:50 --> Utf8 Class Initialized
INFO - 2026-02-16 02:12:50 --> URI Class Initialized
DEBUG - 2026-02-16 02:12:50 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:12:50 --> Utf8 Class Initialized
INFO - 2026-02-16 02:12:50 --> URI Class Initialized
INFO - 2026-02-16 02:12:50 --> Router Class Initialized
INFO - 2026-02-16 02:12:50 --> Output Class Initialized
INFO - 2026-02-16 02:12:50 --> Security Class Initialized
DEBUG - 2026-02-16 02:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:12:50 --> CSRF cookie sent
INFO - 2026-02-16 02:12:50 --> Input Class Initialized
INFO - 2026-02-16 02:12:50 --> Language Class Initialized
INFO - 2026-02-16 02:12:50 --> Language Class Initialized
INFO - 2026-02-16 02:12:50 --> Config Class Initialized
INFO - 2026-02-16 02:12:50 --> Router Class Initialized
INFO - 2026-02-16 02:12:50 --> Loader Class Initialized
INFO - 2026-02-16 02:12:50 --> Output Class Initialized
INFO - 2026-02-16 02:12:50 --> Helper loaded: url_helper
INFO - 2026-02-16 02:12:50 --> Helper loaded: form_helper
INFO - 2026-02-16 02:12:50 --> Helper loaded: html_helper
INFO - 2026-02-16 02:12:50 --> Security Class Initialized
INFO - 2026-02-16 02:12:50 --> Helper loaded: file_helper
INFO - 2026-02-16 02:12:50 --> Helper loaded: email_helper
DEBUG - 2026-02-16 02:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:12:50 --> CSRF cookie sent
INFO - 2026-02-16 02:12:50 --> Input Class Initialized
INFO - 2026-02-16 02:12:50 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:12:50 --> Language Class Initialized
INFO - 2026-02-16 02:12:50 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:12:50 --> Language Class Initialized
INFO - 2026-02-16 02:12:50 --> Config Class Initialized
INFO - 2026-02-16 02:12:50 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:12:50 --> Loader Class Initialized
INFO - 2026-02-16 02:12:50 --> Helper loaded: url_helper
INFO - 2026-02-16 02:12:50 --> Helper loaded: form_helper
INFO - 2026-02-16 02:12:50 --> Helper loaded: html_helper
INFO - 2026-02-16 02:12:50 --> Helper loaded: file_helper
INFO - 2026-02-16 02:12:50 --> Helper loaded: email_helper
INFO - 2026-02-16 02:12:50 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:12:50 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:12:50 --> Database Driver Class Initialized
INFO - 2026-02-16 02:12:50 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:12:50 --> Database Driver Class Initialized
INFO - 2026-02-16 02:12:50 --> Config Class Initialized
INFO - 2026-02-16 02:12:50 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:12:51 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:12:51 --> Utf8 Class Initialized
INFO - 2026-02-16 02:12:51 --> URI Class Initialized
INFO - 2026-02-16 02:12:51 --> Router Class Initialized
INFO - 2026-02-16 02:12:51 --> Output Class Initialized
INFO - 2026-02-16 02:12:51 --> Security Class Initialized
DEBUG - 2026-02-16 02:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:12:51 --> CSRF cookie sent
INFO - 2026-02-16 02:12:51 --> Input Class Initialized
INFO - 2026-02-16 02:12:51 --> Language Class Initialized
INFO - 2026-02-16 02:12:51 --> Language Class Initialized
INFO - 2026-02-16 02:12:51 --> Config Class Initialized
INFO - 2026-02-16 02:12:51 --> Loader Class Initialized
INFO - 2026-02-16 02:12:51 --> Helper loaded: url_helper
INFO - 2026-02-16 02:12:51 --> Helper loaded: form_helper
INFO - 2026-02-16 02:12:51 --> Helper loaded: html_helper
INFO - 2026-02-16 02:12:51 --> Helper loaded: file_helper
INFO - 2026-02-16 02:12:51 --> Helper loaded: email_helper
INFO - 2026-02-16 02:12:51 --> Config Class Initialized
INFO - 2026-02-16 02:12:51 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:12:51 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:12:51 --> Utf8 Class Initialized
INFO - 2026-02-16 02:12:51 --> URI Class Initialized
INFO - 2026-02-16 02:12:51 --> Router Class Initialized
INFO - 2026-02-16 02:12:51 --> Config Class Initialized
INFO - 2026-02-16 02:12:51 --> Hooks Class Initialized
INFO - 2026-02-16 02:12:51 --> Output Class Initialized
INFO - 2026-02-16 02:12:51 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:12:51 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:12:51 --> Security Class Initialized
DEBUG - 2026-02-16 02:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:12:51 --> CSRF cookie sent
INFO - 2026-02-16 02:12:51 --> Input Class Initialized
INFO - 2026-02-16 02:12:51 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:12:51 --> Language Class Initialized
INFO - 2026-02-16 02:12:51 --> Config Class Initialized
INFO - 2026-02-16 02:12:51 --> Hooks Class Initialized
INFO - 2026-02-16 02:12:51 --> Language Class Initialized
INFO - 2026-02-16 02:12:51 --> Config Class Initialized
DEBUG - 2026-02-16 02:12:51 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:12:51 --> Utf8 Class Initialized
INFO - 2026-02-16 02:12:51 --> URI Class Initialized
INFO - 2026-02-16 02:12:51 --> Loader Class Initialized
INFO - 2026-02-16 02:12:51 --> Router Class Initialized
INFO - 2026-02-16 02:12:51 --> Helper loaded: url_helper
DEBUG - 2026-02-16 02:12:51 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:12:51 --> Utf8 Class Initialized
INFO - 2026-02-16 02:12:51 --> Output Class Initialized
INFO - 2026-02-16 02:12:51 --> URI Class Initialized
INFO - 2026-02-16 02:12:51 --> Helper loaded: form_helper
INFO - 2026-02-16 02:12:51 --> Helper loaded: html_helper
INFO - 2026-02-16 02:12:51 --> Security Class Initialized
INFO - 2026-02-16 02:12:51 --> Helper loaded: file_helper
INFO - 2026-02-16 02:12:51 --> Helper loaded: email_helper
INFO - 2026-02-16 02:12:51 --> Router Class Initialized
INFO - 2026-02-16 02:12:51 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:12:51 --> Output Class Initialized
INFO - 2026-02-16 02:12:51 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:12:51 --> Security Class Initialized
INFO - 2026-02-16 02:12:51 --> Helper loaded: cpanel_helper
DEBUG - 2026-02-16 02:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:12:51 --> CSRF cookie sent
INFO - 2026-02-16 02:12:51 --> Input Class Initialized
INFO - 2026-02-16 02:12:51 --> Language Class Initialized
INFO - 2026-02-16 02:12:51 --> Database Driver Class Initialized
INFO - 2026-02-16 02:12:51 --> Language Class Initialized
INFO - 2026-02-16 02:12:51 --> Config Class Initialized
DEBUG - 2026-02-16 02:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:12:51 --> CSRF cookie sent
INFO - 2026-02-16 02:12:51 --> Input Class Initialized
INFO - 2026-02-16 02:12:51 --> Language Class Initialized
INFO - 2026-02-16 02:12:51 --> Language Class Initialized
INFO - 2026-02-16 02:12:51 --> Config Class Initialized
INFO - 2026-02-16 02:12:51 --> Loader Class Initialized
INFO - 2026-02-16 02:12:51 --> Helper loaded: url_helper
INFO - 2026-02-16 02:12:51 --> Loader Class Initialized
INFO - 2026-02-16 02:12:51 --> Database Driver Class Initialized
INFO - 2026-02-16 02:12:51 --> Helper loaded: url_helper
INFO - 2026-02-16 02:12:51 --> Helper loaded: form_helper
INFO - 2026-02-16 02:12:51 --> Helper loaded: html_helper
INFO - 2026-02-16 02:12:51 --> Helper loaded: form_helper
INFO - 2026-02-16 02:12:51 --> Helper loaded: file_helper
INFO - 2026-02-16 02:12:51 --> Helper loaded: email_helper
INFO - 2026-02-16 02:12:51 --> Helper loaded: html_helper
INFO - 2026-02-16 02:12:51 --> Helper loaded: file_helper
INFO - 2026-02-16 02:12:51 --> Helper loaded: email_helper
INFO - 2026-02-16 02:12:51 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:12:51 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:12:51 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:12:51 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:12:51 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:12:51 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:12:51 --> Database Driver Class Initialized
INFO - 2026-02-16 02:12:51 --> Database Driver Class Initialized
INFO - 2026-02-16 02:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:12:52 --> Upload Class Initialized
DEBUG - 2026-02-16 02:12:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:12:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:12:52 --> Encryption Class Initialized
INFO - 2026-02-16 02:12:52 --> Form Validation Class Initialized
INFO - 2026-02-16 02:12:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:12:52 --> Pagination Class Initialized
INFO - 2026-02-16 02:12:52 --> Email Class Initialized
INFO - 2026-02-16 02:12:52 --> Controller Class Initialized
ERROR - 2026-02-16 02:12:52 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:12:52 --> Upload Class Initialized
DEBUG - 2026-02-16 02:12:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:12:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:12:52 --> Encryption Class Initialized
INFO - 2026-02-16 02:12:52 --> Form Validation Class Initialized
INFO - 2026-02-16 02:12:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:12:52 --> Pagination Class Initialized
INFO - 2026-02-16 02:12:52 --> Email Class Initialized
INFO - 2026-02-16 02:12:52 --> Controller Class Initialized
ERROR - 2026-02-16 02:12:52 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:12:52 --> Upload Class Initialized
DEBUG - 2026-02-16 02:12:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:12:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:12:52 --> Encryption Class Initialized
INFO - 2026-02-16 02:12:52 --> Form Validation Class Initialized
INFO - 2026-02-16 02:12:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:12:52 --> Pagination Class Initialized
INFO - 2026-02-16 02:12:52 --> Config Class Initialized
INFO - 2026-02-16 02:12:52 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:12:52 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:12:52 --> Utf8 Class Initialized
INFO - 2026-02-16 02:12:52 --> URI Class Initialized
INFO - 2026-02-16 02:12:52 --> Email Class Initialized
INFO - 2026-02-16 02:12:52 --> Controller Class Initialized
ERROR - 2026-02-16 02:12:52 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:12:52 --> Router Class Initialized
INFO - 2026-02-16 02:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:12:52 --> Output Class Initialized
INFO - 2026-02-16 02:12:52 --> Config Class Initialized
INFO - 2026-02-16 02:12:52 --> Hooks Class Initialized
INFO - 2026-02-16 02:12:52 --> Security Class Initialized
INFO - 2026-02-16 02:12:52 --> Upload Class Initialized
DEBUG - 2026-02-16 02:12:52 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:12:52 --> Utf8 Class Initialized
DEBUG - 2026-02-16 02:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:12:52 --> CSRF cookie sent
INFO - 2026-02-16 02:12:52 --> Input Class Initialized
INFO - 2026-02-16 02:12:52 --> URI Class Initialized
INFO - 2026-02-16 02:12:52 --> Language Class Initialized
DEBUG - 2026-02-16 02:12:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:12:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:12:52 --> Encryption Class Initialized
INFO - 2026-02-16 02:12:52 --> Language Class Initialized
INFO - 2026-02-16 02:12:52 --> Config Class Initialized
INFO - 2026-02-16 02:12:52 --> Router Class Initialized
INFO - 2026-02-16 02:12:52 --> Form Validation Class Initialized
INFO - 2026-02-16 02:12:52 --> Output Class Initialized
INFO - 2026-02-16 02:12:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:12:52 --> Pagination Class Initialized
INFO - 2026-02-16 02:12:52 --> Loader Class Initialized
INFO - 2026-02-16 02:12:52 --> Security Class Initialized
INFO - 2026-02-16 02:12:52 --> Helper loaded: url_helper
DEBUG - 2026-02-16 02:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:12:52 --> CSRF cookie sent
INFO - 2026-02-16 02:12:52 --> Input Class Initialized
INFO - 2026-02-16 02:12:52 --> Language Class Initialized
INFO - 2026-02-16 02:12:52 --> Helper loaded: form_helper
INFO - 2026-02-16 02:12:52 --> Email Class Initialized
INFO - 2026-02-16 02:12:52 --> Language Class Initialized
INFO - 2026-02-16 02:12:52 --> Controller Class Initialized
INFO - 2026-02-16 02:12:52 --> Config Class Initialized
INFO - 2026-02-16 02:12:52 --> Helper loaded: html_helper
ERROR - 2026-02-16 02:12:52 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:12:52 --> Helper loaded: file_helper
INFO - 2026-02-16 02:12:52 --> Helper loaded: email_helper
INFO - 2026-02-16 02:12:52 --> Loader Class Initialized
INFO - 2026-02-16 02:12:52 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:12:52 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:12:52 --> Helper loaded: url_helper
INFO - 2026-02-16 02:12:52 --> Helper loaded: form_helper
INFO - 2026-02-16 02:12:52 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:12:52 --> Helper loaded: html_helper
INFO - 2026-02-16 02:12:52 --> Helper loaded: file_helper
INFO - 2026-02-16 02:12:52 --> Helper loaded: email_helper
INFO - 2026-02-16 02:12:52 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:12:52 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:12:52 --> Config Class Initialized
INFO - 2026-02-16 02:12:52 --> Hooks Class Initialized
INFO - 2026-02-16 02:12:52 --> Helper loaded: cpanel_helper
DEBUG - 2026-02-16 02:12:52 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:12:52 --> Utf8 Class Initialized
INFO - 2026-02-16 02:12:52 --> URI Class Initialized
INFO - 2026-02-16 02:12:52 --> Database Driver Class Initialized
INFO - 2026-02-16 02:12:52 --> Router Class Initialized
INFO - 2026-02-16 02:12:52 --> Database Driver Class Initialized
INFO - 2026-02-16 02:12:52 --> Output Class Initialized
INFO - 2026-02-16 02:12:52 --> Security Class Initialized
DEBUG - 2026-02-16 02:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:12:52 --> CSRF cookie sent
INFO - 2026-02-16 02:12:52 --> Input Class Initialized
INFO - 2026-02-16 02:12:52 --> Language Class Initialized
INFO - 2026-02-16 02:12:52 --> Language Class Initialized
INFO - 2026-02-16 02:12:52 --> Config Class Initialized
INFO - 2026-02-16 02:12:52 --> Loader Class Initialized
INFO - 2026-02-16 02:12:52 --> Helper loaded: url_helper
INFO - 2026-02-16 02:12:52 --> Helper loaded: form_helper
INFO - 2026-02-16 02:12:52 --> Helper loaded: html_helper
INFO - 2026-02-16 02:12:52 --> Helper loaded: file_helper
INFO - 2026-02-16 02:12:52 --> Helper loaded: email_helper
INFO - 2026-02-16 02:12:52 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:12:52 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:12:52 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:12:52 --> Database Driver Class Initialized
INFO - 2026-02-16 02:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:12:53 --> Upload Class Initialized
DEBUG - 2026-02-16 02:12:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:12:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:12:53 --> Encryption Class Initialized
INFO - 2026-02-16 02:12:53 --> Form Validation Class Initialized
INFO - 2026-02-16 02:12:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:12:53 --> Pagination Class Initialized
INFO - 2026-02-16 02:12:53 --> Email Class Initialized
INFO - 2026-02-16 02:12:53 --> Controller Class Initialized
ERROR - 2026-02-16 02:12:53 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:12:53 --> Upload Class Initialized
DEBUG - 2026-02-16 02:12:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:12:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:12:53 --> Encryption Class Initialized
INFO - 2026-02-16 02:12:53 --> Form Validation Class Initialized
INFO - 2026-02-16 02:12:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:12:53 --> Pagination Class Initialized
INFO - 2026-02-16 02:12:53 --> Email Class Initialized
INFO - 2026-02-16 02:12:53 --> Controller Class Initialized
ERROR - 2026-02-16 02:12:53 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:12:54 --> Upload Class Initialized
DEBUG - 2026-02-16 02:12:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:12:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:12:54 --> Encryption Class Initialized
INFO - 2026-02-16 02:12:54 --> Form Validation Class Initialized
INFO - 2026-02-16 02:12:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:12:54 --> Pagination Class Initialized
INFO - 2026-02-16 02:12:54 --> Email Class Initialized
INFO - 2026-02-16 02:12:54 --> Controller Class Initialized
DEBUG - 2026-02-16 02:12:54 --> Cart MX_Controller Initialized
INFO - 2026-02-16 02:12:54 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:12:54 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:12:54 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:12:54 --> Model "Common_model" initialized
INFO - 2026-02-16 02:12:54 --> Model "Order_model" initialized
INFO - 2026-02-16 02:12:54 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 02:12:55 --> Final output sent to browser
DEBUG - 2026-02-16 02:12:55 --> Total execution time: 2.3411
INFO - 2026-02-16 02:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:12:55 --> Upload Class Initialized
DEBUG - 2026-02-16 02:12:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:12:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:12:55 --> Encryption Class Initialized
INFO - 2026-02-16 02:12:55 --> Form Validation Class Initialized
INFO - 2026-02-16 02:12:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:12:55 --> Pagination Class Initialized
INFO - 2026-02-16 02:12:55 --> Email Class Initialized
INFO - 2026-02-16 02:12:55 --> Controller Class Initialized
ERROR - 2026-02-16 02:12:55 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:12:55 --> Upload Class Initialized
DEBUG - 2026-02-16 02:12:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:12:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:12:55 --> Encryption Class Initialized
INFO - 2026-02-16 02:12:55 --> Form Validation Class Initialized
INFO - 2026-02-16 02:12:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:12:55 --> Pagination Class Initialized
INFO - 2026-02-16 02:12:55 --> Email Class Initialized
INFO - 2026-02-16 02:12:55 --> Controller Class Initialized
ERROR - 2026-02-16 02:12:55 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:15:56 --> Config Class Initialized
INFO - 2026-02-16 02:15:56 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:15:56 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:15:56 --> Utf8 Class Initialized
INFO - 2026-02-16 02:15:56 --> URI Class Initialized
INFO - 2026-02-16 02:15:56 --> Router Class Initialized
INFO - 2026-02-16 02:15:56 --> Output Class Initialized
INFO - 2026-02-16 02:15:56 --> Security Class Initialized
DEBUG - 2026-02-16 02:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:15:56 --> CSRF cookie sent
INFO - 2026-02-16 02:15:56 --> Input Class Initialized
INFO - 2026-02-16 02:15:56 --> Language Class Initialized
INFO - 2026-02-16 02:15:56 --> Language Class Initialized
INFO - 2026-02-16 02:15:56 --> Config Class Initialized
INFO - 2026-02-16 02:15:56 --> Loader Class Initialized
INFO - 2026-02-16 02:15:56 --> Helper loaded: url_helper
INFO - 2026-02-16 02:15:56 --> Helper loaded: form_helper
INFO - 2026-02-16 02:15:56 --> Helper loaded: html_helper
INFO - 2026-02-16 02:15:56 --> Helper loaded: file_helper
INFO - 2026-02-16 02:15:56 --> Helper loaded: email_helper
INFO - 2026-02-16 02:15:56 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:15:56 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:15:56 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:15:56 --> Database Driver Class Initialized
INFO - 2026-02-16 02:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:15:58 --> Upload Class Initialized
DEBUG - 2026-02-16 02:15:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:15:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:15:58 --> Encryption Class Initialized
INFO - 2026-02-16 02:15:58 --> Form Validation Class Initialized
INFO - 2026-02-16 02:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:15:58 --> Pagination Class Initialized
INFO - 2026-02-16 02:15:58 --> Email Class Initialized
INFO - 2026-02-16 02:15:58 --> Controller Class Initialized
DEBUG - 2026-02-16 02:15:58 --> Billing MX_Controller Initialized
INFO - 2026-02-16 02:15:58 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:15:58 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:15:58 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:15:58 --> Model "Billing_model" initialized
INFO - 2026-02-16 02:15:58 --> Model "Common_model" initialized
INFO - 2026-02-16 02:15:58 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-16 02:16:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_invoice_pdf_html.php
DEBUG - 2026-02-16 02:16:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-16 02:16:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-02-16 02:16:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-16 02:16:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-16 02:16:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_viewinvoice.php
INFO - 2026-02-16 02:16:00 --> Final output sent to browser
DEBUG - 2026-02-16 02:16:00 --> Total execution time: 4.0389
INFO - 2026-02-16 02:16:00 --> Config Class Initialized
INFO - 2026-02-16 02:16:00 --> Hooks Class Initialized
INFO - 2026-02-16 02:16:00 --> Config Class Initialized
INFO - 2026-02-16 02:16:00 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:16:00 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:16:00 --> Utf8 Class Initialized
DEBUG - 2026-02-16 02:16:00 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:16:00 --> Utf8 Class Initialized
INFO - 2026-02-16 02:16:00 --> URI Class Initialized
INFO - 2026-02-16 02:16:00 --> URI Class Initialized
INFO - 2026-02-16 02:16:00 --> Router Class Initialized
INFO - 2026-02-16 02:16:00 --> Router Class Initialized
INFO - 2026-02-16 02:16:00 --> Output Class Initialized
INFO - 2026-02-16 02:16:00 --> Output Class Initialized
INFO - 2026-02-16 02:16:00 --> Security Class Initialized
INFO - 2026-02-16 02:16:00 --> Security Class Initialized
DEBUG - 2026-02-16 02:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:16:00 --> CSRF cookie sent
INFO - 2026-02-16 02:16:00 --> Input Class Initialized
DEBUG - 2026-02-16 02:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:16:00 --> Language Class Initialized
INFO - 2026-02-16 02:16:00 --> CSRF cookie sent
INFO - 2026-02-16 02:16:00 --> Input Class Initialized
INFO - 2026-02-16 02:16:00 --> Language Class Initialized
INFO - 2026-02-16 02:16:00 --> Language Class Initialized
INFO - 2026-02-16 02:16:00 --> Config Class Initialized
INFO - 2026-02-16 02:16:00 --> Language Class Initialized
INFO - 2026-02-16 02:16:00 --> Config Class Initialized
INFO - 2026-02-16 02:16:00 --> Loader Class Initialized
INFO - 2026-02-16 02:16:00 --> Loader Class Initialized
INFO - 2026-02-16 02:16:00 --> Helper loaded: url_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: url_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: form_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: form_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: html_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: html_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: file_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: file_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: email_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: email_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:16:00 --> Database Driver Class Initialized
INFO - 2026-02-16 02:16:00 --> Database Driver Class Initialized
INFO - 2026-02-16 02:16:00 --> Config Class Initialized
INFO - 2026-02-16 02:16:00 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:16:00 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:16:00 --> Utf8 Class Initialized
INFO - 2026-02-16 02:16:00 --> URI Class Initialized
INFO - 2026-02-16 02:16:00 --> Router Class Initialized
INFO - 2026-02-16 02:16:00 --> Output Class Initialized
INFO - 2026-02-16 02:16:00 --> Security Class Initialized
DEBUG - 2026-02-16 02:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:16:00 --> CSRF cookie sent
INFO - 2026-02-16 02:16:00 --> Input Class Initialized
INFO - 2026-02-16 02:16:00 --> Language Class Initialized
INFO - 2026-02-16 02:16:00 --> Language Class Initialized
INFO - 2026-02-16 02:16:00 --> Config Class Initialized
INFO - 2026-02-16 02:16:00 --> Loader Class Initialized
INFO - 2026-02-16 02:16:00 --> Helper loaded: url_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: form_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: html_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: file_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: email_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:16:00 --> Database Driver Class Initialized
INFO - 2026-02-16 02:16:00 --> Config Class Initialized
INFO - 2026-02-16 02:16:00 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:16:00 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:16:00 --> Utf8 Class Initialized
INFO - 2026-02-16 02:16:00 --> URI Class Initialized
INFO - 2026-02-16 02:16:00 --> Router Class Initialized
INFO - 2026-02-16 02:16:00 --> Output Class Initialized
INFO - 2026-02-16 02:16:00 --> Security Class Initialized
DEBUG - 2026-02-16 02:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:16:00 --> CSRF cookie sent
INFO - 2026-02-16 02:16:00 --> Input Class Initialized
INFO - 2026-02-16 02:16:00 --> Language Class Initialized
INFO - 2026-02-16 02:16:00 --> Language Class Initialized
INFO - 2026-02-16 02:16:00 --> Config Class Initialized
INFO - 2026-02-16 02:16:00 --> Loader Class Initialized
INFO - 2026-02-16 02:16:00 --> Helper loaded: url_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: form_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: html_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: file_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: email_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:16:00 --> Database Driver Class Initialized
INFO - 2026-02-16 02:16:00 --> Config Class Initialized
INFO - 2026-02-16 02:16:00 --> Hooks Class Initialized
INFO - 2026-02-16 02:16:00 --> Config Class Initialized
INFO - 2026-02-16 02:16:00 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:16:00 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:16:00 --> Utf8 Class Initialized
INFO - 2026-02-16 02:16:00 --> URI Class Initialized
DEBUG - 2026-02-16 02:16:00 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:16:00 --> Utf8 Class Initialized
INFO - 2026-02-16 02:16:00 --> URI Class Initialized
INFO - 2026-02-16 02:16:00 --> Router Class Initialized
INFO - 2026-02-16 02:16:00 --> Output Class Initialized
INFO - 2026-02-16 02:16:00 --> Router Class Initialized
INFO - 2026-02-16 02:16:00 --> Security Class Initialized
DEBUG - 2026-02-16 02:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:16:00 --> CSRF cookie sent
INFO - 2026-02-16 02:16:00 --> Input Class Initialized
INFO - 2026-02-16 02:16:00 --> Language Class Initialized
INFO - 2026-02-16 02:16:00 --> Output Class Initialized
INFO - 2026-02-16 02:16:00 --> Language Class Initialized
INFO - 2026-02-16 02:16:00 --> Config Class Initialized
INFO - 2026-02-16 02:16:00 --> Security Class Initialized
DEBUG - 2026-02-16 02:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:16:00 --> CSRF cookie sent
INFO - 2026-02-16 02:16:00 --> Input Class Initialized
INFO - 2026-02-16 02:16:00 --> Loader Class Initialized
INFO - 2026-02-16 02:16:00 --> Language Class Initialized
INFO - 2026-02-16 02:16:00 --> Helper loaded: url_helper
INFO - 2026-02-16 02:16:00 --> Language Class Initialized
INFO - 2026-02-16 02:16:00 --> Config Class Initialized
INFO - 2026-02-16 02:16:00 --> Helper loaded: form_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: html_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: file_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: email_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:16:00 --> Loader Class Initialized
INFO - 2026-02-16 02:16:00 --> Helper loaded: url_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: form_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: html_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: file_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: email_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:16:00 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:16:00 --> Database Driver Class Initialized
INFO - 2026-02-16 02:16:00 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:16:00 --> Database Driver Class Initialized
INFO - 2026-02-16 02:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:16:02 --> Upload Class Initialized
DEBUG - 2026-02-16 02:16:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:16:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:16:02 --> Encryption Class Initialized
INFO - 2026-02-16 02:16:02 --> Form Validation Class Initialized
INFO - 2026-02-16 02:16:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:16:02 --> Pagination Class Initialized
INFO - 2026-02-16 02:16:02 --> Email Class Initialized
INFO - 2026-02-16 02:16:02 --> Controller Class Initialized
ERROR - 2026-02-16 02:16:02 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:16:02 --> Upload Class Initialized
DEBUG - 2026-02-16 02:16:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:16:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:16:02 --> Encryption Class Initialized
INFO - 2026-02-16 02:16:02 --> Form Validation Class Initialized
INFO - 2026-02-16 02:16:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:16:02 --> Pagination Class Initialized
INFO - 2026-02-16 02:16:02 --> Config Class Initialized
INFO - 2026-02-16 02:16:02 --> Hooks Class Initialized
INFO - 2026-02-16 02:16:02 --> Email Class Initialized
DEBUG - 2026-02-16 02:16:02 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:16:02 --> Utf8 Class Initialized
INFO - 2026-02-16 02:16:02 --> Controller Class Initialized
ERROR - 2026-02-16 02:16:02 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:16:02 --> URI Class Initialized
INFO - 2026-02-16 02:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:16:02 --> Upload Class Initialized
INFO - 2026-02-16 02:16:02 --> Router Class Initialized
INFO - 2026-02-16 02:16:02 --> Output Class Initialized
DEBUG - 2026-02-16 02:16:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:16:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:16:02 --> Encryption Class Initialized
INFO - 2026-02-16 02:16:02 --> Security Class Initialized
DEBUG - 2026-02-16 02:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:16:02 --> CSRF cookie sent
INFO - 2026-02-16 02:16:02 --> Input Class Initialized
INFO - 2026-02-16 02:16:02 --> Form Validation Class Initialized
INFO - 2026-02-16 02:16:02 --> Language Class Initialized
INFO - 2026-02-16 02:16:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:16:02 --> Pagination Class Initialized
INFO - 2026-02-16 02:16:02 --> Language Class Initialized
INFO - 2026-02-16 02:16:02 --> Config Class Initialized
INFO - 2026-02-16 02:16:02 --> Loader Class Initialized
INFO - 2026-02-16 02:16:02 --> Email Class Initialized
INFO - 2026-02-16 02:16:02 --> Controller Class Initialized
ERROR - 2026-02-16 02:16:02 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:16:02 --> Helper loaded: url_helper
INFO - 2026-02-16 02:16:02 --> Config Class Initialized
INFO - 2026-02-16 02:16:02 --> Hooks Class Initialized
INFO - 2026-02-16 02:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:16:02 --> Helper loaded: form_helper
DEBUG - 2026-02-16 02:16:02 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:16:02 --> Utf8 Class Initialized
INFO - 2026-02-16 02:16:02 --> Helper loaded: html_helper
INFO - 2026-02-16 02:16:02 --> Upload Class Initialized
INFO - 2026-02-16 02:16:02 --> URI Class Initialized
INFO - 2026-02-16 02:16:02 --> Helper loaded: file_helper
INFO - 2026-02-16 02:16:02 --> Helper loaded: email_helper
INFO - 2026-02-16 02:16:02 --> Router Class Initialized
DEBUG - 2026-02-16 02:16:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:16:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:16:02 --> Encryption Class Initialized
INFO - 2026-02-16 02:16:02 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:16:02 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:16:02 --> Output Class Initialized
INFO - 2026-02-16 02:16:02 --> Security Class Initialized
INFO - 2026-02-16 02:16:02 --> Form Validation Class Initialized
INFO - 2026-02-16 02:16:02 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:16:02 --> Config Class Initialized
DEBUG - 2026-02-16 02:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:16:02 --> Hooks Class Initialized
INFO - 2026-02-16 02:16:02 --> CSRF cookie sent
INFO - 2026-02-16 02:16:02 --> Input Class Initialized
INFO - 2026-02-16 02:16:02 --> Language Class Initialized
INFO - 2026-02-16 02:16:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:16:02 --> Language Class Initialized
INFO - 2026-02-16 02:16:02 --> Pagination Class Initialized
INFO - 2026-02-16 02:16:02 --> Config Class Initialized
DEBUG - 2026-02-16 02:16:02 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:16:02 --> Utf8 Class Initialized
INFO - 2026-02-16 02:16:02 --> URI Class Initialized
INFO - 2026-02-16 02:16:02 --> Router Class Initialized
INFO - 2026-02-16 02:16:02 --> Loader Class Initialized
INFO - 2026-02-16 02:16:02 --> Helper loaded: url_helper
INFO - 2026-02-16 02:16:02 --> Output Class Initialized
INFO - 2026-02-16 02:16:02 --> Email Class Initialized
INFO - 2026-02-16 02:16:02 --> Controller Class Initialized
INFO - 2026-02-16 02:16:02 --> Helper loaded: form_helper
INFO - 2026-02-16 02:16:02 --> Security Class Initialized
INFO - 2026-02-16 02:16:02 --> Helper loaded: html_helper
ERROR - 2026-02-16 02:16:02 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:16:02 --> Helper loaded: file_helper
INFO - 2026-02-16 02:16:02 --> Helper loaded: email_helper
DEBUG - 2026-02-16 02:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:16:02 --> CSRF cookie sent
INFO - 2026-02-16 02:16:02 --> Input Class Initialized
INFO - 2026-02-16 02:16:02 --> Language Class Initialized
INFO - 2026-02-16 02:16:02 --> Database Driver Class Initialized
INFO - 2026-02-16 02:16:02 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:16:02 --> Language Class Initialized
INFO - 2026-02-16 02:16:02 --> Upload Class Initialized
INFO - 2026-02-16 02:16:02 --> Config Class Initialized
INFO - 2026-02-16 02:16:02 --> Helper loaded: ssp_helper
DEBUG - 2026-02-16 02:16:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:16:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:16:02 --> Encryption Class Initialized
INFO - 2026-02-16 02:16:02 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:16:02 --> Loader Class Initialized
INFO - 2026-02-16 02:16:02 --> Form Validation Class Initialized
INFO - 2026-02-16 02:16:02 --> Helper loaded: url_helper
INFO - 2026-02-16 02:16:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:16:02 --> Pagination Class Initialized
INFO - 2026-02-16 02:16:02 --> Helper loaded: form_helper
INFO - 2026-02-16 02:16:02 --> Helper loaded: html_helper
INFO - 2026-02-16 02:16:02 --> Helper loaded: file_helper
INFO - 2026-02-16 02:16:02 --> Helper loaded: email_helper
INFO - 2026-02-16 02:16:02 --> Email Class Initialized
INFO - 2026-02-16 02:16:02 --> Controller Class Initialized
INFO - 2026-02-16 02:16:02 --> Database Driver Class Initialized
ERROR - 2026-02-16 02:16:02 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:16:02 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:16:02 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:16:02 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:16:02 --> Upload Class Initialized
DEBUG - 2026-02-16 02:16:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:16:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:16:02 --> Encryption Class Initialized
INFO - 2026-02-16 02:16:02 --> Form Validation Class Initialized
INFO - 2026-02-16 02:16:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:16:02 --> Pagination Class Initialized
INFO - 2026-02-16 02:16:02 --> Database Driver Class Initialized
INFO - 2026-02-16 02:16:02 --> Email Class Initialized
INFO - 2026-02-16 02:16:02 --> Controller Class Initialized
ERROR - 2026-02-16 02:16:02 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:16:03 --> Config Class Initialized
INFO - 2026-02-16 02:16:03 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:16:03 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:16:03 --> Utf8 Class Initialized
INFO - 2026-02-16 02:16:03 --> URI Class Initialized
INFO - 2026-02-16 02:16:03 --> Router Class Initialized
INFO - 2026-02-16 02:16:03 --> Output Class Initialized
INFO - 2026-02-16 02:16:03 --> Security Class Initialized
DEBUG - 2026-02-16 02:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:16:03 --> CSRF cookie sent
INFO - 2026-02-16 02:16:03 --> Input Class Initialized
INFO - 2026-02-16 02:16:03 --> Language Class Initialized
INFO - 2026-02-16 02:16:03 --> Language Class Initialized
INFO - 2026-02-16 02:16:03 --> Config Class Initialized
INFO - 2026-02-16 02:16:03 --> Loader Class Initialized
INFO - 2026-02-16 02:16:03 --> Helper loaded: url_helper
INFO - 2026-02-16 02:16:03 --> Helper loaded: form_helper
INFO - 2026-02-16 02:16:03 --> Helper loaded: html_helper
INFO - 2026-02-16 02:16:03 --> Helper loaded: file_helper
INFO - 2026-02-16 02:16:03 --> Helper loaded: email_helper
INFO - 2026-02-16 02:16:03 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:16:03 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:16:03 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:16:03 --> Database Driver Class Initialized
INFO - 2026-02-16 02:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:16:04 --> Upload Class Initialized
DEBUG - 2026-02-16 02:16:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:16:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:16:04 --> Encryption Class Initialized
INFO - 2026-02-16 02:16:04 --> Form Validation Class Initialized
INFO - 2026-02-16 02:16:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:16:04 --> Pagination Class Initialized
INFO - 2026-02-16 02:16:04 --> Email Class Initialized
INFO - 2026-02-16 02:16:04 --> Controller Class Initialized
DEBUG - 2026-02-16 02:16:04 --> Cart MX_Controller Initialized
INFO - 2026-02-16 02:16:04 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:16:04 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:16:04 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:16:04 --> Model "Common_model" initialized
INFO - 2026-02-16 02:16:04 --> Model "Order_model" initialized
INFO - 2026-02-16 02:16:04 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 02:16:04 --> Final output sent to browser
DEBUG - 2026-02-16 02:16:04 --> Total execution time: 2.2334
INFO - 2026-02-16 02:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:16:04 --> Upload Class Initialized
DEBUG - 2026-02-16 02:16:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:16:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:16:04 --> Encryption Class Initialized
INFO - 2026-02-16 02:16:04 --> Form Validation Class Initialized
INFO - 2026-02-16 02:16:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:16:04 --> Pagination Class Initialized
INFO - 2026-02-16 02:16:04 --> Email Class Initialized
INFO - 2026-02-16 02:16:04 --> Controller Class Initialized
ERROR - 2026-02-16 02:16:04 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:16:04 --> Upload Class Initialized
DEBUG - 2026-02-16 02:16:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:16:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:16:04 --> Encryption Class Initialized
INFO - 2026-02-16 02:16:04 --> Form Validation Class Initialized
INFO - 2026-02-16 02:16:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:16:04 --> Pagination Class Initialized
INFO - 2026-02-16 02:16:04 --> Email Class Initialized
INFO - 2026-02-16 02:16:04 --> Controller Class Initialized
ERROR - 2026-02-16 02:16:04 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:16:05 --> Upload Class Initialized
DEBUG - 2026-02-16 02:16:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:16:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:16:05 --> Encryption Class Initialized
INFO - 2026-02-16 02:16:05 --> Form Validation Class Initialized
INFO - 2026-02-16 02:16:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:16:05 --> Pagination Class Initialized
INFO - 2026-02-16 02:16:05 --> Email Class Initialized
INFO - 2026-02-16 02:16:05 --> Controller Class Initialized
DEBUG - 2026-02-16 02:16:05 --> Pay MX_Controller Initialized
INFO - 2026-02-16 02:16:05 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:16:05 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:16:05 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:16:05 --> Model "Payment_model" initialized
INFO - 2026-02-16 02:16:05 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-16 02:16:05 --> Model "Billing_model" initialized
INFO - 2026-02-16 02:16:05 --> Model "Invoice_model" initialized
DEBUG - 2026-02-16 02:16:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-16 02:16:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-16 02:16:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-16 02:16:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_pay.php
INFO - 2026-02-16 02:16:07 --> Final output sent to browser
DEBUG - 2026-02-16 02:16:07 --> Total execution time: 4.3137
INFO - 2026-02-16 02:16:07 --> Config Class Initialized
INFO - 2026-02-16 02:16:07 --> Hooks Class Initialized
INFO - 2026-02-16 02:16:07 --> Config Class Initialized
INFO - 2026-02-16 02:16:07 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:16:07 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:16:07 --> Utf8 Class Initialized
DEBUG - 2026-02-16 02:16:07 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:16:07 --> Utf8 Class Initialized
INFO - 2026-02-16 02:16:07 --> URI Class Initialized
INFO - 2026-02-16 02:16:07 --> URI Class Initialized
INFO - 2026-02-16 02:16:07 --> Router Class Initialized
INFO - 2026-02-16 02:16:07 --> Router Class Initialized
INFO - 2026-02-16 02:16:07 --> Output Class Initialized
INFO - 2026-02-16 02:16:07 --> Output Class Initialized
INFO - 2026-02-16 02:16:07 --> Security Class Initialized
INFO - 2026-02-16 02:16:07 --> Security Class Initialized
DEBUG - 2026-02-16 02:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:16:07 --> CSRF cookie sent
INFO - 2026-02-16 02:16:07 --> Input Class Initialized
INFO - 2026-02-16 02:16:07 --> Language Class Initialized
INFO - 2026-02-16 02:16:07 --> Language Class Initialized
INFO - 2026-02-16 02:16:07 --> Config Class Initialized
DEBUG - 2026-02-16 02:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:16:07 --> CSRF cookie sent
INFO - 2026-02-16 02:16:07 --> Input Class Initialized
INFO - 2026-02-16 02:16:07 --> Language Class Initialized
INFO - 2026-02-16 02:16:07 --> Language Class Initialized
INFO - 2026-02-16 02:16:07 --> Config Class Initialized
INFO - 2026-02-16 02:16:07 --> Loader Class Initialized
INFO - 2026-02-16 02:16:07 --> Helper loaded: url_helper
INFO - 2026-02-16 02:16:07 --> Helper loaded: form_helper
INFO - 2026-02-16 02:16:07 --> Helper loaded: html_helper
INFO - 2026-02-16 02:16:07 --> Loader Class Initialized
INFO - 2026-02-16 02:16:07 --> Helper loaded: file_helper
INFO - 2026-02-16 02:16:07 --> Helper loaded: email_helper
INFO - 2026-02-16 02:16:07 --> Helper loaded: url_helper
INFO - 2026-02-16 02:16:07 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:16:07 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:16:07 --> Helper loaded: form_helper
INFO - 2026-02-16 02:16:07 --> Helper loaded: html_helper
INFO - 2026-02-16 02:16:07 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:16:07 --> Helper loaded: file_helper
INFO - 2026-02-16 02:16:07 --> Helper loaded: email_helper
INFO - 2026-02-16 02:16:07 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:16:07 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:16:07 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:16:07 --> Database Driver Class Initialized
INFO - 2026-02-16 02:16:07 --> Database Driver Class Initialized
INFO - 2026-02-16 02:16:08 --> Config Class Initialized
INFO - 2026-02-16 02:16:08 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:16:08 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:16:08 --> Utf8 Class Initialized
INFO - 2026-02-16 02:16:08 --> URI Class Initialized
INFO - 2026-02-16 02:16:08 --> Router Class Initialized
INFO - 2026-02-16 02:16:08 --> Output Class Initialized
INFO - 2026-02-16 02:16:08 --> Security Class Initialized
DEBUG - 2026-02-16 02:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:16:08 --> CSRF cookie sent
INFO - 2026-02-16 02:16:08 --> Input Class Initialized
INFO - 2026-02-16 02:16:08 --> Language Class Initialized
INFO - 2026-02-16 02:16:08 --> Language Class Initialized
INFO - 2026-02-16 02:16:08 --> Config Class Initialized
INFO - 2026-02-16 02:16:08 --> Loader Class Initialized
INFO - 2026-02-16 02:16:08 --> Helper loaded: url_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: form_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: html_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: file_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: email_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:16:08 --> Database Driver Class Initialized
INFO - 2026-02-16 02:16:08 --> Config Class Initialized
INFO - 2026-02-16 02:16:08 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:16:08 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:16:08 --> Utf8 Class Initialized
INFO - 2026-02-16 02:16:08 --> URI Class Initialized
INFO - 2026-02-16 02:16:08 --> Router Class Initialized
INFO - 2026-02-16 02:16:08 --> Output Class Initialized
INFO - 2026-02-16 02:16:08 --> Security Class Initialized
DEBUG - 2026-02-16 02:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:16:08 --> CSRF cookie sent
INFO - 2026-02-16 02:16:08 --> Input Class Initialized
INFO - 2026-02-16 02:16:08 --> Language Class Initialized
INFO - 2026-02-16 02:16:08 --> Language Class Initialized
INFO - 2026-02-16 02:16:08 --> Config Class Initialized
INFO - 2026-02-16 02:16:08 --> Loader Class Initialized
INFO - 2026-02-16 02:16:08 --> Helper loaded: url_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: form_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: html_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: file_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: email_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:16:08 --> Database Driver Class Initialized
INFO - 2026-02-16 02:16:08 --> Config Class Initialized
INFO - 2026-02-16 02:16:08 --> Hooks Class Initialized
INFO - 2026-02-16 02:16:08 --> Config Class Initialized
INFO - 2026-02-16 02:16:08 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:16:08 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:16:08 --> Utf8 Class Initialized
DEBUG - 2026-02-16 02:16:08 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:16:08 --> Utf8 Class Initialized
INFO - 2026-02-16 02:16:08 --> URI Class Initialized
INFO - 2026-02-16 02:16:08 --> URI Class Initialized
INFO - 2026-02-16 02:16:08 --> Router Class Initialized
INFO - 2026-02-16 02:16:08 --> Router Class Initialized
INFO - 2026-02-16 02:16:08 --> Output Class Initialized
INFO - 2026-02-16 02:16:08 --> Output Class Initialized
INFO - 2026-02-16 02:16:08 --> Security Class Initialized
INFO - 2026-02-16 02:16:08 --> Security Class Initialized
DEBUG - 2026-02-16 02:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:16:08 --> CSRF cookie sent
INFO - 2026-02-16 02:16:08 --> Input Class Initialized
DEBUG - 2026-02-16 02:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:16:08 --> CSRF cookie sent
INFO - 2026-02-16 02:16:08 --> Input Class Initialized
INFO - 2026-02-16 02:16:08 --> Language Class Initialized
INFO - 2026-02-16 02:16:08 --> Language Class Initialized
INFO - 2026-02-16 02:16:08 --> Language Class Initialized
INFO - 2026-02-16 02:16:08 --> Config Class Initialized
INFO - 2026-02-16 02:16:08 --> Language Class Initialized
INFO - 2026-02-16 02:16:08 --> Config Class Initialized
INFO - 2026-02-16 02:16:08 --> Loader Class Initialized
INFO - 2026-02-16 02:16:08 --> Loader Class Initialized
INFO - 2026-02-16 02:16:08 --> Helper loaded: url_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: url_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: form_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: html_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: form_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: file_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: html_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: email_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: file_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: email_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:16:08 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:16:08 --> Database Driver Class Initialized
INFO - 2026-02-16 02:16:08 --> Database Driver Class Initialized
INFO - 2026-02-16 02:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:16:09 --> Upload Class Initialized
DEBUG - 2026-02-16 02:16:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:16:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:16:09 --> Encryption Class Initialized
INFO - 2026-02-16 02:16:09 --> Form Validation Class Initialized
INFO - 2026-02-16 02:16:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:16:09 --> Pagination Class Initialized
INFO - 2026-02-16 02:16:09 --> Email Class Initialized
INFO - 2026-02-16 02:16:09 --> Controller Class Initialized
ERROR - 2026-02-16 02:16:09 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:16:09 --> Config Class Initialized
INFO - 2026-02-16 02:16:09 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:16:09 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:16:09 --> Utf8 Class Initialized
INFO - 2026-02-16 02:16:09 --> URI Class Initialized
INFO - 2026-02-16 02:16:09 --> Router Class Initialized
INFO - 2026-02-16 02:16:09 --> Output Class Initialized
INFO - 2026-02-16 02:16:09 --> Security Class Initialized
DEBUG - 2026-02-16 02:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:16:09 --> CSRF cookie sent
INFO - 2026-02-16 02:16:09 --> Input Class Initialized
INFO - 2026-02-16 02:16:09 --> Language Class Initialized
INFO - 2026-02-16 02:16:09 --> Language Class Initialized
INFO - 2026-02-16 02:16:09 --> Config Class Initialized
INFO - 2026-02-16 02:16:09 --> Loader Class Initialized
INFO - 2026-02-16 02:16:09 --> Helper loaded: url_helper
INFO - 2026-02-16 02:16:09 --> Helper loaded: form_helper
INFO - 2026-02-16 02:16:09 --> Helper loaded: html_helper
INFO - 2026-02-16 02:16:09 --> Helper loaded: file_helper
INFO - 2026-02-16 02:16:09 --> Helper loaded: email_helper
INFO - 2026-02-16 02:16:09 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:16:09 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:16:09 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:16:09 --> Database Driver Class Initialized
INFO - 2026-02-16 02:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:16:10 --> Upload Class Initialized
DEBUG - 2026-02-16 02:16:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:16:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:16:10 --> Encryption Class Initialized
INFO - 2026-02-16 02:16:10 --> Form Validation Class Initialized
INFO - 2026-02-16 02:16:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:16:10 --> Pagination Class Initialized
INFO - 2026-02-16 02:16:10 --> Email Class Initialized
INFO - 2026-02-16 02:16:10 --> Controller Class Initialized
ERROR - 2026-02-16 02:16:10 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:16:10 --> Upload Class Initialized
DEBUG - 2026-02-16 02:16:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:16:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:16:10 --> Encryption Class Initialized
INFO - 2026-02-16 02:16:10 --> Form Validation Class Initialized
INFO - 2026-02-16 02:16:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:16:10 --> Pagination Class Initialized
INFO - 2026-02-16 02:16:10 --> Config Class Initialized
INFO - 2026-02-16 02:16:10 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:16:10 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:16:10 --> Utf8 Class Initialized
INFO - 2026-02-16 02:16:10 --> Email Class Initialized
INFO - 2026-02-16 02:16:10 --> Controller Class Initialized
INFO - 2026-02-16 02:16:10 --> URI Class Initialized
ERROR - 2026-02-16 02:16:10 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:16:10 --> Router Class Initialized
INFO - 2026-02-16 02:16:10 --> Output Class Initialized
INFO - 2026-02-16 02:16:10 --> Security Class Initialized
DEBUG - 2026-02-16 02:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:16:10 --> CSRF cookie sent
INFO - 2026-02-16 02:16:10 --> Input Class Initialized
INFO - 2026-02-16 02:16:10 --> Language Class Initialized
INFO - 2026-02-16 02:16:10 --> Language Class Initialized
INFO - 2026-02-16 02:16:10 --> Config Class Initialized
INFO - 2026-02-16 02:16:10 --> Config Class Initialized
INFO - 2026-02-16 02:16:10 --> Hooks Class Initialized
INFO - 2026-02-16 02:16:10 --> Loader Class Initialized
DEBUG - 2026-02-16 02:16:10 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:16:10 --> Utf8 Class Initialized
INFO - 2026-02-16 02:16:10 --> Helper loaded: url_helper
INFO - 2026-02-16 02:16:10 --> URI Class Initialized
INFO - 2026-02-16 02:16:10 --> Helper loaded: form_helper
INFO - 2026-02-16 02:16:10 --> Helper loaded: html_helper
INFO - 2026-02-16 02:16:10 --> Router Class Initialized
INFO - 2026-02-16 02:16:10 --> Helper loaded: file_helper
INFO - 2026-02-16 02:16:10 --> Helper loaded: email_helper
INFO - 2026-02-16 02:16:10 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:16:10 --> Output Class Initialized
INFO - 2026-02-16 02:16:10 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:16:10 --> Security Class Initialized
INFO - 2026-02-16 02:16:10 --> Helper loaded: cpanel_helper
DEBUG - 2026-02-16 02:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:16:10 --> CSRF cookie sent
INFO - 2026-02-16 02:16:10 --> Input Class Initialized
INFO - 2026-02-16 02:16:10 --> Language Class Initialized
INFO - 2026-02-16 02:16:10 --> Language Class Initialized
INFO - 2026-02-16 02:16:10 --> Config Class Initialized
INFO - 2026-02-16 02:16:10 --> Loader Class Initialized
INFO - 2026-02-16 02:16:10 --> Helper loaded: url_helper
INFO - 2026-02-16 02:16:10 --> Database Driver Class Initialized
INFO - 2026-02-16 02:16:10 --> Helper loaded: form_helper
INFO - 2026-02-16 02:16:10 --> Helper loaded: html_helper
INFO - 2026-02-16 02:16:10 --> Helper loaded: file_helper
INFO - 2026-02-16 02:16:10 --> Helper loaded: email_helper
INFO - 2026-02-16 02:16:10 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:16:10 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:16:10 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:16:10 --> Database Driver Class Initialized
INFO - 2026-02-16 02:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:16:10 --> Upload Class Initialized
DEBUG - 2026-02-16 02:16:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:16:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:16:10 --> Encryption Class Initialized
INFO - 2026-02-16 02:16:10 --> Form Validation Class Initialized
INFO - 2026-02-16 02:16:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:16:10 --> Pagination Class Initialized
INFO - 2026-02-16 02:16:10 --> Email Class Initialized
INFO - 2026-02-16 02:16:10 --> Controller Class Initialized
ERROR - 2026-02-16 02:16:10 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:16:10 --> Upload Class Initialized
DEBUG - 2026-02-16 02:16:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:16:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:16:10 --> Encryption Class Initialized
INFO - 2026-02-16 02:16:10 --> Form Validation Class Initialized
INFO - 2026-02-16 02:16:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:16:10 --> Pagination Class Initialized
INFO - 2026-02-16 02:16:10 --> Email Class Initialized
INFO - 2026-02-16 02:16:10 --> Controller Class Initialized
ERROR - 2026-02-16 02:16:10 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:16:10 --> Upload Class Initialized
DEBUG - 2026-02-16 02:16:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:16:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:16:10 --> Encryption Class Initialized
INFO - 2026-02-16 02:16:10 --> Form Validation Class Initialized
INFO - 2026-02-16 02:16:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:16:11 --> Pagination Class Initialized
INFO - 2026-02-16 02:16:11 --> Email Class Initialized
INFO - 2026-02-16 02:16:11 --> Controller Class Initialized
ERROR - 2026-02-16 02:16:11 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:16:11 --> Upload Class Initialized
DEBUG - 2026-02-16 02:16:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:16:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:16:11 --> Encryption Class Initialized
INFO - 2026-02-16 02:16:11 --> Form Validation Class Initialized
INFO - 2026-02-16 02:16:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:16:11 --> Pagination Class Initialized
INFO - 2026-02-16 02:16:11 --> Email Class Initialized
INFO - 2026-02-16 02:16:11 --> Controller Class Initialized
DEBUG - 2026-02-16 02:16:11 --> Cart MX_Controller Initialized
INFO - 2026-02-16 02:16:11 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:16:11 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:16:11 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:16:11 --> Model "Common_model" initialized
INFO - 2026-02-16 02:16:11 --> Model "Order_model" initialized
INFO - 2026-02-16 02:16:11 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 02:16:12 --> Final output sent to browser
DEBUG - 2026-02-16 02:16:12 --> Total execution time: 2.2340
INFO - 2026-02-16 02:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:16:12 --> Upload Class Initialized
DEBUG - 2026-02-16 02:16:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:16:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:16:12 --> Encryption Class Initialized
INFO - 2026-02-16 02:16:12 --> Form Validation Class Initialized
INFO - 2026-02-16 02:16:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:16:12 --> Pagination Class Initialized
INFO - 2026-02-16 02:16:12 --> Email Class Initialized
INFO - 2026-02-16 02:16:12 --> Controller Class Initialized
ERROR - 2026-02-16 02:16:12 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:16:12 --> Upload Class Initialized
DEBUG - 2026-02-16 02:16:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:16:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:16:12 --> Encryption Class Initialized
INFO - 2026-02-16 02:16:12 --> Form Validation Class Initialized
INFO - 2026-02-16 02:16:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:16:12 --> Pagination Class Initialized
INFO - 2026-02-16 02:16:12 --> Email Class Initialized
INFO - 2026-02-16 02:16:12 --> Controller Class Initialized
ERROR - 2026-02-16 02:16:12 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:22:33 --> Config Class Initialized
INFO - 2026-02-16 02:22:33 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:22:33 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:22:33 --> Utf8 Class Initialized
INFO - 2026-02-16 02:22:33 --> URI Class Initialized
INFO - 2026-02-16 02:22:33 --> Router Class Initialized
INFO - 2026-02-16 02:22:33 --> Output Class Initialized
INFO - 2026-02-16 02:22:33 --> Security Class Initialized
DEBUG - 2026-02-16 02:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:22:33 --> CSRF cookie sent
INFO - 2026-02-16 02:22:33 --> Input Class Initialized
INFO - 2026-02-16 02:22:33 --> Language Class Initialized
INFO - 2026-02-16 02:22:33 --> Language Class Initialized
INFO - 2026-02-16 02:22:33 --> Config Class Initialized
INFO - 2026-02-16 02:22:33 --> Loader Class Initialized
INFO - 2026-02-16 02:22:33 --> Helper loaded: url_helper
INFO - 2026-02-16 02:22:33 --> Helper loaded: form_helper
INFO - 2026-02-16 02:22:33 --> Helper loaded: html_helper
INFO - 2026-02-16 02:22:33 --> Helper loaded: file_helper
INFO - 2026-02-16 02:22:33 --> Helper loaded: email_helper
INFO - 2026-02-16 02:22:33 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:22:33 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:22:33 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:22:33 --> Database Driver Class Initialized
INFO - 2026-02-16 02:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:22:36 --> Upload Class Initialized
DEBUG - 2026-02-16 02:22:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:22:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:22:36 --> Encryption Class Initialized
INFO - 2026-02-16 02:22:36 --> Form Validation Class Initialized
INFO - 2026-02-16 02:22:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:22:36 --> Pagination Class Initialized
INFO - 2026-02-16 02:22:36 --> Email Class Initialized
INFO - 2026-02-16 02:22:36 --> Controller Class Initialized
DEBUG - 2026-02-16 02:22:36 --> Pay MX_Controller Initialized
INFO - 2026-02-16 02:22:36 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:22:36 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:22:36 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:22:36 --> Model "Payment_model" initialized
INFO - 2026-02-16 02:22:36 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-16 02:22:36 --> Model "Billing_model" initialized
INFO - 2026-02-16 02:22:36 --> Model "Invoice_model" initialized
DEBUG - 2026-02-16 02:22:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-16 02:22:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-16 02:22:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-16 02:22:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_pay.php
INFO - 2026-02-16 02:22:38 --> Final output sent to browser
DEBUG - 2026-02-16 02:22:38 --> Total execution time: 4.5629
INFO - 2026-02-16 02:22:38 --> Config Class Initialized
INFO - 2026-02-16 02:22:38 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:22:38 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:22:38 --> Utf8 Class Initialized
INFO - 2026-02-16 02:22:38 --> URI Class Initialized
INFO - 2026-02-16 02:22:38 --> Router Class Initialized
INFO - 2026-02-16 02:22:38 --> Output Class Initialized
INFO - 2026-02-16 02:22:38 --> Security Class Initialized
DEBUG - 2026-02-16 02:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:22:38 --> CSRF cookie sent
INFO - 2026-02-16 02:22:38 --> Input Class Initialized
INFO - 2026-02-16 02:22:38 --> Language Class Initialized
INFO - 2026-02-16 02:22:38 --> Language Class Initialized
INFO - 2026-02-16 02:22:38 --> Config Class Initialized
INFO - 2026-02-16 02:22:38 --> Loader Class Initialized
INFO - 2026-02-16 02:22:38 --> Helper loaded: url_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: form_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: html_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: file_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: email_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:22:38 --> Database Driver Class Initialized
INFO - 2026-02-16 02:22:38 --> Config Class Initialized
INFO - 2026-02-16 02:22:38 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:22:38 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:22:38 --> Utf8 Class Initialized
INFO - 2026-02-16 02:22:38 --> URI Class Initialized
INFO - 2026-02-16 02:22:38 --> Router Class Initialized
INFO - 2026-02-16 02:22:38 --> Output Class Initialized
INFO - 2026-02-16 02:22:38 --> Security Class Initialized
DEBUG - 2026-02-16 02:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:22:38 --> CSRF cookie sent
INFO - 2026-02-16 02:22:38 --> Input Class Initialized
INFO - 2026-02-16 02:22:38 --> Language Class Initialized
INFO - 2026-02-16 02:22:38 --> Language Class Initialized
INFO - 2026-02-16 02:22:38 --> Config Class Initialized
INFO - 2026-02-16 02:22:38 --> Loader Class Initialized
INFO - 2026-02-16 02:22:38 --> Helper loaded: url_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: form_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: html_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: file_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: email_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:22:38 --> Config Class Initialized
INFO - 2026-02-16 02:22:38 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:22:38 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:22:38 --> Utf8 Class Initialized
INFO - 2026-02-16 02:22:38 --> URI Class Initialized
INFO - 2026-02-16 02:22:38 --> Config Class Initialized
INFO - 2026-02-16 02:22:38 --> Hooks Class Initialized
INFO - 2026-02-16 02:22:38 --> Router Class Initialized
DEBUG - 2026-02-16 02:22:38 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:22:38 --> Utf8 Class Initialized
INFO - 2026-02-16 02:22:38 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:22:38 --> Output Class Initialized
INFO - 2026-02-16 02:22:38 --> Security Class Initialized
DEBUG - 2026-02-16 02:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:22:38 --> CSRF cookie sent
INFO - 2026-02-16 02:22:38 --> Input Class Initialized
INFO - 2026-02-16 02:22:38 --> Language Class Initialized
INFO - 2026-02-16 02:22:38 --> URI Class Initialized
INFO - 2026-02-16 02:22:38 --> Language Class Initialized
INFO - 2026-02-16 02:22:38 --> Config Class Initialized
INFO - 2026-02-16 02:22:38 --> Router Class Initialized
INFO - 2026-02-16 02:22:38 --> Loader Class Initialized
INFO - 2026-02-16 02:22:38 --> Helper loaded: url_helper
INFO - 2026-02-16 02:22:38 --> Output Class Initialized
INFO - 2026-02-16 02:22:38 --> Helper loaded: form_helper
INFO - 2026-02-16 02:22:38 --> Security Class Initialized
INFO - 2026-02-16 02:22:38 --> Helper loaded: html_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: file_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: email_helper
INFO - 2026-02-16 02:22:38 --> Database Driver Class Initialized
DEBUG - 2026-02-16 02:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:22:38 --> CSRF cookie sent
INFO - 2026-02-16 02:22:38 --> Input Class Initialized
INFO - 2026-02-16 02:22:38 --> Language Class Initialized
INFO - 2026-02-16 02:22:38 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:22:38 --> Language Class Initialized
INFO - 2026-02-16 02:22:38 --> Config Class Initialized
INFO - 2026-02-16 02:22:38 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:22:38 --> Loader Class Initialized
INFO - 2026-02-16 02:22:38 --> Helper loaded: url_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: form_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: html_helper
INFO - 2026-02-16 02:22:38 --> Database Driver Class Initialized
INFO - 2026-02-16 02:22:38 --> Helper loaded: file_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: email_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:22:38 --> Database Driver Class Initialized
INFO - 2026-02-16 02:22:38 --> Config Class Initialized
INFO - 2026-02-16 02:22:38 --> Hooks Class Initialized
INFO - 2026-02-16 02:22:38 --> Config Class Initialized
INFO - 2026-02-16 02:22:38 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:22:38 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:22:38 --> Utf8 Class Initialized
DEBUG - 2026-02-16 02:22:38 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:22:38 --> Utf8 Class Initialized
INFO - 2026-02-16 02:22:38 --> URI Class Initialized
INFO - 2026-02-16 02:22:38 --> URI Class Initialized
INFO - 2026-02-16 02:22:38 --> Router Class Initialized
INFO - 2026-02-16 02:22:38 --> Router Class Initialized
INFO - 2026-02-16 02:22:38 --> Output Class Initialized
INFO - 2026-02-16 02:22:38 --> Output Class Initialized
INFO - 2026-02-16 02:22:38 --> Security Class Initialized
INFO - 2026-02-16 02:22:38 --> Security Class Initialized
DEBUG - 2026-02-16 02:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:22:38 --> CSRF cookie sent
INFO - 2026-02-16 02:22:38 --> Input Class Initialized
INFO - 2026-02-16 02:22:38 --> Language Class Initialized
DEBUG - 2026-02-16 02:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:22:38 --> CSRF cookie sent
INFO - 2026-02-16 02:22:38 --> Input Class Initialized
INFO - 2026-02-16 02:22:38 --> Language Class Initialized
INFO - 2026-02-16 02:22:38 --> Language Class Initialized
INFO - 2026-02-16 02:22:38 --> Config Class Initialized
INFO - 2026-02-16 02:22:38 --> Language Class Initialized
INFO - 2026-02-16 02:22:38 --> Config Class Initialized
INFO - 2026-02-16 02:22:38 --> Loader Class Initialized
INFO - 2026-02-16 02:22:38 --> Helper loaded: url_helper
INFO - 2026-02-16 02:22:38 --> Loader Class Initialized
INFO - 2026-02-16 02:22:38 --> Helper loaded: url_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: form_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: html_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: file_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: email_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: form_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: html_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: file_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: email_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:22:38 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:22:38 --> Database Driver Class Initialized
INFO - 2026-02-16 02:22:38 --> Database Driver Class Initialized
INFO - 2026-02-16 02:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:22:40 --> Upload Class Initialized
DEBUG - 2026-02-16 02:22:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:22:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:22:40 --> Encryption Class Initialized
INFO - 2026-02-16 02:22:40 --> Form Validation Class Initialized
INFO - 2026-02-16 02:22:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:22:40 --> Pagination Class Initialized
INFO - 2026-02-16 02:22:40 --> Email Class Initialized
INFO - 2026-02-16 02:22:40 --> Controller Class Initialized
ERROR - 2026-02-16 02:22:40 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:22:40 --> Upload Class Initialized
DEBUG - 2026-02-16 02:22:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:22:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:22:40 --> Encryption Class Initialized
INFO - 2026-02-16 02:22:40 --> Form Validation Class Initialized
INFO - 2026-02-16 02:22:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:22:40 --> Pagination Class Initialized
INFO - 2026-02-16 02:22:40 --> Email Class Initialized
INFO - 2026-02-16 02:22:40 --> Controller Class Initialized
ERROR - 2026-02-16 02:22:40 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:22:40 --> Config Class Initialized
INFO - 2026-02-16 02:22:40 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:22:40 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:22:40 --> Utf8 Class Initialized
INFO - 2026-02-16 02:22:40 --> URI Class Initialized
INFO - 2026-02-16 02:22:40 --> Router Class Initialized
INFO - 2026-02-16 02:22:40 --> Output Class Initialized
INFO - 2026-02-16 02:22:40 --> Security Class Initialized
DEBUG - 2026-02-16 02:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:22:40 --> CSRF cookie sent
INFO - 2026-02-16 02:22:40 --> Input Class Initialized
INFO - 2026-02-16 02:22:40 --> Language Class Initialized
INFO - 2026-02-16 02:22:40 --> Language Class Initialized
INFO - 2026-02-16 02:22:40 --> Config Class Initialized
INFO - 2026-02-16 02:22:40 --> Config Class Initialized
INFO - 2026-02-16 02:22:40 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:22:40 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:22:40 --> Utf8 Class Initialized
INFO - 2026-02-16 02:22:40 --> Loader Class Initialized
INFO - 2026-02-16 02:22:40 --> URI Class Initialized
INFO - 2026-02-16 02:22:40 --> Helper loaded: url_helper
INFO - 2026-02-16 02:22:40 --> Helper loaded: form_helper
INFO - 2026-02-16 02:22:40 --> Router Class Initialized
INFO - 2026-02-16 02:22:40 --> Helper loaded: html_helper
INFO - 2026-02-16 02:22:40 --> Helper loaded: file_helper
INFO - 2026-02-16 02:22:40 --> Helper loaded: email_helper
INFO - 2026-02-16 02:22:40 --> Output Class Initialized
INFO - 2026-02-16 02:22:40 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:22:40 --> Security Class Initialized
INFO - 2026-02-16 02:22:40 --> Helper loaded: ssp_helper
DEBUG - 2026-02-16 02:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:22:40 --> CSRF cookie sent
INFO - 2026-02-16 02:22:40 --> Input Class Initialized
INFO - 2026-02-16 02:22:40 --> Language Class Initialized
INFO - 2026-02-16 02:22:40 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:22:40 --> Language Class Initialized
INFO - 2026-02-16 02:22:40 --> Config Class Initialized
INFO - 2026-02-16 02:22:40 --> Loader Class Initialized
INFO - 2026-02-16 02:22:40 --> Helper loaded: url_helper
INFO - 2026-02-16 02:22:40 --> Helper loaded: form_helper
INFO - 2026-02-16 02:22:40 --> Helper loaded: html_helper
INFO - 2026-02-16 02:22:40 --> Helper loaded: file_helper
INFO - 2026-02-16 02:22:40 --> Helper loaded: email_helper
INFO - 2026-02-16 02:22:40 --> Database Driver Class Initialized
INFO - 2026-02-16 02:22:40 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:22:40 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:22:40 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:22:40 --> Database Driver Class Initialized
INFO - 2026-02-16 02:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:22:41 --> Upload Class Initialized
DEBUG - 2026-02-16 02:22:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:22:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:22:41 --> Encryption Class Initialized
INFO - 2026-02-16 02:22:41 --> Form Validation Class Initialized
INFO - 2026-02-16 02:22:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:22:41 --> Pagination Class Initialized
INFO - 2026-02-16 02:22:41 --> Email Class Initialized
INFO - 2026-02-16 02:22:41 --> Controller Class Initialized
ERROR - 2026-02-16 02:22:41 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:22:41 --> Config Class Initialized
INFO - 2026-02-16 02:22:41 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:22:41 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:22:41 --> Utf8 Class Initialized
INFO - 2026-02-16 02:22:41 --> URI Class Initialized
INFO - 2026-02-16 02:22:41 --> Router Class Initialized
INFO - 2026-02-16 02:22:41 --> Output Class Initialized
INFO - 2026-02-16 02:22:41 --> Security Class Initialized
DEBUG - 2026-02-16 02:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:22:41 --> CSRF cookie sent
INFO - 2026-02-16 02:22:41 --> Input Class Initialized
INFO - 2026-02-16 02:22:41 --> Language Class Initialized
INFO - 2026-02-16 02:22:41 --> Language Class Initialized
INFO - 2026-02-16 02:22:41 --> Config Class Initialized
INFO - 2026-02-16 02:22:41 --> Loader Class Initialized
INFO - 2026-02-16 02:22:41 --> Helper loaded: url_helper
INFO - 2026-02-16 02:22:41 --> Helper loaded: form_helper
INFO - 2026-02-16 02:22:41 --> Helper loaded: html_helper
INFO - 2026-02-16 02:22:41 --> Helper loaded: file_helper
INFO - 2026-02-16 02:22:41 --> Helper loaded: email_helper
INFO - 2026-02-16 02:22:41 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:22:41 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:22:41 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:22:41 --> Database Driver Class Initialized
INFO - 2026-02-16 02:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:22:41 --> Upload Class Initialized
DEBUG - 2026-02-16 02:22:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:22:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:22:41 --> Encryption Class Initialized
INFO - 2026-02-16 02:22:41 --> Form Validation Class Initialized
INFO - 2026-02-16 02:22:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:22:41 --> Pagination Class Initialized
INFO - 2026-02-16 02:22:41 --> Email Class Initialized
INFO - 2026-02-16 02:22:41 --> Controller Class Initialized
DEBUG - 2026-02-16 02:22:41 --> Cart MX_Controller Initialized
INFO - 2026-02-16 02:22:41 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:22:41 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:22:41 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:22:41 --> Model "Common_model" initialized
INFO - 2026-02-16 02:22:41 --> Model "Order_model" initialized
INFO - 2026-02-16 02:22:41 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 02:22:41 --> Final output sent to browser
DEBUG - 2026-02-16 02:22:41 --> Total execution time: 2.8537
INFO - 2026-02-16 02:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:22:41 --> Upload Class Initialized
DEBUG - 2026-02-16 02:22:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:22:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:22:41 --> Encryption Class Initialized
INFO - 2026-02-16 02:22:41 --> Form Validation Class Initialized
INFO - 2026-02-16 02:22:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:22:41 --> Pagination Class Initialized
INFO - 2026-02-16 02:22:41 --> Email Class Initialized
INFO - 2026-02-16 02:22:41 --> Controller Class Initialized
ERROR - 2026-02-16 02:22:41 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:22:41 --> Upload Class Initialized
DEBUG - 2026-02-16 02:22:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:22:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:22:41 --> Encryption Class Initialized
INFO - 2026-02-16 02:22:41 --> Form Validation Class Initialized
INFO - 2026-02-16 02:22:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:22:41 --> Pagination Class Initialized
INFO - 2026-02-16 02:22:41 --> Email Class Initialized
INFO - 2026-02-16 02:22:41 --> Controller Class Initialized
ERROR - 2026-02-16 02:22:41 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:22:42 --> Upload Class Initialized
DEBUG - 2026-02-16 02:22:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:22:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:22:42 --> Encryption Class Initialized
INFO - 2026-02-16 02:22:42 --> Form Validation Class Initialized
INFO - 2026-02-16 02:22:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:22:42 --> Pagination Class Initialized
INFO - 2026-02-16 02:22:42 --> Email Class Initialized
INFO - 2026-02-16 02:22:42 --> Controller Class Initialized
ERROR - 2026-02-16 02:22:42 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:22:42 --> Upload Class Initialized
DEBUG - 2026-02-16 02:22:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:22:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:22:42 --> Encryption Class Initialized
INFO - 2026-02-16 02:22:42 --> Form Validation Class Initialized
INFO - 2026-02-16 02:22:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:22:42 --> Pagination Class Initialized
INFO - 2026-02-16 02:22:42 --> Email Class Initialized
INFO - 2026-02-16 02:22:42 --> Controller Class Initialized
ERROR - 2026-02-16 02:22:42 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:22:43 --> Upload Class Initialized
DEBUG - 2026-02-16 02:22:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:22:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:22:43 --> Encryption Class Initialized
INFO - 2026-02-16 02:22:43 --> Form Validation Class Initialized
INFO - 2026-02-16 02:22:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:22:43 --> Pagination Class Initialized
INFO - 2026-02-16 02:22:43 --> Email Class Initialized
INFO - 2026-02-16 02:22:43 --> Controller Class Initialized
ERROR - 2026-02-16 02:22:43 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:22:50 --> Config Class Initialized
INFO - 2026-02-16 02:22:50 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:22:50 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:22:50 --> Utf8 Class Initialized
INFO - 2026-02-16 02:22:50 --> URI Class Initialized
INFO - 2026-02-16 02:22:50 --> Router Class Initialized
INFO - 2026-02-16 02:22:50 --> Output Class Initialized
INFO - 2026-02-16 02:22:50 --> Security Class Initialized
DEBUG - 2026-02-16 02:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:22:50 --> CSRF cookie sent
INFO - 2026-02-16 02:22:50 --> CSRF token verified
INFO - 2026-02-16 02:22:50 --> Input Class Initialized
INFO - 2026-02-16 02:22:50 --> Language Class Initialized
INFO - 2026-02-16 02:22:50 --> Language Class Initialized
INFO - 2026-02-16 02:22:50 --> Config Class Initialized
INFO - 2026-02-16 02:22:50 --> Loader Class Initialized
INFO - 2026-02-16 02:22:50 --> Helper loaded: url_helper
INFO - 2026-02-16 02:22:50 --> Helper loaded: form_helper
INFO - 2026-02-16 02:22:50 --> Helper loaded: html_helper
INFO - 2026-02-16 02:22:50 --> Helper loaded: file_helper
INFO - 2026-02-16 02:22:50 --> Helper loaded: email_helper
INFO - 2026-02-16 02:22:50 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:22:50 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:22:50 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:22:51 --> Database Driver Class Initialized
INFO - 2026-02-16 02:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:22:53 --> Upload Class Initialized
DEBUG - 2026-02-16 02:22:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:22:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:22:53 --> Encryption Class Initialized
INFO - 2026-02-16 02:22:53 --> Form Validation Class Initialized
INFO - 2026-02-16 02:22:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:22:53 --> Pagination Class Initialized
INFO - 2026-02-16 02:22:53 --> Email Class Initialized
INFO - 2026-02-16 02:22:53 --> Controller Class Initialized
DEBUG - 2026-02-16 02:22:53 --> Pay MX_Controller Initialized
INFO - 2026-02-16 02:22:53 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:22:53 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:22:53 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:22:53 --> Model "Payment_model" initialized
INFO - 2026-02-16 02:22:53 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-16 02:22:53 --> Model "Billing_model" initialized
INFO - 2026-02-16 02:22:53 --> Model "Invoice_model" initialized
INFO - 2026-02-16 02:22:53 --> Final output sent to browser
DEBUG - 2026-02-16 02:22:53 --> Total execution time: 2.9360
INFO - 2026-02-16 02:23:22 --> Config Class Initialized
INFO - 2026-02-16 02:23:22 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:23:22 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:23:22 --> Utf8 Class Initialized
INFO - 2026-02-16 02:23:22 --> URI Class Initialized
INFO - 2026-02-16 02:23:22 --> Router Class Initialized
INFO - 2026-02-16 02:23:22 --> Output Class Initialized
INFO - 2026-02-16 02:23:22 --> Security Class Initialized
DEBUG - 2026-02-16 02:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:23:22 --> CSRF cookie sent
INFO - 2026-02-16 02:23:26 --> Config Class Initialized
INFO - 2026-02-16 02:23:26 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:23:26 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:23:26 --> Utf8 Class Initialized
INFO - 2026-02-16 02:23:26 --> URI Class Initialized
INFO - 2026-02-16 02:23:26 --> Router Class Initialized
INFO - 2026-02-16 02:23:26 --> Output Class Initialized
INFO - 2026-02-16 02:23:26 --> Security Class Initialized
DEBUG - 2026-02-16 02:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:23:26 --> CSRF cookie sent
INFO - 2026-02-16 02:23:26 --> Input Class Initialized
INFO - 2026-02-16 02:23:26 --> Language Class Initialized
INFO - 2026-02-16 02:23:26 --> Language Class Initialized
INFO - 2026-02-16 02:23:26 --> Config Class Initialized
INFO - 2026-02-16 02:23:26 --> Loader Class Initialized
INFO - 2026-02-16 02:23:26 --> Helper loaded: url_helper
INFO - 2026-02-16 02:23:26 --> Helper loaded: form_helper
INFO - 2026-02-16 02:23:26 --> Helper loaded: html_helper
INFO - 2026-02-16 02:23:26 --> Helper loaded: file_helper
INFO - 2026-02-16 02:23:26 --> Helper loaded: email_helper
INFO - 2026-02-16 02:23:26 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:23:26 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:23:26 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:23:26 --> Database Driver Class Initialized
INFO - 2026-02-16 02:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:23:28 --> Upload Class Initialized
DEBUG - 2026-02-16 02:23:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:23:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:23:28 --> Encryption Class Initialized
INFO - 2026-02-16 02:23:28 --> Form Validation Class Initialized
INFO - 2026-02-16 02:23:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:23:28 --> Pagination Class Initialized
INFO - 2026-02-16 02:23:28 --> Email Class Initialized
INFO - 2026-02-16 02:23:28 --> Controller Class Initialized
DEBUG - 2026-02-16 02:23:28 --> Pay MX_Controller Initialized
INFO - 2026-02-16 02:23:28 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:23:28 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:23:28 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:23:28 --> Model "Payment_model" initialized
INFO - 2026-02-16 02:23:28 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-16 02:23:28 --> Model "Billing_model" initialized
INFO - 2026-02-16 02:23:28 --> Model "Invoice_model" initialized
DEBUG - 2026-02-16 02:23:30 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-16 02:23:30 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-16 02:23:30 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-16 02:23:30 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_pay.php
INFO - 2026-02-16 02:23:30 --> Final output sent to browser
DEBUG - 2026-02-16 02:23:30 --> Total execution time: 4.5753
INFO - 2026-02-16 02:23:31 --> Config Class Initialized
INFO - 2026-02-16 02:23:31 --> Hooks Class Initialized
INFO - 2026-02-16 02:23:31 --> Config Class Initialized
INFO - 2026-02-16 02:23:31 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:23:31 --> UTF-8 Support Enabled
DEBUG - 2026-02-16 02:23:31 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:23:31 --> Utf8 Class Initialized
INFO - 2026-02-16 02:23:31 --> Utf8 Class Initialized
INFO - 2026-02-16 02:23:31 --> URI Class Initialized
INFO - 2026-02-16 02:23:31 --> URI Class Initialized
INFO - 2026-02-16 02:23:31 --> Router Class Initialized
INFO - 2026-02-16 02:23:31 --> Router Class Initialized
INFO - 2026-02-16 02:23:31 --> Output Class Initialized
INFO - 2026-02-16 02:23:31 --> Output Class Initialized
INFO - 2026-02-16 02:23:31 --> Security Class Initialized
INFO - 2026-02-16 02:23:31 --> Security Class Initialized
DEBUG - 2026-02-16 02:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-02-16 02:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:23:31 --> CSRF cookie sent
INFO - 2026-02-16 02:23:31 --> Input Class Initialized
INFO - 2026-02-16 02:23:31 --> CSRF cookie sent
INFO - 2026-02-16 02:23:31 --> Input Class Initialized
INFO - 2026-02-16 02:23:31 --> Language Class Initialized
INFO - 2026-02-16 02:23:31 --> Language Class Initialized
INFO - 2026-02-16 02:23:31 --> Language Class Initialized
INFO - 2026-02-16 02:23:31 --> Config Class Initialized
INFO - 2026-02-16 02:23:31 --> Language Class Initialized
INFO - 2026-02-16 02:23:31 --> Config Class Initialized
INFO - 2026-02-16 02:23:31 --> Loader Class Initialized
INFO - 2026-02-16 02:23:31 --> Loader Class Initialized
INFO - 2026-02-16 02:23:31 --> Helper loaded: url_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: url_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: form_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: form_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: html_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: html_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: file_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: file_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: email_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: email_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:23:31 --> Database Driver Class Initialized
INFO - 2026-02-16 02:23:31 --> Database Driver Class Initialized
INFO - 2026-02-16 02:23:31 --> Config Class Initialized
INFO - 2026-02-16 02:23:31 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:23:31 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:23:31 --> Utf8 Class Initialized
INFO - 2026-02-16 02:23:31 --> URI Class Initialized
INFO - 2026-02-16 02:23:31 --> Router Class Initialized
INFO - 2026-02-16 02:23:31 --> Output Class Initialized
INFO - 2026-02-16 02:23:31 --> Security Class Initialized
DEBUG - 2026-02-16 02:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:23:31 --> CSRF cookie sent
INFO - 2026-02-16 02:23:31 --> Input Class Initialized
INFO - 2026-02-16 02:23:31 --> Language Class Initialized
INFO - 2026-02-16 02:23:31 --> Language Class Initialized
INFO - 2026-02-16 02:23:31 --> Config Class Initialized
INFO - 2026-02-16 02:23:31 --> Loader Class Initialized
INFO - 2026-02-16 02:23:31 --> Helper loaded: url_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: form_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: html_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: file_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: email_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:23:31 --> Database Driver Class Initialized
INFO - 2026-02-16 02:23:31 --> Config Class Initialized
INFO - 2026-02-16 02:23:31 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:23:31 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:23:31 --> Utf8 Class Initialized
INFO - 2026-02-16 02:23:31 --> URI Class Initialized
INFO - 2026-02-16 02:23:31 --> Config Class Initialized
INFO - 2026-02-16 02:23:31 --> Hooks Class Initialized
INFO - 2026-02-16 02:23:31 --> Config Class Initialized
INFO - 2026-02-16 02:23:31 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:23:31 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:23:31 --> Utf8 Class Initialized
INFO - 2026-02-16 02:23:31 --> Router Class Initialized
INFO - 2026-02-16 02:23:31 --> URI Class Initialized
DEBUG - 2026-02-16 02:23:31 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:23:31 --> Utf8 Class Initialized
INFO - 2026-02-16 02:23:31 --> Output Class Initialized
INFO - 2026-02-16 02:23:31 --> URI Class Initialized
INFO - 2026-02-16 02:23:31 --> Security Class Initialized
INFO - 2026-02-16 02:23:31 --> Router Class Initialized
DEBUG - 2026-02-16 02:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:23:31 --> CSRF cookie sent
INFO - 2026-02-16 02:23:31 --> Input Class Initialized
INFO - 2026-02-16 02:23:31 --> Language Class Initialized
INFO - 2026-02-16 02:23:31 --> Output Class Initialized
INFO - 2026-02-16 02:23:31 --> Language Class Initialized
INFO - 2026-02-16 02:23:31 --> Config Class Initialized
INFO - 2026-02-16 02:23:31 --> Router Class Initialized
INFO - 2026-02-16 02:23:31 --> Security Class Initialized
DEBUG - 2026-02-16 02:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:23:31 --> Output Class Initialized
INFO - 2026-02-16 02:23:31 --> CSRF cookie sent
INFO - 2026-02-16 02:23:31 --> Input Class Initialized
INFO - 2026-02-16 02:23:31 --> Language Class Initialized
INFO - 2026-02-16 02:23:31 --> Loader Class Initialized
INFO - 2026-02-16 02:23:31 --> Language Class Initialized
INFO - 2026-02-16 02:23:31 --> Config Class Initialized
INFO - 2026-02-16 02:23:31 --> Helper loaded: url_helper
INFO - 2026-02-16 02:23:31 --> Security Class Initialized
INFO - 2026-02-16 02:23:31 --> Helper loaded: form_helper
DEBUG - 2026-02-16 02:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:23:31 --> CSRF cookie sent
INFO - 2026-02-16 02:23:31 --> Input Class Initialized
INFO - 2026-02-16 02:23:31 --> Helper loaded: html_helper
INFO - 2026-02-16 02:23:31 --> Language Class Initialized
INFO - 2026-02-16 02:23:31 --> Helper loaded: file_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: email_helper
INFO - 2026-02-16 02:23:31 --> Loader Class Initialized
INFO - 2026-02-16 02:23:31 --> Helper loaded: url_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: form_helper
INFO - 2026-02-16 02:23:31 --> Language Class Initialized
INFO - 2026-02-16 02:23:31 --> Config Class Initialized
INFO - 2026-02-16 02:23:31 --> Helper loaded: html_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: file_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: email_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:23:31 --> Loader Class Initialized
INFO - 2026-02-16 02:23:31 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: url_helper
INFO - 2026-02-16 02:23:31 --> Database Driver Class Initialized
INFO - 2026-02-16 02:23:31 --> Helper loaded: form_helper
INFO - 2026-02-16 02:23:31 --> Database Driver Class Initialized
INFO - 2026-02-16 02:23:31 --> Helper loaded: html_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: file_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: email_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:23:31 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:23:31 --> Database Driver Class Initialized
INFO - 2026-02-16 02:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:23:32 --> Upload Class Initialized
DEBUG - 2026-02-16 02:23:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:23:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:23:32 --> Encryption Class Initialized
INFO - 2026-02-16 02:23:32 --> Form Validation Class Initialized
INFO - 2026-02-16 02:23:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:23:32 --> Pagination Class Initialized
INFO - 2026-02-16 02:23:32 --> Email Class Initialized
INFO - 2026-02-16 02:23:32 --> Controller Class Initialized
ERROR - 2026-02-16 02:23:32 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:23:32 --> Upload Class Initialized
DEBUG - 2026-02-16 02:23:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:23:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:23:32 --> Encryption Class Initialized
INFO - 2026-02-16 02:23:32 --> Form Validation Class Initialized
INFO - 2026-02-16 02:23:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:23:32 --> Pagination Class Initialized
INFO - 2026-02-16 02:23:32 --> Config Class Initialized
INFO - 2026-02-16 02:23:32 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:23:32 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:23:32 --> Utf8 Class Initialized
INFO - 2026-02-16 02:23:32 --> URI Class Initialized
INFO - 2026-02-16 02:23:32 --> Email Class Initialized
INFO - 2026-02-16 02:23:32 --> Controller Class Initialized
ERROR - 2026-02-16 02:23:32 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:23:32 --> Router Class Initialized
INFO - 2026-02-16 02:23:32 --> Output Class Initialized
INFO - 2026-02-16 02:23:32 --> Security Class Initialized
DEBUG - 2026-02-16 02:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:23:32 --> CSRF cookie sent
INFO - 2026-02-16 02:23:32 --> Input Class Initialized
INFO - 2026-02-16 02:23:32 --> Language Class Initialized
INFO - 2026-02-16 02:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:23:32 --> Language Class Initialized
INFO - 2026-02-16 02:23:32 --> Config Class Initialized
INFO - 2026-02-16 02:23:32 --> Upload Class Initialized
DEBUG - 2026-02-16 02:23:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:23:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:23:32 --> Encryption Class Initialized
INFO - 2026-02-16 02:23:32 --> Loader Class Initialized
INFO - 2026-02-16 02:23:32 --> Helper loaded: url_helper
INFO - 2026-02-16 02:23:32 --> Form Validation Class Initialized
INFO - 2026-02-16 02:23:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:23:32 --> Helper loaded: form_helper
INFO - 2026-02-16 02:23:32 --> Pagination Class Initialized
INFO - 2026-02-16 02:23:32 --> Helper loaded: html_helper
INFO - 2026-02-16 02:23:32 --> Helper loaded: file_helper
INFO - 2026-02-16 02:23:32 --> Helper loaded: email_helper
INFO - 2026-02-16 02:23:32 --> Config Class Initialized
INFO - 2026-02-16 02:23:32 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:23:32 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:23:32 --> Utf8 Class Initialized
INFO - 2026-02-16 02:23:32 --> Email Class Initialized
INFO - 2026-02-16 02:23:32 --> Controller Class Initialized
ERROR - 2026-02-16 02:23:32 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:23:32 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:23:32 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:23:32 --> URI Class Initialized
INFO - 2026-02-16 02:23:32 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:23:32 --> Router Class Initialized
INFO - 2026-02-16 02:23:32 --> Output Class Initialized
INFO - 2026-02-16 02:23:32 --> Security Class Initialized
INFO - 2026-02-16 02:23:32 --> Upload Class Initialized
DEBUG - 2026-02-16 02:23:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:23:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:23:32 --> Encryption Class Initialized
INFO - 2026-02-16 02:23:32 --> Database Driver Class Initialized
INFO - 2026-02-16 02:23:32 --> Form Validation Class Initialized
DEBUG - 2026-02-16 02:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:23:32 --> CSRF cookie sent
INFO - 2026-02-16 02:23:32 --> Input Class Initialized
INFO - 2026-02-16 02:23:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:23:32 --> Language Class Initialized
INFO - 2026-02-16 02:23:32 --> Pagination Class Initialized
INFO - 2026-02-16 02:23:32 --> Config Class Initialized
INFO - 2026-02-16 02:23:32 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:23:32 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:23:32 --> Utf8 Class Initialized
INFO - 2026-02-16 02:23:32 --> Language Class Initialized
INFO - 2026-02-16 02:23:32 --> Config Class Initialized
INFO - 2026-02-16 02:23:32 --> URI Class Initialized
INFO - 2026-02-16 02:23:32 --> Router Class Initialized
INFO - 2026-02-16 02:23:32 --> Loader Class Initialized
INFO - 2026-02-16 02:23:32 --> Helper loaded: url_helper
INFO - 2026-02-16 02:23:32 --> Helper loaded: form_helper
INFO - 2026-02-16 02:23:32 --> Helper loaded: html_helper
INFO - 2026-02-16 02:23:32 --> Output Class Initialized
INFO - 2026-02-16 02:23:32 --> Email Class Initialized
INFO - 2026-02-16 02:23:32 --> Controller Class Initialized
INFO - 2026-02-16 02:23:32 --> Security Class Initialized
ERROR - 2026-02-16 02:23:32 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:23:32 --> Helper loaded: file_helper
INFO - 2026-02-16 02:23:32 --> Helper loaded: email_helper
DEBUG - 2026-02-16 02:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:23:32 --> CSRF cookie sent
INFO - 2026-02-16 02:23:32 --> Input Class Initialized
INFO - 2026-02-16 02:23:32 --> Language Class Initialized
INFO - 2026-02-16 02:23:32 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:23:32 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:23:32 --> Language Class Initialized
INFO - 2026-02-16 02:23:32 --> Config Class Initialized
INFO - 2026-02-16 02:23:32 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:23:32 --> Loader Class Initialized
INFO - 2026-02-16 02:23:32 --> Helper loaded: url_helper
INFO - 2026-02-16 02:23:32 --> Helper loaded: form_helper
INFO - 2026-02-16 02:23:32 --> Helper loaded: html_helper
INFO - 2026-02-16 02:23:32 --> Helper loaded: file_helper
INFO - 2026-02-16 02:23:32 --> Helper loaded: email_helper
INFO - 2026-02-16 02:23:32 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:23:32 --> Database Driver Class Initialized
INFO - 2026-02-16 02:23:32 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:23:32 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:23:32 --> Database Driver Class Initialized
INFO - 2026-02-16 02:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:23:34 --> Upload Class Initialized
DEBUG - 2026-02-16 02:23:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:23:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:23:34 --> Encryption Class Initialized
INFO - 2026-02-16 02:23:34 --> Form Validation Class Initialized
INFO - 2026-02-16 02:23:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:23:34 --> Pagination Class Initialized
INFO - 2026-02-16 02:23:34 --> Email Class Initialized
INFO - 2026-02-16 02:23:34 --> Controller Class Initialized
ERROR - 2026-02-16 02:23:34 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:23:34 --> Upload Class Initialized
DEBUG - 2026-02-16 02:23:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:23:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:23:34 --> Encryption Class Initialized
INFO - 2026-02-16 02:23:34 --> Form Validation Class Initialized
INFO - 2026-02-16 02:23:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:23:34 --> Pagination Class Initialized
INFO - 2026-02-16 02:23:34 --> Email Class Initialized
INFO - 2026-02-16 02:23:34 --> Controller Class Initialized
ERROR - 2026-02-16 02:23:34 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:23:34 --> Upload Class Initialized
DEBUG - 2026-02-16 02:23:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:23:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:23:34 --> Encryption Class Initialized
INFO - 2026-02-16 02:23:34 --> Form Validation Class Initialized
INFO - 2026-02-16 02:23:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:23:34 --> Pagination Class Initialized
INFO - 2026-02-16 02:23:34 --> Email Class Initialized
INFO - 2026-02-16 02:23:34 --> Controller Class Initialized
DEBUG - 2026-02-16 02:23:34 --> Cart MX_Controller Initialized
INFO - 2026-02-16 02:23:34 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:23:34 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:23:34 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:23:34 --> Model "Common_model" initialized
INFO - 2026-02-16 02:23:34 --> Model "Order_model" initialized
INFO - 2026-02-16 02:23:34 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 02:23:35 --> Final output sent to browser
DEBUG - 2026-02-16 02:23:35 --> Total execution time: 2.3815
INFO - 2026-02-16 02:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:23:35 --> Upload Class Initialized
DEBUG - 2026-02-16 02:23:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:23:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:23:35 --> Encryption Class Initialized
INFO - 2026-02-16 02:23:35 --> Form Validation Class Initialized
INFO - 2026-02-16 02:23:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:23:35 --> Pagination Class Initialized
INFO - 2026-02-16 02:23:35 --> Email Class Initialized
INFO - 2026-02-16 02:23:35 --> Controller Class Initialized
ERROR - 2026-02-16 02:23:35 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:23:35 --> Upload Class Initialized
DEBUG - 2026-02-16 02:23:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:23:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:23:35 --> Encryption Class Initialized
INFO - 2026-02-16 02:23:35 --> Form Validation Class Initialized
INFO - 2026-02-16 02:23:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:23:35 --> Pagination Class Initialized
INFO - 2026-02-16 02:23:35 --> Email Class Initialized
INFO - 2026-02-16 02:23:35 --> Controller Class Initialized
ERROR - 2026-02-16 02:23:35 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:23:36 --> Config Class Initialized
INFO - 2026-02-16 02:23:36 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:23:36 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:23:36 --> Utf8 Class Initialized
INFO - 2026-02-16 02:23:36 --> URI Class Initialized
INFO - 2026-02-16 02:23:36 --> Router Class Initialized
INFO - 2026-02-16 02:23:36 --> Output Class Initialized
INFO - 2026-02-16 02:23:36 --> Security Class Initialized
DEBUG - 2026-02-16 02:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:23:36 --> CSRF cookie sent
INFO - 2026-02-16 02:23:36 --> CSRF token verified
INFO - 2026-02-16 02:23:36 --> Input Class Initialized
INFO - 2026-02-16 02:23:36 --> Language Class Initialized
INFO - 2026-02-16 02:23:36 --> Language Class Initialized
INFO - 2026-02-16 02:23:36 --> Config Class Initialized
INFO - 2026-02-16 02:23:36 --> Loader Class Initialized
INFO - 2026-02-16 02:23:36 --> Helper loaded: url_helper
INFO - 2026-02-16 02:23:36 --> Helper loaded: form_helper
INFO - 2026-02-16 02:23:36 --> Helper loaded: html_helper
INFO - 2026-02-16 02:23:36 --> Helper loaded: file_helper
INFO - 2026-02-16 02:23:36 --> Helper loaded: email_helper
INFO - 2026-02-16 02:23:36 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:23:36 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:23:36 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:23:36 --> Database Driver Class Initialized
INFO - 2026-02-16 02:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:23:39 --> Upload Class Initialized
DEBUG - 2026-02-16 02:23:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:23:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:23:39 --> Encryption Class Initialized
INFO - 2026-02-16 02:23:39 --> Form Validation Class Initialized
INFO - 2026-02-16 02:23:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:23:39 --> Pagination Class Initialized
INFO - 2026-02-16 02:23:39 --> Email Class Initialized
INFO - 2026-02-16 02:23:39 --> Controller Class Initialized
DEBUG - 2026-02-16 02:23:39 --> Pay MX_Controller Initialized
INFO - 2026-02-16 02:23:39 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:23:39 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:23:39 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:23:39 --> Model "Payment_model" initialized
INFO - 2026-02-16 02:23:39 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-16 02:23:39 --> Model "Billing_model" initialized
INFO - 2026-02-16 02:23:39 --> Model "Invoice_model" initialized
INFO - 2026-02-16 02:23:40 --> Final output sent to browser
DEBUG - 2026-02-16 02:23:40 --> Total execution time: 3.8131
INFO - 2026-02-16 02:24:34 --> Config Class Initialized
INFO - 2026-02-16 02:24:34 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:24:34 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:24:34 --> Utf8 Class Initialized
INFO - 2026-02-16 02:24:34 --> URI Class Initialized
INFO - 2026-02-16 02:24:34 --> Router Class Initialized
INFO - 2026-02-16 02:24:34 --> Output Class Initialized
INFO - 2026-02-16 02:24:34 --> Security Class Initialized
DEBUG - 2026-02-16 02:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:24:34 --> CSRF cookie sent
INFO - 2026-02-16 02:24:40 --> Config Class Initialized
INFO - 2026-02-16 02:24:40 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:24:40 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:24:40 --> Utf8 Class Initialized
INFO - 2026-02-16 02:24:40 --> URI Class Initialized
INFO - 2026-02-16 02:24:40 --> Router Class Initialized
INFO - 2026-02-16 02:24:40 --> Output Class Initialized
INFO - 2026-02-16 02:24:40 --> Security Class Initialized
DEBUG - 2026-02-16 02:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:24:40 --> CSRF cookie sent
INFO - 2026-02-16 02:24:40 --> Input Class Initialized
INFO - 2026-02-16 02:24:40 --> Language Class Initialized
INFO - 2026-02-16 02:24:40 --> Language Class Initialized
INFO - 2026-02-16 02:24:40 --> Config Class Initialized
INFO - 2026-02-16 02:24:40 --> Loader Class Initialized
INFO - 2026-02-16 02:24:40 --> Helper loaded: url_helper
INFO - 2026-02-16 02:24:40 --> Helper loaded: form_helper
INFO - 2026-02-16 02:24:40 --> Helper loaded: html_helper
INFO - 2026-02-16 02:24:40 --> Helper loaded: file_helper
INFO - 2026-02-16 02:24:40 --> Helper loaded: email_helper
INFO - 2026-02-16 02:24:40 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:24:40 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:24:40 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:24:40 --> Database Driver Class Initialized
INFO - 2026-02-16 02:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:24:42 --> Upload Class Initialized
DEBUG - 2026-02-16 02:24:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:24:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:24:42 --> Encryption Class Initialized
INFO - 2026-02-16 02:24:42 --> Form Validation Class Initialized
INFO - 2026-02-16 02:24:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:24:42 --> Pagination Class Initialized
INFO - 2026-02-16 02:24:42 --> Email Class Initialized
INFO - 2026-02-16 02:24:42 --> Controller Class Initialized
DEBUG - 2026-02-16 02:24:42 --> Pay MX_Controller Initialized
INFO - 2026-02-16 02:24:42 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:24:42 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:24:42 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:24:42 --> Model "Payment_model" initialized
INFO - 2026-02-16 02:24:42 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-16 02:24:42 --> Model "Billing_model" initialized
INFO - 2026-02-16 02:24:42 --> Model "Invoice_model" initialized
DEBUG - 2026-02-16 02:24:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-16 02:24:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-16 02:24:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-16 02:24:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_pay.php
INFO - 2026-02-16 02:24:44 --> Final output sent to browser
DEBUG - 2026-02-16 02:24:44 --> Total execution time: 4.3962
INFO - 2026-02-16 02:24:44 --> Config Class Initialized
INFO - 2026-02-16 02:24:44 --> Hooks Class Initialized
INFO - 2026-02-16 02:24:44 --> Config Class Initialized
INFO - 2026-02-16 02:24:44 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:24:44 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:24:44 --> Utf8 Class Initialized
INFO - 2026-02-16 02:24:44 --> URI Class Initialized
DEBUG - 2026-02-16 02:24:44 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:24:44 --> Utf8 Class Initialized
INFO - 2026-02-16 02:24:44 --> URI Class Initialized
INFO - 2026-02-16 02:24:44 --> Router Class Initialized
INFO - 2026-02-16 02:24:44 --> Router Class Initialized
INFO - 2026-02-16 02:24:44 --> Output Class Initialized
INFO - 2026-02-16 02:24:44 --> Security Class Initialized
INFO - 2026-02-16 02:24:44 --> Output Class Initialized
DEBUG - 2026-02-16 02:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:24:44 --> CSRF cookie sent
INFO - 2026-02-16 02:24:44 --> Input Class Initialized
INFO - 2026-02-16 02:24:44 --> Security Class Initialized
INFO - 2026-02-16 02:24:44 --> Language Class Initialized
INFO - 2026-02-16 02:24:44 --> Language Class Initialized
INFO - 2026-02-16 02:24:44 --> Config Class Initialized
DEBUG - 2026-02-16 02:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:24:44 --> CSRF cookie sent
INFO - 2026-02-16 02:24:44 --> Input Class Initialized
INFO - 2026-02-16 02:24:44 --> Language Class Initialized
INFO - 2026-02-16 02:24:44 --> Language Class Initialized
INFO - 2026-02-16 02:24:44 --> Config Class Initialized
INFO - 2026-02-16 02:24:44 --> Loader Class Initialized
INFO - 2026-02-16 02:24:44 --> Helper loaded: url_helper
INFO - 2026-02-16 02:24:44 --> Loader Class Initialized
INFO - 2026-02-16 02:24:44 --> Helper loaded: form_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: url_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: html_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: file_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: email_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: form_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: html_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: file_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: email_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:24:44 --> Database Driver Class Initialized
INFO - 2026-02-16 02:24:44 --> Database Driver Class Initialized
INFO - 2026-02-16 02:24:44 --> Config Class Initialized
INFO - 2026-02-16 02:24:44 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:24:44 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:24:44 --> Utf8 Class Initialized
INFO - 2026-02-16 02:24:44 --> URI Class Initialized
INFO - 2026-02-16 02:24:44 --> Router Class Initialized
INFO - 2026-02-16 02:24:44 --> Output Class Initialized
INFO - 2026-02-16 02:24:44 --> Security Class Initialized
DEBUG - 2026-02-16 02:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:24:44 --> CSRF cookie sent
INFO - 2026-02-16 02:24:44 --> Input Class Initialized
INFO - 2026-02-16 02:24:44 --> Language Class Initialized
INFO - 2026-02-16 02:24:44 --> Language Class Initialized
INFO - 2026-02-16 02:24:44 --> Config Class Initialized
INFO - 2026-02-16 02:24:44 --> Loader Class Initialized
INFO - 2026-02-16 02:24:44 --> Helper loaded: url_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: form_helper
INFO - 2026-02-16 02:24:44 --> Config Class Initialized
INFO - 2026-02-16 02:24:44 --> Hooks Class Initialized
INFO - 2026-02-16 02:24:44 --> Helper loaded: html_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: file_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: email_helper
DEBUG - 2026-02-16 02:24:44 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:24:44 --> Utf8 Class Initialized
INFO - 2026-02-16 02:24:44 --> URI Class Initialized
INFO - 2026-02-16 02:24:44 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:24:44 --> Router Class Initialized
INFO - 2026-02-16 02:24:44 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:24:44 --> Output Class Initialized
INFO - 2026-02-16 02:24:44 --> Security Class Initialized
DEBUG - 2026-02-16 02:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:24:44 --> CSRF cookie sent
INFO - 2026-02-16 02:24:44 --> Input Class Initialized
INFO - 2026-02-16 02:24:44 --> Language Class Initialized
INFO - 2026-02-16 02:24:44 --> Language Class Initialized
INFO - 2026-02-16 02:24:44 --> Config Class Initialized
INFO - 2026-02-16 02:24:44 --> Database Driver Class Initialized
INFO - 2026-02-16 02:24:44 --> Loader Class Initialized
INFO - 2026-02-16 02:24:44 --> Helper loaded: url_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: form_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: html_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: file_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: email_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:24:44 --> Database Driver Class Initialized
INFO - 2026-02-16 02:24:44 --> Config Class Initialized
INFO - 2026-02-16 02:24:44 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:24:44 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:24:44 --> Utf8 Class Initialized
INFO - 2026-02-16 02:24:44 --> URI Class Initialized
INFO - 2026-02-16 02:24:44 --> Router Class Initialized
INFO - 2026-02-16 02:24:44 --> Output Class Initialized
INFO - 2026-02-16 02:24:44 --> Security Class Initialized
INFO - 2026-02-16 02:24:44 --> Config Class Initialized
INFO - 2026-02-16 02:24:44 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:24:44 --> CSRF cookie sent
INFO - 2026-02-16 02:24:44 --> Input Class Initialized
INFO - 2026-02-16 02:24:44 --> Language Class Initialized
DEBUG - 2026-02-16 02:24:44 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:24:44 --> Utf8 Class Initialized
INFO - 2026-02-16 02:24:44 --> Language Class Initialized
INFO - 2026-02-16 02:24:44 --> Config Class Initialized
INFO - 2026-02-16 02:24:44 --> URI Class Initialized
INFO - 2026-02-16 02:24:44 --> Router Class Initialized
INFO - 2026-02-16 02:24:44 --> Loader Class Initialized
INFO - 2026-02-16 02:24:44 --> Helper loaded: url_helper
INFO - 2026-02-16 02:24:44 --> Output Class Initialized
INFO - 2026-02-16 02:24:44 --> Helper loaded: form_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: html_helper
INFO - 2026-02-16 02:24:44 --> Security Class Initialized
INFO - 2026-02-16 02:24:44 --> Helper loaded: file_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: email_helper
DEBUG - 2026-02-16 02:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:24:44 --> CSRF cookie sent
INFO - 2026-02-16 02:24:44 --> Input Class Initialized
INFO - 2026-02-16 02:24:44 --> Language Class Initialized
INFO - 2026-02-16 02:24:44 --> Language Class Initialized
INFO - 2026-02-16 02:24:44 --> Config Class Initialized
INFO - 2026-02-16 02:24:44 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:24:44 --> Loader Class Initialized
INFO - 2026-02-16 02:24:44 --> Helper loaded: url_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: form_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: html_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: file_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: email_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:24:44 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:24:44 --> Database Driver Class Initialized
INFO - 2026-02-16 02:24:44 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:24:44 --> Database Driver Class Initialized
INFO - 2026-02-16 02:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:24:46 --> Upload Class Initialized
DEBUG - 2026-02-16 02:24:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:24:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:24:46 --> Encryption Class Initialized
INFO - 2026-02-16 02:24:46 --> Form Validation Class Initialized
INFO - 2026-02-16 02:24:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:24:46 --> Pagination Class Initialized
INFO - 2026-02-16 02:24:46 --> Email Class Initialized
INFO - 2026-02-16 02:24:46 --> Controller Class Initialized
ERROR - 2026-02-16 02:24:46 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:24:46 --> Upload Class Initialized
DEBUG - 2026-02-16 02:24:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:24:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:24:46 --> Encryption Class Initialized
INFO - 2026-02-16 02:24:46 --> Config Class Initialized
INFO - 2026-02-16 02:24:46 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:24:46 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:24:46 --> Utf8 Class Initialized
INFO - 2026-02-16 02:24:46 --> Form Validation Class Initialized
INFO - 2026-02-16 02:24:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:24:46 --> Pagination Class Initialized
INFO - 2026-02-16 02:24:46 --> URI Class Initialized
INFO - 2026-02-16 02:24:46 --> Router Class Initialized
INFO - 2026-02-16 02:24:46 --> Output Class Initialized
INFO - 2026-02-16 02:24:46 --> Security Class Initialized
INFO - 2026-02-16 02:24:46 --> Email Class Initialized
INFO - 2026-02-16 02:24:46 --> Controller Class Initialized
ERROR - 2026-02-16 02:24:46 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:24:46 --> Upload Class Initialized
DEBUG - 2026-02-16 02:24:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:24:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:24:46 --> Encryption Class Initialized
DEBUG - 2026-02-16 02:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:24:46 --> CSRF cookie sent
INFO - 2026-02-16 02:24:46 --> Input Class Initialized
INFO - 2026-02-16 02:24:46 --> Language Class Initialized
INFO - 2026-02-16 02:24:46 --> Form Validation Class Initialized
INFO - 2026-02-16 02:24:46 --> Language Class Initialized
INFO - 2026-02-16 02:24:46 --> Config Class Initialized
INFO - 2026-02-16 02:24:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:24:46 --> Pagination Class Initialized
INFO - 2026-02-16 02:24:46 --> Config Class Initialized
INFO - 2026-02-16 02:24:46 --> Hooks Class Initialized
INFO - 2026-02-16 02:24:46 --> Loader Class Initialized
DEBUG - 2026-02-16 02:24:46 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:24:46 --> Utf8 Class Initialized
INFO - 2026-02-16 02:24:46 --> Helper loaded: url_helper
INFO - 2026-02-16 02:24:46 --> Email Class Initialized
INFO - 2026-02-16 02:24:46 --> URI Class Initialized
INFO - 2026-02-16 02:24:46 --> Controller Class Initialized
ERROR - 2026-02-16 02:24:46 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:24:46 --> Helper loaded: form_helper
INFO - 2026-02-16 02:24:46 --> Router Class Initialized
INFO - 2026-02-16 02:24:46 --> Helper loaded: html_helper
INFO - 2026-02-16 02:24:46 --> Helper loaded: file_helper
INFO - 2026-02-16 02:24:46 --> Helper loaded: email_helper
INFO - 2026-02-16 02:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:24:46 --> Output Class Initialized
INFO - 2026-02-16 02:24:46 --> Upload Class Initialized
INFO - 2026-02-16 02:24:46 --> Helper loaded: whmaz_helper
DEBUG - 2026-02-16 02:24:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:24:46 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:24:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:24:46 --> Encryption Class Initialized
INFO - 2026-02-16 02:24:46 --> Form Validation Class Initialized
INFO - 2026-02-16 02:24:46 --> Security Class Initialized
INFO - 2026-02-16 02:24:46 --> Helper loaded: cpanel_helper
DEBUG - 2026-02-16 02:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:24:46 --> CSRF cookie sent
INFO - 2026-02-16 02:24:46 --> Input Class Initialized
INFO - 2026-02-16 02:24:46 --> Language Class Initialized
INFO - 2026-02-16 02:24:46 --> Language Class Initialized
INFO - 2026-02-16 02:24:46 --> Config Class Initialized
INFO - 2026-02-16 02:24:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:24:46 --> Pagination Class Initialized
INFO - 2026-02-16 02:24:46 --> Config Class Initialized
INFO - 2026-02-16 02:24:46 --> Hooks Class Initialized
INFO - 2026-02-16 02:24:46 --> Email Class Initialized
INFO - 2026-02-16 02:24:46 --> Controller Class Initialized
INFO - 2026-02-16 02:24:46 --> Loader Class Initialized
INFO - 2026-02-16 02:24:46 --> Helper loaded: url_helper
DEBUG - 2026-02-16 02:24:46 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:24:46 --> Utf8 Class Initialized
DEBUG - 2026-02-16 02:24:46 --> Cart MX_Controller Initialized
INFO - 2026-02-16 02:24:46 --> URI Class Initialized
INFO - 2026-02-16 02:24:46 --> Helper loaded: form_helper
INFO - 2026-02-16 02:24:46 --> Helper loaded: html_helper
INFO - 2026-02-16 02:24:46 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:24:46 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:24:46 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:24:46 --> Database Driver Class Initialized
INFO - 2026-02-16 02:24:46 --> Model "Common_model" initialized
INFO - 2026-02-16 02:24:46 --> Helper loaded: file_helper
INFO - 2026-02-16 02:24:46 --> Model "Order_model" initialized
INFO - 2026-02-16 02:24:46 --> Helper loaded: email_helper
INFO - 2026-02-16 02:24:46 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 02:24:46 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:24:46 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:24:46 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:24:46 --> Router Class Initialized
INFO - 2026-02-16 02:24:46 --> Output Class Initialized
INFO - 2026-02-16 02:24:46 --> Database Driver Class Initialized
INFO - 2026-02-16 02:24:46 --> Security Class Initialized
DEBUG - 2026-02-16 02:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:24:46 --> CSRF cookie sent
INFO - 2026-02-16 02:24:46 --> Input Class Initialized
INFO - 2026-02-16 02:24:46 --> Language Class Initialized
INFO - 2026-02-16 02:24:46 --> Language Class Initialized
INFO - 2026-02-16 02:24:46 --> Config Class Initialized
INFO - 2026-02-16 02:24:46 --> Loader Class Initialized
INFO - 2026-02-16 02:24:46 --> Helper loaded: url_helper
INFO - 2026-02-16 02:24:46 --> Helper loaded: form_helper
INFO - 2026-02-16 02:24:46 --> Helper loaded: html_helper
INFO - 2026-02-16 02:24:46 --> Helper loaded: file_helper
INFO - 2026-02-16 02:24:46 --> Helper loaded: email_helper
INFO - 2026-02-16 02:24:46 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:24:46 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:24:46 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:24:46 --> Database Driver Class Initialized
INFO - 2026-02-16 02:24:47 --> Final output sent to browser
DEBUG - 2026-02-16 02:24:47 --> Total execution time: 2.4213
INFO - 2026-02-16 02:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:24:47 --> Upload Class Initialized
DEBUG - 2026-02-16 02:24:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:24:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:24:47 --> Encryption Class Initialized
INFO - 2026-02-16 02:24:47 --> Form Validation Class Initialized
INFO - 2026-02-16 02:24:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:24:47 --> Pagination Class Initialized
INFO - 2026-02-16 02:24:47 --> Email Class Initialized
INFO - 2026-02-16 02:24:47 --> Controller Class Initialized
ERROR - 2026-02-16 02:24:47 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:24:47 --> Upload Class Initialized
DEBUG - 2026-02-16 02:24:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:24:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:24:47 --> Encryption Class Initialized
INFO - 2026-02-16 02:24:47 --> Form Validation Class Initialized
INFO - 2026-02-16 02:24:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:24:47 --> Pagination Class Initialized
INFO - 2026-02-16 02:24:47 --> Email Class Initialized
INFO - 2026-02-16 02:24:47 --> Controller Class Initialized
ERROR - 2026-02-16 02:24:47 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:24:48 --> Upload Class Initialized
DEBUG - 2026-02-16 02:24:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:24:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:24:48 --> Encryption Class Initialized
INFO - 2026-02-16 02:24:48 --> Form Validation Class Initialized
INFO - 2026-02-16 02:24:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:24:48 --> Pagination Class Initialized
INFO - 2026-02-16 02:24:48 --> Email Class Initialized
INFO - 2026-02-16 02:24:48 --> Controller Class Initialized
ERROR - 2026-02-16 02:24:48 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:24:48 --> Upload Class Initialized
DEBUG - 2026-02-16 02:24:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:24:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:24:48 --> Encryption Class Initialized
INFO - 2026-02-16 02:24:48 --> Form Validation Class Initialized
INFO - 2026-02-16 02:24:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:24:48 --> Pagination Class Initialized
INFO - 2026-02-16 02:24:48 --> Email Class Initialized
INFO - 2026-02-16 02:24:48 --> Controller Class Initialized
ERROR - 2026-02-16 02:24:48 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:24:48 --> Upload Class Initialized
DEBUG - 2026-02-16 02:24:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:24:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:24:48 --> Encryption Class Initialized
INFO - 2026-02-16 02:24:48 --> Form Validation Class Initialized
INFO - 2026-02-16 02:24:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:24:48 --> Pagination Class Initialized
INFO - 2026-02-16 02:24:48 --> Email Class Initialized
INFO - 2026-02-16 02:24:48 --> Controller Class Initialized
ERROR - 2026-02-16 02:24:48 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:24:50 --> Config Class Initialized
INFO - 2026-02-16 02:24:50 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:24:50 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:24:50 --> Utf8 Class Initialized
INFO - 2026-02-16 02:24:50 --> URI Class Initialized
INFO - 2026-02-16 02:24:50 --> Router Class Initialized
INFO - 2026-02-16 02:24:50 --> Output Class Initialized
INFO - 2026-02-16 02:24:50 --> Security Class Initialized
DEBUG - 2026-02-16 02:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:24:50 --> CSRF cookie sent
INFO - 2026-02-16 02:24:50 --> CSRF token verified
INFO - 2026-02-16 02:24:50 --> Input Class Initialized
INFO - 2026-02-16 02:24:50 --> Language Class Initialized
INFO - 2026-02-16 02:24:50 --> Language Class Initialized
INFO - 2026-02-16 02:24:50 --> Config Class Initialized
INFO - 2026-02-16 02:24:50 --> Loader Class Initialized
INFO - 2026-02-16 02:24:50 --> Helper loaded: url_helper
INFO - 2026-02-16 02:24:50 --> Helper loaded: form_helper
INFO - 2026-02-16 02:24:50 --> Helper loaded: html_helper
INFO - 2026-02-16 02:24:50 --> Helper loaded: file_helper
INFO - 2026-02-16 02:24:50 --> Helper loaded: email_helper
INFO - 2026-02-16 02:24:50 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:24:50 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:24:50 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:24:50 --> Database Driver Class Initialized
INFO - 2026-02-16 02:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:24:52 --> Upload Class Initialized
DEBUG - 2026-02-16 02:24:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:24:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:24:52 --> Encryption Class Initialized
INFO - 2026-02-16 02:24:52 --> Form Validation Class Initialized
INFO - 2026-02-16 02:24:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:24:52 --> Pagination Class Initialized
INFO - 2026-02-16 02:24:52 --> Email Class Initialized
INFO - 2026-02-16 02:24:52 --> Controller Class Initialized
DEBUG - 2026-02-16 02:24:52 --> Pay MX_Controller Initialized
INFO - 2026-02-16 02:24:52 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:24:52 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:24:52 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:24:52 --> Model "Payment_model" initialized
INFO - 2026-02-16 02:24:52 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-16 02:24:52 --> Model "Billing_model" initialized
INFO - 2026-02-16 02:24:52 --> Model "Invoice_model" initialized
INFO - 2026-02-16 02:24:57 --> Final output sent to browser
DEBUG - 2026-02-16 02:24:57 --> Total execution time: 7.5034
INFO - 2026-02-16 02:25:12 --> Config Class Initialized
INFO - 2026-02-16 02:25:12 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:25:12 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:25:12 --> Utf8 Class Initialized
INFO - 2026-02-16 02:25:12 --> URI Class Initialized
INFO - 2026-02-16 02:25:12 --> Router Class Initialized
INFO - 2026-02-16 02:25:12 --> Output Class Initialized
INFO - 2026-02-16 02:25:12 --> Security Class Initialized
DEBUG - 2026-02-16 02:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:25:12 --> Input Class Initialized
INFO - 2026-02-16 02:25:12 --> Language Class Initialized
INFO - 2026-02-16 02:25:12 --> Language Class Initialized
INFO - 2026-02-16 02:25:12 --> Config Class Initialized
INFO - 2026-02-16 02:25:12 --> Loader Class Initialized
INFO - 2026-02-16 02:25:12 --> Helper loaded: url_helper
INFO - 2026-02-16 02:25:12 --> Helper loaded: form_helper
INFO - 2026-02-16 02:25:12 --> Helper loaded: html_helper
INFO - 2026-02-16 02:25:12 --> Helper loaded: file_helper
INFO - 2026-02-16 02:25:12 --> Helper loaded: email_helper
INFO - 2026-02-16 02:25:12 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:25:12 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:25:12 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:25:12 --> Database Driver Class Initialized
INFO - 2026-02-16 02:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:25:13 --> Upload Class Initialized
DEBUG - 2026-02-16 02:25:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:25:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:25:13 --> Encryption Class Initialized
INFO - 2026-02-16 02:25:13 --> Form Validation Class Initialized
INFO - 2026-02-16 02:25:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:25:13 --> Pagination Class Initialized
INFO - 2026-02-16 02:25:13 --> Email Class Initialized
INFO - 2026-02-16 02:25:13 --> Controller Class Initialized
DEBUG - 2026-02-16 02:25:13 --> Pay MX_Controller Initialized
INFO - 2026-02-16 02:25:13 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:25:13 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:25:13 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:25:14 --> Model "Payment_model" initialized
INFO - 2026-02-16 02:25:14 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-16 02:25:14 --> Model "Billing_model" initialized
INFO - 2026-02-16 02:25:14 --> Model "Invoice_model" initialized
INFO - 2026-02-16 02:25:18 --> Model "Common_model" initialized
INFO - 2026-02-16 02:25:18 --> Model "Order_model" initialized
INFO - 2026-02-16 02:25:18 --> Model "Company_model" initialized
INFO - 2026-02-16 02:25:18 --> Invoice #553 marked as PAID. Total: 32.95, Paid: 32.95
INFO - 2026-02-16 02:25:21 --> Config Class Initialized
INFO - 2026-02-16 02:25:21 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:25:21 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:25:21 --> Utf8 Class Initialized
INFO - 2026-02-16 02:25:21 --> URI Class Initialized
INFO - 2026-02-16 02:25:21 --> Router Class Initialized
INFO - 2026-02-16 02:25:21 --> Output Class Initialized
INFO - 2026-02-16 02:25:21 --> Security Class Initialized
DEBUG - 2026-02-16 02:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:25:21 --> CSRF cookie sent
INFO - 2026-02-16 02:25:21 --> Input Class Initialized
INFO - 2026-02-16 02:25:21 --> Language Class Initialized
INFO - 2026-02-16 02:25:21 --> Language Class Initialized
INFO - 2026-02-16 02:25:21 --> Config Class Initialized
INFO - 2026-02-16 02:25:21 --> Loader Class Initialized
INFO - 2026-02-16 02:25:21 --> Helper loaded: url_helper
INFO - 2026-02-16 02:25:21 --> Helper loaded: form_helper
INFO - 2026-02-16 02:25:21 --> Helper loaded: html_helper
INFO - 2026-02-16 02:25:21 --> Helper loaded: file_helper
INFO - 2026-02-16 02:25:21 --> Helper loaded: email_helper
INFO - 2026-02-16 02:25:21 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:25:21 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:25:21 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:25:21 --> Database Driver Class Initialized
INFO - 2026-02-16 02:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:25:23 --> Upload Class Initialized
DEBUG - 2026-02-16 02:25:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:25:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:25:23 --> Encryption Class Initialized
INFO - 2026-02-16 02:25:23 --> Form Validation Class Initialized
INFO - 2026-02-16 02:25:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:25:23 --> Pagination Class Initialized
INFO - 2026-02-16 02:25:23 --> Email Class Initialized
INFO - 2026-02-16 02:25:23 --> Controller Class Initialized
DEBUG - 2026-02-16 02:25:23 --> Billing MX_Controller Initialized
INFO - 2026-02-16 02:25:23 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:25:23 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:25:23 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:25:23 --> Model "Billing_model" initialized
INFO - 2026-02-16 02:25:23 --> Model "Common_model" initialized
INFO - 2026-02-16 02:25:23 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 02:25:23 --> Config Class Initialized
INFO - 2026-02-16 02:25:23 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:25:23 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:25:23 --> Utf8 Class Initialized
INFO - 2026-02-16 02:25:23 --> URI Class Initialized
INFO - 2026-02-16 02:25:23 --> Router Class Initialized
INFO - 2026-02-16 02:25:23 --> Output Class Initialized
INFO - 2026-02-16 02:25:23 --> Security Class Initialized
DEBUG - 2026-02-16 02:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:25:23 --> CSRF cookie sent
INFO - 2026-02-16 02:25:23 --> Input Class Initialized
INFO - 2026-02-16 02:25:23 --> Language Class Initialized
INFO - 2026-02-16 02:25:23 --> Language Class Initialized
INFO - 2026-02-16 02:25:23 --> Config Class Initialized
INFO - 2026-02-16 02:25:23 --> Loader Class Initialized
INFO - 2026-02-16 02:25:23 --> Helper loaded: url_helper
INFO - 2026-02-16 02:25:23 --> Helper loaded: form_helper
INFO - 2026-02-16 02:25:23 --> Helper loaded: html_helper
INFO - 2026-02-16 02:25:23 --> Helper loaded: file_helper
INFO - 2026-02-16 02:25:23 --> Helper loaded: email_helper
INFO - 2026-02-16 02:25:23 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:25:23 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:25:23 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:25:23 --> Database Driver Class Initialized
INFO - 2026-02-16 02:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:25:25 --> Upload Class Initialized
DEBUG - 2026-02-16 02:25:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:25:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:25:25 --> Encryption Class Initialized
INFO - 2026-02-16 02:25:25 --> Form Validation Class Initialized
INFO - 2026-02-16 02:25:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:25:25 --> Pagination Class Initialized
INFO - 2026-02-16 02:25:25 --> Email Class Initialized
INFO - 2026-02-16 02:25:25 --> Controller Class Initialized
DEBUG - 2026-02-16 02:25:25 --> Auth MX_Controller Initialized
INFO - 2026-02-16 02:25:25 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:25:25 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:25:25 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:25:25 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-16 02:25:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-16 02:25:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-16 02:25:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-16 02:25:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-02-16 02:25:25 --> Final output sent to browser
DEBUG - 2026-02-16 02:25:25 --> Total execution time: 2.3082
INFO - 2026-02-16 02:25:25 --> Config Class Initialized
INFO - 2026-02-16 02:25:25 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:25:25 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:25:25 --> Utf8 Class Initialized
INFO - 2026-02-16 02:25:25 --> Config Class Initialized
INFO - 2026-02-16 02:25:25 --> Hooks Class Initialized
INFO - 2026-02-16 02:25:25 --> URI Class Initialized
DEBUG - 2026-02-16 02:25:25 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:25:25 --> Utf8 Class Initialized
INFO - 2026-02-16 02:25:25 --> Router Class Initialized
INFO - 2026-02-16 02:25:25 --> URI Class Initialized
INFO - 2026-02-16 02:25:25 --> Output Class Initialized
INFO - 2026-02-16 02:25:25 --> Router Class Initialized
INFO - 2026-02-16 02:25:25 --> Security Class Initialized
DEBUG - 2026-02-16 02:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:25:25 --> CSRF cookie sent
INFO - 2026-02-16 02:25:25 --> Input Class Initialized
INFO - 2026-02-16 02:25:25 --> Output Class Initialized
INFO - 2026-02-16 02:25:25 --> Language Class Initialized
INFO - 2026-02-16 02:25:25 --> Language Class Initialized
INFO - 2026-02-16 02:25:25 --> Config Class Initialized
INFO - 2026-02-16 02:25:25 --> Loader Class Initialized
INFO - 2026-02-16 02:25:25 --> Helper loaded: url_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: form_helper
INFO - 2026-02-16 02:25:25 --> Security Class Initialized
INFO - 2026-02-16 02:25:25 --> Helper loaded: html_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: file_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: email_helper
DEBUG - 2026-02-16 02:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:25:25 --> CSRF cookie sent
INFO - 2026-02-16 02:25:25 --> Input Class Initialized
INFO - 2026-02-16 02:25:25 --> Language Class Initialized
INFO - 2026-02-16 02:25:25 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:25:25 --> Language Class Initialized
INFO - 2026-02-16 02:25:25 --> Config Class Initialized
INFO - 2026-02-16 02:25:25 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:25:25 --> Database Driver Class Initialized
INFO - 2026-02-16 02:25:25 --> Loader Class Initialized
INFO - 2026-02-16 02:25:25 --> Helper loaded: url_helper
INFO - 2026-02-16 02:25:25 --> Config Class Initialized
INFO - 2026-02-16 02:25:25 --> Hooks Class Initialized
INFO - 2026-02-16 02:25:25 --> Helper loaded: form_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: html_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: file_helper
DEBUG - 2026-02-16 02:25:25 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:25:25 --> Utf8 Class Initialized
INFO - 2026-02-16 02:25:25 --> Helper loaded: email_helper
INFO - 2026-02-16 02:25:25 --> URI Class Initialized
INFO - 2026-02-16 02:25:25 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:25:25 --> Config Class Initialized
INFO - 2026-02-16 02:25:25 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:25:25 --> Router Class Initialized
INFO - 2026-02-16 02:25:25 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:25:25 --> Config Class Initialized
INFO - 2026-02-16 02:25:25 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:25:25 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:25:25 --> Utf8 Class Initialized
INFO - 2026-02-16 02:25:25 --> URI Class Initialized
INFO - 2026-02-16 02:25:25 --> Hooks Class Initialized
INFO - 2026-02-16 02:25:25 --> Output Class Initialized
DEBUG - 2026-02-16 02:25:25 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:25:25 --> Utf8 Class Initialized
INFO - 2026-02-16 02:25:25 --> URI Class Initialized
INFO - 2026-02-16 02:25:25 --> Security Class Initialized
DEBUG - 2026-02-16 02:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:25:25 --> CSRF cookie sent
INFO - 2026-02-16 02:25:25 --> Input Class Initialized
INFO - 2026-02-16 02:25:25 --> Language Class Initialized
INFO - 2026-02-16 02:25:25 --> Router Class Initialized
INFO - 2026-02-16 02:25:25 --> Language Class Initialized
INFO - 2026-02-16 02:25:25 --> Config Class Initialized
INFO - 2026-02-16 02:25:25 --> Output Class Initialized
INFO - 2026-02-16 02:25:25 --> Database Driver Class Initialized
INFO - 2026-02-16 02:25:25 --> Security Class Initialized
DEBUG - 2026-02-16 02:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:25:25 --> CSRF cookie sent
INFO - 2026-02-16 02:25:25 --> Input Class Initialized
INFO - 2026-02-16 02:25:25 --> Language Class Initialized
INFO - 2026-02-16 02:25:25 --> Router Class Initialized
INFO - 2026-02-16 02:25:25 --> Language Class Initialized
INFO - 2026-02-16 02:25:25 --> Config Class Initialized
INFO - 2026-02-16 02:25:25 --> Output Class Initialized
INFO - 2026-02-16 02:25:25 --> Loader Class Initialized
INFO - 2026-02-16 02:25:25 --> Helper loaded: url_helper
INFO - 2026-02-16 02:25:25 --> Security Class Initialized
INFO - 2026-02-16 02:25:25 --> Helper loaded: form_helper
INFO - 2026-02-16 02:25:25 --> Loader Class Initialized
INFO - 2026-02-16 02:25:25 --> Helper loaded: html_helper
DEBUG - 2026-02-16 02:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:25:25 --> CSRF cookie sent
INFO - 2026-02-16 02:25:25 --> Input Class Initialized
INFO - 2026-02-16 02:25:25 --> Language Class Initialized
INFO - 2026-02-16 02:25:25 --> Helper loaded: file_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: url_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: email_helper
INFO - 2026-02-16 02:25:25 --> Language Class Initialized
INFO - 2026-02-16 02:25:25 --> Config Class Initialized
INFO - 2026-02-16 02:25:25 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: form_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: html_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: file_helper
INFO - 2026-02-16 02:25:25 --> Loader Class Initialized
INFO - 2026-02-16 02:25:25 --> Helper loaded: email_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: url_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: form_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: html_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: file_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: email_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:25:25 --> Database Driver Class Initialized
INFO - 2026-02-16 02:25:25 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:25:25 --> Database Driver Class Initialized
INFO - 2026-02-16 02:25:25 --> Database Driver Class Initialized
INFO - 2026-02-16 02:25:25 --> Config Class Initialized
INFO - 2026-02-16 02:25:25 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:25:25 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:25:25 --> Utf8 Class Initialized
INFO - 2026-02-16 02:25:25 --> URI Class Initialized
INFO - 2026-02-16 02:25:25 --> Router Class Initialized
INFO - 2026-02-16 02:25:25 --> Output Class Initialized
INFO - 2026-02-16 02:25:25 --> Security Class Initialized
DEBUG - 2026-02-16 02:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:25:25 --> CSRF cookie sent
INFO - 2026-02-16 02:25:25 --> Input Class Initialized
INFO - 2026-02-16 02:25:25 --> Language Class Initialized
INFO - 2026-02-16 02:25:25 --> Language Class Initialized
INFO - 2026-02-16 02:25:25 --> Config Class Initialized
INFO - 2026-02-16 02:25:25 --> Loader Class Initialized
INFO - 2026-02-16 02:25:25 --> Helper loaded: url_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: form_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: html_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: file_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: email_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:25:25 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:25:25 --> Database Driver Class Initialized
INFO - 2026-02-16 02:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:25:27 --> Upload Class Initialized
DEBUG - 2026-02-16 02:25:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:25:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:25:27 --> Encryption Class Initialized
INFO - 2026-02-16 02:25:27 --> Form Validation Class Initialized
INFO - 2026-02-16 02:25:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:25:27 --> Pagination Class Initialized
INFO - 2026-02-16 02:25:27 --> Email Class Initialized
INFO - 2026-02-16 02:25:27 --> Controller Class Initialized
ERROR - 2026-02-16 02:25:27 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:25:27 --> Upload Class Initialized
DEBUG - 2026-02-16 02:25:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:25:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:25:27 --> Encryption Class Initialized
INFO - 2026-02-16 02:25:27 --> Form Validation Class Initialized
INFO - 2026-02-16 02:25:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:25:27 --> Pagination Class Initialized
INFO - 2026-02-16 02:25:27 --> Config Class Initialized
INFO - 2026-02-16 02:25:27 --> Hooks Class Initialized
INFO - 2026-02-16 02:25:27 --> Email Class Initialized
INFO - 2026-02-16 02:25:27 --> Controller Class Initialized
ERROR - 2026-02-16 02:25:27 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:25:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-02-16 02:25:27 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:25:27 --> Utf8 Class Initialized
INFO - 2026-02-16 02:25:27 --> URI Class Initialized
INFO - 2026-02-16 02:25:27 --> Upload Class Initialized
INFO - 2026-02-16 02:25:27 --> Router Class Initialized
DEBUG - 2026-02-16 02:25:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:25:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:25:27 --> Encryption Class Initialized
INFO - 2026-02-16 02:25:27 --> Output Class Initialized
INFO - 2026-02-16 02:25:27 --> Security Class Initialized
DEBUG - 2026-02-16 02:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:25:27 --> CSRF cookie sent
INFO - 2026-02-16 02:25:27 --> Input Class Initialized
INFO - 2026-02-16 02:25:27 --> Language Class Initialized
INFO - 2026-02-16 02:25:27 --> Form Validation Class Initialized
INFO - 2026-02-16 02:25:27 --> Language Class Initialized
INFO - 2026-02-16 02:25:27 --> Config Class Initialized
INFO - 2026-02-16 02:25:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:25:27 --> Pagination Class Initialized
INFO - 2026-02-16 02:25:27 --> Loader Class Initialized
INFO - 2026-02-16 02:25:27 --> Helper loaded: url_helper
INFO - 2026-02-16 02:25:27 --> Config Class Initialized
INFO - 2026-02-16 02:25:27 --> Hooks Class Initialized
INFO - 2026-02-16 02:25:27 --> Helper loaded: form_helper
INFO - 2026-02-16 02:25:27 --> Helper loaded: html_helper
INFO - 2026-02-16 02:25:27 --> Helper loaded: file_helper
INFO - 2026-02-16 02:25:27 --> Helper loaded: email_helper
DEBUG - 2026-02-16 02:25:27 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:25:27 --> Utf8 Class Initialized
INFO - 2026-02-16 02:25:27 --> Email Class Initialized
INFO - 2026-02-16 02:25:27 --> Controller Class Initialized
INFO - 2026-02-16 02:25:27 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:25:27 --> URI Class Initialized
ERROR - 2026-02-16 02:25:27 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:25:27 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:25:27 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:25:27 --> Upload Class Initialized
INFO - 2026-02-16 02:25:27 --> Router Class Initialized
DEBUG - 2026-02-16 02:25:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:25:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:25:27 --> Encryption Class Initialized
INFO - 2026-02-16 02:25:27 --> Output Class Initialized
INFO - 2026-02-16 02:25:27 --> Security Class Initialized
INFO - 2026-02-16 02:25:27 --> Form Validation Class Initialized
INFO - 2026-02-16 02:25:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:25:27 --> Pagination Class Initialized
DEBUG - 2026-02-16 02:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:25:27 --> CSRF cookie sent
INFO - 2026-02-16 02:25:27 --> Input Class Initialized
INFO - 2026-02-16 02:25:27 --> Language Class Initialized
INFO - 2026-02-16 02:25:27 --> Database Driver Class Initialized
INFO - 2026-02-16 02:25:27 --> Language Class Initialized
INFO - 2026-02-16 02:25:27 --> Config Class Initialized
INFO - 2026-02-16 02:25:27 --> Email Class Initialized
INFO - 2026-02-16 02:25:27 --> Controller Class Initialized
ERROR - 2026-02-16 02:25:27 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:25:27 --> Config Class Initialized
INFO - 2026-02-16 02:25:27 --> Upload Class Initialized
INFO - 2026-02-16 02:25:27 --> Hooks Class Initialized
INFO - 2026-02-16 02:25:27 --> Loader Class Initialized
INFO - 2026-02-16 02:25:27 --> Helper loaded: url_helper
DEBUG - 2026-02-16 02:25:27 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:25:27 --> Utf8 Class Initialized
DEBUG - 2026-02-16 02:25:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:25:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:25:27 --> Encryption Class Initialized
INFO - 2026-02-16 02:25:27 --> URI Class Initialized
INFO - 2026-02-16 02:25:27 --> Helper loaded: form_helper
INFO - 2026-02-16 02:25:27 --> Helper loaded: html_helper
INFO - 2026-02-16 02:25:27 --> Form Validation Class Initialized
INFO - 2026-02-16 02:25:27 --> Helper loaded: file_helper
INFO - 2026-02-16 02:25:27 --> Router Class Initialized
INFO - 2026-02-16 02:25:27 --> Helper loaded: email_helper
INFO - 2026-02-16 02:25:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:25:27 --> Pagination Class Initialized
INFO - 2026-02-16 02:25:27 --> Output Class Initialized
INFO - 2026-02-16 02:25:27 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:25:27 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:25:27 --> Security Class Initialized
INFO - 2026-02-16 02:25:27 --> Helper loaded: cpanel_helper
DEBUG - 2026-02-16 02:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:25:27 --> CSRF cookie sent
INFO - 2026-02-16 02:25:27 --> Input Class Initialized
INFO - 2026-02-16 02:25:27 --> Language Class Initialized
INFO - 2026-02-16 02:25:27 --> Email Class Initialized
INFO - 2026-02-16 02:25:27 --> Controller Class Initialized
INFO - 2026-02-16 02:25:27 --> Language Class Initialized
INFO - 2026-02-16 02:25:27 --> Config Class Initialized
ERROR - 2026-02-16 02:25:27 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:25:27 --> Loader Class Initialized
INFO - 2026-02-16 02:25:27 --> Helper loaded: url_helper
INFO - 2026-02-16 02:25:27 --> Database Driver Class Initialized
INFO - 2026-02-16 02:25:27 --> Helper loaded: form_helper
INFO - 2026-02-16 02:25:27 --> Helper loaded: html_helper
INFO - 2026-02-16 02:25:27 --> Helper loaded: file_helper
INFO - 2026-02-16 02:25:27 --> Helper loaded: email_helper
INFO - 2026-02-16 02:25:27 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:25:27 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:25:27 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:25:27 --> Database Driver Class Initialized
INFO - 2026-02-16 02:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:25:28 --> Upload Class Initialized
DEBUG - 2026-02-16 02:25:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:25:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:25:28 --> Encryption Class Initialized
INFO - 2026-02-16 02:25:28 --> Form Validation Class Initialized
INFO - 2026-02-16 02:25:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:25:28 --> Pagination Class Initialized
INFO - 2026-02-16 02:25:28 --> Email Class Initialized
INFO - 2026-02-16 02:25:28 --> Controller Class Initialized
ERROR - 2026-02-16 02:25:28 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:25:29 --> Upload Class Initialized
DEBUG - 2026-02-16 02:25:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:25:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:25:29 --> Encryption Class Initialized
INFO - 2026-02-16 02:25:29 --> Form Validation Class Initialized
INFO - 2026-02-16 02:25:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:25:29 --> Pagination Class Initialized
INFO - 2026-02-16 02:25:29 --> Email Class Initialized
INFO - 2026-02-16 02:25:29 --> Controller Class Initialized
DEBUG - 2026-02-16 02:25:29 --> Cart MX_Controller Initialized
INFO - 2026-02-16 02:25:29 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:25:29 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:25:29 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:25:29 --> Model "Common_model" initialized
INFO - 2026-02-16 02:25:29 --> Model "Order_model" initialized
INFO - 2026-02-16 02:25:29 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 02:25:29 --> Final output sent to browser
DEBUG - 2026-02-16 02:25:29 --> Total execution time: 2.3387
INFO - 2026-02-16 02:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:25:29 --> Upload Class Initialized
DEBUG - 2026-02-16 02:25:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:25:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:25:29 --> Encryption Class Initialized
INFO - 2026-02-16 02:25:30 --> Form Validation Class Initialized
INFO - 2026-02-16 02:25:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:25:30 --> Pagination Class Initialized
INFO - 2026-02-16 02:25:30 --> Email Class Initialized
INFO - 2026-02-16 02:25:30 --> Controller Class Initialized
ERROR - 2026-02-16 02:25:30 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:25:30 --> Upload Class Initialized
DEBUG - 2026-02-16 02:25:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:25:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:25:30 --> Encryption Class Initialized
INFO - 2026-02-16 02:25:30 --> Form Validation Class Initialized
INFO - 2026-02-16 02:25:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:25:30 --> Pagination Class Initialized
INFO - 2026-02-16 02:25:30 --> Email Class Initialized
INFO - 2026-02-16 02:25:30 --> Controller Class Initialized
ERROR - 2026-02-16 02:25:30 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:25:41 --> Config Class Initialized
INFO - 2026-02-16 02:25:41 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:25:41 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:25:41 --> Utf8 Class Initialized
INFO - 2026-02-16 02:25:41 --> URI Class Initialized
INFO - 2026-02-16 02:25:41 --> Router Class Initialized
INFO - 2026-02-16 02:25:41 --> Output Class Initialized
INFO - 2026-02-16 02:25:41 --> Security Class Initialized
DEBUG - 2026-02-16 02:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:25:41 --> CSRF cookie sent
INFO - 2026-02-16 02:25:41 --> CSRF token verified
INFO - 2026-02-16 02:25:41 --> Input Class Initialized
INFO - 2026-02-16 02:25:41 --> Language Class Initialized
INFO - 2026-02-16 02:25:41 --> Language Class Initialized
INFO - 2026-02-16 02:25:41 --> Config Class Initialized
INFO - 2026-02-16 02:25:41 --> Loader Class Initialized
INFO - 2026-02-16 02:25:41 --> Helper loaded: url_helper
INFO - 2026-02-16 02:25:41 --> Helper loaded: form_helper
INFO - 2026-02-16 02:25:41 --> Helper loaded: html_helper
INFO - 2026-02-16 02:25:41 --> Helper loaded: file_helper
INFO - 2026-02-16 02:25:41 --> Helper loaded: email_helper
INFO - 2026-02-16 02:25:41 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:25:41 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:25:41 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:25:41 --> Database Driver Class Initialized
INFO - 2026-02-16 02:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:25:43 --> Upload Class Initialized
DEBUG - 2026-02-16 02:25:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:25:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:25:43 --> Encryption Class Initialized
INFO - 2026-02-16 02:25:43 --> Form Validation Class Initialized
INFO - 2026-02-16 02:25:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:25:43 --> Pagination Class Initialized
INFO - 2026-02-16 02:25:43 --> Email Class Initialized
INFO - 2026-02-16 02:25:43 --> Controller Class Initialized
DEBUG - 2026-02-16 02:25:43 --> Auth MX_Controller Initialized
INFO - 2026-02-16 02:25:43 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:25:43 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:25:43 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:25:43 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 02:25:46 --> Config Class Initialized
INFO - 2026-02-16 02:25:46 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:25:46 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:25:46 --> Utf8 Class Initialized
INFO - 2026-02-16 02:25:46 --> URI Class Initialized
INFO - 2026-02-16 02:25:46 --> Router Class Initialized
INFO - 2026-02-16 02:25:46 --> Output Class Initialized
INFO - 2026-02-16 02:25:46 --> Security Class Initialized
DEBUG - 2026-02-16 02:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:25:46 --> CSRF cookie sent
INFO - 2026-02-16 02:25:46 --> Input Class Initialized
INFO - 2026-02-16 02:25:46 --> Language Class Initialized
INFO - 2026-02-16 02:25:46 --> Language Class Initialized
INFO - 2026-02-16 02:25:46 --> Config Class Initialized
INFO - 2026-02-16 02:25:46 --> Loader Class Initialized
INFO - 2026-02-16 02:25:46 --> Helper loaded: url_helper
INFO - 2026-02-16 02:25:46 --> Helper loaded: form_helper
INFO - 2026-02-16 02:25:46 --> Helper loaded: html_helper
INFO - 2026-02-16 02:25:46 --> Helper loaded: file_helper
INFO - 2026-02-16 02:25:46 --> Helper loaded: email_helper
INFO - 2026-02-16 02:25:46 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:25:46 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:25:46 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:25:46 --> Database Driver Class Initialized
INFO - 2026-02-16 02:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:25:48 --> Upload Class Initialized
DEBUG - 2026-02-16 02:25:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:25:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:25:48 --> Encryption Class Initialized
INFO - 2026-02-16 02:25:48 --> Form Validation Class Initialized
INFO - 2026-02-16 02:25:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:25:48 --> Pagination Class Initialized
INFO - 2026-02-16 02:25:48 --> Email Class Initialized
INFO - 2026-02-16 02:25:48 --> Controller Class Initialized
DEBUG - 2026-02-16 02:25:48 --> Clientarea MX_Controller Initialized
INFO - 2026-02-16 02:25:48 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:25:48 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:25:48 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:25:48 --> Model "Clientarea_model" initialized
INFO - 2026-02-16 02:25:48 --> Model "Billing_model" initialized
INFO - 2026-02-16 02:25:48 --> Model "Common_model" initialized
INFO - 2026-02-16 02:25:48 --> Model "Order_model" initialized
INFO - 2026-02-16 02:25:48 --> Model "Support_model" initialized
DEBUG - 2026-02-16 02:25:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-16 02:25:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-16 02:25:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-16 02:25:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_index.php
INFO - 2026-02-16 02:25:49 --> Final output sent to browser
DEBUG - 2026-02-16 02:25:49 --> Total execution time: 2.4060
INFO - 2026-02-16 02:25:49 --> Config Class Initialized
INFO - 2026-02-16 02:25:49 --> Config Class Initialized
INFO - 2026-02-16 02:25:49 --> Hooks Class Initialized
INFO - 2026-02-16 02:25:49 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:25:49 --> UTF-8 Support Enabled
DEBUG - 2026-02-16 02:25:49 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:25:49 --> Utf8 Class Initialized
INFO - 2026-02-16 02:25:49 --> Utf8 Class Initialized
INFO - 2026-02-16 02:25:49 --> URI Class Initialized
INFO - 2026-02-16 02:25:49 --> URI Class Initialized
INFO - 2026-02-16 02:25:49 --> Router Class Initialized
INFO - 2026-02-16 02:25:49 --> Router Class Initialized
INFO - 2026-02-16 02:25:49 --> Output Class Initialized
INFO - 2026-02-16 02:25:49 --> Output Class Initialized
INFO - 2026-02-16 02:25:49 --> Security Class Initialized
INFO - 2026-02-16 02:25:49 --> Security Class Initialized
DEBUG - 2026-02-16 02:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-02-16 02:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:25:49 --> CSRF cookie sent
INFO - 2026-02-16 02:25:49 --> Input Class Initialized
INFO - 2026-02-16 02:25:49 --> CSRF cookie sent
INFO - 2026-02-16 02:25:49 --> Input Class Initialized
INFO - 2026-02-16 02:25:49 --> Language Class Initialized
INFO - 2026-02-16 02:25:49 --> Language Class Initialized
INFO - 2026-02-16 02:25:49 --> Language Class Initialized
INFO - 2026-02-16 02:25:49 --> Language Class Initialized
INFO - 2026-02-16 02:25:49 --> Config Class Initialized
INFO - 2026-02-16 02:25:49 --> Config Class Initialized
INFO - 2026-02-16 02:25:49 --> Loader Class Initialized
INFO - 2026-02-16 02:25:49 --> Loader Class Initialized
INFO - 2026-02-16 02:25:49 --> Helper loaded: url_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: url_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: form_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: form_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: html_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: html_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: file_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: email_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: file_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: email_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:25:49 --> Database Driver Class Initialized
INFO - 2026-02-16 02:25:49 --> Database Driver Class Initialized
INFO - 2026-02-16 02:25:49 --> Config Class Initialized
INFO - 2026-02-16 02:25:49 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:25:49 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:25:49 --> Utf8 Class Initialized
INFO - 2026-02-16 02:25:49 --> URI Class Initialized
INFO - 2026-02-16 02:25:49 --> Router Class Initialized
INFO - 2026-02-16 02:25:49 --> Output Class Initialized
INFO - 2026-02-16 02:25:49 --> Security Class Initialized
DEBUG - 2026-02-16 02:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:25:49 --> CSRF cookie sent
INFO - 2026-02-16 02:25:49 --> Input Class Initialized
INFO - 2026-02-16 02:25:49 --> Language Class Initialized
INFO - 2026-02-16 02:25:49 --> Language Class Initialized
INFO - 2026-02-16 02:25:49 --> Config Class Initialized
INFO - 2026-02-16 02:25:49 --> Loader Class Initialized
INFO - 2026-02-16 02:25:49 --> Config Class Initialized
INFO - 2026-02-16 02:25:49 --> Hooks Class Initialized
INFO - 2026-02-16 02:25:49 --> Helper loaded: url_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: form_helper
DEBUG - 2026-02-16 02:25:49 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:25:49 --> Utf8 Class Initialized
INFO - 2026-02-16 02:25:49 --> Helper loaded: html_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: file_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: email_helper
INFO - 2026-02-16 02:25:49 --> URI Class Initialized
INFO - 2026-02-16 02:25:49 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:25:49 --> Router Class Initialized
INFO - 2026-02-16 02:25:49 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:25:49 --> Output Class Initialized
INFO - 2026-02-16 02:25:49 --> Security Class Initialized
DEBUG - 2026-02-16 02:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:25:49 --> CSRF cookie sent
INFO - 2026-02-16 02:25:49 --> Input Class Initialized
INFO - 2026-02-16 02:25:49 --> Language Class Initialized
INFO - 2026-02-16 02:25:49 --> Language Class Initialized
INFO - 2026-02-16 02:25:49 --> Config Class Initialized
INFO - 2026-02-16 02:25:49 --> Database Driver Class Initialized
INFO - 2026-02-16 02:25:49 --> Config Class Initialized
INFO - 2026-02-16 02:25:49 --> Hooks Class Initialized
INFO - 2026-02-16 02:25:49 --> Config Class Initialized
INFO - 2026-02-16 02:25:49 --> Hooks Class Initialized
INFO - 2026-02-16 02:25:49 --> Loader Class Initialized
INFO - 2026-02-16 02:25:49 --> Helper loaded: url_helper
DEBUG - 2026-02-16 02:25:49 --> UTF-8 Support Enabled
DEBUG - 2026-02-16 02:25:49 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:25:49 --> Utf8 Class Initialized
INFO - 2026-02-16 02:25:49 --> Utf8 Class Initialized
INFO - 2026-02-16 02:25:49 --> Helper loaded: form_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: html_helper
INFO - 2026-02-16 02:25:49 --> URI Class Initialized
INFO - 2026-02-16 02:25:49 --> URI Class Initialized
INFO - 2026-02-16 02:25:49 --> Helper loaded: file_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: email_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:25:49 --> Router Class Initialized
INFO - 2026-02-16 02:25:49 --> Router Class Initialized
INFO - 2026-02-16 02:25:49 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:25:49 --> Output Class Initialized
INFO - 2026-02-16 02:25:49 --> Output Class Initialized
INFO - 2026-02-16 02:25:49 --> Security Class Initialized
INFO - 2026-02-16 02:25:49 --> Security Class Initialized
DEBUG - 2026-02-16 02:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-02-16 02:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:25:49 --> CSRF cookie sent
INFO - 2026-02-16 02:25:49 --> CSRF cookie sent
INFO - 2026-02-16 02:25:49 --> Input Class Initialized
INFO - 2026-02-16 02:25:49 --> Input Class Initialized
INFO - 2026-02-16 02:25:49 --> Language Class Initialized
INFO - 2026-02-16 02:25:49 --> Language Class Initialized
INFO - 2026-02-16 02:25:49 --> Language Class Initialized
INFO - 2026-02-16 02:25:49 --> Language Class Initialized
INFO - 2026-02-16 02:25:49 --> Config Class Initialized
INFO - 2026-02-16 02:25:49 --> Config Class Initialized
INFO - 2026-02-16 02:25:49 --> Database Driver Class Initialized
INFO - 2026-02-16 02:25:49 --> Loader Class Initialized
INFO - 2026-02-16 02:25:49 --> Loader Class Initialized
INFO - 2026-02-16 02:25:49 --> Helper loaded: url_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: url_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: form_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: form_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: html_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: html_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: file_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: email_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: file_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: email_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:25:49 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:25:49 --> Database Driver Class Initialized
INFO - 2026-02-16 02:25:49 --> Database Driver Class Initialized
INFO - 2026-02-16 02:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:25:51 --> Upload Class Initialized
DEBUG - 2026-02-16 02:25:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:25:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:25:51 --> Encryption Class Initialized
INFO - 2026-02-16 02:25:51 --> Form Validation Class Initialized
INFO - 2026-02-16 02:25:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:25:51 --> Pagination Class Initialized
INFO - 2026-02-16 02:25:51 --> Email Class Initialized
INFO - 2026-02-16 02:25:51 --> Controller Class Initialized
ERROR - 2026-02-16 02:25:51 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:25:51 --> Upload Class Initialized
DEBUG - 2026-02-16 02:25:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:25:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:25:51 --> Encryption Class Initialized
INFO - 2026-02-16 02:25:51 --> Form Validation Class Initialized
INFO - 2026-02-16 02:25:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:25:51 --> Pagination Class Initialized
INFO - 2026-02-16 02:25:51 --> Config Class Initialized
INFO - 2026-02-16 02:25:51 --> Hooks Class Initialized
INFO - 2026-02-16 02:25:51 --> Email Class Initialized
INFO - 2026-02-16 02:25:51 --> Controller Class Initialized
ERROR - 2026-02-16 02:25:51 --> 404 Page Not Found: /index
DEBUG - 2026-02-16 02:25:51 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:25:51 --> Utf8 Class Initialized
INFO - 2026-02-16 02:25:51 --> URI Class Initialized
INFO - 2026-02-16 02:25:51 --> Router Class Initialized
INFO - 2026-02-16 02:25:51 --> Output Class Initialized
INFO - 2026-02-16 02:25:51 --> Security Class Initialized
DEBUG - 2026-02-16 02:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:25:51 --> CSRF cookie sent
INFO - 2026-02-16 02:25:51 --> Input Class Initialized
INFO - 2026-02-16 02:25:51 --> Language Class Initialized
INFO - 2026-02-16 02:25:51 --> Language Class Initialized
INFO - 2026-02-16 02:25:51 --> Config Class Initialized
INFO - 2026-02-16 02:25:51 --> Config Class Initialized
INFO - 2026-02-16 02:25:51 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:25:51 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:25:51 --> Utf8 Class Initialized
INFO - 2026-02-16 02:25:51 --> Loader Class Initialized
INFO - 2026-02-16 02:25:51 --> URI Class Initialized
INFO - 2026-02-16 02:25:51 --> Helper loaded: url_helper
INFO - 2026-02-16 02:25:51 --> Router Class Initialized
INFO - 2026-02-16 02:25:51 --> Helper loaded: form_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: html_helper
INFO - 2026-02-16 02:25:51 --> Output Class Initialized
INFO - 2026-02-16 02:25:51 --> Helper loaded: file_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: email_helper
INFO - 2026-02-16 02:25:51 --> Security Class Initialized
INFO - 2026-02-16 02:25:51 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: ssp_helper
DEBUG - 2026-02-16 02:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:25:51 --> Input Class Initialized
INFO - 2026-02-16 02:25:51 --> Language Class Initialized
INFO - 2026-02-16 02:25:51 --> Language Class Initialized
INFO - 2026-02-16 02:25:51 --> Config Class Initialized
INFO - 2026-02-16 02:25:51 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:25:51 --> Loader Class Initialized
INFO - 2026-02-16 02:25:51 --> Helper loaded: url_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: form_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: html_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: file_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: email_helper
INFO - 2026-02-16 02:25:51 --> Database Driver Class Initialized
INFO - 2026-02-16 02:25:51 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:25:51 --> Database Driver Class Initialized
INFO - 2026-02-16 02:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:25:51 --> Upload Class Initialized
DEBUG - 2026-02-16 02:25:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:25:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:25:51 --> Encryption Class Initialized
INFO - 2026-02-16 02:25:51 --> Form Validation Class Initialized
INFO - 2026-02-16 02:25:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:25:51 --> Pagination Class Initialized
INFO - 2026-02-16 02:25:51 --> Email Class Initialized
INFO - 2026-02-16 02:25:51 --> Controller Class Initialized
ERROR - 2026-02-16 02:25:51 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:25:51 --> Upload Class Initialized
DEBUG - 2026-02-16 02:25:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:25:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:25:51 --> Encryption Class Initialized
INFO - 2026-02-16 02:25:51 --> Form Validation Class Initialized
INFO - 2026-02-16 02:25:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:25:51 --> Pagination Class Initialized
INFO - 2026-02-16 02:25:51 --> Email Class Initialized
INFO - 2026-02-16 02:25:51 --> Controller Class Initialized
INFO - 2026-02-16 02:25:51 --> Config Class Initialized
INFO - 2026-02-16 02:25:51 --> Hooks Class Initialized
ERROR - 2026-02-16 02:25:51 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:25:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-02-16 02:25:51 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:25:51 --> Utf8 Class Initialized
INFO - 2026-02-16 02:25:51 --> URI Class Initialized
INFO - 2026-02-16 02:25:51 --> Upload Class Initialized
DEBUG - 2026-02-16 02:25:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:25:51 --> Router Class Initialized
INFO - 2026-02-16 02:25:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:25:51 --> Encryption Class Initialized
INFO - 2026-02-16 02:25:51 --> Output Class Initialized
INFO - 2026-02-16 02:25:51 --> Form Validation Class Initialized
INFO - 2026-02-16 02:25:51 --> Security Class Initialized
INFO - 2026-02-16 02:25:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:25:51 --> Pagination Class Initialized
DEBUG - 2026-02-16 02:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:25:51 --> Input Class Initialized
INFO - 2026-02-16 02:25:51 --> Language Class Initialized
INFO - 2026-02-16 02:25:51 --> Language Class Initialized
INFO - 2026-02-16 02:25:51 --> Config Class Initialized
INFO - 2026-02-16 02:25:51 --> Config Class Initialized
INFO - 2026-02-16 02:25:51 --> Hooks Class Initialized
INFO - 2026-02-16 02:25:51 --> Email Class Initialized
INFO - 2026-02-16 02:25:51 --> Controller Class Initialized
ERROR - 2026-02-16 02:25:51 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:25:51 --> Loader Class Initialized
DEBUG - 2026-02-16 02:25:51 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:25:51 --> Utf8 Class Initialized
INFO - 2026-02-16 02:25:51 --> Helper loaded: url_helper
INFO - 2026-02-16 02:25:51 --> URI Class Initialized
INFO - 2026-02-16 02:25:51 --> Helper loaded: form_helper
INFO - 2026-02-16 02:25:51 --> Upload Class Initialized
INFO - 2026-02-16 02:25:51 --> Helper loaded: html_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: file_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: email_helper
INFO - 2026-02-16 02:25:51 --> Router Class Initialized
DEBUG - 2026-02-16 02:25:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:25:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:25:51 --> Encryption Class Initialized
INFO - 2026-02-16 02:25:51 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:25:51 --> Output Class Initialized
INFO - 2026-02-16 02:25:51 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:25:51 --> Form Validation Class Initialized
INFO - 2026-02-16 02:25:51 --> Security Class Initialized
INFO - 2026-02-16 02:25:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:25:51 --> Pagination Class Initialized
DEBUG - 2026-02-16 02:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:25:51 --> Config Class Initialized
INFO - 2026-02-16 02:25:51 --> Input Class Initialized
INFO - 2026-02-16 02:25:51 --> Hooks Class Initialized
INFO - 2026-02-16 02:25:51 --> Language Class Initialized
DEBUG - 2026-02-16 02:25:51 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:25:51 --> Utf8 Class Initialized
INFO - 2026-02-16 02:25:51 --> Language Class Initialized
INFO - 2026-02-16 02:25:51 --> Config Class Initialized
INFO - 2026-02-16 02:25:51 --> URI Class Initialized
INFO - 2026-02-16 02:25:51 --> Database Driver Class Initialized
INFO - 2026-02-16 02:25:51 --> Router Class Initialized
INFO - 2026-02-16 02:25:51 --> Email Class Initialized
INFO - 2026-02-16 02:25:51 --> Controller Class Initialized
INFO - 2026-02-16 02:25:51 --> Output Class Initialized
ERROR - 2026-02-16 02:25:51 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:25:51 --> Loader Class Initialized
INFO - 2026-02-16 02:25:51 --> Security Class Initialized
INFO - 2026-02-16 02:25:51 --> Helper loaded: url_helper
DEBUG - 2026-02-16 02:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:25:51 --> CSRF cookie sent
INFO - 2026-02-16 02:25:51 --> Input Class Initialized
INFO - 2026-02-16 02:25:51 --> Language Class Initialized
INFO - 2026-02-16 02:25:51 --> Helper loaded: form_helper
INFO - 2026-02-16 02:25:51 --> Language Class Initialized
INFO - 2026-02-16 02:25:51 --> Config Class Initialized
INFO - 2026-02-16 02:25:51 --> Helper loaded: html_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: file_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: email_helper
INFO - 2026-02-16 02:25:51 --> Loader Class Initialized
INFO - 2026-02-16 02:25:51 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: url_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: form_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: html_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: file_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: email_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:25:51 --> Config Class Initialized
INFO - 2026-02-16 02:25:51 --> Hooks Class Initialized
INFO - 2026-02-16 02:25:51 --> Helper loaded: cpanel_helper
DEBUG - 2026-02-16 02:25:51 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:25:51 --> Utf8 Class Initialized
INFO - 2026-02-16 02:25:51 --> URI Class Initialized
INFO - 2026-02-16 02:25:51 --> Database Driver Class Initialized
INFO - 2026-02-16 02:25:51 --> Router Class Initialized
INFO - 2026-02-16 02:25:51 --> Database Driver Class Initialized
INFO - 2026-02-16 02:25:51 --> Output Class Initialized
INFO - 2026-02-16 02:25:51 --> Security Class Initialized
DEBUG - 2026-02-16 02:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:25:51 --> CSRF cookie sent
INFO - 2026-02-16 02:25:51 --> Input Class Initialized
INFO - 2026-02-16 02:25:51 --> Language Class Initialized
INFO - 2026-02-16 02:25:51 --> Language Class Initialized
INFO - 2026-02-16 02:25:51 --> Config Class Initialized
INFO - 2026-02-16 02:25:51 --> Loader Class Initialized
INFO - 2026-02-16 02:25:51 --> Helper loaded: url_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: form_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: html_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: file_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: email_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:25:51 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:25:51 --> Database Driver Class Initialized
INFO - 2026-02-16 02:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:25:53 --> Upload Class Initialized
DEBUG - 2026-02-16 02:25:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:25:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:25:53 --> Encryption Class Initialized
INFO - 2026-02-16 02:25:53 --> Form Validation Class Initialized
INFO - 2026-02-16 02:25:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:25:53 --> Pagination Class Initialized
INFO - 2026-02-16 02:25:53 --> Email Class Initialized
INFO - 2026-02-16 02:25:53 --> Controller Class Initialized
DEBUG - 2026-02-16 02:25:53 --> Clientarea MX_Controller Initialized
INFO - 2026-02-16 02:25:53 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:25:53 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:25:53 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:25:53 --> Model "Clientarea_model" initialized
INFO - 2026-02-16 02:25:53 --> Model "Billing_model" initialized
INFO - 2026-02-16 02:25:53 --> Model "Common_model" initialized
INFO - 2026-02-16 02:25:53 --> Model "Order_model" initialized
INFO - 2026-02-16 02:25:53 --> Model "Support_model" initialized
INFO - 2026-02-16 02:25:54 --> Final output sent to browser
DEBUG - 2026-02-16 02:25:54 --> Total execution time: 2.7968
INFO - 2026-02-16 02:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:25:54 --> Upload Class Initialized
DEBUG - 2026-02-16 02:25:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:25:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:25:54 --> Encryption Class Initialized
INFO - 2026-02-16 02:25:54 --> Form Validation Class Initialized
INFO - 2026-02-16 02:25:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:25:54 --> Pagination Class Initialized
INFO - 2026-02-16 02:25:54 --> Email Class Initialized
INFO - 2026-02-16 02:25:54 --> Controller Class Initialized
ERROR - 2026-02-16 02:25:54 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:25:54 --> Upload Class Initialized
DEBUG - 2026-02-16 02:25:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:25:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:25:54 --> Encryption Class Initialized
INFO - 2026-02-16 02:25:54 --> Form Validation Class Initialized
INFO - 2026-02-16 02:25:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:25:54 --> Pagination Class Initialized
INFO - 2026-02-16 02:25:54 --> Email Class Initialized
INFO - 2026-02-16 02:25:54 --> Controller Class Initialized
DEBUG - 2026-02-16 02:25:54 --> Tickets MX_Controller Initialized
INFO - 2026-02-16 02:25:54 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:25:54 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:25:54 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:25:54 --> Model "Support_model" initialized
INFO - 2026-02-16 02:25:54 --> Model "Common_model" initialized
INFO - 2026-02-16 02:25:54 --> Final output sent to browser
DEBUG - 2026-02-16 02:25:54 --> Total execution time: 3.5569
INFO - 2026-02-16 02:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:25:54 --> Upload Class Initialized
DEBUG - 2026-02-16 02:25:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:25:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:25:54 --> Encryption Class Initialized
INFO - 2026-02-16 02:25:54 --> Form Validation Class Initialized
INFO - 2026-02-16 02:25:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:25:54 --> Pagination Class Initialized
INFO - 2026-02-16 02:25:54 --> Email Class Initialized
INFO - 2026-02-16 02:25:54 --> Controller Class Initialized
DEBUG - 2026-02-16 02:25:54 --> Billing MX_Controller Initialized
INFO - 2026-02-16 02:25:54 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:25:54 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:25:54 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:25:54 --> Model "Billing_model" initialized
INFO - 2026-02-16 02:25:54 --> Model "Common_model" initialized
INFO - 2026-02-16 02:25:54 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 02:25:55 --> Final output sent to browser
DEBUG - 2026-02-16 02:25:55 --> Total execution time: 4.2631
INFO - 2026-02-16 02:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:25:55 --> Upload Class Initialized
DEBUG - 2026-02-16 02:25:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:25:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:25:55 --> Encryption Class Initialized
INFO - 2026-02-16 02:25:55 --> Form Validation Class Initialized
INFO - 2026-02-16 02:25:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:25:55 --> Pagination Class Initialized
INFO - 2026-02-16 02:25:55 --> Email Class Initialized
INFO - 2026-02-16 02:25:55 --> Controller Class Initialized
DEBUG - 2026-02-16 02:25:55 --> Cart MX_Controller Initialized
INFO - 2026-02-16 02:25:55 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:25:55 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:25:55 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:25:55 --> Model "Common_model" initialized
INFO - 2026-02-16 02:25:55 --> Model "Order_model" initialized
INFO - 2026-02-16 02:25:55 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 02:25:56 --> Final output sent to browser
DEBUG - 2026-02-16 02:25:56 --> Total execution time: 4.7184
INFO - 2026-02-16 02:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:25:56 --> Upload Class Initialized
DEBUG - 2026-02-16 02:25:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:25:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:25:56 --> Encryption Class Initialized
INFO - 2026-02-16 02:25:56 --> Form Validation Class Initialized
INFO - 2026-02-16 02:25:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:25:56 --> Pagination Class Initialized
INFO - 2026-02-16 02:25:56 --> Email Class Initialized
INFO - 2026-02-16 02:25:56 --> Controller Class Initialized
ERROR - 2026-02-16 02:25:56 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:26:00 --> Config Class Initialized
INFO - 2026-02-16 02:26:00 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:26:00 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:26:00 --> Utf8 Class Initialized
INFO - 2026-02-16 02:26:00 --> URI Class Initialized
INFO - 2026-02-16 02:26:00 --> Router Class Initialized
INFO - 2026-02-16 02:26:00 --> Output Class Initialized
INFO - 2026-02-16 02:26:00 --> Security Class Initialized
DEBUG - 2026-02-16 02:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:26:00 --> CSRF cookie sent
INFO - 2026-02-16 02:26:00 --> Input Class Initialized
INFO - 2026-02-16 02:26:00 --> Language Class Initialized
INFO - 2026-02-16 02:26:00 --> Language Class Initialized
INFO - 2026-02-16 02:26:00 --> Config Class Initialized
INFO - 2026-02-16 02:26:00 --> Loader Class Initialized
INFO - 2026-02-16 02:26:00 --> Helper loaded: url_helper
INFO - 2026-02-16 02:26:00 --> Helper loaded: form_helper
INFO - 2026-02-16 02:26:00 --> Helper loaded: html_helper
INFO - 2026-02-16 02:26:00 --> Helper loaded: file_helper
INFO - 2026-02-16 02:26:00 --> Helper loaded: email_helper
INFO - 2026-02-16 02:26:00 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:26:00 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:26:00 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:26:00 --> Database Driver Class Initialized
INFO - 2026-02-16 02:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:26:02 --> Upload Class Initialized
DEBUG - 2026-02-16 02:26:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:26:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:26:02 --> Encryption Class Initialized
INFO - 2026-02-16 02:26:02 --> Form Validation Class Initialized
INFO - 2026-02-16 02:26:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:26:02 --> Pagination Class Initialized
INFO - 2026-02-16 02:26:02 --> Email Class Initialized
INFO - 2026-02-16 02:26:02 --> Controller Class Initialized
DEBUG - 2026-02-16 02:26:02 --> Billing MX_Controller Initialized
INFO - 2026-02-16 02:26:02 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:26:02 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:26:02 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:26:02 --> Model "Billing_model" initialized
INFO - 2026-02-16 02:26:02 --> Model "Common_model" initialized
INFO - 2026-02-16 02:26:02 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-16 02:26:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-16 02:26:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-02-16 02:26:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-16 02:26:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-16 02:26:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_invoices.php
INFO - 2026-02-16 02:26:04 --> Final output sent to browser
DEBUG - 2026-02-16 02:26:04 --> Total execution time: 3.2852
INFO - 2026-02-16 02:26:04 --> Config Class Initialized
INFO - 2026-02-16 02:26:04 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:26:04 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:26:04 --> Utf8 Class Initialized
INFO - 2026-02-16 02:26:04 --> URI Class Initialized
INFO - 2026-02-16 02:26:04 --> Router Class Initialized
INFO - 2026-02-16 02:26:04 --> Output Class Initialized
INFO - 2026-02-16 02:26:04 --> Security Class Initialized
DEBUG - 2026-02-16 02:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:26:04 --> CSRF cookie sent
INFO - 2026-02-16 02:26:04 --> Input Class Initialized
INFO - 2026-02-16 02:26:04 --> Language Class Initialized
INFO - 2026-02-16 02:26:04 --> Language Class Initialized
INFO - 2026-02-16 02:26:04 --> Config Class Initialized
INFO - 2026-02-16 02:26:04 --> Loader Class Initialized
INFO - 2026-02-16 02:26:04 --> Helper loaded: url_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: form_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: html_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: file_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: email_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:26:04 --> Database Driver Class Initialized
INFO - 2026-02-16 02:26:04 --> Config Class Initialized
INFO - 2026-02-16 02:26:04 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:26:04 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:26:04 --> Utf8 Class Initialized
INFO - 2026-02-16 02:26:04 --> URI Class Initialized
INFO - 2026-02-16 02:26:04 --> Router Class Initialized
INFO - 2026-02-16 02:26:04 --> Output Class Initialized
INFO - 2026-02-16 02:26:04 --> Security Class Initialized
DEBUG - 2026-02-16 02:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:26:04 --> CSRF cookie sent
INFO - 2026-02-16 02:26:04 --> Input Class Initialized
INFO - 2026-02-16 02:26:04 --> Language Class Initialized
INFO - 2026-02-16 02:26:04 --> Language Class Initialized
INFO - 2026-02-16 02:26:04 --> Config Class Initialized
INFO - 2026-02-16 02:26:04 --> Loader Class Initialized
INFO - 2026-02-16 02:26:04 --> Helper loaded: url_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: form_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: html_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: file_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: email_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:26:04 --> Database Driver Class Initialized
INFO - 2026-02-16 02:26:04 --> Config Class Initialized
INFO - 2026-02-16 02:26:04 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:26:04 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:26:04 --> Utf8 Class Initialized
INFO - 2026-02-16 02:26:04 --> URI Class Initialized
INFO - 2026-02-16 02:26:04 --> Router Class Initialized
INFO - 2026-02-16 02:26:04 --> Output Class Initialized
INFO - 2026-02-16 02:26:04 --> Security Class Initialized
DEBUG - 2026-02-16 02:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:26:04 --> CSRF cookie sent
INFO - 2026-02-16 02:26:04 --> Input Class Initialized
INFO - 2026-02-16 02:26:04 --> Language Class Initialized
INFO - 2026-02-16 02:26:04 --> Language Class Initialized
INFO - 2026-02-16 02:26:04 --> Config Class Initialized
INFO - 2026-02-16 02:26:04 --> Loader Class Initialized
INFO - 2026-02-16 02:26:04 --> Helper loaded: url_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: form_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: html_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: file_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: email_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:26:04 --> Config Class Initialized
INFO - 2026-02-16 02:26:04 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:26:04 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:26:04 --> Utf8 Class Initialized
INFO - 2026-02-16 02:26:04 --> URI Class Initialized
INFO - 2026-02-16 02:26:04 --> Database Driver Class Initialized
INFO - 2026-02-16 02:26:04 --> Router Class Initialized
INFO - 2026-02-16 02:26:04 --> Output Class Initialized
INFO - 2026-02-16 02:26:04 --> Security Class Initialized
DEBUG - 2026-02-16 02:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:26:04 --> CSRF cookie sent
INFO - 2026-02-16 02:26:04 --> Input Class Initialized
INFO - 2026-02-16 02:26:04 --> Language Class Initialized
INFO - 2026-02-16 02:26:04 --> Language Class Initialized
INFO - 2026-02-16 02:26:04 --> Config Class Initialized
INFO - 2026-02-16 02:26:04 --> Loader Class Initialized
INFO - 2026-02-16 02:26:04 --> Helper loaded: url_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: form_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: html_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: file_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: email_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:26:04 --> Database Driver Class Initialized
INFO - 2026-02-16 02:26:04 --> Config Class Initialized
INFO - 2026-02-16 02:26:04 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:26:04 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:26:04 --> Utf8 Class Initialized
INFO - 2026-02-16 02:26:04 --> URI Class Initialized
INFO - 2026-02-16 02:26:04 --> Config Class Initialized
INFO - 2026-02-16 02:26:04 --> Router Class Initialized
INFO - 2026-02-16 02:26:04 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:26:04 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:26:04 --> Utf8 Class Initialized
INFO - 2026-02-16 02:26:04 --> Output Class Initialized
INFO - 2026-02-16 02:26:04 --> URI Class Initialized
INFO - 2026-02-16 02:26:04 --> Security Class Initialized
INFO - 2026-02-16 02:26:04 --> Router Class Initialized
DEBUG - 2026-02-16 02:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:26:04 --> CSRF cookie sent
INFO - 2026-02-16 02:26:04 --> Input Class Initialized
INFO - 2026-02-16 02:26:04 --> Language Class Initialized
INFO - 2026-02-16 02:26:04 --> Output Class Initialized
INFO - 2026-02-16 02:26:04 --> Language Class Initialized
INFO - 2026-02-16 02:26:04 --> Config Class Initialized
INFO - 2026-02-16 02:26:04 --> Security Class Initialized
DEBUG - 2026-02-16 02:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:26:04 --> CSRF cookie sent
INFO - 2026-02-16 02:26:04 --> Input Class Initialized
INFO - 2026-02-16 02:26:04 --> Language Class Initialized
INFO - 2026-02-16 02:26:04 --> Loader Class Initialized
INFO - 2026-02-16 02:26:04 --> Language Class Initialized
INFO - 2026-02-16 02:26:04 --> Config Class Initialized
INFO - 2026-02-16 02:26:04 --> Helper loaded: url_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: form_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: html_helper
INFO - 2026-02-16 02:26:04 --> Loader Class Initialized
INFO - 2026-02-16 02:26:04 --> Helper loaded: file_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: email_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: url_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: form_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: html_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: file_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: email_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:26:04 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:26:04 --> Database Driver Class Initialized
INFO - 2026-02-16 02:26:04 --> Database Driver Class Initialized
INFO - 2026-02-16 02:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:26:06 --> Upload Class Initialized
DEBUG - 2026-02-16 02:26:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:26:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:26:06 --> Encryption Class Initialized
INFO - 2026-02-16 02:26:06 --> Form Validation Class Initialized
INFO - 2026-02-16 02:26:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:26:06 --> Pagination Class Initialized
INFO - 2026-02-16 02:26:06 --> Email Class Initialized
INFO - 2026-02-16 02:26:06 --> Controller Class Initialized
ERROR - 2026-02-16 02:26:06 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:26:06 --> Config Class Initialized
INFO - 2026-02-16 02:26:06 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:26:06 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:26:06 --> Utf8 Class Initialized
INFO - 2026-02-16 02:26:06 --> URI Class Initialized
INFO - 2026-02-16 02:26:06 --> Router Class Initialized
INFO - 2026-02-16 02:26:06 --> Output Class Initialized
INFO - 2026-02-16 02:26:06 --> Security Class Initialized
DEBUG - 2026-02-16 02:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:26:06 --> CSRF cookie sent
INFO - 2026-02-16 02:26:06 --> Input Class Initialized
INFO - 2026-02-16 02:26:06 --> Language Class Initialized
INFO - 2026-02-16 02:26:06 --> Language Class Initialized
INFO - 2026-02-16 02:26:06 --> Config Class Initialized
INFO - 2026-02-16 02:26:06 --> Loader Class Initialized
INFO - 2026-02-16 02:26:06 --> Helper loaded: url_helper
INFO - 2026-02-16 02:26:06 --> Helper loaded: form_helper
INFO - 2026-02-16 02:26:06 --> Helper loaded: html_helper
INFO - 2026-02-16 02:26:06 --> Helper loaded: file_helper
INFO - 2026-02-16 02:26:06 --> Helper loaded: email_helper
INFO - 2026-02-16 02:26:06 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:26:06 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:26:06 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:26:06 --> Database Driver Class Initialized
INFO - 2026-02-16 02:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:26:06 --> Upload Class Initialized
DEBUG - 2026-02-16 02:26:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:26:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:26:06 --> Encryption Class Initialized
INFO - 2026-02-16 02:26:06 --> Form Validation Class Initialized
INFO - 2026-02-16 02:26:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:26:06 --> Pagination Class Initialized
INFO - 2026-02-16 02:26:06 --> Email Class Initialized
INFO - 2026-02-16 02:26:06 --> Controller Class Initialized
ERROR - 2026-02-16 02:26:06 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:26:06 --> Upload Class Initialized
DEBUG - 2026-02-16 02:26:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:26:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:26:06 --> Encryption Class Initialized
INFO - 2026-02-16 02:26:06 --> Form Validation Class Initialized
INFO - 2026-02-16 02:26:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:26:06 --> Pagination Class Initialized
INFO - 2026-02-16 02:26:06 --> Config Class Initialized
INFO - 2026-02-16 02:26:06 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:26:06 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:26:06 --> Utf8 Class Initialized
INFO - 2026-02-16 02:26:06 --> Email Class Initialized
INFO - 2026-02-16 02:26:06 --> Controller Class Initialized
INFO - 2026-02-16 02:26:06 --> URI Class Initialized
ERROR - 2026-02-16 02:26:06 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:26:06 --> Router Class Initialized
INFO - 2026-02-16 02:26:06 --> Upload Class Initialized
INFO - 2026-02-16 02:26:06 --> Output Class Initialized
INFO - 2026-02-16 02:26:06 --> Security Class Initialized
DEBUG - 2026-02-16 02:26:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:26:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:26:06 --> Encryption Class Initialized
DEBUG - 2026-02-16 02:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:26:06 --> CSRF cookie sent
INFO - 2026-02-16 02:26:06 --> Input Class Initialized
INFO - 2026-02-16 02:26:06 --> Language Class Initialized
INFO - 2026-02-16 02:26:06 --> Form Validation Class Initialized
INFO - 2026-02-16 02:26:06 --> Language Class Initialized
INFO - 2026-02-16 02:26:06 --> Config Class Initialized
INFO - 2026-02-16 02:26:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:26:06 --> Pagination Class Initialized
INFO - 2026-02-16 02:26:06 --> Loader Class Initialized
INFO - 2026-02-16 02:26:06 --> Config Class Initialized
INFO - 2026-02-16 02:26:06 --> Hooks Class Initialized
INFO - 2026-02-16 02:26:06 --> Helper loaded: url_helper
INFO - 2026-02-16 02:26:06 --> Email Class Initialized
DEBUG - 2026-02-16 02:26:06 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:26:06 --> Utf8 Class Initialized
INFO - 2026-02-16 02:26:06 --> Controller Class Initialized
INFO - 2026-02-16 02:26:06 --> Helper loaded: form_helper
ERROR - 2026-02-16 02:26:06 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:26:06 --> URI Class Initialized
INFO - 2026-02-16 02:26:06 --> Helper loaded: html_helper
INFO - 2026-02-16 02:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:26:06 --> Helper loaded: file_helper
INFO - 2026-02-16 02:26:06 --> Helper loaded: email_helper
INFO - 2026-02-16 02:26:06 --> Router Class Initialized
INFO - 2026-02-16 02:26:06 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:26:06 --> Upload Class Initialized
INFO - 2026-02-16 02:26:06 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:26:06 --> Output Class Initialized
INFO - 2026-02-16 02:26:06 --> Helper loaded: cpanel_helper
DEBUG - 2026-02-16 02:26:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:26:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:26:06 --> Encryption Class Initialized
INFO - 2026-02-16 02:26:06 --> Security Class Initialized
DEBUG - 2026-02-16 02:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:26:06 --> CSRF cookie sent
INFO - 2026-02-16 02:26:06 --> Input Class Initialized
INFO - 2026-02-16 02:26:06 --> Language Class Initialized
INFO - 2026-02-16 02:26:06 --> Form Validation Class Initialized
INFO - 2026-02-16 02:26:06 --> Language Class Initialized
INFO - 2026-02-16 02:26:06 --> Config Class Initialized
INFO - 2026-02-16 02:26:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:26:06 --> Pagination Class Initialized
INFO - 2026-02-16 02:26:06 --> Loader Class Initialized
INFO - 2026-02-16 02:26:06 --> Database Driver Class Initialized
INFO - 2026-02-16 02:26:06 --> Helper loaded: url_helper
INFO - 2026-02-16 02:26:06 --> Email Class Initialized
INFO - 2026-02-16 02:26:06 --> Controller Class Initialized
INFO - 2026-02-16 02:26:06 --> Helper loaded: form_helper
INFO - 2026-02-16 02:26:06 --> Helper loaded: html_helper
DEBUG - 2026-02-16 02:26:06 --> Cart MX_Controller Initialized
INFO - 2026-02-16 02:26:06 --> Helper loaded: file_helper
INFO - 2026-02-16 02:26:06 --> Helper loaded: email_helper
INFO - 2026-02-16 02:26:06 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:26:06 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:26:06 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:26:06 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:26:06 --> Model "Common_model" initialized
INFO - 2026-02-16 02:26:06 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:26:06 --> Model "Order_model" initialized
INFO - 2026-02-16 02:26:06 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 02:26:06 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:26:06 --> Database Driver Class Initialized
INFO - 2026-02-16 02:26:06 --> Final output sent to browser
DEBUG - 2026-02-16 02:26:06 --> Total execution time: 2.3475
INFO - 2026-02-16 02:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:26:06 --> Upload Class Initialized
DEBUG - 2026-02-16 02:26:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:26:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:26:06 --> Encryption Class Initialized
INFO - 2026-02-16 02:26:06 --> Form Validation Class Initialized
INFO - 2026-02-16 02:26:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:26:06 --> Pagination Class Initialized
INFO - 2026-02-16 02:26:06 --> Email Class Initialized
INFO - 2026-02-16 02:26:06 --> Controller Class Initialized
ERROR - 2026-02-16 02:26:06 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:26:08 --> Upload Class Initialized
DEBUG - 2026-02-16 02:26:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:26:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:26:08 --> Encryption Class Initialized
INFO - 2026-02-16 02:26:08 --> Form Validation Class Initialized
INFO - 2026-02-16 02:26:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:26:08 --> Pagination Class Initialized
INFO - 2026-02-16 02:26:08 --> Email Class Initialized
INFO - 2026-02-16 02:26:08 --> Controller Class Initialized
ERROR - 2026-02-16 02:26:08 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:26:08 --> Upload Class Initialized
DEBUG - 2026-02-16 02:26:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:26:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:26:08 --> Encryption Class Initialized
INFO - 2026-02-16 02:26:08 --> Form Validation Class Initialized
INFO - 2026-02-16 02:26:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:26:08 --> Pagination Class Initialized
INFO - 2026-02-16 02:26:08 --> Email Class Initialized
INFO - 2026-02-16 02:26:08 --> Controller Class Initialized
ERROR - 2026-02-16 02:26:08 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:26:08 --> Upload Class Initialized
DEBUG - 2026-02-16 02:26:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:26:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:26:08 --> Encryption Class Initialized
INFO - 2026-02-16 02:26:08 --> Form Validation Class Initialized
INFO - 2026-02-16 02:26:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:26:08 --> Pagination Class Initialized
INFO - 2026-02-16 02:26:08 --> Email Class Initialized
INFO - 2026-02-16 02:26:08 --> Controller Class Initialized
ERROR - 2026-02-16 02:26:08 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:36:22 --> Config Class Initialized
INFO - 2026-02-16 02:36:22 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:36:22 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:36:22 --> Utf8 Class Initialized
INFO - 2026-02-16 02:36:22 --> URI Class Initialized
INFO - 2026-02-16 02:36:22 --> Router Class Initialized
INFO - 2026-02-16 02:36:22 --> Output Class Initialized
INFO - 2026-02-16 02:36:22 --> Security Class Initialized
DEBUG - 2026-02-16 02:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:36:22 --> CSRF cookie sent
INFO - 2026-02-16 02:36:22 --> Input Class Initialized
INFO - 2026-02-16 02:36:22 --> Language Class Initialized
INFO - 2026-02-16 02:36:22 --> Language Class Initialized
INFO - 2026-02-16 02:36:22 --> Config Class Initialized
INFO - 2026-02-16 02:36:22 --> Loader Class Initialized
INFO - 2026-02-16 02:36:22 --> Helper loaded: url_helper
INFO - 2026-02-16 02:36:22 --> Helper loaded: form_helper
INFO - 2026-02-16 02:36:22 --> Helper loaded: html_helper
INFO - 2026-02-16 02:36:22 --> Helper loaded: file_helper
INFO - 2026-02-16 02:36:22 --> Helper loaded: email_helper
INFO - 2026-02-16 02:36:22 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:36:22 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:36:22 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:36:22 --> Database Driver Class Initialized
INFO - 2026-02-16 02:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:36:24 --> Upload Class Initialized
DEBUG - 2026-02-16 02:36:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:36:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:36:24 --> Encryption Class Initialized
INFO - 2026-02-16 02:36:24 --> Form Validation Class Initialized
INFO - 2026-02-16 02:36:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:36:24 --> Pagination Class Initialized
INFO - 2026-02-16 02:36:24 --> Email Class Initialized
INFO - 2026-02-16 02:36:24 --> Controller Class Initialized
DEBUG - 2026-02-16 02:36:24 --> Billing MX_Controller Initialized
INFO - 2026-02-16 02:36:24 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:36:24 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:36:24 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:36:24 --> Model "Billing_model" initialized
INFO - 2026-02-16 02:36:24 --> Model "Common_model" initialized
INFO - 2026-02-16 02:36:24 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-16 02:36:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-16 02:36:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-02-16 02:36:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-16 02:36:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-16 02:36:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_invoices.php
INFO - 2026-02-16 02:36:25 --> Final output sent to browser
DEBUG - 2026-02-16 02:36:25 --> Total execution time: 3.1504
INFO - 2026-02-16 02:36:25 --> Config Class Initialized
INFO - 2026-02-16 02:36:25 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:36:25 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:36:25 --> Utf8 Class Initialized
INFO - 2026-02-16 02:36:25 --> URI Class Initialized
INFO - 2026-02-16 02:36:25 --> Router Class Initialized
INFO - 2026-02-16 02:36:25 --> Output Class Initialized
INFO - 2026-02-16 02:36:25 --> Security Class Initialized
DEBUG - 2026-02-16 02:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:36:25 --> CSRF cookie sent
INFO - 2026-02-16 02:36:25 --> Input Class Initialized
INFO - 2026-02-16 02:36:25 --> Language Class Initialized
INFO - 2026-02-16 02:36:25 --> Language Class Initialized
INFO - 2026-02-16 02:36:25 --> Config Class Initialized
INFO - 2026-02-16 02:36:25 --> Loader Class Initialized
INFO - 2026-02-16 02:36:25 --> Helper loaded: url_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: form_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: html_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: file_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: email_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:36:25 --> Database Driver Class Initialized
INFO - 2026-02-16 02:36:25 --> Config Class Initialized
INFO - 2026-02-16 02:36:25 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:36:25 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:36:25 --> Utf8 Class Initialized
INFO - 2026-02-16 02:36:25 --> URI Class Initialized
INFO - 2026-02-16 02:36:25 --> Router Class Initialized
INFO - 2026-02-16 02:36:25 --> Output Class Initialized
INFO - 2026-02-16 02:36:25 --> Security Class Initialized
DEBUG - 2026-02-16 02:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:36:25 --> CSRF cookie sent
INFO - 2026-02-16 02:36:25 --> Input Class Initialized
INFO - 2026-02-16 02:36:25 --> Language Class Initialized
INFO - 2026-02-16 02:36:25 --> Language Class Initialized
INFO - 2026-02-16 02:36:25 --> Config Class Initialized
INFO - 2026-02-16 02:36:25 --> Loader Class Initialized
INFO - 2026-02-16 02:36:25 --> Helper loaded: url_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: form_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: html_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: file_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: email_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:36:25 --> Database Driver Class Initialized
INFO - 2026-02-16 02:36:25 --> Config Class Initialized
INFO - 2026-02-16 02:36:25 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:36:25 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:36:25 --> Utf8 Class Initialized
INFO - 2026-02-16 02:36:25 --> URI Class Initialized
INFO - 2026-02-16 02:36:25 --> Router Class Initialized
INFO - 2026-02-16 02:36:25 --> Config Class Initialized
INFO - 2026-02-16 02:36:25 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:36:25 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:36:25 --> Utf8 Class Initialized
INFO - 2026-02-16 02:36:25 --> Output Class Initialized
INFO - 2026-02-16 02:36:25 --> Config Class Initialized
INFO - 2026-02-16 02:36:25 --> Hooks Class Initialized
INFO - 2026-02-16 02:36:25 --> URI Class Initialized
INFO - 2026-02-16 02:36:25 --> Config Class Initialized
INFO - 2026-02-16 02:36:25 --> Security Class Initialized
INFO - 2026-02-16 02:36:25 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:36:25 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:36:25 --> Utf8 Class Initialized
INFO - 2026-02-16 02:36:25 --> URI Class Initialized
DEBUG - 2026-02-16 02:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:36:25 --> CSRF cookie sent
INFO - 2026-02-16 02:36:25 --> Input Class Initialized
INFO - 2026-02-16 02:36:25 --> Router Class Initialized
INFO - 2026-02-16 02:36:25 --> Language Class Initialized
DEBUG - 2026-02-16 02:36:25 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:36:25 --> Utf8 Class Initialized
INFO - 2026-02-16 02:36:25 --> Output Class Initialized
INFO - 2026-02-16 02:36:25 --> URI Class Initialized
INFO - 2026-02-16 02:36:25 --> Router Class Initialized
INFO - 2026-02-16 02:36:25 --> Security Class Initialized
INFO - 2026-02-16 02:36:25 --> Output Class Initialized
INFO - 2026-02-16 02:36:25 --> Language Class Initialized
INFO - 2026-02-16 02:36:25 --> Config Class Initialized
DEBUG - 2026-02-16 02:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:36:25 --> CSRF cookie sent
INFO - 2026-02-16 02:36:25 --> Router Class Initialized
INFO - 2026-02-16 02:36:25 --> Input Class Initialized
INFO - 2026-02-16 02:36:25 --> Language Class Initialized
INFO - 2026-02-16 02:36:25 --> Security Class Initialized
INFO - 2026-02-16 02:36:25 --> Language Class Initialized
INFO - 2026-02-16 02:36:25 --> Config Class Initialized
DEBUG - 2026-02-16 02:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:36:25 --> CSRF cookie sent
INFO - 2026-02-16 02:36:25 --> Input Class Initialized
INFO - 2026-02-16 02:36:25 --> Output Class Initialized
INFO - 2026-02-16 02:36:25 --> Language Class Initialized
INFO - 2026-02-16 02:36:25 --> Loader Class Initialized
INFO - 2026-02-16 02:36:25 --> Language Class Initialized
INFO - 2026-02-16 02:36:25 --> Config Class Initialized
INFO - 2026-02-16 02:36:25 --> Security Class Initialized
INFO - 2026-02-16 02:36:25 --> Helper loaded: url_helper
INFO - 2026-02-16 02:36:25 --> Loader Class Initialized
DEBUG - 2026-02-16 02:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:36:25 --> CSRF cookie sent
INFO - 2026-02-16 02:36:25 --> Input Class Initialized
INFO - 2026-02-16 02:36:25 --> Helper loaded: url_helper
INFO - 2026-02-16 02:36:25 --> Language Class Initialized
INFO - 2026-02-16 02:36:25 --> Helper loaded: form_helper
INFO - 2026-02-16 02:36:25 --> Loader Class Initialized
INFO - 2026-02-16 02:36:25 --> Helper loaded: html_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: form_helper
INFO - 2026-02-16 02:36:25 --> Language Class Initialized
INFO - 2026-02-16 02:36:25 --> Config Class Initialized
INFO - 2026-02-16 02:36:25 --> Helper loaded: html_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: file_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: email_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: file_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: email_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: url_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: form_helper
INFO - 2026-02-16 02:36:25 --> Loader Class Initialized
INFO - 2026-02-16 02:36:25 --> Helper loaded: html_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: file_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: email_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: url_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: form_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: html_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: file_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: email_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:36:25 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:36:25 --> Database Driver Class Initialized
INFO - 2026-02-16 02:36:25 --> Database Driver Class Initialized
INFO - 2026-02-16 02:36:25 --> Database Driver Class Initialized
INFO - 2026-02-16 02:36:25 --> Database Driver Class Initialized
INFO - 2026-02-16 02:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:36:27 --> Upload Class Initialized
DEBUG - 2026-02-16 02:36:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:36:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:36:27 --> Encryption Class Initialized
INFO - 2026-02-16 02:36:27 --> Form Validation Class Initialized
INFO - 2026-02-16 02:36:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:36:27 --> Pagination Class Initialized
INFO - 2026-02-16 02:36:27 --> Email Class Initialized
INFO - 2026-02-16 02:36:27 --> Controller Class Initialized
ERROR - 2026-02-16 02:36:27 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:36:27 --> Config Class Initialized
INFO - 2026-02-16 02:36:27 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:36:27 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:36:27 --> Utf8 Class Initialized
INFO - 2026-02-16 02:36:27 --> URI Class Initialized
INFO - 2026-02-16 02:36:27 --> Router Class Initialized
INFO - 2026-02-16 02:36:27 --> Output Class Initialized
INFO - 2026-02-16 02:36:27 --> Security Class Initialized
DEBUG - 2026-02-16 02:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:36:27 --> CSRF cookie sent
INFO - 2026-02-16 02:36:27 --> Input Class Initialized
INFO - 2026-02-16 02:36:27 --> Language Class Initialized
INFO - 2026-02-16 02:36:27 --> Language Class Initialized
INFO - 2026-02-16 02:36:27 --> Config Class Initialized
INFO - 2026-02-16 02:36:27 --> Loader Class Initialized
INFO - 2026-02-16 02:36:27 --> Helper loaded: url_helper
INFO - 2026-02-16 02:36:27 --> Helper loaded: form_helper
INFO - 2026-02-16 02:36:27 --> Helper loaded: html_helper
INFO - 2026-02-16 02:36:27 --> Helper loaded: file_helper
INFO - 2026-02-16 02:36:27 --> Helper loaded: email_helper
INFO - 2026-02-16 02:36:27 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:36:27 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:36:27 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:36:27 --> Database Driver Class Initialized
INFO - 2026-02-16 02:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:36:27 --> Upload Class Initialized
DEBUG - 2026-02-16 02:36:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:36:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:36:27 --> Encryption Class Initialized
INFO - 2026-02-16 02:36:27 --> Form Validation Class Initialized
INFO - 2026-02-16 02:36:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:36:27 --> Pagination Class Initialized
INFO - 2026-02-16 02:36:27 --> Email Class Initialized
INFO - 2026-02-16 02:36:27 --> Controller Class Initialized
ERROR - 2026-02-16 02:36:27 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:36:27 --> Upload Class Initialized
DEBUG - 2026-02-16 02:36:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:36:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:36:27 --> Encryption Class Initialized
INFO - 2026-02-16 02:36:27 --> Form Validation Class Initialized
INFO - 2026-02-16 02:36:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:36:27 --> Pagination Class Initialized
INFO - 2026-02-16 02:36:27 --> Config Class Initialized
INFO - 2026-02-16 02:36:27 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:36:27 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:36:27 --> Utf8 Class Initialized
INFO - 2026-02-16 02:36:27 --> Email Class Initialized
INFO - 2026-02-16 02:36:27 --> Controller Class Initialized
ERROR - 2026-02-16 02:36:27 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:36:27 --> URI Class Initialized
INFO - 2026-02-16 02:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:36:27 --> Router Class Initialized
INFO - 2026-02-16 02:36:27 --> Upload Class Initialized
INFO - 2026-02-16 02:36:27 --> Output Class Initialized
INFO - 2026-02-16 02:36:27 --> Security Class Initialized
DEBUG - 2026-02-16 02:36:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:36:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:36:27 --> Encryption Class Initialized
DEBUG - 2026-02-16 02:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:36:27 --> CSRF cookie sent
INFO - 2026-02-16 02:36:27 --> Input Class Initialized
INFO - 2026-02-16 02:36:27 --> Language Class Initialized
INFO - 2026-02-16 02:36:27 --> Form Validation Class Initialized
INFO - 2026-02-16 02:36:27 --> Language Class Initialized
INFO - 2026-02-16 02:36:27 --> Config Class Initialized
INFO - 2026-02-16 02:36:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:36:27 --> Pagination Class Initialized
INFO - 2026-02-16 02:36:27 --> Loader Class Initialized
INFO - 2026-02-16 02:36:27 --> Config Class Initialized
INFO - 2026-02-16 02:36:27 --> Hooks Class Initialized
INFO - 2026-02-16 02:36:27 --> Email Class Initialized
INFO - 2026-02-16 02:36:27 --> Controller Class Initialized
INFO - 2026-02-16 02:36:27 --> Helper loaded: url_helper
ERROR - 2026-02-16 02:36:27 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:36:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-02-16 02:36:27 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:36:27 --> Utf8 Class Initialized
INFO - 2026-02-16 02:36:27 --> Helper loaded: form_helper
INFO - 2026-02-16 02:36:27 --> URI Class Initialized
INFO - 2026-02-16 02:36:27 --> Helper loaded: html_helper
INFO - 2026-02-16 02:36:27 --> Upload Class Initialized
INFO - 2026-02-16 02:36:27 --> Helper loaded: file_helper
INFO - 2026-02-16 02:36:27 --> Helper loaded: email_helper
DEBUG - 2026-02-16 02:36:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:36:27 --> Router Class Initialized
INFO - 2026-02-16 02:36:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:36:27 --> Encryption Class Initialized
INFO - 2026-02-16 02:36:27 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:36:27 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:36:27 --> Output Class Initialized
INFO - 2026-02-16 02:36:27 --> Form Validation Class Initialized
INFO - 2026-02-16 02:36:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:36:27 --> Pagination Class Initialized
INFO - 2026-02-16 02:36:27 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:36:27 --> Security Class Initialized
DEBUG - 2026-02-16 02:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:36:27 --> CSRF cookie sent
INFO - 2026-02-16 02:36:27 --> Input Class Initialized
INFO - 2026-02-16 02:36:27 --> Language Class Initialized
INFO - 2026-02-16 02:36:27 --> Email Class Initialized
INFO - 2026-02-16 02:36:27 --> Controller Class Initialized
INFO - 2026-02-16 02:36:27 --> Language Class Initialized
INFO - 2026-02-16 02:36:27 --> Config Class Initialized
ERROR - 2026-02-16 02:36:27 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:36:27 --> Upload Class Initialized
INFO - 2026-02-16 02:36:27 --> Loader Class Initialized
DEBUG - 2026-02-16 02:36:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:36:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:36:27 --> Encryption Class Initialized
INFO - 2026-02-16 02:36:27 --> Helper loaded: url_helper
INFO - 2026-02-16 02:36:27 --> Database Driver Class Initialized
INFO - 2026-02-16 02:36:27 --> Helper loaded: form_helper
INFO - 2026-02-16 02:36:27 --> Form Validation Class Initialized
INFO - 2026-02-16 02:36:27 --> Helper loaded: html_helper
INFO - 2026-02-16 02:36:27 --> Helper loaded: file_helper
INFO - 2026-02-16 02:36:27 --> Helper loaded: email_helper
INFO - 2026-02-16 02:36:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:36:27 --> Pagination Class Initialized
INFO - 2026-02-16 02:36:27 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:36:27 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:36:27 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:36:27 --> Email Class Initialized
INFO - 2026-02-16 02:36:27 --> Controller Class Initialized
ERROR - 2026-02-16 02:36:27 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:36:27 --> Database Driver Class Initialized
INFO - 2026-02-16 02:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:36:29 --> Upload Class Initialized
DEBUG - 2026-02-16 02:36:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:36:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:36:29 --> Encryption Class Initialized
INFO - 2026-02-16 02:36:29 --> Form Validation Class Initialized
INFO - 2026-02-16 02:36:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:36:29 --> Pagination Class Initialized
INFO - 2026-02-16 02:36:29 --> Email Class Initialized
INFO - 2026-02-16 02:36:29 --> Controller Class Initialized
DEBUG - 2026-02-16 02:36:29 --> Cart MX_Controller Initialized
INFO - 2026-02-16 02:36:29 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:36:29 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:36:29 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:36:29 --> Model "Common_model" initialized
INFO - 2026-02-16 02:36:29 --> Model "Order_model" initialized
INFO - 2026-02-16 02:36:29 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 02:36:29 --> Final output sent to browser
DEBUG - 2026-02-16 02:36:29 --> Total execution time: 2.4494
INFO - 2026-02-16 02:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:36:29 --> Upload Class Initialized
DEBUG - 2026-02-16 02:36:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:36:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:36:29 --> Encryption Class Initialized
INFO - 2026-02-16 02:36:29 --> Form Validation Class Initialized
INFO - 2026-02-16 02:36:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:36:29 --> Pagination Class Initialized
INFO - 2026-02-16 02:36:29 --> Email Class Initialized
INFO - 2026-02-16 02:36:29 --> Controller Class Initialized
ERROR - 2026-02-16 02:36:29 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:36:29 --> Upload Class Initialized
DEBUG - 2026-02-16 02:36:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:36:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:36:29 --> Encryption Class Initialized
INFO - 2026-02-16 02:36:29 --> Form Validation Class Initialized
INFO - 2026-02-16 02:36:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:36:29 --> Pagination Class Initialized
INFO - 2026-02-16 02:36:29 --> Email Class Initialized
INFO - 2026-02-16 02:36:29 --> Controller Class Initialized
ERROR - 2026-02-16 02:36:29 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:38:16 --> Config Class Initialized
INFO - 2026-02-16 02:38:16 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:38:16 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:38:16 --> Utf8 Class Initialized
INFO - 2026-02-16 02:38:16 --> URI Class Initialized
INFO - 2026-02-16 02:38:16 --> Router Class Initialized
INFO - 2026-02-16 02:38:16 --> Output Class Initialized
INFO - 2026-02-16 02:38:16 --> Security Class Initialized
DEBUG - 2026-02-16 02:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:38:16 --> CSRF cookie sent
INFO - 2026-02-16 02:38:16 --> Input Class Initialized
INFO - 2026-02-16 02:38:16 --> Language Class Initialized
INFO - 2026-02-16 02:38:16 --> Language Class Initialized
INFO - 2026-02-16 02:38:16 --> Config Class Initialized
INFO - 2026-02-16 02:38:16 --> Loader Class Initialized
INFO - 2026-02-16 02:38:16 --> Helper loaded: url_helper
INFO - 2026-02-16 02:38:16 --> Helper loaded: form_helper
INFO - 2026-02-16 02:38:16 --> Helper loaded: html_helper
INFO - 2026-02-16 02:38:16 --> Helper loaded: file_helper
INFO - 2026-02-16 02:38:16 --> Helper loaded: email_helper
INFO - 2026-02-16 02:38:16 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:38:16 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:38:16 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:38:16 --> Database Driver Class Initialized
INFO - 2026-02-16 02:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:38:18 --> Upload Class Initialized
DEBUG - 2026-02-16 02:38:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:38:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:38:18 --> Encryption Class Initialized
INFO - 2026-02-16 02:38:18 --> Form Validation Class Initialized
INFO - 2026-02-16 02:38:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:38:18 --> Pagination Class Initialized
INFO - 2026-02-16 02:38:18 --> Email Class Initialized
INFO - 2026-02-16 02:38:18 --> Controller Class Initialized
DEBUG - 2026-02-16 02:38:18 --> Billing MX_Controller Initialized
INFO - 2026-02-16 02:38:18 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:38:18 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:38:18 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:38:18 --> Model "Billing_model" initialized
INFO - 2026-02-16 02:38:18 --> Model "Common_model" initialized
INFO - 2026-02-16 02:38:18 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-16 02:38:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_invoice_pdf_html.php
DEBUG - 2026-02-16 02:38:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-16 02:38:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-02-16 02:38:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-16 02:38:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-16 02:38:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_viewinvoice.php
INFO - 2026-02-16 02:38:20 --> Final output sent to browser
DEBUG - 2026-02-16 02:38:20 --> Total execution time: 3.9859
INFO - 2026-02-16 02:38:20 --> Config Class Initialized
INFO - 2026-02-16 02:38:20 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:38:20 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:38:20 --> Utf8 Class Initialized
INFO - 2026-02-16 02:38:20 --> URI Class Initialized
INFO - 2026-02-16 02:38:20 --> Router Class Initialized
INFO - 2026-02-16 02:38:20 --> Output Class Initialized
INFO - 2026-02-16 02:38:20 --> Config Class Initialized
INFO - 2026-02-16 02:38:20 --> Hooks Class Initialized
INFO - 2026-02-16 02:38:20 --> Security Class Initialized
DEBUG - 2026-02-16 02:38:20 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:38:20 --> Utf8 Class Initialized
DEBUG - 2026-02-16 02:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:38:20 --> CSRF cookie sent
INFO - 2026-02-16 02:38:20 --> Input Class Initialized
INFO - 2026-02-16 02:38:20 --> Language Class Initialized
INFO - 2026-02-16 02:38:20 --> URI Class Initialized
INFO - 2026-02-16 02:38:20 --> Language Class Initialized
INFO - 2026-02-16 02:38:20 --> Config Class Initialized
INFO - 2026-02-16 02:38:20 --> Router Class Initialized
INFO - 2026-02-16 02:38:20 --> Loader Class Initialized
INFO - 2026-02-16 02:38:20 --> Helper loaded: url_helper
INFO - 2026-02-16 02:38:20 --> Output Class Initialized
INFO - 2026-02-16 02:38:20 --> Helper loaded: form_helper
INFO - 2026-02-16 02:38:20 --> Helper loaded: html_helper
INFO - 2026-02-16 02:38:20 --> Helper loaded: file_helper
INFO - 2026-02-16 02:38:20 --> Helper loaded: email_helper
INFO - 2026-02-16 02:38:20 --> Security Class Initialized
INFO - 2026-02-16 02:38:20 --> Helper loaded: whmaz_helper
DEBUG - 2026-02-16 02:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:38:20 --> CSRF cookie sent
INFO - 2026-02-16 02:38:20 --> Input Class Initialized
INFO - 2026-02-16 02:38:20 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:38:20 --> Language Class Initialized
INFO - 2026-02-16 02:38:20 --> Language Class Initialized
INFO - 2026-02-16 02:38:20 --> Config Class Initialized
INFO - 2026-02-16 02:38:20 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:38:20 --> Database Driver Class Initialized
INFO - 2026-02-16 02:38:20 --> Loader Class Initialized
INFO - 2026-02-16 02:38:20 --> Helper loaded: url_helper
INFO - 2026-02-16 02:38:20 --> Helper loaded: form_helper
INFO - 2026-02-16 02:38:20 --> Helper loaded: html_helper
INFO - 2026-02-16 02:38:20 --> Helper loaded: file_helper
INFO - 2026-02-16 02:38:20 --> Helper loaded: email_helper
INFO - 2026-02-16 02:38:20 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:38:20 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:38:20 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:38:20 --> Database Driver Class Initialized
INFO - 2026-02-16 02:38:20 --> Config Class Initialized
INFO - 2026-02-16 02:38:20 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:38:20 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:38:20 --> Utf8 Class Initialized
INFO - 2026-02-16 02:38:20 --> URI Class Initialized
INFO - 2026-02-16 02:38:20 --> Router Class Initialized
INFO - 2026-02-16 02:38:20 --> Config Class Initialized
INFO - 2026-02-16 02:38:20 --> Hooks Class Initialized
INFO - 2026-02-16 02:38:20 --> Config Class Initialized
INFO - 2026-02-16 02:38:20 --> Hooks Class Initialized
INFO - 2026-02-16 02:38:20 --> Output Class Initialized
DEBUG - 2026-02-16 02:38:20 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:38:20 --> Utf8 Class Initialized
DEBUG - 2026-02-16 02:38:20 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:38:20 --> Utf8 Class Initialized
INFO - 2026-02-16 02:38:20 --> Security Class Initialized
INFO - 2026-02-16 02:38:20 --> URI Class Initialized
DEBUG - 2026-02-16 02:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:38:20 --> CSRF cookie sent
INFO - 2026-02-16 02:38:20 --> Input Class Initialized
INFO - 2026-02-16 02:38:20 --> Language Class Initialized
INFO - 2026-02-16 02:38:20 --> Language Class Initialized
INFO - 2026-02-16 02:38:20 --> Config Class Initialized
INFO - 2026-02-16 02:38:20 --> Loader Class Initialized
INFO - 2026-02-16 02:38:20 --> Helper loaded: url_helper
INFO - 2026-02-16 02:38:20 --> Router Class Initialized
INFO - 2026-02-16 02:38:20 --> Helper loaded: form_helper
INFO - 2026-02-16 02:38:20 --> Helper loaded: html_helper
INFO - 2026-02-16 02:38:20 --> Helper loaded: file_helper
INFO - 2026-02-16 02:38:20 --> URI Class Initialized
INFO - 2026-02-16 02:38:20 --> Output Class Initialized
INFO - 2026-02-16 02:38:20 --> Helper loaded: email_helper
INFO - 2026-02-16 02:38:20 --> Security Class Initialized
INFO - 2026-02-16 02:38:20 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:38:20 --> Router Class Initialized
INFO - 2026-02-16 02:38:20 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:38:20 --> Config Class Initialized
INFO - 2026-02-16 02:38:20 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:38:20 --> CSRF cookie sent
INFO - 2026-02-16 02:38:20 --> Input Class Initialized
INFO - 2026-02-16 02:38:20 --> Output Class Initialized
INFO - 2026-02-16 02:38:20 --> Helper loaded: cpanel_helper
DEBUG - 2026-02-16 02:38:20 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:38:20 --> Utf8 Class Initialized
INFO - 2026-02-16 02:38:20 --> URI Class Initialized
INFO - 2026-02-16 02:38:20 --> Language Class Initialized
INFO - 2026-02-16 02:38:20 --> Language Class Initialized
INFO - 2026-02-16 02:38:20 --> Config Class Initialized
INFO - 2026-02-16 02:38:20 --> Database Driver Class Initialized
INFO - 2026-02-16 02:38:20 --> Loader Class Initialized
INFO - 2026-02-16 02:38:21 --> Helper loaded: url_helper
INFO - 2026-02-16 02:38:21 --> Helper loaded: form_helper
INFO - 2026-02-16 02:38:21 --> Helper loaded: html_helper
INFO - 2026-02-16 02:38:21 --> Security Class Initialized
INFO - 2026-02-16 02:38:21 --> Router Class Initialized
INFO - 2026-02-16 02:38:21 --> Helper loaded: file_helper
INFO - 2026-02-16 02:38:21 --> Helper loaded: email_helper
DEBUG - 2026-02-16 02:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:38:21 --> CSRF cookie sent
INFO - 2026-02-16 02:38:21 --> Input Class Initialized
INFO - 2026-02-16 02:38:21 --> Language Class Initialized
INFO - 2026-02-16 02:38:21 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:38:21 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:38:21 --> Output Class Initialized
INFO - 2026-02-16 02:38:21 --> Security Class Initialized
INFO - 2026-02-16 02:38:21 --> Language Class Initialized
INFO - 2026-02-16 02:38:21 --> Config Class Initialized
INFO - 2026-02-16 02:38:21 --> Helper loaded: cpanel_helper
DEBUG - 2026-02-16 02:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:38:21 --> CSRF cookie sent
INFO - 2026-02-16 02:38:21 --> Input Class Initialized
INFO - 2026-02-16 02:38:21 --> Language Class Initialized
INFO - 2026-02-16 02:38:21 --> Loader Class Initialized
INFO - 2026-02-16 02:38:21 --> Language Class Initialized
INFO - 2026-02-16 02:38:21 --> Config Class Initialized
INFO - 2026-02-16 02:38:21 --> Helper loaded: url_helper
INFO - 2026-02-16 02:38:21 --> Database Driver Class Initialized
INFO - 2026-02-16 02:38:21 --> Helper loaded: form_helper
INFO - 2026-02-16 02:38:21 --> Helper loaded: html_helper
INFO - 2026-02-16 02:38:21 --> Loader Class Initialized
INFO - 2026-02-16 02:38:21 --> Helper loaded: file_helper
INFO - 2026-02-16 02:38:21 --> Helper loaded: email_helper
INFO - 2026-02-16 02:38:21 --> Helper loaded: url_helper
INFO - 2026-02-16 02:38:21 --> Helper loaded: form_helper
INFO - 2026-02-16 02:38:21 --> Helper loaded: html_helper
INFO - 2026-02-16 02:38:21 --> Helper loaded: file_helper
INFO - 2026-02-16 02:38:21 --> Helper loaded: email_helper
INFO - 2026-02-16 02:38:21 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:38:21 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:38:21 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:38:21 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:38:21 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:38:21 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:38:21 --> Database Driver Class Initialized
INFO - 2026-02-16 02:38:21 --> Database Driver Class Initialized
INFO - 2026-02-16 02:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:38:22 --> Upload Class Initialized
DEBUG - 2026-02-16 02:38:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:38:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:38:22 --> Encryption Class Initialized
INFO - 2026-02-16 02:38:22 --> Form Validation Class Initialized
INFO - 2026-02-16 02:38:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:38:22 --> Pagination Class Initialized
INFO - 2026-02-16 02:38:22 --> Email Class Initialized
INFO - 2026-02-16 02:38:22 --> Controller Class Initialized
ERROR - 2026-02-16 02:38:22 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:38:22 --> Upload Class Initialized
DEBUG - 2026-02-16 02:38:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:38:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:38:22 --> Encryption Class Initialized
INFO - 2026-02-16 02:38:22 --> Form Validation Class Initialized
INFO - 2026-02-16 02:38:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:38:22 --> Pagination Class Initialized
INFO - 2026-02-16 02:38:22 --> Email Class Initialized
INFO - 2026-02-16 02:38:22 --> Config Class Initialized
INFO - 2026-02-16 02:38:22 --> Hooks Class Initialized
INFO - 2026-02-16 02:38:22 --> Controller Class Initialized
ERROR - 2026-02-16 02:38:22 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:38:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-02-16 02:38:22 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:38:22 --> Utf8 Class Initialized
INFO - 2026-02-16 02:38:22 --> URI Class Initialized
INFO - 2026-02-16 02:38:22 --> Upload Class Initialized
INFO - 2026-02-16 02:38:22 --> Router Class Initialized
DEBUG - 2026-02-16 02:38:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:38:22 --> Output Class Initialized
INFO - 2026-02-16 02:38:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:38:22 --> Encryption Class Initialized
INFO - 2026-02-16 02:38:22 --> Security Class Initialized
DEBUG - 2026-02-16 02:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:38:22 --> CSRF cookie sent
INFO - 2026-02-16 02:38:22 --> Input Class Initialized
INFO - 2026-02-16 02:38:22 --> Form Validation Class Initialized
INFO - 2026-02-16 02:38:22 --> Language Class Initialized
INFO - 2026-02-16 02:38:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:38:22 --> Pagination Class Initialized
INFO - 2026-02-16 02:38:22 --> Language Class Initialized
INFO - 2026-02-16 02:38:22 --> Config Class Initialized
INFO - 2026-02-16 02:38:22 --> Loader Class Initialized
INFO - 2026-02-16 02:38:22 --> Config Class Initialized
INFO - 2026-02-16 02:38:22 --> Hooks Class Initialized
INFO - 2026-02-16 02:38:22 --> Email Class Initialized
INFO - 2026-02-16 02:38:22 --> Helper loaded: url_helper
INFO - 2026-02-16 02:38:22 --> Controller Class Initialized
ERROR - 2026-02-16 02:38:22 --> 404 Page Not Found: /index
DEBUG - 2026-02-16 02:38:22 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:38:22 --> Utf8 Class Initialized
INFO - 2026-02-16 02:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:38:22 --> Helper loaded: form_helper
INFO - 2026-02-16 02:38:22 --> Helper loaded: html_helper
INFO - 2026-02-16 02:38:22 --> URI Class Initialized
INFO - 2026-02-16 02:38:22 --> Helper loaded: file_helper
INFO - 2026-02-16 02:38:22 --> Helper loaded: email_helper
INFO - 2026-02-16 02:38:22 --> Upload Class Initialized
INFO - 2026-02-16 02:38:22 --> Router Class Initialized
INFO - 2026-02-16 02:38:22 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:38:22 --> Helper loaded: ssp_helper
DEBUG - 2026-02-16 02:38:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:38:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:38:22 --> Encryption Class Initialized
INFO - 2026-02-16 02:38:22 --> Output Class Initialized
INFO - 2026-02-16 02:38:22 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:38:22 --> Security Class Initialized
INFO - 2026-02-16 02:38:22 --> Form Validation Class Initialized
DEBUG - 2026-02-16 02:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:38:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:38:22 --> CSRF cookie sent
INFO - 2026-02-16 02:38:22 --> Pagination Class Initialized
INFO - 2026-02-16 02:38:22 --> Input Class Initialized
INFO - 2026-02-16 02:38:22 --> Language Class Initialized
INFO - 2026-02-16 02:38:22 --> Language Class Initialized
INFO - 2026-02-16 02:38:22 --> Config Class Initialized
INFO - 2026-02-16 02:38:22 --> Loader Class Initialized
INFO - 2026-02-16 02:38:22 --> Database Driver Class Initialized
INFO - 2026-02-16 02:38:22 --> Config Class Initialized
INFO - 2026-02-16 02:38:22 --> Email Class Initialized
INFO - 2026-02-16 02:38:22 --> Hooks Class Initialized
INFO - 2026-02-16 02:38:22 --> Controller Class Initialized
INFO - 2026-02-16 02:38:22 --> Helper loaded: url_helper
ERROR - 2026-02-16 02:38:22 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:38:22 --> Helper loaded: form_helper
DEBUG - 2026-02-16 02:38:22 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:38:22 --> Utf8 Class Initialized
INFO - 2026-02-16 02:38:22 --> Helper loaded: html_helper
INFO - 2026-02-16 02:38:22 --> Helper loaded: file_helper
INFO - 2026-02-16 02:38:22 --> Helper loaded: email_helper
INFO - 2026-02-16 02:38:22 --> URI Class Initialized
INFO - 2026-02-16 02:38:22 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:38:22 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:38:22 --> Router Class Initialized
INFO - 2026-02-16 02:38:22 --> Output Class Initialized
INFO - 2026-02-16 02:38:22 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:38:22 --> Security Class Initialized
DEBUG - 2026-02-16 02:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:38:22 --> CSRF cookie sent
INFO - 2026-02-16 02:38:22 --> Input Class Initialized
INFO - 2026-02-16 02:38:22 --> Language Class Initialized
INFO - 2026-02-16 02:38:22 --> Language Class Initialized
INFO - 2026-02-16 02:38:22 --> Config Class Initialized
INFO - 2026-02-16 02:38:22 --> Loader Class Initialized
INFO - 2026-02-16 02:38:22 --> Database Driver Class Initialized
INFO - 2026-02-16 02:38:22 --> Helper loaded: url_helper
INFO - 2026-02-16 02:38:22 --> Helper loaded: form_helper
INFO - 2026-02-16 02:38:22 --> Helper loaded: html_helper
INFO - 2026-02-16 02:38:22 --> Helper loaded: file_helper
INFO - 2026-02-16 02:38:22 --> Helper loaded: email_helper
INFO - 2026-02-16 02:38:22 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:38:22 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:38:22 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:38:22 --> Database Driver Class Initialized
INFO - 2026-02-16 02:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:38:23 --> Upload Class Initialized
DEBUG - 2026-02-16 02:38:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:38:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:38:23 --> Encryption Class Initialized
INFO - 2026-02-16 02:38:23 --> Form Validation Class Initialized
INFO - 2026-02-16 02:38:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:38:23 --> Pagination Class Initialized
INFO - 2026-02-16 02:38:23 --> Email Class Initialized
INFO - 2026-02-16 02:38:23 --> Controller Class Initialized
ERROR - 2026-02-16 02:38:23 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:38:23 --> Config Class Initialized
INFO - 2026-02-16 02:38:23 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:38:23 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:38:23 --> Utf8 Class Initialized
INFO - 2026-02-16 02:38:23 --> URI Class Initialized
INFO - 2026-02-16 02:38:23 --> Router Class Initialized
INFO - 2026-02-16 02:38:23 --> Output Class Initialized
INFO - 2026-02-16 02:38:23 --> Security Class Initialized
DEBUG - 2026-02-16 02:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:38:23 --> CSRF cookie sent
INFO - 2026-02-16 02:38:23 --> Input Class Initialized
INFO - 2026-02-16 02:38:23 --> Language Class Initialized
INFO - 2026-02-16 02:38:23 --> Language Class Initialized
INFO - 2026-02-16 02:38:23 --> Config Class Initialized
INFO - 2026-02-16 02:38:23 --> Loader Class Initialized
INFO - 2026-02-16 02:38:23 --> Helper loaded: url_helper
INFO - 2026-02-16 02:38:23 --> Helper loaded: form_helper
INFO - 2026-02-16 02:38:23 --> Helper loaded: html_helper
INFO - 2026-02-16 02:38:23 --> Helper loaded: file_helper
INFO - 2026-02-16 02:38:23 --> Helper loaded: email_helper
INFO - 2026-02-16 02:38:23 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:38:23 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:38:23 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:38:23 --> Database Driver Class Initialized
INFO - 2026-02-16 02:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:38:23 --> Upload Class Initialized
DEBUG - 2026-02-16 02:38:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:38:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:38:23 --> Encryption Class Initialized
INFO - 2026-02-16 02:38:23 --> Form Validation Class Initialized
INFO - 2026-02-16 02:38:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:38:23 --> Pagination Class Initialized
INFO - 2026-02-16 02:38:23 --> Email Class Initialized
INFO - 2026-02-16 02:38:23 --> Controller Class Initialized
ERROR - 2026-02-16 02:38:23 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:38:25 --> Upload Class Initialized
DEBUG - 2026-02-16 02:38:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:38:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:38:25 --> Encryption Class Initialized
INFO - 2026-02-16 02:38:25 --> Form Validation Class Initialized
INFO - 2026-02-16 02:38:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:38:25 --> Pagination Class Initialized
INFO - 2026-02-16 02:38:25 --> Email Class Initialized
INFO - 2026-02-16 02:38:25 --> Controller Class Initialized
DEBUG - 2026-02-16 02:38:25 --> Pay MX_Controller Initialized
INFO - 2026-02-16 02:38:25 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:38:25 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:38:25 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:38:25 --> Model "Payment_model" initialized
INFO - 2026-02-16 02:38:25 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-16 02:38:25 --> Model "Billing_model" initialized
INFO - 2026-02-16 02:38:25 --> Model "Invoice_model" initialized
DEBUG - 2026-02-16 02:38:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-16 02:38:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-16 02:38:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-16 02:38:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_pay.php
INFO - 2026-02-16 02:38:27 --> Final output sent to browser
DEBUG - 2026-02-16 02:38:27 --> Total execution time: 4.3161
INFO - 2026-02-16 02:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:38:27 --> Upload Class Initialized
DEBUG - 2026-02-16 02:38:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:38:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:38:27 --> Encryption Class Initialized
INFO - 2026-02-16 02:38:27 --> Form Validation Class Initialized
INFO - 2026-02-16 02:38:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:38:27 --> Pagination Class Initialized
INFO - 2026-02-16 02:38:27 --> Email Class Initialized
INFO - 2026-02-16 02:38:27 --> Controller Class Initialized
ERROR - 2026-02-16 02:38:27 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:38:27 --> Upload Class Initialized
DEBUG - 2026-02-16 02:38:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:38:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:38:27 --> Encryption Class Initialized
INFO - 2026-02-16 02:38:27 --> Form Validation Class Initialized
INFO - 2026-02-16 02:38:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:38:27 --> Pagination Class Initialized
INFO - 2026-02-16 02:38:27 --> Email Class Initialized
INFO - 2026-02-16 02:38:27 --> Controller Class Initialized
ERROR - 2026-02-16 02:38:27 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:38:27 --> Config Class Initialized
INFO - 2026-02-16 02:38:27 --> Hooks Class Initialized
INFO - 2026-02-16 02:38:27 --> Config Class Initialized
INFO - 2026-02-16 02:38:27 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:38:27 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:38:27 --> Utf8 Class Initialized
INFO - 2026-02-16 02:38:27 --> URI Class Initialized
DEBUG - 2026-02-16 02:38:27 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:38:27 --> Utf8 Class Initialized
INFO - 2026-02-16 02:38:27 --> URI Class Initialized
INFO - 2026-02-16 02:38:27 --> Router Class Initialized
INFO - 2026-02-16 02:38:27 --> Router Class Initialized
INFO - 2026-02-16 02:38:27 --> Output Class Initialized
INFO - 2026-02-16 02:38:27 --> Output Class Initialized
INFO - 2026-02-16 02:38:27 --> Security Class Initialized
INFO - 2026-02-16 02:38:27 --> Security Class Initialized
DEBUG - 2026-02-16 02:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-02-16 02:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:38:27 --> CSRF cookie sent
INFO - 2026-02-16 02:38:27 --> Input Class Initialized
INFO - 2026-02-16 02:38:27 --> CSRF cookie sent
INFO - 2026-02-16 02:38:27 --> Input Class Initialized
INFO - 2026-02-16 02:38:27 --> Language Class Initialized
INFO - 2026-02-16 02:38:27 --> Language Class Initialized
INFO - 2026-02-16 02:38:27 --> Language Class Initialized
INFO - 2026-02-16 02:38:27 --> Config Class Initialized
INFO - 2026-02-16 02:38:27 --> Language Class Initialized
INFO - 2026-02-16 02:38:27 --> Config Class Initialized
INFO - 2026-02-16 02:38:27 --> Loader Class Initialized
INFO - 2026-02-16 02:38:27 --> Loader Class Initialized
INFO - 2026-02-16 02:38:27 --> Helper loaded: url_helper
INFO - 2026-02-16 02:38:27 --> Helper loaded: url_helper
INFO - 2026-02-16 02:38:27 --> Helper loaded: form_helper
INFO - 2026-02-16 02:38:27 --> Helper loaded: form_helper
INFO - 2026-02-16 02:38:27 --> Helper loaded: html_helper
INFO - 2026-02-16 02:38:27 --> Helper loaded: html_helper
INFO - 2026-02-16 02:38:27 --> Helper loaded: file_helper
INFO - 2026-02-16 02:38:27 --> Helper loaded: file_helper
INFO - 2026-02-16 02:38:27 --> Helper loaded: email_helper
INFO - 2026-02-16 02:38:27 --> Helper loaded: email_helper
INFO - 2026-02-16 02:38:27 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:38:27 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:38:27 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:38:27 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:38:27 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:38:27 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:38:27 --> Database Driver Class Initialized
INFO - 2026-02-16 02:38:27 --> Database Driver Class Initialized
INFO - 2026-02-16 02:38:28 --> Config Class Initialized
INFO - 2026-02-16 02:38:28 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:38:28 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:38:28 --> Utf8 Class Initialized
INFO - 2026-02-16 02:38:28 --> URI Class Initialized
INFO - 2026-02-16 02:38:28 --> Router Class Initialized
INFO - 2026-02-16 02:38:28 --> Output Class Initialized
INFO - 2026-02-16 02:38:28 --> Security Class Initialized
DEBUG - 2026-02-16 02:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:38:28 --> CSRF cookie sent
INFO - 2026-02-16 02:38:28 --> Input Class Initialized
INFO - 2026-02-16 02:38:28 --> Language Class Initialized
INFO - 2026-02-16 02:38:28 --> Language Class Initialized
INFO - 2026-02-16 02:38:28 --> Config Class Initialized
INFO - 2026-02-16 02:38:28 --> Loader Class Initialized
INFO - 2026-02-16 02:38:28 --> Helper loaded: url_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: form_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: html_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: file_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: email_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:38:28 --> Database Driver Class Initialized
INFO - 2026-02-16 02:38:28 --> Config Class Initialized
INFO - 2026-02-16 02:38:28 --> Hooks Class Initialized
INFO - 2026-02-16 02:38:28 --> Config Class Initialized
INFO - 2026-02-16 02:38:28 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:38:28 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:38:28 --> Utf8 Class Initialized
DEBUG - 2026-02-16 02:38:28 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:38:28 --> Utf8 Class Initialized
INFO - 2026-02-16 02:38:28 --> URI Class Initialized
INFO - 2026-02-16 02:38:28 --> URI Class Initialized
INFO - 2026-02-16 02:38:28 --> Router Class Initialized
INFO - 2026-02-16 02:38:28 --> Router Class Initialized
INFO - 2026-02-16 02:38:28 --> Output Class Initialized
INFO - 2026-02-16 02:38:28 --> Output Class Initialized
INFO - 2026-02-16 02:38:28 --> Security Class Initialized
INFO - 2026-02-16 02:38:28 --> Security Class Initialized
DEBUG - 2026-02-16 02:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:38:28 --> CSRF cookie sent
INFO - 2026-02-16 02:38:28 --> Input Class Initialized
DEBUG - 2026-02-16 02:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:38:28 --> CSRF cookie sent
INFO - 2026-02-16 02:38:28 --> Input Class Initialized
INFO - 2026-02-16 02:38:28 --> Language Class Initialized
INFO - 2026-02-16 02:38:28 --> Language Class Initialized
INFO - 2026-02-16 02:38:28 --> Language Class Initialized
INFO - 2026-02-16 02:38:28 --> Config Class Initialized
INFO - 2026-02-16 02:38:28 --> Language Class Initialized
INFO - 2026-02-16 02:38:28 --> Config Class Initialized
INFO - 2026-02-16 02:38:28 --> Loader Class Initialized
INFO - 2026-02-16 02:38:28 --> Loader Class Initialized
INFO - 2026-02-16 02:38:28 --> Helper loaded: url_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: url_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: form_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: form_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: html_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: html_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: file_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: file_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: email_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: email_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:38:28 --> Database Driver Class Initialized
INFO - 2026-02-16 02:38:28 --> Database Driver Class Initialized
INFO - 2026-02-16 02:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:38:28 --> Upload Class Initialized
DEBUG - 2026-02-16 02:38:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:38:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:38:28 --> Encryption Class Initialized
INFO - 2026-02-16 02:38:28 --> Form Validation Class Initialized
INFO - 2026-02-16 02:38:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:38:28 --> Pagination Class Initialized
INFO - 2026-02-16 02:38:28 --> Email Class Initialized
INFO - 2026-02-16 02:38:28 --> Controller Class Initialized
DEBUG - 2026-02-16 02:38:28 --> Cart MX_Controller Initialized
INFO - 2026-02-16 02:38:28 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:38:28 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:38:28 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:38:28 --> Model "Common_model" initialized
INFO - 2026-02-16 02:38:28 --> Model "Order_model" initialized
INFO - 2026-02-16 02:38:28 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 02:38:28 --> Final output sent to browser
DEBUG - 2026-02-16 02:38:28 --> Total execution time: 5.8255
INFO - 2026-02-16 02:38:28 --> Config Class Initialized
INFO - 2026-02-16 02:38:28 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:38:28 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:38:28 --> Utf8 Class Initialized
INFO - 2026-02-16 02:38:28 --> URI Class Initialized
INFO - 2026-02-16 02:38:28 --> Router Class Initialized
INFO - 2026-02-16 02:38:28 --> Output Class Initialized
INFO - 2026-02-16 02:38:28 --> Security Class Initialized
DEBUG - 2026-02-16 02:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:38:28 --> CSRF cookie sent
INFO - 2026-02-16 02:38:28 --> Input Class Initialized
INFO - 2026-02-16 02:38:28 --> Language Class Initialized
INFO - 2026-02-16 02:38:28 --> Language Class Initialized
INFO - 2026-02-16 02:38:28 --> Config Class Initialized
INFO - 2026-02-16 02:38:28 --> Loader Class Initialized
INFO - 2026-02-16 02:38:28 --> Helper loaded: url_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: form_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: html_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: file_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: email_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:38:28 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:38:28 --> Database Driver Class Initialized
INFO - 2026-02-16 02:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:38:29 --> Upload Class Initialized
DEBUG - 2026-02-16 02:38:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:38:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:38:29 --> Encryption Class Initialized
INFO - 2026-02-16 02:38:29 --> Form Validation Class Initialized
INFO - 2026-02-16 02:38:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:38:29 --> Pagination Class Initialized
INFO - 2026-02-16 02:38:29 --> Email Class Initialized
INFO - 2026-02-16 02:38:29 --> Controller Class Initialized
ERROR - 2026-02-16 02:38:29 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:38:29 --> Upload Class Initialized
DEBUG - 2026-02-16 02:38:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:38:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:38:29 --> Encryption Class Initialized
INFO - 2026-02-16 02:38:29 --> Form Validation Class Initialized
INFO - 2026-02-16 02:38:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:38:29 --> Pagination Class Initialized
INFO - 2026-02-16 02:38:29 --> Config Class Initialized
INFO - 2026-02-16 02:38:29 --> Hooks Class Initialized
INFO - 2026-02-16 02:38:29 --> Email Class Initialized
INFO - 2026-02-16 02:38:29 --> Controller Class Initialized
ERROR - 2026-02-16 02:38:29 --> 404 Page Not Found: /index
DEBUG - 2026-02-16 02:38:29 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:38:29 --> Utf8 Class Initialized
INFO - 2026-02-16 02:38:29 --> URI Class Initialized
INFO - 2026-02-16 02:38:29 --> Router Class Initialized
INFO - 2026-02-16 02:38:29 --> Output Class Initialized
INFO - 2026-02-16 02:38:29 --> Security Class Initialized
DEBUG - 2026-02-16 02:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:38:29 --> CSRF cookie sent
INFO - 2026-02-16 02:38:29 --> Input Class Initialized
INFO - 2026-02-16 02:38:29 --> Language Class Initialized
INFO - 2026-02-16 02:38:29 --> Language Class Initialized
INFO - 2026-02-16 02:38:29 --> Config Class Initialized
INFO - 2026-02-16 02:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:38:29 --> Config Class Initialized
INFO - 2026-02-16 02:38:29 --> Hooks Class Initialized
INFO - 2026-02-16 02:38:29 --> Loader Class Initialized
DEBUG - 2026-02-16 02:38:29 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:38:29 --> Utf8 Class Initialized
INFO - 2026-02-16 02:38:29 --> Upload Class Initialized
INFO - 2026-02-16 02:38:29 --> Helper loaded: url_helper
INFO - 2026-02-16 02:38:29 --> URI Class Initialized
DEBUG - 2026-02-16 02:38:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:38:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:38:29 --> Encryption Class Initialized
INFO - 2026-02-16 02:38:29 --> Helper loaded: form_helper
INFO - 2026-02-16 02:38:29 --> Helper loaded: html_helper
INFO - 2026-02-16 02:38:29 --> Router Class Initialized
INFO - 2026-02-16 02:38:29 --> Helper loaded: file_helper
INFO - 2026-02-16 02:38:29 --> Helper loaded: email_helper
INFO - 2026-02-16 02:38:29 --> Form Validation Class Initialized
INFO - 2026-02-16 02:38:29 --> Output Class Initialized
INFO - 2026-02-16 02:38:29 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:38:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:38:29 --> Pagination Class Initialized
INFO - 2026-02-16 02:38:29 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:38:29 --> Security Class Initialized
DEBUG - 2026-02-16 02:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:38:29 --> CSRF cookie sent
INFO - 2026-02-16 02:38:29 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:38:29 --> Input Class Initialized
INFO - 2026-02-16 02:38:29 --> Language Class Initialized
INFO - 2026-02-16 02:38:29 --> Language Class Initialized
INFO - 2026-02-16 02:38:29 --> Config Class Initialized
INFO - 2026-02-16 02:38:29 --> Email Class Initialized
INFO - 2026-02-16 02:38:29 --> Controller Class Initialized
ERROR - 2026-02-16 02:38:29 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:38:29 --> Loader Class Initialized
INFO - 2026-02-16 02:38:29 --> Helper loaded: url_helper
INFO - 2026-02-16 02:38:29 --> Helper loaded: form_helper
INFO - 2026-02-16 02:38:29 --> Database Driver Class Initialized
INFO - 2026-02-16 02:38:29 --> Helper loaded: html_helper
INFO - 2026-02-16 02:38:29 --> Helper loaded: file_helper
INFO - 2026-02-16 02:38:29 --> Helper loaded: email_helper
INFO - 2026-02-16 02:38:29 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:38:29 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:38:29 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:38:29 --> Config Class Initialized
INFO - 2026-02-16 02:38:29 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:38:29 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:38:29 --> Utf8 Class Initialized
INFO - 2026-02-16 02:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:38:29 --> URI Class Initialized
INFO - 2026-02-16 02:38:29 --> Upload Class Initialized
INFO - 2026-02-16 02:38:29 --> Router Class Initialized
INFO - 2026-02-16 02:38:29 --> Database Driver Class Initialized
DEBUG - 2026-02-16 02:38:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:38:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:38:29 --> Encryption Class Initialized
INFO - 2026-02-16 02:38:29 --> Output Class Initialized
INFO - 2026-02-16 02:38:29 --> Form Validation Class Initialized
INFO - 2026-02-16 02:38:29 --> Security Class Initialized
INFO - 2026-02-16 02:38:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:38:29 --> Pagination Class Initialized
DEBUG - 2026-02-16 02:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:38:29 --> CSRF cookie sent
INFO - 2026-02-16 02:38:29 --> Input Class Initialized
INFO - 2026-02-16 02:38:29 --> Language Class Initialized
INFO - 2026-02-16 02:38:29 --> Language Class Initialized
INFO - 2026-02-16 02:38:29 --> Config Class Initialized
INFO - 2026-02-16 02:38:29 --> Email Class Initialized
INFO - 2026-02-16 02:38:29 --> Controller Class Initialized
ERROR - 2026-02-16 02:38:29 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:38:29 --> Upload Class Initialized
INFO - 2026-02-16 02:38:29 --> Loader Class Initialized
INFO - 2026-02-16 02:38:29 --> Helper loaded: url_helper
DEBUG - 2026-02-16 02:38:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:38:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:38:29 --> Encryption Class Initialized
INFO - 2026-02-16 02:38:29 --> Helper loaded: form_helper
INFO - 2026-02-16 02:38:29 --> Helper loaded: html_helper
INFO - 2026-02-16 02:38:29 --> Form Validation Class Initialized
INFO - 2026-02-16 02:38:29 --> Helper loaded: file_helper
INFO - 2026-02-16 02:38:29 --> Helper loaded: email_helper
INFO - 2026-02-16 02:38:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:38:29 --> Pagination Class Initialized
INFO - 2026-02-16 02:38:29 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:38:29 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:38:29 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:38:29 --> Email Class Initialized
INFO - 2026-02-16 02:38:29 --> Controller Class Initialized
ERROR - 2026-02-16 02:38:29 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:38:29 --> Database Driver Class Initialized
INFO - 2026-02-16 02:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:38:30 --> Upload Class Initialized
DEBUG - 2026-02-16 02:38:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:38:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:38:30 --> Encryption Class Initialized
INFO - 2026-02-16 02:38:30 --> Form Validation Class Initialized
INFO - 2026-02-16 02:38:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:38:30 --> Pagination Class Initialized
INFO - 2026-02-16 02:38:30 --> Email Class Initialized
INFO - 2026-02-16 02:38:30 --> Controller Class Initialized
DEBUG - 2026-02-16 02:38:30 --> Cart MX_Controller Initialized
INFO - 2026-02-16 02:38:30 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:38:30 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:38:30 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:38:30 --> Model "Common_model" initialized
INFO - 2026-02-16 02:38:30 --> Model "Order_model" initialized
INFO - 2026-02-16 02:38:30 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 02:38:30 --> Final output sent to browser
DEBUG - 2026-02-16 02:38:30 --> Total execution time: 2.1038
INFO - 2026-02-16 02:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:38:31 --> Upload Class Initialized
DEBUG - 2026-02-16 02:38:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:38:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:38:31 --> Encryption Class Initialized
INFO - 2026-02-16 02:38:31 --> Form Validation Class Initialized
INFO - 2026-02-16 02:38:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:38:31 --> Pagination Class Initialized
INFO - 2026-02-16 02:38:31 --> Email Class Initialized
INFO - 2026-02-16 02:38:31 --> Controller Class Initialized
ERROR - 2026-02-16 02:38:31 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:38:31 --> Upload Class Initialized
DEBUG - 2026-02-16 02:38:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:38:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:38:31 --> Encryption Class Initialized
INFO - 2026-02-16 02:38:31 --> Form Validation Class Initialized
INFO - 2026-02-16 02:38:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:38:31 --> Pagination Class Initialized
INFO - 2026-02-16 02:38:31 --> Email Class Initialized
INFO - 2026-02-16 02:38:31 --> Controller Class Initialized
ERROR - 2026-02-16 02:38:31 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:38:32 --> Upload Class Initialized
DEBUG - 2026-02-16 02:38:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:38:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:38:32 --> Encryption Class Initialized
INFO - 2026-02-16 02:38:32 --> Form Validation Class Initialized
INFO - 2026-02-16 02:38:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:38:32 --> Pagination Class Initialized
INFO - 2026-02-16 02:38:32 --> Email Class Initialized
INFO - 2026-02-16 02:38:32 --> Controller Class Initialized
ERROR - 2026-02-16 02:38:32 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:38:36 --> Config Class Initialized
INFO - 2026-02-16 02:38:36 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:38:36 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:38:36 --> Utf8 Class Initialized
INFO - 2026-02-16 02:38:36 --> URI Class Initialized
INFO - 2026-02-16 02:38:36 --> Router Class Initialized
INFO - 2026-02-16 02:38:36 --> Output Class Initialized
INFO - 2026-02-16 02:38:36 --> Security Class Initialized
DEBUG - 2026-02-16 02:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:38:36 --> CSRF cookie sent
INFO - 2026-02-16 02:38:36 --> CSRF token verified
INFO - 2026-02-16 02:38:36 --> Input Class Initialized
INFO - 2026-02-16 02:38:36 --> Language Class Initialized
INFO - 2026-02-16 02:38:36 --> Language Class Initialized
INFO - 2026-02-16 02:38:36 --> Config Class Initialized
INFO - 2026-02-16 02:38:36 --> Loader Class Initialized
INFO - 2026-02-16 02:38:36 --> Helper loaded: url_helper
INFO - 2026-02-16 02:38:36 --> Helper loaded: form_helper
INFO - 2026-02-16 02:38:36 --> Helper loaded: html_helper
INFO - 2026-02-16 02:38:36 --> Helper loaded: file_helper
INFO - 2026-02-16 02:38:36 --> Helper loaded: email_helper
INFO - 2026-02-16 02:38:36 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:38:36 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:38:36 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:38:36 --> Database Driver Class Initialized
INFO - 2026-02-16 02:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:38:38 --> Upload Class Initialized
DEBUG - 2026-02-16 02:38:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:38:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:38:38 --> Encryption Class Initialized
INFO - 2026-02-16 02:38:38 --> Form Validation Class Initialized
INFO - 2026-02-16 02:38:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:38:38 --> Pagination Class Initialized
INFO - 2026-02-16 02:38:38 --> Email Class Initialized
INFO - 2026-02-16 02:38:38 --> Controller Class Initialized
DEBUG - 2026-02-16 02:38:38 --> Pay MX_Controller Initialized
INFO - 2026-02-16 02:38:38 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:38:38 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:38:38 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:38:38 --> Model "Payment_model" initialized
INFO - 2026-02-16 02:38:38 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-16 02:38:38 --> Model "Billing_model" initialized
INFO - 2026-02-16 02:38:38 --> Model "Invoice_model" initialized
INFO - 2026-02-16 02:38:43 --> Final output sent to browser
DEBUG - 2026-02-16 02:38:43 --> Total execution time: 7.3925
INFO - 2026-02-16 02:39:00 --> Config Class Initialized
INFO - 2026-02-16 02:39:00 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:39:00 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:39:00 --> Utf8 Class Initialized
INFO - 2026-02-16 02:39:00 --> URI Class Initialized
INFO - 2026-02-16 02:39:00 --> Router Class Initialized
INFO - 2026-02-16 02:39:00 --> Output Class Initialized
INFO - 2026-02-16 02:39:00 --> Security Class Initialized
DEBUG - 2026-02-16 02:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:39:00 --> Input Class Initialized
INFO - 2026-02-16 02:39:00 --> Language Class Initialized
INFO - 2026-02-16 02:39:00 --> Language Class Initialized
INFO - 2026-02-16 02:39:00 --> Config Class Initialized
INFO - 2026-02-16 02:39:00 --> Loader Class Initialized
INFO - 2026-02-16 02:39:00 --> Helper loaded: url_helper
INFO - 2026-02-16 02:39:00 --> Helper loaded: form_helper
INFO - 2026-02-16 02:39:00 --> Helper loaded: html_helper
INFO - 2026-02-16 02:39:00 --> Helper loaded: file_helper
INFO - 2026-02-16 02:39:00 --> Helper loaded: email_helper
INFO - 2026-02-16 02:39:00 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:39:00 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:39:00 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:39:00 --> Database Driver Class Initialized
INFO - 2026-02-16 02:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:39:02 --> Upload Class Initialized
DEBUG - 2026-02-16 02:39:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:39:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:39:02 --> Encryption Class Initialized
INFO - 2026-02-16 02:39:02 --> Form Validation Class Initialized
INFO - 2026-02-16 02:39:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:39:02 --> Pagination Class Initialized
INFO - 2026-02-16 02:39:02 --> Email Class Initialized
INFO - 2026-02-16 02:39:02 --> Controller Class Initialized
DEBUG - 2026-02-16 02:39:02 --> Pay MX_Controller Initialized
INFO - 2026-02-16 02:39:02 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:39:02 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:39:02 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:39:02 --> Model "Payment_model" initialized
INFO - 2026-02-16 02:39:02 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-16 02:39:02 --> Model "Billing_model" initialized
INFO - 2026-02-16 02:39:02 --> Model "Invoice_model" initialized
INFO - 2026-02-16 02:39:07 --> Model "Common_model" initialized
INFO - 2026-02-16 02:39:07 --> Model "Order_model" initialized
INFO - 2026-02-16 02:39:07 --> Model "Company_model" initialized
INFO - 2026-02-16 02:39:07 --> Invoice #553 marked as PAID. Total: 32.95, Paid: 32.95
INFO - 2026-02-16 02:39:09 --> Config Class Initialized
INFO - 2026-02-16 02:39:09 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:39:09 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:39:09 --> Utf8 Class Initialized
INFO - 2026-02-16 02:39:09 --> URI Class Initialized
INFO - 2026-02-16 02:39:09 --> Router Class Initialized
INFO - 2026-02-16 02:39:09 --> Output Class Initialized
INFO - 2026-02-16 02:39:09 --> Security Class Initialized
DEBUG - 2026-02-16 02:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:39:09 --> CSRF cookie sent
INFO - 2026-02-16 02:39:09 --> Input Class Initialized
INFO - 2026-02-16 02:39:09 --> Language Class Initialized
INFO - 2026-02-16 02:39:09 --> Language Class Initialized
INFO - 2026-02-16 02:39:09 --> Config Class Initialized
INFO - 2026-02-16 02:39:09 --> Loader Class Initialized
INFO - 2026-02-16 02:39:09 --> Helper loaded: url_helper
INFO - 2026-02-16 02:39:09 --> Helper loaded: form_helper
INFO - 2026-02-16 02:39:09 --> Helper loaded: html_helper
INFO - 2026-02-16 02:39:09 --> Helper loaded: file_helper
INFO - 2026-02-16 02:39:09 --> Helper loaded: email_helper
INFO - 2026-02-16 02:39:09 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:39:09 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:39:09 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:39:09 --> Database Driver Class Initialized
INFO - 2026-02-16 02:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:39:11 --> Upload Class Initialized
DEBUG - 2026-02-16 02:39:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:39:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:39:11 --> Encryption Class Initialized
INFO - 2026-02-16 02:39:11 --> Form Validation Class Initialized
INFO - 2026-02-16 02:39:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:39:11 --> Pagination Class Initialized
INFO - 2026-02-16 02:39:11 --> Email Class Initialized
INFO - 2026-02-16 02:39:11 --> Controller Class Initialized
DEBUG - 2026-02-16 02:39:11 --> Billing MX_Controller Initialized
INFO - 2026-02-16 02:39:11 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:39:11 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:39:11 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:39:11 --> Model "Billing_model" initialized
INFO - 2026-02-16 02:39:11 --> Model "Common_model" initialized
INFO - 2026-02-16 02:39:11 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 02:39:11 --> Config Class Initialized
INFO - 2026-02-16 02:39:11 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:39:11 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:39:11 --> Utf8 Class Initialized
INFO - 2026-02-16 02:39:11 --> URI Class Initialized
INFO - 2026-02-16 02:39:11 --> Router Class Initialized
INFO - 2026-02-16 02:39:11 --> Output Class Initialized
INFO - 2026-02-16 02:39:11 --> Security Class Initialized
DEBUG - 2026-02-16 02:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:39:11 --> CSRF cookie sent
INFO - 2026-02-16 02:39:11 --> Input Class Initialized
INFO - 2026-02-16 02:39:11 --> Language Class Initialized
INFO - 2026-02-16 02:39:11 --> Language Class Initialized
INFO - 2026-02-16 02:39:11 --> Config Class Initialized
INFO - 2026-02-16 02:39:11 --> Loader Class Initialized
INFO - 2026-02-16 02:39:11 --> Helper loaded: url_helper
INFO - 2026-02-16 02:39:11 --> Helper loaded: form_helper
INFO - 2026-02-16 02:39:11 --> Helper loaded: html_helper
INFO - 2026-02-16 02:39:11 --> Helper loaded: file_helper
INFO - 2026-02-16 02:39:11 --> Helper loaded: email_helper
INFO - 2026-02-16 02:39:11 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:39:11 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:39:11 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:39:11 --> Database Driver Class Initialized
INFO - 2026-02-16 02:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:39:13 --> Upload Class Initialized
DEBUG - 2026-02-16 02:39:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:39:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:39:13 --> Encryption Class Initialized
INFO - 2026-02-16 02:39:13 --> Form Validation Class Initialized
INFO - 2026-02-16 02:39:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:39:13 --> Pagination Class Initialized
INFO - 2026-02-16 02:39:13 --> Email Class Initialized
INFO - 2026-02-16 02:39:13 --> Controller Class Initialized
DEBUG - 2026-02-16 02:39:13 --> Auth MX_Controller Initialized
INFO - 2026-02-16 02:39:13 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:39:13 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:39:13 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:39:13 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-16 02:39:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-16 02:39:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-16 02:39:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-16 02:39:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-02-16 02:39:14 --> Final output sent to browser
DEBUG - 2026-02-16 02:39:14 --> Total execution time: 2.4026
INFO - 2026-02-16 02:39:14 --> Config Class Initialized
INFO - 2026-02-16 02:39:14 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:39:14 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:39:14 --> Utf8 Class Initialized
INFO - 2026-02-16 02:39:14 --> URI Class Initialized
INFO - 2026-02-16 02:39:14 --> Router Class Initialized
INFO - 2026-02-16 02:39:14 --> Output Class Initialized
INFO - 2026-02-16 02:39:14 --> Security Class Initialized
DEBUG - 2026-02-16 02:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:39:14 --> CSRF cookie sent
INFO - 2026-02-16 02:39:14 --> Input Class Initialized
INFO - 2026-02-16 02:39:14 --> Language Class Initialized
INFO - 2026-02-16 02:39:14 --> Language Class Initialized
INFO - 2026-02-16 02:39:14 --> Config Class Initialized
INFO - 2026-02-16 02:39:14 --> Loader Class Initialized
INFO - 2026-02-16 02:39:14 --> Helper loaded: url_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: form_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: html_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: file_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: email_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:39:14 --> Database Driver Class Initialized
INFO - 2026-02-16 02:39:14 --> Config Class Initialized
INFO - 2026-02-16 02:39:14 --> Hooks Class Initialized
DEBUG - 2026-02-16 02:39:14 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:39:14 --> Utf8 Class Initialized
INFO - 2026-02-16 02:39:14 --> URI Class Initialized
INFO - 2026-02-16 02:39:14 --> Router Class Initialized
INFO - 2026-02-16 02:39:14 --> Output Class Initialized
INFO - 2026-02-16 02:39:14 --> Security Class Initialized
DEBUG - 2026-02-16 02:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:39:14 --> CSRF cookie sent
INFO - 2026-02-16 02:39:14 --> Input Class Initialized
INFO - 2026-02-16 02:39:14 --> Language Class Initialized
INFO - 2026-02-16 02:39:14 --> Language Class Initialized
INFO - 2026-02-16 02:39:14 --> Config Class Initialized
INFO - 2026-02-16 02:39:14 --> Loader Class Initialized
INFO - 2026-02-16 02:39:14 --> Helper loaded: url_helper
INFO - 2026-02-16 02:39:14 --> Config Class Initialized
INFO - 2026-02-16 02:39:14 --> Hooks Class Initialized
INFO - 2026-02-16 02:39:14 --> Helper loaded: form_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: html_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: file_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: email_helper
DEBUG - 2026-02-16 02:39:14 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:39:14 --> Utf8 Class Initialized
INFO - 2026-02-16 02:39:14 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:39:14 --> URI Class Initialized
INFO - 2026-02-16 02:39:14 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:39:14 --> Router Class Initialized
INFO - 2026-02-16 02:39:14 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:39:14 --> Output Class Initialized
INFO - 2026-02-16 02:39:14 --> Security Class Initialized
DEBUG - 2026-02-16 02:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:39:14 --> CSRF cookie sent
INFO - 2026-02-16 02:39:14 --> Input Class Initialized
INFO - 2026-02-16 02:39:14 --> Language Class Initialized
INFO - 2026-02-16 02:39:14 --> Language Class Initialized
INFO - 2026-02-16 02:39:14 --> Config Class Initialized
INFO - 2026-02-16 02:39:14 --> Database Driver Class Initialized
INFO - 2026-02-16 02:39:14 --> Config Class Initialized
INFO - 2026-02-16 02:39:14 --> Hooks Class Initialized
INFO - 2026-02-16 02:39:14 --> Config Class Initialized
INFO - 2026-02-16 02:39:14 --> Hooks Class Initialized
INFO - 2026-02-16 02:39:14 --> Loader Class Initialized
INFO - 2026-02-16 02:39:14 --> Config Class Initialized
INFO - 2026-02-16 02:39:14 --> Hooks Class Initialized
INFO - 2026-02-16 02:39:14 --> Helper loaded: url_helper
DEBUG - 2026-02-16 02:39:14 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:39:14 --> Utf8 Class Initialized
DEBUG - 2026-02-16 02:39:14 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:39:14 --> Utf8 Class Initialized
DEBUG - 2026-02-16 02:39:14 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:39:14 --> Utf8 Class Initialized
INFO - 2026-02-16 02:39:14 --> URI Class Initialized
INFO - 2026-02-16 02:39:14 --> Helper loaded: form_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: html_helper
INFO - 2026-02-16 02:39:14 --> URI Class Initialized
INFO - 2026-02-16 02:39:14 --> URI Class Initialized
INFO - 2026-02-16 02:39:14 --> Helper loaded: file_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: email_helper
INFO - 2026-02-16 02:39:14 --> Router Class Initialized
INFO - 2026-02-16 02:39:14 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:39:14 --> Router Class Initialized
INFO - 2026-02-16 02:39:14 --> Router Class Initialized
INFO - 2026-02-16 02:39:14 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:39:14 --> Output Class Initialized
INFO - 2026-02-16 02:39:14 --> Output Class Initialized
INFO - 2026-02-16 02:39:14 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:39:14 --> Output Class Initialized
INFO - 2026-02-16 02:39:14 --> Security Class Initialized
INFO - 2026-02-16 02:39:14 --> Security Class Initialized
INFO - 2026-02-16 02:39:14 --> Security Class Initialized
DEBUG - 2026-02-16 02:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:39:14 --> CSRF cookie sent
INFO - 2026-02-16 02:39:14 --> Input Class Initialized
INFO - 2026-02-16 02:39:14 --> Language Class Initialized
DEBUG - 2026-02-16 02:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:39:14 --> CSRF cookie sent
INFO - 2026-02-16 02:39:14 --> Input Class Initialized
INFO - 2026-02-16 02:39:14 --> Language Class Initialized
DEBUG - 2026-02-16 02:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:39:14 --> CSRF cookie sent
INFO - 2026-02-16 02:39:14 --> Input Class Initialized
INFO - 2026-02-16 02:39:14 --> Language Class Initialized
INFO - 2026-02-16 02:39:14 --> Config Class Initialized
INFO - 2026-02-16 02:39:14 --> Language Class Initialized
INFO - 2026-02-16 02:39:14 --> Language Class Initialized
INFO - 2026-02-16 02:39:14 --> Config Class Initialized
INFO - 2026-02-16 02:39:14 --> Language Class Initialized
INFO - 2026-02-16 02:39:14 --> Config Class Initialized
INFO - 2026-02-16 02:39:14 --> Database Driver Class Initialized
INFO - 2026-02-16 02:39:14 --> Loader Class Initialized
INFO - 2026-02-16 02:39:14 --> Loader Class Initialized
INFO - 2026-02-16 02:39:14 --> Loader Class Initialized
INFO - 2026-02-16 02:39:14 --> Helper loaded: url_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: url_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: url_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: form_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: form_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: html_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: form_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: html_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: file_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: html_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: email_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: file_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: email_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: file_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: email_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:39:14 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:39:14 --> Database Driver Class Initialized
INFO - 2026-02-16 02:39:14 --> Database Driver Class Initialized
INFO - 2026-02-16 02:39:14 --> Database Driver Class Initialized
INFO - 2026-02-16 02:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:39:16 --> Upload Class Initialized
DEBUG - 2026-02-16 02:39:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:39:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:39:16 --> Encryption Class Initialized
INFO - 2026-02-16 02:39:16 --> Form Validation Class Initialized
INFO - 2026-02-16 02:39:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:39:16 --> Pagination Class Initialized
INFO - 2026-02-16 02:39:16 --> Email Class Initialized
INFO - 2026-02-16 02:39:16 --> Controller Class Initialized
ERROR - 2026-02-16 02:39:16 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:39:16 --> Upload Class Initialized
DEBUG - 2026-02-16 02:39:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:39:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:39:16 --> Encryption Class Initialized
INFO - 2026-02-16 02:39:16 --> Form Validation Class Initialized
INFO - 2026-02-16 02:39:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:39:16 --> Pagination Class Initialized
INFO - 2026-02-16 02:39:16 --> Config Class Initialized
INFO - 2026-02-16 02:39:16 --> Hooks Class Initialized
INFO - 2026-02-16 02:39:16 --> Email Class Initialized
INFO - 2026-02-16 02:39:16 --> Controller Class Initialized
DEBUG - 2026-02-16 02:39:16 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:39:16 --> Utf8 Class Initialized
ERROR - 2026-02-16 02:39:16 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:39:16 --> URI Class Initialized
INFO - 2026-02-16 02:39:16 --> Router Class Initialized
INFO - 2026-02-16 02:39:16 --> Upload Class Initialized
INFO - 2026-02-16 02:39:16 --> Output Class Initialized
DEBUG - 2026-02-16 02:39:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:39:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:39:16 --> Encryption Class Initialized
INFO - 2026-02-16 02:39:16 --> Security Class Initialized
DEBUG - 2026-02-16 02:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:39:16 --> CSRF cookie sent
INFO - 2026-02-16 02:39:16 --> Input Class Initialized
INFO - 2026-02-16 02:39:16 --> Language Class Initialized
INFO - 2026-02-16 02:39:16 --> Form Validation Class Initialized
INFO - 2026-02-16 02:39:16 --> Language Class Initialized
INFO - 2026-02-16 02:39:16 --> Config Class Initialized
INFO - 2026-02-16 02:39:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:39:16 --> Pagination Class Initialized
INFO - 2026-02-16 02:39:16 --> Config Class Initialized
INFO - 2026-02-16 02:39:16 --> Hooks Class Initialized
INFO - 2026-02-16 02:39:16 --> Loader Class Initialized
INFO - 2026-02-16 02:39:16 --> Helper loaded: url_helper
INFO - 2026-02-16 02:39:16 --> Email Class Initialized
INFO - 2026-02-16 02:39:16 --> Controller Class Initialized
DEBUG - 2026-02-16 02:39:16 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:39:16 --> Utf8 Class Initialized
ERROR - 2026-02-16 02:39:16 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:39:16 --> URI Class Initialized
INFO - 2026-02-16 02:39:16 --> Helper loaded: form_helper
INFO - 2026-02-16 02:39:16 --> Helper loaded: html_helper
INFO - 2026-02-16 02:39:16 --> Helper loaded: file_helper
INFO - 2026-02-16 02:39:16 --> Helper loaded: email_helper
INFO - 2026-02-16 02:39:16 --> Router Class Initialized
INFO - 2026-02-16 02:39:16 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:39:16 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:39:16 --> Output Class Initialized
INFO - 2026-02-16 02:39:16 --> Security Class Initialized
INFO - 2026-02-16 02:39:16 --> Helper loaded: cpanel_helper
DEBUG - 2026-02-16 02:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:39:16 --> CSRF cookie sent
INFO - 2026-02-16 02:39:16 --> Input Class Initialized
INFO - 2026-02-16 02:39:16 --> Language Class Initialized
INFO - 2026-02-16 02:39:16 --> Language Class Initialized
INFO - 2026-02-16 02:39:16 --> Config Class Initialized
INFO - 2026-02-16 02:39:16 --> Database Driver Class Initialized
INFO - 2026-02-16 02:39:16 --> Loader Class Initialized
INFO - 2026-02-16 02:39:16 --> Config Class Initialized
INFO - 2026-02-16 02:39:16 --> Hooks Class Initialized
INFO - 2026-02-16 02:39:16 --> Helper loaded: url_helper
DEBUG - 2026-02-16 02:39:16 --> UTF-8 Support Enabled
INFO - 2026-02-16 02:39:16 --> Utf8 Class Initialized
INFO - 2026-02-16 02:39:16 --> Helper loaded: form_helper
INFO - 2026-02-16 02:39:16 --> URI Class Initialized
INFO - 2026-02-16 02:39:16 --> Helper loaded: html_helper
INFO - 2026-02-16 02:39:16 --> Helper loaded: file_helper
INFO - 2026-02-16 02:39:16 --> Helper loaded: email_helper
INFO - 2026-02-16 02:39:16 --> Router Class Initialized
INFO - 2026-02-16 02:39:16 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:39:16 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:39:16 --> Output Class Initialized
INFO - 2026-02-16 02:39:16 --> Security Class Initialized
INFO - 2026-02-16 02:39:16 --> Helper loaded: cpanel_helper
DEBUG - 2026-02-16 02:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 02:39:16 --> CSRF cookie sent
INFO - 2026-02-16 02:39:16 --> Input Class Initialized
INFO - 2026-02-16 02:39:16 --> Language Class Initialized
INFO - 2026-02-16 02:39:16 --> Language Class Initialized
INFO - 2026-02-16 02:39:16 --> Config Class Initialized
INFO - 2026-02-16 02:39:16 --> Loader Class Initialized
INFO - 2026-02-16 02:39:16 --> Helper loaded: url_helper
INFO - 2026-02-16 02:39:16 --> Database Driver Class Initialized
INFO - 2026-02-16 02:39:16 --> Helper loaded: form_helper
INFO - 2026-02-16 02:39:16 --> Helper loaded: html_helper
INFO - 2026-02-16 02:39:16 --> Helper loaded: file_helper
INFO - 2026-02-16 02:39:16 --> Helper loaded: email_helper
INFO - 2026-02-16 02:39:16 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 02:39:16 --> Helper loaded: ssp_helper
INFO - 2026-02-16 02:39:16 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 02:39:16 --> Database Driver Class Initialized
INFO - 2026-02-16 02:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:39:16 --> Upload Class Initialized
DEBUG - 2026-02-16 02:39:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:39:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:39:16 --> Encryption Class Initialized
INFO - 2026-02-16 02:39:16 --> Form Validation Class Initialized
INFO - 2026-02-16 02:39:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:39:16 --> Pagination Class Initialized
INFO - 2026-02-16 02:39:16 --> Email Class Initialized
INFO - 2026-02-16 02:39:16 --> Controller Class Initialized
ERROR - 2026-02-16 02:39:16 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:39:17 --> Upload Class Initialized
DEBUG - 2026-02-16 02:39:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:39:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:39:17 --> Encryption Class Initialized
INFO - 2026-02-16 02:39:17 --> Form Validation Class Initialized
INFO - 2026-02-16 02:39:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:39:17 --> Pagination Class Initialized
INFO - 2026-02-16 02:39:17 --> Email Class Initialized
INFO - 2026-02-16 02:39:17 --> Controller Class Initialized
ERROR - 2026-02-16 02:39:17 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:39:17 --> Upload Class Initialized
DEBUG - 2026-02-16 02:39:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:39:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:39:17 --> Encryption Class Initialized
INFO - 2026-02-16 02:39:17 --> Form Validation Class Initialized
INFO - 2026-02-16 02:39:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:39:17 --> Pagination Class Initialized
INFO - 2026-02-16 02:39:17 --> Email Class Initialized
INFO - 2026-02-16 02:39:17 --> Controller Class Initialized
ERROR - 2026-02-16 02:39:17 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:39:18 --> Upload Class Initialized
DEBUG - 2026-02-16 02:39:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:39:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:39:18 --> Encryption Class Initialized
INFO - 2026-02-16 02:39:18 --> Form Validation Class Initialized
INFO - 2026-02-16 02:39:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:39:18 --> Pagination Class Initialized
INFO - 2026-02-16 02:39:18 --> Email Class Initialized
INFO - 2026-02-16 02:39:18 --> Controller Class Initialized
DEBUG - 2026-02-16 02:39:18 --> Cart MX_Controller Initialized
INFO - 2026-02-16 02:39:18 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 02:39:18 --> Model "Auth_model" initialized
INFO - 2026-02-16 02:39:18 --> Model "Cart_model" initialized
INFO - 2026-02-16 02:39:18 --> Model "Common_model" initialized
INFO - 2026-02-16 02:39:18 --> Model "Order_model" initialized
INFO - 2026-02-16 02:39:18 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 02:39:18 --> Final output sent to browser
DEBUG - 2026-02-16 02:39:18 --> Total execution time: 2.3027
INFO - 2026-02-16 02:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:39:18 --> Upload Class Initialized
DEBUG - 2026-02-16 02:39:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:39:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:39:18 --> Encryption Class Initialized
INFO - 2026-02-16 02:39:18 --> Form Validation Class Initialized
INFO - 2026-02-16 02:39:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:39:18 --> Pagination Class Initialized
INFO - 2026-02-16 02:39:18 --> Email Class Initialized
INFO - 2026-02-16 02:39:18 --> Controller Class Initialized
ERROR - 2026-02-16 02:39:18 --> 404 Page Not Found: /index
INFO - 2026-02-16 02:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 02:39:18 --> Upload Class Initialized
DEBUG - 2026-02-16 02:39:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 02:39:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 02:39:18 --> Encryption Class Initialized
INFO - 2026-02-16 02:39:18 --> Form Validation Class Initialized
INFO - 2026-02-16 02:39:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 02:39:18 --> Pagination Class Initialized
INFO - 2026-02-16 02:39:18 --> Email Class Initialized
INFO - 2026-02-16 02:39:18 --> Controller Class Initialized
ERROR - 2026-02-16 02:39:18 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:12:12 --> Config Class Initialized
INFO - 2026-02-16 03:12:12 --> Hooks Class Initialized
DEBUG - 2026-02-16 03:12:12 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:12 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:12 --> URI Class Initialized
INFO - 2026-02-16 03:12:12 --> Router Class Initialized
INFO - 2026-02-16 03:12:12 --> Output Class Initialized
INFO - 2026-02-16 03:12:12 --> Security Class Initialized
DEBUG - 2026-02-16 03:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:12 --> CSRF cookie sent
INFO - 2026-02-16 03:12:12 --> CSRF token verified
INFO - 2026-02-16 03:12:12 --> Input Class Initialized
INFO - 2026-02-16 03:12:12 --> Language Class Initialized
INFO - 2026-02-16 03:12:12 --> Language Class Initialized
INFO - 2026-02-16 03:12:12 --> Config Class Initialized
INFO - 2026-02-16 03:12:12 --> Loader Class Initialized
INFO - 2026-02-16 03:12:12 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:12 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:12 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:12 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:12 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:12 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:12 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:12 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:12 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:12:14 --> Upload Class Initialized
DEBUG - 2026-02-16 03:12:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:14 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:14 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:14 --> Pagination Class Initialized
INFO - 2026-02-16 03:12:14 --> Email Class Initialized
INFO - 2026-02-16 03:12:14 --> Controller Class Initialized
DEBUG - 2026-02-16 03:12:14 --> Auth MX_Controller Initialized
INFO - 2026-02-16 03:12:14 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 03:12:14 --> Model "Auth_model" initialized
INFO - 2026-02-16 03:12:14 --> Model "Cart_model" initialized
INFO - 2026-02-16 03:12:14 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 03:12:17 --> Config Class Initialized
INFO - 2026-02-16 03:12:17 --> Hooks Class Initialized
DEBUG - 2026-02-16 03:12:17 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:17 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:17 --> URI Class Initialized
INFO - 2026-02-16 03:12:17 --> Router Class Initialized
INFO - 2026-02-16 03:12:17 --> Output Class Initialized
INFO - 2026-02-16 03:12:17 --> Security Class Initialized
DEBUG - 2026-02-16 03:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:17 --> CSRF cookie sent
INFO - 2026-02-16 03:12:17 --> Input Class Initialized
INFO - 2026-02-16 03:12:17 --> Language Class Initialized
INFO - 2026-02-16 03:12:17 --> Language Class Initialized
INFO - 2026-02-16 03:12:17 --> Config Class Initialized
INFO - 2026-02-16 03:12:17 --> Loader Class Initialized
INFO - 2026-02-16 03:12:17 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:17 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:17 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:17 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:17 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:17 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:17 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:17 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:17 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:12:19 --> Upload Class Initialized
DEBUG - 2026-02-16 03:12:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:19 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:19 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:19 --> Pagination Class Initialized
INFO - 2026-02-16 03:12:19 --> Email Class Initialized
INFO - 2026-02-16 03:12:19 --> Controller Class Initialized
DEBUG - 2026-02-16 03:12:19 --> Clientarea MX_Controller Initialized
INFO - 2026-02-16 03:12:19 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 03:12:19 --> Model "Auth_model" initialized
INFO - 2026-02-16 03:12:19 --> Model "Cart_model" initialized
INFO - 2026-02-16 03:12:19 --> Model "Clientarea_model" initialized
INFO - 2026-02-16 03:12:19 --> Model "Billing_model" initialized
INFO - 2026-02-16 03:12:19 --> Model "Common_model" initialized
INFO - 2026-02-16 03:12:19 --> Model "Order_model" initialized
INFO - 2026-02-16 03:12:19 --> Model "Support_model" initialized
DEBUG - 2026-02-16 03:12:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-16 03:12:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-16 03:12:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-16 03:12:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_index.php
INFO - 2026-02-16 03:12:20 --> Final output sent to browser
DEBUG - 2026-02-16 03:12:20 --> Total execution time: 2.4212
INFO - 2026-02-16 03:12:20 --> Config Class Initialized
INFO - 2026-02-16 03:12:20 --> Hooks Class Initialized
INFO - 2026-02-16 03:12:20 --> Config Class Initialized
DEBUG - 2026-02-16 03:12:20 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:20 --> Hooks Class Initialized
INFO - 2026-02-16 03:12:20 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:20 --> URI Class Initialized
DEBUG - 2026-02-16 03:12:20 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:20 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:20 --> Router Class Initialized
INFO - 2026-02-16 03:12:20 --> URI Class Initialized
INFO - 2026-02-16 03:12:20 --> Output Class Initialized
INFO - 2026-02-16 03:12:20 --> Security Class Initialized
INFO - 2026-02-16 03:12:20 --> Router Class Initialized
DEBUG - 2026-02-16 03:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:20 --> CSRF cookie sent
INFO - 2026-02-16 03:12:20 --> Input Class Initialized
INFO - 2026-02-16 03:12:20 --> Language Class Initialized
INFO - 2026-02-16 03:12:20 --> Language Class Initialized
INFO - 2026-02-16 03:12:20 --> Config Class Initialized
INFO - 2026-02-16 03:12:20 --> Output Class Initialized
INFO - 2026-02-16 03:12:20 --> Security Class Initialized
INFO - 2026-02-16 03:12:20 --> Loader Class Initialized
INFO - 2026-02-16 03:12:20 --> Helper loaded: url_helper
DEBUG - 2026-02-16 03:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:20 --> CSRF cookie sent
INFO - 2026-02-16 03:12:20 --> Input Class Initialized
INFO - 2026-02-16 03:12:20 --> Config Class Initialized
INFO - 2026-02-16 03:12:20 --> Hooks Class Initialized
INFO - 2026-02-16 03:12:20 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:20 --> Language Class Initialized
INFO - 2026-02-16 03:12:20 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:20 --> Language Class Initialized
INFO - 2026-02-16 03:12:20 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:20 --> Config Class Initialized
INFO - 2026-02-16 03:12:20 --> Helper loaded: email_helper
DEBUG - 2026-02-16 03:12:20 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:20 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:20 --> URI Class Initialized
INFO - 2026-02-16 03:12:20 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:20 --> Loader Class Initialized
INFO - 2026-02-16 03:12:20 --> Router Class Initialized
INFO - 2026-02-16 03:12:20 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:20 --> Output Class Initialized
INFO - 2026-02-16 03:12:20 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:20 --> Security Class Initialized
INFO - 2026-02-16 03:12:20 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: html_helper
DEBUG - 2026-02-16 03:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:20 --> CSRF cookie sent
INFO - 2026-02-16 03:12:20 --> Input Class Initialized
INFO - 2026-02-16 03:12:20 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:20 --> Language Class Initialized
INFO - 2026-02-16 03:12:20 --> Language Class Initialized
INFO - 2026-02-16 03:12:20 --> Config Class Initialized
INFO - 2026-02-16 03:12:20 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:20 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:20 --> Config Class Initialized
INFO - 2026-02-16 03:12:20 --> Hooks Class Initialized
INFO - 2026-02-16 03:12:20 --> Config Class Initialized
INFO - 2026-02-16 03:12:20 --> Hooks Class Initialized
INFO - 2026-02-16 03:12:20 --> Config Class Initialized
INFO - 2026-02-16 03:12:20 --> Hooks Class Initialized
INFO - 2026-02-16 03:12:20 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:20 --> Loader Class Initialized
DEBUG - 2026-02-16 03:12:20 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:20 --> Utf8 Class Initialized
DEBUG - 2026-02-16 03:12:20 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:20 --> Utf8 Class Initialized
DEBUG - 2026-02-16 03:12:20 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:20 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:20 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:20 --> URI Class Initialized
INFO - 2026-02-16 03:12:20 --> URI Class Initialized
INFO - 2026-02-16 03:12:20 --> URI Class Initialized
INFO - 2026-02-16 03:12:20 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:20 --> Router Class Initialized
INFO - 2026-02-16 03:12:20 --> Router Class Initialized
INFO - 2026-02-16 03:12:20 --> Router Class Initialized
INFO - 2026-02-16 03:12:20 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:20 --> Output Class Initialized
INFO - 2026-02-16 03:12:20 --> Output Class Initialized
INFO - 2026-02-16 03:12:20 --> Output Class Initialized
INFO - 2026-02-16 03:12:20 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:20 --> Security Class Initialized
INFO - 2026-02-16 03:12:20 --> Security Class Initialized
INFO - 2026-02-16 03:12:20 --> Security Class Initialized
DEBUG - 2026-02-16 03:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:20 --> CSRF cookie sent
INFO - 2026-02-16 03:12:20 --> Input Class Initialized
INFO - 2026-02-16 03:12:20 --> Language Class Initialized
DEBUG - 2026-02-16 03:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:20 --> CSRF cookie sent
INFO - 2026-02-16 03:12:20 --> Input Class Initialized
DEBUG - 2026-02-16 03:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:20 --> CSRF cookie sent
INFO - 2026-02-16 03:12:20 --> Input Class Initialized
INFO - 2026-02-16 03:12:20 --> Language Class Initialized
INFO - 2026-02-16 03:12:20 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:20 --> Language Class Initialized
INFO - 2026-02-16 03:12:20 --> Config Class Initialized
INFO - 2026-02-16 03:12:20 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:20 --> Language Class Initialized
INFO - 2026-02-16 03:12:20 --> Config Class Initialized
INFO - 2026-02-16 03:12:20 --> Language Class Initialized
INFO - 2026-02-16 03:12:20 --> Language Class Initialized
INFO - 2026-02-16 03:12:20 --> Config Class Initialized
INFO - 2026-02-16 03:12:20 --> Loader Class Initialized
INFO - 2026-02-16 03:12:20 --> Loader Class Initialized
INFO - 2026-02-16 03:12:20 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:20 --> Loader Class Initialized
INFO - 2026-02-16 03:12:20 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:20 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:20 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:20 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:20 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:20 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:20 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:12:22 --> Upload Class Initialized
DEBUG - 2026-02-16 03:12:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:22 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:22 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:22 --> Pagination Class Initialized
INFO - 2026-02-16 03:12:22 --> Email Class Initialized
INFO - 2026-02-16 03:12:22 --> Controller Class Initialized
ERROR - 2026-02-16 03:12:22 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:12:22 --> Upload Class Initialized
DEBUG - 2026-02-16 03:12:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:22 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:22 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:22 --> Pagination Class Initialized
INFO - 2026-02-16 03:12:22 --> Config Class Initialized
INFO - 2026-02-16 03:12:22 --> Hooks Class Initialized
DEBUG - 2026-02-16 03:12:22 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:22 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:22 --> Email Class Initialized
INFO - 2026-02-16 03:12:22 --> URI Class Initialized
INFO - 2026-02-16 03:12:22 --> Controller Class Initialized
ERROR - 2026-02-16 03:12:22 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:12:22 --> Router Class Initialized
INFO - 2026-02-16 03:12:22 --> Output Class Initialized
INFO - 2026-02-16 03:12:22 --> Upload Class Initialized
INFO - 2026-02-16 03:12:22 --> Security Class Initialized
DEBUG - 2026-02-16 03:12:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:22 --> Encryption Class Initialized
DEBUG - 2026-02-16 03:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:22 --> CSRF cookie sent
INFO - 2026-02-16 03:12:22 --> Input Class Initialized
INFO - 2026-02-16 03:12:22 --> Language Class Initialized
INFO - 2026-02-16 03:12:22 --> Language Class Initialized
INFO - 2026-02-16 03:12:22 --> Config Class Initialized
INFO - 2026-02-16 03:12:22 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:22 --> Pagination Class Initialized
INFO - 2026-02-16 03:12:22 --> Loader Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:22 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:22 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:22 --> Email Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:22 --> Controller Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: email_helper
ERROR - 2026-02-16 03:12:22 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:12:22 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:22 --> Config Class Initialized
INFO - 2026-02-16 03:12:22 --> Hooks Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: ssp_helper
DEBUG - 2026-02-16 03:12:22 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:22 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:22 --> Upload Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:22 --> URI Class Initialized
DEBUG - 2026-02-16 03:12:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:22 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:22 --> Router Class Initialized
INFO - 2026-02-16 03:12:22 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:22 --> Output Class Initialized
INFO - 2026-02-16 03:12:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:22 --> Pagination Class Initialized
INFO - 2026-02-16 03:12:22 --> Security Class Initialized
INFO - 2026-02-16 03:12:22 --> Database Driver Class Initialized
DEBUG - 2026-02-16 03:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:22 --> CSRF cookie sent
INFO - 2026-02-16 03:12:22 --> Input Class Initialized
INFO - 2026-02-16 03:12:22 --> Language Class Initialized
INFO - 2026-02-16 03:12:22 --> Language Class Initialized
INFO - 2026-02-16 03:12:22 --> Config Class Initialized
INFO - 2026-02-16 03:12:22 --> Email Class Initialized
INFO - 2026-02-16 03:12:22 --> Controller Class Initialized
ERROR - 2026-02-16 03:12:22 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:12:22 --> Loader Class Initialized
INFO - 2026-02-16 03:12:22 --> Config Class Initialized
INFO - 2026-02-16 03:12:22 --> Hooks Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:22 --> Upload Class Initialized
DEBUG - 2026-02-16 03:12:22 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:22 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:22 --> URI Class Initialized
DEBUG - 2026-02-16 03:12:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:22 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:22 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:22 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:22 --> Router Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:22 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:22 --> Output Class Initialized
INFO - 2026-02-16 03:12:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:22 --> Pagination Class Initialized
INFO - 2026-02-16 03:12:22 --> Security Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: cpanel_helper
DEBUG - 2026-02-16 03:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:22 --> Input Class Initialized
INFO - 2026-02-16 03:12:22 --> Language Class Initialized
INFO - 2026-02-16 03:12:22 --> Email Class Initialized
INFO - 2026-02-16 03:12:22 --> Controller Class Initialized
INFO - 2026-02-16 03:12:22 --> Config Class Initialized
INFO - 2026-02-16 03:12:22 --> Hooks Class Initialized
INFO - 2026-02-16 03:12:22 --> Language Class Initialized
INFO - 2026-02-16 03:12:22 --> Config Class Initialized
ERROR - 2026-02-16 03:12:22 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:12:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-02-16 03:12:22 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:22 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:22 --> URI Class Initialized
INFO - 2026-02-16 03:12:22 --> Loader Class Initialized
INFO - 2026-02-16 03:12:22 --> Upload Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:22 --> Router Class Initialized
DEBUG - 2026-02-16 03:12:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:22 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:22 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:22 --> Output Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:22 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:22 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:22 --> Security Class Initialized
INFO - 2026-02-16 03:12:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:22 --> Pagination Class Initialized
DEBUG - 2026-02-16 03:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:22 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:22 --> Input Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:22 --> Language Class Initialized
INFO - 2026-02-16 03:12:22 --> Language Class Initialized
INFO - 2026-02-16 03:12:22 --> Config Class Initialized
INFO - 2026-02-16 03:12:22 --> Email Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:22 --> Controller Class Initialized
ERROR - 2026-02-16 03:12:22 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:12:22 --> Loader Class Initialized
INFO - 2026-02-16 03:12:22 --> Config Class Initialized
INFO - 2026-02-16 03:12:22 --> Hooks Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: url_helper
DEBUG - 2026-02-16 03:12:22 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:22 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:22 --> URI Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:22 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:22 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:22 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:22 --> Router Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:22 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:22 --> Output Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:22 --> Security Class Initialized
DEBUG - 2026-02-16 03:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:22 --> Input Class Initialized
INFO - 2026-02-16 03:12:22 --> Language Class Initialized
INFO - 2026-02-16 03:12:22 --> Config Class Initialized
INFO - 2026-02-16 03:12:22 --> Hooks Class Initialized
INFO - 2026-02-16 03:12:22 --> Language Class Initialized
INFO - 2026-02-16 03:12:22 --> Config Class Initialized
DEBUG - 2026-02-16 03:12:22 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:22 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:22 --> URI Class Initialized
INFO - 2026-02-16 03:12:22 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:22 --> Loader Class Initialized
INFO - 2026-02-16 03:12:22 --> Router Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:22 --> Output Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:22 --> Security Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: html_helper
DEBUG - 2026-02-16 03:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:22 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:22 --> CSRF cookie sent
INFO - 2026-02-16 03:12:22 --> Input Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:22 --> Language Class Initialized
INFO - 2026-02-16 03:12:22 --> Language Class Initialized
INFO - 2026-02-16 03:12:22 --> Config Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:22 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:22 --> Loader Class Initialized
INFO - 2026-02-16 03:12:22 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:22 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:22 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:22 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:22 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:22 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:22 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:22 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:22 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:22 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:22 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:12:24 --> Upload Class Initialized
DEBUG - 2026-02-16 03:12:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:24 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:24 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:24 --> Pagination Class Initialized
INFO - 2026-02-16 03:12:24 --> Email Class Initialized
INFO - 2026-02-16 03:12:24 --> Controller Class Initialized
DEBUG - 2026-02-16 03:12:24 --> Cart MX_Controller Initialized
INFO - 2026-02-16 03:12:24 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 03:12:24 --> Model "Auth_model" initialized
INFO - 2026-02-16 03:12:24 --> Model "Cart_model" initialized
INFO - 2026-02-16 03:12:24 --> Model "Common_model" initialized
INFO - 2026-02-16 03:12:24 --> Model "Order_model" initialized
INFO - 2026-02-16 03:12:24 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 03:12:25 --> Final output sent to browser
DEBUG - 2026-02-16 03:12:25 --> Total execution time: 2.4453
INFO - 2026-02-16 03:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:12:25 --> Upload Class Initialized
DEBUG - 2026-02-16 03:12:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:25 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:25 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:25 --> Pagination Class Initialized
INFO - 2026-02-16 03:12:25 --> Email Class Initialized
INFO - 2026-02-16 03:12:25 --> Controller Class Initialized
DEBUG - 2026-02-16 03:12:25 --> Billing MX_Controller Initialized
INFO - 2026-02-16 03:12:25 --> Config Class Initialized
INFO - 2026-02-16 03:12:25 --> Hooks Class Initialized
INFO - 2026-02-16 03:12:25 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 03:12:25 --> Model "Auth_model" initialized
INFO - 2026-02-16 03:12:25 --> Model "Cart_model" initialized
INFO - 2026-02-16 03:12:25 --> Model "Billing_model" initialized
DEBUG - 2026-02-16 03:12:25 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:25 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:25 --> URI Class Initialized
INFO - 2026-02-16 03:12:25 --> Model "Common_model" initialized
INFO - 2026-02-16 03:12:25 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 03:12:25 --> Router Class Initialized
INFO - 2026-02-16 03:12:25 --> Output Class Initialized
INFO - 2026-02-16 03:12:25 --> Security Class Initialized
DEBUG - 2026-02-16 03:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:25 --> CSRF cookie sent
INFO - 2026-02-16 03:12:25 --> Input Class Initialized
INFO - 2026-02-16 03:12:25 --> Language Class Initialized
INFO - 2026-02-16 03:12:25 --> Language Class Initialized
INFO - 2026-02-16 03:12:25 --> Config Class Initialized
INFO - 2026-02-16 03:12:25 --> Loader Class Initialized
INFO - 2026-02-16 03:12:25 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:25 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:25 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:25 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:25 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:25 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:25 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:25 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:25 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:25 --> Final output sent to browser
DEBUG - 2026-02-16 03:12:25 --> Total execution time: 3.2520
INFO - 2026-02-16 03:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:12:25 --> Upload Class Initialized
DEBUG - 2026-02-16 03:12:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:25 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:25 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:25 --> Pagination Class Initialized
INFO - 2026-02-16 03:12:25 --> Email Class Initialized
INFO - 2026-02-16 03:12:25 --> Controller Class Initialized
DEBUG - 2026-02-16 03:12:25 --> Tickets MX_Controller Initialized
INFO - 2026-02-16 03:12:25 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 03:12:25 --> Model "Auth_model" initialized
INFO - 2026-02-16 03:12:25 --> Model "Cart_model" initialized
INFO - 2026-02-16 03:12:25 --> Model "Support_model" initialized
INFO - 2026-02-16 03:12:25 --> Model "Common_model" initialized
INFO - 2026-02-16 03:12:26 --> Final output sent to browser
DEBUG - 2026-02-16 03:12:26 --> Total execution time: 3.9099
INFO - 2026-02-16 03:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:12:26 --> Upload Class Initialized
DEBUG - 2026-02-16 03:12:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:26 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:26 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:26 --> Pagination Class Initialized
INFO - 2026-02-16 03:12:26 --> Email Class Initialized
INFO - 2026-02-16 03:12:26 --> Controller Class Initialized
DEBUG - 2026-02-16 03:12:26 --> Billing MX_Controller Initialized
INFO - 2026-02-16 03:12:26 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 03:12:26 --> Model "Auth_model" initialized
INFO - 2026-02-16 03:12:26 --> Model "Cart_model" initialized
INFO - 2026-02-16 03:12:26 --> Model "Billing_model" initialized
INFO - 2026-02-16 03:12:26 --> Model "Common_model" initialized
INFO - 2026-02-16 03:12:26 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-16 03:12:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-16 03:12:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-02-16 03:12:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-16 03:12:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-16 03:12:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_invoices.php
INFO - 2026-02-16 03:12:27 --> Final output sent to browser
DEBUG - 2026-02-16 03:12:27 --> Total execution time: 5.1151
INFO - 2026-02-16 03:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:12:27 --> Upload Class Initialized
DEBUG - 2026-02-16 03:12:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:27 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:27 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:27 --> Pagination Class Initialized
INFO - 2026-02-16 03:12:27 --> Email Class Initialized
INFO - 2026-02-16 03:12:27 --> Controller Class Initialized
DEBUG - 2026-02-16 03:12:27 --> Clientarea MX_Controller Initialized
INFO - 2026-02-16 03:12:27 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 03:12:27 --> Model "Auth_model" initialized
INFO - 2026-02-16 03:12:27 --> Model "Cart_model" initialized
INFO - 2026-02-16 03:12:27 --> Model "Clientarea_model" initialized
INFO - 2026-02-16 03:12:27 --> Model "Billing_model" initialized
INFO - 2026-02-16 03:12:27 --> Model "Common_model" initialized
INFO - 2026-02-16 03:12:27 --> Model "Order_model" initialized
INFO - 2026-02-16 03:12:27 --> Model "Support_model" initialized
INFO - 2026-02-16 03:12:27 --> Config Class Initialized
INFO - 2026-02-16 03:12:27 --> Hooks Class Initialized
INFO - 2026-02-16 03:12:27 --> Config Class Initialized
INFO - 2026-02-16 03:12:27 --> Hooks Class Initialized
DEBUG - 2026-02-16 03:12:27 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:27 --> Utf8 Class Initialized
DEBUG - 2026-02-16 03:12:27 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:27 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:27 --> Config Class Initialized
INFO - 2026-02-16 03:12:27 --> Hooks Class Initialized
INFO - 2026-02-16 03:12:27 --> URI Class Initialized
INFO - 2026-02-16 03:12:27 --> URI Class Initialized
DEBUG - 2026-02-16 03:12:27 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:27 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:27 --> URI Class Initialized
INFO - 2026-02-16 03:12:27 --> Router Class Initialized
INFO - 2026-02-16 03:12:27 --> Router Class Initialized
INFO - 2026-02-16 03:12:27 --> Router Class Initialized
INFO - 2026-02-16 03:12:27 --> Output Class Initialized
INFO - 2026-02-16 03:12:27 --> Output Class Initialized
INFO - 2026-02-16 03:12:27 --> Output Class Initialized
INFO - 2026-02-16 03:12:27 --> Security Class Initialized
INFO - 2026-02-16 03:12:27 --> Security Class Initialized
DEBUG - 2026-02-16 03:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:27 --> Security Class Initialized
INFO - 2026-02-16 03:12:27 --> CSRF cookie sent
INFO - 2026-02-16 03:12:27 --> Input Class Initialized
INFO - 2026-02-16 03:12:27 --> Language Class Initialized
DEBUG - 2026-02-16 03:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:27 --> CSRF cookie sent
INFO - 2026-02-16 03:12:27 --> Input Class Initialized
INFO - 2026-02-16 03:12:27 --> Language Class Initialized
INFO - 2026-02-16 03:12:27 --> Config Class Initialized
DEBUG - 2026-02-16 03:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:27 --> CSRF cookie sent
INFO - 2026-02-16 03:12:27 --> Input Class Initialized
INFO - 2026-02-16 03:12:27 --> Language Class Initialized
INFO - 2026-02-16 03:12:27 --> Language Class Initialized
INFO - 2026-02-16 03:12:27 --> Language Class Initialized
INFO - 2026-02-16 03:12:27 --> Config Class Initialized
INFO - 2026-02-16 03:12:27 --> Language Class Initialized
INFO - 2026-02-16 03:12:27 --> Config Class Initialized
INFO - 2026-02-16 03:12:27 --> Loader Class Initialized
INFO - 2026-02-16 03:12:27 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:27 --> Loader Class Initialized
INFO - 2026-02-16 03:12:27 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:27 --> Loader Class Initialized
INFO - 2026-02-16 03:12:27 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:27 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:27 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:27 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:27 --> Config Class Initialized
INFO - 2026-02-16 03:12:27 --> Hooks Class Initialized
DEBUG - 2026-02-16 03:12:27 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:27 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:27 --> URI Class Initialized
INFO - 2026-02-16 03:12:27 --> Router Class Initialized
INFO - 2026-02-16 03:12:27 --> Output Class Initialized
INFO - 2026-02-16 03:12:27 --> Security Class Initialized
DEBUG - 2026-02-16 03:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:27 --> CSRF cookie sent
INFO - 2026-02-16 03:12:27 --> Input Class Initialized
INFO - 2026-02-16 03:12:27 --> Language Class Initialized
INFO - 2026-02-16 03:12:27 --> Language Class Initialized
INFO - 2026-02-16 03:12:27 --> Config Class Initialized
INFO - 2026-02-16 03:12:27 --> Loader Class Initialized
INFO - 2026-02-16 03:12:27 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:27 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:27 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:28 --> Final output sent to browser
DEBUG - 2026-02-16 03:12:28 --> Total execution time: 5.9223
INFO - 2026-02-16 03:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:12:28 --> Upload Class Initialized
DEBUG - 2026-02-16 03:12:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:28 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:28 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:28 --> Pagination Class Initialized
INFO - 2026-02-16 03:12:28 --> Email Class Initialized
INFO - 2026-02-16 03:12:28 --> Controller Class Initialized
ERROR - 2026-02-16 03:12:28 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:12:28 --> Upload Class Initialized
DEBUG - 2026-02-16 03:12:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:28 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:28 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:28 --> Pagination Class Initialized
INFO - 2026-02-16 03:12:28 --> Config Class Initialized
INFO - 2026-02-16 03:12:28 --> Hooks Class Initialized
INFO - 2026-02-16 03:12:28 --> Email Class Initialized
INFO - 2026-02-16 03:12:28 --> Controller Class Initialized
ERROR - 2026-02-16 03:12:28 --> 404 Page Not Found: /index
DEBUG - 2026-02-16 03:12:28 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:28 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:28 --> URI Class Initialized
INFO - 2026-02-16 03:12:28 --> Router Class Initialized
INFO - 2026-02-16 03:12:28 --> Output Class Initialized
INFO - 2026-02-16 03:12:28 --> Security Class Initialized
DEBUG - 2026-02-16 03:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:28 --> CSRF cookie sent
INFO - 2026-02-16 03:12:28 --> Input Class Initialized
INFO - 2026-02-16 03:12:28 --> Language Class Initialized
INFO - 2026-02-16 03:12:28 --> Language Class Initialized
INFO - 2026-02-16 03:12:28 --> Config Class Initialized
INFO - 2026-02-16 03:12:28 --> Config Class Initialized
INFO - 2026-02-16 03:12:28 --> Hooks Class Initialized
INFO - 2026-02-16 03:12:28 --> Loader Class Initialized
DEBUG - 2026-02-16 03:12:28 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:28 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:28 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:28 --> URI Class Initialized
INFO - 2026-02-16 03:12:28 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:28 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:28 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:28 --> Router Class Initialized
INFO - 2026-02-16 03:12:28 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:28 --> Output Class Initialized
INFO - 2026-02-16 03:12:28 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:28 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:28 --> Security Class Initialized
INFO - 2026-02-16 03:12:28 --> Helper loaded: cpanel_helper
DEBUG - 2026-02-16 03:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:28 --> CSRF cookie sent
INFO - 2026-02-16 03:12:28 --> Input Class Initialized
INFO - 2026-02-16 03:12:28 --> Language Class Initialized
INFO - 2026-02-16 03:12:28 --> Language Class Initialized
INFO - 2026-02-16 03:12:28 --> Config Class Initialized
INFO - 2026-02-16 03:12:28 --> Loader Class Initialized
INFO - 2026-02-16 03:12:28 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:28 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:28 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:28 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:28 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:28 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:28 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:28 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:28 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:28 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:12:29 --> Upload Class Initialized
DEBUG - 2026-02-16 03:12:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:29 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:29 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:29 --> Pagination Class Initialized
INFO - 2026-02-16 03:12:29 --> Email Class Initialized
INFO - 2026-02-16 03:12:29 --> Controller Class Initialized
ERROR - 2026-02-16 03:12:29 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:12:29 --> Upload Class Initialized
DEBUG - 2026-02-16 03:12:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:29 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:29 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:29 --> Pagination Class Initialized
INFO - 2026-02-16 03:12:29 --> Email Class Initialized
INFO - 2026-02-16 03:12:29 --> Controller Class Initialized
ERROR - 2026-02-16 03:12:29 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:12:29 --> Config Class Initialized
INFO - 2026-02-16 03:12:29 --> Hooks Class Initialized
DEBUG - 2026-02-16 03:12:29 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:29 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:29 --> URI Class Initialized
INFO - 2026-02-16 03:12:29 --> Router Class Initialized
INFO - 2026-02-16 03:12:29 --> Output Class Initialized
INFO - 2026-02-16 03:12:29 --> Security Class Initialized
DEBUG - 2026-02-16 03:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:29 --> CSRF cookie sent
INFO - 2026-02-16 03:12:29 --> Input Class Initialized
INFO - 2026-02-16 03:12:29 --> Language Class Initialized
INFO - 2026-02-16 03:12:29 --> Config Class Initialized
INFO - 2026-02-16 03:12:29 --> Hooks Class Initialized
INFO - 2026-02-16 03:12:29 --> Language Class Initialized
INFO - 2026-02-16 03:12:29 --> Config Class Initialized
DEBUG - 2026-02-16 03:12:29 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:29 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:29 --> URI Class Initialized
INFO - 2026-02-16 03:12:29 --> Loader Class Initialized
INFO - 2026-02-16 03:12:29 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:29 --> Router Class Initialized
INFO - 2026-02-16 03:12:29 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:29 --> Output Class Initialized
INFO - 2026-02-16 03:12:29 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:29 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:29 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:29 --> Security Class Initialized
INFO - 2026-02-16 03:12:29 --> Helper loaded: whmaz_helper
DEBUG - 2026-02-16 03:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:29 --> CSRF cookie sent
INFO - 2026-02-16 03:12:29 --> Input Class Initialized
INFO - 2026-02-16 03:12:29 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:29 --> Language Class Initialized
INFO - 2026-02-16 03:12:29 --> Language Class Initialized
INFO - 2026-02-16 03:12:29 --> Config Class Initialized
INFO - 2026-02-16 03:12:29 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:29 --> Loader Class Initialized
INFO - 2026-02-16 03:12:29 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:29 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:29 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:29 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:29 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:29 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:29 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:29 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:29 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:29 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:12:30 --> Upload Class Initialized
DEBUG - 2026-02-16 03:12:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:30 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:30 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:30 --> Pagination Class Initialized
INFO - 2026-02-16 03:12:30 --> Email Class Initialized
INFO - 2026-02-16 03:12:30 --> Controller Class Initialized
ERROR - 2026-02-16 03:12:30 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:12:30 --> Upload Class Initialized
DEBUG - 2026-02-16 03:12:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:30 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:30 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:30 --> Pagination Class Initialized
INFO - 2026-02-16 03:12:30 --> Config Class Initialized
INFO - 2026-02-16 03:12:30 --> Hooks Class Initialized
INFO - 2026-02-16 03:12:30 --> Email Class Initialized
INFO - 2026-02-16 03:12:30 --> Controller Class Initialized
ERROR - 2026-02-16 03:12:30 --> 404 Page Not Found: /index
DEBUG - 2026-02-16 03:12:30 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:30 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:30 --> URI Class Initialized
INFO - 2026-02-16 03:12:30 --> Router Class Initialized
INFO - 2026-02-16 03:12:30 --> Output Class Initialized
INFO - 2026-02-16 03:12:30 --> Security Class Initialized
DEBUG - 2026-02-16 03:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:30 --> CSRF cookie sent
INFO - 2026-02-16 03:12:30 --> Input Class Initialized
INFO - 2026-02-16 03:12:30 --> Language Class Initialized
INFO - 2026-02-16 03:12:30 --> Language Class Initialized
INFO - 2026-02-16 03:12:30 --> Config Class Initialized
INFO - 2026-02-16 03:12:30 --> Loader Class Initialized
INFO - 2026-02-16 03:12:30 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:30 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:30 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:30 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:30 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:30 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:30 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:30 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:30 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:12:31 --> Upload Class Initialized
DEBUG - 2026-02-16 03:12:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:31 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:31 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:31 --> Pagination Class Initialized
INFO - 2026-02-16 03:12:31 --> Email Class Initialized
INFO - 2026-02-16 03:12:31 --> Controller Class Initialized
DEBUG - 2026-02-16 03:12:31 --> Cart MX_Controller Initialized
INFO - 2026-02-16 03:12:31 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 03:12:31 --> Model "Auth_model" initialized
INFO - 2026-02-16 03:12:31 --> Model "Cart_model" initialized
INFO - 2026-02-16 03:12:31 --> Model "Common_model" initialized
INFO - 2026-02-16 03:12:31 --> Model "Order_model" initialized
INFO - 2026-02-16 03:12:31 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 03:12:31 --> Final output sent to browser
DEBUG - 2026-02-16 03:12:31 --> Total execution time: 3.1553
INFO - 2026-02-16 03:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:12:31 --> Upload Class Initialized
DEBUG - 2026-02-16 03:12:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:31 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:31 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:31 --> Pagination Class Initialized
INFO - 2026-02-16 03:12:31 --> Email Class Initialized
INFO - 2026-02-16 03:12:31 --> Controller Class Initialized
ERROR - 2026-02-16 03:12:31 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:12:31 --> Upload Class Initialized
DEBUG - 2026-02-16 03:12:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:31 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:31 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:31 --> Pagination Class Initialized
INFO - 2026-02-16 03:12:31 --> Email Class Initialized
INFO - 2026-02-16 03:12:31 --> Controller Class Initialized
ERROR - 2026-02-16 03:12:31 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:12:32 --> Upload Class Initialized
DEBUG - 2026-02-16 03:12:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:32 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:32 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:32 --> Pagination Class Initialized
INFO - 2026-02-16 03:12:32 --> Email Class Initialized
INFO - 2026-02-16 03:12:32 --> Controller Class Initialized
ERROR - 2026-02-16 03:12:32 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:12:33 --> Upload Class Initialized
DEBUG - 2026-02-16 03:12:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:33 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:33 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:33 --> Pagination Class Initialized
INFO - 2026-02-16 03:12:33 --> Email Class Initialized
INFO - 2026-02-16 03:12:33 --> Controller Class Initialized
ERROR - 2026-02-16 03:12:33 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:12:52 --> Config Class Initialized
INFO - 2026-02-16 03:12:52 --> Hooks Class Initialized
DEBUG - 2026-02-16 03:12:52 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:52 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:52 --> URI Class Initialized
INFO - 2026-02-16 03:12:52 --> Router Class Initialized
INFO - 2026-02-16 03:12:52 --> Output Class Initialized
INFO - 2026-02-16 03:12:52 --> Security Class Initialized
DEBUG - 2026-02-16 03:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:52 --> CSRF cookie sent
INFO - 2026-02-16 03:12:52 --> Input Class Initialized
INFO - 2026-02-16 03:12:52 --> Language Class Initialized
INFO - 2026-02-16 03:12:52 --> Language Class Initialized
INFO - 2026-02-16 03:12:52 --> Config Class Initialized
INFO - 2026-02-16 03:12:52 --> Loader Class Initialized
INFO - 2026-02-16 03:12:52 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:52 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:52 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:52 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:52 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:52 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:52 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:52 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:52 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:12:54 --> Upload Class Initialized
DEBUG - 2026-02-16 03:12:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:54 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:54 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:54 --> Pagination Class Initialized
INFO - 2026-02-16 03:12:54 --> Email Class Initialized
INFO - 2026-02-16 03:12:54 --> Controller Class Initialized
DEBUG - 2026-02-16 03:12:54 --> Pay MX_Controller Initialized
INFO - 2026-02-16 03:12:54 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 03:12:54 --> Model "Auth_model" initialized
INFO - 2026-02-16 03:12:54 --> Model "Cart_model" initialized
INFO - 2026-02-16 03:12:54 --> Model "Payment_model" initialized
INFO - 2026-02-16 03:12:54 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-16 03:12:54 --> Model "Billing_model" initialized
INFO - 2026-02-16 03:12:54 --> Model "Invoice_model" initialized
DEBUG - 2026-02-16 03:12:57 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-16 03:12:57 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-16 03:12:57 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-16 03:12:57 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_pay.php
INFO - 2026-02-16 03:12:57 --> Final output sent to browser
DEBUG - 2026-02-16 03:12:57 --> Total execution time: 4.4433
INFO - 2026-02-16 03:12:57 --> Config Class Initialized
INFO - 2026-02-16 03:12:57 --> Hooks Class Initialized
DEBUG - 2026-02-16 03:12:57 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:57 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:57 --> Config Class Initialized
INFO - 2026-02-16 03:12:57 --> Hooks Class Initialized
INFO - 2026-02-16 03:12:57 --> URI Class Initialized
DEBUG - 2026-02-16 03:12:57 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:57 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:57 --> Router Class Initialized
INFO - 2026-02-16 03:12:57 --> URI Class Initialized
INFO - 2026-02-16 03:12:57 --> Output Class Initialized
INFO - 2026-02-16 03:12:57 --> Security Class Initialized
INFO - 2026-02-16 03:12:57 --> Router Class Initialized
DEBUG - 2026-02-16 03:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:57 --> CSRF cookie sent
INFO - 2026-02-16 03:12:57 --> Input Class Initialized
INFO - 2026-02-16 03:12:57 --> Language Class Initialized
INFO - 2026-02-16 03:12:57 --> Output Class Initialized
INFO - 2026-02-16 03:12:57 --> Language Class Initialized
INFO - 2026-02-16 03:12:57 --> Config Class Initialized
INFO - 2026-02-16 03:12:57 --> Security Class Initialized
DEBUG - 2026-02-16 03:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:57 --> CSRF cookie sent
INFO - 2026-02-16 03:12:57 --> Input Class Initialized
INFO - 2026-02-16 03:12:57 --> Language Class Initialized
INFO - 2026-02-16 03:12:57 --> Loader Class Initialized
INFO - 2026-02-16 03:12:57 --> Language Class Initialized
INFO - 2026-02-16 03:12:57 --> Config Class Initialized
INFO - 2026-02-16 03:12:57 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:57 --> Loader Class Initialized
INFO - 2026-02-16 03:12:57 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:57 --> Config Class Initialized
INFO - 2026-02-16 03:12:57 --> Hooks Class Initialized
INFO - 2026-02-16 03:12:57 --> Database Driver Class Initialized
DEBUG - 2026-02-16 03:12:57 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:57 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:57 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:57 --> URI Class Initialized
INFO - 2026-02-16 03:12:57 --> Router Class Initialized
INFO - 2026-02-16 03:12:57 --> Output Class Initialized
INFO - 2026-02-16 03:12:57 --> Security Class Initialized
DEBUG - 2026-02-16 03:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:57 --> CSRF cookie sent
INFO - 2026-02-16 03:12:57 --> Input Class Initialized
INFO - 2026-02-16 03:12:57 --> Language Class Initialized
INFO - 2026-02-16 03:12:57 --> Language Class Initialized
INFO - 2026-02-16 03:12:57 --> Config Class Initialized
INFO - 2026-02-16 03:12:57 --> Loader Class Initialized
INFO - 2026-02-16 03:12:57 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:57 --> Config Class Initialized
INFO - 2026-02-16 03:12:57 --> Hooks Class Initialized
INFO - 2026-02-16 03:12:57 --> Config Class Initialized
INFO - 2026-02-16 03:12:57 --> Config Class Initialized
INFO - 2026-02-16 03:12:57 --> Hooks Class Initialized
INFO - 2026-02-16 03:12:57 --> Hooks Class Initialized
DEBUG - 2026-02-16 03:12:57 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:57 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:57 --> Database Driver Class Initialized
DEBUG - 2026-02-16 03:12:57 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:57 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:57 --> URI Class Initialized
DEBUG - 2026-02-16 03:12:57 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:57 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:57 --> URI Class Initialized
INFO - 2026-02-16 03:12:57 --> URI Class Initialized
INFO - 2026-02-16 03:12:57 --> Router Class Initialized
INFO - 2026-02-16 03:12:57 --> Router Class Initialized
INFO - 2026-02-16 03:12:57 --> Router Class Initialized
INFO - 2026-02-16 03:12:57 --> Output Class Initialized
INFO - 2026-02-16 03:12:57 --> Output Class Initialized
INFO - 2026-02-16 03:12:57 --> Output Class Initialized
INFO - 2026-02-16 03:12:57 --> Security Class Initialized
INFO - 2026-02-16 03:12:57 --> Security Class Initialized
DEBUG - 2026-02-16 03:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:57 --> CSRF cookie sent
INFO - 2026-02-16 03:12:57 --> Input Class Initialized
DEBUG - 2026-02-16 03:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:57 --> CSRF cookie sent
INFO - 2026-02-16 03:12:57 --> Security Class Initialized
INFO - 2026-02-16 03:12:57 --> Input Class Initialized
INFO - 2026-02-16 03:12:57 --> Language Class Initialized
INFO - 2026-02-16 03:12:57 --> Language Class Initialized
INFO - 2026-02-16 03:12:57 --> Language Class Initialized
INFO - 2026-02-16 03:12:57 --> Config Class Initialized
INFO - 2026-02-16 03:12:57 --> Language Class Initialized
INFO - 2026-02-16 03:12:57 --> Config Class Initialized
DEBUG - 2026-02-16 03:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:57 --> CSRF cookie sent
INFO - 2026-02-16 03:12:57 --> Input Class Initialized
INFO - 2026-02-16 03:12:57 --> Language Class Initialized
INFO - 2026-02-16 03:12:57 --> Language Class Initialized
INFO - 2026-02-16 03:12:57 --> Config Class Initialized
INFO - 2026-02-16 03:12:57 --> Loader Class Initialized
INFO - 2026-02-16 03:12:57 --> Loader Class Initialized
INFO - 2026-02-16 03:12:57 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:57 --> Loader Class Initialized
INFO - 2026-02-16 03:12:57 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:57 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:57 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:57 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:57 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:12:59 --> Upload Class Initialized
DEBUG - 2026-02-16 03:12:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:59 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:59 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:59 --> Pagination Class Initialized
INFO - 2026-02-16 03:12:59 --> Email Class Initialized
INFO - 2026-02-16 03:12:59 --> Controller Class Initialized
ERROR - 2026-02-16 03:12:59 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:12:59 --> Upload Class Initialized
DEBUG - 2026-02-16 03:12:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:59 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:59 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:59 --> Pagination Class Initialized
INFO - 2026-02-16 03:12:59 --> Config Class Initialized
INFO - 2026-02-16 03:12:59 --> Hooks Class Initialized
INFO - 2026-02-16 03:12:59 --> Email Class Initialized
INFO - 2026-02-16 03:12:59 --> Controller Class Initialized
ERROR - 2026-02-16 03:12:59 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:12:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-02-16 03:12:59 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:59 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:59 --> URI Class Initialized
INFO - 2026-02-16 03:12:59 --> Upload Class Initialized
INFO - 2026-02-16 03:12:59 --> Router Class Initialized
DEBUG - 2026-02-16 03:12:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:12:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:12:59 --> Encryption Class Initialized
INFO - 2026-02-16 03:12:59 --> Output Class Initialized
INFO - 2026-02-16 03:12:59 --> Form Validation Class Initialized
INFO - 2026-02-16 03:12:59 --> Security Class Initialized
INFO - 2026-02-16 03:12:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:12:59 --> Pagination Class Initialized
DEBUG - 2026-02-16 03:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:59 --> CSRF cookie sent
INFO - 2026-02-16 03:12:59 --> Input Class Initialized
INFO - 2026-02-16 03:12:59 --> Language Class Initialized
INFO - 2026-02-16 03:12:59 --> Language Class Initialized
INFO - 2026-02-16 03:12:59 --> Config Class Initialized
INFO - 2026-02-16 03:12:59 --> Email Class Initialized
INFO - 2026-02-16 03:12:59 --> Controller Class Initialized
ERROR - 2026-02-16 03:12:59 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:12:59 --> Config Class Initialized
INFO - 2026-02-16 03:12:59 --> Hooks Class Initialized
INFO - 2026-02-16 03:12:59 --> Loader Class Initialized
INFO - 2026-02-16 03:12:59 --> Helper loaded: url_helper
DEBUG - 2026-02-16 03:12:59 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:59 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:59 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:59 --> URI Class Initialized
INFO - 2026-02-16 03:12:59 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:59 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:59 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:59 --> Router Class Initialized
INFO - 2026-02-16 03:12:59 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:59 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:59 --> Output Class Initialized
INFO - 2026-02-16 03:12:59 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:59 --> Security Class Initialized
DEBUG - 2026-02-16 03:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:59 --> CSRF cookie sent
INFO - 2026-02-16 03:12:59 --> Input Class Initialized
INFO - 2026-02-16 03:12:59 --> Language Class Initialized
INFO - 2026-02-16 03:12:59 --> Language Class Initialized
INFO - 2026-02-16 03:12:59 --> Config Class Initialized
INFO - 2026-02-16 03:12:59 --> Config Class Initialized
INFO - 2026-02-16 03:12:59 --> Hooks Class Initialized
DEBUG - 2026-02-16 03:12:59 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:12:59 --> Utf8 Class Initialized
INFO - 2026-02-16 03:12:59 --> Loader Class Initialized
INFO - 2026-02-16 03:12:59 --> URI Class Initialized
INFO - 2026-02-16 03:12:59 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:59 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:59 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:59 --> Router Class Initialized
INFO - 2026-02-16 03:12:59 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:59 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:59 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:59 --> Output Class Initialized
INFO - 2026-02-16 03:12:59 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:59 --> Security Class Initialized
INFO - 2026-02-16 03:12:59 --> Helper loaded: ssp_helper
DEBUG - 2026-02-16 03:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:12:59 --> CSRF cookie sent
INFO - 2026-02-16 03:12:59 --> Input Class Initialized
INFO - 2026-02-16 03:12:59 --> Language Class Initialized
INFO - 2026-02-16 03:12:59 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:59 --> Language Class Initialized
INFO - 2026-02-16 03:12:59 --> Config Class Initialized
INFO - 2026-02-16 03:12:59 --> Loader Class Initialized
INFO - 2026-02-16 03:12:59 --> Helper loaded: url_helper
INFO - 2026-02-16 03:12:59 --> Helper loaded: form_helper
INFO - 2026-02-16 03:12:59 --> Helper loaded: html_helper
INFO - 2026-02-16 03:12:59 --> Helper loaded: file_helper
INFO - 2026-02-16 03:12:59 --> Database Driver Class Initialized
INFO - 2026-02-16 03:12:59 --> Helper loaded: email_helper
INFO - 2026-02-16 03:12:59 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:12:59 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:12:59 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:12:59 --> Database Driver Class Initialized
INFO - 2026-02-16 03:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:13:00 --> Upload Class Initialized
DEBUG - 2026-02-16 03:13:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:13:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:13:00 --> Encryption Class Initialized
INFO - 2026-02-16 03:13:00 --> Form Validation Class Initialized
INFO - 2026-02-16 03:13:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:13:00 --> Pagination Class Initialized
INFO - 2026-02-16 03:13:00 --> Email Class Initialized
INFO - 2026-02-16 03:13:00 --> Controller Class Initialized
ERROR - 2026-02-16 03:13:00 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:13:00 --> Upload Class Initialized
DEBUG - 2026-02-16 03:13:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:13:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:13:00 --> Encryption Class Initialized
INFO - 2026-02-16 03:13:00 --> Form Validation Class Initialized
INFO - 2026-02-16 03:13:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:13:00 --> Pagination Class Initialized
INFO - 2026-02-16 03:13:00 --> Email Class Initialized
INFO - 2026-02-16 03:13:00 --> Controller Class Initialized
ERROR - 2026-02-16 03:13:00 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:13:00 --> Upload Class Initialized
DEBUG - 2026-02-16 03:13:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:13:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:13:00 --> Encryption Class Initialized
INFO - 2026-02-16 03:13:00 --> Form Validation Class Initialized
INFO - 2026-02-16 03:13:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:13:00 --> Pagination Class Initialized
INFO - 2026-02-16 03:13:00 --> Email Class Initialized
INFO - 2026-02-16 03:13:00 --> Controller Class Initialized
ERROR - 2026-02-16 03:13:00 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:13:01 --> Upload Class Initialized
DEBUG - 2026-02-16 03:13:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:13:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:13:01 --> Encryption Class Initialized
INFO - 2026-02-16 03:13:01 --> Form Validation Class Initialized
INFO - 2026-02-16 03:13:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:13:01 --> Pagination Class Initialized
INFO - 2026-02-16 03:13:01 --> Email Class Initialized
INFO - 2026-02-16 03:13:01 --> Controller Class Initialized
ERROR - 2026-02-16 03:13:01 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:13:01 --> Upload Class Initialized
DEBUG - 2026-02-16 03:13:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:13:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:13:01 --> Encryption Class Initialized
INFO - 2026-02-16 03:13:01 --> Form Validation Class Initialized
INFO - 2026-02-16 03:13:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:13:01 --> Pagination Class Initialized
INFO - 2026-02-16 03:13:01 --> Email Class Initialized
INFO - 2026-02-16 03:13:01 --> Controller Class Initialized
ERROR - 2026-02-16 03:13:01 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:13:01 --> Upload Class Initialized
DEBUG - 2026-02-16 03:13:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:13:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:13:01 --> Encryption Class Initialized
INFO - 2026-02-16 03:13:01 --> Form Validation Class Initialized
INFO - 2026-02-16 03:13:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:13:01 --> Pagination Class Initialized
INFO - 2026-02-16 03:13:01 --> Email Class Initialized
INFO - 2026-02-16 03:13:01 --> Controller Class Initialized
DEBUG - 2026-02-16 03:13:01 --> Cart MX_Controller Initialized
INFO - 2026-02-16 03:13:01 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 03:13:01 --> Model "Auth_model" initialized
INFO - 2026-02-16 03:13:01 --> Model "Cart_model" initialized
INFO - 2026-02-16 03:13:01 --> Model "Common_model" initialized
INFO - 2026-02-16 03:13:01 --> Model "Order_model" initialized
INFO - 2026-02-16 03:13:01 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 03:13:01 --> Final output sent to browser
DEBUG - 2026-02-16 03:13:01 --> Total execution time: 2.4400
INFO - 2026-02-16 03:13:05 --> Config Class Initialized
INFO - 2026-02-16 03:13:05 --> Hooks Class Initialized
DEBUG - 2026-02-16 03:13:05 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:13:05 --> Utf8 Class Initialized
INFO - 2026-02-16 03:13:05 --> URI Class Initialized
INFO - 2026-02-16 03:13:05 --> Router Class Initialized
INFO - 2026-02-16 03:13:05 --> Output Class Initialized
INFO - 2026-02-16 03:13:05 --> Security Class Initialized
DEBUG - 2026-02-16 03:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:13:05 --> CSRF cookie sent
INFO - 2026-02-16 03:13:05 --> CSRF token verified
INFO - 2026-02-16 03:13:05 --> Input Class Initialized
INFO - 2026-02-16 03:13:05 --> Language Class Initialized
INFO - 2026-02-16 03:13:05 --> Language Class Initialized
INFO - 2026-02-16 03:13:05 --> Config Class Initialized
INFO - 2026-02-16 03:13:05 --> Loader Class Initialized
INFO - 2026-02-16 03:13:05 --> Helper loaded: url_helper
INFO - 2026-02-16 03:13:05 --> Helper loaded: form_helper
INFO - 2026-02-16 03:13:05 --> Helper loaded: html_helper
INFO - 2026-02-16 03:13:05 --> Helper loaded: file_helper
INFO - 2026-02-16 03:13:05 --> Helper loaded: email_helper
INFO - 2026-02-16 03:13:05 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:13:05 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:13:05 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:13:05 --> Database Driver Class Initialized
INFO - 2026-02-16 03:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:13:07 --> Upload Class Initialized
DEBUG - 2026-02-16 03:13:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:13:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:13:07 --> Encryption Class Initialized
INFO - 2026-02-16 03:13:07 --> Form Validation Class Initialized
INFO - 2026-02-16 03:13:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:13:07 --> Pagination Class Initialized
INFO - 2026-02-16 03:13:07 --> Email Class Initialized
INFO - 2026-02-16 03:13:07 --> Controller Class Initialized
DEBUG - 2026-02-16 03:13:07 --> Pay MX_Controller Initialized
INFO - 2026-02-16 03:13:07 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 03:13:07 --> Model "Auth_model" initialized
INFO - 2026-02-16 03:13:07 --> Model "Cart_model" initialized
INFO - 2026-02-16 03:13:07 --> Model "Payment_model" initialized
INFO - 2026-02-16 03:13:07 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-16 03:13:07 --> Model "Billing_model" initialized
INFO - 2026-02-16 03:13:07 --> Model "Invoice_model" initialized
INFO - 2026-02-16 03:13:13 --> Final output sent to browser
DEBUG - 2026-02-16 03:13:13 --> Total execution time: 7.2893
INFO - 2026-02-16 03:13:23 --> Config Class Initialized
INFO - 2026-02-16 03:13:23 --> Hooks Class Initialized
DEBUG - 2026-02-16 03:13:23 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:13:23 --> Utf8 Class Initialized
INFO - 2026-02-16 03:13:23 --> URI Class Initialized
INFO - 2026-02-16 03:13:23 --> Router Class Initialized
INFO - 2026-02-16 03:13:23 --> Output Class Initialized
INFO - 2026-02-16 03:13:23 --> Security Class Initialized
DEBUG - 2026-02-16 03:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:13:23 --> Input Class Initialized
INFO - 2026-02-16 03:13:23 --> Language Class Initialized
INFO - 2026-02-16 03:13:23 --> Language Class Initialized
INFO - 2026-02-16 03:13:23 --> Config Class Initialized
INFO - 2026-02-16 03:13:23 --> Loader Class Initialized
INFO - 2026-02-16 03:13:23 --> Helper loaded: url_helper
INFO - 2026-02-16 03:13:23 --> Helper loaded: form_helper
INFO - 2026-02-16 03:13:23 --> Helper loaded: html_helper
INFO - 2026-02-16 03:13:23 --> Helper loaded: file_helper
INFO - 2026-02-16 03:13:23 --> Helper loaded: email_helper
INFO - 2026-02-16 03:13:23 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:13:23 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:13:23 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:13:23 --> Database Driver Class Initialized
INFO - 2026-02-16 03:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:13:25 --> Upload Class Initialized
DEBUG - 2026-02-16 03:13:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:13:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:13:25 --> Encryption Class Initialized
INFO - 2026-02-16 03:13:25 --> Form Validation Class Initialized
INFO - 2026-02-16 03:13:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:13:25 --> Pagination Class Initialized
INFO - 2026-02-16 03:13:25 --> Email Class Initialized
INFO - 2026-02-16 03:13:25 --> Controller Class Initialized
DEBUG - 2026-02-16 03:13:25 --> Pay MX_Controller Initialized
INFO - 2026-02-16 03:13:25 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 03:13:25 --> Model "Auth_model" initialized
INFO - 2026-02-16 03:13:25 --> Model "Cart_model" initialized
INFO - 2026-02-16 03:13:25 --> Model "Payment_model" initialized
INFO - 2026-02-16 03:13:25 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-16 03:13:25 --> Model "Billing_model" initialized
INFO - 2026-02-16 03:13:25 --> Model "Invoice_model" initialized
INFO - 2026-02-16 03:13:30 --> Model "Common_model" initialized
INFO - 2026-02-16 03:13:30 --> Model "Order_model" initialized
INFO - 2026-02-16 03:13:30 --> Model "Company_model" initialized
INFO - 2026-02-16 03:13:30 --> Invoice #553 marked as PAID. Total: 32.95, Paid: 32.95
INFO - 2026-02-16 03:13:32 --> Config Class Initialized
INFO - 2026-02-16 03:13:32 --> Hooks Class Initialized
DEBUG - 2026-02-16 03:13:32 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:13:32 --> Utf8 Class Initialized
INFO - 2026-02-16 03:13:32 --> URI Class Initialized
INFO - 2026-02-16 03:13:32 --> Router Class Initialized
INFO - 2026-02-16 03:13:32 --> Output Class Initialized
INFO - 2026-02-16 03:13:32 --> Security Class Initialized
DEBUG - 2026-02-16 03:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:13:32 --> CSRF cookie sent
INFO - 2026-02-16 03:13:32 --> Input Class Initialized
INFO - 2026-02-16 03:13:32 --> Language Class Initialized
INFO - 2026-02-16 03:13:32 --> Language Class Initialized
INFO - 2026-02-16 03:13:32 --> Config Class Initialized
INFO - 2026-02-16 03:13:32 --> Loader Class Initialized
INFO - 2026-02-16 03:13:32 --> Helper loaded: url_helper
INFO - 2026-02-16 03:13:32 --> Helper loaded: form_helper
INFO - 2026-02-16 03:13:32 --> Helper loaded: html_helper
INFO - 2026-02-16 03:13:32 --> Helper loaded: file_helper
INFO - 2026-02-16 03:13:32 --> Helper loaded: email_helper
INFO - 2026-02-16 03:13:32 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:13:32 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:13:32 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:13:32 --> Database Driver Class Initialized
INFO - 2026-02-16 03:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:13:34 --> Upload Class Initialized
DEBUG - 2026-02-16 03:13:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:13:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:13:34 --> Encryption Class Initialized
INFO - 2026-02-16 03:13:34 --> Form Validation Class Initialized
INFO - 2026-02-16 03:13:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:13:34 --> Pagination Class Initialized
INFO - 2026-02-16 03:13:34 --> Email Class Initialized
INFO - 2026-02-16 03:13:34 --> Controller Class Initialized
DEBUG - 2026-02-16 03:13:34 --> Billing MX_Controller Initialized
INFO - 2026-02-16 03:13:34 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 03:13:34 --> Model "Auth_model" initialized
INFO - 2026-02-16 03:13:34 --> Model "Cart_model" initialized
INFO - 2026-02-16 03:13:34 --> Model "Billing_model" initialized
INFO - 2026-02-16 03:13:34 --> Model "Common_model" initialized
INFO - 2026-02-16 03:13:34 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-16 03:13:36 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_invoice_pdf_html.php
DEBUG - 2026-02-16 03:13:36 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-16 03:13:36 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-02-16 03:13:36 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-16 03:13:36 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-16 03:13:36 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_viewinvoice.php
INFO - 2026-02-16 03:13:36 --> Final output sent to browser
DEBUG - 2026-02-16 03:13:36 --> Total execution time: 3.9860
INFO - 2026-02-16 03:13:36 --> Config Class Initialized
INFO - 2026-02-16 03:13:36 --> Hooks Class Initialized
DEBUG - 2026-02-16 03:13:36 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:13:36 --> Utf8 Class Initialized
INFO - 2026-02-16 03:13:36 --> URI Class Initialized
INFO - 2026-02-16 03:13:36 --> Router Class Initialized
INFO - 2026-02-16 03:13:36 --> Output Class Initialized
INFO - 2026-02-16 03:13:36 --> Security Class Initialized
DEBUG - 2026-02-16 03:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:13:36 --> CSRF cookie sent
INFO - 2026-02-16 03:13:36 --> Input Class Initialized
INFO - 2026-02-16 03:13:36 --> Language Class Initialized
INFO - 2026-02-16 03:13:36 --> Language Class Initialized
INFO - 2026-02-16 03:13:36 --> Config Class Initialized
INFO - 2026-02-16 03:13:36 --> Loader Class Initialized
INFO - 2026-02-16 03:13:36 --> Helper loaded: url_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: form_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: html_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: file_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: email_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:13:36 --> Database Driver Class Initialized
INFO - 2026-02-16 03:13:36 --> Config Class Initialized
INFO - 2026-02-16 03:13:36 --> Hooks Class Initialized
DEBUG - 2026-02-16 03:13:36 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:13:36 --> Utf8 Class Initialized
INFO - 2026-02-16 03:13:36 --> URI Class Initialized
INFO - 2026-02-16 03:13:36 --> Router Class Initialized
INFO - 2026-02-16 03:13:36 --> Output Class Initialized
INFO - 2026-02-16 03:13:36 --> Security Class Initialized
DEBUG - 2026-02-16 03:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:13:36 --> CSRF cookie sent
INFO - 2026-02-16 03:13:36 --> Input Class Initialized
INFO - 2026-02-16 03:13:36 --> Language Class Initialized
INFO - 2026-02-16 03:13:36 --> Language Class Initialized
INFO - 2026-02-16 03:13:36 --> Config Class Initialized
INFO - 2026-02-16 03:13:36 --> Loader Class Initialized
INFO - 2026-02-16 03:13:36 --> Helper loaded: url_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: form_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: html_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: file_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: email_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:13:36 --> Config Class Initialized
INFO - 2026-02-16 03:13:36 --> Hooks Class Initialized
INFO - 2026-02-16 03:13:36 --> Database Driver Class Initialized
DEBUG - 2026-02-16 03:13:36 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:13:36 --> Utf8 Class Initialized
INFO - 2026-02-16 03:13:36 --> URI Class Initialized
INFO - 2026-02-16 03:13:36 --> Router Class Initialized
INFO - 2026-02-16 03:13:36 --> Output Class Initialized
INFO - 2026-02-16 03:13:36 --> Security Class Initialized
DEBUG - 2026-02-16 03:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:13:36 --> CSRF cookie sent
INFO - 2026-02-16 03:13:36 --> Input Class Initialized
INFO - 2026-02-16 03:13:36 --> Language Class Initialized
INFO - 2026-02-16 03:13:36 --> Language Class Initialized
INFO - 2026-02-16 03:13:36 --> Config Class Initialized
INFO - 2026-02-16 03:13:36 --> Config Class Initialized
INFO - 2026-02-16 03:13:36 --> Hooks Class Initialized
INFO - 2026-02-16 03:13:36 --> Config Class Initialized
INFO - 2026-02-16 03:13:36 --> Config Class Initialized
INFO - 2026-02-16 03:13:36 --> Hooks Class Initialized
INFO - 2026-02-16 03:13:36 --> Hooks Class Initialized
INFO - 2026-02-16 03:13:36 --> Loader Class Initialized
DEBUG - 2026-02-16 03:13:36 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:13:36 --> Utf8 Class Initialized
INFO - 2026-02-16 03:13:36 --> Helper loaded: url_helper
INFO - 2026-02-16 03:13:36 --> URI Class Initialized
DEBUG - 2026-02-16 03:13:36 --> UTF-8 Support Enabled
DEBUG - 2026-02-16 03:13:36 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:13:36 --> Utf8 Class Initialized
INFO - 2026-02-16 03:13:36 --> Utf8 Class Initialized
INFO - 2026-02-16 03:13:36 --> URI Class Initialized
INFO - 2026-02-16 03:13:36 --> URI Class Initialized
INFO - 2026-02-16 03:13:36 --> Helper loaded: form_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: html_helper
INFO - 2026-02-16 03:13:36 --> Router Class Initialized
INFO - 2026-02-16 03:13:36 --> Helper loaded: file_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: email_helper
INFO - 2026-02-16 03:13:36 --> Router Class Initialized
INFO - 2026-02-16 03:13:36 --> Router Class Initialized
INFO - 2026-02-16 03:13:36 --> Output Class Initialized
INFO - 2026-02-16 03:13:36 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:13:36 --> Security Class Initialized
INFO - 2026-02-16 03:13:36 --> Output Class Initialized
INFO - 2026-02-16 03:13:36 --> Output Class Initialized
INFO - 2026-02-16 03:13:36 --> Helper loaded: ssp_helper
DEBUG - 2026-02-16 03:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:13:36 --> CSRF cookie sent
INFO - 2026-02-16 03:13:36 --> Input Class Initialized
INFO - 2026-02-16 03:13:36 --> Security Class Initialized
INFO - 2026-02-16 03:13:36 --> Security Class Initialized
INFO - 2026-02-16 03:13:36 --> Language Class Initialized
INFO - 2026-02-16 03:13:36 --> Helper loaded: cpanel_helper
DEBUG - 2026-02-16 03:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:13:36 --> Language Class Initialized
DEBUG - 2026-02-16 03:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:13:36 --> CSRF cookie sent
INFO - 2026-02-16 03:13:36 --> CSRF cookie sent
INFO - 2026-02-16 03:13:36 --> Input Class Initialized
INFO - 2026-02-16 03:13:36 --> Input Class Initialized
INFO - 2026-02-16 03:13:36 --> Config Class Initialized
INFO - 2026-02-16 03:13:36 --> Language Class Initialized
INFO - 2026-02-16 03:13:36 --> Language Class Initialized
INFO - 2026-02-16 03:13:36 --> Language Class Initialized
INFO - 2026-02-16 03:13:36 --> Language Class Initialized
INFO - 2026-02-16 03:13:36 --> Config Class Initialized
INFO - 2026-02-16 03:13:36 --> Config Class Initialized
INFO - 2026-02-16 03:13:36 --> Loader Class Initialized
INFO - 2026-02-16 03:13:36 --> Helper loaded: url_helper
INFO - 2026-02-16 03:13:36 --> Loader Class Initialized
INFO - 2026-02-16 03:13:36 --> Loader Class Initialized
INFO - 2026-02-16 03:13:36 --> Helper loaded: form_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: url_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: url_helper
INFO - 2026-02-16 03:13:36 --> Database Driver Class Initialized
INFO - 2026-02-16 03:13:36 --> Helper loaded: html_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: form_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: file_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: email_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: html_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: form_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: file_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: email_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: html_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: file_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: email_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:13:36 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:13:36 --> Database Driver Class Initialized
INFO - 2026-02-16 03:13:36 --> Database Driver Class Initialized
INFO - 2026-02-16 03:13:36 --> Database Driver Class Initialized
INFO - 2026-02-16 03:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:13:38 --> Upload Class Initialized
DEBUG - 2026-02-16 03:13:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:13:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:13:38 --> Encryption Class Initialized
INFO - 2026-02-16 03:13:38 --> Form Validation Class Initialized
INFO - 2026-02-16 03:13:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:13:38 --> Pagination Class Initialized
INFO - 2026-02-16 03:13:38 --> Email Class Initialized
INFO - 2026-02-16 03:13:38 --> Controller Class Initialized
ERROR - 2026-02-16 03:13:38 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:13:38 --> Upload Class Initialized
DEBUG - 2026-02-16 03:13:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:13:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:13:38 --> Encryption Class Initialized
INFO - 2026-02-16 03:13:38 --> Form Validation Class Initialized
INFO - 2026-02-16 03:13:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:13:38 --> Pagination Class Initialized
INFO - 2026-02-16 03:13:38 --> Config Class Initialized
INFO - 2026-02-16 03:13:38 --> Email Class Initialized
INFO - 2026-02-16 03:13:38 --> Hooks Class Initialized
INFO - 2026-02-16 03:13:38 --> Controller Class Initialized
ERROR - 2026-02-16 03:13:38 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:13:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-02-16 03:13:38 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:13:38 --> Utf8 Class Initialized
INFO - 2026-02-16 03:13:38 --> URI Class Initialized
INFO - 2026-02-16 03:13:38 --> Upload Class Initialized
DEBUG - 2026-02-16 03:13:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:13:38 --> Router Class Initialized
INFO - 2026-02-16 03:13:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:13:38 --> Encryption Class Initialized
INFO - 2026-02-16 03:13:38 --> Output Class Initialized
INFO - 2026-02-16 03:13:38 --> Form Validation Class Initialized
INFO - 2026-02-16 03:13:38 --> Security Class Initialized
INFO - 2026-02-16 03:13:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:13:38 --> Pagination Class Initialized
INFO - 2026-02-16 03:13:38 --> Config Class Initialized
INFO - 2026-02-16 03:13:38 --> Hooks Class Initialized
DEBUG - 2026-02-16 03:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:13:38 --> CSRF cookie sent
INFO - 2026-02-16 03:13:38 --> Input Class Initialized
INFO - 2026-02-16 03:13:38 --> Language Class Initialized
DEBUG - 2026-02-16 03:13:38 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:13:38 --> Utf8 Class Initialized
INFO - 2026-02-16 03:13:38 --> URI Class Initialized
INFO - 2026-02-16 03:13:38 --> Language Class Initialized
INFO - 2026-02-16 03:13:38 --> Config Class Initialized
INFO - 2026-02-16 03:13:38 --> Email Class Initialized
INFO - 2026-02-16 03:13:38 --> Controller Class Initialized
INFO - 2026-02-16 03:13:38 --> Router Class Initialized
ERROR - 2026-02-16 03:13:38 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:13:38 --> Output Class Initialized
INFO - 2026-02-16 03:13:38 --> Loader Class Initialized
INFO - 2026-02-16 03:13:38 --> Security Class Initialized
INFO - 2026-02-16 03:13:38 --> Helper loaded: url_helper
INFO - 2026-02-16 03:13:38 --> Upload Class Initialized
DEBUG - 2026-02-16 03:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:13:38 --> CSRF cookie sent
INFO - 2026-02-16 03:13:38 --> Input Class Initialized
INFO - 2026-02-16 03:13:38 --> Language Class Initialized
INFO - 2026-02-16 03:13:38 --> Helper loaded: form_helper
INFO - 2026-02-16 03:13:38 --> Language Class Initialized
INFO - 2026-02-16 03:13:38 --> Config Class Initialized
DEBUG - 2026-02-16 03:13:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:13:38 --> Helper loaded: html_helper
INFO - 2026-02-16 03:13:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:13:38 --> Encryption Class Initialized
INFO - 2026-02-16 03:13:38 --> Helper loaded: file_helper
INFO - 2026-02-16 03:13:38 --> Helper loaded: email_helper
INFO - 2026-02-16 03:13:38 --> Loader Class Initialized
INFO - 2026-02-16 03:13:38 --> Form Validation Class Initialized
INFO - 2026-02-16 03:13:38 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:13:38 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:13:38 --> Helper loaded: url_helper
INFO - 2026-02-16 03:13:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:13:38 --> Pagination Class Initialized
INFO - 2026-02-16 03:13:38 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:13:38 --> Helper loaded: form_helper
INFO - 2026-02-16 03:13:38 --> Helper loaded: html_helper
INFO - 2026-02-16 03:13:38 --> Helper loaded: file_helper
INFO - 2026-02-16 03:13:38 --> Config Class Initialized
INFO - 2026-02-16 03:13:38 --> Hooks Class Initialized
INFO - 2026-02-16 03:13:38 --> Helper loaded: email_helper
INFO - 2026-02-16 03:13:38 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:13:38 --> Email Class Initialized
DEBUG - 2026-02-16 03:13:38 --> UTF-8 Support Enabled
INFO - 2026-02-16 03:13:38 --> Utf8 Class Initialized
INFO - 2026-02-16 03:13:38 --> Controller Class Initialized
INFO - 2026-02-16 03:13:38 --> Helper loaded: ssp_helper
ERROR - 2026-02-16 03:13:38 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:13:38 --> URI Class Initialized
INFO - 2026-02-16 03:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:13:38 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:13:38 --> Database Driver Class Initialized
INFO - 2026-02-16 03:13:38 --> Router Class Initialized
INFO - 2026-02-16 03:13:38 --> Upload Class Initialized
INFO - 2026-02-16 03:13:38 --> Output Class Initialized
DEBUG - 2026-02-16 03:13:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:13:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:13:38 --> Encryption Class Initialized
INFO - 2026-02-16 03:13:38 --> Security Class Initialized
INFO - 2026-02-16 03:13:38 --> Form Validation Class Initialized
DEBUG - 2026-02-16 03:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-16 03:13:38 --> CSRF cookie sent
INFO - 2026-02-16 03:13:38 --> Input Class Initialized
INFO - 2026-02-16 03:13:38 --> Database Driver Class Initialized
INFO - 2026-02-16 03:13:38 --> Language Class Initialized
INFO - 2026-02-16 03:13:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:13:38 --> Pagination Class Initialized
INFO - 2026-02-16 03:13:38 --> Language Class Initialized
INFO - 2026-02-16 03:13:38 --> Config Class Initialized
INFO - 2026-02-16 03:13:38 --> Email Class Initialized
INFO - 2026-02-16 03:13:38 --> Controller Class Initialized
INFO - 2026-02-16 03:13:38 --> Loader Class Initialized
ERROR - 2026-02-16 03:13:38 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:13:38 --> Helper loaded: url_helper
INFO - 2026-02-16 03:13:38 --> Helper loaded: form_helper
INFO - 2026-02-16 03:13:38 --> Upload Class Initialized
INFO - 2026-02-16 03:13:38 --> Helper loaded: html_helper
INFO - 2026-02-16 03:13:38 --> Helper loaded: file_helper
INFO - 2026-02-16 03:13:38 --> Helper loaded: email_helper
DEBUG - 2026-02-16 03:13:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:13:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:13:38 --> Encryption Class Initialized
INFO - 2026-02-16 03:13:38 --> Helper loaded: whmaz_helper
INFO - 2026-02-16 03:13:38 --> Helper loaded: ssp_helper
INFO - 2026-02-16 03:13:38 --> Form Validation Class Initialized
INFO - 2026-02-16 03:13:38 --> Helper loaded: cpanel_helper
INFO - 2026-02-16 03:13:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:13:38 --> Pagination Class Initialized
INFO - 2026-02-16 03:13:38 --> Email Class Initialized
INFO - 2026-02-16 03:13:38 --> Controller Class Initialized
ERROR - 2026-02-16 03:13:38 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:13:38 --> Database Driver Class Initialized
INFO - 2026-02-16 03:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:13:40 --> Upload Class Initialized
DEBUG - 2026-02-16 03:13:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:13:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:13:40 --> Encryption Class Initialized
INFO - 2026-02-16 03:13:40 --> Form Validation Class Initialized
INFO - 2026-02-16 03:13:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:13:40 --> Pagination Class Initialized
INFO - 2026-02-16 03:13:40 --> Email Class Initialized
INFO - 2026-02-16 03:13:40 --> Controller Class Initialized
ERROR - 2026-02-16 03:13:40 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:13:40 --> Upload Class Initialized
DEBUG - 2026-02-16 03:13:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:13:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:13:40 --> Encryption Class Initialized
INFO - 2026-02-16 03:13:40 --> Form Validation Class Initialized
INFO - 2026-02-16 03:13:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:13:40 --> Pagination Class Initialized
INFO - 2026-02-16 03:13:40 --> Email Class Initialized
INFO - 2026-02-16 03:13:40 --> Controller Class Initialized
ERROR - 2026-02-16 03:13:40 --> 404 Page Not Found: /index
INFO - 2026-02-16 03:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-16 03:13:41 --> Upload Class Initialized
DEBUG - 2026-02-16 03:13:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-16 03:13:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-16 03:13:41 --> Encryption Class Initialized
INFO - 2026-02-16 03:13:41 --> Form Validation Class Initialized
INFO - 2026-02-16 03:13:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-16 03:13:41 --> Pagination Class Initialized
INFO - 2026-02-16 03:13:41 --> Email Class Initialized
INFO - 2026-02-16 03:13:41 --> Controller Class Initialized
DEBUG - 2026-02-16 03:13:41 --> Cart MX_Controller Initialized
INFO - 2026-02-16 03:13:41 --> Model "Loginattempt_model" initialized
INFO - 2026-02-16 03:13:41 --> Model "Auth_model" initialized
INFO - 2026-02-16 03:13:41 --> Model "Cart_model" initialized
INFO - 2026-02-16 03:13:41 --> Model "Common_model" initialized
INFO - 2026-02-16 03:13:41 --> Model "Order_model" initialized
INFO - 2026-02-16 03:13:41 --> Model "Appsetting_model" initialized
INFO - 2026-02-16 03:13:41 --> Final output sent to browser
DEBUG - 2026-02-16 03:13:41 --> Total execution time: 3.0550

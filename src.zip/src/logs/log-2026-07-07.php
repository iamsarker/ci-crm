<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-07-07 19:20:26 --> Config Class Initialized
INFO - 2026-07-07 19:20:26 --> Hooks Class Initialized
DEBUG - 2026-07-07 19:20:26 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:20:26 --> Utf8 Class Initialized
INFO - 2026-07-07 19:20:26 --> URI Class Initialized
INFO - 2026-07-07 19:20:26 --> Router Class Initialized
INFO - 2026-07-07 19:20:26 --> Output Class Initialized
INFO - 2026-07-07 19:20:26 --> Security Class Initialized
DEBUG - 2026-07-07 19:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:20:26 --> CSRF cookie sent
INFO - 2026-07-07 19:20:26 --> Input Class Initialized
INFO - 2026-07-07 19:20:26 --> Language Class Initialized
INFO - 2026-07-07 19:20:26 --> Language Class Initialized
INFO - 2026-07-07 19:20:26 --> Config Class Initialized
INFO - 2026-07-07 19:20:26 --> Loader Class Initialized
INFO - 2026-07-07 19:20:26 --> Helper loaded: url_helper
INFO - 2026-07-07 19:20:26 --> Helper loaded: form_helper
INFO - 2026-07-07 19:20:26 --> Helper loaded: html_helper
INFO - 2026-07-07 19:20:26 --> Helper loaded: file_helper
INFO - 2026-07-07 19:20:26 --> Helper loaded: email_helper
INFO - 2026-07-07 19:20:26 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:20:26 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:20:26 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:20:26 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:20:26 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:20:26 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:20:26 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:20:26 --> Database Driver Class Initialized
INFO - 2026-07-07 19:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:20:29 --> Upload Class Initialized
DEBUG - 2026-07-07 19:20:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:20:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:20:29 --> Encryption Class Initialized
INFO - 2026-07-07 19:20:29 --> Form Validation Class Initialized
INFO - 2026-07-07 19:20:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:20:29 --> Pagination Class Initialized
INFO - 2026-07-07 19:20:29 --> Email Class Initialized
INFO - 2026-07-07 19:20:29 --> Controller Class Initialized
DEBUG - 2026-07-07 19:20:29 --> Dashboard MX_Controller Initialized
INFO - 2026-07-07 19:20:29 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:20:29 --> Model "Adminauth_model" initialized
INFO - 2026-07-07 19:20:29 --> Config Class Initialized
INFO - 2026-07-07 19:20:29 --> Hooks Class Initialized
DEBUG - 2026-07-07 19:20:29 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:20:29 --> Utf8 Class Initialized
INFO - 2026-07-07 19:20:29 --> URI Class Initialized
INFO - 2026-07-07 19:20:29 --> Router Class Initialized
INFO - 2026-07-07 19:20:29 --> Output Class Initialized
INFO - 2026-07-07 19:20:29 --> Security Class Initialized
DEBUG - 2026-07-07 19:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:20:29 --> CSRF cookie sent
INFO - 2026-07-07 19:20:29 --> Input Class Initialized
INFO - 2026-07-07 19:20:29 --> Language Class Initialized
INFO - 2026-07-07 19:20:29 --> Language Class Initialized
INFO - 2026-07-07 19:20:29 --> Config Class Initialized
INFO - 2026-07-07 19:20:29 --> Loader Class Initialized
INFO - 2026-07-07 19:20:29 --> Helper loaded: url_helper
INFO - 2026-07-07 19:20:29 --> Helper loaded: form_helper
INFO - 2026-07-07 19:20:29 --> Helper loaded: html_helper
INFO - 2026-07-07 19:20:29 --> Helper loaded: file_helper
INFO - 2026-07-07 19:20:29 --> Helper loaded: email_helper
INFO - 2026-07-07 19:20:29 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:20:29 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:20:29 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:20:29 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:20:29 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:20:29 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:20:29 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:20:29 --> Database Driver Class Initialized
INFO - 2026-07-07 19:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:20:31 --> Upload Class Initialized
DEBUG - 2026-07-07 19:20:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:20:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:20:31 --> Encryption Class Initialized
INFO - 2026-07-07 19:20:31 --> Form Validation Class Initialized
INFO - 2026-07-07 19:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:20:31 --> Pagination Class Initialized
INFO - 2026-07-07 19:20:31 --> Email Class Initialized
INFO - 2026-07-07 19:20:31 --> Controller Class Initialized
DEBUG - 2026-07-07 19:20:31 --> Authenticate MX_Controller Initialized
INFO - 2026-07-07 19:20:31 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:20:31 --> Model "Adminauth_model" initialized
INFO - 2026-07-07 19:20:31 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-07 19:20:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-07 19:20:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-07 19:20:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-07-07 19:20:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-07 19:20:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-07 19:20:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-07-07 19:20:31 --> Final output sent to browser
DEBUG - 2026-07-07 19:20:31 --> Total execution time: 2.3921
INFO - 2026-07-07 19:20:42 --> Config Class Initialized
INFO - 2026-07-07 19:20:42 --> Hooks Class Initialized
DEBUG - 2026-07-07 19:20:42 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:20:42 --> Utf8 Class Initialized
INFO - 2026-07-07 19:20:42 --> URI Class Initialized
INFO - 2026-07-07 19:20:42 --> Router Class Initialized
INFO - 2026-07-07 19:20:42 --> Output Class Initialized
INFO - 2026-07-07 19:20:42 --> Security Class Initialized
DEBUG - 2026-07-07 19:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:20:42 --> CSRF cookie sent
INFO - 2026-07-07 19:20:42 --> CSRF token verified
INFO - 2026-07-07 19:20:42 --> Input Class Initialized
INFO - 2026-07-07 19:20:42 --> Language Class Initialized
INFO - 2026-07-07 19:20:42 --> Language Class Initialized
INFO - 2026-07-07 19:20:42 --> Config Class Initialized
INFO - 2026-07-07 19:20:42 --> Loader Class Initialized
INFO - 2026-07-07 19:20:42 --> Helper loaded: url_helper
INFO - 2026-07-07 19:20:42 --> Helper loaded: form_helper
INFO - 2026-07-07 19:20:42 --> Helper loaded: html_helper
INFO - 2026-07-07 19:20:42 --> Helper loaded: file_helper
INFO - 2026-07-07 19:20:42 --> Helper loaded: email_helper
INFO - 2026-07-07 19:20:42 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:20:42 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:20:42 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:20:42 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:20:42 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:20:42 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:20:42 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:20:42 --> Database Driver Class Initialized
INFO - 2026-07-07 19:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:20:44 --> Upload Class Initialized
DEBUG - 2026-07-07 19:20:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:20:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:20:44 --> Encryption Class Initialized
INFO - 2026-07-07 19:20:44 --> Form Validation Class Initialized
INFO - 2026-07-07 19:20:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:20:44 --> Pagination Class Initialized
INFO - 2026-07-07 19:20:44 --> Email Class Initialized
INFO - 2026-07-07 19:20:44 --> Controller Class Initialized
DEBUG - 2026-07-07 19:20:44 --> Authenticate MX_Controller Initialized
INFO - 2026-07-07 19:20:44 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:20:44 --> Model "Adminauth_model" initialized
INFO - 2026-07-07 19:20:44 --> Model "Appsetting_model" initialized
INFO - 2026-07-07 19:20:58 --> Config Class Initialized
INFO - 2026-07-07 19:20:58 --> Hooks Class Initialized
DEBUG - 2026-07-07 19:20:58 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:20:58 --> Utf8 Class Initialized
INFO - 2026-07-07 19:20:58 --> URI Class Initialized
INFO - 2026-07-07 19:20:58 --> Router Class Initialized
INFO - 2026-07-07 19:20:58 --> Output Class Initialized
INFO - 2026-07-07 19:20:58 --> Security Class Initialized
DEBUG - 2026-07-07 19:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:20:58 --> CSRF cookie sent
INFO - 2026-07-07 19:20:58 --> Input Class Initialized
INFO - 2026-07-07 19:20:58 --> Language Class Initialized
INFO - 2026-07-07 19:20:58 --> Language Class Initialized
INFO - 2026-07-07 19:20:58 --> Config Class Initialized
INFO - 2026-07-07 19:20:58 --> Loader Class Initialized
INFO - 2026-07-07 19:20:58 --> Helper loaded: url_helper
INFO - 2026-07-07 19:20:58 --> Helper loaded: form_helper
INFO - 2026-07-07 19:20:58 --> Helper loaded: html_helper
INFO - 2026-07-07 19:20:58 --> Helper loaded: file_helper
INFO - 2026-07-07 19:20:58 --> Helper loaded: email_helper
INFO - 2026-07-07 19:20:58 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:20:58 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:20:58 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:20:58 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:20:58 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:20:58 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:20:58 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:20:58 --> Database Driver Class Initialized
INFO - 2026-07-07 19:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:21:05 --> Upload Class Initialized
DEBUG - 2026-07-07 19:21:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:21:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:21:05 --> Encryption Class Initialized
INFO - 2026-07-07 19:21:05 --> Form Validation Class Initialized
INFO - 2026-07-07 19:21:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:21:05 --> Pagination Class Initialized
INFO - 2026-07-07 19:21:05 --> Email Class Initialized
INFO - 2026-07-07 19:21:05 --> Controller Class Initialized
DEBUG - 2026-07-07 19:21:05 --> Dashboard MX_Controller Initialized
INFO - 2026-07-07 19:21:05 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:21:05 --> Model "Adminauth_model" initialized
INFO - 2026-07-07 19:21:05 --> Model "Dashboard_model" initialized
DEBUG - 2026-07-07 19:21:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-07 19:21:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-07 19:21:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-07 19:21:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-07 19:21:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-07 19:21:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/dashboard_index.php
INFO - 2026-07-07 19:21:05 --> Final output sent to browser
DEBUG - 2026-07-07 19:21:05 --> Total execution time: 6.7120
INFO - 2026-07-07 19:21:05 --> Config Class Initialized
INFO - 2026-07-07 19:21:05 --> Hooks Class Initialized
DEBUG - 2026-07-07 19:21:05 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:21:05 --> Utf8 Class Initialized
INFO - 2026-07-07 19:21:05 --> URI Class Initialized
INFO - 2026-07-07 19:21:05 --> Router Class Initialized
INFO - 2026-07-07 19:21:05 --> Output Class Initialized
INFO - 2026-07-07 19:21:05 --> Config Class Initialized
INFO - 2026-07-07 19:21:05 --> Hooks Class Initialized
INFO - 2026-07-07 19:21:05 --> Config Class Initialized
INFO - 2026-07-07 19:21:05 --> Hooks Class Initialized
INFO - 2026-07-07 19:21:05 --> Security Class Initialized
DEBUG - 2026-07-07 19:21:05 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:21:05 --> Utf8 Class Initialized
DEBUG - 2026-07-07 19:21:05 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:21:05 --> Utf8 Class Initialized
DEBUG - 2026-07-07 19:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:21:05 --> CSRF cookie sent
INFO - 2026-07-07 19:21:05 --> Input Class Initialized
INFO - 2026-07-07 19:21:05 --> Language Class Initialized
INFO - 2026-07-07 19:21:05 --> URI Class Initialized
INFO - 2026-07-07 19:21:05 --> Language Class Initialized
INFO - 2026-07-07 19:21:05 --> URI Class Initialized
INFO - 2026-07-07 19:21:05 --> Router Class Initialized
INFO - 2026-07-07 19:21:05 --> Router Class Initialized
INFO - 2026-07-07 19:21:05 --> Output Class Initialized
INFO - 2026-07-07 19:21:05 --> Output Class Initialized
INFO - 2026-07-07 19:21:05 --> Security Class Initialized
INFO - 2026-07-07 19:21:05 --> Security Class Initialized
INFO - 2026-07-07 19:21:05 --> Config Class Initialized
DEBUG - 2026-07-07 19:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:21:05 --> Input Class Initialized
DEBUG - 2026-07-07 19:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:21:05 --> Language Class Initialized
INFO - 2026-07-07 19:21:05 --> Input Class Initialized
INFO - 2026-07-07 19:21:05 --> Language Class Initialized
INFO - 2026-07-07 19:21:05 --> Language Class Initialized
INFO - 2026-07-07 19:21:05 --> Config Class Initialized
INFO - 2026-07-07 19:21:05 --> Language Class Initialized
INFO - 2026-07-07 19:21:05 --> Loader Class Initialized
INFO - 2026-07-07 19:21:05 --> Config Class Initialized
INFO - 2026-07-07 19:21:05 --> Config Class Initialized
INFO - 2026-07-07 19:21:05 --> Hooks Class Initialized
INFO - 2026-07-07 19:21:05 --> Helper loaded: url_helper
DEBUG - 2026-07-07 19:21:05 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:21:05 --> Utf8 Class Initialized
INFO - 2026-07-07 19:21:05 --> Loader Class Initialized
INFO - 2026-07-07 19:21:05 --> Loader Class Initialized
INFO - 2026-07-07 19:21:05 --> Helper loaded: form_helper
INFO - 2026-07-07 19:21:05 --> URI Class Initialized
INFO - 2026-07-07 19:21:05 --> Helper loaded: url_helper
INFO - 2026-07-07 19:21:05 --> Config Class Initialized
INFO - 2026-07-07 19:21:05 --> Hooks Class Initialized
INFO - 2026-07-07 19:21:05 --> Helper loaded: url_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: html_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: form_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: form_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: html_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: file_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: email_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: html_helper
INFO - 2026-07-07 19:21:05 --> Router Class Initialized
INFO - 2026-07-07 19:21:05 --> Helper loaded: file_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: email_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: file_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: email_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:21:05 --> Output Class Initialized
INFO - 2026-07-07 19:21:05 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:21:05 --> Config Class Initialized
INFO - 2026-07-07 19:21:05 --> Hooks Class Initialized
INFO - 2026-07-07 19:21:05 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:21:05 --> Security Class Initialized
DEBUG - 2026-07-07 19:21:05 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:21:05 --> Utf8 Class Initialized
INFO - 2026-07-07 19:21:05 --> Helper loaded: plesk_helper
DEBUG - 2026-07-07 19:21:05 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:21:05 --> Utf8 Class Initialized
DEBUG - 2026-07-07 19:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:21:05 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:21:05 --> URI Class Initialized
INFO - 2026-07-07 19:21:05 --> Input Class Initialized
INFO - 2026-07-07 19:21:05 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:21:05 --> Language Class Initialized
INFO - 2026-07-07 19:21:05 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:21:05 --> Language Class Initialized
INFO - 2026-07-07 19:21:05 --> Config Class Initialized
INFO - 2026-07-07 19:21:05 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:21:05 --> Router Class Initialized
INFO - 2026-07-07 19:21:05 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:21:05 --> URI Class Initialized
INFO - 2026-07-07 19:21:05 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:21:05 --> Output Class Initialized
INFO - 2026-07-07 19:21:05 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:21:05 --> Router Class Initialized
INFO - 2026-07-07 19:21:05 --> Security Class Initialized
INFO - 2026-07-07 19:21:05 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:21:05 --> Database Driver Class Initialized
INFO - 2026-07-07 19:21:05 --> Loader Class Initialized
INFO - 2026-07-07 19:21:05 --> Output Class Initialized
DEBUG - 2026-07-07 19:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:21:05 --> Helper loaded: url_helper
INFO - 2026-07-07 19:21:05 --> Input Class Initialized
INFO - 2026-07-07 19:21:05 --> Security Class Initialized
INFO - 2026-07-07 19:21:05 --> Language Class Initialized
INFO - 2026-07-07 19:21:05 --> Helper loaded: form_helper
INFO - 2026-07-07 19:21:05 --> Language Class Initialized
DEBUG - 2026-07-07 19:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:21:05 --> Config Class Initialized
INFO - 2026-07-07 19:21:05 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: html_helper
INFO - 2026-07-07 19:21:05 --> Input Class Initialized
INFO - 2026-07-07 19:21:05 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:21:05 --> Language Class Initialized
INFO - 2026-07-07 19:21:05 --> Helper loaded: file_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: email_helper
INFO - 2026-07-07 19:21:05 --> Database Driver Class Initialized
INFO - 2026-07-07 19:21:05 --> Language Class Initialized
INFO - 2026-07-07 19:21:05 --> Config Class Initialized
INFO - 2026-07-07 19:21:05 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:21:05 --> Loader Class Initialized
INFO - 2026-07-07 19:21:05 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: url_helper
INFO - 2026-07-07 19:21:05 --> Loader Class Initialized
INFO - 2026-07-07 19:21:05 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: form_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: html_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: url_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: file_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: email_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: form_helper
INFO - 2026-07-07 19:21:05 --> Database Driver Class Initialized
INFO - 2026-07-07 19:21:05 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: html_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: file_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: email_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:21:05 --> Database Driver Class Initialized
INFO - 2026-07-07 19:21:05 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:21:05 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:21:05 --> Database Driver Class Initialized
INFO - 2026-07-07 19:21:05 --> Database Driver Class Initialized
INFO - 2026-07-07 19:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:21:07 --> Upload Class Initialized
DEBUG - 2026-07-07 19:21:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:21:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:21:07 --> Encryption Class Initialized
INFO - 2026-07-07 19:21:07 --> Form Validation Class Initialized
INFO - 2026-07-07 19:21:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:21:07 --> Pagination Class Initialized
INFO - 2026-07-07 19:21:07 --> Email Class Initialized
INFO - 2026-07-07 19:21:07 --> Controller Class Initialized
DEBUG - 2026-07-07 19:21:07 --> Order MX_Controller Initialized
INFO - 2026-07-07 19:21:07 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:21:07 --> Model "Adminauth_model" initialized
INFO - 2026-07-07 19:21:08 --> Model "Order_model" initialized
INFO - 2026-07-07 19:21:08 --> Model "Common_model" initialized
INFO - 2026-07-07 19:21:08 --> Model "Currency_model" initialized
INFO - 2026-07-07 19:21:08 --> Final output sent to browser
DEBUG - 2026-07-07 19:21:08 --> Total execution time: 2.6522
INFO - 2026-07-07 19:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:21:08 --> Upload Class Initialized
DEBUG - 2026-07-07 19:21:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:21:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:21:08 --> Encryption Class Initialized
INFO - 2026-07-07 19:21:08 --> Form Validation Class Initialized
INFO - 2026-07-07 19:21:08 --> Config Class Initialized
INFO - 2026-07-07 19:21:08 --> Hooks Class Initialized
INFO - 2026-07-07 19:21:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:21:08 --> Pagination Class Initialized
DEBUG - 2026-07-07 19:21:08 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:21:08 --> Utf8 Class Initialized
INFO - 2026-07-07 19:21:08 --> URI Class Initialized
INFO - 2026-07-07 19:21:08 --> Email Class Initialized
INFO - 2026-07-07 19:21:08 --> Controller Class Initialized
INFO - 2026-07-07 19:21:08 --> Router Class Initialized
DEBUG - 2026-07-07 19:21:08 --> Dashboard MX_Controller Initialized
INFO - 2026-07-07 19:21:08 --> Output Class Initialized
INFO - 2026-07-07 19:21:08 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:21:08 --> Model "Adminauth_model" initialized
INFO - 2026-07-07 19:21:08 --> Security Class Initialized
DEBUG - 2026-07-07 19:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:21:08 --> Input Class Initialized
INFO - 2026-07-07 19:21:08 --> Language Class Initialized
INFO - 2026-07-07 19:21:08 --> Language Class Initialized
INFO - 2026-07-07 19:21:08 --> Config Class Initialized
INFO - 2026-07-07 19:21:08 --> Loader Class Initialized
INFO - 2026-07-07 19:21:08 --> Helper loaded: url_helper
INFO - 2026-07-07 19:21:08 --> Helper loaded: form_helper
INFO - 2026-07-07 19:21:08 --> Helper loaded: html_helper
INFO - 2026-07-07 19:21:08 --> Helper loaded: file_helper
INFO - 2026-07-07 19:21:08 --> Helper loaded: email_helper
INFO - 2026-07-07 19:21:08 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:21:08 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:21:08 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:21:08 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:21:08 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:21:08 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:21:08 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:21:08 --> Database Driver Class Initialized
INFO - 2026-07-07 19:21:08 --> Model "Dashboard_model" initialized
INFO - 2026-07-07 19:21:09 --> Final output sent to browser
DEBUG - 2026-07-07 19:21:09 --> Total execution time: 3.3561
INFO - 2026-07-07 19:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:21:09 --> Upload Class Initialized
DEBUG - 2026-07-07 19:21:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:21:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:21:09 --> Encryption Class Initialized
INFO - 2026-07-07 19:21:09 --> Form Validation Class Initialized
INFO - 2026-07-07 19:21:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:21:09 --> Pagination Class Initialized
INFO - 2026-07-07 19:21:09 --> Email Class Initialized
INFO - 2026-07-07 19:21:09 --> Controller Class Initialized
DEBUG - 2026-07-07 19:21:09 --> Invoice MX_Controller Initialized
INFO - 2026-07-07 19:21:09 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:21:09 --> Model "Adminauth_model" initialized
INFO - 2026-07-07 19:21:09 --> Model "Billing_model" initialized
INFO - 2026-07-07 19:21:09 --> Model "Common_model" initialized
INFO - 2026-07-07 19:21:09 --> Model "Invoice_model" initialized
INFO - 2026-07-07 19:21:09 --> Model "Appsetting_model" initialized
INFO - 2026-07-07 19:21:11 --> Final output sent to browser
DEBUG - 2026-07-07 19:21:11 --> Total execution time: 6.0990
INFO - 2026-07-07 19:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:21:11 --> Upload Class Initialized
DEBUG - 2026-07-07 19:21:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:21:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:21:11 --> Encryption Class Initialized
INFO - 2026-07-07 19:21:11 --> Form Validation Class Initialized
INFO - 2026-07-07 19:21:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:21:11 --> Pagination Class Initialized
INFO - 2026-07-07 19:21:11 --> Email Class Initialized
INFO - 2026-07-07 19:21:11 --> Controller Class Initialized
DEBUG - 2026-07-07 19:21:11 --> Dashboard MX_Controller Initialized
INFO - 2026-07-07 19:21:11 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:21:11 --> Model "Adminauth_model" initialized
INFO - 2026-07-07 19:21:12 --> Model "Dashboard_model" initialized
INFO - 2026-07-07 19:21:14 --> Config Class Initialized
INFO - 2026-07-07 19:21:14 --> Hooks Class Initialized
DEBUG - 2026-07-07 19:21:14 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:21:14 --> Utf8 Class Initialized
INFO - 2026-07-07 19:21:14 --> URI Class Initialized
INFO - 2026-07-07 19:21:14 --> Router Class Initialized
INFO - 2026-07-07 19:21:14 --> Output Class Initialized
INFO - 2026-07-07 19:21:14 --> Security Class Initialized
DEBUG - 2026-07-07 19:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:21:14 --> CSRF cookie sent
INFO - 2026-07-07 19:21:14 --> Input Class Initialized
INFO - 2026-07-07 19:21:14 --> Language Class Initialized
INFO - 2026-07-07 19:21:14 --> Language Class Initialized
INFO - 2026-07-07 19:21:14 --> Config Class Initialized
INFO - 2026-07-07 19:21:14 --> Loader Class Initialized
INFO - 2026-07-07 19:21:14 --> Helper loaded: url_helper
INFO - 2026-07-07 19:21:14 --> Helper loaded: form_helper
INFO - 2026-07-07 19:21:14 --> Helper loaded: html_helper
INFO - 2026-07-07 19:21:14 --> Helper loaded: file_helper
INFO - 2026-07-07 19:21:14 --> Helper loaded: email_helper
INFO - 2026-07-07 19:21:14 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:21:14 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:21:14 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:21:14 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:21:14 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:21:14 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:21:14 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:21:14 --> Database Driver Class Initialized
INFO - 2026-07-07 19:21:15 --> Final output sent to browser
DEBUG - 2026-07-07 19:21:15 --> Total execution time: 10.1275
INFO - 2026-07-07 19:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:21:15 --> Upload Class Initialized
DEBUG - 2026-07-07 19:21:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:21:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:21:15 --> Encryption Class Initialized
INFO - 2026-07-07 19:21:15 --> Form Validation Class Initialized
INFO - 2026-07-07 19:21:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:21:15 --> Pagination Class Initialized
INFO - 2026-07-07 19:21:15 --> Email Class Initialized
INFO - 2026-07-07 19:21:15 --> Controller Class Initialized
DEBUG - 2026-07-07 19:21:15 --> Ticket MX_Controller Initialized
INFO - 2026-07-07 19:21:15 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:21:15 --> Model "Adminauth_model" initialized
INFO - 2026-07-07 19:21:16 --> Model "Support_model" initialized
INFO - 2026-07-07 19:21:16 --> Model "Common_model" initialized
INFO - 2026-07-07 19:21:16 --> Final output sent to browser
DEBUG - 2026-07-07 19:21:16 --> Total execution time: 10.9402
INFO - 2026-07-07 19:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:21:16 --> Upload Class Initialized
DEBUG - 2026-07-07 19:21:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:21:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:21:16 --> Encryption Class Initialized
INFO - 2026-07-07 19:21:16 --> Form Validation Class Initialized
INFO - 2026-07-07 19:21:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:21:16 --> Pagination Class Initialized
INFO - 2026-07-07 19:21:16 --> Email Class Initialized
INFO - 2026-07-07 19:21:16 --> Controller Class Initialized
DEBUG - 2026-07-07 19:21:16 --> Notification MX_Controller Initialized
INFO - 2026-07-07 19:21:16 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:21:16 --> Model "Adminauth_model" initialized
INFO - 2026-07-07 19:21:16 --> Model "Notification_model" initialized
INFO - 2026-07-07 19:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:21:17 --> Upload Class Initialized
DEBUG - 2026-07-07 19:21:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:21:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:21:17 --> Encryption Class Initialized
INFO - 2026-07-07 19:21:17 --> Form Validation Class Initialized
INFO - 2026-07-07 19:21:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:21:17 --> Pagination Class Initialized
INFO - 2026-07-07 19:21:17 --> Email Class Initialized
INFO - 2026-07-07 19:21:17 --> Controller Class Initialized
DEBUG - 2026-07-07 19:21:17 --> Dashboard MX_Controller Initialized
INFO - 2026-07-07 19:21:17 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:21:17 --> Model "Adminauth_model" initialized
INFO - 2026-07-07 19:21:18 --> Model "Dashboard_model" initialized
INFO - 2026-07-07 19:21:18 --> Final output sent to browser
DEBUG - 2026-07-07 19:21:18 --> Total execution time: 9.8957
INFO - 2026-07-07 19:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:21:18 --> Upload Class Initialized
DEBUG - 2026-07-07 19:21:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:21:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:21:18 --> Encryption Class Initialized
INFO - 2026-07-07 19:21:18 --> Form Validation Class Initialized
INFO - 2026-07-07 19:21:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:21:18 --> Pagination Class Initialized
INFO - 2026-07-07 19:21:18 --> Email Class Initialized
INFO - 2026-07-07 19:21:18 --> Controller Class Initialized
DEBUG - 2026-07-07 19:21:18 --> Page MX_Controller Initialized
INFO - 2026-07-07 19:21:18 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:21:18 --> Model "Adminauth_model" initialized
INFO - 2026-07-07 19:21:18 --> Model "Page_model" initialized
DEBUG - 2026-07-07 19:21:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-07 19:21:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-07 19:21:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-07 19:21:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-07 19:21:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-07 19:21:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/page_list.php
INFO - 2026-07-07 19:21:19 --> Final output sent to browser
DEBUG - 2026-07-07 19:21:19 --> Total execution time: 4.4457
INFO - 2026-07-07 19:21:19 --> Config Class Initialized
INFO - 2026-07-07 19:21:19 --> Hooks Class Initialized
DEBUG - 2026-07-07 19:21:19 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:21:19 --> Utf8 Class Initialized
INFO - 2026-07-07 19:21:19 --> URI Class Initialized
INFO - 2026-07-07 19:21:19 --> Router Class Initialized
INFO - 2026-07-07 19:21:19 --> Output Class Initialized
INFO - 2026-07-07 19:21:19 --> Security Class Initialized
DEBUG - 2026-07-07 19:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:21:19 --> CSRF cookie sent
INFO - 2026-07-07 19:21:19 --> Input Class Initialized
INFO - 2026-07-07 19:21:19 --> Language Class Initialized
INFO - 2026-07-07 19:21:19 --> Language Class Initialized
INFO - 2026-07-07 19:21:19 --> Config Class Initialized
INFO - 2026-07-07 19:21:19 --> Loader Class Initialized
INFO - 2026-07-07 19:21:19 --> Helper loaded: url_helper
INFO - 2026-07-07 19:21:19 --> Helper loaded: form_helper
INFO - 2026-07-07 19:21:19 --> Helper loaded: html_helper
INFO - 2026-07-07 19:21:19 --> Helper loaded: file_helper
INFO - 2026-07-07 19:21:19 --> Helper loaded: email_helper
INFO - 2026-07-07 19:21:19 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:21:19 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:21:19 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:21:19 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:21:19 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:21:19 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:21:19 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:21:19 --> Database Driver Class Initialized
INFO - 2026-07-07 19:21:19 --> Config Class Initialized
INFO - 2026-07-07 19:21:19 --> Hooks Class Initialized
DEBUG - 2026-07-07 19:21:19 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:21:19 --> Utf8 Class Initialized
INFO - 2026-07-07 19:21:19 --> URI Class Initialized
INFO - 2026-07-07 19:21:19 --> Router Class Initialized
INFO - 2026-07-07 19:21:19 --> Output Class Initialized
INFO - 2026-07-07 19:21:19 --> Security Class Initialized
DEBUG - 2026-07-07 19:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:21:19 --> CSRF cookie sent
INFO - 2026-07-07 19:21:19 --> Input Class Initialized
INFO - 2026-07-07 19:21:19 --> Language Class Initialized
INFO - 2026-07-07 19:21:19 --> Language Class Initialized
INFO - 2026-07-07 19:21:19 --> Config Class Initialized
INFO - 2026-07-07 19:21:19 --> Loader Class Initialized
INFO - 2026-07-07 19:21:19 --> Helper loaded: url_helper
INFO - 2026-07-07 19:21:19 --> Helper loaded: form_helper
INFO - 2026-07-07 19:21:19 --> Helper loaded: html_helper
INFO - 2026-07-07 19:21:19 --> Helper loaded: file_helper
INFO - 2026-07-07 19:21:19 --> Helper loaded: email_helper
INFO - 2026-07-07 19:21:19 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:21:19 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:21:19 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:21:19 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:21:19 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:21:19 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:21:19 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:21:19 --> Database Driver Class Initialized
INFO - 2026-07-07 19:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:21:20 --> Upload Class Initialized
DEBUG - 2026-07-07 19:21:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:21:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:21:20 --> Encryption Class Initialized
INFO - 2026-07-07 19:21:20 --> Form Validation Class Initialized
INFO - 2026-07-07 19:21:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:21:20 --> Pagination Class Initialized
INFO - 2026-07-07 19:21:20 --> Email Class Initialized
INFO - 2026-07-07 19:21:20 --> Controller Class Initialized
DEBUG - 2026-07-07 19:21:20 --> Notification MX_Controller Initialized
INFO - 2026-07-07 19:21:20 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:21:20 --> Model "Adminauth_model" initialized
INFO - 2026-07-07 19:21:20 --> Model "Notification_model" initialized
INFO - 2026-07-07 19:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:21:23 --> Upload Class Initialized
DEBUG - 2026-07-07 19:21:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:21:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:21:23 --> Encryption Class Initialized
INFO - 2026-07-07 19:21:23 --> Form Validation Class Initialized
INFO - 2026-07-07 19:21:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:21:23 --> Pagination Class Initialized
INFO - 2026-07-07 19:21:23 --> Email Class Initialized
INFO - 2026-07-07 19:21:23 --> Controller Class Initialized
DEBUG - 2026-07-07 19:21:23 --> Page MX_Controller Initialized
INFO - 2026-07-07 19:21:23 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:21:23 --> Model "Adminauth_model" initialized
INFO - 2026-07-07 19:21:23 --> Model "Page_model" initialized
INFO - 2026-07-07 19:21:53 --> Config Class Initialized
INFO - 2026-07-07 19:21:53 --> Hooks Class Initialized
DEBUG - 2026-07-07 19:21:53 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:21:53 --> Utf8 Class Initialized
INFO - 2026-07-07 19:21:53 --> URI Class Initialized
INFO - 2026-07-07 19:21:53 --> Router Class Initialized
INFO - 2026-07-07 19:21:53 --> Output Class Initialized
INFO - 2026-07-07 19:21:53 --> Security Class Initialized
DEBUG - 2026-07-07 19:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:21:53 --> CSRF cookie sent
INFO - 2026-07-07 19:21:53 --> Input Class Initialized
INFO - 2026-07-07 19:21:53 --> Language Class Initialized
INFO - 2026-07-07 19:21:53 --> Language Class Initialized
INFO - 2026-07-07 19:21:53 --> Config Class Initialized
INFO - 2026-07-07 19:21:53 --> Loader Class Initialized
INFO - 2026-07-07 19:21:53 --> Helper loaded: url_helper
INFO - 2026-07-07 19:21:53 --> Helper loaded: form_helper
INFO - 2026-07-07 19:21:53 --> Helper loaded: html_helper
INFO - 2026-07-07 19:21:53 --> Helper loaded: file_helper
INFO - 2026-07-07 19:21:53 --> Helper loaded: email_helper
INFO - 2026-07-07 19:21:53 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:21:53 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:21:53 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:21:53 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:21:53 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:21:53 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:21:53 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:21:53 --> Database Driver Class Initialized
INFO - 2026-07-07 19:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:21:56 --> Upload Class Initialized
DEBUG - 2026-07-07 19:21:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:21:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:21:56 --> Encryption Class Initialized
INFO - 2026-07-07 19:21:56 --> Form Validation Class Initialized
INFO - 2026-07-07 19:21:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:21:56 --> Pagination Class Initialized
INFO - 2026-07-07 19:21:56 --> Email Class Initialized
INFO - 2026-07-07 19:21:56 --> Controller Class Initialized
DEBUG - 2026-07-07 19:21:56 --> Page MX_Controller Initialized
INFO - 2026-07-07 19:21:56 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:21:56 --> Model "Adminauth_model" initialized
INFO - 2026-07-07 19:21:56 --> Model "Page_model" initialized
DEBUG - 2026-07-07 19:21:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-07 19:21:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-07 19:21:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-07 19:21:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-07 19:21:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-07 19:21:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/page_manage.php
INFO - 2026-07-07 19:21:59 --> Final output sent to browser
DEBUG - 2026-07-07 19:21:59 --> Total execution time: 5.5443
INFO - 2026-07-07 19:21:59 --> Config Class Initialized
INFO - 2026-07-07 19:21:59 --> Hooks Class Initialized
DEBUG - 2026-07-07 19:21:59 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:21:59 --> Utf8 Class Initialized
INFO - 2026-07-07 19:21:59 --> URI Class Initialized
INFO - 2026-07-07 19:21:59 --> Router Class Initialized
INFO - 2026-07-07 19:21:59 --> Output Class Initialized
INFO - 2026-07-07 19:21:59 --> Security Class Initialized
DEBUG - 2026-07-07 19:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:21:59 --> CSRF cookie sent
INFO - 2026-07-07 19:21:59 --> Input Class Initialized
INFO - 2026-07-07 19:21:59 --> Language Class Initialized
INFO - 2026-07-07 19:21:59 --> Language Class Initialized
INFO - 2026-07-07 19:21:59 --> Config Class Initialized
INFO - 2026-07-07 19:21:59 --> Loader Class Initialized
INFO - 2026-07-07 19:21:59 --> Helper loaded: url_helper
INFO - 2026-07-07 19:21:59 --> Helper loaded: form_helper
INFO - 2026-07-07 19:21:59 --> Helper loaded: html_helper
INFO - 2026-07-07 19:21:59 --> Helper loaded: file_helper
INFO - 2026-07-07 19:21:59 --> Helper loaded: email_helper
INFO - 2026-07-07 19:21:59 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:21:59 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:21:59 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:21:59 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:21:59 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:21:59 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:21:59 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:21:59 --> Database Driver Class Initialized
INFO - 2026-07-07 19:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:22:01 --> Upload Class Initialized
DEBUG - 2026-07-07 19:22:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:22:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:22:01 --> Encryption Class Initialized
INFO - 2026-07-07 19:22:01 --> Form Validation Class Initialized
INFO - 2026-07-07 19:22:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:22:01 --> Pagination Class Initialized
INFO - 2026-07-07 19:22:01 --> Email Class Initialized
INFO - 2026-07-07 19:22:01 --> Controller Class Initialized
DEBUG - 2026-07-07 19:22:01 --> Notification MX_Controller Initialized
INFO - 2026-07-07 19:22:01 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:22:01 --> Model "Adminauth_model" initialized
INFO - 2026-07-07 19:22:01 --> Model "Notification_model" initialized
INFO - 2026-07-07 19:22:54 --> Config Class Initialized
INFO - 2026-07-07 19:22:54 --> Hooks Class Initialized
DEBUG - 2026-07-07 19:22:54 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:22:54 --> Utf8 Class Initialized
INFO - 2026-07-07 19:22:54 --> URI Class Initialized
INFO - 2026-07-07 19:22:54 --> Router Class Initialized
INFO - 2026-07-07 19:22:54 --> Output Class Initialized
INFO - 2026-07-07 19:22:54 --> Security Class Initialized
DEBUG - 2026-07-07 19:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:22:54 --> CSRF cookie sent
INFO - 2026-07-07 19:22:54 --> CSRF token verified
INFO - 2026-07-07 19:22:54 --> Input Class Initialized
INFO - 2026-07-07 19:22:54 --> Language Class Initialized
INFO - 2026-07-07 19:22:54 --> Language Class Initialized
INFO - 2026-07-07 19:22:54 --> Config Class Initialized
INFO - 2026-07-07 19:22:54 --> Loader Class Initialized
INFO - 2026-07-07 19:22:54 --> Helper loaded: url_helper
INFO - 2026-07-07 19:22:54 --> Helper loaded: form_helper
INFO - 2026-07-07 19:22:54 --> Helper loaded: html_helper
INFO - 2026-07-07 19:22:54 --> Helper loaded: file_helper
INFO - 2026-07-07 19:22:54 --> Helper loaded: email_helper
INFO - 2026-07-07 19:22:54 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:22:54 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:22:54 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:22:54 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:22:54 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:22:54 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:22:54 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:22:54 --> Database Driver Class Initialized
INFO - 2026-07-07 19:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:22:58 --> Upload Class Initialized
DEBUG - 2026-07-07 19:22:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:22:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:22:58 --> Encryption Class Initialized
INFO - 2026-07-07 19:22:58 --> Form Validation Class Initialized
INFO - 2026-07-07 19:22:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:22:58 --> Pagination Class Initialized
INFO - 2026-07-07 19:22:58 --> Email Class Initialized
INFO - 2026-07-07 19:22:58 --> Controller Class Initialized
DEBUG - 2026-07-07 19:22:58 --> Page MX_Controller Initialized
INFO - 2026-07-07 19:22:58 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:22:58 --> Model "Adminauth_model" initialized
INFO - 2026-07-07 19:22:58 --> Model "Page_model" initialized
INFO - 2026-07-07 19:22:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-07-07 19:22:59 --> Config Class Initialized
INFO - 2026-07-07 19:22:59 --> Hooks Class Initialized
DEBUG - 2026-07-07 19:22:59 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:22:59 --> Utf8 Class Initialized
INFO - 2026-07-07 19:22:59 --> URI Class Initialized
INFO - 2026-07-07 19:22:59 --> Router Class Initialized
INFO - 2026-07-07 19:22:59 --> Output Class Initialized
INFO - 2026-07-07 19:22:59 --> Security Class Initialized
DEBUG - 2026-07-07 19:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:22:59 --> CSRF cookie sent
INFO - 2026-07-07 19:22:59 --> Input Class Initialized
INFO - 2026-07-07 19:22:59 --> Language Class Initialized
INFO - 2026-07-07 19:22:59 --> Language Class Initialized
INFO - 2026-07-07 19:22:59 --> Config Class Initialized
INFO - 2026-07-07 19:22:59 --> Loader Class Initialized
INFO - 2026-07-07 19:22:59 --> Helper loaded: url_helper
INFO - 2026-07-07 19:22:59 --> Helper loaded: form_helper
INFO - 2026-07-07 19:22:59 --> Helper loaded: html_helper
INFO - 2026-07-07 19:22:59 --> Helper loaded: file_helper
INFO - 2026-07-07 19:22:59 --> Helper loaded: email_helper
INFO - 2026-07-07 19:22:59 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:22:59 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:22:59 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:22:59 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:22:59 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:22:59 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:22:59 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:22:59 --> Database Driver Class Initialized
INFO - 2026-07-07 19:22:59 --> Config Class Initialized
INFO - 2026-07-07 19:22:59 --> Hooks Class Initialized
DEBUG - 2026-07-07 19:22:59 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:22:59 --> Utf8 Class Initialized
INFO - 2026-07-07 19:22:59 --> URI Class Initialized
INFO - 2026-07-07 19:22:59 --> Router Class Initialized
INFO - 2026-07-07 19:22:59 --> Output Class Initialized
INFO - 2026-07-07 19:22:59 --> Security Class Initialized
DEBUG - 2026-07-07 19:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:22:59 --> CSRF cookie sent
INFO - 2026-07-07 19:22:59 --> Input Class Initialized
INFO - 2026-07-07 19:22:59 --> Language Class Initialized
INFO - 2026-07-07 19:22:59 --> Language Class Initialized
INFO - 2026-07-07 19:22:59 --> Config Class Initialized
INFO - 2026-07-07 19:22:59 --> Loader Class Initialized
INFO - 2026-07-07 19:22:59 --> Helper loaded: url_helper
INFO - 2026-07-07 19:22:59 --> Helper loaded: form_helper
INFO - 2026-07-07 19:22:59 --> Helper loaded: html_helper
INFO - 2026-07-07 19:22:59 --> Helper loaded: file_helper
INFO - 2026-07-07 19:22:59 --> Helper loaded: email_helper
INFO - 2026-07-07 19:22:59 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:22:59 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:22:59 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:22:59 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:22:59 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:22:59 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:22:59 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:22:59 --> Database Driver Class Initialized
INFO - 2026-07-07 19:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:23:04 --> Upload Class Initialized
DEBUG - 2026-07-07 19:23:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:23:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:23:04 --> Encryption Class Initialized
INFO - 2026-07-07 19:23:04 --> Form Validation Class Initialized
INFO - 2026-07-07 19:23:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:23:04 --> Pagination Class Initialized
INFO - 2026-07-07 19:23:04 --> Email Class Initialized
INFO - 2026-07-07 19:23:04 --> Controller Class Initialized
DEBUG - 2026-07-07 19:23:04 --> Notification MX_Controller Initialized
INFO - 2026-07-07 19:23:04 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:23:04 --> Model "Adminauth_model" initialized
INFO - 2026-07-07 19:23:04 --> Model "Notification_model" initialized
INFO - 2026-07-07 19:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:23:08 --> Upload Class Initialized
DEBUG - 2026-07-07 19:23:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:23:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:23:08 --> Encryption Class Initialized
INFO - 2026-07-07 19:23:08 --> Form Validation Class Initialized
INFO - 2026-07-07 19:23:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:23:08 --> Pagination Class Initialized
INFO - 2026-07-07 19:23:08 --> Email Class Initialized
INFO - 2026-07-07 19:23:08 --> Controller Class Initialized
DEBUG - 2026-07-07 19:23:08 --> Page MX_Controller Initialized
INFO - 2026-07-07 19:23:08 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:23:08 --> Model "Adminauth_model" initialized
INFO - 2026-07-07 19:23:08 --> Model "Page_model" initialized
DEBUG - 2026-07-07 19:23:16 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-07 19:23:16 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-07 19:23:16 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-07 19:23:16 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-07 19:23:16 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-07 19:23:16 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/page_list.php
INFO - 2026-07-07 19:23:16 --> Final output sent to browser
DEBUG - 2026-07-07 19:23:16 --> Total execution time: 16.8898
INFO - 2026-07-07 19:23:16 --> Config Class Initialized
INFO - 2026-07-07 19:23:16 --> Hooks Class Initialized
DEBUG - 2026-07-07 19:23:16 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:23:16 --> Utf8 Class Initialized
INFO - 2026-07-07 19:23:16 --> URI Class Initialized
INFO - 2026-07-07 19:23:16 --> Router Class Initialized
INFO - 2026-07-07 19:23:16 --> Output Class Initialized
INFO - 2026-07-07 19:23:16 --> Security Class Initialized
DEBUG - 2026-07-07 19:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:23:16 --> CSRF cookie sent
INFO - 2026-07-07 19:23:16 --> Input Class Initialized
INFO - 2026-07-07 19:23:16 --> Language Class Initialized
INFO - 2026-07-07 19:23:16 --> Language Class Initialized
INFO - 2026-07-07 19:23:16 --> Config Class Initialized
INFO - 2026-07-07 19:23:16 --> Loader Class Initialized
INFO - 2026-07-07 19:23:16 --> Helper loaded: url_helper
INFO - 2026-07-07 19:23:16 --> Helper loaded: form_helper
INFO - 2026-07-07 19:23:16 --> Helper loaded: html_helper
INFO - 2026-07-07 19:23:16 --> Helper loaded: file_helper
INFO - 2026-07-07 19:23:16 --> Helper loaded: email_helper
INFO - 2026-07-07 19:23:16 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:23:16 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:23:16 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:23:16 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:23:16 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:23:16 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:23:16 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:23:16 --> Database Driver Class Initialized
INFO - 2026-07-07 19:23:16 --> Config Class Initialized
INFO - 2026-07-07 19:23:16 --> Hooks Class Initialized
DEBUG - 2026-07-07 19:23:16 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:23:16 --> Utf8 Class Initialized
INFO - 2026-07-07 19:23:16 --> URI Class Initialized
INFO - 2026-07-07 19:23:16 --> Router Class Initialized
INFO - 2026-07-07 19:23:16 --> Output Class Initialized
INFO - 2026-07-07 19:23:16 --> Security Class Initialized
DEBUG - 2026-07-07 19:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:23:16 --> CSRF cookie sent
INFO - 2026-07-07 19:23:16 --> Input Class Initialized
INFO - 2026-07-07 19:23:16 --> Language Class Initialized
INFO - 2026-07-07 19:23:16 --> Language Class Initialized
INFO - 2026-07-07 19:23:16 --> Config Class Initialized
INFO - 2026-07-07 19:23:16 --> Loader Class Initialized
INFO - 2026-07-07 19:23:16 --> Helper loaded: url_helper
INFO - 2026-07-07 19:23:16 --> Helper loaded: form_helper
INFO - 2026-07-07 19:23:16 --> Helper loaded: html_helper
INFO - 2026-07-07 19:23:16 --> Helper loaded: file_helper
INFO - 2026-07-07 19:23:16 --> Helper loaded: email_helper
INFO - 2026-07-07 19:23:16 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:23:16 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:23:16 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:23:16 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:23:16 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:23:16 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:23:16 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:23:16 --> Database Driver Class Initialized
INFO - 2026-07-07 19:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:23:19 --> Upload Class Initialized
DEBUG - 2026-07-07 19:23:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:23:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:23:19 --> Encryption Class Initialized
INFO - 2026-07-07 19:23:19 --> Form Validation Class Initialized
INFO - 2026-07-07 19:23:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:23:19 --> Pagination Class Initialized
INFO - 2026-07-07 19:23:19 --> Email Class Initialized
INFO - 2026-07-07 19:23:19 --> Controller Class Initialized
DEBUG - 2026-07-07 19:23:19 --> Page MX_Controller Initialized
INFO - 2026-07-07 19:23:19 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:23:19 --> Model "Adminauth_model" initialized
INFO - 2026-07-07 19:23:19 --> Model "Page_model" initialized
INFO - 2026-07-07 19:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:23:24 --> Upload Class Initialized
DEBUG - 2026-07-07 19:23:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:23:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:23:24 --> Encryption Class Initialized
INFO - 2026-07-07 19:23:24 --> Form Validation Class Initialized
INFO - 2026-07-07 19:23:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:23:24 --> Pagination Class Initialized
INFO - 2026-07-07 19:23:24 --> Email Class Initialized
INFO - 2026-07-07 19:23:24 --> Controller Class Initialized
DEBUG - 2026-07-07 19:23:24 --> Notification MX_Controller Initialized
INFO - 2026-07-07 19:23:24 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:23:24 --> Model "Adminauth_model" initialized
INFO - 2026-07-07 19:23:24 --> Model "Notification_model" initialized
INFO - 2026-07-07 19:23:25 --> Config Class Initialized
INFO - 2026-07-07 19:23:25 --> Hooks Class Initialized
DEBUG - 2026-07-07 19:23:25 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:23:25 --> Utf8 Class Initialized
INFO - 2026-07-07 19:23:25 --> URI Class Initialized
INFO - 2026-07-07 19:23:25 --> Router Class Initialized
INFO - 2026-07-07 19:23:25 --> Output Class Initialized
INFO - 2026-07-07 19:23:25 --> Security Class Initialized
DEBUG - 2026-07-07 19:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:23:25 --> CSRF cookie sent
INFO - 2026-07-07 19:23:25 --> Input Class Initialized
INFO - 2026-07-07 19:23:25 --> Language Class Initialized
INFO - 2026-07-07 19:23:25 --> Language Class Initialized
INFO - 2026-07-07 19:23:25 --> Config Class Initialized
INFO - 2026-07-07 19:23:25 --> Loader Class Initialized
INFO - 2026-07-07 19:23:25 --> Helper loaded: url_helper
INFO - 2026-07-07 19:23:25 --> Helper loaded: form_helper
INFO - 2026-07-07 19:23:25 --> Helper loaded: html_helper
INFO - 2026-07-07 19:23:25 --> Helper loaded: file_helper
INFO - 2026-07-07 19:23:25 --> Helper loaded: email_helper
INFO - 2026-07-07 19:23:25 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:23:25 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:23:25 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:23:25 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:23:25 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:23:25 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:23:25 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:23:25 --> Database Driver Class Initialized
INFO - 2026-07-07 19:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:23:29 --> Upload Class Initialized
DEBUG - 2026-07-07 19:23:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:23:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:23:29 --> Encryption Class Initialized
INFO - 2026-07-07 19:23:29 --> Form Validation Class Initialized
INFO - 2026-07-07 19:23:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:23:29 --> Pagination Class Initialized
INFO - 2026-07-07 19:23:29 --> Email Class Initialized
INFO - 2026-07-07 19:23:29 --> Controller Class Initialized
DEBUG - 2026-07-07 19:23:29 --> Authenticate MX_Controller Initialized
INFO - 2026-07-07 19:23:29 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:23:29 --> Model "Adminauth_model" initialized
INFO - 2026-07-07 19:23:29 --> Model "Appsetting_model" initialized
INFO - 2026-07-07 19:23:29 --> Config Class Initialized
INFO - 2026-07-07 19:23:29 --> Hooks Class Initialized
DEBUG - 2026-07-07 19:23:29 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:23:29 --> Utf8 Class Initialized
INFO - 2026-07-07 19:23:29 --> URI Class Initialized
INFO - 2026-07-07 19:23:29 --> Router Class Initialized
INFO - 2026-07-07 19:23:29 --> Output Class Initialized
INFO - 2026-07-07 19:23:29 --> Security Class Initialized
DEBUG - 2026-07-07 19:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:23:29 --> CSRF cookie sent
INFO - 2026-07-07 19:23:29 --> Input Class Initialized
INFO - 2026-07-07 19:23:29 --> Language Class Initialized
INFO - 2026-07-07 19:23:29 --> Language Class Initialized
INFO - 2026-07-07 19:23:29 --> Config Class Initialized
INFO - 2026-07-07 19:23:29 --> Loader Class Initialized
INFO - 2026-07-07 19:23:29 --> Helper loaded: url_helper
INFO - 2026-07-07 19:23:29 --> Helper loaded: form_helper
INFO - 2026-07-07 19:23:29 --> Helper loaded: html_helper
INFO - 2026-07-07 19:23:29 --> Helper loaded: file_helper
INFO - 2026-07-07 19:23:29 --> Helper loaded: email_helper
INFO - 2026-07-07 19:23:29 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:23:29 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:23:29 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:23:29 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:23:29 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:23:29 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:23:29 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:23:29 --> Database Driver Class Initialized
INFO - 2026-07-07 19:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:23:34 --> Upload Class Initialized
DEBUG - 2026-07-07 19:23:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:23:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:23:34 --> Encryption Class Initialized
INFO - 2026-07-07 19:23:34 --> Form Validation Class Initialized
INFO - 2026-07-07 19:23:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:23:34 --> Pagination Class Initialized
INFO - 2026-07-07 19:23:34 --> Email Class Initialized
INFO - 2026-07-07 19:23:34 --> Controller Class Initialized
DEBUG - 2026-07-07 19:23:34 --> Authenticate MX_Controller Initialized
INFO - 2026-07-07 19:23:34 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:23:34 --> Model "Adminauth_model" initialized
INFO - 2026-07-07 19:23:34 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-07 19:23:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-07 19:23:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-07 19:23:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-07-07 19:23:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-07 19:23:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-07 19:23:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-07-07 19:23:34 --> Final output sent to browser
DEBUG - 2026-07-07 19:23:34 --> Total execution time: 5.4746
INFO - 2026-07-07 19:23:39 --> Config Class Initialized
INFO - 2026-07-07 19:23:39 --> Hooks Class Initialized
DEBUG - 2026-07-07 19:23:39 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:23:39 --> Utf8 Class Initialized
INFO - 2026-07-07 19:23:39 --> URI Class Initialized
DEBUG - 2026-07-07 19:23:39 --> No URI present. Default controller set.
INFO - 2026-07-07 19:23:39 --> Router Class Initialized
INFO - 2026-07-07 19:23:39 --> Output Class Initialized
INFO - 2026-07-07 19:23:39 --> Security Class Initialized
DEBUG - 2026-07-07 19:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:23:39 --> CSRF cookie sent
INFO - 2026-07-07 19:23:39 --> Input Class Initialized
INFO - 2026-07-07 19:23:39 --> Language Class Initialized
INFO - 2026-07-07 19:23:39 --> Language Class Initialized
INFO - 2026-07-07 19:23:39 --> Config Class Initialized
INFO - 2026-07-07 19:23:39 --> Loader Class Initialized
INFO - 2026-07-07 19:23:39 --> Helper loaded: url_helper
INFO - 2026-07-07 19:23:39 --> Helper loaded: form_helper
INFO - 2026-07-07 19:23:39 --> Helper loaded: html_helper
INFO - 2026-07-07 19:23:39 --> Helper loaded: file_helper
INFO - 2026-07-07 19:23:39 --> Helper loaded: email_helper
INFO - 2026-07-07 19:23:39 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:23:39 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:23:39 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:23:39 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:23:39 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:23:39 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:23:39 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:23:39 --> Database Driver Class Initialized
INFO - 2026-07-07 19:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:23:44 --> Upload Class Initialized
DEBUG - 2026-07-07 19:23:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:23:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:23:44 --> Encryption Class Initialized
INFO - 2026-07-07 19:23:44 --> Form Validation Class Initialized
INFO - 2026-07-07 19:23:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:23:44 --> Pagination Class Initialized
INFO - 2026-07-07 19:23:44 --> Email Class Initialized
INFO - 2026-07-07 19:23:44 --> Controller Class Initialized
DEBUG - 2026-07-07 19:23:44 --> Auth MX_Controller Initialized
INFO - 2026-07-07 19:23:44 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:23:44 --> Model "Auth_model" initialized
INFO - 2026-07-07 19:23:44 --> Model "Cart_model" initialized
INFO - 2026-07-07 19:23:45 --> Model "Appsetting_model" initialized
INFO - 2026-07-07 19:23:45 --> Config Class Initialized
INFO - 2026-07-07 19:23:45 --> Hooks Class Initialized
DEBUG - 2026-07-07 19:23:45 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:23:45 --> Utf8 Class Initialized
INFO - 2026-07-07 19:23:45 --> URI Class Initialized
INFO - 2026-07-07 19:23:45 --> Router Class Initialized
INFO - 2026-07-07 19:23:45 --> Output Class Initialized
INFO - 2026-07-07 19:23:45 --> Security Class Initialized
DEBUG - 2026-07-07 19:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:23:45 --> CSRF cookie sent
INFO - 2026-07-07 19:23:45 --> Input Class Initialized
INFO - 2026-07-07 19:23:45 --> Language Class Initialized
INFO - 2026-07-07 19:23:45 --> Language Class Initialized
INFO - 2026-07-07 19:23:45 --> Config Class Initialized
INFO - 2026-07-07 19:23:45 --> Loader Class Initialized
INFO - 2026-07-07 19:23:45 --> Helper loaded: url_helper
INFO - 2026-07-07 19:23:45 --> Helper loaded: form_helper
INFO - 2026-07-07 19:23:45 --> Helper loaded: html_helper
INFO - 2026-07-07 19:23:45 --> Helper loaded: file_helper
INFO - 2026-07-07 19:23:45 --> Helper loaded: email_helper
INFO - 2026-07-07 19:23:45 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:23:45 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:23:45 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:23:45 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:23:45 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:23:45 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:23:45 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:23:45 --> Database Driver Class Initialized
INFO - 2026-07-07 19:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:23:49 --> Upload Class Initialized
DEBUG - 2026-07-07 19:23:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:23:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:23:49 --> Encryption Class Initialized
INFO - 2026-07-07 19:23:49 --> Form Validation Class Initialized
INFO - 2026-07-07 19:23:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:23:49 --> Pagination Class Initialized
INFO - 2026-07-07 19:23:49 --> Email Class Initialized
INFO - 2026-07-07 19:23:49 --> Controller Class Initialized
DEBUG - 2026-07-07 19:23:49 --> Auth MX_Controller Initialized
INFO - 2026-07-07 19:23:49 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:23:49 --> Model "Auth_model" initialized
INFO - 2026-07-07 19:23:49 --> Model "Cart_model" initialized
INFO - 2026-07-07 19:23:49 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-07 19:23:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-07 19:23:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-07 19:23:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-07 19:23:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-07-07 19:23:49 --> Final output sent to browser
DEBUG - 2026-07-07 19:23:49 --> Total execution time: 4.2069
INFO - 2026-07-07 19:23:49 --> Config Class Initialized
INFO - 2026-07-07 19:23:49 --> Hooks Class Initialized
DEBUG - 2026-07-07 19:23:49 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:23:49 --> Utf8 Class Initialized
INFO - 2026-07-07 19:23:49 --> URI Class Initialized
INFO - 2026-07-07 19:23:49 --> Router Class Initialized
INFO - 2026-07-07 19:23:49 --> Output Class Initialized
INFO - 2026-07-07 19:23:49 --> Security Class Initialized
DEBUG - 2026-07-07 19:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:23:49 --> CSRF cookie sent
INFO - 2026-07-07 19:23:49 --> Input Class Initialized
INFO - 2026-07-07 19:23:49 --> Language Class Initialized
INFO - 2026-07-07 19:23:49 --> Language Class Initialized
INFO - 2026-07-07 19:23:49 --> Config Class Initialized
INFO - 2026-07-07 19:23:49 --> Loader Class Initialized
INFO - 2026-07-07 19:23:49 --> Helper loaded: url_helper
INFO - 2026-07-07 19:23:49 --> Helper loaded: form_helper
INFO - 2026-07-07 19:23:49 --> Helper loaded: html_helper
INFO - 2026-07-07 19:23:49 --> Helper loaded: file_helper
INFO - 2026-07-07 19:23:49 --> Helper loaded: email_helper
INFO - 2026-07-07 19:23:49 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:23:49 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:23:49 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:23:49 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:23:49 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:23:49 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:23:49 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:23:49 --> Database Driver Class Initialized
INFO - 2026-07-07 19:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:23:52 --> Upload Class Initialized
DEBUG - 2026-07-07 19:23:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:23:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:23:52 --> Encryption Class Initialized
INFO - 2026-07-07 19:23:52 --> Form Validation Class Initialized
INFO - 2026-07-07 19:23:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:23:52 --> Pagination Class Initialized
INFO - 2026-07-07 19:23:52 --> Email Class Initialized
INFO - 2026-07-07 19:23:52 --> Controller Class Initialized
DEBUG - 2026-07-07 19:23:52 --> Cart MX_Controller Initialized
INFO - 2026-07-07 19:23:52 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:23:52 --> Model "Auth_model" initialized
INFO - 2026-07-07 19:23:52 --> Model "Cart_model" initialized
INFO - 2026-07-07 19:23:52 --> Model "Common_model" initialized
INFO - 2026-07-07 19:23:52 --> Model "Order_model" initialized
INFO - 2026-07-07 19:23:52 --> Model "Appsetting_model" initialized
INFO - 2026-07-07 19:23:52 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-07 19:23:52 --> Model "Promocode_model" initialized
DEBUG - 2026-07-07 19:23:52 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-07 19:23:52 --> Model "Plan_model" initialized
INFO - 2026-07-07 19:23:52 --> Model "Orderlicense_model" initialized
INFO - 2026-07-07 19:23:53 --> Final output sent to browser
DEBUG - 2026-07-07 19:23:53 --> Total execution time: 4.0550
INFO - 2026-07-07 19:24:11 --> Config Class Initialized
INFO - 2026-07-07 19:24:11 --> Hooks Class Initialized
DEBUG - 2026-07-07 19:24:11 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:24:11 --> Utf8 Class Initialized
INFO - 2026-07-07 19:24:11 --> URI Class Initialized
INFO - 2026-07-07 19:24:11 --> Router Class Initialized
INFO - 2026-07-07 19:24:11 --> Output Class Initialized
INFO - 2026-07-07 19:24:11 --> Security Class Initialized
DEBUG - 2026-07-07 19:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:24:11 --> CSRF cookie sent
INFO - 2026-07-07 19:24:11 --> Input Class Initialized
INFO - 2026-07-07 19:24:11 --> Language Class Initialized
INFO - 2026-07-07 19:24:11 --> Language Class Initialized
INFO - 2026-07-07 19:24:11 --> Config Class Initialized
INFO - 2026-07-07 19:24:11 --> Loader Class Initialized
INFO - 2026-07-07 19:24:11 --> Helper loaded: url_helper
INFO - 2026-07-07 19:24:11 --> Helper loaded: form_helper
INFO - 2026-07-07 19:24:11 --> Helper loaded: html_helper
INFO - 2026-07-07 19:24:11 --> Helper loaded: file_helper
INFO - 2026-07-07 19:24:11 --> Helper loaded: email_helper
INFO - 2026-07-07 19:24:11 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:24:11 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:24:11 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:24:11 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:24:11 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:24:11 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:24:11 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:24:11 --> Database Driver Class Initialized
INFO - 2026-07-07 19:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:24:14 --> Upload Class Initialized
DEBUG - 2026-07-07 19:24:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:24:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:24:14 --> Encryption Class Initialized
INFO - 2026-07-07 19:24:14 --> Form Validation Class Initialized
INFO - 2026-07-07 19:24:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:24:14 --> Pagination Class Initialized
INFO - 2026-07-07 19:24:14 --> Email Class Initialized
INFO - 2026-07-07 19:24:14 --> Controller Class Initialized
DEBUG - 2026-07-07 19:24:14 --> Pages MX_Controller Initialized
INFO - 2026-07-07 19:24:14 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:24:14 --> Model "Auth_model" initialized
INFO - 2026-07-07 19:24:14 --> Model "Cart_model" initialized
INFO - 2026-07-07 19:24:14 --> Model "Page_model" initialized
INFO - 2026-07-07 19:26:01 --> Config Class Initialized
INFO - 2026-07-07 19:26:01 --> Hooks Class Initialized
DEBUG - 2026-07-07 19:26:01 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:26:01 --> Utf8 Class Initialized
INFO - 2026-07-07 19:26:01 --> URI Class Initialized
INFO - 2026-07-07 19:26:01 --> Router Class Initialized
INFO - 2026-07-07 19:26:01 --> Output Class Initialized
INFO - 2026-07-07 19:26:01 --> Security Class Initialized
DEBUG - 2026-07-07 19:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:26:01 --> CSRF cookie sent
INFO - 2026-07-07 19:26:01 --> Input Class Initialized
INFO - 2026-07-07 19:26:01 --> Language Class Initialized
INFO - 2026-07-07 19:26:01 --> Language Class Initialized
INFO - 2026-07-07 19:26:01 --> Config Class Initialized
INFO - 2026-07-07 19:26:01 --> Loader Class Initialized
INFO - 2026-07-07 19:26:01 --> Helper loaded: url_helper
INFO - 2026-07-07 19:26:01 --> Helper loaded: form_helper
INFO - 2026-07-07 19:26:01 --> Helper loaded: html_helper
INFO - 2026-07-07 19:26:01 --> Helper loaded: file_helper
INFO - 2026-07-07 19:26:01 --> Helper loaded: email_helper
INFO - 2026-07-07 19:26:01 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:26:01 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:26:01 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:26:01 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:26:01 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:26:01 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:26:01 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:26:01 --> Database Driver Class Initialized
INFO - 2026-07-07 19:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:26:03 --> Upload Class Initialized
DEBUG - 2026-07-07 19:26:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:26:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:26:03 --> Encryption Class Initialized
INFO - 2026-07-07 19:26:03 --> Form Validation Class Initialized
INFO - 2026-07-07 19:26:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:26:03 --> Pagination Class Initialized
INFO - 2026-07-07 19:26:03 --> Email Class Initialized
INFO - 2026-07-07 19:26:03 --> Controller Class Initialized
DEBUG - 2026-07-07 19:26:03 --> Auth MX_Controller Initialized
INFO - 2026-07-07 19:26:03 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:26:03 --> Model "Auth_model" initialized
INFO - 2026-07-07 19:26:03 --> Model "Cart_model" initialized
INFO - 2026-07-07 19:26:03 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-07 19:26:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-07 19:26:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-07 19:26:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-07 19:26:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-07-07 19:26:04 --> Final output sent to browser
DEBUG - 2026-07-07 19:26:04 --> Total execution time: 3.5168
INFO - 2026-07-07 19:26:04 --> Config Class Initialized
INFO - 2026-07-07 19:26:04 --> Hooks Class Initialized
DEBUG - 2026-07-07 19:26:04 --> UTF-8 Support Enabled
INFO - 2026-07-07 19:26:04 --> Utf8 Class Initialized
INFO - 2026-07-07 19:26:04 --> URI Class Initialized
INFO - 2026-07-07 19:26:04 --> Router Class Initialized
INFO - 2026-07-07 19:26:04 --> Output Class Initialized
INFO - 2026-07-07 19:26:04 --> Security Class Initialized
DEBUG - 2026-07-07 19:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-07 19:26:04 --> CSRF cookie sent
INFO - 2026-07-07 19:26:04 --> Input Class Initialized
INFO - 2026-07-07 19:26:04 --> Language Class Initialized
INFO - 2026-07-07 19:26:04 --> Language Class Initialized
INFO - 2026-07-07 19:26:04 --> Config Class Initialized
INFO - 2026-07-07 19:26:04 --> Loader Class Initialized
INFO - 2026-07-07 19:26:04 --> Helper loaded: url_helper
INFO - 2026-07-07 19:26:04 --> Helper loaded: form_helper
INFO - 2026-07-07 19:26:04 --> Helper loaded: html_helper
INFO - 2026-07-07 19:26:04 --> Helper loaded: file_helper
INFO - 2026-07-07 19:26:04 --> Helper loaded: email_helper
INFO - 2026-07-07 19:26:04 --> Helper loaded: whmaz_helper
INFO - 2026-07-07 19:26:04 --> Helper loaded: ssp_helper
INFO - 2026-07-07 19:26:04 --> Helper loaded: cpanel_helper
INFO - 2026-07-07 19:26:04 --> Helper loaded: plesk_helper
INFO - 2026-07-07 19:26:04 --> Helper loaded: directadmin_helper
INFO - 2026-07-07 19:26:04 --> Helper loaded: domain_helper
INFO - 2026-07-07 19:26:04 --> Helper loaded: entitlement_helper
INFO - 2026-07-07 19:26:04 --> Database Driver Class Initialized
INFO - 2026-07-07 19:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-07 19:26:09 --> Upload Class Initialized
DEBUG - 2026-07-07 19:26:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-07 19:26:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-07 19:26:09 --> Encryption Class Initialized
INFO - 2026-07-07 19:26:09 --> Form Validation Class Initialized
INFO - 2026-07-07 19:26:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-07 19:26:09 --> Pagination Class Initialized
INFO - 2026-07-07 19:26:09 --> Email Class Initialized
INFO - 2026-07-07 19:26:09 --> Controller Class Initialized
DEBUG - 2026-07-07 19:26:09 --> Cart MX_Controller Initialized
INFO - 2026-07-07 19:26:09 --> Model "Loginattempt_model" initialized
INFO - 2026-07-07 19:26:09 --> Model "Auth_model" initialized
INFO - 2026-07-07 19:26:09 --> Model "Cart_model" initialized
INFO - 2026-07-07 19:26:09 --> Model "Common_model" initialized
INFO - 2026-07-07 19:26:09 --> Model "Order_model" initialized
INFO - 2026-07-07 19:26:09 --> Model "Appsetting_model" initialized
INFO - 2026-07-07 19:26:09 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-07 19:26:09 --> Model "Promocode_model" initialized
DEBUG - 2026-07-07 19:26:09 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-07 19:26:09 --> Model "Plan_model" initialized
INFO - 2026-07-07 19:26:09 --> Model "Orderlicense_model" initialized
INFO - 2026-07-07 19:26:11 --> Final output sent to browser
DEBUG - 2026-07-07 19:26:11 --> Total execution time: 6.3248

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-07-11 18:56:59 --> Config Class Initialized
INFO - 2026-07-11 18:56:59 --> Hooks Class Initialized
DEBUG - 2026-07-11 18:56:59 --> UTF-8 Support Enabled
INFO - 2026-07-11 18:56:59 --> Utf8 Class Initialized
INFO - 2026-07-11 18:56:59 --> URI Class Initialized
DEBUG - 2026-07-11 18:56:59 --> No URI present. Default controller set.
INFO - 2026-07-11 18:56:59 --> Router Class Initialized
INFO - 2026-07-11 18:56:59 --> Output Class Initialized
INFO - 2026-07-11 18:56:59 --> Security Class Initialized
DEBUG - 2026-07-11 18:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-11 18:56:59 --> CSRF cookie sent
INFO - 2026-07-11 18:56:59 --> Input Class Initialized
INFO - 2026-07-11 18:56:59 --> Language Class Initialized
INFO - 2026-07-11 18:56:59 --> Language Class Initialized
INFO - 2026-07-11 18:56:59 --> Config Class Initialized
INFO - 2026-07-11 18:56:59 --> Loader Class Initialized
INFO - 2026-07-11 18:56:59 --> Helper loaded: url_helper
INFO - 2026-07-11 18:56:59 --> Helper loaded: form_helper
INFO - 2026-07-11 18:56:59 --> Helper loaded: html_helper
INFO - 2026-07-11 18:56:59 --> Helper loaded: file_helper
INFO - 2026-07-11 18:56:59 --> Helper loaded: email_helper
INFO - 2026-07-11 18:56:59 --> Helper loaded: whmaz_helper
INFO - 2026-07-11 18:56:59 --> Helper loaded: ssp_helper
INFO - 2026-07-11 18:56:59 --> Helper loaded: cpanel_helper
INFO - 2026-07-11 18:56:59 --> Helper loaded: plesk_helper
INFO - 2026-07-11 18:56:59 --> Helper loaded: directadmin_helper
INFO - 2026-07-11 18:56:59 --> Helper loaded: domain_helper
INFO - 2026-07-11 18:56:59 --> Helper loaded: entitlement_helper
INFO - 2026-07-11 18:56:59 --> Database Driver Class Initialized
INFO - 2026-07-11 18:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-11 18:57:00 --> Upload Class Initialized
DEBUG - 2026-07-11 18:57:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-11 18:57:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-11 18:57:00 --> Encryption Class Initialized
INFO - 2026-07-11 18:57:00 --> Form Validation Class Initialized
INFO - 2026-07-11 18:57:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-11 18:57:00 --> Pagination Class Initialized
INFO - 2026-07-11 18:57:00 --> Email Class Initialized
INFO - 2026-07-11 18:57:00 --> Controller Class Initialized
DEBUG - 2026-07-11 18:57:00 --> Home MX_Controller Initialized
INFO - 2026-07-11 18:57:00 --> Model "Loginattempt_model" initialized
INFO - 2026-07-11 18:57:00 --> Model "Auth_model" initialized
INFO - 2026-07-11 18:57:00 --> Model "Cart_model" initialized
DEBUG - 2026-07-11 18:57:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-11 18:57:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-11 18:57:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-11 18:57:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/home/views/home_view.php
INFO - 2026-07-11 18:57:02 --> Final output sent to browser
DEBUG - 2026-07-11 18:57:02 --> Total execution time: 2.9811
INFO - 2026-07-11 18:57:02 --> Config Class Initialized
INFO - 2026-07-11 18:57:02 --> Hooks Class Initialized
DEBUG - 2026-07-11 18:57:02 --> UTF-8 Support Enabled
INFO - 2026-07-11 18:57:02 --> Utf8 Class Initialized
INFO - 2026-07-11 18:57:02 --> URI Class Initialized
DEBUG - 2026-07-11 18:57:02 --> No URI present. Default controller set.
INFO - 2026-07-11 18:57:02 --> Router Class Initialized
INFO - 2026-07-11 18:57:02 --> Output Class Initialized
INFO - 2026-07-11 18:57:02 --> Security Class Initialized
DEBUG - 2026-07-11 18:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-11 18:57:02 --> CSRF cookie sent
INFO - 2026-07-11 18:57:02 --> Input Class Initialized
INFO - 2026-07-11 18:57:02 --> Language Class Initialized
INFO - 2026-07-11 18:57:02 --> Language Class Initialized
INFO - 2026-07-11 18:57:02 --> Config Class Initialized
INFO - 2026-07-11 18:57:02 --> Loader Class Initialized
INFO - 2026-07-11 18:57:02 --> Helper loaded: url_helper
INFO - 2026-07-11 18:57:02 --> Helper loaded: form_helper
INFO - 2026-07-11 18:57:02 --> Helper loaded: html_helper
INFO - 2026-07-11 18:57:02 --> Helper loaded: file_helper
INFO - 2026-07-11 18:57:02 --> Helper loaded: email_helper
INFO - 2026-07-11 18:57:02 --> Helper loaded: whmaz_helper
INFO - 2026-07-11 18:57:02 --> Helper loaded: ssp_helper
INFO - 2026-07-11 18:57:02 --> Helper loaded: cpanel_helper
INFO - 2026-07-11 18:57:02 --> Helper loaded: plesk_helper
INFO - 2026-07-11 18:57:02 --> Helper loaded: directadmin_helper
INFO - 2026-07-11 18:57:02 --> Helper loaded: domain_helper
INFO - 2026-07-11 18:57:02 --> Helper loaded: entitlement_helper
INFO - 2026-07-11 18:57:02 --> Database Driver Class Initialized
INFO - 2026-07-11 18:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-11 18:57:03 --> Upload Class Initialized
DEBUG - 2026-07-11 18:57:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-11 18:57:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-11 18:57:03 --> Encryption Class Initialized
INFO - 2026-07-11 18:57:03 --> Form Validation Class Initialized
INFO - 2026-07-11 18:57:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-11 18:57:03 --> Pagination Class Initialized
INFO - 2026-07-11 18:57:03 --> Email Class Initialized
INFO - 2026-07-11 18:57:03 --> Controller Class Initialized
DEBUG - 2026-07-11 18:57:03 --> Home MX_Controller Initialized
INFO - 2026-07-11 18:57:03 --> Model "Loginattempt_model" initialized
INFO - 2026-07-11 18:57:03 --> Model "Auth_model" initialized
INFO - 2026-07-11 18:57:03 --> Model "Cart_model" initialized
DEBUG - 2026-07-11 18:57:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-11 18:57:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-11 18:57:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-11 18:57:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/home/views/home_view.php
INFO - 2026-07-11 18:57:05 --> Final output sent to browser
DEBUG - 2026-07-11 18:57:05 --> Total execution time: 2.9055
INFO - 2026-07-11 18:57:15 --> Config Class Initialized
INFO - 2026-07-11 18:57:15 --> Hooks Class Initialized
DEBUG - 2026-07-11 18:57:15 --> UTF-8 Support Enabled
INFO - 2026-07-11 18:57:15 --> Utf8 Class Initialized
INFO - 2026-07-11 18:57:15 --> URI Class Initialized
DEBUG - 2026-07-11 18:57:15 --> No URI present. Default controller set.
INFO - 2026-07-11 18:57:15 --> Router Class Initialized
INFO - 2026-07-11 18:57:15 --> Output Class Initialized
INFO - 2026-07-11 18:57:15 --> Security Class Initialized
DEBUG - 2026-07-11 18:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-11 18:57:15 --> CSRF cookie sent
INFO - 2026-07-11 18:57:15 --> Input Class Initialized
INFO - 2026-07-11 18:57:15 --> Language Class Initialized
INFO - 2026-07-11 18:57:15 --> Language Class Initialized
INFO - 2026-07-11 18:57:15 --> Config Class Initialized
INFO - 2026-07-11 18:57:15 --> Loader Class Initialized
INFO - 2026-07-11 18:57:15 --> Helper loaded: url_helper
INFO - 2026-07-11 18:57:15 --> Helper loaded: form_helper
INFO - 2026-07-11 18:57:15 --> Helper loaded: html_helper
INFO - 2026-07-11 18:57:15 --> Helper loaded: file_helper
INFO - 2026-07-11 18:57:15 --> Helper loaded: email_helper
INFO - 2026-07-11 18:57:15 --> Helper loaded: whmaz_helper
INFO - 2026-07-11 18:57:15 --> Helper loaded: ssp_helper
INFO - 2026-07-11 18:57:15 --> Helper loaded: cpanel_helper
INFO - 2026-07-11 18:57:15 --> Helper loaded: plesk_helper
INFO - 2026-07-11 18:57:15 --> Helper loaded: directadmin_helper
INFO - 2026-07-11 18:57:15 --> Helper loaded: domain_helper
INFO - 2026-07-11 18:57:15 --> Helper loaded: entitlement_helper
INFO - 2026-07-11 18:57:15 --> Database Driver Class Initialized
INFO - 2026-07-11 18:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-11 18:57:17 --> Upload Class Initialized
DEBUG - 2026-07-11 18:57:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-11 18:57:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-11 18:57:17 --> Encryption Class Initialized
INFO - 2026-07-11 18:57:17 --> Form Validation Class Initialized
INFO - 2026-07-11 18:57:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-11 18:57:17 --> Pagination Class Initialized
INFO - 2026-07-11 18:57:17 --> Email Class Initialized
INFO - 2026-07-11 18:57:17 --> Controller Class Initialized
DEBUG - 2026-07-11 18:57:17 --> Home MX_Controller Initialized
INFO - 2026-07-11 18:57:17 --> Model "Loginattempt_model" initialized
INFO - 2026-07-11 18:57:17 --> Model "Auth_model" initialized
INFO - 2026-07-11 18:57:17 --> Model "Cart_model" initialized
DEBUG - 2026-07-11 18:57:17 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-11 18:57:17 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-11 18:57:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-11 18:57:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/home/views/home_view.php
INFO - 2026-07-11 18:57:19 --> Final output sent to browser
DEBUG - 2026-07-11 18:57:19 --> Total execution time: 3.7680
INFO - 2026-07-11 18:57:23 --> Config Class Initialized
INFO - 2026-07-11 18:57:23 --> Hooks Class Initialized
DEBUG - 2026-07-11 18:57:23 --> UTF-8 Support Enabled
INFO - 2026-07-11 18:57:23 --> Utf8 Class Initialized
INFO - 2026-07-11 18:57:23 --> URI Class Initialized
DEBUG - 2026-07-11 18:57:23 --> No URI present. Default controller set.
INFO - 2026-07-11 18:57:23 --> Router Class Initialized
INFO - 2026-07-11 18:57:23 --> Output Class Initialized
INFO - 2026-07-11 18:57:23 --> Security Class Initialized
DEBUG - 2026-07-11 18:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-11 18:57:23 --> CSRF cookie sent
INFO - 2026-07-11 18:57:23 --> Input Class Initialized
INFO - 2026-07-11 18:57:23 --> Language Class Initialized
INFO - 2026-07-11 18:57:23 --> Language Class Initialized
INFO - 2026-07-11 18:57:23 --> Config Class Initialized
INFO - 2026-07-11 18:57:23 --> Loader Class Initialized
INFO - 2026-07-11 18:57:23 --> Helper loaded: url_helper
INFO - 2026-07-11 18:57:23 --> Helper loaded: form_helper
INFO - 2026-07-11 18:57:23 --> Helper loaded: html_helper
INFO - 2026-07-11 18:57:23 --> Helper loaded: file_helper
INFO - 2026-07-11 18:57:23 --> Helper loaded: email_helper
INFO - 2026-07-11 18:57:23 --> Helper loaded: whmaz_helper
INFO - 2026-07-11 18:57:23 --> Helper loaded: ssp_helper
INFO - 2026-07-11 18:57:23 --> Helper loaded: cpanel_helper
INFO - 2026-07-11 18:57:23 --> Helper loaded: plesk_helper
INFO - 2026-07-11 18:57:23 --> Helper loaded: directadmin_helper
INFO - 2026-07-11 18:57:23 --> Helper loaded: domain_helper
INFO - 2026-07-11 18:57:23 --> Helper loaded: entitlement_helper
INFO - 2026-07-11 18:57:23 --> Database Driver Class Initialized
INFO - 2026-07-11 18:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-11 18:57:27 --> Upload Class Initialized
DEBUG - 2026-07-11 18:57:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-11 18:57:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-11 18:57:27 --> Encryption Class Initialized
INFO - 2026-07-11 18:57:27 --> Form Validation Class Initialized
INFO - 2026-07-11 18:57:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-11 18:57:27 --> Pagination Class Initialized
INFO - 2026-07-11 18:57:27 --> Email Class Initialized
INFO - 2026-07-11 18:57:27 --> Controller Class Initialized
DEBUG - 2026-07-11 18:57:27 --> Home MX_Controller Initialized
INFO - 2026-07-11 18:57:27 --> Model "Loginattempt_model" initialized
INFO - 2026-07-11 18:57:27 --> Model "Auth_model" initialized
INFO - 2026-07-11 18:57:27 --> Model "Cart_model" initialized
DEBUG - 2026-07-11 18:57:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-11 18:57:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-11 18:57:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-11 18:57:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/home/views/home_view.php
INFO - 2026-07-11 18:57:28 --> Final output sent to browser
DEBUG - 2026-07-11 18:57:28 --> Total execution time: 5.0861
INFO - 2026-07-11 18:57:29 --> Config Class Initialized
INFO - 2026-07-11 18:57:29 --> Hooks Class Initialized
DEBUG - 2026-07-11 18:57:29 --> UTF-8 Support Enabled
INFO - 2026-07-11 18:57:29 --> Utf8 Class Initialized
INFO - 2026-07-11 18:57:29 --> URI Class Initialized
INFO - 2026-07-11 18:57:29 --> Router Class Initialized
INFO - 2026-07-11 18:57:29 --> Output Class Initialized
INFO - 2026-07-11 18:57:29 --> Security Class Initialized
DEBUG - 2026-07-11 18:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-11 18:57:29 --> CSRF cookie sent
INFO - 2026-07-11 18:57:29 --> Input Class Initialized
INFO - 2026-07-11 18:57:29 --> Language Class Initialized
INFO - 2026-07-11 18:57:29 --> Language Class Initialized
INFO - 2026-07-11 18:57:29 --> Config Class Initialized
INFO - 2026-07-11 18:57:29 --> Loader Class Initialized
INFO - 2026-07-11 18:57:29 --> Helper loaded: url_helper
INFO - 2026-07-11 18:57:29 --> Helper loaded: form_helper
INFO - 2026-07-11 18:57:29 --> Helper loaded: html_helper
INFO - 2026-07-11 18:57:29 --> Helper loaded: file_helper
INFO - 2026-07-11 18:57:29 --> Helper loaded: email_helper
INFO - 2026-07-11 18:57:29 --> Helper loaded: whmaz_helper
INFO - 2026-07-11 18:57:29 --> Helper loaded: ssp_helper
INFO - 2026-07-11 18:57:29 --> Helper loaded: cpanel_helper
INFO - 2026-07-11 18:57:29 --> Helper loaded: plesk_helper
INFO - 2026-07-11 18:57:29 --> Helper loaded: directadmin_helper
INFO - 2026-07-11 18:57:29 --> Helper loaded: domain_helper
INFO - 2026-07-11 18:57:29 --> Helper loaded: entitlement_helper
INFO - 2026-07-11 18:57:29 --> Database Driver Class Initialized
INFO - 2026-07-11 18:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-11 18:57:30 --> Upload Class Initialized
DEBUG - 2026-07-11 18:57:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-11 18:57:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-11 18:57:30 --> Encryption Class Initialized
INFO - 2026-07-11 18:57:30 --> Form Validation Class Initialized
INFO - 2026-07-11 18:57:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-11 18:57:30 --> Pagination Class Initialized
INFO - 2026-07-11 18:57:30 --> Email Class Initialized
INFO - 2026-07-11 18:57:30 --> Controller Class Initialized
DEBUG - 2026-07-11 18:57:30 --> Cart MX_Controller Initialized
INFO - 2026-07-11 18:57:30 --> Model "Loginattempt_model" initialized
INFO - 2026-07-11 18:57:30 --> Model "Auth_model" initialized
INFO - 2026-07-11 18:57:30 --> Model "Cart_model" initialized
INFO - 2026-07-11 18:57:30 --> Model "Common_model" initialized
INFO - 2026-07-11 18:57:30 --> Model "Order_model" initialized
INFO - 2026-07-11 18:57:30 --> Model "Appsetting_model" initialized
INFO - 2026-07-11 18:57:30 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-11 18:57:30 --> Model "Promocode_model" initialized
DEBUG - 2026-07-11 18:57:30 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-11 18:57:30 --> Model "Plan_model" initialized
INFO - 2026-07-11 18:57:30 --> Model "Orderlicense_model" initialized
INFO - 2026-07-11 18:57:31 --> Final output sent to browser
DEBUG - 2026-07-11 18:57:31 --> Total execution time: 2.0466
INFO - 2026-07-11 18:57:31 --> Config Class Initialized
INFO - 2026-07-11 18:57:31 --> Hooks Class Initialized
DEBUG - 2026-07-11 18:57:31 --> UTF-8 Support Enabled
INFO - 2026-07-11 18:57:31 --> Utf8 Class Initialized
INFO - 2026-07-11 18:57:31 --> URI Class Initialized
INFO - 2026-07-11 18:57:31 --> Router Class Initialized
INFO - 2026-07-11 18:57:31 --> Output Class Initialized
INFO - 2026-07-11 18:57:31 --> Security Class Initialized
DEBUG - 2026-07-11 18:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-11 18:57:31 --> CSRF cookie sent
INFO - 2026-07-11 18:57:31 --> Input Class Initialized
INFO - 2026-07-11 18:57:31 --> Language Class Initialized
INFO - 2026-07-11 18:57:31 --> Language Class Initialized
INFO - 2026-07-11 18:57:31 --> Config Class Initialized
INFO - 2026-07-11 18:57:31 --> Loader Class Initialized
INFO - 2026-07-11 18:57:31 --> Helper loaded: url_helper
INFO - 2026-07-11 18:57:31 --> Helper loaded: form_helper
INFO - 2026-07-11 18:57:31 --> Helper loaded: html_helper
INFO - 2026-07-11 18:57:31 --> Helper loaded: file_helper
INFO - 2026-07-11 18:57:31 --> Helper loaded: email_helper
INFO - 2026-07-11 18:57:31 --> Helper loaded: whmaz_helper
INFO - 2026-07-11 18:57:31 --> Helper loaded: ssp_helper
INFO - 2026-07-11 18:57:31 --> Helper loaded: cpanel_helper
INFO - 2026-07-11 18:57:31 --> Helper loaded: plesk_helper
INFO - 2026-07-11 18:57:31 --> Helper loaded: directadmin_helper
INFO - 2026-07-11 18:57:31 --> Helper loaded: domain_helper
INFO - 2026-07-11 18:57:31 --> Helper loaded: entitlement_helper
INFO - 2026-07-11 18:57:31 --> Database Driver Class Initialized
INFO - 2026-07-11 18:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-11 18:57:33 --> Upload Class Initialized
DEBUG - 2026-07-11 18:57:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-11 18:57:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-11 18:57:33 --> Encryption Class Initialized
INFO - 2026-07-11 18:57:33 --> Form Validation Class Initialized
INFO - 2026-07-11 18:57:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-11 18:57:33 --> Pagination Class Initialized
INFO - 2026-07-11 18:57:33 --> Email Class Initialized
INFO - 2026-07-11 18:57:33 --> Controller Class Initialized
DEBUG - 2026-07-11 18:57:33 --> Auth MX_Controller Initialized
INFO - 2026-07-11 18:57:33 --> Model "Loginattempt_model" initialized
INFO - 2026-07-11 18:57:33 --> Model "Auth_model" initialized
INFO - 2026-07-11 18:57:33 --> Model "Cart_model" initialized
INFO - 2026-07-11 18:57:33 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-11 18:57:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-11 18:57:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-11 18:57:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-11 18:57:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-07-11 18:57:34 --> Final output sent to browser
DEBUG - 2026-07-11 18:57:34 --> Total execution time: 2.8365
INFO - 2026-07-11 18:57:34 --> Config Class Initialized
INFO - 2026-07-11 18:57:34 --> Hooks Class Initialized
DEBUG - 2026-07-11 18:57:34 --> UTF-8 Support Enabled
INFO - 2026-07-11 18:57:34 --> Utf8 Class Initialized
INFO - 2026-07-11 18:57:34 --> URI Class Initialized
INFO - 2026-07-11 18:57:34 --> Router Class Initialized
INFO - 2026-07-11 18:57:34 --> Output Class Initialized
INFO - 2026-07-11 18:57:34 --> Security Class Initialized
DEBUG - 2026-07-11 18:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-11 18:57:34 --> CSRF cookie sent
INFO - 2026-07-11 18:57:34 --> Input Class Initialized
INFO - 2026-07-11 18:57:34 --> Language Class Initialized
INFO - 2026-07-11 18:57:34 --> Language Class Initialized
INFO - 2026-07-11 18:57:34 --> Config Class Initialized
INFO - 2026-07-11 18:57:34 --> Loader Class Initialized
INFO - 2026-07-11 18:57:34 --> Helper loaded: url_helper
INFO - 2026-07-11 18:57:34 --> Helper loaded: form_helper
INFO - 2026-07-11 18:57:34 --> Helper loaded: html_helper
INFO - 2026-07-11 18:57:34 --> Helper loaded: file_helper
INFO - 2026-07-11 18:57:34 --> Helper loaded: email_helper
INFO - 2026-07-11 18:57:34 --> Helper loaded: whmaz_helper
INFO - 2026-07-11 18:57:34 --> Helper loaded: ssp_helper
INFO - 2026-07-11 18:57:34 --> Helper loaded: cpanel_helper
INFO - 2026-07-11 18:57:34 --> Helper loaded: plesk_helper
INFO - 2026-07-11 18:57:34 --> Helper loaded: directadmin_helper
INFO - 2026-07-11 18:57:34 --> Helper loaded: domain_helper
INFO - 2026-07-11 18:57:34 --> Helper loaded: entitlement_helper
INFO - 2026-07-11 18:57:34 --> Database Driver Class Initialized
INFO - 2026-07-11 18:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-11 18:57:36 --> Upload Class Initialized
DEBUG - 2026-07-11 18:57:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-11 18:57:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-11 18:57:36 --> Encryption Class Initialized
INFO - 2026-07-11 18:57:36 --> Form Validation Class Initialized
INFO - 2026-07-11 18:57:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-11 18:57:36 --> Pagination Class Initialized
INFO - 2026-07-11 18:57:36 --> Email Class Initialized
INFO - 2026-07-11 18:57:36 --> Controller Class Initialized
DEBUG - 2026-07-11 18:57:36 --> Auth MX_Controller Initialized
INFO - 2026-07-11 18:57:36 --> Model "Loginattempt_model" initialized
INFO - 2026-07-11 18:57:36 --> Model "Auth_model" initialized
INFO - 2026-07-11 18:57:36 --> Model "Cart_model" initialized
INFO - 2026-07-11 18:57:36 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-11 18:57:37 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-11 18:57:37 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-11 18:57:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-11 18:57:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_register.php
INFO - 2026-07-11 18:57:38 --> Final output sent to browser
DEBUG - 2026-07-11 18:57:38 --> Total execution time: 3.6662

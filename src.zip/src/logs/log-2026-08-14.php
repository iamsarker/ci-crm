<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-08-14 05:53:18 --> Config Class Initialized
INFO - 2026-08-14 05:53:18 --> Hooks Class Initialized
DEBUG - 2026-08-14 05:53:18 --> UTF-8 Support Enabled
INFO - 2026-08-14 05:53:18 --> Utf8 Class Initialized
INFO - 2026-08-14 05:53:18 --> URI Class Initialized
DEBUG - 2026-08-14 05:53:18 --> No URI present. Default controller set.
INFO - 2026-08-14 05:53:18 --> Router Class Initialized
INFO - 2026-08-14 05:53:18 --> Output Class Initialized
INFO - 2026-08-14 05:53:18 --> Security Class Initialized
DEBUG - 2026-08-14 05:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-14 05:53:18 --> CSRF cookie sent
INFO - 2026-08-14 05:53:18 --> Input Class Initialized
INFO - 2026-08-14 05:53:18 --> Language Class Initialized
INFO - 2026-08-14 05:53:18 --> Language Class Initialized
INFO - 2026-08-14 05:53:18 --> Config Class Initialized
INFO - 2026-08-14 05:53:18 --> Loader Class Initialized
INFO - 2026-08-14 05:53:18 --> Helper loaded: url_helper
INFO - 2026-08-14 05:53:18 --> Helper loaded: form_helper
INFO - 2026-08-14 05:53:18 --> Helper loaded: html_helper
INFO - 2026-08-14 05:53:18 --> Helper loaded: file_helper
INFO - 2026-08-14 05:53:18 --> Helper loaded: email_helper
INFO - 2026-08-14 05:53:18 --> Helper loaded: whmaz_helper
INFO - 2026-08-14 05:53:18 --> Helper loaded: ssp_helper
INFO - 2026-08-14 05:53:18 --> Helper loaded: cpanel_helper
INFO - 2026-08-14 05:53:18 --> Helper loaded: plesk_helper
INFO - 2026-08-14 05:53:18 --> Helper loaded: directadmin_helper
INFO - 2026-08-14 05:53:18 --> Helper loaded: domain_helper
INFO - 2026-08-14 05:53:18 --> Helper loaded: entitlement_helper
INFO - 2026-08-14 05:53:18 --> Database Driver Class Initialized
INFO - 2026-08-14 05:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-14 05:53:19 --> Upload Class Initialized
DEBUG - 2026-08-14 05:53:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-14 05:53:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-14 05:53:19 --> Encryption Class Initialized
INFO - 2026-08-14 05:53:19 --> Form Validation Class Initialized
INFO - 2026-08-14 05:53:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-14 05:53:19 --> Pagination Class Initialized
INFO - 2026-08-14 05:53:19 --> Email Class Initialized
INFO - 2026-08-14 05:53:19 --> Controller Class Initialized
DEBUG - 2026-08-14 05:53:19 --> Home MX_Controller Initialized
INFO - 2026-08-14 05:53:19 --> Model "Loginattempt_model" initialized
INFO - 2026-08-14 05:53:19 --> Model "Auth_model" initialized
INFO - 2026-08-14 05:53:19 --> Model "Cart_model" initialized
DEBUG - 2026-08-14 05:53:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-14 05:53:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-14 05:53:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-14 05:53:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/home/views/home_view.php
INFO - 2026-08-14 05:53:20 --> Final output sent to browser
DEBUG - 2026-08-14 05:53:20 --> Total execution time: 2.6767
INFO - 2026-08-14 05:53:21 --> Config Class Initialized
INFO - 2026-08-14 05:53:21 --> Hooks Class Initialized
DEBUG - 2026-08-14 05:53:21 --> UTF-8 Support Enabled
INFO - 2026-08-14 05:53:21 --> Utf8 Class Initialized
INFO - 2026-08-14 05:53:21 --> URI Class Initialized
INFO - 2026-08-14 05:53:21 --> Router Class Initialized
INFO - 2026-08-14 05:53:21 --> Output Class Initialized
INFO - 2026-08-14 05:53:21 --> Security Class Initialized
DEBUG - 2026-08-14 05:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-14 05:53:21 --> CSRF cookie sent
INFO - 2026-08-14 05:53:21 --> Input Class Initialized
INFO - 2026-08-14 05:53:21 --> Language Class Initialized
INFO - 2026-08-14 05:53:21 --> Language Class Initialized
INFO - 2026-08-14 05:53:21 --> Config Class Initialized
INFO - 2026-08-14 05:53:21 --> Loader Class Initialized
INFO - 2026-08-14 05:53:21 --> Helper loaded: url_helper
INFO - 2026-08-14 05:53:21 --> Helper loaded: form_helper
INFO - 2026-08-14 05:53:21 --> Helper loaded: html_helper
INFO - 2026-08-14 05:53:21 --> Helper loaded: file_helper
INFO - 2026-08-14 05:53:21 --> Helper loaded: email_helper
INFO - 2026-08-14 05:53:21 --> Helper loaded: whmaz_helper
INFO - 2026-08-14 05:53:21 --> Helper loaded: ssp_helper
INFO - 2026-08-14 05:53:21 --> Helper loaded: cpanel_helper
INFO - 2026-08-14 05:53:21 --> Helper loaded: plesk_helper
INFO - 2026-08-14 05:53:21 --> Helper loaded: directadmin_helper
INFO - 2026-08-14 05:53:21 --> Helper loaded: domain_helper
INFO - 2026-08-14 05:53:21 --> Helper loaded: entitlement_helper
INFO - 2026-08-14 05:53:21 --> Database Driver Class Initialized
INFO - 2026-08-14 05:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-14 05:53:22 --> Upload Class Initialized
DEBUG - 2026-08-14 05:53:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-14 05:53:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-14 05:53:22 --> Encryption Class Initialized
INFO - 2026-08-14 05:53:22 --> Form Validation Class Initialized
INFO - 2026-08-14 05:53:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-14 05:53:22 --> Pagination Class Initialized
INFO - 2026-08-14 05:53:22 --> Email Class Initialized
INFO - 2026-08-14 05:53:22 --> Controller Class Initialized
DEBUG - 2026-08-14 05:53:22 --> Cart MX_Controller Initialized
INFO - 2026-08-14 05:53:22 --> Model "Loginattempt_model" initialized
INFO - 2026-08-14 05:53:22 --> Model "Auth_model" initialized
INFO - 2026-08-14 05:53:22 --> Model "Cart_model" initialized
INFO - 2026-08-14 05:53:22 --> Model "Common_model" initialized
INFO - 2026-08-14 05:53:22 --> Model "Order_model" initialized
INFO - 2026-08-14 05:53:22 --> Model "Appsetting_model" initialized
INFO - 2026-08-14 05:53:22 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-14 05:53:22 --> Model "Promocode_model" initialized
DEBUG - 2026-08-14 05:53:22 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-08-14 05:53:22 --> Model "Plan_model" initialized
INFO - 2026-08-14 05:53:22 --> Model "Orderlicense_model" initialized
INFO - 2026-08-14 05:53:23 --> Final output sent to browser
DEBUG - 2026-08-14 05:53:23 --> Total execution time: 1.8850
INFO - 2026-08-14 05:53:28 --> Config Class Initialized
INFO - 2026-08-14 05:53:28 --> Hooks Class Initialized
DEBUG - 2026-08-14 05:53:28 --> UTF-8 Support Enabled
INFO - 2026-08-14 05:53:28 --> Utf8 Class Initialized
INFO - 2026-08-14 05:53:28 --> URI Class Initialized
INFO - 2026-08-14 05:53:28 --> Router Class Initialized
INFO - 2026-08-14 05:53:28 --> Output Class Initialized
INFO - 2026-08-14 05:53:28 --> Security Class Initialized
DEBUG - 2026-08-14 05:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-14 05:53:28 --> CSRF cookie sent
INFO - 2026-08-14 05:53:28 --> Input Class Initialized
INFO - 2026-08-14 05:53:28 --> Language Class Initialized
INFO - 2026-08-14 05:53:28 --> Language Class Initialized
INFO - 2026-08-14 05:53:28 --> Config Class Initialized
INFO - 2026-08-14 05:53:28 --> Loader Class Initialized
INFO - 2026-08-14 05:53:28 --> Helper loaded: url_helper
INFO - 2026-08-14 05:53:28 --> Helper loaded: form_helper
INFO - 2026-08-14 05:53:28 --> Helper loaded: html_helper
INFO - 2026-08-14 05:53:28 --> Helper loaded: file_helper
INFO - 2026-08-14 05:53:28 --> Helper loaded: email_helper
INFO - 2026-08-14 05:53:28 --> Helper loaded: whmaz_helper
INFO - 2026-08-14 05:53:28 --> Helper loaded: ssp_helper
INFO - 2026-08-14 05:53:28 --> Helper loaded: cpanel_helper
INFO - 2026-08-14 05:53:28 --> Helper loaded: plesk_helper
INFO - 2026-08-14 05:53:28 --> Helper loaded: directadmin_helper
INFO - 2026-08-14 05:53:28 --> Helper loaded: domain_helper
INFO - 2026-08-14 05:53:28 --> Helper loaded: entitlement_helper
INFO - 2026-08-14 05:53:28 --> Database Driver Class Initialized
INFO - 2026-08-14 05:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-14 05:53:30 --> Upload Class Initialized
DEBUG - 2026-08-14 05:53:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-14 05:53:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-14 05:53:30 --> Encryption Class Initialized
INFO - 2026-08-14 05:53:30 --> Form Validation Class Initialized
INFO - 2026-08-14 05:53:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-14 05:53:30 --> Pagination Class Initialized
INFO - 2026-08-14 05:53:30 --> Email Class Initialized
INFO - 2026-08-14 05:53:30 --> Controller Class Initialized
DEBUG - 2026-08-14 05:53:30 --> Dashboard MX_Controller Initialized
INFO - 2026-08-14 05:53:30 --> Model "Loginattempt_model" initialized
INFO - 2026-08-14 05:53:30 --> Model "Adminauth_model" initialized
INFO - 2026-08-14 05:53:30 --> Config Class Initialized
INFO - 2026-08-14 05:53:30 --> Hooks Class Initialized
DEBUG - 2026-08-14 05:53:30 --> UTF-8 Support Enabled
INFO - 2026-08-14 05:53:30 --> Utf8 Class Initialized
INFO - 2026-08-14 05:53:30 --> URI Class Initialized
INFO - 2026-08-14 05:53:30 --> Router Class Initialized
INFO - 2026-08-14 05:53:30 --> Output Class Initialized
INFO - 2026-08-14 05:53:30 --> Security Class Initialized
DEBUG - 2026-08-14 05:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-14 05:53:30 --> CSRF cookie sent
INFO - 2026-08-14 05:53:30 --> Input Class Initialized
INFO - 2026-08-14 05:53:30 --> Language Class Initialized
INFO - 2026-08-14 05:53:30 --> Language Class Initialized
INFO - 2026-08-14 05:53:30 --> Config Class Initialized
INFO - 2026-08-14 05:53:30 --> Loader Class Initialized
INFO - 2026-08-14 05:53:30 --> Helper loaded: url_helper
INFO - 2026-08-14 05:53:30 --> Helper loaded: form_helper
INFO - 2026-08-14 05:53:30 --> Helper loaded: html_helper
INFO - 2026-08-14 05:53:30 --> Helper loaded: file_helper
INFO - 2026-08-14 05:53:30 --> Helper loaded: email_helper
INFO - 2026-08-14 05:53:30 --> Helper loaded: whmaz_helper
INFO - 2026-08-14 05:53:30 --> Helper loaded: ssp_helper
INFO - 2026-08-14 05:53:30 --> Helper loaded: cpanel_helper
INFO - 2026-08-14 05:53:30 --> Helper loaded: plesk_helper
INFO - 2026-08-14 05:53:30 --> Helper loaded: directadmin_helper
INFO - 2026-08-14 05:53:30 --> Helper loaded: domain_helper
INFO - 2026-08-14 05:53:30 --> Helper loaded: entitlement_helper
INFO - 2026-08-14 05:53:30 --> Database Driver Class Initialized
INFO - 2026-08-14 05:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-14 05:53:32 --> Upload Class Initialized
DEBUG - 2026-08-14 05:53:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-14 05:53:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-14 05:53:32 --> Encryption Class Initialized
INFO - 2026-08-14 05:53:32 --> Form Validation Class Initialized
INFO - 2026-08-14 05:53:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-14 05:53:32 --> Pagination Class Initialized
INFO - 2026-08-14 05:53:32 --> Email Class Initialized
INFO - 2026-08-14 05:53:32 --> Controller Class Initialized
DEBUG - 2026-08-14 05:53:32 --> Authenticate MX_Controller Initialized
INFO - 2026-08-14 05:53:32 --> Model "Loginattempt_model" initialized
INFO - 2026-08-14 05:53:32 --> Model "Adminauth_model" initialized
INFO - 2026-08-14 05:53:32 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-14 05:53:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-08-14 05:53:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-08-14 05:53:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-08-14 05:53:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-08-14 05:53:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-08-14 05:53:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-08-14 05:53:32 --> Final output sent to browser
DEBUG - 2026-08-14 05:53:32 --> Total execution time: 2.1413
INFO - 2026-08-14 05:53:39 --> Config Class Initialized
INFO - 2026-08-14 05:53:39 --> Hooks Class Initialized
DEBUG - 2026-08-14 05:53:39 --> UTF-8 Support Enabled
INFO - 2026-08-14 05:53:39 --> Utf8 Class Initialized
INFO - 2026-08-14 05:53:39 --> URI Class Initialized
INFO - 2026-08-14 05:53:39 --> Router Class Initialized
INFO - 2026-08-14 05:53:39 --> Output Class Initialized
INFO - 2026-08-14 05:53:39 --> Security Class Initialized
DEBUG - 2026-08-14 05:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-14 05:53:39 --> CSRF cookie sent
INFO - 2026-08-14 05:53:39 --> CSRF token verified
INFO - 2026-08-14 05:53:39 --> Input Class Initialized
INFO - 2026-08-14 05:53:39 --> Language Class Initialized
INFO - 2026-08-14 05:53:39 --> Language Class Initialized
INFO - 2026-08-14 05:53:39 --> Config Class Initialized
INFO - 2026-08-14 05:53:39 --> Loader Class Initialized
INFO - 2026-08-14 05:53:39 --> Helper loaded: url_helper
INFO - 2026-08-14 05:53:39 --> Helper loaded: form_helper
INFO - 2026-08-14 05:53:39 --> Helper loaded: html_helper
INFO - 2026-08-14 05:53:39 --> Helper loaded: file_helper
INFO - 2026-08-14 05:53:39 --> Helper loaded: email_helper
INFO - 2026-08-14 05:53:39 --> Helper loaded: whmaz_helper
INFO - 2026-08-14 05:53:39 --> Helper loaded: ssp_helper
INFO - 2026-08-14 05:53:39 --> Helper loaded: cpanel_helper
INFO - 2026-08-14 05:53:39 --> Helper loaded: plesk_helper
INFO - 2026-08-14 05:53:39 --> Helper loaded: directadmin_helper
INFO - 2026-08-14 05:53:39 --> Helper loaded: domain_helper
INFO - 2026-08-14 05:53:39 --> Helper loaded: entitlement_helper
INFO - 2026-08-14 05:53:39 --> Database Driver Class Initialized
INFO - 2026-08-14 05:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-14 05:53:41 --> Upload Class Initialized
DEBUG - 2026-08-14 05:53:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-14 05:53:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-14 05:53:41 --> Encryption Class Initialized
INFO - 2026-08-14 05:53:41 --> Form Validation Class Initialized
INFO - 2026-08-14 05:53:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-14 05:53:41 --> Pagination Class Initialized
INFO - 2026-08-14 05:53:41 --> Email Class Initialized
INFO - 2026-08-14 05:53:41 --> Controller Class Initialized
DEBUG - 2026-08-14 05:53:41 --> Authenticate MX_Controller Initialized
INFO - 2026-08-14 05:53:41 --> Model "Loginattempt_model" initialized
INFO - 2026-08-14 05:53:41 --> Model "Adminauth_model" initialized
INFO - 2026-08-14 05:53:41 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-14 05:53:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-08-14 05:53:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-08-14 05:53:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-08-14 05:53:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-08-14 05:53:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-08-14 05:53:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-08-14 05:53:42 --> Final output sent to browser
DEBUG - 2026-08-14 05:53:42 --> Total execution time: 3.4721
INFO - 2026-08-14 06:03:48 --> Config Class Initialized
INFO - 2026-08-14 06:03:48 --> Hooks Class Initialized
DEBUG - 2026-08-14 06:03:48 --> UTF-8 Support Enabled
INFO - 2026-08-14 06:03:48 --> Utf8 Class Initialized
INFO - 2026-08-14 06:03:48 --> URI Class Initialized
INFO - 2026-08-14 06:03:48 --> Router Class Initialized
INFO - 2026-08-14 06:03:48 --> Output Class Initialized
INFO - 2026-08-14 06:03:48 --> Security Class Initialized
DEBUG - 2026-08-14 06:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-14 06:03:48 --> CSRF cookie sent
INFO - 2026-08-14 06:03:48 --> CSRF token verified
INFO - 2026-08-14 06:03:48 --> Input Class Initialized
INFO - 2026-08-14 06:03:48 --> Language Class Initialized
INFO - 2026-08-14 06:03:48 --> Language Class Initialized
INFO - 2026-08-14 06:03:48 --> Config Class Initialized
INFO - 2026-08-14 06:03:48 --> Loader Class Initialized
INFO - 2026-08-14 06:03:48 --> Helper loaded: url_helper
INFO - 2026-08-14 06:03:48 --> Helper loaded: form_helper
INFO - 2026-08-14 06:03:48 --> Helper loaded: html_helper
INFO - 2026-08-14 06:03:48 --> Helper loaded: file_helper
INFO - 2026-08-14 06:03:48 --> Helper loaded: email_helper
INFO - 2026-08-14 06:03:48 --> Helper loaded: whmaz_helper
INFO - 2026-08-14 06:03:48 --> Helper loaded: ssp_helper
INFO - 2026-08-14 06:03:48 --> Helper loaded: cpanel_helper
INFO - 2026-08-14 06:03:48 --> Helper loaded: plesk_helper
INFO - 2026-08-14 06:03:48 --> Helper loaded: directadmin_helper
INFO - 2026-08-14 06:03:48 --> Helper loaded: domain_helper
INFO - 2026-08-14 06:03:48 --> Helper loaded: entitlement_helper
INFO - 2026-08-14 06:03:48 --> Database Driver Class Initialized
INFO - 2026-08-14 06:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-14 06:03:50 --> Upload Class Initialized
DEBUG - 2026-08-14 06:03:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-14 06:03:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-14 06:03:50 --> Encryption Class Initialized
INFO - 2026-08-14 06:03:50 --> Form Validation Class Initialized
INFO - 2026-08-14 06:03:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-14 06:03:50 --> Pagination Class Initialized
INFO - 2026-08-14 06:03:50 --> Email Class Initialized
INFO - 2026-08-14 06:03:50 --> Controller Class Initialized
DEBUG - 2026-08-14 06:03:50 --> Authenticate MX_Controller Initialized
INFO - 2026-08-14 06:03:50 --> Model "Loginattempt_model" initialized
INFO - 2026-08-14 06:03:50 --> Model "Adminauth_model" initialized
INFO - 2026-08-14 06:03:50 --> Model "Appsetting_model" initialized
DEBUG - 2026-08-14 06:03:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-08-14 06:03:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-08-14 06:03:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-08-14 06:03:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-08-14 06:03:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-08-14 06:03:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-08-14 06:03:51 --> Final output sent to browser
DEBUG - 2026-08-14 06:03:51 --> Total execution time: 2.9014

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-03-15 15:01:22 --> Config Class Initialized
INFO - 2026-03-15 15:01:22 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:01:22 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:01:22 --> Utf8 Class Initialized
INFO - 2026-03-15 15:01:22 --> URI Class Initialized
DEBUG - 2026-03-15 15:01:22 --> No URI present. Default controller set.
INFO - 2026-03-15 15:01:22 --> Router Class Initialized
INFO - 2026-03-15 15:01:22 --> Output Class Initialized
INFO - 2026-03-15 15:01:22 --> Security Class Initialized
DEBUG - 2026-03-15 15:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:01:22 --> CSRF cookie sent
INFO - 2026-03-15 15:01:22 --> Input Class Initialized
INFO - 2026-03-15 15:01:22 --> Language Class Initialized
INFO - 2026-03-15 15:01:22 --> Language Class Initialized
INFO - 2026-03-15 15:01:22 --> Config Class Initialized
INFO - 2026-03-15 15:01:22 --> Loader Class Initialized
INFO - 2026-03-15 15:01:22 --> Helper loaded: url_helper
INFO - 2026-03-15 15:01:22 --> Helper loaded: form_helper
INFO - 2026-03-15 15:01:22 --> Helper loaded: html_helper
INFO - 2026-03-15 15:01:22 --> Helper loaded: file_helper
INFO - 2026-03-15 15:01:22 --> Helper loaded: email_helper
INFO - 2026-03-15 15:01:22 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:01:22 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:01:22 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:01:22 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:01:22 --> Database Driver Class Initialized
INFO - 2026-03-15 15:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:01:24 --> Upload Class Initialized
DEBUG - 2026-03-15 15:01:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:01:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:01:24 --> Encryption Class Initialized
INFO - 2026-03-15 15:01:24 --> Form Validation Class Initialized
INFO - 2026-03-15 15:01:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:01:24 --> Pagination Class Initialized
INFO - 2026-03-15 15:01:24 --> Email Class Initialized
INFO - 2026-03-15 15:01:24 --> Controller Class Initialized
DEBUG - 2026-03-15 15:01:24 --> Auth MX_Controller Initialized
INFO - 2026-03-15 15:01:24 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:01:24 --> Model "Auth_model" initialized
INFO - 2026-03-15 15:01:24 --> Model "Cart_model" initialized
INFO - 2026-03-15 15:01:25 --> Model "Appsetting_model" initialized
INFO - 2026-03-15 15:01:25 --> Config Class Initialized
INFO - 2026-03-15 15:01:25 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:01:25 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:01:25 --> Utf8 Class Initialized
INFO - 2026-03-15 15:01:25 --> URI Class Initialized
INFO - 2026-03-15 15:01:25 --> Router Class Initialized
INFO - 2026-03-15 15:01:25 --> Output Class Initialized
INFO - 2026-03-15 15:01:25 --> Security Class Initialized
DEBUG - 2026-03-15 15:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:01:25 --> CSRF cookie sent
INFO - 2026-03-15 15:01:25 --> Input Class Initialized
INFO - 2026-03-15 15:01:25 --> Language Class Initialized
INFO - 2026-03-15 15:01:25 --> Language Class Initialized
INFO - 2026-03-15 15:01:25 --> Config Class Initialized
INFO - 2026-03-15 15:01:25 --> Loader Class Initialized
INFO - 2026-03-15 15:01:25 --> Helper loaded: url_helper
INFO - 2026-03-15 15:01:25 --> Helper loaded: form_helper
INFO - 2026-03-15 15:01:25 --> Helper loaded: html_helper
INFO - 2026-03-15 15:01:25 --> Helper loaded: file_helper
INFO - 2026-03-15 15:01:25 --> Helper loaded: email_helper
INFO - 2026-03-15 15:01:25 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:01:25 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:01:25 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:01:25 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:01:25 --> Database Driver Class Initialized
INFO - 2026-03-15 15:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:01:27 --> Upload Class Initialized
DEBUG - 2026-03-15 15:01:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:01:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:01:27 --> Encryption Class Initialized
INFO - 2026-03-15 15:01:27 --> Form Validation Class Initialized
INFO - 2026-03-15 15:01:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:01:27 --> Pagination Class Initialized
INFO - 2026-03-15 15:01:27 --> Email Class Initialized
INFO - 2026-03-15 15:01:27 --> Controller Class Initialized
DEBUG - 2026-03-15 15:01:27 --> Auth MX_Controller Initialized
INFO - 2026-03-15 15:01:27 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:01:27 --> Model "Auth_model" initialized
INFO - 2026-03-15 15:01:27 --> Model "Cart_model" initialized
INFO - 2026-03-15 15:01:27 --> Model "Appsetting_model" initialized
DEBUG - 2026-03-15 15:01:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-03-15 15:01:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-03-15 15:01:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-03-15 15:01:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-03-15 15:01:27 --> Final output sent to browser
DEBUG - 2026-03-15 15:01:27 --> Total execution time: 2.2246
INFO - 2026-03-15 15:01:27 --> Config Class Initialized
INFO - 2026-03-15 15:01:27 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:01:27 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:01:27 --> Utf8 Class Initialized
INFO - 2026-03-15 15:01:27 --> URI Class Initialized
INFO - 2026-03-15 15:01:27 --> Router Class Initialized
INFO - 2026-03-15 15:01:27 --> Output Class Initialized
INFO - 2026-03-15 15:01:27 --> Security Class Initialized
DEBUG - 2026-03-15 15:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:01:27 --> CSRF cookie sent
INFO - 2026-03-15 15:01:27 --> Input Class Initialized
INFO - 2026-03-15 15:01:27 --> Language Class Initialized
INFO - 2026-03-15 15:01:27 --> Language Class Initialized
INFO - 2026-03-15 15:01:27 --> Config Class Initialized
INFO - 2026-03-15 15:01:27 --> Loader Class Initialized
INFO - 2026-03-15 15:01:27 --> Helper loaded: url_helper
INFO - 2026-03-15 15:01:27 --> Helper loaded: form_helper
INFO - 2026-03-15 15:01:27 --> Helper loaded: html_helper
INFO - 2026-03-15 15:01:27 --> Helper loaded: file_helper
INFO - 2026-03-15 15:01:27 --> Helper loaded: email_helper
INFO - 2026-03-15 15:01:27 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:01:27 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:01:27 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:01:27 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:01:27 --> Database Driver Class Initialized
INFO - 2026-03-15 15:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:01:29 --> Upload Class Initialized
DEBUG - 2026-03-15 15:01:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:01:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:01:29 --> Encryption Class Initialized
INFO - 2026-03-15 15:01:29 --> Form Validation Class Initialized
INFO - 2026-03-15 15:01:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:01:29 --> Pagination Class Initialized
INFO - 2026-03-15 15:01:29 --> Email Class Initialized
INFO - 2026-03-15 15:01:29 --> Controller Class Initialized
DEBUG - 2026-03-15 15:01:29 --> Cart MX_Controller Initialized
INFO - 2026-03-15 15:01:29 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:01:29 --> Model "Auth_model" initialized
INFO - 2026-03-15 15:01:29 --> Model "Cart_model" initialized
INFO - 2026-03-15 15:01:29 --> Model "Common_model" initialized
INFO - 2026-03-15 15:01:29 --> Model "Order_model" initialized
INFO - 2026-03-15 15:01:29 --> Model "Appsetting_model" initialized
INFO - 2026-03-15 15:01:29 --> Model "PaymentGateway_model" initialized
INFO - 2026-03-15 15:01:30 --> Final output sent to browser
DEBUG - 2026-03-15 15:01:30 --> Total execution time: 2.4003
INFO - 2026-03-15 15:01:42 --> Config Class Initialized
INFO - 2026-03-15 15:01:42 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:01:42 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:01:42 --> Utf8 Class Initialized
INFO - 2026-03-15 15:01:42 --> URI Class Initialized
INFO - 2026-03-15 15:01:42 --> Router Class Initialized
INFO - 2026-03-15 15:01:42 --> Output Class Initialized
INFO - 2026-03-15 15:01:42 --> Config Class Initialized
INFO - 2026-03-15 15:01:42 --> Hooks Class Initialized
INFO - 2026-03-15 15:01:42 --> Config Class Initialized
INFO - 2026-03-15 15:01:42 --> Security Class Initialized
INFO - 2026-03-15 15:01:42 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:01:42 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:01:42 --> Utf8 Class Initialized
INFO - 2026-03-15 15:01:42 --> Config Class Initialized
INFO - 2026-03-15 15:01:42 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:01:42 --> Config Class Initialized
DEBUG - 2026-03-15 15:01:42 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:01:42 --> Hooks Class Initialized
INFO - 2026-03-15 15:01:42 --> Utf8 Class Initialized
INFO - 2026-03-15 15:01:42 --> CSRF cookie sent
INFO - 2026-03-15 15:01:42 --> Input Class Initialized
INFO - 2026-03-15 15:01:42 --> Language Class Initialized
INFO - 2026-03-15 15:01:42 --> URI Class Initialized
DEBUG - 2026-03-15 15:01:42 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:01:42 --> Utf8 Class Initialized
INFO - 2026-03-15 15:01:42 --> URI Class Initialized
INFO - 2026-03-15 15:01:42 --> URI Class Initialized
INFO - 2026-03-15 15:01:42 --> Language Class Initialized
INFO - 2026-03-15 15:01:42 --> Config Class Initialized
DEBUG - 2026-03-15 15:01:42 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:01:42 --> Utf8 Class Initialized
INFO - 2026-03-15 15:01:42 --> Router Class Initialized
INFO - 2026-03-15 15:01:42 --> Router Class Initialized
INFO - 2026-03-15 15:01:42 --> Router Class Initialized
INFO - 2026-03-15 15:01:42 --> URI Class Initialized
INFO - 2026-03-15 15:01:42 --> Output Class Initialized
INFO - 2026-03-15 15:01:42 --> Output Class Initialized
INFO - 2026-03-15 15:01:42 --> Output Class Initialized
INFO - 2026-03-15 15:01:42 --> Loader Class Initialized
INFO - 2026-03-15 15:01:42 --> Router Class Initialized
INFO - 2026-03-15 15:01:42 --> Config Class Initialized
INFO - 2026-03-15 15:01:42 --> Hooks Class Initialized
INFO - 2026-03-15 15:01:42 --> Helper loaded: url_helper
INFO - 2026-03-15 15:01:42 --> Security Class Initialized
INFO - 2026-03-15 15:01:42 --> Security Class Initialized
INFO - 2026-03-15 15:01:42 --> Security Class Initialized
INFO - 2026-03-15 15:01:42 --> Output Class Initialized
DEBUG - 2026-03-15 15:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:01:42 --> CSRF cookie sent
INFO - 2026-03-15 15:01:42 --> Input Class Initialized
DEBUG - 2026-03-15 15:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:01:42 --> CSRF cookie sent
INFO - 2026-03-15 15:01:42 --> Input Class Initialized
INFO - 2026-03-15 15:01:42 --> Language Class Initialized
INFO - 2026-03-15 15:01:42 --> Helper loaded: form_helper
DEBUG - 2026-03-15 15:01:42 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:01:42 --> Utf8 Class Initialized
INFO - 2026-03-15 15:01:42 --> Language Class Initialized
INFO - 2026-03-15 15:01:42 --> Helper loaded: html_helper
INFO - 2026-03-15 15:01:42 --> Language Class Initialized
INFO - 2026-03-15 15:01:42 --> Config Class Initialized
DEBUG - 2026-03-15 15:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:01:42 --> CSRF cookie sent
INFO - 2026-03-15 15:01:42 --> Input Class Initialized
INFO - 2026-03-15 15:01:42 --> URI Class Initialized
INFO - 2026-03-15 15:01:42 --> Security Class Initialized
INFO - 2026-03-15 15:01:42 --> Language Class Initialized
INFO - 2026-03-15 15:01:42 --> Config Class Initialized
INFO - 2026-03-15 15:01:42 --> Helper loaded: file_helper
INFO - 2026-03-15 15:01:42 --> Language Class Initialized
INFO - 2026-03-15 15:01:42 --> Helper loaded: email_helper
INFO - 2026-03-15 15:01:42 --> Language Class Initialized
INFO - 2026-03-15 15:01:42 --> Config Class Initialized
DEBUG - 2026-03-15 15:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:01:42 --> CSRF cookie sent
INFO - 2026-03-15 15:01:42 --> Input Class Initialized
INFO - 2026-03-15 15:01:42 --> Language Class Initialized
INFO - 2026-03-15 15:01:42 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:01:42 --> Router Class Initialized
INFO - 2026-03-15 15:01:42 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:01:42 --> Loader Class Initialized
INFO - 2026-03-15 15:01:42 --> Language Class Initialized
INFO - 2026-03-15 15:01:42 --> Config Class Initialized
INFO - 2026-03-15 15:01:42 --> Loader Class Initialized
INFO - 2026-03-15 15:01:42 --> Loader Class Initialized
INFO - 2026-03-15 15:01:42 --> Helper loaded: url_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: url_helper
INFO - 2026-03-15 15:01:42 --> Output Class Initialized
INFO - 2026-03-15 15:01:42 --> Helper loaded: url_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: form_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: html_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: form_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: form_helper
INFO - 2026-03-15 15:01:42 --> Security Class Initialized
INFO - 2026-03-15 15:01:42 --> Helper loaded: file_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: email_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: html_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: html_helper
INFO - 2026-03-15 15:01:42 --> Loader Class Initialized
INFO - 2026-03-15 15:01:42 --> Helper loaded: file_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: file_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: email_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: email_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: url_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: form_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: html_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: file_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: email_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: ssp_helper
DEBUG - 2026-03-15 15:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:01:42 --> CSRF cookie sent
INFO - 2026-03-15 15:01:42 --> Input Class Initialized
INFO - 2026-03-15 15:01:42 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:01:42 --> Language Class Initialized
INFO - 2026-03-15 15:01:42 --> Database Driver Class Initialized
INFO - 2026-03-15 15:01:42 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:01:42 --> Language Class Initialized
INFO - 2026-03-15 15:01:42 --> Config Class Initialized
INFO - 2026-03-15 15:01:42 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:01:42 --> Loader Class Initialized
INFO - 2026-03-15 15:01:42 --> Helper loaded: url_helper
INFO - 2026-03-15 15:01:42 --> Database Driver Class Initialized
INFO - 2026-03-15 15:01:42 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:01:42 --> Database Driver Class Initialized
INFO - 2026-03-15 15:01:42 --> Database Driver Class Initialized
INFO - 2026-03-15 15:01:42 --> Helper loaded: form_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: html_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: file_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: email_helper
INFO - 2026-03-15 15:01:42 --> Database Driver Class Initialized
INFO - 2026-03-15 15:01:42 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:01:42 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:01:42 --> Database Driver Class Initialized
INFO - 2026-03-15 15:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:01:44 --> Upload Class Initialized
DEBUG - 2026-03-15 15:01:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:01:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:01:44 --> Encryption Class Initialized
INFO - 2026-03-15 15:01:44 --> Form Validation Class Initialized
INFO - 2026-03-15 15:01:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:01:44 --> Pagination Class Initialized
INFO - 2026-03-15 15:01:44 --> Email Class Initialized
INFO - 2026-03-15 15:01:44 --> Controller Class Initialized
ERROR - 2026-03-15 15:01:44 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:01:44 --> Upload Class Initialized
DEBUG - 2026-03-15 15:01:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:01:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:01:44 --> Encryption Class Initialized
INFO - 2026-03-15 15:01:44 --> Form Validation Class Initialized
INFO - 2026-03-15 15:01:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:01:44 --> Pagination Class Initialized
INFO - 2026-03-15 15:01:44 --> Email Class Initialized
INFO - 2026-03-15 15:01:44 --> Controller Class Initialized
ERROR - 2026-03-15 15:01:44 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:01:44 --> Config Class Initialized
INFO - 2026-03-15 15:01:44 --> Hooks Class Initialized
INFO - 2026-03-15 15:01:44 --> Upload Class Initialized
DEBUG - 2026-03-15 15:01:44 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:01:44 --> Utf8 Class Initialized
INFO - 2026-03-15 15:01:44 --> URI Class Initialized
DEBUG - 2026-03-15 15:01:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:01:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:01:44 --> Encryption Class Initialized
INFO - 2026-03-15 15:01:44 --> Router Class Initialized
INFO - 2026-03-15 15:01:44 --> Form Validation Class Initialized
INFO - 2026-03-15 15:01:44 --> Output Class Initialized
INFO - 2026-03-15 15:01:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:01:44 --> Pagination Class Initialized
INFO - 2026-03-15 15:01:44 --> Security Class Initialized
DEBUG - 2026-03-15 15:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:01:44 --> CSRF cookie sent
INFO - 2026-03-15 15:01:44 --> Input Class Initialized
INFO - 2026-03-15 15:01:44 --> Language Class Initialized
INFO - 2026-03-15 15:01:44 --> Email Class Initialized
INFO - 2026-03-15 15:01:44 --> Controller Class Initialized
INFO - 2026-03-15 15:01:44 --> Language Class Initialized
INFO - 2026-03-15 15:01:44 --> Config Class Initialized
ERROR - 2026-03-15 15:01:44 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:01:44 --> Upload Class Initialized
INFO - 2026-03-15 15:01:44 --> Loader Class Initialized
INFO - 2026-03-15 15:01:44 --> Helper loaded: url_helper
DEBUG - 2026-03-15 15:01:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:01:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:01:44 --> Encryption Class Initialized
INFO - 2026-03-15 15:01:44 --> Helper loaded: form_helper
INFO - 2026-03-15 15:01:44 --> Helper loaded: html_helper
INFO - 2026-03-15 15:01:44 --> Helper loaded: file_helper
INFO - 2026-03-15 15:01:44 --> Helper loaded: email_helper
INFO - 2026-03-15 15:01:44 --> Form Validation Class Initialized
INFO - 2026-03-15 15:01:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:01:44 --> Pagination Class Initialized
INFO - 2026-03-15 15:01:44 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:01:44 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:01:44 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:01:44 --> Email Class Initialized
INFO - 2026-03-15 15:01:44 --> Controller Class Initialized
ERROR - 2026-03-15 15:01:44 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:01:44 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:01:44 --> Upload Class Initialized
DEBUG - 2026-03-15 15:01:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:01:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:01:44 --> Encryption Class Initialized
INFO - 2026-03-15 15:01:44 --> Form Validation Class Initialized
INFO - 2026-03-15 15:01:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:01:44 --> Pagination Class Initialized
INFO - 2026-03-15 15:01:44 --> Database Driver Class Initialized
INFO - 2026-03-15 15:01:44 --> Email Class Initialized
INFO - 2026-03-15 15:01:44 --> Controller Class Initialized
ERROR - 2026-03-15 15:01:44 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:01:44 --> Upload Class Initialized
DEBUG - 2026-03-15 15:01:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:01:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:01:44 --> Encryption Class Initialized
INFO - 2026-03-15 15:01:44 --> Form Validation Class Initialized
INFO - 2026-03-15 15:01:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:01:44 --> Pagination Class Initialized
INFO - 2026-03-15 15:01:44 --> Email Class Initialized
INFO - 2026-03-15 15:01:44 --> Controller Class Initialized
ERROR - 2026-03-15 15:01:44 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:01:46 --> Upload Class Initialized
DEBUG - 2026-03-15 15:01:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:01:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:01:46 --> Encryption Class Initialized
INFO - 2026-03-15 15:01:46 --> Form Validation Class Initialized
INFO - 2026-03-15 15:01:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:01:46 --> Pagination Class Initialized
INFO - 2026-03-15 15:01:46 --> Email Class Initialized
INFO - 2026-03-15 15:01:46 --> Controller Class Initialized
ERROR - 2026-03-15 15:01:46 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:02:23 --> Config Class Initialized
INFO - 2026-03-15 15:02:23 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:02:23 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:02:23 --> Utf8 Class Initialized
INFO - 2026-03-15 15:02:23 --> URI Class Initialized
INFO - 2026-03-15 15:02:23 --> Router Class Initialized
INFO - 2026-03-15 15:02:23 --> Output Class Initialized
INFO - 2026-03-15 15:02:23 --> Security Class Initialized
DEBUG - 2026-03-15 15:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:02:23 --> CSRF cookie sent
INFO - 2026-03-15 15:02:23 --> Input Class Initialized
INFO - 2026-03-15 15:02:23 --> Language Class Initialized
INFO - 2026-03-15 15:02:23 --> Language Class Initialized
INFO - 2026-03-15 15:02:23 --> Config Class Initialized
INFO - 2026-03-15 15:02:23 --> Loader Class Initialized
INFO - 2026-03-15 15:02:23 --> Helper loaded: url_helper
INFO - 2026-03-15 15:02:23 --> Helper loaded: form_helper
INFO - 2026-03-15 15:02:23 --> Helper loaded: html_helper
INFO - 2026-03-15 15:02:23 --> Helper loaded: file_helper
INFO - 2026-03-15 15:02:23 --> Helper loaded: email_helper
INFO - 2026-03-15 15:02:23 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:02:23 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:02:23 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:02:23 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:02:23 --> Database Driver Class Initialized
INFO - 2026-03-15 15:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:02:25 --> Upload Class Initialized
DEBUG - 2026-03-15 15:02:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:02:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:02:25 --> Encryption Class Initialized
INFO - 2026-03-15 15:02:25 --> Form Validation Class Initialized
INFO - 2026-03-15 15:02:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:02:25 --> Pagination Class Initialized
INFO - 2026-03-15 15:02:25 --> Email Class Initialized
INFO - 2026-03-15 15:02:25 --> Controller Class Initialized
DEBUG - 2026-03-15 15:02:25 --> Dashboard MX_Controller Initialized
INFO - 2026-03-15 15:02:25 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:02:25 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:02:25 --> Config Class Initialized
INFO - 2026-03-15 15:02:25 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:02:25 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:02:25 --> Utf8 Class Initialized
INFO - 2026-03-15 15:02:25 --> URI Class Initialized
INFO - 2026-03-15 15:02:25 --> Router Class Initialized
INFO - 2026-03-15 15:02:25 --> Output Class Initialized
INFO - 2026-03-15 15:02:25 --> Security Class Initialized
DEBUG - 2026-03-15 15:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:02:25 --> CSRF cookie sent
INFO - 2026-03-15 15:02:25 --> Input Class Initialized
INFO - 2026-03-15 15:02:25 --> Language Class Initialized
INFO - 2026-03-15 15:02:25 --> Language Class Initialized
INFO - 2026-03-15 15:02:25 --> Config Class Initialized
INFO - 2026-03-15 15:02:25 --> Loader Class Initialized
INFO - 2026-03-15 15:02:25 --> Helper loaded: url_helper
INFO - 2026-03-15 15:02:25 --> Helper loaded: form_helper
INFO - 2026-03-15 15:02:25 --> Helper loaded: html_helper
INFO - 2026-03-15 15:02:25 --> Helper loaded: file_helper
INFO - 2026-03-15 15:02:25 --> Helper loaded: email_helper
INFO - 2026-03-15 15:02:25 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:02:25 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:02:25 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:02:25 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:02:25 --> Database Driver Class Initialized
INFO - 2026-03-15 15:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:02:27 --> Upload Class Initialized
DEBUG - 2026-03-15 15:02:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:02:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:02:27 --> Encryption Class Initialized
INFO - 2026-03-15 15:02:27 --> Form Validation Class Initialized
INFO - 2026-03-15 15:02:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:02:27 --> Pagination Class Initialized
INFO - 2026-03-15 15:02:27 --> Email Class Initialized
INFO - 2026-03-15 15:02:27 --> Controller Class Initialized
DEBUG - 2026-03-15 15:02:27 --> Authenticate MX_Controller Initialized
INFO - 2026-03-15 15:02:27 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:02:27 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:02:27 --> Model "Appsetting_model" initialized
DEBUG - 2026-03-15 15:02:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 15:02:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 15:02:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-03-15 15:02:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 15:02:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 15:02:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-03-15 15:02:27 --> Final output sent to browser
DEBUG - 2026-03-15 15:02:27 --> Total execution time: 2.4124
INFO - 2026-03-15 15:02:27 --> Config Class Initialized
INFO - 2026-03-15 15:02:27 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:02:27 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:02:27 --> Utf8 Class Initialized
INFO - 2026-03-15 15:02:27 --> URI Class Initialized
INFO - 2026-03-15 15:02:27 --> Router Class Initialized
INFO - 2026-03-15 15:02:27 --> Output Class Initialized
INFO - 2026-03-15 15:02:27 --> Security Class Initialized
DEBUG - 2026-03-15 15:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:02:27 --> CSRF cookie sent
INFO - 2026-03-15 15:02:27 --> Input Class Initialized
INFO - 2026-03-15 15:02:27 --> Language Class Initialized
INFO - 2026-03-15 15:02:27 --> Language Class Initialized
INFO - 2026-03-15 15:02:27 --> Config Class Initialized
INFO - 2026-03-15 15:02:27 --> Loader Class Initialized
INFO - 2026-03-15 15:02:27 --> Helper loaded: url_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: form_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: html_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: file_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: email_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:02:27 --> Database Driver Class Initialized
INFO - 2026-03-15 15:02:27 --> Config Class Initialized
INFO - 2026-03-15 15:02:27 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:02:27 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:02:27 --> Utf8 Class Initialized
INFO - 2026-03-15 15:02:27 --> URI Class Initialized
INFO - 2026-03-15 15:02:27 --> Router Class Initialized
INFO - 2026-03-15 15:02:27 --> Output Class Initialized
INFO - 2026-03-15 15:02:27 --> Config Class Initialized
INFO - 2026-03-15 15:02:27 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:02:27 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:02:27 --> Utf8 Class Initialized
INFO - 2026-03-15 15:02:27 --> URI Class Initialized
INFO - 2026-03-15 15:02:27 --> Config Class Initialized
INFO - 2026-03-15 15:02:27 --> Hooks Class Initialized
INFO - 2026-03-15 15:02:27 --> Security Class Initialized
INFO - 2026-03-15 15:02:27 --> Config Class Initialized
INFO - 2026-03-15 15:02:27 --> Hooks Class Initialized
INFO - 2026-03-15 15:02:27 --> Router Class Initialized
DEBUG - 2026-03-15 15:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:02:27 --> CSRF cookie sent
INFO - 2026-03-15 15:02:27 --> Input Class Initialized
INFO - 2026-03-15 15:02:27 --> Language Class Initialized
DEBUG - 2026-03-15 15:02:27 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:02:27 --> Utf8 Class Initialized
INFO - 2026-03-15 15:02:27 --> Language Class Initialized
INFO - 2026-03-15 15:02:27 --> Config Class Initialized
INFO - 2026-03-15 15:02:27 --> Output Class Initialized
INFO - 2026-03-15 15:02:27 --> URI Class Initialized
INFO - 2026-03-15 15:02:27 --> Router Class Initialized
INFO - 2026-03-15 15:02:27 --> Security Class Initialized
INFO - 2026-03-15 15:02:27 --> Loader Class Initialized
INFO - 2026-03-15 15:02:27 --> Helper loaded: url_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: form_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: html_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: file_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: email_helper
INFO - 2026-03-15 15:02:27 --> Config Class Initialized
INFO - 2026-03-15 15:02:27 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:02:27 --> CSRF cookie sent
INFO - 2026-03-15 15:02:27 --> Input Class Initialized
INFO - 2026-03-15 15:02:27 --> Language Class Initialized
INFO - 2026-03-15 15:02:27 --> Language Class Initialized
INFO - 2026-03-15 15:02:27 --> Config Class Initialized
DEBUG - 2026-03-15 15:02:27 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:02:27 --> Utf8 Class Initialized
DEBUG - 2026-03-15 15:02:27 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:02:27 --> Utf8 Class Initialized
INFO - 2026-03-15 15:02:27 --> Output Class Initialized
INFO - 2026-03-15 15:02:27 --> URI Class Initialized
INFO - 2026-03-15 15:02:27 --> URI Class Initialized
INFO - 2026-03-15 15:02:27 --> Security Class Initialized
INFO - 2026-03-15 15:02:27 --> Loader Class Initialized
INFO - 2026-03-15 15:02:27 --> Router Class Initialized
INFO - 2026-03-15 15:02:27 --> Router Class Initialized
DEBUG - 2026-03-15 15:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:02:27 --> Helper loaded: url_helper
INFO - 2026-03-15 15:02:27 --> CSRF cookie sent
INFO - 2026-03-15 15:02:27 --> Input Class Initialized
INFO - 2026-03-15 15:02:27 --> Language Class Initialized
INFO - 2026-03-15 15:02:27 --> Output Class Initialized
INFO - 2026-03-15 15:02:27 --> Helper loaded: form_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: html_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:02:27 --> Language Class Initialized
INFO - 2026-03-15 15:02:27 --> Config Class Initialized
INFO - 2026-03-15 15:02:27 --> Helper loaded: file_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: email_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:02:27 --> Output Class Initialized
INFO - 2026-03-15 15:02:27 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:02:27 --> Security Class Initialized
INFO - 2026-03-15 15:02:27 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:02:27 --> Loader Class Initialized
INFO - 2026-03-15 15:02:27 --> Security Class Initialized
INFO - 2026-03-15 15:02:27 --> Helper loaded: url_helper
DEBUG - 2026-03-15 15:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:02:27 --> CSRF cookie sent
INFO - 2026-03-15 15:02:27 --> Input Class Initialized
INFO - 2026-03-15 15:02:27 --> Language Class Initialized
INFO - 2026-03-15 15:02:27 --> Helper loaded: domain_helper
DEBUG - 2026-03-15 15:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:02:27 --> CSRF cookie sent
INFO - 2026-03-15 15:02:27 --> Input Class Initialized
INFO - 2026-03-15 15:02:27 --> Language Class Initialized
INFO - 2026-03-15 15:02:27 --> Language Class Initialized
INFO - 2026-03-15 15:02:27 --> Helper loaded: form_helper
INFO - 2026-03-15 15:02:27 --> Config Class Initialized
INFO - 2026-03-15 15:02:27 --> Helper loaded: html_helper
INFO - 2026-03-15 15:02:27 --> Language Class Initialized
INFO - 2026-03-15 15:02:27 --> Config Class Initialized
INFO - 2026-03-15 15:02:27 --> Helper loaded: file_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: email_helper
INFO - 2026-03-15 15:02:27 --> Loader Class Initialized
INFO - 2026-03-15 15:02:27 --> Loader Class Initialized
INFO - 2026-03-15 15:02:27 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: url_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: url_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: form_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: html_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: form_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: file_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: email_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: html_helper
INFO - 2026-03-15 15:02:27 --> Database Driver Class Initialized
INFO - 2026-03-15 15:02:27 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: file_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: email_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:02:27 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:02:27 --> Database Driver Class Initialized
INFO - 2026-03-15 15:02:27 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:02:27 --> Database Driver Class Initialized
INFO - 2026-03-15 15:02:27 --> Database Driver Class Initialized
INFO - 2026-03-15 15:02:27 --> Database Driver Class Initialized
INFO - 2026-03-15 15:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:02:29 --> Upload Class Initialized
DEBUG - 2026-03-15 15:02:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:02:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:02:29 --> Encryption Class Initialized
INFO - 2026-03-15 15:02:29 --> Form Validation Class Initialized
INFO - 2026-03-15 15:02:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:02:29 --> Pagination Class Initialized
INFO - 2026-03-15 15:02:29 --> Email Class Initialized
INFO - 2026-03-15 15:02:29 --> Controller Class Initialized
ERROR - 2026-03-15 15:02:29 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:02:29 --> Config Class Initialized
INFO - 2026-03-15 15:02:29 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:02:29 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:02:29 --> Utf8 Class Initialized
INFO - 2026-03-15 15:02:29 --> URI Class Initialized
INFO - 2026-03-15 15:02:29 --> Router Class Initialized
INFO - 2026-03-15 15:02:29 --> Output Class Initialized
INFO - 2026-03-15 15:02:29 --> Security Class Initialized
DEBUG - 2026-03-15 15:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:02:29 --> CSRF cookie sent
INFO - 2026-03-15 15:02:29 --> Input Class Initialized
INFO - 2026-03-15 15:02:29 --> Language Class Initialized
INFO - 2026-03-15 15:02:29 --> Language Class Initialized
INFO - 2026-03-15 15:02:29 --> Config Class Initialized
INFO - 2026-03-15 15:02:29 --> Loader Class Initialized
INFO - 2026-03-15 15:02:29 --> Helper loaded: url_helper
INFO - 2026-03-15 15:02:29 --> Helper loaded: form_helper
INFO - 2026-03-15 15:02:29 --> Helper loaded: html_helper
INFO - 2026-03-15 15:02:29 --> Helper loaded: file_helper
INFO - 2026-03-15 15:02:29 --> Helper loaded: email_helper
INFO - 2026-03-15 15:02:29 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:02:29 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:02:29 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:02:29 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:02:29 --> Database Driver Class Initialized
INFO - 2026-03-15 15:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:02:29 --> Upload Class Initialized
DEBUG - 2026-03-15 15:02:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:02:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:02:29 --> Encryption Class Initialized
INFO - 2026-03-15 15:02:29 --> Form Validation Class Initialized
INFO - 2026-03-15 15:02:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:02:29 --> Pagination Class Initialized
INFO - 2026-03-15 15:02:29 --> Email Class Initialized
INFO - 2026-03-15 15:02:29 --> Controller Class Initialized
ERROR - 2026-03-15 15:02:29 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:02:29 --> Upload Class Initialized
DEBUG - 2026-03-15 15:02:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:02:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:02:29 --> Encryption Class Initialized
INFO - 2026-03-15 15:02:29 --> Form Validation Class Initialized
INFO - 2026-03-15 15:02:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:02:29 --> Pagination Class Initialized
INFO - 2026-03-15 15:02:29 --> Email Class Initialized
INFO - 2026-03-15 15:02:29 --> Controller Class Initialized
ERROR - 2026-03-15 15:02:29 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:02:29 --> Upload Class Initialized
DEBUG - 2026-03-15 15:02:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:02:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:02:29 --> Encryption Class Initialized
INFO - 2026-03-15 15:02:29 --> Form Validation Class Initialized
INFO - 2026-03-15 15:02:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:02:29 --> Pagination Class Initialized
INFO - 2026-03-15 15:02:29 --> Email Class Initialized
INFO - 2026-03-15 15:02:29 --> Controller Class Initialized
ERROR - 2026-03-15 15:02:29 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:02:29 --> Upload Class Initialized
DEBUG - 2026-03-15 15:02:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:02:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:02:29 --> Encryption Class Initialized
INFO - 2026-03-15 15:02:29 --> Form Validation Class Initialized
INFO - 2026-03-15 15:02:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:02:29 --> Pagination Class Initialized
INFO - 2026-03-15 15:02:29 --> Email Class Initialized
INFO - 2026-03-15 15:02:29 --> Controller Class Initialized
ERROR - 2026-03-15 15:02:29 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:02:30 --> Upload Class Initialized
DEBUG - 2026-03-15 15:02:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:02:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:02:30 --> Encryption Class Initialized
INFO - 2026-03-15 15:02:30 --> Form Validation Class Initialized
INFO - 2026-03-15 15:02:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:02:30 --> Pagination Class Initialized
INFO - 2026-03-15 15:02:30 --> Email Class Initialized
INFO - 2026-03-15 15:02:30 --> Controller Class Initialized
ERROR - 2026-03-15 15:02:30 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:02:31 --> Upload Class Initialized
DEBUG - 2026-03-15 15:02:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:02:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:02:31 --> Encryption Class Initialized
INFO - 2026-03-15 15:02:31 --> Form Validation Class Initialized
INFO - 2026-03-15 15:02:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:02:31 --> Pagination Class Initialized
INFO - 2026-03-15 15:02:31 --> Email Class Initialized
INFO - 2026-03-15 15:02:31 --> Controller Class Initialized
ERROR - 2026-03-15 15:02:31 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:03:00 --> Config Class Initialized
INFO - 2026-03-15 15:03:00 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:03:00 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:03:00 --> Utf8 Class Initialized
INFO - 2026-03-15 15:03:00 --> URI Class Initialized
INFO - 2026-03-15 15:03:00 --> Router Class Initialized
INFO - 2026-03-15 15:03:00 --> Output Class Initialized
INFO - 2026-03-15 15:03:00 --> Security Class Initialized
DEBUG - 2026-03-15 15:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:03:00 --> CSRF cookie sent
INFO - 2026-03-15 15:03:00 --> CSRF token verified
INFO - 2026-03-15 15:03:00 --> Input Class Initialized
INFO - 2026-03-15 15:03:00 --> Language Class Initialized
INFO - 2026-03-15 15:03:00 --> Language Class Initialized
INFO - 2026-03-15 15:03:00 --> Config Class Initialized
INFO - 2026-03-15 15:03:00 --> Loader Class Initialized
INFO - 2026-03-15 15:03:00 --> Helper loaded: url_helper
INFO - 2026-03-15 15:03:00 --> Helper loaded: form_helper
INFO - 2026-03-15 15:03:00 --> Helper loaded: html_helper
INFO - 2026-03-15 15:03:00 --> Helper loaded: file_helper
INFO - 2026-03-15 15:03:00 --> Helper loaded: email_helper
INFO - 2026-03-15 15:03:00 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:03:00 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:03:00 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:03:00 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:03:00 --> Database Driver Class Initialized
INFO - 2026-03-15 15:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:03:02 --> Upload Class Initialized
DEBUG - 2026-03-15 15:03:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:03:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:03:02 --> Encryption Class Initialized
INFO - 2026-03-15 15:03:02 --> Form Validation Class Initialized
INFO - 2026-03-15 15:03:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:03:02 --> Pagination Class Initialized
INFO - 2026-03-15 15:03:02 --> Email Class Initialized
INFO - 2026-03-15 15:03:02 --> Controller Class Initialized
DEBUG - 2026-03-15 15:03:02 --> Authenticate MX_Controller Initialized
INFO - 2026-03-15 15:03:02 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:03:02 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:03:02 --> Model "Appsetting_model" initialized
DEBUG - 2026-03-15 15:03:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 15:03:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 15:03:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-03-15 15:03:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 15:03:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 15:03:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-03-15 15:03:03 --> Final output sent to browser
DEBUG - 2026-03-15 15:03:03 --> Total execution time: 2.3360
INFO - 2026-03-15 15:03:03 --> Config Class Initialized
INFO - 2026-03-15 15:03:03 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:03:03 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:03:03 --> Utf8 Class Initialized
INFO - 2026-03-15 15:03:03 --> URI Class Initialized
INFO - 2026-03-15 15:03:03 --> Router Class Initialized
INFO - 2026-03-15 15:03:03 --> Output Class Initialized
INFO - 2026-03-15 15:03:03 --> Security Class Initialized
DEBUG - 2026-03-15 15:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:03:03 --> CSRF cookie sent
INFO - 2026-03-15 15:03:03 --> Input Class Initialized
INFO - 2026-03-15 15:03:03 --> Language Class Initialized
INFO - 2026-03-15 15:03:03 --> Language Class Initialized
INFO - 2026-03-15 15:03:03 --> Config Class Initialized
INFO - 2026-03-15 15:03:03 --> Loader Class Initialized
INFO - 2026-03-15 15:03:03 --> Helper loaded: url_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: form_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: html_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: file_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: email_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:03:03 --> Database Driver Class Initialized
INFO - 2026-03-15 15:03:03 --> Config Class Initialized
INFO - 2026-03-15 15:03:03 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:03:03 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:03:03 --> Utf8 Class Initialized
INFO - 2026-03-15 15:03:03 --> URI Class Initialized
INFO - 2026-03-15 15:03:03 --> Router Class Initialized
INFO - 2026-03-15 15:03:03 --> Output Class Initialized
INFO - 2026-03-15 15:03:03 --> Security Class Initialized
DEBUG - 2026-03-15 15:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:03:03 --> CSRF cookie sent
INFO - 2026-03-15 15:03:03 --> Input Class Initialized
INFO - 2026-03-15 15:03:03 --> Language Class Initialized
INFO - 2026-03-15 15:03:03 --> Config Class Initialized
INFO - 2026-03-15 15:03:03 --> Hooks Class Initialized
INFO - 2026-03-15 15:03:03 --> Language Class Initialized
INFO - 2026-03-15 15:03:03 --> Config Class Initialized
DEBUG - 2026-03-15 15:03:03 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:03:03 --> Utf8 Class Initialized
INFO - 2026-03-15 15:03:03 --> URI Class Initialized
INFO - 2026-03-15 15:03:03 --> Config Class Initialized
INFO - 2026-03-15 15:03:03 --> Hooks Class Initialized
INFO - 2026-03-15 15:03:03 --> Config Class Initialized
INFO - 2026-03-15 15:03:03 --> Config Class Initialized
INFO - 2026-03-15 15:03:03 --> Hooks Class Initialized
INFO - 2026-03-15 15:03:03 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:03:03 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:03:03 --> Utf8 Class Initialized
INFO - 2026-03-15 15:03:03 --> Loader Class Initialized
INFO - 2026-03-15 15:03:03 --> Router Class Initialized
DEBUG - 2026-03-15 15:03:03 --> UTF-8 Support Enabled
DEBUG - 2026-03-15 15:03:03 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:03:03 --> Utf8 Class Initialized
INFO - 2026-03-15 15:03:03 --> Utf8 Class Initialized
INFO - 2026-03-15 15:03:03 --> URI Class Initialized
INFO - 2026-03-15 15:03:03 --> Helper loaded: url_helper
INFO - 2026-03-15 15:03:03 --> URI Class Initialized
INFO - 2026-03-15 15:03:03 --> URI Class Initialized
INFO - 2026-03-15 15:03:03 --> Output Class Initialized
INFO - 2026-03-15 15:03:03 --> Router Class Initialized
INFO - 2026-03-15 15:03:03 --> Helper loaded: form_helper
INFO - 2026-03-15 15:03:03 --> Security Class Initialized
INFO - 2026-03-15 15:03:03 --> Router Class Initialized
INFO - 2026-03-15 15:03:03 --> Router Class Initialized
INFO - 2026-03-15 15:03:03 --> Helper loaded: html_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: file_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: email_helper
DEBUG - 2026-03-15 15:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:03:03 --> CSRF cookie sent
INFO - 2026-03-15 15:03:03 --> Input Class Initialized
INFO - 2026-03-15 15:03:03 --> Output Class Initialized
INFO - 2026-03-15 15:03:03 --> Output Class Initialized
INFO - 2026-03-15 15:03:03 --> Language Class Initialized
INFO - 2026-03-15 15:03:03 --> Output Class Initialized
INFO - 2026-03-15 15:03:03 --> Security Class Initialized
INFO - 2026-03-15 15:03:03 --> Security Class Initialized
INFO - 2026-03-15 15:03:03 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:03:03 --> Language Class Initialized
INFO - 2026-03-15 15:03:03 --> Config Class Initialized
INFO - 2026-03-15 15:03:03 --> Security Class Initialized
DEBUG - 2026-03-15 15:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-03-15 15:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:03:03 --> CSRF cookie sent
INFO - 2026-03-15 15:03:03 --> CSRF cookie sent
INFO - 2026-03-15 15:03:03 --> Input Class Initialized
INFO - 2026-03-15 15:03:03 --> Input Class Initialized
INFO - 2026-03-15 15:03:03 --> Language Class Initialized
INFO - 2026-03-15 15:03:03 --> Language Class Initialized
DEBUG - 2026-03-15 15:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:03:03 --> CSRF cookie sent
INFO - 2026-03-15 15:03:03 --> Input Class Initialized
INFO - 2026-03-15 15:03:03 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:03:03 --> Language Class Initialized
INFO - 2026-03-15 15:03:03 --> Language Class Initialized
INFO - 2026-03-15 15:03:03 --> Config Class Initialized
INFO - 2026-03-15 15:03:03 --> Config Class Initialized
INFO - 2026-03-15 15:03:03 --> Language Class Initialized
INFO - 2026-03-15 15:03:03 --> Loader Class Initialized
INFO - 2026-03-15 15:03:03 --> Language Class Initialized
INFO - 2026-03-15 15:03:03 --> Config Class Initialized
INFO - 2026-03-15 15:03:03 --> Helper loaded: url_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:03:03 --> Loader Class Initialized
INFO - 2026-03-15 15:03:03 --> Loader Class Initialized
INFO - 2026-03-15 15:03:03 --> Helper loaded: form_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: html_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: url_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: url_helper
INFO - 2026-03-15 15:03:03 --> Loader Class Initialized
INFO - 2026-03-15 15:03:03 --> Helper loaded: file_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: email_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: url_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: form_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: form_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: html_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: html_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: form_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: file_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: email_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: file_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: email_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: html_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: file_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: email_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:03:03 --> Database Driver Class Initialized
INFO - 2026-03-15 15:03:03 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:03:03 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:03:03 --> Database Driver Class Initialized
INFO - 2026-03-15 15:03:03 --> Database Driver Class Initialized
INFO - 2026-03-15 15:03:03 --> Database Driver Class Initialized
INFO - 2026-03-15 15:03:03 --> Database Driver Class Initialized
INFO - 2026-03-15 15:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:03:04 --> Upload Class Initialized
DEBUG - 2026-03-15 15:03:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:03:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:03:04 --> Encryption Class Initialized
INFO - 2026-03-15 15:03:04 --> Form Validation Class Initialized
INFO - 2026-03-15 15:03:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:03:04 --> Pagination Class Initialized
INFO - 2026-03-15 15:03:04 --> Email Class Initialized
INFO - 2026-03-15 15:03:04 --> Controller Class Initialized
ERROR - 2026-03-15 15:03:04 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:03:04 --> Config Class Initialized
INFO - 2026-03-15 15:03:04 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:03:04 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:03:04 --> Utf8 Class Initialized
INFO - 2026-03-15 15:03:04 --> URI Class Initialized
INFO - 2026-03-15 15:03:04 --> Router Class Initialized
INFO - 2026-03-15 15:03:04 --> Output Class Initialized
INFO - 2026-03-15 15:03:04 --> Security Class Initialized
DEBUG - 2026-03-15 15:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:03:04 --> CSRF cookie sent
INFO - 2026-03-15 15:03:04 --> Input Class Initialized
INFO - 2026-03-15 15:03:04 --> Language Class Initialized
INFO - 2026-03-15 15:03:04 --> Language Class Initialized
INFO - 2026-03-15 15:03:04 --> Config Class Initialized
INFO - 2026-03-15 15:03:04 --> Loader Class Initialized
INFO - 2026-03-15 15:03:04 --> Helper loaded: url_helper
INFO - 2026-03-15 15:03:04 --> Helper loaded: form_helper
INFO - 2026-03-15 15:03:04 --> Helper loaded: html_helper
INFO - 2026-03-15 15:03:04 --> Helper loaded: file_helper
INFO - 2026-03-15 15:03:04 --> Helper loaded: email_helper
INFO - 2026-03-15 15:03:04 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:03:04 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:03:04 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:03:04 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:03:04 --> Database Driver Class Initialized
INFO - 2026-03-15 15:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:03:06 --> Upload Class Initialized
DEBUG - 2026-03-15 15:03:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:03:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:03:06 --> Encryption Class Initialized
INFO - 2026-03-15 15:03:06 --> Form Validation Class Initialized
INFO - 2026-03-15 15:03:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:03:06 --> Pagination Class Initialized
INFO - 2026-03-15 15:03:06 --> Email Class Initialized
INFO - 2026-03-15 15:03:06 --> Controller Class Initialized
ERROR - 2026-03-15 15:03:06 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:03:06 --> Upload Class Initialized
DEBUG - 2026-03-15 15:03:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:03:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:03:06 --> Encryption Class Initialized
INFO - 2026-03-15 15:03:06 --> Form Validation Class Initialized
INFO - 2026-03-15 15:03:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:03:06 --> Pagination Class Initialized
INFO - 2026-03-15 15:03:06 --> Email Class Initialized
INFO - 2026-03-15 15:03:06 --> Controller Class Initialized
ERROR - 2026-03-15 15:03:06 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:03:06 --> Upload Class Initialized
DEBUG - 2026-03-15 15:03:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:03:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:03:06 --> Encryption Class Initialized
INFO - 2026-03-15 15:03:06 --> Form Validation Class Initialized
INFO - 2026-03-15 15:03:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:03:06 --> Pagination Class Initialized
INFO - 2026-03-15 15:03:06 --> Email Class Initialized
INFO - 2026-03-15 15:03:06 --> Controller Class Initialized
ERROR - 2026-03-15 15:03:06 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:03:06 --> Upload Class Initialized
DEBUG - 2026-03-15 15:03:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:03:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:03:06 --> Encryption Class Initialized
INFO - 2026-03-15 15:03:06 --> Form Validation Class Initialized
INFO - 2026-03-15 15:03:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:03:06 --> Pagination Class Initialized
INFO - 2026-03-15 15:03:06 --> Email Class Initialized
INFO - 2026-03-15 15:03:06 --> Controller Class Initialized
ERROR - 2026-03-15 15:03:06 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:03:06 --> Upload Class Initialized
DEBUG - 2026-03-15 15:03:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:03:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:03:06 --> Encryption Class Initialized
INFO - 2026-03-15 15:03:06 --> Form Validation Class Initialized
INFO - 2026-03-15 15:03:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:03:06 --> Pagination Class Initialized
INFO - 2026-03-15 15:03:06 --> Email Class Initialized
INFO - 2026-03-15 15:03:06 --> Controller Class Initialized
ERROR - 2026-03-15 15:03:06 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:03:08 --> Upload Class Initialized
DEBUG - 2026-03-15 15:03:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:03:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:03:08 --> Encryption Class Initialized
INFO - 2026-03-15 15:03:08 --> Form Validation Class Initialized
INFO - 2026-03-15 15:03:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:03:08 --> Pagination Class Initialized
INFO - 2026-03-15 15:03:08 --> Email Class Initialized
INFO - 2026-03-15 15:03:08 --> Controller Class Initialized
ERROR - 2026-03-15 15:03:08 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:03:21 --> Config Class Initialized
INFO - 2026-03-15 15:03:21 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:03:21 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:03:21 --> Utf8 Class Initialized
INFO - 2026-03-15 15:03:21 --> URI Class Initialized
INFO - 2026-03-15 15:03:21 --> Router Class Initialized
INFO - 2026-03-15 15:03:21 --> Output Class Initialized
INFO - 2026-03-15 15:03:21 --> Security Class Initialized
DEBUG - 2026-03-15 15:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:03:21 --> CSRF cookie sent
INFO - 2026-03-15 15:03:21 --> CSRF token verified
INFO - 2026-03-15 15:03:21 --> Input Class Initialized
INFO - 2026-03-15 15:03:21 --> Language Class Initialized
INFO - 2026-03-15 15:03:21 --> Language Class Initialized
INFO - 2026-03-15 15:03:21 --> Config Class Initialized
INFO - 2026-03-15 15:03:21 --> Loader Class Initialized
INFO - 2026-03-15 15:03:21 --> Helper loaded: url_helper
INFO - 2026-03-15 15:03:21 --> Helper loaded: form_helper
INFO - 2026-03-15 15:03:21 --> Helper loaded: html_helper
INFO - 2026-03-15 15:03:21 --> Helper loaded: file_helper
INFO - 2026-03-15 15:03:21 --> Helper loaded: email_helper
INFO - 2026-03-15 15:03:21 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:03:21 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:03:21 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:03:21 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:03:21 --> Database Driver Class Initialized
INFO - 2026-03-15 15:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:03:23 --> Upload Class Initialized
DEBUG - 2026-03-15 15:03:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:03:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:03:23 --> Encryption Class Initialized
INFO - 2026-03-15 15:03:23 --> Form Validation Class Initialized
INFO - 2026-03-15 15:03:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:03:23 --> Pagination Class Initialized
INFO - 2026-03-15 15:03:23 --> Email Class Initialized
INFO - 2026-03-15 15:03:23 --> Controller Class Initialized
DEBUG - 2026-03-15 15:03:23 --> Authenticate MX_Controller Initialized
INFO - 2026-03-15 15:03:23 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:03:23 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:03:23 --> Model "Appsetting_model" initialized
INFO - 2026-03-15 15:03:26 --> Config Class Initialized
INFO - 2026-03-15 15:03:26 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:03:26 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:03:26 --> Utf8 Class Initialized
INFO - 2026-03-15 15:03:26 --> URI Class Initialized
INFO - 2026-03-15 15:03:26 --> Router Class Initialized
INFO - 2026-03-15 15:03:26 --> Output Class Initialized
INFO - 2026-03-15 15:03:26 --> Security Class Initialized
DEBUG - 2026-03-15 15:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:03:26 --> CSRF cookie sent
INFO - 2026-03-15 15:03:26 --> Input Class Initialized
INFO - 2026-03-15 15:03:26 --> Language Class Initialized
INFO - 2026-03-15 15:03:26 --> Language Class Initialized
INFO - 2026-03-15 15:03:26 --> Config Class Initialized
INFO - 2026-03-15 15:03:26 --> Loader Class Initialized
INFO - 2026-03-15 15:03:26 --> Helper loaded: url_helper
INFO - 2026-03-15 15:03:26 --> Helper loaded: form_helper
INFO - 2026-03-15 15:03:26 --> Helper loaded: html_helper
INFO - 2026-03-15 15:03:26 --> Helper loaded: file_helper
INFO - 2026-03-15 15:03:26 --> Helper loaded: email_helper
INFO - 2026-03-15 15:03:26 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:03:26 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:03:26 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:03:26 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:03:26 --> Database Driver Class Initialized
INFO - 2026-03-15 15:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:03:28 --> Upload Class Initialized
DEBUG - 2026-03-15 15:03:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:03:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:03:28 --> Encryption Class Initialized
INFO - 2026-03-15 15:03:28 --> Form Validation Class Initialized
INFO - 2026-03-15 15:03:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:03:28 --> Pagination Class Initialized
INFO - 2026-03-15 15:03:28 --> Email Class Initialized
INFO - 2026-03-15 15:03:28 --> Controller Class Initialized
DEBUG - 2026-03-15 15:03:28 --> Dashboard MX_Controller Initialized
INFO - 2026-03-15 15:03:28 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:03:28 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:03:29 --> Model "Dashboard_model" initialized
DEBUG - 2026-03-15 15:03:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 15:03:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 15:03:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 15:03:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 15:03:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 15:03:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/dashboard_index.php
INFO - 2026-03-15 15:03:29 --> Final output sent to browser
DEBUG - 2026-03-15 15:03:29 --> Total execution time: 2.4092
INFO - 2026-03-15 15:03:29 --> Config Class Initialized
INFO - 2026-03-15 15:03:29 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:03:29 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:03:29 --> Utf8 Class Initialized
INFO - 2026-03-15 15:03:29 --> URI Class Initialized
INFO - 2026-03-15 15:03:29 --> Router Class Initialized
INFO - 2026-03-15 15:03:29 --> Output Class Initialized
INFO - 2026-03-15 15:03:29 --> Security Class Initialized
DEBUG - 2026-03-15 15:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:03:29 --> CSRF cookie sent
INFO - 2026-03-15 15:03:29 --> Input Class Initialized
INFO - 2026-03-15 15:03:29 --> Language Class Initialized
INFO - 2026-03-15 15:03:29 --> Language Class Initialized
INFO - 2026-03-15 15:03:29 --> Config Class Initialized
INFO - 2026-03-15 15:03:29 --> Loader Class Initialized
INFO - 2026-03-15 15:03:29 --> Config Class Initialized
INFO - 2026-03-15 15:03:29 --> Hooks Class Initialized
INFO - 2026-03-15 15:03:29 --> Helper loaded: url_helper
DEBUG - 2026-03-15 15:03:29 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:03:29 --> Helper loaded: form_helper
INFO - 2026-03-15 15:03:29 --> Utf8 Class Initialized
INFO - 2026-03-15 15:03:29 --> Config Class Initialized
INFO - 2026-03-15 15:03:29 --> Hooks Class Initialized
INFO - 2026-03-15 15:03:29 --> Helper loaded: html_helper
INFO - 2026-03-15 15:03:29 --> URI Class Initialized
INFO - 2026-03-15 15:03:29 --> Helper loaded: file_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: email_helper
DEBUG - 2026-03-15 15:03:29 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:03:29 --> Utf8 Class Initialized
INFO - 2026-03-15 15:03:29 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:03:29 --> Router Class Initialized
INFO - 2026-03-15 15:03:29 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:03:29 --> URI Class Initialized
INFO - 2026-03-15 15:03:29 --> Output Class Initialized
INFO - 2026-03-15 15:03:29 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:03:29 --> Router Class Initialized
INFO - 2026-03-15 15:03:29 --> Security Class Initialized
INFO - 2026-03-15 15:03:29 --> Helper loaded: domain_helper
DEBUG - 2026-03-15 15:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:03:29 --> CSRF cookie sent
INFO - 2026-03-15 15:03:29 --> Input Class Initialized
INFO - 2026-03-15 15:03:29 --> Output Class Initialized
INFO - 2026-03-15 15:03:29 --> Language Class Initialized
INFO - 2026-03-15 15:03:29 --> Language Class Initialized
INFO - 2026-03-15 15:03:29 --> Config Class Initialized
INFO - 2026-03-15 15:03:29 --> Security Class Initialized
DEBUG - 2026-03-15 15:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:03:29 --> CSRF cookie sent
INFO - 2026-03-15 15:03:29 --> Loader Class Initialized
INFO - 2026-03-15 15:03:29 --> Input Class Initialized
INFO - 2026-03-15 15:03:29 --> Language Class Initialized
INFO - 2026-03-15 15:03:29 --> Helper loaded: url_helper
INFO - 2026-03-15 15:03:29 --> Language Class Initialized
INFO - 2026-03-15 15:03:29 --> Config Class Initialized
INFO - 2026-03-15 15:03:29 --> Helper loaded: form_helper
INFO - 2026-03-15 15:03:29 --> Database Driver Class Initialized
INFO - 2026-03-15 15:03:29 --> Helper loaded: html_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: file_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: email_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:03:29 --> Loader Class Initialized
INFO - 2026-03-15 15:03:29 --> Helper loaded: url_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: form_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: html_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: file_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: email_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:03:29 --> Database Driver Class Initialized
INFO - 2026-03-15 15:03:29 --> Database Driver Class Initialized
INFO - 2026-03-15 15:03:29 --> Config Class Initialized
INFO - 2026-03-15 15:03:29 --> Hooks Class Initialized
INFO - 2026-03-15 15:03:29 --> Config Class Initialized
INFO - 2026-03-15 15:03:29 --> Hooks Class Initialized
INFO - 2026-03-15 15:03:29 --> Config Class Initialized
INFO - 2026-03-15 15:03:29 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:03:29 --> UTF-8 Support Enabled
DEBUG - 2026-03-15 15:03:29 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:03:29 --> Utf8 Class Initialized
INFO - 2026-03-15 15:03:29 --> Utf8 Class Initialized
INFO - 2026-03-15 15:03:29 --> URI Class Initialized
INFO - 2026-03-15 15:03:29 --> URI Class Initialized
DEBUG - 2026-03-15 15:03:29 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:03:29 --> Utf8 Class Initialized
INFO - 2026-03-15 15:03:29 --> URI Class Initialized
INFO - 2026-03-15 15:03:29 --> Router Class Initialized
INFO - 2026-03-15 15:03:29 --> Router Class Initialized
INFO - 2026-03-15 15:03:29 --> Router Class Initialized
INFO - 2026-03-15 15:03:29 --> Output Class Initialized
INFO - 2026-03-15 15:03:29 --> Output Class Initialized
INFO - 2026-03-15 15:03:29 --> Security Class Initialized
INFO - 2026-03-15 15:03:29 --> Security Class Initialized
INFO - 2026-03-15 15:03:29 --> Output Class Initialized
DEBUG - 2026-03-15 15:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:03:29 --> CSRF cookie sent
INFO - 2026-03-15 15:03:29 --> Input Class Initialized
INFO - 2026-03-15 15:03:29 --> Security Class Initialized
INFO - 2026-03-15 15:03:29 --> Language Class Initialized
DEBUG - 2026-03-15 15:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:03:29 --> CSRF cookie sent
INFO - 2026-03-15 15:03:29 --> Input Class Initialized
INFO - 2026-03-15 15:03:29 --> Language Class Initialized
INFO - 2026-03-15 15:03:29 --> Config Class Initialized
INFO - 2026-03-15 15:03:29 --> Language Class Initialized
INFO - 2026-03-15 15:03:29 --> Language Class Initialized
INFO - 2026-03-15 15:03:29 --> Config Class Initialized
INFO - 2026-03-15 15:03:29 --> Loader Class Initialized
DEBUG - 2026-03-15 15:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:03:29 --> CSRF cookie sent
INFO - 2026-03-15 15:03:29 --> Input Class Initialized
INFO - 2026-03-15 15:03:29 --> Language Class Initialized
INFO - 2026-03-15 15:03:29 --> Helper loaded: url_helper
INFO - 2026-03-15 15:03:29 --> Loader Class Initialized
INFO - 2026-03-15 15:03:29 --> Language Class Initialized
INFO - 2026-03-15 15:03:29 --> Config Class Initialized
INFO - 2026-03-15 15:03:29 --> Helper loaded: url_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: form_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: html_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: form_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: file_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: email_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: html_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: file_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: email_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:03:29 --> Loader Class Initialized
INFO - 2026-03-15 15:03:29 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: url_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: form_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: html_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: file_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: email_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:03:29 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:03:29 --> Database Driver Class Initialized
INFO - 2026-03-15 15:03:29 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:03:29 --> Database Driver Class Initialized
INFO - 2026-03-15 15:03:29 --> Database Driver Class Initialized
INFO - 2026-03-15 15:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:03:31 --> Upload Class Initialized
DEBUG - 2026-03-15 15:03:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:03:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:03:31 --> Encryption Class Initialized
INFO - 2026-03-15 15:03:31 --> Form Validation Class Initialized
INFO - 2026-03-15 15:03:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:03:31 --> Pagination Class Initialized
INFO - 2026-03-15 15:03:31 --> Email Class Initialized
INFO - 2026-03-15 15:03:31 --> Controller Class Initialized
ERROR - 2026-03-15 15:03:31 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:03:31 --> Upload Class Initialized
DEBUG - 2026-03-15 15:03:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:03:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:03:31 --> Encryption Class Initialized
INFO - 2026-03-15 15:03:31 --> Form Validation Class Initialized
INFO - 2026-03-15 15:03:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:03:31 --> Pagination Class Initialized
INFO - 2026-03-15 15:03:31 --> Config Class Initialized
INFO - 2026-03-15 15:03:31 --> Hooks Class Initialized
INFO - 2026-03-15 15:03:31 --> Email Class Initialized
INFO - 2026-03-15 15:03:31 --> Controller Class Initialized
ERROR - 2026-03-15 15:03:31 --> 404 Page Not Found: /index
DEBUG - 2026-03-15 15:03:31 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:03:31 --> Utf8 Class Initialized
INFO - 2026-03-15 15:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:03:31 --> URI Class Initialized
INFO - 2026-03-15 15:03:31 --> Router Class Initialized
INFO - 2026-03-15 15:03:31 --> Upload Class Initialized
INFO - 2026-03-15 15:03:31 --> Output Class Initialized
DEBUG - 2026-03-15 15:03:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:03:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:03:31 --> Encryption Class Initialized
INFO - 2026-03-15 15:03:31 --> Security Class Initialized
DEBUG - 2026-03-15 15:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:03:31 --> Form Validation Class Initialized
INFO - 2026-03-15 15:03:31 --> Input Class Initialized
INFO - 2026-03-15 15:03:31 --> Language Class Initialized
INFO - 2026-03-15 15:03:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:03:31 --> Pagination Class Initialized
INFO - 2026-03-15 15:03:31 --> Language Class Initialized
INFO - 2026-03-15 15:03:31 --> Config Class Initialized
INFO - 2026-03-15 15:03:31 --> Loader Class Initialized
INFO - 2026-03-15 15:03:31 --> Email Class Initialized
INFO - 2026-03-15 15:03:31 --> Controller Class Initialized
ERROR - 2026-03-15 15:03:31 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:03:31 --> Config Class Initialized
INFO - 2026-03-15 15:03:31 --> Hooks Class Initialized
INFO - 2026-03-15 15:03:31 --> Helper loaded: url_helper
INFO - 2026-03-15 15:03:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-03-15 15:03:31 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:03:31 --> Utf8 Class Initialized
INFO - 2026-03-15 15:03:31 --> Helper loaded: form_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: html_helper
INFO - 2026-03-15 15:03:31 --> Upload Class Initialized
INFO - 2026-03-15 15:03:31 --> URI Class Initialized
INFO - 2026-03-15 15:03:31 --> Helper loaded: file_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: email_helper
DEBUG - 2026-03-15 15:03:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:03:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:03:31 --> Encryption Class Initialized
INFO - 2026-03-15 15:03:31 --> Router Class Initialized
INFO - 2026-03-15 15:03:31 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:03:31 --> Output Class Initialized
INFO - 2026-03-15 15:03:31 --> Form Validation Class Initialized
INFO - 2026-03-15 15:03:31 --> Security Class Initialized
INFO - 2026-03-15 15:03:31 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:03:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:03:31 --> Pagination Class Initialized
DEBUG - 2026-03-15 15:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:03:31 --> Input Class Initialized
INFO - 2026-03-15 15:03:31 --> Config Class Initialized
INFO - 2026-03-15 15:03:31 --> Hooks Class Initialized
INFO - 2026-03-15 15:03:31 --> Language Class Initialized
INFO - 2026-03-15 15:03:31 --> Language Class Initialized
INFO - 2026-03-15 15:03:31 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:03:31 --> Config Class Initialized
DEBUG - 2026-03-15 15:03:31 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:03:31 --> Utf8 Class Initialized
INFO - 2026-03-15 15:03:31 --> URI Class Initialized
INFO - 2026-03-15 15:03:31 --> Email Class Initialized
INFO - 2026-03-15 15:03:31 --> Controller Class Initialized
ERROR - 2026-03-15 15:03:31 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:03:31 --> Router Class Initialized
INFO - 2026-03-15 15:03:31 --> Loader Class Initialized
INFO - 2026-03-15 15:03:31 --> Helper loaded: url_helper
INFO - 2026-03-15 15:03:31 --> Upload Class Initialized
INFO - 2026-03-15 15:03:31 --> Output Class Initialized
INFO - 2026-03-15 15:03:31 --> Helper loaded: form_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: html_helper
INFO - 2026-03-15 15:03:31 --> Security Class Initialized
DEBUG - 2026-03-15 15:03:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:03:31 --> Helper loaded: file_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: email_helper
INFO - 2026-03-15 15:03:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:03:31 --> Encryption Class Initialized
DEBUG - 2026-03-15 15:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:03:31 --> Input Class Initialized
INFO - 2026-03-15 15:03:31 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:03:31 --> Language Class Initialized
INFO - 2026-03-15 15:03:31 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:03:31 --> Database Driver Class Initialized
INFO - 2026-03-15 15:03:31 --> Language Class Initialized
INFO - 2026-03-15 15:03:31 --> Config Class Initialized
INFO - 2026-03-15 15:03:31 --> Form Validation Class Initialized
INFO - 2026-03-15 15:03:31 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:03:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:03:31 --> Pagination Class Initialized
INFO - 2026-03-15 15:03:31 --> Loader Class Initialized
INFO - 2026-03-15 15:03:31 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: url_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: form_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: html_helper
INFO - 2026-03-15 15:03:31 --> Email Class Initialized
INFO - 2026-03-15 15:03:31 --> Helper loaded: file_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: email_helper
INFO - 2026-03-15 15:03:31 --> Controller Class Initialized
ERROR - 2026-03-15 15:03:31 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:03:31 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:03:31 --> Config Class Initialized
INFO - 2026-03-15 15:03:31 --> Hooks Class Initialized
INFO - 2026-03-15 15:03:31 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:03:31 --> Upload Class Initialized
DEBUG - 2026-03-15 15:03:31 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:03:31 --> Utf8 Class Initialized
INFO - 2026-03-15 15:03:31 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:03:31 --> Database Driver Class Initialized
INFO - 2026-03-15 15:03:31 --> URI Class Initialized
DEBUG - 2026-03-15 15:03:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:03:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:03:31 --> Encryption Class Initialized
INFO - 2026-03-15 15:03:31 --> Router Class Initialized
INFO - 2026-03-15 15:03:31 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:03:31 --> Output Class Initialized
INFO - 2026-03-15 15:03:31 --> Form Validation Class Initialized
INFO - 2026-03-15 15:03:31 --> Security Class Initialized
INFO - 2026-03-15 15:03:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:03:31 --> Pagination Class Initialized
DEBUG - 2026-03-15 15:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:03:31 --> Input Class Initialized
INFO - 2026-03-15 15:03:31 --> Language Class Initialized
INFO - 2026-03-15 15:03:31 --> Database Driver Class Initialized
INFO - 2026-03-15 15:03:31 --> Email Class Initialized
INFO - 2026-03-15 15:03:31 --> Controller Class Initialized
INFO - 2026-03-15 15:03:31 --> Language Class Initialized
ERROR - 2026-03-15 15:03:31 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:03:31 --> Config Class Initialized
INFO - 2026-03-15 15:03:31 --> Config Class Initialized
INFO - 2026-03-15 15:03:31 --> Hooks Class Initialized
INFO - 2026-03-15 15:03:31 --> Loader Class Initialized
DEBUG - 2026-03-15 15:03:31 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:03:31 --> Utf8 Class Initialized
INFO - 2026-03-15 15:03:31 --> Helper loaded: url_helper
INFO - 2026-03-15 15:03:31 --> URI Class Initialized
INFO - 2026-03-15 15:03:31 --> Helper loaded: form_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: html_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: file_helper
INFO - 2026-03-15 15:03:31 --> Router Class Initialized
INFO - 2026-03-15 15:03:31 --> Helper loaded: email_helper
INFO - 2026-03-15 15:03:31 --> Config Class Initialized
INFO - 2026-03-15 15:03:31 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:03:31 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:03:31 --> Utf8 Class Initialized
INFO - 2026-03-15 15:03:31 --> Output Class Initialized
INFO - 2026-03-15 15:03:31 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:03:31 --> URI Class Initialized
INFO - 2026-03-15 15:03:31 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:03:31 --> Router Class Initialized
INFO - 2026-03-15 15:03:31 --> Security Class Initialized
INFO - 2026-03-15 15:03:31 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:03:31 --> Output Class Initialized
DEBUG - 2026-03-15 15:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:03:31 --> Input Class Initialized
INFO - 2026-03-15 15:03:31 --> Security Class Initialized
INFO - 2026-03-15 15:03:31 --> Language Class Initialized
INFO - 2026-03-15 15:03:31 --> Language Class Initialized
DEBUG - 2026-03-15 15:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:03:31 --> Config Class Initialized
INFO - 2026-03-15 15:03:31 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:03:31 --> Input Class Initialized
INFO - 2026-03-15 15:03:31 --> Language Class Initialized
INFO - 2026-03-15 15:03:31 --> Language Class Initialized
INFO - 2026-03-15 15:03:31 --> Config Class Initialized
INFO - 2026-03-15 15:03:31 --> Loader Class Initialized
INFO - 2026-03-15 15:03:31 --> Loader Class Initialized
INFO - 2026-03-15 15:03:31 --> Helper loaded: url_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: url_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: form_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: form_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: html_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: html_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: file_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: file_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: email_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: email_helper
INFO - 2026-03-15 15:03:31 --> Database Driver Class Initialized
INFO - 2026-03-15 15:03:31 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:03:31 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:03:31 --> Database Driver Class Initialized
INFO - 2026-03-15 15:03:31 --> Database Driver Class Initialized
INFO - 2026-03-15 15:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:03:33 --> Upload Class Initialized
DEBUG - 2026-03-15 15:03:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:03:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:03:33 --> Encryption Class Initialized
INFO - 2026-03-15 15:03:33 --> Form Validation Class Initialized
INFO - 2026-03-15 15:03:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:03:33 --> Pagination Class Initialized
INFO - 2026-03-15 15:03:33 --> Email Class Initialized
INFO - 2026-03-15 15:03:33 --> Controller Class Initialized
DEBUG - 2026-03-15 15:03:33 --> Dashboard MX_Controller Initialized
INFO - 2026-03-15 15:03:33 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:03:33 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:03:34 --> Model "Dashboard_model" initialized
INFO - 2026-03-15 15:03:34 --> Final output sent to browser
DEBUG - 2026-03-15 15:03:34 --> Total execution time: 3.3578
INFO - 2026-03-15 15:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:03:34 --> Upload Class Initialized
DEBUG - 2026-03-15 15:03:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:03:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:03:34 --> Encryption Class Initialized
INFO - 2026-03-15 15:03:34 --> Form Validation Class Initialized
INFO - 2026-03-15 15:03:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:03:34 --> Pagination Class Initialized
INFO - 2026-03-15 15:03:34 --> Email Class Initialized
INFO - 2026-03-15 15:03:34 --> Controller Class Initialized
INFO - 2026-03-15 15:03:34 --> Config Class Initialized
INFO - 2026-03-15 15:03:34 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:03:34 --> UTF-8 Support Enabled
DEBUG - 2026-03-15 15:03:34 --> Invoice MX_Controller Initialized
INFO - 2026-03-15 15:03:34 --> Utf8 Class Initialized
INFO - 2026-03-15 15:03:34 --> URI Class Initialized
INFO - 2026-03-15 15:03:34 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:03:34 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:03:34 --> Model "Billing_model" initialized
INFO - 2026-03-15 15:03:34 --> Router Class Initialized
INFO - 2026-03-15 15:03:34 --> Model "Common_model" initialized
INFO - 2026-03-15 15:03:34 --> Output Class Initialized
INFO - 2026-03-15 15:03:34 --> Model "Invoice_model" initialized
INFO - 2026-03-15 15:03:34 --> Model "Appsetting_model" initialized
INFO - 2026-03-15 15:03:34 --> Security Class Initialized
DEBUG - 2026-03-15 15:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:03:34 --> CSRF cookie sent
INFO - 2026-03-15 15:03:34 --> Input Class Initialized
INFO - 2026-03-15 15:03:34 --> Language Class Initialized
INFO - 2026-03-15 15:03:34 --> Language Class Initialized
INFO - 2026-03-15 15:03:34 --> Config Class Initialized
INFO - 2026-03-15 15:03:34 --> Loader Class Initialized
INFO - 2026-03-15 15:03:34 --> Helper loaded: url_helper
INFO - 2026-03-15 15:03:34 --> Helper loaded: form_helper
INFO - 2026-03-15 15:03:34 --> Helper loaded: html_helper
INFO - 2026-03-15 15:03:34 --> Helper loaded: file_helper
INFO - 2026-03-15 15:03:34 --> Helper loaded: email_helper
INFO - 2026-03-15 15:03:34 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:03:34 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:03:34 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:03:34 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:03:34 --> Database Driver Class Initialized
INFO - 2026-03-15 15:03:35 --> Final output sent to browser
DEBUG - 2026-03-15 15:03:35 --> Total execution time: 4.1726
INFO - 2026-03-15 15:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:03:35 --> Upload Class Initialized
DEBUG - 2026-03-15 15:03:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:03:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:03:35 --> Encryption Class Initialized
INFO - 2026-03-15 15:03:35 --> Form Validation Class Initialized
INFO - 2026-03-15 15:03:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:03:35 --> Pagination Class Initialized
INFO - 2026-03-15 15:03:35 --> Email Class Initialized
INFO - 2026-03-15 15:03:35 --> Controller Class Initialized
DEBUG - 2026-03-15 15:03:35 --> Order MX_Controller Initialized
INFO - 2026-03-15 15:03:35 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:03:35 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:03:35 --> Model "Order_model" initialized
INFO - 2026-03-15 15:03:35 --> Model "Common_model" initialized
INFO - 2026-03-15 15:03:35 --> Model "Currency_model" initialized
INFO - 2026-03-15 15:03:36 --> Final output sent to browser
DEBUG - 2026-03-15 15:03:36 --> Total execution time: 5.0076
INFO - 2026-03-15 15:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:03:36 --> Upload Class Initialized
DEBUG - 2026-03-15 15:03:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:03:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:03:36 --> Encryption Class Initialized
INFO - 2026-03-15 15:03:36 --> Form Validation Class Initialized
INFO - 2026-03-15 15:03:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:03:36 --> Pagination Class Initialized
INFO - 2026-03-15 15:03:36 --> Email Class Initialized
INFO - 2026-03-15 15:03:36 --> Controller Class Initialized
DEBUG - 2026-03-15 15:03:36 --> Ticket MX_Controller Initialized
INFO - 2026-03-15 15:03:36 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:03:36 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:03:36 --> Model "Support_model" initialized
INFO - 2026-03-15 15:03:36 --> Model "Common_model" initialized
INFO - 2026-03-15 15:03:38 --> Final output sent to browser
DEBUG - 2026-03-15 15:03:38 --> Total execution time: 7.7515
INFO - 2026-03-15 15:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:03:38 --> Upload Class Initialized
DEBUG - 2026-03-15 15:03:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:03:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:03:38 --> Encryption Class Initialized
INFO - 2026-03-15 15:03:38 --> Form Validation Class Initialized
INFO - 2026-03-15 15:03:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:03:38 --> Pagination Class Initialized
INFO - 2026-03-15 15:03:38 --> Email Class Initialized
INFO - 2026-03-15 15:03:38 --> Controller Class Initialized
DEBUG - 2026-03-15 15:03:38 --> Dashboard MX_Controller Initialized
INFO - 2026-03-15 15:03:38 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:03:38 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:03:39 --> Model "Dashboard_model" initialized
INFO - 2026-03-15 15:03:39 --> Final output sent to browser
DEBUG - 2026-03-15 15:03:39 --> Total execution time: 8.5926
INFO - 2026-03-15 15:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:03:39 --> Upload Class Initialized
DEBUG - 2026-03-15 15:03:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:03:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:03:39 --> Encryption Class Initialized
INFO - 2026-03-15 15:03:39 --> Form Validation Class Initialized
INFO - 2026-03-15 15:03:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:03:39 --> Pagination Class Initialized
INFO - 2026-03-15 15:03:39 --> Email Class Initialized
INFO - 2026-03-15 15:03:39 --> Controller Class Initialized
DEBUG - 2026-03-15 15:03:39 --> Dashboard MX_Controller Initialized
INFO - 2026-03-15 15:03:39 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:03:39 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:03:40 --> Model "Dashboard_model" initialized
INFO - 2026-03-15 15:03:40 --> Final output sent to browser
DEBUG - 2026-03-15 15:03:40 --> Total execution time: 9.3865
INFO - 2026-03-15 15:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:03:40 --> Upload Class Initialized
DEBUG - 2026-03-15 15:03:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:03:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:03:40 --> Encryption Class Initialized
INFO - 2026-03-15 15:03:40 --> Form Validation Class Initialized
INFO - 2026-03-15 15:03:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:03:40 --> Pagination Class Initialized
INFO - 2026-03-15 15:03:40 --> Email Class Initialized
INFO - 2026-03-15 15:03:40 --> Controller Class Initialized
ERROR - 2026-03-15 15:03:40 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:04:19 --> Config Class Initialized
INFO - 2026-03-15 15:04:19 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:04:19 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:04:19 --> Utf8 Class Initialized
INFO - 2026-03-15 15:04:19 --> URI Class Initialized
INFO - 2026-03-15 15:04:19 --> Router Class Initialized
INFO - 2026-03-15 15:04:19 --> Output Class Initialized
INFO - 2026-03-15 15:04:19 --> Security Class Initialized
DEBUG - 2026-03-15 15:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:04:19 --> CSRF cookie sent
INFO - 2026-03-15 15:04:19 --> Input Class Initialized
INFO - 2026-03-15 15:04:19 --> Language Class Initialized
INFO - 2026-03-15 15:04:19 --> Language Class Initialized
INFO - 2026-03-15 15:04:19 --> Config Class Initialized
INFO - 2026-03-15 15:04:19 --> Loader Class Initialized
INFO - 2026-03-15 15:04:19 --> Helper loaded: url_helper
INFO - 2026-03-15 15:04:19 --> Helper loaded: form_helper
INFO - 2026-03-15 15:04:19 --> Helper loaded: html_helper
INFO - 2026-03-15 15:04:19 --> Helper loaded: file_helper
INFO - 2026-03-15 15:04:19 --> Helper loaded: email_helper
INFO - 2026-03-15 15:04:19 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:04:19 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:04:19 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:04:19 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:04:19 --> Database Driver Class Initialized
INFO - 2026-03-15 15:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:04:21 --> Upload Class Initialized
DEBUG - 2026-03-15 15:04:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:04:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:04:21 --> Encryption Class Initialized
INFO - 2026-03-15 15:04:21 --> Form Validation Class Initialized
INFO - 2026-03-15 15:04:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:04:21 --> Pagination Class Initialized
INFO - 2026-03-15 15:04:21 --> Email Class Initialized
INFO - 2026-03-15 15:04:21 --> Controller Class Initialized
DEBUG - 2026-03-15 15:04:21 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:04:21 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:04:21 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:04:21 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:04:21 --> Model "Common_model" initialized
DEBUG - 2026-03-15 15:04:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 15:04:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 15:04:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 15:04:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 15:04:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 15:04:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_list.php
INFO - 2026-03-15 15:04:21 --> Final output sent to browser
DEBUG - 2026-03-15 15:04:21 --> Total execution time: 2.4450
INFO - 2026-03-15 15:04:21 --> Config Class Initialized
INFO - 2026-03-15 15:04:21 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:04:21 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:04:21 --> Utf8 Class Initialized
INFO - 2026-03-15 15:04:21 --> URI Class Initialized
INFO - 2026-03-15 15:04:21 --> Router Class Initialized
INFO - 2026-03-15 15:04:21 --> Output Class Initialized
INFO - 2026-03-15 15:04:21 --> Security Class Initialized
DEBUG - 2026-03-15 15:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:04:21 --> CSRF cookie sent
INFO - 2026-03-15 15:04:21 --> Input Class Initialized
INFO - 2026-03-15 15:04:21 --> Language Class Initialized
INFO - 2026-03-15 15:04:21 --> Language Class Initialized
INFO - 2026-03-15 15:04:21 --> Config Class Initialized
INFO - 2026-03-15 15:04:21 --> Loader Class Initialized
INFO - 2026-03-15 15:04:21 --> Helper loaded: url_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: form_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: html_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: file_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: email_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:04:21 --> Database Driver Class Initialized
INFO - 2026-03-15 15:04:21 --> Config Class Initialized
INFO - 2026-03-15 15:04:21 --> Hooks Class Initialized
INFO - 2026-03-15 15:04:21 --> Config Class Initialized
INFO - 2026-03-15 15:04:21 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:04:21 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:04:21 --> Utf8 Class Initialized
INFO - 2026-03-15 15:04:21 --> URI Class Initialized
DEBUG - 2026-03-15 15:04:21 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:04:21 --> Utf8 Class Initialized
INFO - 2026-03-15 15:04:21 --> URI Class Initialized
INFO - 2026-03-15 15:04:21 --> Router Class Initialized
INFO - 2026-03-15 15:04:21 --> Router Class Initialized
INFO - 2026-03-15 15:04:21 --> Output Class Initialized
INFO - 2026-03-15 15:04:21 --> Output Class Initialized
INFO - 2026-03-15 15:04:21 --> Security Class Initialized
INFO - 2026-03-15 15:04:21 --> Security Class Initialized
DEBUG - 2026-03-15 15:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:04:21 --> CSRF cookie sent
INFO - 2026-03-15 15:04:21 --> Input Class Initialized
INFO - 2026-03-15 15:04:21 --> Language Class Initialized
DEBUG - 2026-03-15 15:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:04:21 --> CSRF cookie sent
INFO - 2026-03-15 15:04:21 --> Input Class Initialized
INFO - 2026-03-15 15:04:21 --> Language Class Initialized
INFO - 2026-03-15 15:04:21 --> Language Class Initialized
INFO - 2026-03-15 15:04:21 --> Config Class Initialized
INFO - 2026-03-15 15:04:21 --> Language Class Initialized
INFO - 2026-03-15 15:04:21 --> Config Class Initialized
INFO - 2026-03-15 15:04:21 --> Loader Class Initialized
INFO - 2026-03-15 15:04:21 --> Helper loaded: url_helper
INFO - 2026-03-15 15:04:21 --> Loader Class Initialized
INFO - 2026-03-15 15:04:21 --> Helper loaded: url_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: form_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: html_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: form_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: file_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: email_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: html_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: file_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: email_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:04:21 --> Database Driver Class Initialized
INFO - 2026-03-15 15:04:21 --> Database Driver Class Initialized
INFO - 2026-03-15 15:04:21 --> Config Class Initialized
INFO - 2026-03-15 15:04:21 --> Config Class Initialized
INFO - 2026-03-15 15:04:21 --> Config Class Initialized
INFO - 2026-03-15 15:04:21 --> Hooks Class Initialized
INFO - 2026-03-15 15:04:21 --> Hooks Class Initialized
INFO - 2026-03-15 15:04:21 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:04:21 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:04:21 --> Utf8 Class Initialized
DEBUG - 2026-03-15 15:04:21 --> UTF-8 Support Enabled
DEBUG - 2026-03-15 15:04:21 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:04:21 --> Utf8 Class Initialized
INFO - 2026-03-15 15:04:21 --> Utf8 Class Initialized
INFO - 2026-03-15 15:04:21 --> URI Class Initialized
INFO - 2026-03-15 15:04:21 --> URI Class Initialized
INFO - 2026-03-15 15:04:21 --> URI Class Initialized
INFO - 2026-03-15 15:04:21 --> Router Class Initialized
INFO - 2026-03-15 15:04:21 --> Router Class Initialized
INFO - 2026-03-15 15:04:21 --> Router Class Initialized
INFO - 2026-03-15 15:04:21 --> Output Class Initialized
INFO - 2026-03-15 15:04:21 --> Output Class Initialized
INFO - 2026-03-15 15:04:21 --> Security Class Initialized
INFO - 2026-03-15 15:04:21 --> Output Class Initialized
DEBUG - 2026-03-15 15:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:04:21 --> CSRF cookie sent
INFO - 2026-03-15 15:04:21 --> Input Class Initialized
INFO - 2026-03-15 15:04:21 --> Language Class Initialized
INFO - 2026-03-15 15:04:21 --> Security Class Initialized
INFO - 2026-03-15 15:04:21 --> Security Class Initialized
INFO - 2026-03-15 15:04:21 --> Language Class Initialized
INFO - 2026-03-15 15:04:21 --> Config Class Initialized
DEBUG - 2026-03-15 15:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:04:21 --> CSRF cookie sent
INFO - 2026-03-15 15:04:21 --> Input Class Initialized
DEBUG - 2026-03-15 15:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:04:21 --> Language Class Initialized
INFO - 2026-03-15 15:04:21 --> CSRF cookie sent
INFO - 2026-03-15 15:04:21 --> Input Class Initialized
INFO - 2026-03-15 15:04:21 --> Language Class Initialized
INFO - 2026-03-15 15:04:21 --> Language Class Initialized
INFO - 2026-03-15 15:04:21 --> Config Class Initialized
INFO - 2026-03-15 15:04:21 --> Language Class Initialized
INFO - 2026-03-15 15:04:21 --> Config Class Initialized
INFO - 2026-03-15 15:04:21 --> Loader Class Initialized
INFO - 2026-03-15 15:04:21 --> Helper loaded: url_helper
INFO - 2026-03-15 15:04:21 --> Loader Class Initialized
INFO - 2026-03-15 15:04:21 --> Helper loaded: form_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: html_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: url_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: file_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: email_helper
INFO - 2026-03-15 15:04:21 --> Loader Class Initialized
INFO - 2026-03-15 15:04:21 --> Helper loaded: form_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: html_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: file_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: email_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: url_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: form_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: html_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: file_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: email_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:04:21 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:04:21 --> Database Driver Class Initialized
INFO - 2026-03-15 15:04:21 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:04:21 --> Database Driver Class Initialized
INFO - 2026-03-15 15:04:21 --> Database Driver Class Initialized
INFO - 2026-03-15 15:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:04:23 --> Upload Class Initialized
DEBUG - 2026-03-15 15:04:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:04:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:04:23 --> Encryption Class Initialized
INFO - 2026-03-15 15:04:23 --> Form Validation Class Initialized
INFO - 2026-03-15 15:04:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:04:23 --> Pagination Class Initialized
INFO - 2026-03-15 15:04:23 --> Email Class Initialized
INFO - 2026-03-15 15:04:23 --> Controller Class Initialized
ERROR - 2026-03-15 15:04:23 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:04:23 --> Upload Class Initialized
DEBUG - 2026-03-15 15:04:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:04:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:04:23 --> Encryption Class Initialized
INFO - 2026-03-15 15:04:23 --> Form Validation Class Initialized
INFO - 2026-03-15 15:04:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:04:23 --> Pagination Class Initialized
INFO - 2026-03-15 15:04:23 --> Email Class Initialized
INFO - 2026-03-15 15:04:23 --> Controller Class Initialized
ERROR - 2026-03-15 15:04:23 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:04:23 --> Config Class Initialized
INFO - 2026-03-15 15:04:23 --> Hooks Class Initialized
INFO - 2026-03-15 15:04:23 --> Upload Class Initialized
DEBUG - 2026-03-15 15:04:23 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:04:23 --> Utf8 Class Initialized
INFO - 2026-03-15 15:04:23 --> URI Class Initialized
DEBUG - 2026-03-15 15:04:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:04:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:04:23 --> Encryption Class Initialized
INFO - 2026-03-15 15:04:23 --> Router Class Initialized
INFO - 2026-03-15 15:04:23 --> Form Validation Class Initialized
INFO - 2026-03-15 15:04:23 --> Output Class Initialized
INFO - 2026-03-15 15:04:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:04:23 --> Pagination Class Initialized
INFO - 2026-03-15 15:04:23 --> Security Class Initialized
DEBUG - 2026-03-15 15:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:04:23 --> CSRF cookie sent
INFO - 2026-03-15 15:04:23 --> Input Class Initialized
INFO - 2026-03-15 15:04:23 --> Language Class Initialized
INFO - 2026-03-15 15:04:23 --> Language Class Initialized
INFO - 2026-03-15 15:04:23 --> Config Class Initialized
INFO - 2026-03-15 15:04:23 --> Config Class Initialized
INFO - 2026-03-15 15:04:23 --> Hooks Class Initialized
INFO - 2026-03-15 15:04:23 --> Email Class Initialized
INFO - 2026-03-15 15:04:23 --> Controller Class Initialized
ERROR - 2026-03-15 15:04:23 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:04:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-03-15 15:04:23 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:04:23 --> Utf8 Class Initialized
INFO - 2026-03-15 15:04:23 --> URI Class Initialized
INFO - 2026-03-15 15:04:23 --> Loader Class Initialized
INFO - 2026-03-15 15:04:23 --> Helper loaded: url_helper
INFO - 2026-03-15 15:04:23 --> Upload Class Initialized
INFO - 2026-03-15 15:04:23 --> Router Class Initialized
INFO - 2026-03-15 15:04:23 --> Helper loaded: form_helper
DEBUG - 2026-03-15 15:04:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:04:23 --> Output Class Initialized
INFO - 2026-03-15 15:04:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:04:23 --> Encryption Class Initialized
INFO - 2026-03-15 15:04:23 --> Helper loaded: html_helper
INFO - 2026-03-15 15:04:23 --> Helper loaded: file_helper
INFO - 2026-03-15 15:04:23 --> Security Class Initialized
INFO - 2026-03-15 15:04:23 --> Helper loaded: email_helper
DEBUG - 2026-03-15 15:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:04:23 --> CSRF cookie sent
INFO - 2026-03-15 15:04:23 --> Input Class Initialized
INFO - 2026-03-15 15:04:23 --> Form Validation Class Initialized
INFO - 2026-03-15 15:04:23 --> Language Class Initialized
INFO - 2026-03-15 15:04:23 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:04:23 --> Language Class Initialized
INFO - 2026-03-15 15:04:23 --> Config Class Initialized
INFO - 2026-03-15 15:04:23 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:04:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:04:23 --> Pagination Class Initialized
INFO - 2026-03-15 15:04:23 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:04:23 --> Loader Class Initialized
INFO - 2026-03-15 15:04:23 --> Helper loaded: url_helper
INFO - 2026-03-15 15:04:23 --> Helper loaded: form_helper
INFO - 2026-03-15 15:04:23 --> Email Class Initialized
INFO - 2026-03-15 15:04:23 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:04:23 --> Controller Class Initialized
INFO - 2026-03-15 15:04:23 --> Helper loaded: html_helper
ERROR - 2026-03-15 15:04:23 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:04:23 --> Helper loaded: file_helper
INFO - 2026-03-15 15:04:23 --> Helper loaded: email_helper
INFO - 2026-03-15 15:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:04:23 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:04:23 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:04:23 --> Upload Class Initialized
DEBUG - 2026-03-15 15:04:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:04:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:04:23 --> Encryption Class Initialized
INFO - 2026-03-15 15:04:23 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:04:23 --> Database Driver Class Initialized
INFO - 2026-03-15 15:04:23 --> Form Validation Class Initialized
INFO - 2026-03-15 15:04:23 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:04:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:04:23 --> Pagination Class Initialized
INFO - 2026-03-15 15:04:23 --> Email Class Initialized
INFO - 2026-03-15 15:04:23 --> Controller Class Initialized
ERROR - 2026-03-15 15:04:23 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:04:23 --> Database Driver Class Initialized
INFO - 2026-03-15 15:04:23 --> Upload Class Initialized
DEBUG - 2026-03-15 15:04:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:04:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:04:23 --> Encryption Class Initialized
INFO - 2026-03-15 15:04:23 --> Form Validation Class Initialized
INFO - 2026-03-15 15:04:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:04:23 --> Pagination Class Initialized
INFO - 2026-03-15 15:04:23 --> Email Class Initialized
INFO - 2026-03-15 15:04:23 --> Controller Class Initialized
ERROR - 2026-03-15 15:04:23 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:04:25 --> Upload Class Initialized
DEBUG - 2026-03-15 15:04:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:04:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:04:25 --> Encryption Class Initialized
INFO - 2026-03-15 15:04:25 --> Form Validation Class Initialized
INFO - 2026-03-15 15:04:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:04:25 --> Pagination Class Initialized
INFO - 2026-03-15 15:04:25 --> Email Class Initialized
INFO - 2026-03-15 15:04:25 --> Controller Class Initialized
DEBUG - 2026-03-15 15:04:25 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:04:25 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:04:25 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:04:25 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:04:25 --> Model "Common_model" initialized
INFO - 2026-03-15 15:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:04:27 --> Upload Class Initialized
DEBUG - 2026-03-15 15:04:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:04:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:04:27 --> Encryption Class Initialized
INFO - 2026-03-15 15:04:27 --> Form Validation Class Initialized
INFO - 2026-03-15 15:04:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:04:27 --> Pagination Class Initialized
INFO - 2026-03-15 15:04:27 --> Email Class Initialized
INFO - 2026-03-15 15:04:27 --> Controller Class Initialized
ERROR - 2026-03-15 15:04:27 --> 404 Page Not Found: /index
INFO - 2026-03-15 15:04:42 --> Config Class Initialized
INFO - 2026-03-15 15:04:42 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:04:42 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:04:42 --> Utf8 Class Initialized
INFO - 2026-03-15 15:04:42 --> URI Class Initialized
INFO - 2026-03-15 15:04:42 --> Router Class Initialized
INFO - 2026-03-15 15:04:42 --> Output Class Initialized
INFO - 2026-03-15 15:04:42 --> Security Class Initialized
DEBUG - 2026-03-15 15:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:04:42 --> CSRF cookie sent
INFO - 2026-03-15 15:04:42 --> Input Class Initialized
INFO - 2026-03-15 15:04:42 --> Language Class Initialized
INFO - 2026-03-15 15:04:42 --> Language Class Initialized
INFO - 2026-03-15 15:04:42 --> Config Class Initialized
INFO - 2026-03-15 15:04:42 --> Loader Class Initialized
INFO - 2026-03-15 15:04:42 --> Helper loaded: url_helper
INFO - 2026-03-15 15:04:42 --> Helper loaded: form_helper
INFO - 2026-03-15 15:04:42 --> Helper loaded: html_helper
INFO - 2026-03-15 15:04:42 --> Helper loaded: file_helper
INFO - 2026-03-15 15:04:42 --> Helper loaded: email_helper
INFO - 2026-03-15 15:04:42 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:04:42 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:04:42 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:04:42 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:04:42 --> Database Driver Class Initialized
INFO - 2026-03-15 15:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:04:44 --> Upload Class Initialized
DEBUG - 2026-03-15 15:04:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:04:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:04:44 --> Encryption Class Initialized
INFO - 2026-03-15 15:04:44 --> Form Validation Class Initialized
INFO - 2026-03-15 15:04:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:04:44 --> Pagination Class Initialized
INFO - 2026-03-15 15:04:44 --> Email Class Initialized
INFO - 2026-03-15 15:04:44 --> Controller Class Initialized
DEBUG - 2026-03-15 15:04:44 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:04:44 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:04:44 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:04:44 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:04:44 --> Model "Common_model" initialized
INFO - 2026-03-15 15:12:18 --> Config Class Initialized
INFO - 2026-03-15 15:12:18 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:12:18 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:12:18 --> Utf8 Class Initialized
INFO - 2026-03-15 15:12:18 --> URI Class Initialized
INFO - 2026-03-15 15:12:18 --> Router Class Initialized
INFO - 2026-03-15 15:12:18 --> Output Class Initialized
INFO - 2026-03-15 15:12:18 --> Security Class Initialized
DEBUG - 2026-03-15 15:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:12:18 --> CSRF cookie sent
INFO - 2026-03-15 15:12:18 --> Input Class Initialized
INFO - 2026-03-15 15:12:18 --> Language Class Initialized
INFO - 2026-03-15 15:12:18 --> Language Class Initialized
INFO - 2026-03-15 15:12:18 --> Config Class Initialized
INFO - 2026-03-15 15:12:18 --> Loader Class Initialized
INFO - 2026-03-15 15:12:18 --> Helper loaded: url_helper
INFO - 2026-03-15 15:12:18 --> Helper loaded: form_helper
INFO - 2026-03-15 15:12:18 --> Helper loaded: html_helper
INFO - 2026-03-15 15:12:18 --> Helper loaded: file_helper
INFO - 2026-03-15 15:12:18 --> Helper loaded: email_helper
INFO - 2026-03-15 15:12:18 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:12:18 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:12:18 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:12:18 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:12:18 --> Database Driver Class Initialized
INFO - 2026-03-15 15:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:12:20 --> Upload Class Initialized
DEBUG - 2026-03-15 15:12:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:12:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:12:20 --> Encryption Class Initialized
INFO - 2026-03-15 15:12:20 --> Form Validation Class Initialized
INFO - 2026-03-15 15:12:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:12:20 --> Pagination Class Initialized
INFO - 2026-03-15 15:12:20 --> Email Class Initialized
INFO - 2026-03-15 15:12:20 --> Controller Class Initialized
DEBUG - 2026-03-15 15:12:20 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:12:20 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:12:20 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:12:20 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:12:20 --> Model "Common_model" initialized
DEBUG - 2026-03-15 15:12:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 15:12:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 15:12:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 15:12:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 15:12:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 15:12:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_list.php
INFO - 2026-03-15 15:12:21 --> Final output sent to browser
DEBUG - 2026-03-15 15:12:21 --> Total execution time: 2.4434
INFO - 2026-03-15 15:12:21 --> Config Class Initialized
INFO - 2026-03-15 15:12:21 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:12:21 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:12:21 --> Utf8 Class Initialized
INFO - 2026-03-15 15:12:21 --> URI Class Initialized
INFO - 2026-03-15 15:12:21 --> Router Class Initialized
INFO - 2026-03-15 15:12:21 --> Output Class Initialized
INFO - 2026-03-15 15:12:21 --> Security Class Initialized
DEBUG - 2026-03-15 15:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:12:21 --> CSRF cookie sent
INFO - 2026-03-15 15:12:21 --> Input Class Initialized
INFO - 2026-03-15 15:12:21 --> Language Class Initialized
INFO - 2026-03-15 15:12:21 --> Language Class Initialized
INFO - 2026-03-15 15:12:21 --> Config Class Initialized
INFO - 2026-03-15 15:12:21 --> Loader Class Initialized
INFO - 2026-03-15 15:12:21 --> Helper loaded: url_helper
INFO - 2026-03-15 15:12:21 --> Helper loaded: form_helper
INFO - 2026-03-15 15:12:21 --> Helper loaded: html_helper
INFO - 2026-03-15 15:12:21 --> Helper loaded: file_helper
INFO - 2026-03-15 15:12:21 --> Helper loaded: email_helper
INFO - 2026-03-15 15:12:21 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:12:21 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:12:21 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:12:21 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:12:21 --> Database Driver Class Initialized
INFO - 2026-03-15 15:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:12:23 --> Upload Class Initialized
DEBUG - 2026-03-15 15:12:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:12:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:12:23 --> Encryption Class Initialized
INFO - 2026-03-15 15:12:23 --> Form Validation Class Initialized
INFO - 2026-03-15 15:12:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:12:23 --> Pagination Class Initialized
INFO - 2026-03-15 15:12:23 --> Email Class Initialized
INFO - 2026-03-15 15:12:23 --> Controller Class Initialized
DEBUG - 2026-03-15 15:12:23 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:12:23 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:12:23 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:12:23 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:12:23 --> Model "Common_model" initialized
INFO - 2026-03-15 15:12:58 --> Config Class Initialized
INFO - 2026-03-15 15:12:58 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:12:58 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:12:58 --> Utf8 Class Initialized
INFO - 2026-03-15 15:12:58 --> URI Class Initialized
INFO - 2026-03-15 15:12:58 --> Router Class Initialized
INFO - 2026-03-15 15:12:58 --> Output Class Initialized
INFO - 2026-03-15 15:12:58 --> Security Class Initialized
DEBUG - 2026-03-15 15:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:12:58 --> CSRF cookie sent
INFO - 2026-03-15 15:12:58 --> Input Class Initialized
INFO - 2026-03-15 15:12:58 --> Language Class Initialized
INFO - 2026-03-15 15:12:58 --> Language Class Initialized
INFO - 2026-03-15 15:12:58 --> Config Class Initialized
INFO - 2026-03-15 15:12:58 --> Loader Class Initialized
INFO - 2026-03-15 15:12:58 --> Helper loaded: url_helper
INFO - 2026-03-15 15:12:58 --> Helper loaded: form_helper
INFO - 2026-03-15 15:12:58 --> Helper loaded: html_helper
INFO - 2026-03-15 15:12:58 --> Helper loaded: file_helper
INFO - 2026-03-15 15:12:58 --> Helper loaded: email_helper
INFO - 2026-03-15 15:12:58 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:12:58 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:12:58 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:12:58 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:12:58 --> Database Driver Class Initialized
INFO - 2026-03-15 15:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:13:00 --> Upload Class Initialized
DEBUG - 2026-03-15 15:13:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:13:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:13:00 --> Encryption Class Initialized
INFO - 2026-03-15 15:13:00 --> Form Validation Class Initialized
INFO - 2026-03-15 15:13:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:13:00 --> Pagination Class Initialized
INFO - 2026-03-15 15:13:00 --> Email Class Initialized
INFO - 2026-03-15 15:13:00 --> Controller Class Initialized
DEBUG - 2026-03-15 15:13:00 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:13:00 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:13:00 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:13:00 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:13:00 --> Model "Common_model" initialized
INFO - 2026-03-15 15:13:05 --> Config Class Initialized
INFO - 2026-03-15 15:13:05 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:13:05 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:13:05 --> Utf8 Class Initialized
INFO - 2026-03-15 15:13:05 --> URI Class Initialized
INFO - 2026-03-15 15:13:05 --> Router Class Initialized
INFO - 2026-03-15 15:13:05 --> Output Class Initialized
INFO - 2026-03-15 15:13:05 --> Security Class Initialized
DEBUG - 2026-03-15 15:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:13:05 --> CSRF cookie sent
INFO - 2026-03-15 15:13:05 --> Input Class Initialized
INFO - 2026-03-15 15:13:05 --> Language Class Initialized
INFO - 2026-03-15 15:13:05 --> Language Class Initialized
INFO - 2026-03-15 15:13:05 --> Config Class Initialized
INFO - 2026-03-15 15:13:05 --> Loader Class Initialized
INFO - 2026-03-15 15:13:05 --> Helper loaded: url_helper
INFO - 2026-03-15 15:13:05 --> Helper loaded: form_helper
INFO - 2026-03-15 15:13:05 --> Helper loaded: html_helper
INFO - 2026-03-15 15:13:05 --> Helper loaded: file_helper
INFO - 2026-03-15 15:13:05 --> Helper loaded: email_helper
INFO - 2026-03-15 15:13:05 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:13:05 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:13:05 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:13:05 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:13:05 --> Database Driver Class Initialized
INFO - 2026-03-15 15:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:13:06 --> Upload Class Initialized
DEBUG - 2026-03-15 15:13:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:13:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:13:06 --> Encryption Class Initialized
INFO - 2026-03-15 15:13:06 --> Form Validation Class Initialized
INFO - 2026-03-15 15:13:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:13:06 --> Pagination Class Initialized
INFO - 2026-03-15 15:13:06 --> Email Class Initialized
INFO - 2026-03-15 15:13:06 --> Controller Class Initialized
DEBUG - 2026-03-15 15:13:06 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:13:06 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:13:06 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:13:06 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:13:06 --> Model "Common_model" initialized
DEBUG - 2026-03-15 15:13:09 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 15:13:09 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 15:13:09 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 15:13:09 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 15:13:09 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 15:13:09 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_manage.php
INFO - 2026-03-15 15:13:09 --> Final output sent to browser
DEBUG - 2026-03-15 15:13:09 --> Total execution time: 4.6446
INFO - 2026-03-15 15:13:09 --> Config Class Initialized
INFO - 2026-03-15 15:13:09 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:13:09 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:13:09 --> Utf8 Class Initialized
INFO - 2026-03-15 15:13:09 --> URI Class Initialized
INFO - 2026-03-15 15:13:09 --> Router Class Initialized
INFO - 2026-03-15 15:13:09 --> Output Class Initialized
INFO - 2026-03-15 15:13:09 --> Security Class Initialized
DEBUG - 2026-03-15 15:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:13:09 --> CSRF cookie sent
INFO - 2026-03-15 15:13:09 --> Input Class Initialized
INFO - 2026-03-15 15:13:09 --> Language Class Initialized
INFO - 2026-03-15 15:13:09 --> Language Class Initialized
INFO - 2026-03-15 15:13:09 --> Config Class Initialized
INFO - 2026-03-15 15:13:09 --> Loader Class Initialized
INFO - 2026-03-15 15:13:09 --> Helper loaded: url_helper
INFO - 2026-03-15 15:13:09 --> Helper loaded: form_helper
INFO - 2026-03-15 15:13:09 --> Helper loaded: html_helper
INFO - 2026-03-15 15:13:09 --> Helper loaded: file_helper
INFO - 2026-03-15 15:13:09 --> Helper loaded: email_helper
INFO - 2026-03-15 15:13:09 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:13:09 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:13:09 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:13:09 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:13:09 --> Database Driver Class Initialized
INFO - 2026-03-15 15:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:13:11 --> Upload Class Initialized
DEBUG - 2026-03-15 15:13:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:13:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:13:11 --> Encryption Class Initialized
INFO - 2026-03-15 15:13:11 --> Form Validation Class Initialized
INFO - 2026-03-15 15:13:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:13:11 --> Pagination Class Initialized
INFO - 2026-03-15 15:13:11 --> Email Class Initialized
INFO - 2026-03-15 15:13:11 --> Controller Class Initialized
DEBUG - 2026-03-15 15:13:11 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:13:11 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:13:11 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:13:11 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:13:11 --> Model "Common_model" initialized
INFO - 2026-03-15 15:15:00 --> Config Class Initialized
INFO - 2026-03-15 15:15:00 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:15:00 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:15:00 --> Utf8 Class Initialized
INFO - 2026-03-15 15:15:00 --> URI Class Initialized
INFO - 2026-03-15 15:15:00 --> Router Class Initialized
INFO - 2026-03-15 15:15:00 --> Output Class Initialized
INFO - 2026-03-15 15:15:00 --> Security Class Initialized
DEBUG - 2026-03-15 15:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:15:00 --> CSRF cookie sent
INFO - 2026-03-15 15:15:00 --> Input Class Initialized
INFO - 2026-03-15 15:15:00 --> Language Class Initialized
INFO - 2026-03-15 15:15:00 --> Language Class Initialized
INFO - 2026-03-15 15:15:00 --> Config Class Initialized
INFO - 2026-03-15 15:15:00 --> Loader Class Initialized
INFO - 2026-03-15 15:15:00 --> Helper loaded: url_helper
INFO - 2026-03-15 15:15:00 --> Helper loaded: form_helper
INFO - 2026-03-15 15:15:00 --> Helper loaded: html_helper
INFO - 2026-03-15 15:15:00 --> Helper loaded: file_helper
INFO - 2026-03-15 15:15:00 --> Helper loaded: email_helper
INFO - 2026-03-15 15:15:00 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:15:00 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:15:00 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:15:00 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:15:00 --> Database Driver Class Initialized
INFO - 2026-03-15 15:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:15:02 --> Upload Class Initialized
DEBUG - 2026-03-15 15:15:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:15:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:15:02 --> Encryption Class Initialized
INFO - 2026-03-15 15:15:02 --> Form Validation Class Initialized
INFO - 2026-03-15 15:15:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:15:02 --> Pagination Class Initialized
INFO - 2026-03-15 15:15:02 --> Email Class Initialized
INFO - 2026-03-15 15:15:02 --> Controller Class Initialized
DEBUG - 2026-03-15 15:15:02 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:15:02 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:15:02 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:15:02 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:15:02 --> Model "Common_model" initialized
DEBUG - 2026-03-15 15:15:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 15:15:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 15:15:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 15:15:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 15:15:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 15:15:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_manage.php
INFO - 2026-03-15 15:15:05 --> Final output sent to browser
DEBUG - 2026-03-15 15:15:05 --> Total execution time: 5.1080
INFO - 2026-03-15 15:15:05 --> Config Class Initialized
INFO - 2026-03-15 15:15:05 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:15:05 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:15:05 --> Utf8 Class Initialized
INFO - 2026-03-15 15:15:05 --> URI Class Initialized
INFO - 2026-03-15 15:15:05 --> Router Class Initialized
INFO - 2026-03-15 15:15:05 --> Output Class Initialized
INFO - 2026-03-15 15:15:05 --> Security Class Initialized
DEBUG - 2026-03-15 15:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:15:05 --> CSRF cookie sent
INFO - 2026-03-15 15:15:05 --> Input Class Initialized
INFO - 2026-03-15 15:15:05 --> Language Class Initialized
INFO - 2026-03-15 15:15:05 --> Language Class Initialized
INFO - 2026-03-15 15:15:05 --> Config Class Initialized
INFO - 2026-03-15 15:15:05 --> Loader Class Initialized
INFO - 2026-03-15 15:15:05 --> Helper loaded: url_helper
INFO - 2026-03-15 15:15:05 --> Helper loaded: form_helper
INFO - 2026-03-15 15:15:05 --> Helper loaded: html_helper
INFO - 2026-03-15 15:15:05 --> Helper loaded: file_helper
INFO - 2026-03-15 15:15:05 --> Helper loaded: email_helper
INFO - 2026-03-15 15:15:05 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:15:05 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:15:05 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:15:05 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:15:05 --> Database Driver Class Initialized
INFO - 2026-03-15 15:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:15:07 --> Upload Class Initialized
DEBUG - 2026-03-15 15:15:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:15:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:15:07 --> Encryption Class Initialized
INFO - 2026-03-15 15:15:07 --> Form Validation Class Initialized
INFO - 2026-03-15 15:15:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:15:07 --> Pagination Class Initialized
INFO - 2026-03-15 15:15:07 --> Email Class Initialized
INFO - 2026-03-15 15:15:07 --> Controller Class Initialized
DEBUG - 2026-03-15 15:15:07 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:15:07 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:15:07 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:15:07 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:15:07 --> Model "Common_model" initialized
INFO - 2026-03-15 15:15:32 --> Config Class Initialized
INFO - 2026-03-15 15:15:32 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:15:32 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:15:32 --> Utf8 Class Initialized
INFO - 2026-03-15 15:15:32 --> URI Class Initialized
INFO - 2026-03-15 15:15:32 --> Router Class Initialized
INFO - 2026-03-15 15:15:32 --> Output Class Initialized
INFO - 2026-03-15 15:15:32 --> Security Class Initialized
DEBUG - 2026-03-15 15:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:15:32 --> CSRF cookie sent
INFO - 2026-03-15 15:15:32 --> Input Class Initialized
INFO - 2026-03-15 15:15:32 --> Language Class Initialized
INFO - 2026-03-15 15:15:32 --> Language Class Initialized
INFO - 2026-03-15 15:15:32 --> Config Class Initialized
INFO - 2026-03-15 15:15:32 --> Loader Class Initialized
INFO - 2026-03-15 15:15:32 --> Helper loaded: url_helper
INFO - 2026-03-15 15:15:32 --> Helper loaded: form_helper
INFO - 2026-03-15 15:15:32 --> Helper loaded: html_helper
INFO - 2026-03-15 15:15:32 --> Helper loaded: file_helper
INFO - 2026-03-15 15:15:32 --> Helper loaded: email_helper
INFO - 2026-03-15 15:15:32 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:15:32 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:15:32 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:15:32 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:15:32 --> Database Driver Class Initialized
INFO - 2026-03-15 15:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:15:34 --> Upload Class Initialized
DEBUG - 2026-03-15 15:15:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:15:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:15:34 --> Encryption Class Initialized
INFO - 2026-03-15 15:15:34 --> Form Validation Class Initialized
INFO - 2026-03-15 15:15:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:15:34 --> Pagination Class Initialized
INFO - 2026-03-15 15:15:34 --> Email Class Initialized
INFO - 2026-03-15 15:15:34 --> Controller Class Initialized
DEBUG - 2026-03-15 15:15:34 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:15:34 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:15:34 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:15:34 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:15:34 --> Model "Common_model" initialized
INFO - 2026-03-15 15:15:44 --> Config Class Initialized
INFO - 2026-03-15 15:15:44 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:15:44 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:15:44 --> Utf8 Class Initialized
INFO - 2026-03-15 15:15:44 --> URI Class Initialized
INFO - 2026-03-15 15:15:44 --> Router Class Initialized
INFO - 2026-03-15 15:15:44 --> Output Class Initialized
INFO - 2026-03-15 15:15:44 --> Security Class Initialized
DEBUG - 2026-03-15 15:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:15:44 --> CSRF cookie sent
INFO - 2026-03-15 15:15:44 --> Input Class Initialized
INFO - 2026-03-15 15:15:44 --> Language Class Initialized
INFO - 2026-03-15 15:15:44 --> Language Class Initialized
INFO - 2026-03-15 15:15:44 --> Config Class Initialized
INFO - 2026-03-15 15:15:44 --> Loader Class Initialized
INFO - 2026-03-15 15:15:44 --> Helper loaded: url_helper
INFO - 2026-03-15 15:15:44 --> Helper loaded: form_helper
INFO - 2026-03-15 15:15:44 --> Helper loaded: html_helper
INFO - 2026-03-15 15:15:44 --> Helper loaded: file_helper
INFO - 2026-03-15 15:15:44 --> Helper loaded: email_helper
INFO - 2026-03-15 15:15:44 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:15:44 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:15:44 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:15:44 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:15:44 --> Database Driver Class Initialized
INFO - 2026-03-15 15:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:15:46 --> Upload Class Initialized
DEBUG - 2026-03-15 15:15:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:15:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:15:46 --> Encryption Class Initialized
INFO - 2026-03-15 15:15:46 --> Form Validation Class Initialized
INFO - 2026-03-15 15:15:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:15:46 --> Pagination Class Initialized
INFO - 2026-03-15 15:15:46 --> Email Class Initialized
INFO - 2026-03-15 15:15:46 --> Controller Class Initialized
DEBUG - 2026-03-15 15:15:46 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:15:46 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:15:46 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:15:46 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:15:46 --> Model "Common_model" initialized
DEBUG - 2026-03-15 15:15:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 15:15:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 15:15:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 15:15:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 15:15:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 15:15:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_list.php
INFO - 2026-03-15 15:15:46 --> Final output sent to browser
DEBUG - 2026-03-15 15:15:46 --> Total execution time: 2.4873
INFO - 2026-03-15 15:15:46 --> Config Class Initialized
INFO - 2026-03-15 15:15:46 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:15:46 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:15:46 --> Utf8 Class Initialized
INFO - 2026-03-15 15:15:46 --> URI Class Initialized
INFO - 2026-03-15 15:15:46 --> Router Class Initialized
INFO - 2026-03-15 15:15:46 --> Output Class Initialized
INFO - 2026-03-15 15:15:46 --> Security Class Initialized
DEBUG - 2026-03-15 15:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:15:46 --> CSRF cookie sent
INFO - 2026-03-15 15:15:46 --> Input Class Initialized
INFO - 2026-03-15 15:15:46 --> Language Class Initialized
INFO - 2026-03-15 15:15:46 --> Language Class Initialized
INFO - 2026-03-15 15:15:46 --> Config Class Initialized
INFO - 2026-03-15 15:15:46 --> Loader Class Initialized
INFO - 2026-03-15 15:15:46 --> Helper loaded: url_helper
INFO - 2026-03-15 15:15:46 --> Helper loaded: form_helper
INFO - 2026-03-15 15:15:46 --> Helper loaded: html_helper
INFO - 2026-03-15 15:15:46 --> Helper loaded: file_helper
INFO - 2026-03-15 15:15:46 --> Helper loaded: email_helper
INFO - 2026-03-15 15:15:46 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:15:46 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:15:46 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:15:46 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:15:46 --> Database Driver Class Initialized
INFO - 2026-03-15 15:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:15:48 --> Upload Class Initialized
DEBUG - 2026-03-15 15:15:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:15:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:15:48 --> Encryption Class Initialized
INFO - 2026-03-15 15:15:48 --> Form Validation Class Initialized
INFO - 2026-03-15 15:15:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:15:48 --> Pagination Class Initialized
INFO - 2026-03-15 15:15:48 --> Email Class Initialized
INFO - 2026-03-15 15:15:48 --> Controller Class Initialized
DEBUG - 2026-03-15 15:15:48 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:15:48 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:15:48 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:15:48 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:15:48 --> Model "Common_model" initialized
INFO - 2026-03-15 15:16:49 --> Config Class Initialized
INFO - 2026-03-15 15:16:49 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:16:49 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:16:49 --> Utf8 Class Initialized
INFO - 2026-03-15 15:16:49 --> URI Class Initialized
INFO - 2026-03-15 15:16:49 --> Router Class Initialized
INFO - 2026-03-15 15:16:49 --> Output Class Initialized
INFO - 2026-03-15 15:16:49 --> Security Class Initialized
DEBUG - 2026-03-15 15:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:16:49 --> CSRF cookie sent
INFO - 2026-03-15 15:16:49 --> Input Class Initialized
INFO - 2026-03-15 15:16:49 --> Language Class Initialized
INFO - 2026-03-15 15:16:49 --> Language Class Initialized
INFO - 2026-03-15 15:16:49 --> Config Class Initialized
INFO - 2026-03-15 15:16:49 --> Loader Class Initialized
INFO - 2026-03-15 15:16:49 --> Helper loaded: url_helper
INFO - 2026-03-15 15:16:49 --> Helper loaded: form_helper
INFO - 2026-03-15 15:16:49 --> Helper loaded: html_helper
INFO - 2026-03-15 15:16:49 --> Helper loaded: file_helper
INFO - 2026-03-15 15:16:49 --> Helper loaded: email_helper
INFO - 2026-03-15 15:16:49 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:16:49 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:16:49 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:16:49 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:16:49 --> Database Driver Class Initialized
INFO - 2026-03-15 15:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:16:51 --> Upload Class Initialized
DEBUG - 2026-03-15 15:16:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:16:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:16:51 --> Encryption Class Initialized
INFO - 2026-03-15 15:16:51 --> Form Validation Class Initialized
INFO - 2026-03-15 15:16:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:16:51 --> Pagination Class Initialized
INFO - 2026-03-15 15:16:51 --> Email Class Initialized
INFO - 2026-03-15 15:16:51 --> Controller Class Initialized
DEBUG - 2026-03-15 15:16:51 --> Package MX_Controller Initialized
INFO - 2026-03-15 15:16:51 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:16:51 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:16:51 --> Model "Package_model" initialized
INFO - 2026-03-15 15:16:51 --> Model "Common_model" initialized
DEBUG - 2026-03-15 15:16:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 15:16:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 15:16:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 15:16:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 15:16:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 15:16:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/package_list.php
INFO - 2026-03-15 15:16:52 --> Final output sent to browser
DEBUG - 2026-03-15 15:16:52 --> Total execution time: 2.3799
INFO - 2026-03-15 15:16:52 --> Config Class Initialized
INFO - 2026-03-15 15:16:52 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:16:52 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:16:52 --> Utf8 Class Initialized
INFO - 2026-03-15 15:16:52 --> URI Class Initialized
INFO - 2026-03-15 15:16:52 --> Router Class Initialized
INFO - 2026-03-15 15:16:52 --> Output Class Initialized
INFO - 2026-03-15 15:16:52 --> Security Class Initialized
DEBUG - 2026-03-15 15:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:16:52 --> CSRF cookie sent
INFO - 2026-03-15 15:16:52 --> Input Class Initialized
INFO - 2026-03-15 15:16:52 --> Language Class Initialized
INFO - 2026-03-15 15:16:52 --> Language Class Initialized
INFO - 2026-03-15 15:16:52 --> Config Class Initialized
INFO - 2026-03-15 15:16:52 --> Loader Class Initialized
INFO - 2026-03-15 15:16:52 --> Helper loaded: url_helper
INFO - 2026-03-15 15:16:52 --> Helper loaded: form_helper
INFO - 2026-03-15 15:16:52 --> Helper loaded: html_helper
INFO - 2026-03-15 15:16:52 --> Helper loaded: file_helper
INFO - 2026-03-15 15:16:52 --> Helper loaded: email_helper
INFO - 2026-03-15 15:16:52 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:16:52 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:16:52 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:16:52 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:16:52 --> Database Driver Class Initialized
INFO - 2026-03-15 15:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:16:54 --> Upload Class Initialized
DEBUG - 2026-03-15 15:16:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:16:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:16:54 --> Encryption Class Initialized
INFO - 2026-03-15 15:16:54 --> Form Validation Class Initialized
INFO - 2026-03-15 15:16:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:16:54 --> Pagination Class Initialized
INFO - 2026-03-15 15:16:54 --> Email Class Initialized
INFO - 2026-03-15 15:16:54 --> Controller Class Initialized
DEBUG - 2026-03-15 15:16:54 --> Package MX_Controller Initialized
INFO - 2026-03-15 15:16:54 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:16:54 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:16:54 --> Model "Package_model" initialized
INFO - 2026-03-15 15:16:54 --> Model "Common_model" initialized
INFO - 2026-03-15 15:17:06 --> Config Class Initialized
INFO - 2026-03-15 15:17:06 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:17:06 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:17:06 --> Utf8 Class Initialized
INFO - 2026-03-15 15:17:06 --> URI Class Initialized
INFO - 2026-03-15 15:17:06 --> Router Class Initialized
INFO - 2026-03-15 15:17:06 --> Output Class Initialized
INFO - 2026-03-15 15:17:06 --> Security Class Initialized
DEBUG - 2026-03-15 15:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:17:06 --> CSRF cookie sent
INFO - 2026-03-15 15:17:06 --> Input Class Initialized
INFO - 2026-03-15 15:17:06 --> Language Class Initialized
INFO - 2026-03-15 15:17:06 --> Language Class Initialized
INFO - 2026-03-15 15:17:06 --> Config Class Initialized
INFO - 2026-03-15 15:17:06 --> Loader Class Initialized
INFO - 2026-03-15 15:17:06 --> Helper loaded: url_helper
INFO - 2026-03-15 15:17:06 --> Helper loaded: form_helper
INFO - 2026-03-15 15:17:06 --> Helper loaded: html_helper
INFO - 2026-03-15 15:17:06 --> Helper loaded: file_helper
INFO - 2026-03-15 15:17:06 --> Helper loaded: email_helper
INFO - 2026-03-15 15:17:06 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:17:06 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:17:06 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:17:06 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:17:06 --> Database Driver Class Initialized
INFO - 2026-03-15 15:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:17:08 --> Upload Class Initialized
DEBUG - 2026-03-15 15:17:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:17:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:17:08 --> Encryption Class Initialized
INFO - 2026-03-15 15:17:08 --> Form Validation Class Initialized
INFO - 2026-03-15 15:17:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:17:08 --> Pagination Class Initialized
INFO - 2026-03-15 15:17:08 --> Email Class Initialized
INFO - 2026-03-15 15:17:08 --> Controller Class Initialized
DEBUG - 2026-03-15 15:17:08 --> Package MX_Controller Initialized
INFO - 2026-03-15 15:17:08 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:17:08 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:17:08 --> Model "Package_model" initialized
INFO - 2026-03-15 15:17:08 --> Model "Common_model" initialized
DEBUG - 2026-03-15 15:17:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 15:17:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 15:17:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 15:17:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 15:17:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 15:17:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/package_manage.php
INFO - 2026-03-15 15:17:10 --> Final output sent to browser
DEBUG - 2026-03-15 15:17:10 --> Total execution time: 3.6765
INFO - 2026-03-15 15:17:25 --> Config Class Initialized
INFO - 2026-03-15 15:17:25 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:17:25 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:17:25 --> Utf8 Class Initialized
INFO - 2026-03-15 15:17:25 --> URI Class Initialized
INFO - 2026-03-15 15:17:25 --> Router Class Initialized
INFO - 2026-03-15 15:17:25 --> Output Class Initialized
INFO - 2026-03-15 15:17:25 --> Security Class Initialized
DEBUG - 2026-03-15 15:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:17:25 --> CSRF cookie sent
INFO - 2026-03-15 15:17:25 --> Input Class Initialized
INFO - 2026-03-15 15:17:25 --> Language Class Initialized
INFO - 2026-03-15 15:17:25 --> Language Class Initialized
INFO - 2026-03-15 15:17:25 --> Config Class Initialized
INFO - 2026-03-15 15:17:25 --> Loader Class Initialized
INFO - 2026-03-15 15:17:25 --> Helper loaded: url_helper
INFO - 2026-03-15 15:17:25 --> Helper loaded: form_helper
INFO - 2026-03-15 15:17:25 --> Helper loaded: html_helper
INFO - 2026-03-15 15:17:25 --> Helper loaded: file_helper
INFO - 2026-03-15 15:17:25 --> Helper loaded: email_helper
INFO - 2026-03-15 15:17:25 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:17:25 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:17:25 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:17:25 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:17:25 --> Database Driver Class Initialized
INFO - 2026-03-15 15:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:17:27 --> Upload Class Initialized
DEBUG - 2026-03-15 15:17:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:17:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:17:27 --> Encryption Class Initialized
INFO - 2026-03-15 15:17:27 --> Form Validation Class Initialized
INFO - 2026-03-15 15:17:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:17:27 --> Pagination Class Initialized
INFO - 2026-03-15 15:17:27 --> Email Class Initialized
INFO - 2026-03-15 15:17:27 --> Controller Class Initialized
DEBUG - 2026-03-15 15:17:27 --> Package MX_Controller Initialized
INFO - 2026-03-15 15:17:27 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:17:27 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:17:27 --> Model "Package_model" initialized
INFO - 2026-03-15 15:17:27 --> Model "Common_model" initialized
DEBUG - 2026-03-15 15:17:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 15:17:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 15:17:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 15:17:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 15:17:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 15:17:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/package_list.php
INFO - 2026-03-15 15:17:28 --> Final output sent to browser
DEBUG - 2026-03-15 15:17:28 --> Total execution time: 2.2980
INFO - 2026-03-15 15:17:28 --> Config Class Initialized
INFO - 2026-03-15 15:17:28 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:17:28 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:17:28 --> Utf8 Class Initialized
INFO - 2026-03-15 15:17:28 --> URI Class Initialized
INFO - 2026-03-15 15:17:28 --> Router Class Initialized
INFO - 2026-03-15 15:17:28 --> Output Class Initialized
INFO - 2026-03-15 15:17:28 --> Security Class Initialized
DEBUG - 2026-03-15 15:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:17:28 --> CSRF cookie sent
INFO - 2026-03-15 15:17:28 --> Input Class Initialized
INFO - 2026-03-15 15:17:28 --> Language Class Initialized
INFO - 2026-03-15 15:17:28 --> Language Class Initialized
INFO - 2026-03-15 15:17:28 --> Config Class Initialized
INFO - 2026-03-15 15:17:28 --> Loader Class Initialized
INFO - 2026-03-15 15:17:28 --> Helper loaded: url_helper
INFO - 2026-03-15 15:17:28 --> Helper loaded: form_helper
INFO - 2026-03-15 15:17:28 --> Helper loaded: html_helper
INFO - 2026-03-15 15:17:28 --> Helper loaded: file_helper
INFO - 2026-03-15 15:17:28 --> Helper loaded: email_helper
INFO - 2026-03-15 15:17:28 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:17:28 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:17:28 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:17:28 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:17:28 --> Database Driver Class Initialized
INFO - 2026-03-15 15:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:17:30 --> Upload Class Initialized
DEBUG - 2026-03-15 15:17:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:17:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:17:30 --> Encryption Class Initialized
INFO - 2026-03-15 15:17:30 --> Form Validation Class Initialized
INFO - 2026-03-15 15:17:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:17:30 --> Pagination Class Initialized
INFO - 2026-03-15 15:17:30 --> Email Class Initialized
INFO - 2026-03-15 15:17:30 --> Controller Class Initialized
DEBUG - 2026-03-15 15:17:30 --> Package MX_Controller Initialized
INFO - 2026-03-15 15:17:30 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:17:30 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:17:30 --> Model "Package_model" initialized
INFO - 2026-03-15 15:17:30 --> Model "Common_model" initialized
INFO - 2026-03-15 15:17:43 --> Config Class Initialized
INFO - 2026-03-15 15:17:43 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:17:43 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:17:43 --> Utf8 Class Initialized
INFO - 2026-03-15 15:17:43 --> URI Class Initialized
INFO - 2026-03-15 15:17:43 --> Router Class Initialized
INFO - 2026-03-15 15:17:43 --> Output Class Initialized
INFO - 2026-03-15 15:17:43 --> Security Class Initialized
DEBUG - 2026-03-15 15:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:17:43 --> CSRF cookie sent
INFO - 2026-03-15 15:17:43 --> Input Class Initialized
INFO - 2026-03-15 15:17:43 --> Language Class Initialized
INFO - 2026-03-15 15:17:43 --> Language Class Initialized
INFO - 2026-03-15 15:17:43 --> Config Class Initialized
INFO - 2026-03-15 15:17:43 --> Loader Class Initialized
INFO - 2026-03-15 15:17:43 --> Helper loaded: url_helper
INFO - 2026-03-15 15:17:43 --> Helper loaded: form_helper
INFO - 2026-03-15 15:17:43 --> Helper loaded: html_helper
INFO - 2026-03-15 15:17:43 --> Helper loaded: file_helper
INFO - 2026-03-15 15:17:43 --> Helper loaded: email_helper
INFO - 2026-03-15 15:17:43 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:17:43 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:17:43 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:17:43 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:17:43 --> Database Driver Class Initialized
INFO - 2026-03-15 15:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:17:45 --> Upload Class Initialized
DEBUG - 2026-03-15 15:17:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:17:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:17:45 --> Encryption Class Initialized
INFO - 2026-03-15 15:17:45 --> Form Validation Class Initialized
INFO - 2026-03-15 15:17:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:17:45 --> Pagination Class Initialized
INFO - 2026-03-15 15:17:45 --> Email Class Initialized
INFO - 2026-03-15 15:17:45 --> Controller Class Initialized
DEBUG - 2026-03-15 15:17:45 --> Package MX_Controller Initialized
INFO - 2026-03-15 15:17:45 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:17:45 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:17:45 --> Model "Package_model" initialized
INFO - 2026-03-15 15:17:45 --> Model "Common_model" initialized
INFO - 2026-03-15 15:20:28 --> Config Class Initialized
INFO - 2026-03-15 15:20:28 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:20:28 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:20:28 --> Utf8 Class Initialized
INFO - 2026-03-15 15:20:28 --> URI Class Initialized
INFO - 2026-03-15 15:20:28 --> Router Class Initialized
INFO - 2026-03-15 15:20:28 --> Output Class Initialized
INFO - 2026-03-15 15:20:28 --> Security Class Initialized
DEBUG - 2026-03-15 15:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:20:28 --> CSRF cookie sent
INFO - 2026-03-15 15:20:28 --> Input Class Initialized
INFO - 2026-03-15 15:20:28 --> Language Class Initialized
INFO - 2026-03-15 15:20:28 --> Language Class Initialized
INFO - 2026-03-15 15:20:28 --> Config Class Initialized
INFO - 2026-03-15 15:20:28 --> Loader Class Initialized
INFO - 2026-03-15 15:20:28 --> Helper loaded: url_helper
INFO - 2026-03-15 15:20:28 --> Helper loaded: form_helper
INFO - 2026-03-15 15:20:28 --> Helper loaded: html_helper
INFO - 2026-03-15 15:20:28 --> Helper loaded: file_helper
INFO - 2026-03-15 15:20:28 --> Helper loaded: email_helper
INFO - 2026-03-15 15:20:28 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:20:28 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:20:28 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:20:28 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:20:28 --> Database Driver Class Initialized
INFO - 2026-03-15 15:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:20:30 --> Upload Class Initialized
DEBUG - 2026-03-15 15:20:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:20:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:20:30 --> Encryption Class Initialized
INFO - 2026-03-15 15:20:30 --> Form Validation Class Initialized
INFO - 2026-03-15 15:20:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:20:30 --> Pagination Class Initialized
INFO - 2026-03-15 15:20:30 --> Email Class Initialized
INFO - 2026-03-15 15:20:30 --> Controller Class Initialized
DEBUG - 2026-03-15 15:20:30 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:20:30 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:20:30 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:20:30 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:20:30 --> Model "Common_model" initialized
DEBUG - 2026-03-15 15:20:30 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 15:20:30 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 15:20:30 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 15:20:30 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 15:20:30 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 15:20:30 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_list.php
INFO - 2026-03-15 15:20:30 --> Final output sent to browser
DEBUG - 2026-03-15 15:20:30 --> Total execution time: 2.3595
INFO - 2026-03-15 15:20:30 --> Config Class Initialized
INFO - 2026-03-15 15:20:30 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:20:30 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:20:30 --> Utf8 Class Initialized
INFO - 2026-03-15 15:20:30 --> URI Class Initialized
INFO - 2026-03-15 15:20:30 --> Router Class Initialized
INFO - 2026-03-15 15:20:30 --> Output Class Initialized
INFO - 2026-03-15 15:20:30 --> Security Class Initialized
DEBUG - 2026-03-15 15:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:20:30 --> CSRF cookie sent
INFO - 2026-03-15 15:20:30 --> Input Class Initialized
INFO - 2026-03-15 15:20:30 --> Language Class Initialized
INFO - 2026-03-15 15:20:30 --> Language Class Initialized
INFO - 2026-03-15 15:20:30 --> Config Class Initialized
INFO - 2026-03-15 15:20:30 --> Loader Class Initialized
INFO - 2026-03-15 15:20:30 --> Helper loaded: url_helper
INFO - 2026-03-15 15:20:30 --> Helper loaded: form_helper
INFO - 2026-03-15 15:20:30 --> Helper loaded: html_helper
INFO - 2026-03-15 15:20:30 --> Helper loaded: file_helper
INFO - 2026-03-15 15:20:30 --> Helper loaded: email_helper
INFO - 2026-03-15 15:20:30 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:20:30 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:20:30 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:20:30 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:20:30 --> Database Driver Class Initialized
INFO - 2026-03-15 15:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:20:32 --> Upload Class Initialized
DEBUG - 2026-03-15 15:20:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:20:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:20:32 --> Encryption Class Initialized
INFO - 2026-03-15 15:20:32 --> Form Validation Class Initialized
INFO - 2026-03-15 15:20:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:20:32 --> Pagination Class Initialized
INFO - 2026-03-15 15:20:32 --> Email Class Initialized
INFO - 2026-03-15 15:20:32 --> Controller Class Initialized
DEBUG - 2026-03-15 15:20:32 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:20:32 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:20:32 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:20:32 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:20:32 --> Model "Common_model" initialized
INFO - 2026-03-15 15:23:52 --> Config Class Initialized
INFO - 2026-03-15 15:23:52 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:23:52 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:23:52 --> Utf8 Class Initialized
INFO - 2026-03-15 15:23:52 --> URI Class Initialized
INFO - 2026-03-15 15:23:52 --> Router Class Initialized
INFO - 2026-03-15 15:23:52 --> Output Class Initialized
INFO - 2026-03-15 15:23:52 --> Security Class Initialized
DEBUG - 2026-03-15 15:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:23:52 --> CSRF cookie sent
INFO - 2026-03-15 15:23:52 --> Input Class Initialized
INFO - 2026-03-15 15:23:52 --> Language Class Initialized
INFO - 2026-03-15 15:23:52 --> Language Class Initialized
INFO - 2026-03-15 15:23:52 --> Config Class Initialized
INFO - 2026-03-15 15:23:52 --> Loader Class Initialized
INFO - 2026-03-15 15:23:52 --> Helper loaded: url_helper
INFO - 2026-03-15 15:23:52 --> Helper loaded: form_helper
INFO - 2026-03-15 15:23:52 --> Helper loaded: html_helper
INFO - 2026-03-15 15:23:52 --> Helper loaded: file_helper
INFO - 2026-03-15 15:23:52 --> Helper loaded: email_helper
INFO - 2026-03-15 15:23:52 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:23:52 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:23:52 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:23:52 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:23:52 --> Database Driver Class Initialized
INFO - 2026-03-15 15:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:23:54 --> Upload Class Initialized
DEBUG - 2026-03-15 15:23:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:23:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:23:54 --> Encryption Class Initialized
INFO - 2026-03-15 15:23:54 --> Form Validation Class Initialized
INFO - 2026-03-15 15:23:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:23:54 --> Pagination Class Initialized
INFO - 2026-03-15 15:23:54 --> Email Class Initialized
INFO - 2026-03-15 15:23:54 --> Controller Class Initialized
DEBUG - 2026-03-15 15:23:54 --> Package MX_Controller Initialized
INFO - 2026-03-15 15:23:54 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:23:54 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:23:54 --> Model "Package_model" initialized
INFO - 2026-03-15 15:23:54 --> Model "Common_model" initialized
DEBUG - 2026-03-15 15:23:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 15:23:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 15:23:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 15:23:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 15:23:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 15:23:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/package_manage.php
INFO - 2026-03-15 15:23:56 --> Final output sent to browser
DEBUG - 2026-03-15 15:23:56 --> Total execution time: 3.9069
INFO - 2026-03-15 15:37:50 --> Config Class Initialized
INFO - 2026-03-15 15:37:50 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:37:50 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:37:50 --> Utf8 Class Initialized
INFO - 2026-03-15 15:37:50 --> URI Class Initialized
INFO - 2026-03-15 15:37:50 --> Router Class Initialized
INFO - 2026-03-15 15:37:50 --> Output Class Initialized
INFO - 2026-03-15 15:37:50 --> Security Class Initialized
DEBUG - 2026-03-15 15:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:37:50 --> CSRF cookie sent
INFO - 2026-03-15 15:37:50 --> Input Class Initialized
INFO - 2026-03-15 15:37:50 --> Language Class Initialized
INFO - 2026-03-15 15:37:50 --> Language Class Initialized
INFO - 2026-03-15 15:37:50 --> Config Class Initialized
INFO - 2026-03-15 15:37:50 --> Loader Class Initialized
INFO - 2026-03-15 15:37:50 --> Helper loaded: url_helper
INFO - 2026-03-15 15:37:50 --> Helper loaded: form_helper
INFO - 2026-03-15 15:37:50 --> Helper loaded: html_helper
INFO - 2026-03-15 15:37:50 --> Helper loaded: file_helper
INFO - 2026-03-15 15:37:50 --> Helper loaded: email_helper
INFO - 2026-03-15 15:37:50 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:37:50 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:37:50 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:37:50 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:37:50 --> Database Driver Class Initialized
INFO - 2026-03-15 15:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:37:52 --> Upload Class Initialized
DEBUG - 2026-03-15 15:37:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:37:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:37:52 --> Encryption Class Initialized
INFO - 2026-03-15 15:37:52 --> Form Validation Class Initialized
INFO - 2026-03-15 15:37:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:37:52 --> Pagination Class Initialized
INFO - 2026-03-15 15:37:52 --> Email Class Initialized
INFO - 2026-03-15 15:37:52 --> Controller Class Initialized
DEBUG - 2026-03-15 15:37:52 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:37:52 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:37:52 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:37:52 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:37:52 --> Model "Common_model" initialized
DEBUG - 2026-03-15 15:37:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 15:37:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 15:37:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 15:37:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 15:37:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 15:37:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_manage.php
INFO - 2026-03-15 15:37:56 --> Final output sent to browser
DEBUG - 2026-03-15 15:37:56 --> Total execution time: 6.3064
INFO - 2026-03-15 15:37:56 --> Config Class Initialized
INFO - 2026-03-15 15:37:56 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:37:56 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:37:56 --> Utf8 Class Initialized
INFO - 2026-03-15 15:37:56 --> URI Class Initialized
INFO - 2026-03-15 15:37:56 --> Router Class Initialized
INFO - 2026-03-15 15:37:56 --> Output Class Initialized
INFO - 2026-03-15 15:37:56 --> Security Class Initialized
DEBUG - 2026-03-15 15:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:37:56 --> CSRF cookie sent
INFO - 2026-03-15 15:37:56 --> Input Class Initialized
INFO - 2026-03-15 15:37:56 --> Language Class Initialized
INFO - 2026-03-15 15:37:56 --> Language Class Initialized
INFO - 2026-03-15 15:37:56 --> Config Class Initialized
INFO - 2026-03-15 15:37:56 --> Loader Class Initialized
INFO - 2026-03-15 15:37:56 --> Helper loaded: url_helper
INFO - 2026-03-15 15:37:56 --> Helper loaded: form_helper
INFO - 2026-03-15 15:37:56 --> Helper loaded: html_helper
INFO - 2026-03-15 15:37:56 --> Helper loaded: file_helper
INFO - 2026-03-15 15:37:56 --> Helper loaded: email_helper
INFO - 2026-03-15 15:37:56 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:37:56 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:37:56 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:37:56 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:37:56 --> Database Driver Class Initialized
INFO - 2026-03-15 15:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:37:58 --> Upload Class Initialized
DEBUG - 2026-03-15 15:37:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:37:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:37:58 --> Encryption Class Initialized
INFO - 2026-03-15 15:37:58 --> Form Validation Class Initialized
INFO - 2026-03-15 15:37:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:37:58 --> Pagination Class Initialized
INFO - 2026-03-15 15:37:58 --> Email Class Initialized
INFO - 2026-03-15 15:37:58 --> Controller Class Initialized
DEBUG - 2026-03-15 15:37:58 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:37:58 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:37:58 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:37:58 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:37:58 --> Model "Common_model" initialized
INFO - 2026-03-15 15:48:33 --> Config Class Initialized
INFO - 2026-03-15 15:48:33 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:48:33 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:48:33 --> Utf8 Class Initialized
INFO - 2026-03-15 15:48:33 --> URI Class Initialized
INFO - 2026-03-15 15:48:33 --> Router Class Initialized
INFO - 2026-03-15 15:48:33 --> Output Class Initialized
INFO - 2026-03-15 15:48:33 --> Security Class Initialized
DEBUG - 2026-03-15 15:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:48:33 --> CSRF cookie sent
INFO - 2026-03-15 15:48:33 --> Input Class Initialized
INFO - 2026-03-15 15:48:33 --> Language Class Initialized
INFO - 2026-03-15 15:48:33 --> Language Class Initialized
INFO - 2026-03-15 15:48:33 --> Config Class Initialized
INFO - 2026-03-15 15:48:33 --> Loader Class Initialized
INFO - 2026-03-15 15:48:33 --> Helper loaded: url_helper
INFO - 2026-03-15 15:48:33 --> Helper loaded: form_helper
INFO - 2026-03-15 15:48:33 --> Helper loaded: html_helper
INFO - 2026-03-15 15:48:33 --> Helper loaded: file_helper
INFO - 2026-03-15 15:48:33 --> Helper loaded: email_helper
INFO - 2026-03-15 15:48:33 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:48:33 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:48:33 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:48:33 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:48:33 --> Database Driver Class Initialized
INFO - 2026-03-15 15:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:48:35 --> Upload Class Initialized
DEBUG - 2026-03-15 15:48:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:48:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:48:35 --> Encryption Class Initialized
INFO - 2026-03-15 15:48:35 --> Form Validation Class Initialized
INFO - 2026-03-15 15:48:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:48:35 --> Pagination Class Initialized
INFO - 2026-03-15 15:48:35 --> Email Class Initialized
INFO - 2026-03-15 15:48:35 --> Controller Class Initialized
DEBUG - 2026-03-15 15:48:35 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:48:35 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:48:35 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:48:35 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:48:35 --> Model "Common_model" initialized
DEBUG - 2026-03-15 15:48:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 15:48:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 15:48:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 15:48:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 15:48:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 15:48:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_manage.php
INFO - 2026-03-15 15:48:39 --> Final output sent to browser
DEBUG - 2026-03-15 15:48:39 --> Total execution time: 6.4244
INFO - 2026-03-15 15:48:40 --> Config Class Initialized
INFO - 2026-03-15 15:48:40 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:48:40 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:48:40 --> Utf8 Class Initialized
INFO - 2026-03-15 15:48:40 --> URI Class Initialized
INFO - 2026-03-15 15:48:40 --> Router Class Initialized
INFO - 2026-03-15 15:48:40 --> Output Class Initialized
INFO - 2026-03-15 15:48:40 --> Security Class Initialized
DEBUG - 2026-03-15 15:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:48:40 --> CSRF cookie sent
INFO - 2026-03-15 15:48:40 --> Input Class Initialized
INFO - 2026-03-15 15:48:40 --> Language Class Initialized
INFO - 2026-03-15 15:48:40 --> Language Class Initialized
INFO - 2026-03-15 15:48:40 --> Config Class Initialized
INFO - 2026-03-15 15:48:40 --> Loader Class Initialized
INFO - 2026-03-15 15:48:40 --> Helper loaded: url_helper
INFO - 2026-03-15 15:48:40 --> Helper loaded: form_helper
INFO - 2026-03-15 15:48:40 --> Helper loaded: html_helper
INFO - 2026-03-15 15:48:40 --> Helper loaded: file_helper
INFO - 2026-03-15 15:48:40 --> Helper loaded: email_helper
INFO - 2026-03-15 15:48:40 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:48:40 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:48:40 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:48:40 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:48:40 --> Database Driver Class Initialized
INFO - 2026-03-15 15:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:48:42 --> Upload Class Initialized
DEBUG - 2026-03-15 15:48:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:48:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:48:42 --> Encryption Class Initialized
INFO - 2026-03-15 15:48:42 --> Form Validation Class Initialized
INFO - 2026-03-15 15:48:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:48:42 --> Pagination Class Initialized
INFO - 2026-03-15 15:48:42 --> Email Class Initialized
INFO - 2026-03-15 15:48:42 --> Controller Class Initialized
DEBUG - 2026-03-15 15:48:42 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:48:42 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:48:42 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:48:42 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:48:42 --> Model "Common_model" initialized
INFO - 2026-03-15 15:49:01 --> Config Class Initialized
INFO - 2026-03-15 15:49:01 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:49:01 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:49:01 --> Utf8 Class Initialized
INFO - 2026-03-15 15:49:01 --> URI Class Initialized
INFO - 2026-03-15 15:49:01 --> Router Class Initialized
INFO - 2026-03-15 15:49:01 --> Output Class Initialized
INFO - 2026-03-15 15:49:01 --> Security Class Initialized
DEBUG - 2026-03-15 15:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:49:01 --> CSRF cookie sent
INFO - 2026-03-15 15:49:01 --> CSRF token verified
INFO - 2026-03-15 15:49:01 --> Input Class Initialized
INFO - 2026-03-15 15:49:01 --> Language Class Initialized
INFO - 2026-03-15 15:49:01 --> Language Class Initialized
INFO - 2026-03-15 15:49:01 --> Config Class Initialized
INFO - 2026-03-15 15:49:01 --> Loader Class Initialized
INFO - 2026-03-15 15:49:01 --> Helper loaded: url_helper
INFO - 2026-03-15 15:49:01 --> Helper loaded: form_helper
INFO - 2026-03-15 15:49:01 --> Helper loaded: html_helper
INFO - 2026-03-15 15:49:01 --> Helper loaded: file_helper
INFO - 2026-03-15 15:49:01 --> Helper loaded: email_helper
INFO - 2026-03-15 15:49:01 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:49:01 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:49:01 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:49:01 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:49:01 --> Database Driver Class Initialized
INFO - 2026-03-15 15:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:49:03 --> Upload Class Initialized
DEBUG - 2026-03-15 15:49:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:49:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:49:03 --> Encryption Class Initialized
INFO - 2026-03-15 15:49:03 --> Form Validation Class Initialized
INFO - 2026-03-15 15:49:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:49:03 --> Pagination Class Initialized
INFO - 2026-03-15 15:49:03 --> Email Class Initialized
INFO - 2026-03-15 15:49:03 --> Controller Class Initialized
DEBUG - 2026-03-15 15:49:03 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:49:03 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:49:03 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:49:03 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:49:03 --> Model "Common_model" initialized
INFO - 2026-03-15 15:49:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-03-15 15:49:07 --> Config Class Initialized
INFO - 2026-03-15 15:49:07 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:49:07 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:49:07 --> Utf8 Class Initialized
INFO - 2026-03-15 15:49:07 --> URI Class Initialized
INFO - 2026-03-15 15:49:07 --> Router Class Initialized
INFO - 2026-03-15 15:49:07 --> Output Class Initialized
INFO - 2026-03-15 15:49:07 --> Security Class Initialized
DEBUG - 2026-03-15 15:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:49:07 --> CSRF cookie sent
INFO - 2026-03-15 15:49:07 --> Input Class Initialized
INFO - 2026-03-15 15:49:07 --> Language Class Initialized
INFO - 2026-03-15 15:49:07 --> Language Class Initialized
INFO - 2026-03-15 15:49:07 --> Config Class Initialized
INFO - 2026-03-15 15:49:07 --> Loader Class Initialized
INFO - 2026-03-15 15:49:07 --> Helper loaded: url_helper
INFO - 2026-03-15 15:49:07 --> Helper loaded: form_helper
INFO - 2026-03-15 15:49:07 --> Helper loaded: html_helper
INFO - 2026-03-15 15:49:07 --> Helper loaded: file_helper
INFO - 2026-03-15 15:49:07 --> Helper loaded: email_helper
INFO - 2026-03-15 15:49:07 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:49:07 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:49:07 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:49:07 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:49:07 --> Database Driver Class Initialized
INFO - 2026-03-15 15:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:49:09 --> Upload Class Initialized
DEBUG - 2026-03-15 15:49:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:49:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:49:09 --> Encryption Class Initialized
INFO - 2026-03-15 15:49:09 --> Form Validation Class Initialized
INFO - 2026-03-15 15:49:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:49:09 --> Pagination Class Initialized
INFO - 2026-03-15 15:49:09 --> Email Class Initialized
INFO - 2026-03-15 15:49:09 --> Controller Class Initialized
DEBUG - 2026-03-15 15:49:09 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:49:09 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:49:09 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:49:09 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:49:09 --> Model "Common_model" initialized
DEBUG - 2026-03-15 15:49:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 15:49:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 15:49:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 15:49:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 15:49:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 15:49:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_list.php
INFO - 2026-03-15 15:49:10 --> Final output sent to browser
DEBUG - 2026-03-15 15:49:10 --> Total execution time: 2.3535
INFO - 2026-03-15 15:49:10 --> Config Class Initialized
INFO - 2026-03-15 15:49:10 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:49:10 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:49:10 --> Utf8 Class Initialized
INFO - 2026-03-15 15:49:10 --> URI Class Initialized
INFO - 2026-03-15 15:49:10 --> Router Class Initialized
INFO - 2026-03-15 15:49:10 --> Output Class Initialized
INFO - 2026-03-15 15:49:10 --> Security Class Initialized
DEBUG - 2026-03-15 15:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:49:10 --> CSRF cookie sent
INFO - 2026-03-15 15:49:10 --> Input Class Initialized
INFO - 2026-03-15 15:49:10 --> Language Class Initialized
INFO - 2026-03-15 15:49:10 --> Language Class Initialized
INFO - 2026-03-15 15:49:10 --> Config Class Initialized
INFO - 2026-03-15 15:49:10 --> Loader Class Initialized
INFO - 2026-03-15 15:49:10 --> Helper loaded: url_helper
INFO - 2026-03-15 15:49:10 --> Helper loaded: form_helper
INFO - 2026-03-15 15:49:10 --> Helper loaded: html_helper
INFO - 2026-03-15 15:49:10 --> Helper loaded: file_helper
INFO - 2026-03-15 15:49:10 --> Helper loaded: email_helper
INFO - 2026-03-15 15:49:10 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:49:10 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:49:10 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:49:10 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:49:10 --> Database Driver Class Initialized
INFO - 2026-03-15 15:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:49:12 --> Upload Class Initialized
DEBUG - 2026-03-15 15:49:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:49:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:49:12 --> Encryption Class Initialized
INFO - 2026-03-15 15:49:12 --> Form Validation Class Initialized
INFO - 2026-03-15 15:49:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:49:12 --> Pagination Class Initialized
INFO - 2026-03-15 15:49:12 --> Email Class Initialized
INFO - 2026-03-15 15:49:12 --> Controller Class Initialized
DEBUG - 2026-03-15 15:49:12 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:49:12 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:49:12 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:49:12 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:49:12 --> Model "Common_model" initialized
INFO - 2026-03-15 15:49:20 --> Config Class Initialized
INFO - 2026-03-15 15:49:20 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:49:20 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:49:20 --> Utf8 Class Initialized
INFO - 2026-03-15 15:49:20 --> URI Class Initialized
INFO - 2026-03-15 15:49:20 --> Router Class Initialized
INFO - 2026-03-15 15:49:20 --> Output Class Initialized
INFO - 2026-03-15 15:49:20 --> Security Class Initialized
DEBUG - 2026-03-15 15:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:49:20 --> CSRF cookie sent
INFO - 2026-03-15 15:49:20 --> Input Class Initialized
INFO - 2026-03-15 15:49:20 --> Language Class Initialized
INFO - 2026-03-15 15:49:20 --> Language Class Initialized
INFO - 2026-03-15 15:49:20 --> Config Class Initialized
INFO - 2026-03-15 15:49:20 --> Loader Class Initialized
INFO - 2026-03-15 15:49:20 --> Helper loaded: url_helper
INFO - 2026-03-15 15:49:20 --> Helper loaded: form_helper
INFO - 2026-03-15 15:49:20 --> Helper loaded: html_helper
INFO - 2026-03-15 15:49:20 --> Helper loaded: file_helper
INFO - 2026-03-15 15:49:20 --> Helper loaded: email_helper
INFO - 2026-03-15 15:49:20 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:49:20 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:49:20 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:49:20 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:49:20 --> Database Driver Class Initialized
INFO - 2026-03-15 15:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:49:22 --> Upload Class Initialized
DEBUG - 2026-03-15 15:49:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:49:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:49:22 --> Encryption Class Initialized
INFO - 2026-03-15 15:49:22 --> Form Validation Class Initialized
INFO - 2026-03-15 15:49:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:49:22 --> Pagination Class Initialized
INFO - 2026-03-15 15:49:22 --> Email Class Initialized
INFO - 2026-03-15 15:49:22 --> Controller Class Initialized
DEBUG - 2026-03-15 15:49:22 --> Package MX_Controller Initialized
INFO - 2026-03-15 15:49:22 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:49:22 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:49:22 --> Model "Package_model" initialized
INFO - 2026-03-15 15:49:22 --> Model "Common_model" initialized
DEBUG - 2026-03-15 15:49:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 15:49:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 15:49:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 15:49:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 15:49:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 15:49:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/package_list.php
INFO - 2026-03-15 15:49:22 --> Final output sent to browser
DEBUG - 2026-03-15 15:49:22 --> Total execution time: 2.3642
INFO - 2026-03-15 15:49:22 --> Config Class Initialized
INFO - 2026-03-15 15:49:22 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:49:22 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:49:22 --> Utf8 Class Initialized
INFO - 2026-03-15 15:49:22 --> URI Class Initialized
INFO - 2026-03-15 15:49:22 --> Router Class Initialized
INFO - 2026-03-15 15:49:22 --> Output Class Initialized
INFO - 2026-03-15 15:49:22 --> Security Class Initialized
DEBUG - 2026-03-15 15:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:49:22 --> CSRF cookie sent
INFO - 2026-03-15 15:49:22 --> Input Class Initialized
INFO - 2026-03-15 15:49:22 --> Language Class Initialized
INFO - 2026-03-15 15:49:22 --> Language Class Initialized
INFO - 2026-03-15 15:49:22 --> Config Class Initialized
INFO - 2026-03-15 15:49:22 --> Loader Class Initialized
INFO - 2026-03-15 15:49:22 --> Helper loaded: url_helper
INFO - 2026-03-15 15:49:22 --> Helper loaded: form_helper
INFO - 2026-03-15 15:49:22 --> Helper loaded: html_helper
INFO - 2026-03-15 15:49:22 --> Helper loaded: file_helper
INFO - 2026-03-15 15:49:22 --> Helper loaded: email_helper
INFO - 2026-03-15 15:49:22 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:49:22 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:49:22 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:49:22 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:49:22 --> Database Driver Class Initialized
INFO - 2026-03-15 15:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:49:24 --> Upload Class Initialized
DEBUG - 2026-03-15 15:49:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:49:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:49:24 --> Encryption Class Initialized
INFO - 2026-03-15 15:49:24 --> Form Validation Class Initialized
INFO - 2026-03-15 15:49:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:49:24 --> Pagination Class Initialized
INFO - 2026-03-15 15:49:24 --> Email Class Initialized
INFO - 2026-03-15 15:49:24 --> Controller Class Initialized
DEBUG - 2026-03-15 15:49:24 --> Package MX_Controller Initialized
INFO - 2026-03-15 15:49:24 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:49:24 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:49:24 --> Model "Package_model" initialized
INFO - 2026-03-15 15:49:24 --> Model "Common_model" initialized
INFO - 2026-03-15 15:49:53 --> Config Class Initialized
INFO - 2026-03-15 15:49:53 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:49:53 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:49:53 --> Utf8 Class Initialized
INFO - 2026-03-15 15:49:53 --> URI Class Initialized
INFO - 2026-03-15 15:49:53 --> Router Class Initialized
INFO - 2026-03-15 15:49:53 --> Output Class Initialized
INFO - 2026-03-15 15:49:53 --> Security Class Initialized
DEBUG - 2026-03-15 15:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:49:53 --> CSRF cookie sent
INFO - 2026-03-15 15:49:53 --> Input Class Initialized
INFO - 2026-03-15 15:49:53 --> Language Class Initialized
INFO - 2026-03-15 15:49:53 --> Language Class Initialized
INFO - 2026-03-15 15:49:53 --> Config Class Initialized
INFO - 2026-03-15 15:49:53 --> Loader Class Initialized
INFO - 2026-03-15 15:49:53 --> Helper loaded: url_helper
INFO - 2026-03-15 15:49:53 --> Helper loaded: form_helper
INFO - 2026-03-15 15:49:53 --> Helper loaded: html_helper
INFO - 2026-03-15 15:49:53 --> Helper loaded: file_helper
INFO - 2026-03-15 15:49:53 --> Helper loaded: email_helper
INFO - 2026-03-15 15:49:53 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:49:53 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:49:53 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:49:53 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:49:53 --> Database Driver Class Initialized
INFO - 2026-03-15 15:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:49:55 --> Upload Class Initialized
DEBUG - 2026-03-15 15:49:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:49:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:49:55 --> Encryption Class Initialized
INFO - 2026-03-15 15:49:55 --> Form Validation Class Initialized
INFO - 2026-03-15 15:49:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:49:55 --> Pagination Class Initialized
INFO - 2026-03-15 15:49:55 --> Email Class Initialized
INFO - 2026-03-15 15:49:55 --> Controller Class Initialized
DEBUG - 2026-03-15 15:49:55 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:49:55 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:49:55 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:49:55 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:49:55 --> Model "Common_model" initialized
DEBUG - 2026-03-15 15:49:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 15:49:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 15:49:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 15:49:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 15:49:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 15:49:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_list.php
INFO - 2026-03-15 15:49:55 --> Final output sent to browser
DEBUG - 2026-03-15 15:49:55 --> Total execution time: 2.5535
INFO - 2026-03-15 15:49:55 --> Config Class Initialized
INFO - 2026-03-15 15:49:55 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:49:55 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:49:55 --> Utf8 Class Initialized
INFO - 2026-03-15 15:49:55 --> URI Class Initialized
INFO - 2026-03-15 15:49:55 --> Router Class Initialized
INFO - 2026-03-15 15:49:55 --> Output Class Initialized
INFO - 2026-03-15 15:49:55 --> Security Class Initialized
DEBUG - 2026-03-15 15:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:49:55 --> CSRF cookie sent
INFO - 2026-03-15 15:49:55 --> Input Class Initialized
INFO - 2026-03-15 15:49:55 --> Language Class Initialized
INFO - 2026-03-15 15:49:55 --> Language Class Initialized
INFO - 2026-03-15 15:49:55 --> Config Class Initialized
INFO - 2026-03-15 15:49:55 --> Loader Class Initialized
INFO - 2026-03-15 15:49:55 --> Helper loaded: url_helper
INFO - 2026-03-15 15:49:55 --> Helper loaded: form_helper
INFO - 2026-03-15 15:49:55 --> Helper loaded: html_helper
INFO - 2026-03-15 15:49:55 --> Helper loaded: file_helper
INFO - 2026-03-15 15:49:55 --> Helper loaded: email_helper
INFO - 2026-03-15 15:49:55 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:49:55 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:49:55 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:49:55 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:49:55 --> Database Driver Class Initialized
INFO - 2026-03-15 15:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:49:57 --> Upload Class Initialized
DEBUG - 2026-03-15 15:49:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:49:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:49:57 --> Encryption Class Initialized
INFO - 2026-03-15 15:49:57 --> Form Validation Class Initialized
INFO - 2026-03-15 15:49:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:49:57 --> Pagination Class Initialized
INFO - 2026-03-15 15:49:57 --> Email Class Initialized
INFO - 2026-03-15 15:49:57 --> Controller Class Initialized
DEBUG - 2026-03-15 15:49:57 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:49:57 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:49:57 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:49:57 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:49:57 --> Model "Common_model" initialized
INFO - 2026-03-15 15:50:18 --> Config Class Initialized
INFO - 2026-03-15 15:50:18 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:50:18 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:50:18 --> Utf8 Class Initialized
INFO - 2026-03-15 15:50:18 --> URI Class Initialized
INFO - 2026-03-15 15:50:18 --> Router Class Initialized
INFO - 2026-03-15 15:50:18 --> Output Class Initialized
INFO - 2026-03-15 15:50:18 --> Security Class Initialized
DEBUG - 2026-03-15 15:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:50:18 --> CSRF cookie sent
INFO - 2026-03-15 15:50:18 --> Input Class Initialized
INFO - 2026-03-15 15:50:18 --> Language Class Initialized
INFO - 2026-03-15 15:50:18 --> Language Class Initialized
INFO - 2026-03-15 15:50:18 --> Config Class Initialized
INFO - 2026-03-15 15:50:18 --> Loader Class Initialized
INFO - 2026-03-15 15:50:18 --> Helper loaded: url_helper
INFO - 2026-03-15 15:50:18 --> Helper loaded: form_helper
INFO - 2026-03-15 15:50:18 --> Helper loaded: html_helper
INFO - 2026-03-15 15:50:18 --> Helper loaded: file_helper
INFO - 2026-03-15 15:50:18 --> Helper loaded: email_helper
INFO - 2026-03-15 15:50:18 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:50:18 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:50:18 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:50:18 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:50:18 --> Database Driver Class Initialized
INFO - 2026-03-15 15:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:50:20 --> Upload Class Initialized
DEBUG - 2026-03-15 15:50:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:50:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:50:20 --> Encryption Class Initialized
INFO - 2026-03-15 15:50:20 --> Form Validation Class Initialized
INFO - 2026-03-15 15:50:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:50:20 --> Pagination Class Initialized
INFO - 2026-03-15 15:50:20 --> Email Class Initialized
INFO - 2026-03-15 15:50:20 --> Controller Class Initialized
DEBUG - 2026-03-15 15:50:20 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:50:20 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:50:20 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:50:20 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:50:20 --> Model "Common_model" initialized
DEBUG - 2026-03-15 15:50:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 15:50:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 15:50:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 15:50:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 15:50:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 15:50:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_list.php
INFO - 2026-03-15 15:50:20 --> Final output sent to browser
DEBUG - 2026-03-15 15:50:20 --> Total execution time: 2.5002
INFO - 2026-03-15 15:50:20 --> Config Class Initialized
INFO - 2026-03-15 15:50:20 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:50:20 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:50:20 --> Utf8 Class Initialized
INFO - 2026-03-15 15:50:20 --> URI Class Initialized
INFO - 2026-03-15 15:50:20 --> Router Class Initialized
INFO - 2026-03-15 15:50:20 --> Output Class Initialized
INFO - 2026-03-15 15:50:20 --> Security Class Initialized
DEBUG - 2026-03-15 15:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:50:20 --> CSRF cookie sent
INFO - 2026-03-15 15:50:20 --> Input Class Initialized
INFO - 2026-03-15 15:50:20 --> Language Class Initialized
INFO - 2026-03-15 15:50:20 --> Language Class Initialized
INFO - 2026-03-15 15:50:20 --> Config Class Initialized
INFO - 2026-03-15 15:50:20 --> Loader Class Initialized
INFO - 2026-03-15 15:50:20 --> Helper loaded: url_helper
INFO - 2026-03-15 15:50:20 --> Helper loaded: form_helper
INFO - 2026-03-15 15:50:20 --> Helper loaded: html_helper
INFO - 2026-03-15 15:50:20 --> Helper loaded: file_helper
INFO - 2026-03-15 15:50:20 --> Helper loaded: email_helper
INFO - 2026-03-15 15:50:20 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:50:20 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:50:20 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:50:20 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:50:20 --> Database Driver Class Initialized
INFO - 2026-03-15 15:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:50:22 --> Upload Class Initialized
DEBUG - 2026-03-15 15:50:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:50:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:50:22 --> Encryption Class Initialized
INFO - 2026-03-15 15:50:22 --> Form Validation Class Initialized
INFO - 2026-03-15 15:50:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:50:22 --> Pagination Class Initialized
INFO - 2026-03-15 15:50:22 --> Email Class Initialized
INFO - 2026-03-15 15:50:22 --> Controller Class Initialized
DEBUG - 2026-03-15 15:50:22 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:50:22 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:50:22 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:50:22 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:50:22 --> Model "Common_model" initialized
INFO - 2026-03-15 15:56:54 --> Config Class Initialized
INFO - 2026-03-15 15:56:54 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:56:54 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:56:54 --> Utf8 Class Initialized
INFO - 2026-03-15 15:56:54 --> URI Class Initialized
INFO - 2026-03-15 15:56:54 --> Router Class Initialized
INFO - 2026-03-15 15:56:54 --> Output Class Initialized
INFO - 2026-03-15 15:56:54 --> Security Class Initialized
DEBUG - 2026-03-15 15:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:56:54 --> CSRF cookie sent
INFO - 2026-03-15 15:56:54 --> Input Class Initialized
INFO - 2026-03-15 15:56:54 --> Language Class Initialized
INFO - 2026-03-15 15:56:54 --> Language Class Initialized
INFO - 2026-03-15 15:56:54 --> Config Class Initialized
INFO - 2026-03-15 15:56:54 --> Loader Class Initialized
INFO - 2026-03-15 15:56:54 --> Helper loaded: url_helper
INFO - 2026-03-15 15:56:54 --> Helper loaded: form_helper
INFO - 2026-03-15 15:56:54 --> Helper loaded: html_helper
INFO - 2026-03-15 15:56:54 --> Helper loaded: file_helper
INFO - 2026-03-15 15:56:54 --> Helper loaded: email_helper
INFO - 2026-03-15 15:56:54 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:56:54 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:56:54 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:56:54 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:56:54 --> Database Driver Class Initialized
INFO - 2026-03-15 15:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:56:56 --> Upload Class Initialized
DEBUG - 2026-03-15 15:56:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:56:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:56:56 --> Encryption Class Initialized
INFO - 2026-03-15 15:56:56 --> Form Validation Class Initialized
INFO - 2026-03-15 15:56:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:56:56 --> Pagination Class Initialized
INFO - 2026-03-15 15:56:56 --> Email Class Initialized
INFO - 2026-03-15 15:56:56 --> Controller Class Initialized
DEBUG - 2026-03-15 15:56:56 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:56:56 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:56:56 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:56:56 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:56:56 --> Model "Common_model" initialized
DEBUG - 2026-03-15 15:56:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 15:56:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 15:56:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 15:56:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 15:56:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 15:56:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_list.php
INFO - 2026-03-15 15:56:56 --> Final output sent to browser
DEBUG - 2026-03-15 15:56:56 --> Total execution time: 2.1986
INFO - 2026-03-15 15:56:56 --> Config Class Initialized
INFO - 2026-03-15 15:56:56 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:56:56 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:56:56 --> Utf8 Class Initialized
INFO - 2026-03-15 15:56:56 --> URI Class Initialized
INFO - 2026-03-15 15:56:56 --> Router Class Initialized
INFO - 2026-03-15 15:56:56 --> Output Class Initialized
INFO - 2026-03-15 15:56:56 --> Security Class Initialized
DEBUG - 2026-03-15 15:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:56:56 --> CSRF cookie sent
INFO - 2026-03-15 15:56:56 --> Input Class Initialized
INFO - 2026-03-15 15:56:56 --> Language Class Initialized
INFO - 2026-03-15 15:56:56 --> Language Class Initialized
INFO - 2026-03-15 15:56:56 --> Config Class Initialized
INFO - 2026-03-15 15:56:56 --> Loader Class Initialized
INFO - 2026-03-15 15:56:56 --> Helper loaded: url_helper
INFO - 2026-03-15 15:56:56 --> Helper loaded: form_helper
INFO - 2026-03-15 15:56:56 --> Helper loaded: html_helper
INFO - 2026-03-15 15:56:56 --> Helper loaded: file_helper
INFO - 2026-03-15 15:56:56 --> Helper loaded: email_helper
INFO - 2026-03-15 15:56:56 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:56:56 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:56:56 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:56:56 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:56:56 --> Database Driver Class Initialized
INFO - 2026-03-15 15:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:56:58 --> Upload Class Initialized
DEBUG - 2026-03-15 15:56:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:56:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:56:58 --> Encryption Class Initialized
INFO - 2026-03-15 15:56:58 --> Form Validation Class Initialized
INFO - 2026-03-15 15:56:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:56:58 --> Pagination Class Initialized
INFO - 2026-03-15 15:56:58 --> Email Class Initialized
INFO - 2026-03-15 15:56:58 --> Controller Class Initialized
DEBUG - 2026-03-15 15:56:58 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:56:58 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:56:58 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:56:58 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:56:58 --> Model "Common_model" initialized
INFO - 2026-03-15 15:57:03 --> Config Class Initialized
INFO - 2026-03-15 15:57:03 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:57:03 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:57:03 --> Utf8 Class Initialized
INFO - 2026-03-15 15:57:03 --> URI Class Initialized
INFO - 2026-03-15 15:57:03 --> Router Class Initialized
INFO - 2026-03-15 15:57:03 --> Output Class Initialized
INFO - 2026-03-15 15:57:03 --> Security Class Initialized
DEBUG - 2026-03-15 15:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:57:03 --> CSRF cookie sent
INFO - 2026-03-15 15:57:03 --> Input Class Initialized
INFO - 2026-03-15 15:57:03 --> Language Class Initialized
INFO - 2026-03-15 15:57:03 --> Language Class Initialized
INFO - 2026-03-15 15:57:03 --> Config Class Initialized
INFO - 2026-03-15 15:57:03 --> Loader Class Initialized
INFO - 2026-03-15 15:57:03 --> Helper loaded: url_helper
INFO - 2026-03-15 15:57:03 --> Helper loaded: form_helper
INFO - 2026-03-15 15:57:03 --> Helper loaded: html_helper
INFO - 2026-03-15 15:57:03 --> Helper loaded: file_helper
INFO - 2026-03-15 15:57:03 --> Helper loaded: email_helper
INFO - 2026-03-15 15:57:03 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:57:03 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:57:03 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:57:03 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:57:03 --> Database Driver Class Initialized
INFO - 2026-03-15 15:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:57:05 --> Upload Class Initialized
DEBUG - 2026-03-15 15:57:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:57:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:57:05 --> Encryption Class Initialized
INFO - 2026-03-15 15:57:05 --> Form Validation Class Initialized
INFO - 2026-03-15 15:57:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:57:05 --> Pagination Class Initialized
INFO - 2026-03-15 15:57:05 --> Email Class Initialized
INFO - 2026-03-15 15:57:05 --> Controller Class Initialized
DEBUG - 2026-03-15 15:57:05 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:57:05 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:57:05 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:57:05 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:57:05 --> Model "Common_model" initialized
DEBUG - 2026-03-15 15:57:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 15:57:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 15:57:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 15:57:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 15:57:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 15:57:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_manage.php
INFO - 2026-03-15 15:57:11 --> Final output sent to browser
DEBUG - 2026-03-15 15:57:11 --> Total execution time: 7.2906
INFO - 2026-03-15 15:57:11 --> Config Class Initialized
INFO - 2026-03-15 15:57:11 --> Hooks Class Initialized
DEBUG - 2026-03-15 15:57:11 --> UTF-8 Support Enabled
INFO - 2026-03-15 15:57:11 --> Utf8 Class Initialized
INFO - 2026-03-15 15:57:11 --> URI Class Initialized
INFO - 2026-03-15 15:57:11 --> Router Class Initialized
INFO - 2026-03-15 15:57:11 --> Output Class Initialized
INFO - 2026-03-15 15:57:11 --> Security Class Initialized
DEBUG - 2026-03-15 15:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 15:57:11 --> CSRF cookie sent
INFO - 2026-03-15 15:57:11 --> Input Class Initialized
INFO - 2026-03-15 15:57:11 --> Language Class Initialized
INFO - 2026-03-15 15:57:11 --> Language Class Initialized
INFO - 2026-03-15 15:57:11 --> Config Class Initialized
INFO - 2026-03-15 15:57:11 --> Loader Class Initialized
INFO - 2026-03-15 15:57:11 --> Helper loaded: url_helper
INFO - 2026-03-15 15:57:11 --> Helper loaded: form_helper
INFO - 2026-03-15 15:57:11 --> Helper loaded: html_helper
INFO - 2026-03-15 15:57:11 --> Helper loaded: file_helper
INFO - 2026-03-15 15:57:11 --> Helper loaded: email_helper
INFO - 2026-03-15 15:57:11 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 15:57:11 --> Helper loaded: ssp_helper
INFO - 2026-03-15 15:57:11 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 15:57:11 --> Helper loaded: domain_helper
INFO - 2026-03-15 15:57:11 --> Database Driver Class Initialized
INFO - 2026-03-15 15:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 15:57:13 --> Upload Class Initialized
DEBUG - 2026-03-15 15:57:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 15:57:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 15:57:13 --> Encryption Class Initialized
INFO - 2026-03-15 15:57:13 --> Form Validation Class Initialized
INFO - 2026-03-15 15:57:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 15:57:13 --> Pagination Class Initialized
INFO - 2026-03-15 15:57:13 --> Email Class Initialized
INFO - 2026-03-15 15:57:13 --> Controller Class Initialized
DEBUG - 2026-03-15 15:57:13 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 15:57:13 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 15:57:13 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 15:57:13 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 15:57:13 --> Model "Common_model" initialized
INFO - 2026-03-15 16:01:00 --> Config Class Initialized
INFO - 2026-03-15 16:01:00 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:01:00 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:01:00 --> Utf8 Class Initialized
INFO - 2026-03-15 16:01:00 --> URI Class Initialized
INFO - 2026-03-15 16:01:00 --> Router Class Initialized
INFO - 2026-03-15 16:01:00 --> Output Class Initialized
INFO - 2026-03-15 16:01:00 --> Security Class Initialized
DEBUG - 2026-03-15 16:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:01:00 --> CSRF cookie sent
INFO - 2026-03-15 16:01:00 --> Input Class Initialized
INFO - 2026-03-15 16:01:00 --> Language Class Initialized
INFO - 2026-03-15 16:01:00 --> Language Class Initialized
INFO - 2026-03-15 16:01:00 --> Config Class Initialized
INFO - 2026-03-15 16:01:00 --> Loader Class Initialized
INFO - 2026-03-15 16:01:00 --> Helper loaded: url_helper
INFO - 2026-03-15 16:01:00 --> Helper loaded: form_helper
INFO - 2026-03-15 16:01:00 --> Helper loaded: html_helper
INFO - 2026-03-15 16:01:00 --> Helper loaded: file_helper
INFO - 2026-03-15 16:01:00 --> Helper loaded: email_helper
INFO - 2026-03-15 16:01:00 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:01:00 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:01:00 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:01:00 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:01:00 --> Database Driver Class Initialized
INFO - 2026-03-15 16:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:01:02 --> Upload Class Initialized
DEBUG - 2026-03-15 16:01:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:01:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:01:02 --> Encryption Class Initialized
INFO - 2026-03-15 16:01:02 --> Form Validation Class Initialized
INFO - 2026-03-15 16:01:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:01:02 --> Pagination Class Initialized
INFO - 2026-03-15 16:01:02 --> Email Class Initialized
INFO - 2026-03-15 16:01:02 --> Controller Class Initialized
DEBUG - 2026-03-15 16:01:02 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 16:01:02 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:01:02 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:01:02 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 16:01:02 --> Model "Common_model" initialized
DEBUG - 2026-03-15 16:01:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 16:01:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 16:01:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 16:01:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 16:01:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 16:01:07 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_manage.php
INFO - 2026-03-15 16:01:07 --> Final output sent to browser
DEBUG - 2026-03-15 16:01:07 --> Total execution time: 7.1740
INFO - 2026-03-15 16:01:07 --> Config Class Initialized
INFO - 2026-03-15 16:01:07 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:01:07 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:01:07 --> Utf8 Class Initialized
INFO - 2026-03-15 16:01:07 --> URI Class Initialized
INFO - 2026-03-15 16:01:07 --> Router Class Initialized
INFO - 2026-03-15 16:01:07 --> Output Class Initialized
INFO - 2026-03-15 16:01:07 --> Security Class Initialized
DEBUG - 2026-03-15 16:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:01:07 --> CSRF cookie sent
INFO - 2026-03-15 16:01:07 --> Input Class Initialized
INFO - 2026-03-15 16:01:07 --> Language Class Initialized
INFO - 2026-03-15 16:01:07 --> Language Class Initialized
INFO - 2026-03-15 16:01:07 --> Config Class Initialized
INFO - 2026-03-15 16:01:07 --> Loader Class Initialized
INFO - 2026-03-15 16:01:07 --> Helper loaded: url_helper
INFO - 2026-03-15 16:01:07 --> Helper loaded: form_helper
INFO - 2026-03-15 16:01:07 --> Helper loaded: html_helper
INFO - 2026-03-15 16:01:07 --> Helper loaded: file_helper
INFO - 2026-03-15 16:01:07 --> Helper loaded: email_helper
INFO - 2026-03-15 16:01:07 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:01:07 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:01:07 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:01:07 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:01:07 --> Database Driver Class Initialized
INFO - 2026-03-15 16:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:01:09 --> Upload Class Initialized
DEBUG - 2026-03-15 16:01:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:01:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:01:09 --> Encryption Class Initialized
INFO - 2026-03-15 16:01:09 --> Form Validation Class Initialized
INFO - 2026-03-15 16:01:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:01:09 --> Pagination Class Initialized
INFO - 2026-03-15 16:01:09 --> Email Class Initialized
INFO - 2026-03-15 16:01:09 --> Controller Class Initialized
DEBUG - 2026-03-15 16:01:09 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 16:01:09 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:01:09 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:01:09 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 16:01:09 --> Model "Common_model" initialized
INFO - 2026-03-15 16:08:38 --> Config Class Initialized
INFO - 2026-03-15 16:08:38 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:08:38 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:08:38 --> Utf8 Class Initialized
INFO - 2026-03-15 16:08:38 --> URI Class Initialized
INFO - 2026-03-15 16:08:38 --> Router Class Initialized
INFO - 2026-03-15 16:08:38 --> Output Class Initialized
INFO - 2026-03-15 16:08:38 --> Security Class Initialized
DEBUG - 2026-03-15 16:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:08:38 --> CSRF cookie sent
INFO - 2026-03-15 16:08:38 --> Input Class Initialized
INFO - 2026-03-15 16:08:38 --> Language Class Initialized
INFO - 2026-03-15 16:08:38 --> Language Class Initialized
INFO - 2026-03-15 16:08:38 --> Config Class Initialized
INFO - 2026-03-15 16:08:38 --> Loader Class Initialized
INFO - 2026-03-15 16:08:38 --> Helper loaded: url_helper
INFO - 2026-03-15 16:08:38 --> Helper loaded: form_helper
INFO - 2026-03-15 16:08:38 --> Helper loaded: html_helper
INFO - 2026-03-15 16:08:38 --> Helper loaded: file_helper
INFO - 2026-03-15 16:08:38 --> Helper loaded: email_helper
INFO - 2026-03-15 16:08:38 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:08:38 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:08:38 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:08:38 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:08:38 --> Database Driver Class Initialized
INFO - 2026-03-15 16:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:08:40 --> Upload Class Initialized
DEBUG - 2026-03-15 16:08:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:08:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:08:40 --> Encryption Class Initialized
INFO - 2026-03-15 16:08:40 --> Form Validation Class Initialized
INFO - 2026-03-15 16:08:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:08:40 --> Pagination Class Initialized
INFO - 2026-03-15 16:08:40 --> Email Class Initialized
INFO - 2026-03-15 16:08:40 --> Controller Class Initialized
DEBUG - 2026-03-15 16:08:40 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 16:08:40 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:08:40 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:08:40 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 16:08:40 --> Model "Common_model" initialized
DEBUG - 2026-03-15 16:08:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 16:08:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 16:08:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 16:08:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 16:08:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 16:08:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_manage.php
INFO - 2026-03-15 16:08:45 --> Final output sent to browser
DEBUG - 2026-03-15 16:08:45 --> Total execution time: 6.2756
INFO - 2026-03-15 16:09:49 --> Config Class Initialized
INFO - 2026-03-15 16:09:49 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:09:49 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:09:49 --> Utf8 Class Initialized
INFO - 2026-03-15 16:09:49 --> URI Class Initialized
INFO - 2026-03-15 16:09:49 --> Router Class Initialized
INFO - 2026-03-15 16:09:49 --> Output Class Initialized
INFO - 2026-03-15 16:09:49 --> Security Class Initialized
DEBUG - 2026-03-15 16:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:09:49 --> CSRF cookie sent
INFO - 2026-03-15 16:09:49 --> CSRF token verified
INFO - 2026-03-15 16:09:49 --> Input Class Initialized
INFO - 2026-03-15 16:09:49 --> Language Class Initialized
INFO - 2026-03-15 16:09:49 --> Language Class Initialized
INFO - 2026-03-15 16:09:49 --> Config Class Initialized
INFO - 2026-03-15 16:09:49 --> Loader Class Initialized
INFO - 2026-03-15 16:09:49 --> Helper loaded: url_helper
INFO - 2026-03-15 16:09:49 --> Helper loaded: form_helper
INFO - 2026-03-15 16:09:49 --> Helper loaded: html_helper
INFO - 2026-03-15 16:09:49 --> Helper loaded: file_helper
INFO - 2026-03-15 16:09:49 --> Helper loaded: email_helper
INFO - 2026-03-15 16:09:49 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:09:49 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:09:49 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:09:49 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:09:49 --> Database Driver Class Initialized
INFO - 2026-03-15 16:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:09:51 --> Upload Class Initialized
DEBUG - 2026-03-15 16:09:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:09:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:09:51 --> Encryption Class Initialized
INFO - 2026-03-15 16:09:51 --> Form Validation Class Initialized
INFO - 2026-03-15 16:09:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:09:51 --> Pagination Class Initialized
INFO - 2026-03-15 16:09:51 --> Email Class Initialized
INFO - 2026-03-15 16:09:51 --> Controller Class Initialized
DEBUG - 2026-03-15 16:09:51 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 16:09:51 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:09:51 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:09:51 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 16:09:51 --> Model "Common_model" initialized
INFO - 2026-03-15 16:09:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-03-15 16:09:53 --> Config Class Initialized
INFO - 2026-03-15 16:09:53 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:09:53 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:09:53 --> Utf8 Class Initialized
INFO - 2026-03-15 16:09:53 --> URI Class Initialized
INFO - 2026-03-15 16:09:53 --> Router Class Initialized
INFO - 2026-03-15 16:09:53 --> Output Class Initialized
INFO - 2026-03-15 16:09:53 --> Security Class Initialized
DEBUG - 2026-03-15 16:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:09:53 --> CSRF cookie sent
INFO - 2026-03-15 16:09:53 --> Input Class Initialized
INFO - 2026-03-15 16:09:53 --> Language Class Initialized
INFO - 2026-03-15 16:09:53 --> Language Class Initialized
INFO - 2026-03-15 16:09:53 --> Config Class Initialized
INFO - 2026-03-15 16:09:53 --> Loader Class Initialized
INFO - 2026-03-15 16:09:53 --> Helper loaded: url_helper
INFO - 2026-03-15 16:09:53 --> Helper loaded: form_helper
INFO - 2026-03-15 16:09:53 --> Helper loaded: html_helper
INFO - 2026-03-15 16:09:53 --> Helper loaded: file_helper
INFO - 2026-03-15 16:09:53 --> Helper loaded: email_helper
INFO - 2026-03-15 16:09:53 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:09:53 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:09:53 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:09:53 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:09:53 --> Database Driver Class Initialized
INFO - 2026-03-15 16:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:09:55 --> Upload Class Initialized
DEBUG - 2026-03-15 16:09:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:09:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:09:55 --> Encryption Class Initialized
INFO - 2026-03-15 16:09:55 --> Form Validation Class Initialized
INFO - 2026-03-15 16:09:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:09:55 --> Pagination Class Initialized
INFO - 2026-03-15 16:09:55 --> Email Class Initialized
INFO - 2026-03-15 16:09:55 --> Controller Class Initialized
DEBUG - 2026-03-15 16:09:55 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 16:09:55 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:09:55 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:09:55 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 16:09:55 --> Model "Common_model" initialized
DEBUG - 2026-03-15 16:09:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 16:09:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 16:09:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 16:09:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 16:09:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 16:09:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_list.php
INFO - 2026-03-15 16:09:56 --> Final output sent to browser
DEBUG - 2026-03-15 16:09:56 --> Total execution time: 2.3524
INFO - 2026-03-15 16:09:56 --> Config Class Initialized
INFO - 2026-03-15 16:09:56 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:09:56 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:09:56 --> Utf8 Class Initialized
INFO - 2026-03-15 16:09:56 --> URI Class Initialized
INFO - 2026-03-15 16:09:56 --> Router Class Initialized
INFO - 2026-03-15 16:09:56 --> Output Class Initialized
INFO - 2026-03-15 16:09:56 --> Security Class Initialized
DEBUG - 2026-03-15 16:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:09:56 --> CSRF cookie sent
INFO - 2026-03-15 16:09:56 --> Input Class Initialized
INFO - 2026-03-15 16:09:56 --> Language Class Initialized
INFO - 2026-03-15 16:09:56 --> Language Class Initialized
INFO - 2026-03-15 16:09:56 --> Config Class Initialized
INFO - 2026-03-15 16:09:56 --> Loader Class Initialized
INFO - 2026-03-15 16:09:56 --> Helper loaded: url_helper
INFO - 2026-03-15 16:09:56 --> Helper loaded: form_helper
INFO - 2026-03-15 16:09:56 --> Helper loaded: html_helper
INFO - 2026-03-15 16:09:56 --> Helper loaded: file_helper
INFO - 2026-03-15 16:09:56 --> Helper loaded: email_helper
INFO - 2026-03-15 16:09:56 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:09:56 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:09:56 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:09:56 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:09:56 --> Database Driver Class Initialized
INFO - 2026-03-15 16:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:09:58 --> Upload Class Initialized
DEBUG - 2026-03-15 16:09:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:09:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:09:58 --> Encryption Class Initialized
INFO - 2026-03-15 16:09:58 --> Form Validation Class Initialized
INFO - 2026-03-15 16:09:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:09:58 --> Pagination Class Initialized
INFO - 2026-03-15 16:09:58 --> Email Class Initialized
INFO - 2026-03-15 16:09:58 --> Controller Class Initialized
DEBUG - 2026-03-15 16:09:58 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 16:09:58 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:09:58 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:09:58 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 16:09:58 --> Model "Common_model" initialized
INFO - 2026-03-15 16:11:06 --> Config Class Initialized
INFO - 2026-03-15 16:11:06 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:11:06 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:11:06 --> Utf8 Class Initialized
INFO - 2026-03-15 16:11:06 --> URI Class Initialized
INFO - 2026-03-15 16:11:06 --> Router Class Initialized
INFO - 2026-03-15 16:11:06 --> Output Class Initialized
INFO - 2026-03-15 16:11:06 --> Security Class Initialized
DEBUG - 2026-03-15 16:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:11:06 --> CSRF cookie sent
INFO - 2026-03-15 16:11:06 --> Input Class Initialized
INFO - 2026-03-15 16:11:06 --> Language Class Initialized
INFO - 2026-03-15 16:11:06 --> Language Class Initialized
INFO - 2026-03-15 16:11:06 --> Config Class Initialized
INFO - 2026-03-15 16:11:06 --> Loader Class Initialized
INFO - 2026-03-15 16:11:06 --> Helper loaded: url_helper
INFO - 2026-03-15 16:11:06 --> Helper loaded: form_helper
INFO - 2026-03-15 16:11:06 --> Helper loaded: html_helper
INFO - 2026-03-15 16:11:06 --> Helper loaded: file_helper
INFO - 2026-03-15 16:11:06 --> Helper loaded: email_helper
INFO - 2026-03-15 16:11:06 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:11:06 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:11:06 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:11:06 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:11:06 --> Database Driver Class Initialized
INFO - 2026-03-15 16:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:11:08 --> Upload Class Initialized
DEBUG - 2026-03-15 16:11:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:11:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:11:08 --> Encryption Class Initialized
INFO - 2026-03-15 16:11:08 --> Form Validation Class Initialized
INFO - 2026-03-15 16:11:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:11:08 --> Pagination Class Initialized
INFO - 2026-03-15 16:11:08 --> Email Class Initialized
INFO - 2026-03-15 16:11:08 --> Controller Class Initialized
DEBUG - 2026-03-15 16:11:08 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 16:11:08 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:11:08 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:11:08 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 16:11:08 --> Model "Common_model" initialized
DEBUG - 2026-03-15 16:11:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 16:11:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 16:11:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 16:11:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 16:11:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 16:11:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_manage.php
INFO - 2026-03-15 16:11:13 --> Final output sent to browser
DEBUG - 2026-03-15 16:11:13 --> Total execution time: 6.6582
INFO - 2026-03-15 16:11:18 --> Config Class Initialized
INFO - 2026-03-15 16:11:18 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:11:18 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:11:18 --> Utf8 Class Initialized
INFO - 2026-03-15 16:11:18 --> URI Class Initialized
INFO - 2026-03-15 16:11:18 --> Router Class Initialized
INFO - 2026-03-15 16:11:18 --> Output Class Initialized
INFO - 2026-03-15 16:11:18 --> Security Class Initialized
DEBUG - 2026-03-15 16:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:11:18 --> CSRF cookie sent
INFO - 2026-03-15 16:11:18 --> CSRF token verified
INFO - 2026-03-15 16:11:18 --> Input Class Initialized
INFO - 2026-03-15 16:11:18 --> Language Class Initialized
INFO - 2026-03-15 16:11:18 --> Language Class Initialized
INFO - 2026-03-15 16:11:18 --> Config Class Initialized
INFO - 2026-03-15 16:11:18 --> Loader Class Initialized
INFO - 2026-03-15 16:11:18 --> Helper loaded: url_helper
INFO - 2026-03-15 16:11:18 --> Helper loaded: form_helper
INFO - 2026-03-15 16:11:18 --> Helper loaded: html_helper
INFO - 2026-03-15 16:11:18 --> Helper loaded: file_helper
INFO - 2026-03-15 16:11:18 --> Helper loaded: email_helper
INFO - 2026-03-15 16:11:18 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:11:18 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:11:18 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:11:18 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:11:18 --> Database Driver Class Initialized
ERROR - 2026-03-15 16:11:28 --> Severity: error --> Exception: Connection timed out /opt/lampp/htdocs/ci-crm/whmaz/database/drivers/mysqli/mysqli_driver.php 203
INFO - 2026-03-15 16:11:36 --> Config Class Initialized
INFO - 2026-03-15 16:11:36 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:11:36 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:11:36 --> Utf8 Class Initialized
INFO - 2026-03-15 16:11:36 --> URI Class Initialized
INFO - 2026-03-15 16:11:36 --> Router Class Initialized
INFO - 2026-03-15 16:11:36 --> Output Class Initialized
INFO - 2026-03-15 16:11:36 --> Security Class Initialized
DEBUG - 2026-03-15 16:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:11:36 --> CSRF cookie sent
INFO - 2026-03-15 16:11:40 --> Config Class Initialized
INFO - 2026-03-15 16:11:40 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:11:40 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:11:40 --> Utf8 Class Initialized
INFO - 2026-03-15 16:11:40 --> URI Class Initialized
INFO - 2026-03-15 16:11:40 --> Router Class Initialized
INFO - 2026-03-15 16:11:40 --> Output Class Initialized
INFO - 2026-03-15 16:11:40 --> Security Class Initialized
DEBUG - 2026-03-15 16:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:11:40 --> CSRF cookie sent
INFO - 2026-03-15 16:11:40 --> Input Class Initialized
INFO - 2026-03-15 16:11:40 --> Language Class Initialized
INFO - 2026-03-15 16:11:40 --> Language Class Initialized
INFO - 2026-03-15 16:11:40 --> Config Class Initialized
INFO - 2026-03-15 16:11:40 --> Loader Class Initialized
INFO - 2026-03-15 16:11:40 --> Helper loaded: url_helper
INFO - 2026-03-15 16:11:40 --> Helper loaded: form_helper
INFO - 2026-03-15 16:11:40 --> Helper loaded: html_helper
INFO - 2026-03-15 16:11:40 --> Helper loaded: file_helper
INFO - 2026-03-15 16:11:40 --> Helper loaded: email_helper
INFO - 2026-03-15 16:11:40 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:11:40 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:11:40 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:11:40 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:11:40 --> Database Driver Class Initialized
ERROR - 2026-03-15 16:11:50 --> Severity: error --> Exception: Connection timed out /opt/lampp/htdocs/ci-crm/whmaz/database/drivers/mysqli/mysqli_driver.php 203
INFO - 2026-03-15 16:11:59 --> Config Class Initialized
INFO - 2026-03-15 16:11:59 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:11:59 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:11:59 --> Utf8 Class Initialized
INFO - 2026-03-15 16:11:59 --> URI Class Initialized
INFO - 2026-03-15 16:11:59 --> Router Class Initialized
INFO - 2026-03-15 16:11:59 --> Output Class Initialized
INFO - 2026-03-15 16:11:59 --> Security Class Initialized
DEBUG - 2026-03-15 16:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:11:59 --> CSRF cookie sent
INFO - 2026-03-15 16:11:59 --> Input Class Initialized
INFO - 2026-03-15 16:11:59 --> Language Class Initialized
INFO - 2026-03-15 16:11:59 --> Language Class Initialized
INFO - 2026-03-15 16:11:59 --> Config Class Initialized
INFO - 2026-03-15 16:11:59 --> Loader Class Initialized
INFO - 2026-03-15 16:11:59 --> Helper loaded: url_helper
INFO - 2026-03-15 16:11:59 --> Helper loaded: form_helper
INFO - 2026-03-15 16:11:59 --> Helper loaded: html_helper
INFO - 2026-03-15 16:11:59 --> Helper loaded: file_helper
INFO - 2026-03-15 16:11:59 --> Helper loaded: email_helper
INFO - 2026-03-15 16:11:59 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:11:59 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:11:59 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:11:59 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:11:59 --> Database Driver Class Initialized
INFO - 2026-03-15 16:16:17 --> Config Class Initialized
INFO - 2026-03-15 16:16:17 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:16:17 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:16:17 --> Utf8 Class Initialized
INFO - 2026-03-15 16:16:17 --> URI Class Initialized
INFO - 2026-03-15 16:16:17 --> Router Class Initialized
INFO - 2026-03-15 16:16:17 --> Output Class Initialized
INFO - 2026-03-15 16:16:17 --> Security Class Initialized
DEBUG - 2026-03-15 16:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:16:17 --> CSRF cookie sent
INFO - 2026-03-15 16:16:17 --> Input Class Initialized
INFO - 2026-03-15 16:16:17 --> Language Class Initialized
INFO - 2026-03-15 16:16:17 --> Language Class Initialized
INFO - 2026-03-15 16:16:17 --> Config Class Initialized
INFO - 2026-03-15 16:16:17 --> Loader Class Initialized
INFO - 2026-03-15 16:16:17 --> Helper loaded: url_helper
INFO - 2026-03-15 16:16:17 --> Helper loaded: form_helper
INFO - 2026-03-15 16:16:17 --> Helper loaded: html_helper
INFO - 2026-03-15 16:16:17 --> Helper loaded: file_helper
INFO - 2026-03-15 16:16:17 --> Helper loaded: email_helper
INFO - 2026-03-15 16:16:17 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:16:17 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:16:17 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:16:17 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:16:17 --> Database Driver Class Initialized
INFO - 2026-03-15 16:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:16:19 --> Upload Class Initialized
DEBUG - 2026-03-15 16:16:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:16:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:16:19 --> Encryption Class Initialized
INFO - 2026-03-15 16:16:19 --> Form Validation Class Initialized
INFO - 2026-03-15 16:16:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:16:19 --> Pagination Class Initialized
INFO - 2026-03-15 16:16:19 --> Email Class Initialized
INFO - 2026-03-15 16:16:19 --> Controller Class Initialized
DEBUG - 2026-03-15 16:16:19 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 16:16:19 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:16:19 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:16:19 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 16:16:19 --> Model "Common_model" initialized
DEBUG - 2026-03-15 16:16:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 16:16:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 16:16:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 16:16:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 16:16:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 16:16:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_list.php
INFO - 2026-03-15 16:16:19 --> Final output sent to browser
DEBUG - 2026-03-15 16:16:19 --> Total execution time: 2.6541
INFO - 2026-03-15 16:16:20 --> Config Class Initialized
INFO - 2026-03-15 16:16:20 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:16:20 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:16:20 --> Utf8 Class Initialized
INFO - 2026-03-15 16:16:20 --> URI Class Initialized
INFO - 2026-03-15 16:16:20 --> Router Class Initialized
INFO - 2026-03-15 16:16:20 --> Output Class Initialized
INFO - 2026-03-15 16:16:20 --> Security Class Initialized
DEBUG - 2026-03-15 16:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:16:20 --> CSRF cookie sent
INFO - 2026-03-15 16:16:20 --> Input Class Initialized
INFO - 2026-03-15 16:16:20 --> Language Class Initialized
INFO - 2026-03-15 16:16:20 --> Language Class Initialized
INFO - 2026-03-15 16:16:20 --> Config Class Initialized
INFO - 2026-03-15 16:16:20 --> Loader Class Initialized
INFO - 2026-03-15 16:16:20 --> Helper loaded: url_helper
INFO - 2026-03-15 16:16:20 --> Helper loaded: form_helper
INFO - 2026-03-15 16:16:20 --> Helper loaded: html_helper
INFO - 2026-03-15 16:16:20 --> Helper loaded: file_helper
INFO - 2026-03-15 16:16:20 --> Helper loaded: email_helper
INFO - 2026-03-15 16:16:20 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:16:20 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:16:20 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:16:20 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:16:20 --> Database Driver Class Initialized
INFO - 2026-03-15 16:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:16:22 --> Upload Class Initialized
DEBUG - 2026-03-15 16:16:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:16:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:16:22 --> Encryption Class Initialized
INFO - 2026-03-15 16:16:22 --> Form Validation Class Initialized
INFO - 2026-03-15 16:16:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:16:22 --> Pagination Class Initialized
INFO - 2026-03-15 16:16:22 --> Email Class Initialized
INFO - 2026-03-15 16:16:22 --> Controller Class Initialized
DEBUG - 2026-03-15 16:16:22 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 16:16:22 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:16:22 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:16:22 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 16:16:22 --> Model "Common_model" initialized
INFO - 2026-03-15 16:16:29 --> Config Class Initialized
INFO - 2026-03-15 16:16:29 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:16:29 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:16:29 --> Utf8 Class Initialized
INFO - 2026-03-15 16:16:29 --> URI Class Initialized
INFO - 2026-03-15 16:16:29 --> Router Class Initialized
INFO - 2026-03-15 16:16:29 --> Output Class Initialized
INFO - 2026-03-15 16:16:29 --> Security Class Initialized
DEBUG - 2026-03-15 16:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:16:29 --> CSRF cookie sent
INFO - 2026-03-15 16:16:29 --> Input Class Initialized
INFO - 2026-03-15 16:16:29 --> Language Class Initialized
INFO - 2026-03-15 16:16:29 --> Language Class Initialized
INFO - 2026-03-15 16:16:29 --> Config Class Initialized
INFO - 2026-03-15 16:16:29 --> Loader Class Initialized
INFO - 2026-03-15 16:16:29 --> Helper loaded: url_helper
INFO - 2026-03-15 16:16:29 --> Helper loaded: form_helper
INFO - 2026-03-15 16:16:29 --> Helper loaded: html_helper
INFO - 2026-03-15 16:16:29 --> Helper loaded: file_helper
INFO - 2026-03-15 16:16:29 --> Helper loaded: email_helper
INFO - 2026-03-15 16:16:29 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:16:29 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:16:29 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:16:29 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:16:29 --> Database Driver Class Initialized
INFO - 2026-03-15 16:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:16:31 --> Upload Class Initialized
DEBUG - 2026-03-15 16:16:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:16:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:16:31 --> Encryption Class Initialized
INFO - 2026-03-15 16:16:31 --> Form Validation Class Initialized
INFO - 2026-03-15 16:16:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:16:31 --> Pagination Class Initialized
INFO - 2026-03-15 16:16:31 --> Email Class Initialized
INFO - 2026-03-15 16:16:31 --> Controller Class Initialized
DEBUG - 2026-03-15 16:16:31 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 16:16:31 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:16:31 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:16:31 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 16:16:31 --> Model "Common_model" initialized
DEBUG - 2026-03-15 16:16:36 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 16:16:36 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 16:16:36 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 16:16:36 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 16:16:36 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 16:16:36 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_manage.php
INFO - 2026-03-15 16:16:36 --> Final output sent to browser
DEBUG - 2026-03-15 16:16:36 --> Total execution time: 7.0192
INFO - 2026-03-15 16:16:42 --> Config Class Initialized
INFO - 2026-03-15 16:16:42 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:16:42 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:16:42 --> Utf8 Class Initialized
INFO - 2026-03-15 16:16:42 --> URI Class Initialized
INFO - 2026-03-15 16:16:42 --> Router Class Initialized
INFO - 2026-03-15 16:16:42 --> Output Class Initialized
INFO - 2026-03-15 16:16:42 --> Security Class Initialized
DEBUG - 2026-03-15 16:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:16:42 --> CSRF cookie sent
INFO - 2026-03-15 16:16:42 --> CSRF token verified
INFO - 2026-03-15 16:16:42 --> Input Class Initialized
INFO - 2026-03-15 16:16:42 --> Language Class Initialized
INFO - 2026-03-15 16:16:42 --> Language Class Initialized
INFO - 2026-03-15 16:16:42 --> Config Class Initialized
INFO - 2026-03-15 16:16:42 --> Loader Class Initialized
INFO - 2026-03-15 16:16:42 --> Helper loaded: url_helper
INFO - 2026-03-15 16:16:42 --> Helper loaded: form_helper
INFO - 2026-03-15 16:16:42 --> Helper loaded: html_helper
INFO - 2026-03-15 16:16:42 --> Helper loaded: file_helper
INFO - 2026-03-15 16:16:42 --> Helper loaded: email_helper
INFO - 2026-03-15 16:16:42 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:16:42 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:16:42 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:16:42 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:16:42 --> Database Driver Class Initialized
INFO - 2026-03-15 16:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:16:45 --> Upload Class Initialized
DEBUG - 2026-03-15 16:16:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:16:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:16:45 --> Encryption Class Initialized
INFO - 2026-03-15 16:16:45 --> Form Validation Class Initialized
INFO - 2026-03-15 16:16:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:16:45 --> Pagination Class Initialized
INFO - 2026-03-15 16:16:45 --> Email Class Initialized
INFO - 2026-03-15 16:16:45 --> Controller Class Initialized
DEBUG - 2026-03-15 16:16:45 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 16:16:45 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:16:45 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:16:45 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 16:16:45 --> Model "Common_model" initialized
INFO - 2026-03-15 16:16:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-03-15 16:16:49 --> Config Class Initialized
INFO - 2026-03-15 16:16:49 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:16:49 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:16:49 --> Utf8 Class Initialized
INFO - 2026-03-15 16:16:49 --> URI Class Initialized
INFO - 2026-03-15 16:16:49 --> Router Class Initialized
INFO - 2026-03-15 16:16:49 --> Output Class Initialized
INFO - 2026-03-15 16:16:49 --> Security Class Initialized
DEBUG - 2026-03-15 16:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:16:49 --> CSRF cookie sent
INFO - 2026-03-15 16:16:49 --> Input Class Initialized
INFO - 2026-03-15 16:16:49 --> Language Class Initialized
INFO - 2026-03-15 16:16:49 --> Language Class Initialized
INFO - 2026-03-15 16:16:49 --> Config Class Initialized
INFO - 2026-03-15 16:16:49 --> Loader Class Initialized
INFO - 2026-03-15 16:16:49 --> Helper loaded: url_helper
INFO - 2026-03-15 16:16:49 --> Helper loaded: form_helper
INFO - 2026-03-15 16:16:49 --> Helper loaded: html_helper
INFO - 2026-03-15 16:16:49 --> Helper loaded: file_helper
INFO - 2026-03-15 16:16:49 --> Helper loaded: email_helper
INFO - 2026-03-15 16:16:49 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:16:49 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:16:49 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:16:49 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:16:49 --> Database Driver Class Initialized
INFO - 2026-03-15 16:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:16:51 --> Upload Class Initialized
DEBUG - 2026-03-15 16:16:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:16:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:16:51 --> Encryption Class Initialized
INFO - 2026-03-15 16:16:51 --> Form Validation Class Initialized
INFO - 2026-03-15 16:16:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:16:51 --> Pagination Class Initialized
INFO - 2026-03-15 16:16:51 --> Email Class Initialized
INFO - 2026-03-15 16:16:51 --> Controller Class Initialized
DEBUG - 2026-03-15 16:16:51 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 16:16:51 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:16:51 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:16:51 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 16:16:51 --> Model "Common_model" initialized
DEBUG - 2026-03-15 16:16:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 16:16:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 16:16:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 16:16:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 16:16:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 16:16:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_list.php
INFO - 2026-03-15 16:16:51 --> Final output sent to browser
DEBUG - 2026-03-15 16:16:51 --> Total execution time: 2.4549
INFO - 2026-03-15 16:16:51 --> Config Class Initialized
INFO - 2026-03-15 16:16:51 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:16:51 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:16:51 --> Utf8 Class Initialized
INFO - 2026-03-15 16:16:51 --> URI Class Initialized
INFO - 2026-03-15 16:16:51 --> Router Class Initialized
INFO - 2026-03-15 16:16:51 --> Output Class Initialized
INFO - 2026-03-15 16:16:51 --> Security Class Initialized
DEBUG - 2026-03-15 16:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:16:51 --> CSRF cookie sent
INFO - 2026-03-15 16:16:51 --> Input Class Initialized
INFO - 2026-03-15 16:16:51 --> Language Class Initialized
INFO - 2026-03-15 16:16:51 --> Language Class Initialized
INFO - 2026-03-15 16:16:51 --> Config Class Initialized
INFO - 2026-03-15 16:16:51 --> Loader Class Initialized
INFO - 2026-03-15 16:16:51 --> Helper loaded: url_helper
INFO - 2026-03-15 16:16:51 --> Helper loaded: form_helper
INFO - 2026-03-15 16:16:51 --> Helper loaded: html_helper
INFO - 2026-03-15 16:16:51 --> Helper loaded: file_helper
INFO - 2026-03-15 16:16:51 --> Helper loaded: email_helper
INFO - 2026-03-15 16:16:51 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:16:51 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:16:51 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:16:51 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:16:51 --> Database Driver Class Initialized
INFO - 2026-03-15 16:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:16:53 --> Upload Class Initialized
DEBUG - 2026-03-15 16:16:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:16:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:16:53 --> Encryption Class Initialized
INFO - 2026-03-15 16:16:53 --> Form Validation Class Initialized
INFO - 2026-03-15 16:16:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:16:53 --> Pagination Class Initialized
INFO - 2026-03-15 16:16:53 --> Email Class Initialized
INFO - 2026-03-15 16:16:53 --> Controller Class Initialized
DEBUG - 2026-03-15 16:16:53 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 16:16:53 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:16:53 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:16:53 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 16:16:53 --> Model "Common_model" initialized
INFO - 2026-03-15 16:17:51 --> Config Class Initialized
INFO - 2026-03-15 16:17:51 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:17:51 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:17:51 --> Utf8 Class Initialized
INFO - 2026-03-15 16:17:51 --> URI Class Initialized
INFO - 2026-03-15 16:17:51 --> Router Class Initialized
INFO - 2026-03-15 16:17:51 --> Output Class Initialized
INFO - 2026-03-15 16:17:51 --> Security Class Initialized
DEBUG - 2026-03-15 16:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:17:51 --> CSRF cookie sent
INFO - 2026-03-15 16:17:51 --> Input Class Initialized
INFO - 2026-03-15 16:17:51 --> Language Class Initialized
INFO - 2026-03-15 16:17:51 --> Language Class Initialized
INFO - 2026-03-15 16:17:51 --> Config Class Initialized
INFO - 2026-03-15 16:17:51 --> Loader Class Initialized
INFO - 2026-03-15 16:17:51 --> Helper loaded: url_helper
INFO - 2026-03-15 16:17:51 --> Helper loaded: form_helper
INFO - 2026-03-15 16:17:51 --> Helper loaded: html_helper
INFO - 2026-03-15 16:17:51 --> Helper loaded: file_helper
INFO - 2026-03-15 16:17:51 --> Helper loaded: email_helper
INFO - 2026-03-15 16:17:51 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:17:51 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:17:51 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:17:51 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:17:51 --> Database Driver Class Initialized
INFO - 2026-03-15 16:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:17:53 --> Upload Class Initialized
DEBUG - 2026-03-15 16:17:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:17:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:17:53 --> Encryption Class Initialized
INFO - 2026-03-15 16:17:53 --> Form Validation Class Initialized
INFO - 2026-03-15 16:17:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:17:53 --> Pagination Class Initialized
INFO - 2026-03-15 16:17:53 --> Email Class Initialized
INFO - 2026-03-15 16:17:53 --> Controller Class Initialized
DEBUG - 2026-03-15 16:17:53 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 16:17:53 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:17:53 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:17:53 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 16:17:53 --> Model "Common_model" initialized
DEBUG - 2026-03-15 16:17:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 16:17:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 16:17:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 16:17:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 16:17:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 16:17:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_manage.php
INFO - 2026-03-15 16:17:58 --> Final output sent to browser
DEBUG - 2026-03-15 16:17:58 --> Total execution time: 6.7975
INFO - 2026-03-15 16:18:35 --> Config Class Initialized
INFO - 2026-03-15 16:18:35 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:18:35 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:18:35 --> Utf8 Class Initialized
INFO - 2026-03-15 16:18:35 --> URI Class Initialized
INFO - 2026-03-15 16:18:35 --> Router Class Initialized
INFO - 2026-03-15 16:18:35 --> Output Class Initialized
INFO - 2026-03-15 16:18:35 --> Security Class Initialized
DEBUG - 2026-03-15 16:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:18:35 --> CSRF cookie sent
INFO - 2026-03-15 16:18:35 --> CSRF token verified
INFO - 2026-03-15 16:18:35 --> Input Class Initialized
INFO - 2026-03-15 16:18:35 --> Language Class Initialized
INFO - 2026-03-15 16:18:35 --> Language Class Initialized
INFO - 2026-03-15 16:18:35 --> Config Class Initialized
INFO - 2026-03-15 16:18:35 --> Loader Class Initialized
INFO - 2026-03-15 16:18:35 --> Helper loaded: url_helper
INFO - 2026-03-15 16:18:35 --> Helper loaded: form_helper
INFO - 2026-03-15 16:18:35 --> Helper loaded: html_helper
INFO - 2026-03-15 16:18:35 --> Helper loaded: file_helper
INFO - 2026-03-15 16:18:35 --> Helper loaded: email_helper
INFO - 2026-03-15 16:18:35 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:18:35 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:18:35 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:18:35 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:18:35 --> Database Driver Class Initialized
INFO - 2026-03-15 16:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:18:37 --> Upload Class Initialized
DEBUG - 2026-03-15 16:18:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:18:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:18:37 --> Encryption Class Initialized
INFO - 2026-03-15 16:18:37 --> Form Validation Class Initialized
INFO - 2026-03-15 16:18:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:18:37 --> Pagination Class Initialized
INFO - 2026-03-15 16:18:37 --> Email Class Initialized
INFO - 2026-03-15 16:18:37 --> Controller Class Initialized
DEBUG - 2026-03-15 16:18:37 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 16:18:37 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:18:37 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:18:37 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 16:18:37 --> Model "Common_model" initialized
INFO - 2026-03-15 16:18:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-03-15 16:18:40 --> Config Class Initialized
INFO - 2026-03-15 16:18:40 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:18:40 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:18:40 --> Utf8 Class Initialized
INFO - 2026-03-15 16:18:40 --> URI Class Initialized
INFO - 2026-03-15 16:18:40 --> Router Class Initialized
INFO - 2026-03-15 16:18:40 --> Output Class Initialized
INFO - 2026-03-15 16:18:40 --> Security Class Initialized
DEBUG - 2026-03-15 16:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:18:40 --> CSRF cookie sent
INFO - 2026-03-15 16:18:40 --> Input Class Initialized
INFO - 2026-03-15 16:18:40 --> Language Class Initialized
INFO - 2026-03-15 16:18:40 --> Language Class Initialized
INFO - 2026-03-15 16:18:40 --> Config Class Initialized
INFO - 2026-03-15 16:18:40 --> Loader Class Initialized
INFO - 2026-03-15 16:18:40 --> Helper loaded: url_helper
INFO - 2026-03-15 16:18:40 --> Helper loaded: form_helper
INFO - 2026-03-15 16:18:40 --> Helper loaded: html_helper
INFO - 2026-03-15 16:18:40 --> Helper loaded: file_helper
INFO - 2026-03-15 16:18:40 --> Helper loaded: email_helper
INFO - 2026-03-15 16:18:40 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:18:40 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:18:40 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:18:40 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:18:40 --> Database Driver Class Initialized
INFO - 2026-03-15 16:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:18:42 --> Upload Class Initialized
DEBUG - 2026-03-15 16:18:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:18:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:18:42 --> Encryption Class Initialized
INFO - 2026-03-15 16:18:42 --> Form Validation Class Initialized
INFO - 2026-03-15 16:18:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:18:42 --> Pagination Class Initialized
INFO - 2026-03-15 16:18:42 --> Email Class Initialized
INFO - 2026-03-15 16:18:42 --> Controller Class Initialized
DEBUG - 2026-03-15 16:18:42 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 16:18:42 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:18:42 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:18:42 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 16:18:42 --> Model "Common_model" initialized
DEBUG - 2026-03-15 16:18:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 16:18:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 16:18:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 16:18:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 16:18:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 16:18:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_list.php
INFO - 2026-03-15 16:18:42 --> Final output sent to browser
DEBUG - 2026-03-15 16:18:42 --> Total execution time: 2.4550
INFO - 2026-03-15 16:18:43 --> Config Class Initialized
INFO - 2026-03-15 16:18:43 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:18:43 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:18:43 --> Utf8 Class Initialized
INFO - 2026-03-15 16:18:43 --> URI Class Initialized
INFO - 2026-03-15 16:18:43 --> Router Class Initialized
INFO - 2026-03-15 16:18:43 --> Output Class Initialized
INFO - 2026-03-15 16:18:43 --> Security Class Initialized
DEBUG - 2026-03-15 16:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:18:43 --> CSRF cookie sent
INFO - 2026-03-15 16:18:43 --> Input Class Initialized
INFO - 2026-03-15 16:18:43 --> Language Class Initialized
INFO - 2026-03-15 16:18:43 --> Language Class Initialized
INFO - 2026-03-15 16:18:43 --> Config Class Initialized
INFO - 2026-03-15 16:18:43 --> Loader Class Initialized
INFO - 2026-03-15 16:18:43 --> Helper loaded: url_helper
INFO - 2026-03-15 16:18:43 --> Helper loaded: form_helper
INFO - 2026-03-15 16:18:43 --> Helper loaded: html_helper
INFO - 2026-03-15 16:18:43 --> Helper loaded: file_helper
INFO - 2026-03-15 16:18:43 --> Helper loaded: email_helper
INFO - 2026-03-15 16:18:43 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:18:43 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:18:43 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:18:43 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:18:43 --> Database Driver Class Initialized
INFO - 2026-03-15 16:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:18:45 --> Upload Class Initialized
DEBUG - 2026-03-15 16:18:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:18:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:18:45 --> Encryption Class Initialized
INFO - 2026-03-15 16:18:45 --> Form Validation Class Initialized
INFO - 2026-03-15 16:18:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:18:45 --> Pagination Class Initialized
INFO - 2026-03-15 16:18:45 --> Email Class Initialized
INFO - 2026-03-15 16:18:45 --> Controller Class Initialized
DEBUG - 2026-03-15 16:18:45 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 16:18:45 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:18:45 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:18:45 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 16:18:45 --> Model "Common_model" initialized
INFO - 2026-03-15 16:19:27 --> Config Class Initialized
INFO - 2026-03-15 16:19:27 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:19:27 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:19:27 --> Utf8 Class Initialized
INFO - 2026-03-15 16:19:27 --> URI Class Initialized
INFO - 2026-03-15 16:19:27 --> Router Class Initialized
INFO - 2026-03-15 16:19:27 --> Output Class Initialized
INFO - 2026-03-15 16:19:27 --> Security Class Initialized
DEBUG - 2026-03-15 16:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:19:27 --> CSRF cookie sent
INFO - 2026-03-15 16:19:27 --> Input Class Initialized
INFO - 2026-03-15 16:19:27 --> Language Class Initialized
INFO - 2026-03-15 16:19:27 --> Language Class Initialized
INFO - 2026-03-15 16:19:27 --> Config Class Initialized
INFO - 2026-03-15 16:19:27 --> Loader Class Initialized
INFO - 2026-03-15 16:19:27 --> Helper loaded: url_helper
INFO - 2026-03-15 16:19:27 --> Helper loaded: form_helper
INFO - 2026-03-15 16:19:27 --> Helper loaded: html_helper
INFO - 2026-03-15 16:19:27 --> Helper loaded: file_helper
INFO - 2026-03-15 16:19:27 --> Helper loaded: email_helper
INFO - 2026-03-15 16:19:27 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:19:27 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:19:27 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:19:27 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:19:27 --> Database Driver Class Initialized
INFO - 2026-03-15 16:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:19:29 --> Upload Class Initialized
DEBUG - 2026-03-15 16:19:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:19:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:19:29 --> Encryption Class Initialized
INFO - 2026-03-15 16:19:29 --> Form Validation Class Initialized
INFO - 2026-03-15 16:19:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:19:29 --> Pagination Class Initialized
INFO - 2026-03-15 16:19:29 --> Email Class Initialized
INFO - 2026-03-15 16:19:29 --> Controller Class Initialized
DEBUG - 2026-03-15 16:19:29 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 16:19:29 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:19:29 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:19:29 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 16:19:29 --> Model "Common_model" initialized
DEBUG - 2026-03-15 16:19:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 16:19:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 16:19:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 16:19:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 16:19:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 16:19:34 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_manage.php
INFO - 2026-03-15 16:19:34 --> Final output sent to browser
DEBUG - 2026-03-15 16:19:34 --> Total execution time: 6.9551
INFO - 2026-03-15 16:19:40 --> Config Class Initialized
INFO - 2026-03-15 16:19:40 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:19:40 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:19:40 --> Utf8 Class Initialized
INFO - 2026-03-15 16:19:40 --> URI Class Initialized
INFO - 2026-03-15 16:19:40 --> Router Class Initialized
INFO - 2026-03-15 16:19:40 --> Output Class Initialized
INFO - 2026-03-15 16:19:40 --> Security Class Initialized
DEBUG - 2026-03-15 16:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:19:40 --> CSRF cookie sent
INFO - 2026-03-15 16:19:40 --> Input Class Initialized
INFO - 2026-03-15 16:19:40 --> Language Class Initialized
INFO - 2026-03-15 16:19:40 --> Language Class Initialized
INFO - 2026-03-15 16:19:40 --> Config Class Initialized
INFO - 2026-03-15 16:19:40 --> Loader Class Initialized
INFO - 2026-03-15 16:19:40 --> Helper loaded: url_helper
INFO - 2026-03-15 16:19:40 --> Helper loaded: form_helper
INFO - 2026-03-15 16:19:40 --> Helper loaded: html_helper
INFO - 2026-03-15 16:19:40 --> Helper loaded: file_helper
INFO - 2026-03-15 16:19:40 --> Helper loaded: email_helper
INFO - 2026-03-15 16:19:40 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:19:40 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:19:40 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:19:40 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:19:40 --> Database Driver Class Initialized
INFO - 2026-03-15 16:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:19:42 --> Upload Class Initialized
DEBUG - 2026-03-15 16:19:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:19:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:19:42 --> Encryption Class Initialized
INFO - 2026-03-15 16:19:42 --> Form Validation Class Initialized
INFO - 2026-03-15 16:19:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:19:42 --> Pagination Class Initialized
INFO - 2026-03-15 16:19:42 --> Email Class Initialized
INFO - 2026-03-15 16:19:42 --> Controller Class Initialized
DEBUG - 2026-03-15 16:19:42 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 16:19:42 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:19:42 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:19:42 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 16:19:42 --> Model "Common_model" initialized
DEBUG - 2026-03-15 16:19:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 16:19:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 16:19:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 16:19:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 16:19:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 16:19:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_list.php
INFO - 2026-03-15 16:19:43 --> Final output sent to browser
DEBUG - 2026-03-15 16:19:43 --> Total execution time: 2.4947
INFO - 2026-03-15 16:19:43 --> Config Class Initialized
INFO - 2026-03-15 16:19:43 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:19:43 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:19:43 --> Utf8 Class Initialized
INFO - 2026-03-15 16:19:43 --> URI Class Initialized
INFO - 2026-03-15 16:19:43 --> Router Class Initialized
INFO - 2026-03-15 16:19:43 --> Output Class Initialized
INFO - 2026-03-15 16:19:43 --> Security Class Initialized
DEBUG - 2026-03-15 16:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:19:43 --> CSRF cookie sent
INFO - 2026-03-15 16:19:43 --> Input Class Initialized
INFO - 2026-03-15 16:19:43 --> Language Class Initialized
INFO - 2026-03-15 16:19:43 --> Language Class Initialized
INFO - 2026-03-15 16:19:43 --> Config Class Initialized
INFO - 2026-03-15 16:19:43 --> Loader Class Initialized
INFO - 2026-03-15 16:19:43 --> Helper loaded: url_helper
INFO - 2026-03-15 16:19:43 --> Helper loaded: form_helper
INFO - 2026-03-15 16:19:43 --> Helper loaded: html_helper
INFO - 2026-03-15 16:19:43 --> Helper loaded: file_helper
INFO - 2026-03-15 16:19:43 --> Helper loaded: email_helper
INFO - 2026-03-15 16:19:43 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:19:43 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:19:43 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:19:43 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:19:43 --> Database Driver Class Initialized
INFO - 2026-03-15 16:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:19:46 --> Upload Class Initialized
DEBUG - 2026-03-15 16:19:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:19:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:19:46 --> Encryption Class Initialized
INFO - 2026-03-15 16:19:46 --> Form Validation Class Initialized
INFO - 2026-03-15 16:19:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:19:46 --> Pagination Class Initialized
INFO - 2026-03-15 16:19:46 --> Email Class Initialized
INFO - 2026-03-15 16:19:46 --> Controller Class Initialized
DEBUG - 2026-03-15 16:19:46 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 16:19:46 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:19:46 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:19:46 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 16:19:46 --> Model "Common_model" initialized
INFO - 2026-03-15 16:20:26 --> Config Class Initialized
INFO - 2026-03-15 16:20:26 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:20:26 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:20:26 --> Utf8 Class Initialized
INFO - 2026-03-15 16:20:26 --> URI Class Initialized
INFO - 2026-03-15 16:20:26 --> Router Class Initialized
INFO - 2026-03-15 16:20:26 --> Output Class Initialized
INFO - 2026-03-15 16:20:26 --> Security Class Initialized
DEBUG - 2026-03-15 16:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:20:26 --> CSRF cookie sent
INFO - 2026-03-15 16:20:26 --> Input Class Initialized
INFO - 2026-03-15 16:20:26 --> Language Class Initialized
INFO - 2026-03-15 16:20:26 --> Language Class Initialized
INFO - 2026-03-15 16:20:26 --> Config Class Initialized
INFO - 2026-03-15 16:20:26 --> Loader Class Initialized
INFO - 2026-03-15 16:20:26 --> Helper loaded: url_helper
INFO - 2026-03-15 16:20:26 --> Helper loaded: form_helper
INFO - 2026-03-15 16:20:26 --> Helper loaded: html_helper
INFO - 2026-03-15 16:20:26 --> Helper loaded: file_helper
INFO - 2026-03-15 16:20:26 --> Helper loaded: email_helper
INFO - 2026-03-15 16:20:26 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:20:26 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:20:26 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:20:26 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:20:26 --> Database Driver Class Initialized
INFO - 2026-03-15 16:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:20:28 --> Upload Class Initialized
DEBUG - 2026-03-15 16:20:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:20:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:20:28 --> Encryption Class Initialized
INFO - 2026-03-15 16:20:28 --> Form Validation Class Initialized
INFO - 2026-03-15 16:20:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:20:28 --> Pagination Class Initialized
INFO - 2026-03-15 16:20:28 --> Email Class Initialized
INFO - 2026-03-15 16:20:28 --> Controller Class Initialized
DEBUG - 2026-03-15 16:20:28 --> Package MX_Controller Initialized
INFO - 2026-03-15 16:20:28 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:20:28 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:20:28 --> Model "Package_model" initialized
INFO - 2026-03-15 16:20:28 --> Model "Common_model" initialized
DEBUG - 2026-03-15 16:20:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 16:20:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 16:20:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 16:20:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 16:20:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 16:20:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/package_list.php
INFO - 2026-03-15 16:20:29 --> Final output sent to browser
DEBUG - 2026-03-15 16:20:29 --> Total execution time: 2.4722
INFO - 2026-03-15 16:20:29 --> Config Class Initialized
INFO - 2026-03-15 16:20:29 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:20:29 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:20:29 --> Utf8 Class Initialized
INFO - 2026-03-15 16:20:29 --> URI Class Initialized
INFO - 2026-03-15 16:20:29 --> Router Class Initialized
INFO - 2026-03-15 16:20:29 --> Output Class Initialized
INFO - 2026-03-15 16:20:29 --> Security Class Initialized
DEBUG - 2026-03-15 16:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:20:29 --> CSRF cookie sent
INFO - 2026-03-15 16:20:29 --> Input Class Initialized
INFO - 2026-03-15 16:20:29 --> Language Class Initialized
INFO - 2026-03-15 16:20:29 --> Language Class Initialized
INFO - 2026-03-15 16:20:29 --> Config Class Initialized
INFO - 2026-03-15 16:20:29 --> Loader Class Initialized
INFO - 2026-03-15 16:20:29 --> Helper loaded: url_helper
INFO - 2026-03-15 16:20:29 --> Helper loaded: form_helper
INFO - 2026-03-15 16:20:29 --> Helper loaded: html_helper
INFO - 2026-03-15 16:20:29 --> Helper loaded: file_helper
INFO - 2026-03-15 16:20:29 --> Helper loaded: email_helper
INFO - 2026-03-15 16:20:29 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:20:29 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:20:29 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:20:29 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:20:29 --> Database Driver Class Initialized
INFO - 2026-03-15 16:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:20:31 --> Upload Class Initialized
DEBUG - 2026-03-15 16:20:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:20:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:20:31 --> Encryption Class Initialized
INFO - 2026-03-15 16:20:31 --> Form Validation Class Initialized
INFO - 2026-03-15 16:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:20:31 --> Pagination Class Initialized
INFO - 2026-03-15 16:20:31 --> Email Class Initialized
INFO - 2026-03-15 16:20:31 --> Controller Class Initialized
DEBUG - 2026-03-15 16:20:31 --> Package MX_Controller Initialized
INFO - 2026-03-15 16:20:31 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:20:31 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:20:31 --> Model "Package_model" initialized
INFO - 2026-03-15 16:20:31 --> Model "Common_model" initialized
INFO - 2026-03-15 16:21:26 --> Config Class Initialized
INFO - 2026-03-15 16:21:26 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:21:26 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:21:26 --> Utf8 Class Initialized
INFO - 2026-03-15 16:21:26 --> URI Class Initialized
INFO - 2026-03-15 16:21:26 --> Router Class Initialized
INFO - 2026-03-15 16:21:26 --> Output Class Initialized
INFO - 2026-03-15 16:21:26 --> Security Class Initialized
DEBUG - 2026-03-15 16:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:21:26 --> CSRF cookie sent
INFO - 2026-03-15 16:21:26 --> Input Class Initialized
INFO - 2026-03-15 16:21:26 --> Language Class Initialized
INFO - 2026-03-15 16:21:26 --> Language Class Initialized
INFO - 2026-03-15 16:21:26 --> Config Class Initialized
INFO - 2026-03-15 16:21:26 --> Loader Class Initialized
INFO - 2026-03-15 16:21:26 --> Helper loaded: url_helper
INFO - 2026-03-15 16:21:26 --> Helper loaded: form_helper
INFO - 2026-03-15 16:21:26 --> Helper loaded: html_helper
INFO - 2026-03-15 16:21:26 --> Helper loaded: file_helper
INFO - 2026-03-15 16:21:26 --> Helper loaded: email_helper
INFO - 2026-03-15 16:21:26 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:21:26 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:21:26 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:21:26 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:21:26 --> Database Driver Class Initialized
INFO - 2026-03-15 16:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:21:28 --> Upload Class Initialized
DEBUG - 2026-03-15 16:21:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:21:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:21:28 --> Encryption Class Initialized
INFO - 2026-03-15 16:21:28 --> Form Validation Class Initialized
INFO - 2026-03-15 16:21:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:21:28 --> Pagination Class Initialized
INFO - 2026-03-15 16:21:28 --> Email Class Initialized
INFO - 2026-03-15 16:21:28 --> Controller Class Initialized
DEBUG - 2026-03-15 16:21:28 --> Package MX_Controller Initialized
INFO - 2026-03-15 16:21:28 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:21:28 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:21:28 --> Model "Package_model" initialized
INFO - 2026-03-15 16:21:28 --> Model "Common_model" initialized
INFO - 2026-03-15 16:21:32 --> Config Class Initialized
INFO - 2026-03-15 16:21:32 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:21:32 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:21:32 --> Utf8 Class Initialized
INFO - 2026-03-15 16:21:32 --> URI Class Initialized
INFO - 2026-03-15 16:21:32 --> Router Class Initialized
INFO - 2026-03-15 16:21:32 --> Output Class Initialized
INFO - 2026-03-15 16:21:32 --> Security Class Initialized
DEBUG - 2026-03-15 16:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:21:32 --> CSRF cookie sent
INFO - 2026-03-15 16:21:32 --> Input Class Initialized
INFO - 2026-03-15 16:21:32 --> Language Class Initialized
INFO - 2026-03-15 16:21:32 --> Language Class Initialized
INFO - 2026-03-15 16:21:32 --> Config Class Initialized
INFO - 2026-03-15 16:21:32 --> Loader Class Initialized
INFO - 2026-03-15 16:21:32 --> Helper loaded: url_helper
INFO - 2026-03-15 16:21:32 --> Helper loaded: form_helper
INFO - 2026-03-15 16:21:32 --> Helper loaded: html_helper
INFO - 2026-03-15 16:21:32 --> Helper loaded: file_helper
INFO - 2026-03-15 16:21:32 --> Helper loaded: email_helper
INFO - 2026-03-15 16:21:32 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:21:32 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:21:32 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:21:32 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:21:32 --> Database Driver Class Initialized
INFO - 2026-03-15 16:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:21:34 --> Upload Class Initialized
DEBUG - 2026-03-15 16:21:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:21:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:21:34 --> Encryption Class Initialized
INFO - 2026-03-15 16:21:34 --> Form Validation Class Initialized
INFO - 2026-03-15 16:21:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:21:34 --> Pagination Class Initialized
INFO - 2026-03-15 16:21:34 --> Email Class Initialized
INFO - 2026-03-15 16:21:34 --> Controller Class Initialized
DEBUG - 2026-03-15 16:21:34 --> Package MX_Controller Initialized
INFO - 2026-03-15 16:21:34 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:21:34 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:21:34 --> Model "Package_model" initialized
INFO - 2026-03-15 16:21:34 --> Model "Common_model" initialized
INFO - 2026-03-15 16:21:56 --> Config Class Initialized
INFO - 2026-03-15 16:21:56 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:21:56 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:21:56 --> Utf8 Class Initialized
INFO - 2026-03-15 16:21:56 --> URI Class Initialized
INFO - 2026-03-15 16:21:56 --> Router Class Initialized
INFO - 2026-03-15 16:21:56 --> Output Class Initialized
INFO - 2026-03-15 16:21:56 --> Security Class Initialized
DEBUG - 2026-03-15 16:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:21:56 --> CSRF cookie sent
INFO - 2026-03-15 16:21:56 --> Input Class Initialized
INFO - 2026-03-15 16:21:56 --> Language Class Initialized
INFO - 2026-03-15 16:21:56 --> Language Class Initialized
INFO - 2026-03-15 16:21:56 --> Config Class Initialized
INFO - 2026-03-15 16:21:56 --> Loader Class Initialized
INFO - 2026-03-15 16:21:56 --> Helper loaded: url_helper
INFO - 2026-03-15 16:21:56 --> Helper loaded: form_helper
INFO - 2026-03-15 16:21:56 --> Helper loaded: html_helper
INFO - 2026-03-15 16:21:56 --> Helper loaded: file_helper
INFO - 2026-03-15 16:21:56 --> Helper loaded: email_helper
INFO - 2026-03-15 16:21:56 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:21:56 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:21:56 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:21:56 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:21:56 --> Database Driver Class Initialized
INFO - 2026-03-15 16:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:21:58 --> Upload Class Initialized
DEBUG - 2026-03-15 16:21:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:21:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:21:58 --> Encryption Class Initialized
INFO - 2026-03-15 16:21:58 --> Form Validation Class Initialized
INFO - 2026-03-15 16:21:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:21:58 --> Pagination Class Initialized
INFO - 2026-03-15 16:21:58 --> Email Class Initialized
INFO - 2026-03-15 16:21:58 --> Controller Class Initialized
DEBUG - 2026-03-15 16:21:58 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 16:21:58 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:21:58 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:21:58 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 16:21:58 --> Model "Common_model" initialized
DEBUG - 2026-03-15 16:21:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 16:21:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 16:21:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 16:21:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 16:21:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 16:21:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_list.php
INFO - 2026-03-15 16:21:58 --> Final output sent to browser
DEBUG - 2026-03-15 16:21:58 --> Total execution time: 2.5137
INFO - 2026-03-15 16:21:58 --> Config Class Initialized
INFO - 2026-03-15 16:21:58 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:21:58 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:21:58 --> Utf8 Class Initialized
INFO - 2026-03-15 16:21:58 --> URI Class Initialized
INFO - 2026-03-15 16:21:58 --> Router Class Initialized
INFO - 2026-03-15 16:21:58 --> Output Class Initialized
INFO - 2026-03-15 16:21:58 --> Security Class Initialized
DEBUG - 2026-03-15 16:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:21:58 --> CSRF cookie sent
INFO - 2026-03-15 16:21:58 --> Input Class Initialized
INFO - 2026-03-15 16:21:58 --> Language Class Initialized
INFO - 2026-03-15 16:21:58 --> Language Class Initialized
INFO - 2026-03-15 16:21:58 --> Config Class Initialized
INFO - 2026-03-15 16:21:58 --> Loader Class Initialized
INFO - 2026-03-15 16:21:58 --> Helper loaded: url_helper
INFO - 2026-03-15 16:21:58 --> Helper loaded: form_helper
INFO - 2026-03-15 16:21:58 --> Helper loaded: html_helper
INFO - 2026-03-15 16:21:58 --> Helper loaded: file_helper
INFO - 2026-03-15 16:21:58 --> Helper loaded: email_helper
INFO - 2026-03-15 16:21:58 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:21:58 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:21:58 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:21:58 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:21:58 --> Database Driver Class Initialized
INFO - 2026-03-15 16:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:22:00 --> Upload Class Initialized
DEBUG - 2026-03-15 16:22:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:22:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:22:00 --> Encryption Class Initialized
INFO - 2026-03-15 16:22:00 --> Form Validation Class Initialized
INFO - 2026-03-15 16:22:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:22:00 --> Pagination Class Initialized
INFO - 2026-03-15 16:22:00 --> Email Class Initialized
INFO - 2026-03-15 16:22:00 --> Controller Class Initialized
DEBUG - 2026-03-15 16:22:00 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 16:22:00 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:22:00 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:22:00 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 16:22:00 --> Model "Common_model" initialized
INFO - 2026-03-15 16:22:00 --> Config Class Initialized
INFO - 2026-03-15 16:22:00 --> Hooks Class Initialized
INFO - 2026-03-15 16:22:00 --> Config Class Initialized
INFO - 2026-03-15 16:22:00 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:22:00 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:22:00 --> Utf8 Class Initialized
INFO - 2026-03-15 16:22:00 --> URI Class Initialized
INFO - 2026-03-15 16:22:00 --> Router Class Initialized
INFO - 2026-03-15 16:22:00 --> Output Class Initialized
DEBUG - 2026-03-15 16:22:00 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:22:00 --> Utf8 Class Initialized
INFO - 2026-03-15 16:22:00 --> Config Class Initialized
INFO - 2026-03-15 16:22:00 --> URI Class Initialized
INFO - 2026-03-15 16:22:00 --> Hooks Class Initialized
INFO - 2026-03-15 16:22:00 --> Security Class Initialized
INFO - 2026-03-15 16:22:00 --> Config Class Initialized
INFO - 2026-03-15 16:22:00 --> Hooks Class Initialized
INFO - 2026-03-15 16:22:00 --> Config Class Initialized
INFO - 2026-03-15 16:22:00 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:22:00 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:22:00 --> Utf8 Class Initialized
DEBUG - 2026-03-15 16:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:22:00 --> CSRF cookie sent
INFO - 2026-03-15 16:22:00 --> Input Class Initialized
INFO - 2026-03-15 16:22:00 --> Language Class Initialized
DEBUG - 2026-03-15 16:22:00 --> UTF-8 Support Enabled
DEBUG - 2026-03-15 16:22:00 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:22:00 --> Router Class Initialized
INFO - 2026-03-15 16:22:00 --> Utf8 Class Initialized
INFO - 2026-03-15 16:22:00 --> URI Class Initialized
INFO - 2026-03-15 16:22:00 --> Language Class Initialized
INFO - 2026-03-15 16:22:00 --> Config Class Initialized
INFO - 2026-03-15 16:22:00 --> URI Class Initialized
INFO - 2026-03-15 16:22:00 --> Utf8 Class Initialized
INFO - 2026-03-15 16:22:00 --> Output Class Initialized
INFO - 2026-03-15 16:22:00 --> Router Class Initialized
INFO - 2026-03-15 16:22:00 --> URI Class Initialized
INFO - 2026-03-15 16:22:00 --> Router Class Initialized
INFO - 2026-03-15 16:22:00 --> Security Class Initialized
INFO - 2026-03-15 16:22:00 --> Output Class Initialized
INFO - 2026-03-15 16:22:00 --> Router Class Initialized
INFO - 2026-03-15 16:22:00 --> Output Class Initialized
DEBUG - 2026-03-15 16:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:22:00 --> CSRF cookie sent
INFO - 2026-03-15 16:22:00 --> Input Class Initialized
INFO - 2026-03-15 16:22:00 --> Language Class Initialized
INFO - 2026-03-15 16:22:00 --> Security Class Initialized
INFO - 2026-03-15 16:22:00 --> Output Class Initialized
INFO - 2026-03-15 16:22:00 --> Security Class Initialized
INFO - 2026-03-15 16:22:00 --> Language Class Initialized
INFO - 2026-03-15 16:22:00 --> Config Class Initialized
DEBUG - 2026-03-15 16:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:22:00 --> CSRF cookie sent
INFO - 2026-03-15 16:22:00 --> Input Class Initialized
INFO - 2026-03-15 16:22:00 --> Language Class Initialized
DEBUG - 2026-03-15 16:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:22:00 --> CSRF cookie sent
INFO - 2026-03-15 16:22:00 --> Input Class Initialized
INFO - 2026-03-15 16:22:00 --> Security Class Initialized
INFO - 2026-03-15 16:22:00 --> Language Class Initialized
INFO - 2026-03-15 16:22:00 --> Language Class Initialized
INFO - 2026-03-15 16:22:00 --> Config Class Initialized
INFO - 2026-03-15 16:22:00 --> Language Class Initialized
INFO - 2026-03-15 16:22:00 --> Config Class Initialized
DEBUG - 2026-03-15 16:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:22:00 --> CSRF cookie sent
INFO - 2026-03-15 16:22:00 --> Input Class Initialized
INFO - 2026-03-15 16:22:00 --> Loader Class Initialized
INFO - 2026-03-15 16:22:00 --> Language Class Initialized
INFO - 2026-03-15 16:22:00 --> Helper loaded: url_helper
INFO - 2026-03-15 16:22:00 --> Language Class Initialized
INFO - 2026-03-15 16:22:00 --> Config Class Initialized
INFO - 2026-03-15 16:22:00 --> Helper loaded: form_helper
INFO - 2026-03-15 16:22:00 --> Loader Class Initialized
INFO - 2026-03-15 16:22:00 --> Loader Class Initialized
INFO - 2026-03-15 16:22:00 --> Helper loaded: html_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: file_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: url_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: url_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: email_helper
INFO - 2026-03-15 16:22:00 --> Loader Class Initialized
INFO - 2026-03-15 16:22:00 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: form_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: form_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: url_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: html_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: file_helper
INFO - 2026-03-15 16:22:00 --> Loader Class Initialized
INFO - 2026-03-15 16:22:00 --> Helper loaded: email_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: form_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: url_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: html_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: file_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: email_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: form_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: html_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: html_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: file_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: file_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: email_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: email_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:22:00 --> Database Driver Class Initialized
INFO - 2026-03-15 16:22:00 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:22:00 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:22:00 --> Database Driver Class Initialized
INFO - 2026-03-15 16:22:00 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:22:00 --> Database Driver Class Initialized
INFO - 2026-03-15 16:22:00 --> Database Driver Class Initialized
INFO - 2026-03-15 16:22:00 --> Database Driver Class Initialized
INFO - 2026-03-15 16:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:22:02 --> Upload Class Initialized
DEBUG - 2026-03-15 16:22:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:22:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:22:02 --> Encryption Class Initialized
INFO - 2026-03-15 16:22:02 --> Form Validation Class Initialized
INFO - 2026-03-15 16:22:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:22:02 --> Pagination Class Initialized
INFO - 2026-03-15 16:22:02 --> Config Class Initialized
INFO - 2026-03-15 16:22:02 --> Hooks Class Initialized
INFO - 2026-03-15 16:22:02 --> Email Class Initialized
INFO - 2026-03-15 16:22:02 --> Controller Class Initialized
ERROR - 2026-03-15 16:22:02 --> 404 Page Not Found: /index
DEBUG - 2026-03-15 16:22:02 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:22:02 --> Utf8 Class Initialized
INFO - 2026-03-15 16:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:22:02 --> URI Class Initialized
INFO - 2026-03-15 16:22:02 --> Upload Class Initialized
INFO - 2026-03-15 16:22:02 --> Router Class Initialized
DEBUG - 2026-03-15 16:22:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:22:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:22:02 --> Encryption Class Initialized
INFO - 2026-03-15 16:22:02 --> Output Class Initialized
INFO - 2026-03-15 16:22:02 --> Form Validation Class Initialized
INFO - 2026-03-15 16:22:02 --> Security Class Initialized
INFO - 2026-03-15 16:22:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:22:02 --> Pagination Class Initialized
DEBUG - 2026-03-15 16:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:22:02 --> CSRF cookie sent
INFO - 2026-03-15 16:22:02 --> Input Class Initialized
INFO - 2026-03-15 16:22:02 --> Language Class Initialized
INFO - 2026-03-15 16:22:02 --> Language Class Initialized
INFO - 2026-03-15 16:22:02 --> Config Class Initialized
INFO - 2026-03-15 16:22:02 --> Email Class Initialized
INFO - 2026-03-15 16:22:02 --> Controller Class Initialized
ERROR - 2026-03-15 16:22:02 --> 404 Page Not Found: /index
INFO - 2026-03-15 16:22:02 --> Config Class Initialized
INFO - 2026-03-15 16:22:02 --> Hooks Class Initialized
INFO - 2026-03-15 16:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:22:02 --> Loader Class Initialized
DEBUG - 2026-03-15 16:22:02 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:22:02 --> Utf8 Class Initialized
INFO - 2026-03-15 16:22:02 --> Helper loaded: url_helper
INFO - 2026-03-15 16:22:02 --> URI Class Initialized
INFO - 2026-03-15 16:22:02 --> Upload Class Initialized
INFO - 2026-03-15 16:22:02 --> Router Class Initialized
INFO - 2026-03-15 16:22:02 --> Helper loaded: form_helper
INFO - 2026-03-15 16:22:02 --> Helper loaded: html_helper
DEBUG - 2026-03-15 16:22:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:22:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:22:02 --> Encryption Class Initialized
INFO - 2026-03-15 16:22:02 --> Helper loaded: file_helper
INFO - 2026-03-15 16:22:02 --> Helper loaded: email_helper
INFO - 2026-03-15 16:22:02 --> Output Class Initialized
INFO - 2026-03-15 16:22:02 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:22:02 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:22:02 --> Security Class Initialized
INFO - 2026-03-15 16:22:02 --> Form Validation Class Initialized
DEBUG - 2026-03-15 16:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:22:02 --> CSRF cookie sent
INFO - 2026-03-15 16:22:02 --> Input Class Initialized
INFO - 2026-03-15 16:22:02 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:22:02 --> Language Class Initialized
INFO - 2026-03-15 16:22:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:22:02 --> Pagination Class Initialized
INFO - 2026-03-15 16:22:02 --> Language Class Initialized
INFO - 2026-03-15 16:22:02 --> Config Class Initialized
INFO - 2026-03-15 16:22:02 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:22:02 --> Loader Class Initialized
INFO - 2026-03-15 16:22:02 --> Helper loaded: url_helper
INFO - 2026-03-15 16:22:02 --> Helper loaded: form_helper
INFO - 2026-03-15 16:22:02 --> Helper loaded: html_helper
INFO - 2026-03-15 16:22:02 --> Email Class Initialized
INFO - 2026-03-15 16:22:02 --> Controller Class Initialized
INFO - 2026-03-15 16:22:02 --> Helper loaded: file_helper
INFO - 2026-03-15 16:22:02 --> Helper loaded: email_helper
ERROR - 2026-03-15 16:22:02 --> 404 Page Not Found: /index
INFO - 2026-03-15 16:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:22:02 --> Database Driver Class Initialized
INFO - 2026-03-15 16:22:02 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:22:02 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:22:02 --> Upload Class Initialized
INFO - 2026-03-15 16:22:02 --> Helper loaded: cpanel_helper
DEBUG - 2026-03-15 16:22:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:22:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:22:02 --> Encryption Class Initialized
INFO - 2026-03-15 16:22:02 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:22:02 --> Form Validation Class Initialized
INFO - 2026-03-15 16:22:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:22:02 --> Pagination Class Initialized
INFO - 2026-03-15 16:22:02 --> Email Class Initialized
INFO - 2026-03-15 16:22:02 --> Controller Class Initialized
ERROR - 2026-03-15 16:22:02 --> 404 Page Not Found: /index
INFO - 2026-03-15 16:22:02 --> Database Driver Class Initialized
INFO - 2026-03-15 16:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:22:02 --> Upload Class Initialized
DEBUG - 2026-03-15 16:22:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:22:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:22:02 --> Encryption Class Initialized
INFO - 2026-03-15 16:22:02 --> Form Validation Class Initialized
INFO - 2026-03-15 16:22:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:22:02 --> Pagination Class Initialized
INFO - 2026-03-15 16:22:02 --> Email Class Initialized
INFO - 2026-03-15 16:22:02 --> Controller Class Initialized
ERROR - 2026-03-15 16:22:02 --> 404 Page Not Found: /index
INFO - 2026-03-15 16:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:22:04 --> Upload Class Initialized
DEBUG - 2026-03-15 16:22:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:22:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:22:04 --> Encryption Class Initialized
INFO - 2026-03-15 16:22:04 --> Form Validation Class Initialized
INFO - 2026-03-15 16:22:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:22:04 --> Pagination Class Initialized
INFO - 2026-03-15 16:22:04 --> Email Class Initialized
INFO - 2026-03-15 16:22:04 --> Controller Class Initialized
ERROR - 2026-03-15 16:22:04 --> 404 Page Not Found: /index
INFO - 2026-03-15 16:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:22:04 --> Upload Class Initialized
DEBUG - 2026-03-15 16:22:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:22:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:22:04 --> Encryption Class Initialized
INFO - 2026-03-15 16:22:04 --> Form Validation Class Initialized
INFO - 2026-03-15 16:22:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:22:04 --> Pagination Class Initialized
INFO - 2026-03-15 16:22:04 --> Email Class Initialized
INFO - 2026-03-15 16:22:04 --> Controller Class Initialized
ERROR - 2026-03-15 16:22:04 --> 404 Page Not Found: /index
INFO - 2026-03-15 16:22:06 --> Config Class Initialized
INFO - 2026-03-15 16:22:06 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:22:06 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:22:06 --> Utf8 Class Initialized
INFO - 2026-03-15 16:22:06 --> URI Class Initialized
INFO - 2026-03-15 16:22:06 --> Router Class Initialized
INFO - 2026-03-15 16:22:06 --> Output Class Initialized
INFO - 2026-03-15 16:22:06 --> Security Class Initialized
DEBUG - 2026-03-15 16:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:22:06 --> CSRF cookie sent
INFO - 2026-03-15 16:22:06 --> Input Class Initialized
INFO - 2026-03-15 16:22:06 --> Language Class Initialized
INFO - 2026-03-15 16:22:06 --> Language Class Initialized
INFO - 2026-03-15 16:22:06 --> Config Class Initialized
INFO - 2026-03-15 16:22:06 --> Loader Class Initialized
INFO - 2026-03-15 16:22:06 --> Helper loaded: url_helper
INFO - 2026-03-15 16:22:06 --> Helper loaded: form_helper
INFO - 2026-03-15 16:22:06 --> Helper loaded: html_helper
INFO - 2026-03-15 16:22:06 --> Helper loaded: file_helper
INFO - 2026-03-15 16:22:06 --> Helper loaded: email_helper
INFO - 2026-03-15 16:22:06 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:22:06 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:22:06 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:22:06 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:22:06 --> Database Driver Class Initialized
INFO - 2026-03-15 16:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:22:07 --> Upload Class Initialized
DEBUG - 2026-03-15 16:22:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:22:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:22:07 --> Encryption Class Initialized
INFO - 2026-03-15 16:22:07 --> Form Validation Class Initialized
INFO - 2026-03-15 16:22:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:22:07 --> Pagination Class Initialized
INFO - 2026-03-15 16:22:07 --> Email Class Initialized
INFO - 2026-03-15 16:22:07 --> Controller Class Initialized
DEBUG - 2026-03-15 16:22:07 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 16:22:07 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:22:07 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:22:07 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 16:22:07 --> Model "Common_model" initialized
DEBUG - 2026-03-15 16:22:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 16:22:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 16:22:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 16:22:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 16:22:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 16:22:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_manage.php
INFO - 2026-03-15 16:22:12 --> Final output sent to browser
DEBUG - 2026-03-15 16:22:12 --> Total execution time: 6.6941
INFO - 2026-03-15 16:22:12 --> Config Class Initialized
INFO - 2026-03-15 16:22:12 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:22:12 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:22:12 --> Utf8 Class Initialized
INFO - 2026-03-15 16:22:12 --> URI Class Initialized
INFO - 2026-03-15 16:22:12 --> Router Class Initialized
INFO - 2026-03-15 16:22:12 --> Output Class Initialized
INFO - 2026-03-15 16:22:12 --> Security Class Initialized
DEBUG - 2026-03-15 16:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:22:12 --> CSRF cookie sent
INFO - 2026-03-15 16:22:12 --> Input Class Initialized
INFO - 2026-03-15 16:22:12 --> Language Class Initialized
INFO - 2026-03-15 16:22:12 --> Language Class Initialized
INFO - 2026-03-15 16:22:12 --> Config Class Initialized
INFO - 2026-03-15 16:22:12 --> Loader Class Initialized
INFO - 2026-03-15 16:22:12 --> Helper loaded: url_helper
INFO - 2026-03-15 16:22:12 --> Helper loaded: form_helper
INFO - 2026-03-15 16:22:12 --> Helper loaded: html_helper
INFO - 2026-03-15 16:22:12 --> Helper loaded: file_helper
INFO - 2026-03-15 16:22:12 --> Helper loaded: email_helper
INFO - 2026-03-15 16:22:12 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:22:12 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:22:12 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:22:12 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:22:13 --> Database Driver Class Initialized
INFO - 2026-03-15 16:22:13 --> Config Class Initialized
INFO - 2026-03-15 16:22:13 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:22:13 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:22:13 --> Utf8 Class Initialized
INFO - 2026-03-15 16:22:13 --> URI Class Initialized
INFO - 2026-03-15 16:22:13 --> Router Class Initialized
INFO - 2026-03-15 16:22:13 --> Output Class Initialized
INFO - 2026-03-15 16:22:13 --> Security Class Initialized
DEBUG - 2026-03-15 16:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:22:13 --> CSRF cookie sent
INFO - 2026-03-15 16:22:13 --> Input Class Initialized
INFO - 2026-03-15 16:22:13 --> Language Class Initialized
INFO - 2026-03-15 16:22:13 --> Language Class Initialized
INFO - 2026-03-15 16:22:13 --> Config Class Initialized
INFO - 2026-03-15 16:22:13 --> Loader Class Initialized
INFO - 2026-03-15 16:22:13 --> Helper loaded: url_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: form_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: html_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: file_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: email_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:22:13 --> Database Driver Class Initialized
INFO - 2026-03-15 16:22:13 --> Config Class Initialized
INFO - 2026-03-15 16:22:13 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:22:13 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:22:13 --> Utf8 Class Initialized
INFO - 2026-03-15 16:22:13 --> URI Class Initialized
INFO - 2026-03-15 16:22:13 --> Router Class Initialized
INFO - 2026-03-15 16:22:13 --> Output Class Initialized
INFO - 2026-03-15 16:22:13 --> Security Class Initialized
DEBUG - 2026-03-15 16:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:22:13 --> CSRF cookie sent
INFO - 2026-03-15 16:22:13 --> Input Class Initialized
INFO - 2026-03-15 16:22:13 --> Language Class Initialized
INFO - 2026-03-15 16:22:13 --> Language Class Initialized
INFO - 2026-03-15 16:22:13 --> Config Class Initialized
INFO - 2026-03-15 16:22:13 --> Loader Class Initialized
INFO - 2026-03-15 16:22:13 --> Helper loaded: url_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: form_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: html_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: file_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: email_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:22:13 --> Database Driver Class Initialized
INFO - 2026-03-15 16:22:13 --> Config Class Initialized
INFO - 2026-03-15 16:22:13 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:22:13 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:22:13 --> Utf8 Class Initialized
INFO - 2026-03-15 16:22:13 --> URI Class Initialized
INFO - 2026-03-15 16:22:13 --> Router Class Initialized
INFO - 2026-03-15 16:22:13 --> Config Class Initialized
INFO - 2026-03-15 16:22:13 --> Hooks Class Initialized
INFO - 2026-03-15 16:22:13 --> Config Class Initialized
INFO - 2026-03-15 16:22:13 --> Hooks Class Initialized
INFO - 2026-03-15 16:22:13 --> Output Class Initialized
DEBUG - 2026-03-15 16:22:13 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:22:13 --> Utf8 Class Initialized
DEBUG - 2026-03-15 16:22:13 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:22:13 --> Utf8 Class Initialized
INFO - 2026-03-15 16:22:13 --> URI Class Initialized
INFO - 2026-03-15 16:22:13 --> Security Class Initialized
INFO - 2026-03-15 16:22:13 --> URI Class Initialized
DEBUG - 2026-03-15 16:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:22:13 --> CSRF cookie sent
INFO - 2026-03-15 16:22:13 --> Input Class Initialized
INFO - 2026-03-15 16:22:13 --> Language Class Initialized
INFO - 2026-03-15 16:22:13 --> Router Class Initialized
INFO - 2026-03-15 16:22:13 --> Language Class Initialized
INFO - 2026-03-15 16:22:13 --> Config Class Initialized
INFO - 2026-03-15 16:22:13 --> Router Class Initialized
INFO - 2026-03-15 16:22:13 --> Output Class Initialized
INFO - 2026-03-15 16:22:13 --> Output Class Initialized
INFO - 2026-03-15 16:22:13 --> Security Class Initialized
INFO - 2026-03-15 16:22:13 --> Loader Class Initialized
INFO - 2026-03-15 16:22:13 --> Security Class Initialized
DEBUG - 2026-03-15 16:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:22:13 --> CSRF cookie sent
INFO - 2026-03-15 16:22:13 --> Input Class Initialized
INFO - 2026-03-15 16:22:13 --> Helper loaded: url_helper
INFO - 2026-03-15 16:22:13 --> Language Class Initialized
DEBUG - 2026-03-15 16:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:22:13 --> CSRF cookie sent
INFO - 2026-03-15 16:22:13 --> Input Class Initialized
INFO - 2026-03-15 16:22:13 --> Language Class Initialized
INFO - 2026-03-15 16:22:13 --> Helper loaded: form_helper
INFO - 2026-03-15 16:22:13 --> Language Class Initialized
INFO - 2026-03-15 16:22:13 --> Config Class Initialized
INFO - 2026-03-15 16:22:13 --> Language Class Initialized
INFO - 2026-03-15 16:22:13 --> Config Class Initialized
INFO - 2026-03-15 16:22:13 --> Helper loaded: html_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: file_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: email_helper
INFO - 2026-03-15 16:22:13 --> Loader Class Initialized
INFO - 2026-03-15 16:22:13 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:22:13 --> Loader Class Initialized
INFO - 2026-03-15 16:22:13 --> Helper loaded: url_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: url_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: form_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: html_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: file_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: email_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: form_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: html_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: file_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: email_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:22:13 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:22:13 --> Database Driver Class Initialized
INFO - 2026-03-15 16:22:13 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:22:13 --> Database Driver Class Initialized
INFO - 2026-03-15 16:22:13 --> Database Driver Class Initialized
INFO - 2026-03-15 16:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:22:14 --> Upload Class Initialized
DEBUG - 2026-03-15 16:22:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:22:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:22:14 --> Encryption Class Initialized
INFO - 2026-03-15 16:22:14 --> Form Validation Class Initialized
INFO - 2026-03-15 16:22:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:22:14 --> Pagination Class Initialized
INFO - 2026-03-15 16:22:14 --> Email Class Initialized
INFO - 2026-03-15 16:22:14 --> Controller Class Initialized
ERROR - 2026-03-15 16:22:14 --> 404 Page Not Found: /index
INFO - 2026-03-15 16:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:22:14 --> Upload Class Initialized
DEBUG - 2026-03-15 16:22:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:22:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:22:14 --> Encryption Class Initialized
INFO - 2026-03-15 16:22:14 --> Form Validation Class Initialized
INFO - 2026-03-15 16:22:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:22:14 --> Pagination Class Initialized
INFO - 2026-03-15 16:22:14 --> Config Class Initialized
INFO - 2026-03-15 16:22:14 --> Hooks Class Initialized
INFO - 2026-03-15 16:22:14 --> Email Class Initialized
INFO - 2026-03-15 16:22:14 --> Controller Class Initialized
ERROR - 2026-03-15 16:22:14 --> 404 Page Not Found: /index
DEBUG - 2026-03-15 16:22:14 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:22:14 --> Utf8 Class Initialized
INFO - 2026-03-15 16:22:14 --> URI Class Initialized
INFO - 2026-03-15 16:22:14 --> Router Class Initialized
INFO - 2026-03-15 16:22:14 --> Output Class Initialized
INFO - 2026-03-15 16:22:14 --> Security Class Initialized
DEBUG - 2026-03-15 16:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:22:14 --> CSRF cookie sent
INFO - 2026-03-15 16:22:14 --> Input Class Initialized
INFO - 2026-03-15 16:22:14 --> Language Class Initialized
INFO - 2026-03-15 16:22:14 --> Language Class Initialized
INFO - 2026-03-15 16:22:14 --> Config Class Initialized
INFO - 2026-03-15 16:22:14 --> Loader Class Initialized
INFO - 2026-03-15 16:22:14 --> Helper loaded: url_helper
INFO - 2026-03-15 16:22:14 --> Helper loaded: form_helper
INFO - 2026-03-15 16:22:14 --> Helper loaded: html_helper
INFO - 2026-03-15 16:22:14 --> Helper loaded: file_helper
INFO - 2026-03-15 16:22:14 --> Helper loaded: email_helper
INFO - 2026-03-15 16:22:14 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:22:14 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:22:14 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:22:14 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:22:14 --> Database Driver Class Initialized
INFO - 2026-03-15 16:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:22:15 --> Upload Class Initialized
DEBUG - 2026-03-15 16:22:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:22:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:22:15 --> Encryption Class Initialized
INFO - 2026-03-15 16:22:15 --> Form Validation Class Initialized
INFO - 2026-03-15 16:22:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:22:15 --> Pagination Class Initialized
INFO - 2026-03-15 16:22:15 --> Email Class Initialized
INFO - 2026-03-15 16:22:15 --> Controller Class Initialized
ERROR - 2026-03-15 16:22:15 --> 404 Page Not Found: /index
INFO - 2026-03-15 16:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:22:15 --> Upload Class Initialized
DEBUG - 2026-03-15 16:22:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:22:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:22:15 --> Encryption Class Initialized
INFO - 2026-03-15 16:22:15 --> Form Validation Class Initialized
INFO - 2026-03-15 16:22:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:22:15 --> Pagination Class Initialized
INFO - 2026-03-15 16:22:15 --> Email Class Initialized
INFO - 2026-03-15 16:22:15 --> Controller Class Initialized
ERROR - 2026-03-15 16:22:15 --> 404 Page Not Found: /index
INFO - 2026-03-15 16:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:22:15 --> Upload Class Initialized
DEBUG - 2026-03-15 16:22:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:22:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:22:15 --> Encryption Class Initialized
INFO - 2026-03-15 16:22:15 --> Form Validation Class Initialized
INFO - 2026-03-15 16:22:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:22:15 --> Pagination Class Initialized
INFO - 2026-03-15 16:22:15 --> Email Class Initialized
INFO - 2026-03-15 16:22:15 --> Controller Class Initialized
ERROR - 2026-03-15 16:22:15 --> 404 Page Not Found: /index
INFO - 2026-03-15 16:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:22:15 --> Upload Class Initialized
DEBUG - 2026-03-15 16:22:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:22:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:22:15 --> Encryption Class Initialized
INFO - 2026-03-15 16:22:15 --> Form Validation Class Initialized
INFO - 2026-03-15 16:22:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:22:15 --> Pagination Class Initialized
INFO - 2026-03-15 16:22:15 --> Email Class Initialized
INFO - 2026-03-15 16:22:15 --> Controller Class Initialized
ERROR - 2026-03-15 16:22:15 --> 404 Page Not Found: /index
INFO - 2026-03-15 16:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:22:16 --> Upload Class Initialized
DEBUG - 2026-03-15 16:22:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:22:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:22:16 --> Encryption Class Initialized
INFO - 2026-03-15 16:22:16 --> Form Validation Class Initialized
INFO - 2026-03-15 16:22:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:22:16 --> Pagination Class Initialized
INFO - 2026-03-15 16:22:16 --> Email Class Initialized
INFO - 2026-03-15 16:22:16 --> Controller Class Initialized
ERROR - 2026-03-15 16:22:16 --> 404 Page Not Found: /index
INFO - 2026-03-15 16:23:25 --> Config Class Initialized
INFO - 2026-03-15 16:23:25 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:23:25 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:23:25 --> Utf8 Class Initialized
INFO - 2026-03-15 16:23:25 --> URI Class Initialized
INFO - 2026-03-15 16:23:25 --> Router Class Initialized
INFO - 2026-03-15 16:23:25 --> Output Class Initialized
INFO - 2026-03-15 16:23:25 --> Security Class Initialized
DEBUG - 2026-03-15 16:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:23:25 --> CSRF cookie sent
INFO - 2026-03-15 16:23:25 --> Input Class Initialized
INFO - 2026-03-15 16:23:25 --> Language Class Initialized
INFO - 2026-03-15 16:23:25 --> Language Class Initialized
INFO - 2026-03-15 16:23:25 --> Config Class Initialized
INFO - 2026-03-15 16:23:25 --> Loader Class Initialized
INFO - 2026-03-15 16:23:25 --> Helper loaded: url_helper
INFO - 2026-03-15 16:23:25 --> Helper loaded: form_helper
INFO - 2026-03-15 16:23:25 --> Helper loaded: html_helper
INFO - 2026-03-15 16:23:25 --> Helper loaded: file_helper
INFO - 2026-03-15 16:23:25 --> Helper loaded: email_helper
INFO - 2026-03-15 16:23:25 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:23:25 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:23:25 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:23:25 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:23:25 --> Database Driver Class Initialized
INFO - 2026-03-15 16:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:23:27 --> Upload Class Initialized
DEBUG - 2026-03-15 16:23:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:23:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:23:27 --> Encryption Class Initialized
INFO - 2026-03-15 16:23:27 --> Form Validation Class Initialized
INFO - 2026-03-15 16:23:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:23:27 --> Pagination Class Initialized
INFO - 2026-03-15 16:23:27 --> Email Class Initialized
INFO - 2026-03-15 16:23:27 --> Controller Class Initialized
DEBUG - 2026-03-15 16:23:27 --> Service_product MX_Controller Initialized
INFO - 2026-03-15 16:23:27 --> Model "Loginattempt_model" initialized
INFO - 2026-03-15 16:23:27 --> Model "Adminauth_model" initialized
INFO - 2026-03-15 16:23:27 --> Model "Serviceproduct_model" initialized
INFO - 2026-03-15 16:23:27 --> Model "Common_model" initialized
DEBUG - 2026-03-15 16:23:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-03-15 16:23:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-03-15 16:23:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-03-15 16:23:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-03-15 16:23:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-03-15 16:23:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_manage.php
INFO - 2026-03-15 16:23:32 --> Final output sent to browser
DEBUG - 2026-03-15 16:23:32 --> Total execution time: 6.8621
INFO - 2026-03-15 16:23:33 --> Config Class Initialized
INFO - 2026-03-15 16:23:33 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:23:33 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:23:33 --> Utf8 Class Initialized
INFO - 2026-03-15 16:23:33 --> URI Class Initialized
INFO - 2026-03-15 16:23:33 --> Router Class Initialized
INFO - 2026-03-15 16:23:33 --> Output Class Initialized
INFO - 2026-03-15 16:23:33 --> Security Class Initialized
DEBUG - 2026-03-15 16:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:23:33 --> CSRF cookie sent
INFO - 2026-03-15 16:23:33 --> Input Class Initialized
INFO - 2026-03-15 16:23:33 --> Language Class Initialized
INFO - 2026-03-15 16:23:33 --> Language Class Initialized
INFO - 2026-03-15 16:23:33 --> Config Class Initialized
INFO - 2026-03-15 16:23:33 --> Loader Class Initialized
INFO - 2026-03-15 16:23:33 --> Helper loaded: url_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: form_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: html_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: file_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: email_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:23:33 --> Database Driver Class Initialized
INFO - 2026-03-15 16:23:33 --> Config Class Initialized
INFO - 2026-03-15 16:23:33 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:23:33 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:23:33 --> Utf8 Class Initialized
INFO - 2026-03-15 16:23:33 --> URI Class Initialized
INFO - 2026-03-15 16:23:33 --> Router Class Initialized
INFO - 2026-03-15 16:23:33 --> Output Class Initialized
INFO - 2026-03-15 16:23:33 --> Security Class Initialized
DEBUG - 2026-03-15 16:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:23:33 --> CSRF cookie sent
INFO - 2026-03-15 16:23:33 --> Input Class Initialized
INFO - 2026-03-15 16:23:33 --> Language Class Initialized
INFO - 2026-03-15 16:23:33 --> Language Class Initialized
INFO - 2026-03-15 16:23:33 --> Config Class Initialized
INFO - 2026-03-15 16:23:33 --> Loader Class Initialized
INFO - 2026-03-15 16:23:33 --> Helper loaded: url_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: form_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: html_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: file_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: email_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:23:33 --> Database Driver Class Initialized
INFO - 2026-03-15 16:23:33 --> Config Class Initialized
INFO - 2026-03-15 16:23:33 --> Hooks Class Initialized
INFO - 2026-03-15 16:23:33 --> Config Class Initialized
INFO - 2026-03-15 16:23:33 --> Hooks Class Initialized
INFO - 2026-03-15 16:23:33 --> Config Class Initialized
INFO - 2026-03-15 16:23:33 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:23:33 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:23:33 --> Utf8 Class Initialized
INFO - 2026-03-15 16:23:33 --> URI Class Initialized
DEBUG - 2026-03-15 16:23:33 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:23:33 --> Utf8 Class Initialized
DEBUG - 2026-03-15 16:23:33 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:23:33 --> Utf8 Class Initialized
INFO - 2026-03-15 16:23:33 --> URI Class Initialized
INFO - 2026-03-15 16:23:33 --> URI Class Initialized
INFO - 2026-03-15 16:23:33 --> Router Class Initialized
INFO - 2026-03-15 16:23:33 --> Output Class Initialized
INFO - 2026-03-15 16:23:33 --> Router Class Initialized
INFO - 2026-03-15 16:23:33 --> Router Class Initialized
INFO - 2026-03-15 16:23:33 --> Security Class Initialized
DEBUG - 2026-03-15 16:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:23:33 --> CSRF cookie sent
INFO - 2026-03-15 16:23:33 --> Output Class Initialized
INFO - 2026-03-15 16:23:33 --> Input Class Initialized
INFO - 2026-03-15 16:23:33 --> Output Class Initialized
INFO - 2026-03-15 16:23:33 --> Language Class Initialized
INFO - 2026-03-15 16:23:33 --> Config Class Initialized
INFO - 2026-03-15 16:23:33 --> Hooks Class Initialized
INFO - 2026-03-15 16:23:33 --> Security Class Initialized
INFO - 2026-03-15 16:23:33 --> Language Class Initialized
INFO - 2026-03-15 16:23:33 --> Security Class Initialized
INFO - 2026-03-15 16:23:33 --> Config Class Initialized
DEBUG - 2026-03-15 16:23:33 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:23:33 --> Utf8 Class Initialized
DEBUG - 2026-03-15 16:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-03-15 16:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:23:33 --> CSRF cookie sent
INFO - 2026-03-15 16:23:33 --> CSRF cookie sent
INFO - 2026-03-15 16:23:33 --> Input Class Initialized
INFO - 2026-03-15 16:23:33 --> Input Class Initialized
INFO - 2026-03-15 16:23:33 --> URI Class Initialized
INFO - 2026-03-15 16:23:33 --> Language Class Initialized
INFO - 2026-03-15 16:23:33 --> Language Class Initialized
INFO - 2026-03-15 16:23:33 --> Language Class Initialized
INFO - 2026-03-15 16:23:33 --> Language Class Initialized
INFO - 2026-03-15 16:23:33 --> Config Class Initialized
INFO - 2026-03-15 16:23:33 --> Config Class Initialized
INFO - 2026-03-15 16:23:33 --> Loader Class Initialized
INFO - 2026-03-15 16:23:33 --> Router Class Initialized
INFO - 2026-03-15 16:23:33 --> Helper loaded: url_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: form_helper
INFO - 2026-03-15 16:23:33 --> Output Class Initialized
INFO - 2026-03-15 16:23:33 --> Helper loaded: html_helper
INFO - 2026-03-15 16:23:33 --> Loader Class Initialized
INFO - 2026-03-15 16:23:33 --> Loader Class Initialized
INFO - 2026-03-15 16:23:33 --> Helper loaded: file_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: email_helper
INFO - 2026-03-15 16:23:33 --> Security Class Initialized
INFO - 2026-03-15 16:23:33 --> Helper loaded: url_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: url_helper
DEBUG - 2026-03-15 16:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:23:33 --> CSRF cookie sent
INFO - 2026-03-15 16:23:33 --> Input Class Initialized
INFO - 2026-03-15 16:23:33 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: form_helper
INFO - 2026-03-15 16:23:33 --> Language Class Initialized
INFO - 2026-03-15 16:23:33 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: form_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: html_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: html_helper
INFO - 2026-03-15 16:23:33 --> Language Class Initialized
INFO - 2026-03-15 16:23:33 --> Config Class Initialized
INFO - 2026-03-15 16:23:33 --> Helper loaded: file_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: email_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: file_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: email_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:23:33 --> Loader Class Initialized
INFO - 2026-03-15 16:23:33 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: url_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: form_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: html_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: file_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: email_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:23:33 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:23:33 --> Database Driver Class Initialized
INFO - 2026-03-15 16:23:33 --> Database Driver Class Initialized
INFO - 2026-03-15 16:23:33 --> Database Driver Class Initialized
INFO - 2026-03-15 16:23:33 --> Database Driver Class Initialized
INFO - 2026-03-15 16:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:23:34 --> Upload Class Initialized
DEBUG - 2026-03-15 16:23:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:23:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:23:34 --> Encryption Class Initialized
INFO - 2026-03-15 16:23:34 --> Form Validation Class Initialized
INFO - 2026-03-15 16:23:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:23:34 --> Pagination Class Initialized
INFO - 2026-03-15 16:23:35 --> Email Class Initialized
INFO - 2026-03-15 16:23:35 --> Controller Class Initialized
ERROR - 2026-03-15 16:23:35 --> 404 Page Not Found: /index
INFO - 2026-03-15 16:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:23:35 --> Upload Class Initialized
DEBUG - 2026-03-15 16:23:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:23:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:23:35 --> Encryption Class Initialized
INFO - 2026-03-15 16:23:35 --> Form Validation Class Initialized
INFO - 2026-03-15 16:23:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:23:35 --> Pagination Class Initialized
INFO - 2026-03-15 16:23:35 --> Email Class Initialized
INFO - 2026-03-15 16:23:35 --> Controller Class Initialized
ERROR - 2026-03-15 16:23:35 --> 404 Page Not Found: /index
INFO - 2026-03-15 16:23:35 --> Config Class Initialized
INFO - 2026-03-15 16:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:23:35 --> Hooks Class Initialized
DEBUG - 2026-03-15 16:23:35 --> UTF-8 Support Enabled
INFO - 2026-03-15 16:23:35 --> Utf8 Class Initialized
INFO - 2026-03-15 16:23:35 --> URI Class Initialized
INFO - 2026-03-15 16:23:35 --> Upload Class Initialized
DEBUG - 2026-03-15 16:23:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:23:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:23:35 --> Encryption Class Initialized
INFO - 2026-03-15 16:23:35 --> Router Class Initialized
INFO - 2026-03-15 16:23:35 --> Output Class Initialized
INFO - 2026-03-15 16:23:35 --> Form Validation Class Initialized
INFO - 2026-03-15 16:23:35 --> Security Class Initialized
DEBUG - 2026-03-15 16:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-03-15 16:23:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:23:35 --> CSRF cookie sent
INFO - 2026-03-15 16:23:35 --> Input Class Initialized
INFO - 2026-03-15 16:23:35 --> Pagination Class Initialized
INFO - 2026-03-15 16:23:35 --> Language Class Initialized
INFO - 2026-03-15 16:23:35 --> Language Class Initialized
INFO - 2026-03-15 16:23:35 --> Config Class Initialized
INFO - 2026-03-15 16:23:35 --> Email Class Initialized
INFO - 2026-03-15 16:23:35 --> Controller Class Initialized
INFO - 2026-03-15 16:23:35 --> Loader Class Initialized
ERROR - 2026-03-15 16:23:35 --> 404 Page Not Found: /index
INFO - 2026-03-15 16:23:35 --> Helper loaded: url_helper
INFO - 2026-03-15 16:23:35 --> Helper loaded: form_helper
INFO - 2026-03-15 16:23:35 --> Helper loaded: html_helper
INFO - 2026-03-15 16:23:35 --> Helper loaded: file_helper
INFO - 2026-03-15 16:23:35 --> Helper loaded: email_helper
INFO - 2026-03-15 16:23:35 --> Helper loaded: whmaz_helper
INFO - 2026-03-15 16:23:35 --> Helper loaded: ssp_helper
INFO - 2026-03-15 16:23:35 --> Helper loaded: cpanel_helper
INFO - 2026-03-15 16:23:35 --> Helper loaded: domain_helper
INFO - 2026-03-15 16:23:35 --> Database Driver Class Initialized
INFO - 2026-03-15 16:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:23:35 --> Upload Class Initialized
DEBUG - 2026-03-15 16:23:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:23:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:23:35 --> Encryption Class Initialized
INFO - 2026-03-15 16:23:35 --> Form Validation Class Initialized
INFO - 2026-03-15 16:23:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:23:35 --> Pagination Class Initialized
INFO - 2026-03-15 16:23:35 --> Email Class Initialized
INFO - 2026-03-15 16:23:35 --> Controller Class Initialized
ERROR - 2026-03-15 16:23:35 --> 404 Page Not Found: /index
INFO - 2026-03-15 16:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:23:35 --> Upload Class Initialized
DEBUG - 2026-03-15 16:23:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:23:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:23:35 --> Encryption Class Initialized
INFO - 2026-03-15 16:23:35 --> Form Validation Class Initialized
INFO - 2026-03-15 16:23:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:23:35 --> Pagination Class Initialized
INFO - 2026-03-15 16:23:35 --> Email Class Initialized
INFO - 2026-03-15 16:23:35 --> Controller Class Initialized
ERROR - 2026-03-15 16:23:35 --> 404 Page Not Found: /index
INFO - 2026-03-15 16:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:23:36 --> Upload Class Initialized
DEBUG - 2026-03-15 16:23:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:23:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:23:36 --> Encryption Class Initialized
INFO - 2026-03-15 16:23:36 --> Form Validation Class Initialized
INFO - 2026-03-15 16:23:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:23:36 --> Pagination Class Initialized
INFO - 2026-03-15 16:23:36 --> Email Class Initialized
INFO - 2026-03-15 16:23:36 --> Controller Class Initialized
ERROR - 2026-03-15 16:23:36 --> 404 Page Not Found: /index
INFO - 2026-03-15 16:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-03-15 16:23:37 --> Upload Class Initialized
DEBUG - 2026-03-15 16:23:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-03-15 16:23:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-03-15 16:23:37 --> Encryption Class Initialized
INFO - 2026-03-15 16:23:37 --> Form Validation Class Initialized
INFO - 2026-03-15 16:23:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-03-15 16:23:37 --> Pagination Class Initialized
INFO - 2026-03-15 16:23:37 --> Email Class Initialized
INFO - 2026-03-15 16:23:37 --> Controller Class Initialized
ERROR - 2026-03-15 16:23:37 --> 404 Page Not Found: /index

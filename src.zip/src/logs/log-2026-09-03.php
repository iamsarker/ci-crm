<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-09-03 13:14:59 --> Config Class Initialized
INFO - 2026-09-03 13:14:59 --> Hooks Class Initialized
DEBUG - 2026-09-03 13:14:59 --> UTF-8 Support Enabled
INFO - 2026-09-03 13:14:59 --> Utf8 Class Initialized
INFO - 2026-09-03 13:14:59 --> URI Class Initialized
INFO - 2026-09-03 13:14:59 --> Router Class Initialized
INFO - 2026-09-03 13:14:59 --> Output Class Initialized
INFO - 2026-09-03 13:14:59 --> Security Class Initialized
DEBUG - 2026-09-03 13:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-03 13:14:59 --> Input Class Initialized
INFO - 2026-09-03 13:14:59 --> Language Class Initialized
INFO - 2026-09-03 13:14:59 --> Language Class Initialized
INFO - 2026-09-03 13:14:59 --> Config Class Initialized
INFO - 2026-09-03 13:14:59 --> Loader Class Initialized
INFO - 2026-09-03 13:14:59 --> Helper loaded: url_helper
INFO - 2026-09-03 13:14:59 --> Helper loaded: form_helper
INFO - 2026-09-03 13:14:59 --> Helper loaded: html_helper
INFO - 2026-09-03 13:14:59 --> Helper loaded: file_helper
INFO - 2026-09-03 13:14:59 --> Helper loaded: email_helper
INFO - 2026-09-03 13:14:59 --> Helper loaded: whmaz_helper
INFO - 2026-09-03 13:14:59 --> Helper loaded: ssp_helper
INFO - 2026-09-03 13:14:59 --> Helper loaded: cpanel_helper
INFO - 2026-09-03 13:14:59 --> Helper loaded: plesk_helper
INFO - 2026-09-03 13:14:59 --> Helper loaded: directadmin_helper
INFO - 2026-09-03 13:14:59 --> Helper loaded: domain_helper
INFO - 2026-09-03 13:14:59 --> Helper loaded: entitlement_helper
INFO - 2026-09-03 13:14:59 --> Helper loaded: tenant_helper
INFO - 2026-09-03 13:14:59 --> Database Driver Class Initialized
DEBUG - 2026-09-03 13:15:01 --> Session: Initialization under CLI aborted.
INFO - 2026-09-03 13:15:01 --> Upload Class Initialized
ERROR - 2026-09-03 13:15:01 --> Severity: 8192 --> CI_Encryption::encrypt(): Implicitly marking parameter $params as nullable is deprecated, the explicit nullable type must be used instead /opt/lampp/htdocs/ci-crm/whmaz/libraries/Encryption.php 371
ERROR - 2026-09-03 13:15:01 --> Severity: 8192 --> CI_Encryption::decrypt(): Implicitly marking parameter $params as nullable is deprecated, the explicit nullable type must be used instead /opt/lampp/htdocs/ci-crm/whmaz/libraries/Encryption.php 506
DEBUG - 2026-09-03 13:15:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-03 13:15:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-03 13:15:01 --> Encryption Class Initialized
INFO - 2026-09-03 13:15:01 --> Form Validation Class Initialized
INFO - 2026-09-03 13:15:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-03 13:15:01 --> Pagination Class Initialized
INFO - 2026-09-03 13:15:01 --> Email Class Initialized
INFO - 2026-09-03 13:15:01 --> Controller Class Initialized
DEBUG - 2026-09-03 13:15:01 --> Pricingcheck MX_Controller Initialized
INFO - 2026-09-03 13:15:01 --> Model "Loginattempt_model" initialized
INFO - 2026-09-03 13:15:01 --> Model "Adminauth_model" initialized
ERROR - 2026-09-03 13:15:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /opt/lampp/htdocs/ci-crm/whmaz/core/Exceptions.php:75) /opt/lampp/htdocs/ci-crm/src/core/WHMAZADMIN_Controller.php 154
ERROR - 2026-09-03 13:15:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /opt/lampp/htdocs/ci-crm/whmaz/core/Exceptions.php:75) /opt/lampp/htdocs/ci-crm/src/core/WHMAZADMIN_Controller.php 155
INFO - 2026-09-03 13:15:01 --> Model "Pricing_model" initialized
INFO - 2026-09-03 13:15:03 --> Final output sent to browser
DEBUG - 2026-09-03 13:15:03 --> Total execution time: 4.4321
INFO - 2026-09-03 13:21:19 --> Config Class Initialized
INFO - 2026-09-03 13:21:19 --> Hooks Class Initialized
DEBUG - 2026-09-03 13:21:19 --> UTF-8 Support Enabled
INFO - 2026-09-03 13:21:19 --> Utf8 Class Initialized
INFO - 2026-09-03 13:21:19 --> URI Class Initialized
INFO - 2026-09-03 13:21:19 --> Router Class Initialized
INFO - 2026-09-03 13:21:19 --> Output Class Initialized
INFO - 2026-09-03 13:21:19 --> Security Class Initialized
DEBUG - 2026-09-03 13:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-03 13:21:19 --> Input Class Initialized
INFO - 2026-09-03 13:21:19 --> Language Class Initialized
INFO - 2026-09-03 13:21:19 --> Language Class Initialized
INFO - 2026-09-03 13:21:19 --> Config Class Initialized
INFO - 2026-09-03 13:21:19 --> Loader Class Initialized
INFO - 2026-09-03 13:21:19 --> Helper loaded: url_helper
INFO - 2026-09-03 13:21:19 --> Helper loaded: form_helper
INFO - 2026-09-03 13:21:19 --> Helper loaded: html_helper
INFO - 2026-09-03 13:21:19 --> Helper loaded: file_helper
INFO - 2026-09-03 13:21:19 --> Helper loaded: email_helper
INFO - 2026-09-03 13:21:19 --> Helper loaded: whmaz_helper
INFO - 2026-09-03 13:21:19 --> Helper loaded: ssp_helper
INFO - 2026-09-03 13:21:19 --> Helper loaded: cpanel_helper
INFO - 2026-09-03 13:21:19 --> Helper loaded: plesk_helper
INFO - 2026-09-03 13:21:19 --> Helper loaded: directadmin_helper
INFO - 2026-09-03 13:21:19 --> Helper loaded: domain_helper
INFO - 2026-09-03 13:21:19 --> Helper loaded: entitlement_helper
INFO - 2026-09-03 13:21:19 --> Helper loaded: tenant_helper
INFO - 2026-09-03 13:21:19 --> Database Driver Class Initialized
DEBUG - 2026-09-03 13:21:21 --> Session: Initialization under CLI aborted.
INFO - 2026-09-03 13:21:21 --> Upload Class Initialized
ERROR - 2026-09-03 13:21:21 --> Severity: 8192 --> CI_Encryption::encrypt(): Implicitly marking parameter $params as nullable is deprecated, the explicit nullable type must be used instead /opt/lampp/htdocs/ci-crm/whmaz/libraries/Encryption.php 371
ERROR - 2026-09-03 13:21:21 --> Severity: 8192 --> CI_Encryption::decrypt(): Implicitly marking parameter $params as nullable is deprecated, the explicit nullable type must be used instead /opt/lampp/htdocs/ci-crm/whmaz/libraries/Encryption.php 506
DEBUG - 2026-09-03 13:21:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-03 13:21:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-03 13:21:21 --> Encryption Class Initialized
INFO - 2026-09-03 13:21:21 --> Form Validation Class Initialized
INFO - 2026-09-03 13:21:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-03 13:21:21 --> Pagination Class Initialized
INFO - 2026-09-03 13:21:21 --> Email Class Initialized
INFO - 2026-09-03 13:21:21 --> Controller Class Initialized
DEBUG - 2026-09-03 13:21:21 --> Pricingcheck MX_Controller Initialized
INFO - 2026-09-03 13:21:21 --> Model "Loginattempt_model" initialized
INFO - 2026-09-03 13:21:21 --> Model "Adminauth_model" initialized
ERROR - 2026-09-03 13:21:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /opt/lampp/htdocs/ci-crm/whmaz/core/Exceptions.php:75) /opt/lampp/htdocs/ci-crm/src/core/WHMAZADMIN_Controller.php 154
ERROR - 2026-09-03 13:21:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /opt/lampp/htdocs/ci-crm/whmaz/core/Exceptions.php:75) /opt/lampp/htdocs/ci-crm/src/core/WHMAZADMIN_Controller.php 155
INFO - 2026-09-03 13:21:21 --> Model "Pricing_model" initialized
INFO - 2026-09-03 13:22:13 --> Final output sent to browser
DEBUG - 2026-09-03 13:22:13 --> Total execution time: 54.4493
INFO - 2026-09-03 16:46:45 --> Config Class Initialized
INFO - 2026-09-03 16:46:45 --> Hooks Class Initialized
DEBUG - 2026-09-03 16:46:45 --> UTF-8 Support Enabled
INFO - 2026-09-03 16:46:45 --> Utf8 Class Initialized
INFO - 2026-09-03 16:46:45 --> URI Class Initialized
INFO - 2026-09-03 16:46:45 --> Router Class Initialized
INFO - 2026-09-03 16:46:45 --> Output Class Initialized
INFO - 2026-09-03 16:46:45 --> Security Class Initialized
DEBUG - 2026-09-03 16:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-03 16:46:45 --> Input Class Initialized
INFO - 2026-09-03 16:46:45 --> Language Class Initialized
INFO - 2026-09-03 16:46:45 --> Language Class Initialized
INFO - 2026-09-03 16:46:45 --> Config Class Initialized
INFO - 2026-09-03 16:46:45 --> Loader Class Initialized
INFO - 2026-09-03 16:46:45 --> Helper loaded: url_helper
INFO - 2026-09-03 16:46:45 --> Helper loaded: form_helper
INFO - 2026-09-03 16:46:45 --> Helper loaded: html_helper
INFO - 2026-09-03 16:46:45 --> Helper loaded: file_helper
INFO - 2026-09-03 16:46:45 --> Helper loaded: email_helper
INFO - 2026-09-03 16:46:45 --> Helper loaded: whmaz_helper
INFO - 2026-09-03 16:46:45 --> Helper loaded: ssp_helper
INFO - 2026-09-03 16:46:45 --> Helper loaded: cpanel_helper
INFO - 2026-09-03 16:46:45 --> Helper loaded: plesk_helper
INFO - 2026-09-03 16:46:45 --> Helper loaded: directadmin_helper
INFO - 2026-09-03 16:46:45 --> Helper loaded: domain_helper
INFO - 2026-09-03 16:46:45 --> Helper loaded: entitlement_helper
INFO - 2026-09-03 16:46:45 --> Helper loaded: tenant_helper
INFO - 2026-09-03 16:46:45 --> Database Driver Class Initialized
DEBUG - 2026-09-03 16:46:46 --> Session: Initialization under CLI aborted.
INFO - 2026-09-03 16:46:46 --> Upload Class Initialized
ERROR - 2026-09-03 16:46:46 --> Severity: 8192 --> CI_Encryption::encrypt(): Implicitly marking parameter $params as nullable is deprecated, the explicit nullable type must be used instead /opt/lampp/htdocs/ci-crm/whmaz/libraries/Encryption.php 371
ERROR - 2026-09-03 16:46:46 --> Severity: 8192 --> CI_Encryption::decrypt(): Implicitly marking parameter $params as nullable is deprecated, the explicit nullable type must be used instead /opt/lampp/htdocs/ci-crm/whmaz/libraries/Encryption.php 506
DEBUG - 2026-09-03 16:46:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-03 16:46:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-03 16:46:46 --> Encryption Class Initialized
INFO - 2026-09-03 16:46:46 --> Form Validation Class Initialized
INFO - 2026-09-03 16:46:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-03 16:46:46 --> Pagination Class Initialized
INFO - 2026-09-03 16:46:46 --> Email Class Initialized
INFO - 2026-09-03 16:46:46 --> Controller Class Initialized
DEBUG - 2026-09-03 16:46:46 --> Pricingcheck MX_Controller Initialized
INFO - 2026-09-03 16:46:46 --> Model "Loginattempt_model" initialized
INFO - 2026-09-03 16:46:46 --> Model "Adminauth_model" initialized
ERROR - 2026-09-03 16:46:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /opt/lampp/htdocs/ci-crm/whmaz/core/Exceptions.php:75) /opt/lampp/htdocs/ci-crm/src/core/WHMAZADMIN_Controller.php 154
ERROR - 2026-09-03 16:46:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /opt/lampp/htdocs/ci-crm/whmaz/core/Exceptions.php:75) /opt/lampp/htdocs/ci-crm/src/core/WHMAZADMIN_Controller.php 155
INFO - 2026-09-03 16:46:46 --> Model "Pricing_model" initialized
INFO - 2026-09-03 16:51:39 --> Config Class Initialized
INFO - 2026-09-03 16:51:39 --> Hooks Class Initialized
DEBUG - 2026-09-03 16:51:39 --> UTF-8 Support Enabled
INFO - 2026-09-03 16:51:39 --> Utf8 Class Initialized
INFO - 2026-09-03 16:51:39 --> URI Class Initialized
INFO - 2026-09-03 16:51:39 --> Router Class Initialized
INFO - 2026-09-03 16:51:39 --> Output Class Initialized
INFO - 2026-09-03 16:51:39 --> Security Class Initialized
DEBUG - 2026-09-03 16:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-03 16:51:39 --> Input Class Initialized
INFO - 2026-09-03 16:51:39 --> Language Class Initialized
INFO - 2026-09-03 16:51:39 --> Language Class Initialized
INFO - 2026-09-03 16:51:39 --> Config Class Initialized
INFO - 2026-09-03 16:51:39 --> Loader Class Initialized
INFO - 2026-09-03 16:51:39 --> Helper loaded: url_helper
INFO - 2026-09-03 16:51:39 --> Helper loaded: form_helper
INFO - 2026-09-03 16:51:39 --> Helper loaded: html_helper
INFO - 2026-09-03 16:51:39 --> Helper loaded: file_helper
INFO - 2026-09-03 16:51:39 --> Helper loaded: email_helper
INFO - 2026-09-03 16:51:39 --> Helper loaded: whmaz_helper
INFO - 2026-09-03 16:51:39 --> Helper loaded: ssp_helper
INFO - 2026-09-03 16:51:39 --> Helper loaded: cpanel_helper
INFO - 2026-09-03 16:51:39 --> Helper loaded: plesk_helper
INFO - 2026-09-03 16:51:39 --> Helper loaded: directadmin_helper
INFO - 2026-09-03 16:51:39 --> Helper loaded: domain_helper
INFO - 2026-09-03 16:51:39 --> Helper loaded: entitlement_helper
INFO - 2026-09-03 16:51:39 --> Helper loaded: tenant_helper
INFO - 2026-09-03 16:51:39 --> Database Driver Class Initialized
DEBUG - 2026-09-03 16:51:41 --> Session: Initialization under CLI aborted.
INFO - 2026-09-03 16:51:41 --> Upload Class Initialized
ERROR - 2026-09-03 16:51:41 --> Severity: 8192 --> CI_Encryption::encrypt(): Implicitly marking parameter $params as nullable is deprecated, the explicit nullable type must be used instead /opt/lampp/htdocs/ci-crm/whmaz/libraries/Encryption.php 371
ERROR - 2026-09-03 16:51:41 --> Severity: 8192 --> CI_Encryption::decrypt(): Implicitly marking parameter $params as nullable is deprecated, the explicit nullable type must be used instead /opt/lampp/htdocs/ci-crm/whmaz/libraries/Encryption.php 506
DEBUG - 2026-09-03 16:51:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-03 16:51:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-03 16:51:41 --> Encryption Class Initialized
INFO - 2026-09-03 16:51:41 --> Form Validation Class Initialized
INFO - 2026-09-03 16:51:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-03 16:51:41 --> Pagination Class Initialized
INFO - 2026-09-03 16:51:41 --> Email Class Initialized
INFO - 2026-09-03 16:51:41 --> Controller Class Initialized
DEBUG - 2026-09-03 16:51:41 --> Pricingcheck MX_Controller Initialized
INFO - 2026-09-03 16:51:41 --> Model "Loginattempt_model" initialized
INFO - 2026-09-03 16:51:41 --> Model "Adminauth_model" initialized
ERROR - 2026-09-03 16:51:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /opt/lampp/htdocs/ci-crm/whmaz/core/Exceptions.php:75) /opt/lampp/htdocs/ci-crm/src/core/WHMAZADMIN_Controller.php 154
ERROR - 2026-09-03 16:51:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /opt/lampp/htdocs/ci-crm/whmaz/core/Exceptions.php:75) /opt/lampp/htdocs/ci-crm/src/core/WHMAZADMIN_Controller.php 155
INFO - 2026-09-03 16:51:41 --> Model "Pricing_model" initialized
INFO - 2026-09-03 16:54:09 --> Config Class Initialized
INFO - 2026-09-03 16:54:09 --> Hooks Class Initialized
DEBUG - 2026-09-03 16:54:09 --> UTF-8 Support Enabled
INFO - 2026-09-03 16:54:09 --> Utf8 Class Initialized
INFO - 2026-09-03 16:54:09 --> URI Class Initialized
INFO - 2026-09-03 16:54:09 --> Router Class Initialized
INFO - 2026-09-03 16:54:09 --> Output Class Initialized
INFO - 2026-09-03 16:54:09 --> Security Class Initialized
DEBUG - 2026-09-03 16:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-03 16:54:09 --> Input Class Initialized
INFO - 2026-09-03 16:54:09 --> Language Class Initialized
INFO - 2026-09-03 16:54:09 --> Language Class Initialized
INFO - 2026-09-03 16:54:09 --> Config Class Initialized
INFO - 2026-09-03 16:54:09 --> Loader Class Initialized
INFO - 2026-09-03 16:54:09 --> Helper loaded: url_helper
INFO - 2026-09-03 16:54:09 --> Helper loaded: form_helper
INFO - 2026-09-03 16:54:09 --> Helper loaded: html_helper
INFO - 2026-09-03 16:54:09 --> Helper loaded: file_helper
INFO - 2026-09-03 16:54:09 --> Helper loaded: email_helper
INFO - 2026-09-03 16:54:09 --> Helper loaded: whmaz_helper
INFO - 2026-09-03 16:54:09 --> Helper loaded: ssp_helper
INFO - 2026-09-03 16:54:09 --> Helper loaded: cpanel_helper
INFO - 2026-09-03 16:54:09 --> Helper loaded: plesk_helper
INFO - 2026-09-03 16:54:09 --> Helper loaded: directadmin_helper
INFO - 2026-09-03 16:54:09 --> Helper loaded: domain_helper
INFO - 2026-09-03 16:54:09 --> Helper loaded: entitlement_helper
INFO - 2026-09-03 16:54:09 --> Helper loaded: tenant_helper
INFO - 2026-09-03 16:54:09 --> Database Driver Class Initialized
DEBUG - 2026-09-03 16:54:12 --> Session: Initialization under CLI aborted.
INFO - 2026-09-03 16:54:12 --> Upload Class Initialized
ERROR - 2026-09-03 16:54:12 --> Severity: 8192 --> CI_Encryption::encrypt(): Implicitly marking parameter $params as nullable is deprecated, the explicit nullable type must be used instead /opt/lampp/htdocs/ci-crm/whmaz/libraries/Encryption.php 371
ERROR - 2026-09-03 16:54:12 --> Severity: 8192 --> CI_Encryption::decrypt(): Implicitly marking parameter $params as nullable is deprecated, the explicit nullable type must be used instead /opt/lampp/htdocs/ci-crm/whmaz/libraries/Encryption.php 506
DEBUG - 2026-09-03 16:54:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-03 16:54:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-03 16:54:12 --> Encryption Class Initialized
INFO - 2026-09-03 16:54:12 --> Form Validation Class Initialized
INFO - 2026-09-03 16:54:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-03 16:54:12 --> Pagination Class Initialized
INFO - 2026-09-03 16:54:12 --> Email Class Initialized
INFO - 2026-09-03 16:54:12 --> Controller Class Initialized
DEBUG - 2026-09-03 16:54:12 --> Pricingcheck MX_Controller Initialized
INFO - 2026-09-03 16:54:12 --> Model "Loginattempt_model" initialized
INFO - 2026-09-03 16:54:12 --> Model "Adminauth_model" initialized
ERROR - 2026-09-03 16:54:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /opt/lampp/htdocs/ci-crm/whmaz/core/Exceptions.php:75) /opt/lampp/htdocs/ci-crm/src/core/WHMAZADMIN_Controller.php 154
ERROR - 2026-09-03 16:54:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /opt/lampp/htdocs/ci-crm/whmaz/core/Exceptions.php:75) /opt/lampp/htdocs/ci-crm/src/core/WHMAZADMIN_Controller.php 155
INFO - 2026-09-03 16:54:12 --> Model "Pricing_model" initialized
INFO - 2026-09-03 16:55:13 --> Config Class Initialized
INFO - 2026-09-03 16:55:13 --> Hooks Class Initialized
DEBUG - 2026-09-03 16:55:13 --> UTF-8 Support Enabled
INFO - 2026-09-03 16:55:13 --> Utf8 Class Initialized
INFO - 2026-09-03 16:55:13 --> URI Class Initialized
INFO - 2026-09-03 16:55:13 --> Router Class Initialized
INFO - 2026-09-03 16:55:13 --> Output Class Initialized
INFO - 2026-09-03 16:55:13 --> Security Class Initialized
DEBUG - 2026-09-03 16:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-03 16:55:13 --> Input Class Initialized
INFO - 2026-09-03 16:55:13 --> Language Class Initialized
INFO - 2026-09-03 16:55:13 --> Language Class Initialized
INFO - 2026-09-03 16:55:13 --> Config Class Initialized
INFO - 2026-09-03 16:55:13 --> Loader Class Initialized
INFO - 2026-09-03 16:55:13 --> Helper loaded: url_helper
INFO - 2026-09-03 16:55:13 --> Helper loaded: form_helper
INFO - 2026-09-03 16:55:13 --> Helper loaded: html_helper
INFO - 2026-09-03 16:55:13 --> Helper loaded: file_helper
INFO - 2026-09-03 16:55:13 --> Helper loaded: email_helper
INFO - 2026-09-03 16:55:13 --> Helper loaded: whmaz_helper
INFO - 2026-09-03 16:55:13 --> Helper loaded: ssp_helper
INFO - 2026-09-03 16:55:13 --> Helper loaded: cpanel_helper
INFO - 2026-09-03 16:55:13 --> Helper loaded: plesk_helper
INFO - 2026-09-03 16:55:13 --> Helper loaded: directadmin_helper
INFO - 2026-09-03 16:55:13 --> Helper loaded: domain_helper
INFO - 2026-09-03 16:55:13 --> Helper loaded: entitlement_helper
INFO - 2026-09-03 16:55:13 --> Helper loaded: tenant_helper
INFO - 2026-09-03 16:55:13 --> Database Driver Class Initialized
DEBUG - 2026-09-03 16:55:14 --> Session: Initialization under CLI aborted.
INFO - 2026-09-03 16:55:14 --> Upload Class Initialized
ERROR - 2026-09-03 16:55:14 --> Severity: 8192 --> CI_Encryption::encrypt(): Implicitly marking parameter $params as nullable is deprecated, the explicit nullable type must be used instead /opt/lampp/htdocs/ci-crm/whmaz/libraries/Encryption.php 371
ERROR - 2026-09-03 16:55:14 --> Severity: 8192 --> CI_Encryption::decrypt(): Implicitly marking parameter $params as nullable is deprecated, the explicit nullable type must be used instead /opt/lampp/htdocs/ci-crm/whmaz/libraries/Encryption.php 506
DEBUG - 2026-09-03 16:55:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-03 16:55:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-03 16:55:14 --> Encryption Class Initialized
INFO - 2026-09-03 16:55:14 --> Form Validation Class Initialized
INFO - 2026-09-03 16:55:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-03 16:55:14 --> Pagination Class Initialized
INFO - 2026-09-03 16:55:14 --> Email Class Initialized
INFO - 2026-09-03 16:55:14 --> Controller Class Initialized
DEBUG - 2026-09-03 16:55:14 --> Pricingcheck MX_Controller Initialized
INFO - 2026-09-03 16:55:14 --> Model "Loginattempt_model" initialized
INFO - 2026-09-03 16:55:14 --> Model "Adminauth_model" initialized
ERROR - 2026-09-03 16:55:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /opt/lampp/htdocs/ci-crm/whmaz/core/Exceptions.php:75) /opt/lampp/htdocs/ci-crm/src/core/WHMAZADMIN_Controller.php 154
ERROR - 2026-09-03 16:55:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /opt/lampp/htdocs/ci-crm/whmaz/core/Exceptions.php:75) /opt/lampp/htdocs/ci-crm/src/core/WHMAZADMIN_Controller.php 155
INFO - 2026-09-03 16:55:14 --> Model "Pricing_model" initialized
INFO - 2026-09-03 16:59:05 --> Config Class Initialized
INFO - 2026-09-03 16:59:05 --> Hooks Class Initialized
DEBUG - 2026-09-03 16:59:05 --> UTF-8 Support Enabled
INFO - 2026-09-03 16:59:05 --> Utf8 Class Initialized
INFO - 2026-09-03 16:59:05 --> URI Class Initialized
INFO - 2026-09-03 16:59:05 --> Router Class Initialized
INFO - 2026-09-03 16:59:05 --> Output Class Initialized
INFO - 2026-09-03 16:59:05 --> Security Class Initialized
DEBUG - 2026-09-03 16:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-03 16:59:05 --> Input Class Initialized
INFO - 2026-09-03 16:59:05 --> Language Class Initialized
INFO - 2026-09-03 16:59:05 --> Language Class Initialized
INFO - 2026-09-03 16:59:05 --> Config Class Initialized
INFO - 2026-09-03 16:59:05 --> Loader Class Initialized
INFO - 2026-09-03 16:59:05 --> Helper loaded: url_helper
INFO - 2026-09-03 16:59:05 --> Helper loaded: form_helper
INFO - 2026-09-03 16:59:05 --> Helper loaded: html_helper
INFO - 2026-09-03 16:59:05 --> Helper loaded: file_helper
INFO - 2026-09-03 16:59:05 --> Helper loaded: email_helper
INFO - 2026-09-03 16:59:05 --> Helper loaded: whmaz_helper
INFO - 2026-09-03 16:59:05 --> Helper loaded: ssp_helper
INFO - 2026-09-03 16:59:05 --> Helper loaded: cpanel_helper
INFO - 2026-09-03 16:59:05 --> Helper loaded: plesk_helper
INFO - 2026-09-03 16:59:05 --> Helper loaded: directadmin_helper
INFO - 2026-09-03 16:59:05 --> Helper loaded: domain_helper
INFO - 2026-09-03 16:59:05 --> Helper loaded: entitlement_helper
INFO - 2026-09-03 16:59:05 --> Helper loaded: tenant_helper
INFO - 2026-09-03 16:59:05 --> Database Driver Class Initialized
DEBUG - 2026-09-03 16:59:07 --> Session: Initialization under CLI aborted.
INFO - 2026-09-03 16:59:07 --> Upload Class Initialized
ERROR - 2026-09-03 16:59:07 --> Severity: 8192 --> CI_Encryption::encrypt(): Implicitly marking parameter $params as nullable is deprecated, the explicit nullable type must be used instead /opt/lampp/htdocs/ci-crm/whmaz/libraries/Encryption.php 371
ERROR - 2026-09-03 16:59:07 --> Severity: 8192 --> CI_Encryption::decrypt(): Implicitly marking parameter $params as nullable is deprecated, the explicit nullable type must be used instead /opt/lampp/htdocs/ci-crm/whmaz/libraries/Encryption.php 506
DEBUG - 2026-09-03 16:59:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-03 16:59:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-03 16:59:07 --> Encryption Class Initialized
INFO - 2026-09-03 16:59:07 --> Form Validation Class Initialized
INFO - 2026-09-03 16:59:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-03 16:59:07 --> Pagination Class Initialized
INFO - 2026-09-03 16:59:07 --> Email Class Initialized
INFO - 2026-09-03 16:59:07 --> Controller Class Initialized
DEBUG - 2026-09-03 16:59:07 --> Pricingcheck MX_Controller Initialized
INFO - 2026-09-03 16:59:07 --> Model "Loginattempt_model" initialized
INFO - 2026-09-03 16:59:07 --> Model "Adminauth_model" initialized
ERROR - 2026-09-03 16:59:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /opt/lampp/htdocs/ci-crm/whmaz/core/Exceptions.php:75) /opt/lampp/htdocs/ci-crm/src/core/WHMAZADMIN_Controller.php 154
ERROR - 2026-09-03 16:59:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /opt/lampp/htdocs/ci-crm/whmaz/core/Exceptions.php:75) /opt/lampp/htdocs/ci-crm/src/core/WHMAZADMIN_Controller.php 155
INFO - 2026-09-03 16:59:07 --> Model "Pricing_model" initialized
INFO - 2026-09-03 17:01:23 --> Config Class Initialized
INFO - 2026-09-03 17:01:23 --> Hooks Class Initialized
DEBUG - 2026-09-03 17:01:23 --> UTF-8 Support Enabled
INFO - 2026-09-03 17:01:23 --> Utf8 Class Initialized
INFO - 2026-09-03 17:01:23 --> URI Class Initialized
INFO - 2026-09-03 17:01:23 --> Router Class Initialized
INFO - 2026-09-03 17:01:23 --> Output Class Initialized
INFO - 2026-09-03 17:01:23 --> Security Class Initialized
DEBUG - 2026-09-03 17:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-03 17:01:23 --> Input Class Initialized
INFO - 2026-09-03 17:01:23 --> Language Class Initialized
INFO - 2026-09-03 17:01:23 --> Language Class Initialized
INFO - 2026-09-03 17:01:23 --> Config Class Initialized
INFO - 2026-09-03 17:01:23 --> Loader Class Initialized
INFO - 2026-09-03 17:01:23 --> Helper loaded: url_helper
INFO - 2026-09-03 17:01:23 --> Helper loaded: form_helper
INFO - 2026-09-03 17:01:23 --> Helper loaded: html_helper
INFO - 2026-09-03 17:01:23 --> Helper loaded: file_helper
INFO - 2026-09-03 17:01:23 --> Helper loaded: email_helper
INFO - 2026-09-03 17:01:23 --> Helper loaded: whmaz_helper
INFO - 2026-09-03 17:01:23 --> Helper loaded: ssp_helper
INFO - 2026-09-03 17:01:23 --> Helper loaded: cpanel_helper
INFO - 2026-09-03 17:01:23 --> Helper loaded: plesk_helper
INFO - 2026-09-03 17:01:23 --> Helper loaded: directadmin_helper
INFO - 2026-09-03 17:01:23 --> Helper loaded: domain_helper
INFO - 2026-09-03 17:01:23 --> Helper loaded: entitlement_helper
INFO - 2026-09-03 17:01:23 --> Helper loaded: tenant_helper
INFO - 2026-09-03 17:01:23 --> Database Driver Class Initialized
DEBUG - 2026-09-03 17:01:25 --> Session: Initialization under CLI aborted.
INFO - 2026-09-03 17:01:25 --> Upload Class Initialized
ERROR - 2026-09-03 17:01:25 --> Severity: 8192 --> CI_Encryption::encrypt(): Implicitly marking parameter $params as nullable is deprecated, the explicit nullable type must be used instead /opt/lampp/htdocs/ci-crm/whmaz/libraries/Encryption.php 371
ERROR - 2026-09-03 17:01:25 --> Severity: 8192 --> CI_Encryption::decrypt(): Implicitly marking parameter $params as nullable is deprecated, the explicit nullable type must be used instead /opt/lampp/htdocs/ci-crm/whmaz/libraries/Encryption.php 506
DEBUG - 2026-09-03 17:01:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-03 17:01:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-03 17:01:25 --> Encryption Class Initialized
INFO - 2026-09-03 17:01:25 --> Form Validation Class Initialized
INFO - 2026-09-03 17:01:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-03 17:01:25 --> Pagination Class Initialized
INFO - 2026-09-03 17:01:25 --> Email Class Initialized
INFO - 2026-09-03 17:01:25 --> Controller Class Initialized
DEBUG - 2026-09-03 17:01:25 --> Pricingcheck MX_Controller Initialized
INFO - 2026-09-03 17:01:25 --> Model "Loginattempt_model" initialized
INFO - 2026-09-03 17:01:25 --> Model "Adminauth_model" initialized
ERROR - 2026-09-03 17:01:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /opt/lampp/htdocs/ci-crm/whmaz/core/Exceptions.php:75) /opt/lampp/htdocs/ci-crm/src/core/WHMAZADMIN_Controller.php 154
ERROR - 2026-09-03 17:01:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /opt/lampp/htdocs/ci-crm/whmaz/core/Exceptions.php:75) /opt/lampp/htdocs/ci-crm/src/core/WHMAZADMIN_Controller.php 155
INFO - 2026-09-03 17:01:25 --> Model "Pricing_model" initialized
INFO - 2026-09-03 17:03:41 --> Final output sent to browser
DEBUG - 2026-09-03 17:03:41 --> Total execution time: 138.0961
INFO - 2026-09-03 17:05:22 --> Config Class Initialized
INFO - 2026-09-03 17:05:22 --> Hooks Class Initialized
DEBUG - 2026-09-03 17:05:22 --> UTF-8 Support Enabled
INFO - 2026-09-03 17:05:22 --> Utf8 Class Initialized
INFO - 2026-09-03 17:05:22 --> URI Class Initialized
INFO - 2026-09-03 17:05:22 --> Router Class Initialized
INFO - 2026-09-03 17:05:22 --> Output Class Initialized
INFO - 2026-09-03 17:05:22 --> Security Class Initialized
DEBUG - 2026-09-03 17:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-09-03 17:05:22 --> Input Class Initialized
INFO - 2026-09-03 17:05:22 --> Language Class Initialized
INFO - 2026-09-03 17:05:22 --> Language Class Initialized
INFO - 2026-09-03 17:05:22 --> Config Class Initialized
INFO - 2026-09-03 17:05:22 --> Loader Class Initialized
INFO - 2026-09-03 17:05:22 --> Helper loaded: url_helper
INFO - 2026-09-03 17:05:22 --> Helper loaded: form_helper
INFO - 2026-09-03 17:05:22 --> Helper loaded: html_helper
INFO - 2026-09-03 17:05:22 --> Helper loaded: file_helper
INFO - 2026-09-03 17:05:22 --> Helper loaded: email_helper
INFO - 2026-09-03 17:05:22 --> Helper loaded: whmaz_helper
INFO - 2026-09-03 17:05:22 --> Helper loaded: ssp_helper
INFO - 2026-09-03 17:05:22 --> Helper loaded: cpanel_helper
INFO - 2026-09-03 17:05:22 --> Helper loaded: plesk_helper
INFO - 2026-09-03 17:05:22 --> Helper loaded: directadmin_helper
INFO - 2026-09-03 17:05:22 --> Helper loaded: domain_helper
INFO - 2026-09-03 17:05:22 --> Helper loaded: entitlement_helper
INFO - 2026-09-03 17:05:22 --> Helper loaded: tenant_helper
INFO - 2026-09-03 17:05:22 --> Database Driver Class Initialized
DEBUG - 2026-09-03 17:05:24 --> Session: Initialization under CLI aborted.
INFO - 2026-09-03 17:05:24 --> Upload Class Initialized
ERROR - 2026-09-03 17:05:24 --> Severity: 8192 --> CI_Encryption::encrypt(): Implicitly marking parameter $params as nullable is deprecated, the explicit nullable type must be used instead /opt/lampp/htdocs/ci-crm/whmaz/libraries/Encryption.php 371
ERROR - 2026-09-03 17:05:24 --> Severity: 8192 --> CI_Encryption::decrypt(): Implicitly marking parameter $params as nullable is deprecated, the explicit nullable type must be used instead /opt/lampp/htdocs/ci-crm/whmaz/libraries/Encryption.php 506
DEBUG - 2026-09-03 17:05:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-09-03 17:05:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-09-03 17:05:24 --> Encryption Class Initialized
INFO - 2026-09-03 17:05:24 --> Form Validation Class Initialized
INFO - 2026-09-03 17:05:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-09-03 17:05:24 --> Pagination Class Initialized
INFO - 2026-09-03 17:05:24 --> Email Class Initialized
INFO - 2026-09-03 17:05:24 --> Controller Class Initialized
DEBUG - 2026-09-03 17:05:24 --> Pricingcheck MX_Controller Initialized
INFO - 2026-09-03 17:05:24 --> Model "Loginattempt_model" initialized
INFO - 2026-09-03 17:05:24 --> Model "Adminauth_model" initialized
ERROR - 2026-09-03 17:05:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /opt/lampp/htdocs/ci-crm/whmaz/core/Exceptions.php:75) /opt/lampp/htdocs/ci-crm/src/core/WHMAZADMIN_Controller.php 154
ERROR - 2026-09-03 17:05:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /opt/lampp/htdocs/ci-crm/whmaz/core/Exceptions.php:75) /opt/lampp/htdocs/ci-crm/src/core/WHMAZADMIN_Controller.php 155
INFO - 2026-09-03 17:05:24 --> Model "Pricing_model" initialized
INFO - 2026-09-03 17:07:47 --> Final output sent to browser
DEBUG - 2026-09-03 17:07:47 --> Total execution time: 144.5899

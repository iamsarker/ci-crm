<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-02-22 00:11:04 --> Config Class Initialized
INFO - 2026-02-22 00:11:04 --> Hooks Class Initialized
DEBUG - 2026-02-22 00:11:04 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:11:04 --> Utf8 Class Initialized
INFO - 2026-02-22 00:11:04 --> URI Class Initialized
INFO - 2026-02-22 00:11:04 --> Router Class Initialized
INFO - 2026-02-22 00:11:04 --> Output Class Initialized
INFO - 2026-02-22 00:11:04 --> Security Class Initialized
DEBUG - 2026-02-22 00:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:11:04 --> CSRF cookie sent
INFO - 2026-02-22 00:11:04 --> CSRF token verified
INFO - 2026-02-22 00:11:04 --> Input Class Initialized
INFO - 2026-02-22 00:11:04 --> Language Class Initialized
INFO - 2026-02-22 00:11:04 --> Language Class Initialized
INFO - 2026-02-22 00:11:04 --> Config Class Initialized
INFO - 2026-02-22 00:11:04 --> Loader Class Initialized
INFO - 2026-02-22 00:11:04 --> Helper loaded: url_helper
INFO - 2026-02-22 00:11:04 --> Helper loaded: form_helper
INFO - 2026-02-22 00:11:04 --> Helper loaded: html_helper
INFO - 2026-02-22 00:11:04 --> Helper loaded: file_helper
INFO - 2026-02-22 00:11:04 --> Helper loaded: email_helper
INFO - 2026-02-22 00:11:04 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:11:04 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:11:04 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:11:04 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:11:04 --> Database Driver Class Initialized
INFO - 2026-02-22 00:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:11:06 --> Upload Class Initialized
DEBUG - 2026-02-22 00:11:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:11:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:11:06 --> Encryption Class Initialized
INFO - 2026-02-22 00:11:06 --> Form Validation Class Initialized
INFO - 2026-02-22 00:11:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:11:06 --> Pagination Class Initialized
INFO - 2026-02-22 00:11:06 --> Email Class Initialized
INFO - 2026-02-22 00:11:06 --> Controller Class Initialized
DEBUG - 2026-02-22 00:11:06 --> Authenticate MX_Controller Initialized
INFO - 2026-02-22 00:11:06 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 00:11:06 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 00:11:06 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 00:11:09 --> Config Class Initialized
INFO - 2026-02-22 00:11:09 --> Hooks Class Initialized
DEBUG - 2026-02-22 00:11:09 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:11:09 --> Utf8 Class Initialized
INFO - 2026-02-22 00:11:09 --> URI Class Initialized
INFO - 2026-02-22 00:11:09 --> Router Class Initialized
INFO - 2026-02-22 00:11:09 --> Output Class Initialized
INFO - 2026-02-22 00:11:09 --> Security Class Initialized
DEBUG - 2026-02-22 00:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:11:09 --> CSRF cookie sent
INFO - 2026-02-22 00:11:09 --> Input Class Initialized
INFO - 2026-02-22 00:11:09 --> Language Class Initialized
INFO - 2026-02-22 00:11:09 --> Language Class Initialized
INFO - 2026-02-22 00:11:09 --> Config Class Initialized
INFO - 2026-02-22 00:11:09 --> Loader Class Initialized
INFO - 2026-02-22 00:11:09 --> Helper loaded: url_helper
INFO - 2026-02-22 00:11:09 --> Helper loaded: form_helper
INFO - 2026-02-22 00:11:09 --> Helper loaded: html_helper
INFO - 2026-02-22 00:11:09 --> Helper loaded: file_helper
INFO - 2026-02-22 00:11:09 --> Helper loaded: email_helper
INFO - 2026-02-22 00:11:09 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:11:09 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:11:09 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:11:09 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:11:09 --> Database Driver Class Initialized
INFO - 2026-02-22 00:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:11:11 --> Upload Class Initialized
DEBUG - 2026-02-22 00:11:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:11:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:11:11 --> Encryption Class Initialized
INFO - 2026-02-22 00:11:11 --> Form Validation Class Initialized
INFO - 2026-02-22 00:11:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:11:11 --> Pagination Class Initialized
INFO - 2026-02-22 00:11:11 --> Email Class Initialized
INFO - 2026-02-22 00:11:11 --> Controller Class Initialized
DEBUG - 2026-02-22 00:11:11 --> Dashboard MX_Controller Initialized
INFO - 2026-02-22 00:11:11 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 00:11:11 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 00:11:11 --> Model "Dashboard_model" initialized
DEBUG - 2026-02-22 00:11:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 00:11:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 00:11:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 00:11:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 00:11:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 00:11:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/dashboard_index.php
INFO - 2026-02-22 00:11:11 --> Final output sent to browser
DEBUG - 2026-02-22 00:11:11 --> Total execution time: 2.0001
INFO - 2026-02-22 00:11:11 --> Config Class Initialized
INFO - 2026-02-22 00:11:11 --> Hooks Class Initialized
DEBUG - 2026-02-22 00:11:11 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:11:11 --> Utf8 Class Initialized
INFO - 2026-02-22 00:11:11 --> URI Class Initialized
INFO - 2026-02-22 00:11:11 --> Router Class Initialized
INFO - 2026-02-22 00:11:11 --> Output Class Initialized
INFO - 2026-02-22 00:11:11 --> Security Class Initialized
DEBUG - 2026-02-22 00:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:11:11 --> Input Class Initialized
INFO - 2026-02-22 00:11:11 --> Language Class Initialized
INFO - 2026-02-22 00:11:11 --> Language Class Initialized
INFO - 2026-02-22 00:11:11 --> Config Class Initialized
INFO - 2026-02-22 00:11:11 --> Loader Class Initialized
INFO - 2026-02-22 00:11:11 --> Config Class Initialized
INFO - 2026-02-22 00:11:11 --> Hooks Class Initialized
INFO - 2026-02-22 00:11:11 --> Config Class Initialized
INFO - 2026-02-22 00:11:11 --> Hooks Class Initialized
INFO - 2026-02-22 00:11:11 --> Helper loaded: url_helper
INFO - 2026-02-22 00:11:11 --> Config Class Initialized
DEBUG - 2026-02-22 00:11:11 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:11:11 --> Hooks Class Initialized
INFO - 2026-02-22 00:11:11 --> Utf8 Class Initialized
INFO - 2026-02-22 00:11:11 --> Helper loaded: form_helper
INFO - 2026-02-22 00:11:11 --> URI Class Initialized
INFO - 2026-02-22 00:11:11 --> Helper loaded: html_helper
INFO - 2026-02-22 00:11:11 --> Config Class Initialized
INFO - 2026-02-22 00:11:11 --> Hooks Class Initialized
DEBUG - 2026-02-22 00:11:11 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:11:11 --> Utf8 Class Initialized
INFO - 2026-02-22 00:11:11 --> Helper loaded: file_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: email_helper
INFO - 2026-02-22 00:11:11 --> Config Class Initialized
INFO - 2026-02-22 00:11:11 --> Hooks Class Initialized
INFO - 2026-02-22 00:11:11 --> Router Class Initialized
INFO - 2026-02-22 00:11:11 --> URI Class Initialized
DEBUG - 2026-02-22 00:11:11 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:11:11 --> Utf8 Class Initialized
DEBUG - 2026-02-22 00:11:11 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:11:11 --> Utf8 Class Initialized
INFO - 2026-02-22 00:11:11 --> Output Class Initialized
INFO - 2026-02-22 00:11:11 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:11:11 --> URI Class Initialized
INFO - 2026-02-22 00:11:11 --> Router Class Initialized
INFO - 2026-02-22 00:11:11 --> Security Class Initialized
INFO - 2026-02-22 00:11:11 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:11:11 --> Router Class Initialized
DEBUG - 2026-02-22 00:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:11:11 --> Output Class Initialized
INFO - 2026-02-22 00:11:11 --> Input Class Initialized
INFO - 2026-02-22 00:11:11 --> Language Class Initialized
INFO - 2026-02-22 00:11:11 --> URI Class Initialized
DEBUG - 2026-02-22 00:11:11 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:11:11 --> Utf8 Class Initialized
INFO - 2026-02-22 00:11:11 --> Security Class Initialized
INFO - 2026-02-22 00:11:11 --> Language Class Initialized
INFO - 2026-02-22 00:11:11 --> Config Class Initialized
INFO - 2026-02-22 00:11:11 --> URI Class Initialized
DEBUG - 2026-02-22 00:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:11:11 --> Router Class Initialized
INFO - 2026-02-22 00:11:11 --> Input Class Initialized
INFO - 2026-02-22 00:11:11 --> Language Class Initialized
INFO - 2026-02-22 00:11:11 --> Router Class Initialized
INFO - 2026-02-22 00:11:11 --> Loader Class Initialized
INFO - 2026-02-22 00:11:11 --> Output Class Initialized
INFO - 2026-02-22 00:11:11 --> Language Class Initialized
INFO - 2026-02-22 00:11:11 --> Config Class Initialized
INFO - 2026-02-22 00:11:11 --> Output Class Initialized
INFO - 2026-02-22 00:11:11 --> Helper loaded: url_helper
INFO - 2026-02-22 00:11:11 --> Output Class Initialized
INFO - 2026-02-22 00:11:11 --> Security Class Initialized
INFO - 2026-02-22 00:11:11 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: form_helper
INFO - 2026-02-22 00:11:11 --> Security Class Initialized
INFO - 2026-02-22 00:11:11 --> Helper loaded: html_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: file_helper
INFO - 2026-02-22 00:11:11 --> Loader Class Initialized
INFO - 2026-02-22 00:11:11 --> Helper loaded: email_helper
INFO - 2026-02-22 00:11:11 --> Security Class Initialized
INFO - 2026-02-22 00:11:11 --> Helper loaded: url_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: ssp_helper
DEBUG - 2026-02-22 00:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:11:11 --> Input Class Initialized
INFO - 2026-02-22 00:11:11 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:11:11 --> Language Class Initialized
INFO - 2026-02-22 00:11:11 --> Language Class Initialized
INFO - 2026-02-22 00:11:11 --> Helper loaded: form_helper
DEBUG - 2026-02-22 00:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:11:11 --> Helper loaded: html_helper
INFO - 2026-02-22 00:11:11 --> Input Class Initialized
INFO - 2026-02-22 00:11:11 --> Language Class Initialized
INFO - 2026-02-22 00:11:11 --> Helper loaded: domain_helper
DEBUG - 2026-02-22 00:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:11:11 --> Helper loaded: file_helper
INFO - 2026-02-22 00:11:11 --> Database Driver Class Initialized
INFO - 2026-02-22 00:11:11 --> Input Class Initialized
INFO - 2026-02-22 00:11:11 --> Helper loaded: email_helper
INFO - 2026-02-22 00:11:11 --> Language Class Initialized
INFO - 2026-02-22 00:11:11 --> Language Class Initialized
INFO - 2026-02-22 00:11:11 --> Config Class Initialized
INFO - 2026-02-22 00:11:11 --> Language Class Initialized
INFO - 2026-02-22 00:11:11 --> Config Class Initialized
INFO - 2026-02-22 00:11:11 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:11:11 --> Loader Class Initialized
INFO - 2026-02-22 00:11:11 --> Loader Class Initialized
INFO - 2026-02-22 00:11:11 --> Helper loaded: url_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: url_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: form_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: html_helper
INFO - 2026-02-22 00:11:11 --> Config Class Initialized
INFO - 2026-02-22 00:11:11 --> Helper loaded: form_helper
INFO - 2026-02-22 00:11:11 --> Database Driver Class Initialized
INFO - 2026-02-22 00:11:11 --> Helper loaded: file_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: html_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: email_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: file_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: email_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:11:11 --> Loader Class Initialized
INFO - 2026-02-22 00:11:11 --> Helper loaded: url_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: form_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: html_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: file_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: email_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:11:11 --> Database Driver Class Initialized
INFO - 2026-02-22 00:11:11 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:11:11 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:11:11 --> Database Driver Class Initialized
INFO - 2026-02-22 00:11:11 --> Database Driver Class Initialized
INFO - 2026-02-22 00:11:11 --> Database Driver Class Initialized
INFO - 2026-02-22 00:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:11:13 --> Upload Class Initialized
DEBUG - 2026-02-22 00:11:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:11:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:11:13 --> Encryption Class Initialized
INFO - 2026-02-22 00:11:13 --> Form Validation Class Initialized
INFO - 2026-02-22 00:11:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:11:13 --> Pagination Class Initialized
INFO - 2026-02-22 00:11:13 --> Email Class Initialized
INFO - 2026-02-22 00:11:13 --> Controller Class Initialized
DEBUG - 2026-02-22 00:11:13 --> Dashboard MX_Controller Initialized
INFO - 2026-02-22 00:11:13 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 00:11:13 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 00:11:13 --> Model "Dashboard_model" initialized
INFO - 2026-02-22 00:11:14 --> Final output sent to browser
DEBUG - 2026-02-22 00:11:14 --> Total execution time: 2.3789
INFO - 2026-02-22 00:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:11:14 --> Upload Class Initialized
DEBUG - 2026-02-22 00:11:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:11:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:11:14 --> Encryption Class Initialized
INFO - 2026-02-22 00:11:14 --> Form Validation Class Initialized
INFO - 2026-02-22 00:11:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:11:14 --> Pagination Class Initialized
INFO - 2026-02-22 00:11:14 --> Email Class Initialized
INFO - 2026-02-22 00:11:14 --> Controller Class Initialized
DEBUG - 2026-02-22 00:11:14 --> Dashboard MX_Controller Initialized
INFO - 2026-02-22 00:11:14 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 00:11:14 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 00:11:14 --> Model "Dashboard_model" initialized
INFO - 2026-02-22 00:11:14 --> Final output sent to browser
DEBUG - 2026-02-22 00:11:14 --> Total execution time: 3.1347
INFO - 2026-02-22 00:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:11:14 --> Upload Class Initialized
DEBUG - 2026-02-22 00:11:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:11:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:11:14 --> Encryption Class Initialized
INFO - 2026-02-22 00:11:14 --> Form Validation Class Initialized
INFO - 2026-02-22 00:11:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:11:14 --> Pagination Class Initialized
INFO - 2026-02-22 00:11:14 --> Email Class Initialized
INFO - 2026-02-22 00:11:14 --> Controller Class Initialized
DEBUG - 2026-02-22 00:11:14 --> Invoice MX_Controller Initialized
INFO - 2026-02-22 00:11:14 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 00:11:14 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 00:11:14 --> Model "Billing_model" initialized
INFO - 2026-02-22 00:11:14 --> Model "Common_model" initialized
INFO - 2026-02-22 00:11:14 --> Model "Invoice_model" initialized
INFO - 2026-02-22 00:11:14 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 00:11:15 --> Final output sent to browser
DEBUG - 2026-02-22 00:11:15 --> Total execution time: 3.9152
INFO - 2026-02-22 00:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:11:15 --> Upload Class Initialized
DEBUG - 2026-02-22 00:11:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:11:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:11:15 --> Encryption Class Initialized
INFO - 2026-02-22 00:11:15 --> Form Validation Class Initialized
INFO - 2026-02-22 00:11:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:11:15 --> Pagination Class Initialized
INFO - 2026-02-22 00:11:15 --> Email Class Initialized
INFO - 2026-02-22 00:11:15 --> Controller Class Initialized
DEBUG - 2026-02-22 00:11:15 --> Ticket MX_Controller Initialized
INFO - 2026-02-22 00:11:15 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 00:11:15 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 00:11:15 --> Model "Support_model" initialized
INFO - 2026-02-22 00:11:15 --> Model "Common_model" initialized
INFO - 2026-02-22 00:11:16 --> Final output sent to browser
DEBUG - 2026-02-22 00:11:16 --> Total execution time: 4.7335
INFO - 2026-02-22 00:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:11:16 --> Upload Class Initialized
DEBUG - 2026-02-22 00:11:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:11:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:11:16 --> Encryption Class Initialized
INFO - 2026-02-22 00:11:16 --> Form Validation Class Initialized
INFO - 2026-02-22 00:11:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:11:16 --> Pagination Class Initialized
INFO - 2026-02-22 00:11:16 --> Email Class Initialized
INFO - 2026-02-22 00:11:16 --> Controller Class Initialized
DEBUG - 2026-02-22 00:11:16 --> Order MX_Controller Initialized
INFO - 2026-02-22 00:11:16 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 00:11:16 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 00:11:16 --> Model "Order_model" initialized
INFO - 2026-02-22 00:11:16 --> Model "Common_model" initialized
INFO - 2026-02-22 00:11:16 --> Model "Currency_model" initialized
INFO - 2026-02-22 00:11:17 --> Final output sent to browser
DEBUG - 2026-02-22 00:11:17 --> Total execution time: 5.5594
INFO - 2026-02-22 00:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:11:17 --> Upload Class Initialized
DEBUG - 2026-02-22 00:11:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:11:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:11:17 --> Encryption Class Initialized
INFO - 2026-02-22 00:11:17 --> Form Validation Class Initialized
INFO - 2026-02-22 00:11:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:11:17 --> Pagination Class Initialized
INFO - 2026-02-22 00:11:17 --> Email Class Initialized
INFO - 2026-02-22 00:11:17 --> Controller Class Initialized
DEBUG - 2026-02-22 00:11:17 --> Dashboard MX_Controller Initialized
INFO - 2026-02-22 00:11:17 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 00:11:17 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 00:11:17 --> Model "Dashboard_model" initialized
INFO - 2026-02-22 00:11:18 --> Final output sent to browser
DEBUG - 2026-02-22 00:11:18 --> Total execution time: 6.3720
INFO - 2026-02-22 00:11:31 --> Config Class Initialized
INFO - 2026-02-22 00:11:31 --> Hooks Class Initialized
DEBUG - 2026-02-22 00:11:31 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:11:31 --> Utf8 Class Initialized
INFO - 2026-02-22 00:11:31 --> URI Class Initialized
INFO - 2026-02-22 00:11:31 --> Router Class Initialized
INFO - 2026-02-22 00:11:31 --> Output Class Initialized
INFO - 2026-02-22 00:11:31 --> Security Class Initialized
DEBUG - 2026-02-22 00:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:11:31 --> CSRF cookie sent
INFO - 2026-02-22 00:11:31 --> Input Class Initialized
INFO - 2026-02-22 00:11:31 --> Language Class Initialized
INFO - 2026-02-22 00:11:31 --> Language Class Initialized
INFO - 2026-02-22 00:11:31 --> Config Class Initialized
INFO - 2026-02-22 00:11:31 --> Loader Class Initialized
INFO - 2026-02-22 00:11:31 --> Helper loaded: url_helper
INFO - 2026-02-22 00:11:31 --> Helper loaded: form_helper
INFO - 2026-02-22 00:11:31 --> Helper loaded: html_helper
INFO - 2026-02-22 00:11:31 --> Helper loaded: file_helper
INFO - 2026-02-22 00:11:31 --> Helper loaded: email_helper
INFO - 2026-02-22 00:11:31 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:11:31 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:11:31 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:11:31 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:11:31 --> Database Driver Class Initialized
INFO - 2026-02-22 00:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:11:33 --> Upload Class Initialized
DEBUG - 2026-02-22 00:11:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:11:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:11:33 --> Encryption Class Initialized
INFO - 2026-02-22 00:11:33 --> Form Validation Class Initialized
INFO - 2026-02-22 00:11:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:11:33 --> Pagination Class Initialized
INFO - 2026-02-22 00:11:33 --> Email Class Initialized
INFO - 2026-02-22 00:11:33 --> Controller Class Initialized
DEBUG - 2026-02-22 00:11:33 --> Provisioning MX_Controller Initialized
INFO - 2026-02-22 00:11:33 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 00:11:33 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 00:11:33 --> Model "Provisioning_model" initialized
INFO - 2026-02-22 00:11:33 --> Model "Invoice_model" initialized
DEBUG - 2026-02-22 00:11:35 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 00:11:35 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 00:11:35 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 00:11:35 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 00:11:35 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 00:11:35 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/provisioning_logs.php
INFO - 2026-02-22 00:11:35 --> Final output sent to browser
DEBUG - 2026-02-22 00:11:35 --> Total execution time: 3.8938
INFO - 2026-02-22 00:11:35 --> Config Class Initialized
INFO - 2026-02-22 00:11:35 --> Hooks Class Initialized
DEBUG - 2026-02-22 00:11:35 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:11:35 --> Utf8 Class Initialized
INFO - 2026-02-22 00:11:35 --> URI Class Initialized
INFO - 2026-02-22 00:11:35 --> Router Class Initialized
INFO - 2026-02-22 00:11:35 --> Output Class Initialized
INFO - 2026-02-22 00:11:35 --> Security Class Initialized
DEBUG - 2026-02-22 00:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:11:35 --> CSRF cookie sent
INFO - 2026-02-22 00:11:35 --> Input Class Initialized
INFO - 2026-02-22 00:11:35 --> Language Class Initialized
INFO - 2026-02-22 00:11:35 --> Language Class Initialized
INFO - 2026-02-22 00:11:35 --> Config Class Initialized
INFO - 2026-02-22 00:11:35 --> Loader Class Initialized
INFO - 2026-02-22 00:11:35 --> Helper loaded: url_helper
INFO - 2026-02-22 00:11:35 --> Helper loaded: form_helper
INFO - 2026-02-22 00:11:35 --> Helper loaded: html_helper
INFO - 2026-02-22 00:11:35 --> Helper loaded: file_helper
INFO - 2026-02-22 00:11:35 --> Helper loaded: email_helper
INFO - 2026-02-22 00:11:35 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:11:35 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:11:35 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:11:35 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:11:35 --> Database Driver Class Initialized
INFO - 2026-02-22 00:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:11:37 --> Upload Class Initialized
DEBUG - 2026-02-22 00:11:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:11:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:11:37 --> Encryption Class Initialized
INFO - 2026-02-22 00:11:37 --> Form Validation Class Initialized
INFO - 2026-02-22 00:11:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:11:37 --> Pagination Class Initialized
INFO - 2026-02-22 00:11:37 --> Email Class Initialized
INFO - 2026-02-22 00:11:37 --> Controller Class Initialized
DEBUG - 2026-02-22 00:11:37 --> Provisioning MX_Controller Initialized
INFO - 2026-02-22 00:11:37 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 00:11:37 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 00:11:37 --> Model "Provisioning_model" initialized
INFO - 2026-02-22 00:11:37 --> Model "Invoice_model" initialized
INFO - 2026-02-22 00:11:54 --> Config Class Initialized
INFO - 2026-02-22 00:11:54 --> Hooks Class Initialized
DEBUG - 2026-02-22 00:11:54 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:11:54 --> Utf8 Class Initialized
INFO - 2026-02-22 00:11:54 --> URI Class Initialized
INFO - 2026-02-22 00:11:54 --> Router Class Initialized
INFO - 2026-02-22 00:11:54 --> Output Class Initialized
INFO - 2026-02-22 00:11:54 --> Security Class Initialized
DEBUG - 2026-02-22 00:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:11:54 --> CSRF cookie sent
INFO - 2026-02-22 00:11:54 --> Input Class Initialized
INFO - 2026-02-22 00:11:54 --> Language Class Initialized
INFO - 2026-02-22 00:11:54 --> Language Class Initialized
INFO - 2026-02-22 00:11:54 --> Config Class Initialized
INFO - 2026-02-22 00:11:54 --> Loader Class Initialized
INFO - 2026-02-22 00:11:54 --> Helper loaded: url_helper
INFO - 2026-02-22 00:11:54 --> Helper loaded: form_helper
INFO - 2026-02-22 00:11:54 --> Helper loaded: html_helper
INFO - 2026-02-22 00:11:54 --> Helper loaded: file_helper
INFO - 2026-02-22 00:11:54 --> Helper loaded: email_helper
INFO - 2026-02-22 00:11:54 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:11:54 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:11:54 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:11:54 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:11:54 --> Database Driver Class Initialized
INFO - 2026-02-22 00:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:11:56 --> Upload Class Initialized
DEBUG - 2026-02-22 00:11:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:11:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:11:56 --> Encryption Class Initialized
INFO - 2026-02-22 00:11:56 --> Form Validation Class Initialized
INFO - 2026-02-22 00:11:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:11:56 --> Pagination Class Initialized
INFO - 2026-02-22 00:11:56 --> Email Class Initialized
INFO - 2026-02-22 00:11:56 --> Controller Class Initialized
DEBUG - 2026-02-22 00:11:56 --> Provisioning MX_Controller Initialized
INFO - 2026-02-22 00:11:56 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 00:11:56 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 00:11:56 --> Model "Provisioning_model" initialized
INFO - 2026-02-22 00:11:56 --> Model "Invoice_model" initialized
DEBUG - 2026-02-22 00:11:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 00:11:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 00:11:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 00:11:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 00:11:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 00:11:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/provisioning_logs.php
INFO - 2026-02-22 00:11:58 --> Final output sent to browser
DEBUG - 2026-02-22 00:11:58 --> Total execution time: 3.9607
INFO - 2026-02-22 00:11:58 --> Config Class Initialized
INFO - 2026-02-22 00:11:58 --> Hooks Class Initialized
DEBUG - 2026-02-22 00:11:58 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:11:58 --> Utf8 Class Initialized
INFO - 2026-02-22 00:11:58 --> URI Class Initialized
INFO - 2026-02-22 00:11:58 --> Router Class Initialized
INFO - 2026-02-22 00:11:58 --> Output Class Initialized
INFO - 2026-02-22 00:11:58 --> Security Class Initialized
DEBUG - 2026-02-22 00:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:11:58 --> CSRF cookie sent
INFO - 2026-02-22 00:11:58 --> Input Class Initialized
INFO - 2026-02-22 00:11:58 --> Language Class Initialized
INFO - 2026-02-22 00:11:58 --> Language Class Initialized
INFO - 2026-02-22 00:11:58 --> Config Class Initialized
INFO - 2026-02-22 00:11:58 --> Loader Class Initialized
INFO - 2026-02-22 00:11:58 --> Helper loaded: url_helper
INFO - 2026-02-22 00:11:58 --> Helper loaded: form_helper
INFO - 2026-02-22 00:11:58 --> Helper loaded: html_helper
INFO - 2026-02-22 00:11:58 --> Helper loaded: file_helper
INFO - 2026-02-22 00:11:58 --> Helper loaded: email_helper
INFO - 2026-02-22 00:11:58 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:11:58 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:11:58 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:11:58 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:11:58 --> Database Driver Class Initialized
INFO - 2026-02-22 00:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:12:00 --> Upload Class Initialized
DEBUG - 2026-02-22 00:12:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:12:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:12:00 --> Encryption Class Initialized
INFO - 2026-02-22 00:12:00 --> Form Validation Class Initialized
INFO - 2026-02-22 00:12:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:12:00 --> Pagination Class Initialized
INFO - 2026-02-22 00:12:00 --> Email Class Initialized
INFO - 2026-02-22 00:12:00 --> Controller Class Initialized
DEBUG - 2026-02-22 00:12:00 --> Provisioning MX_Controller Initialized
INFO - 2026-02-22 00:12:00 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 00:12:00 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 00:12:00 --> Model "Provisioning_model" initialized
INFO - 2026-02-22 00:12:00 --> Model "Invoice_model" initialized
INFO - 2026-02-22 00:16:52 --> Config Class Initialized
INFO - 2026-02-22 00:16:52 --> Hooks Class Initialized
DEBUG - 2026-02-22 00:16:52 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:16:52 --> Utf8 Class Initialized
INFO - 2026-02-22 00:16:52 --> URI Class Initialized
INFO - 2026-02-22 00:16:52 --> Router Class Initialized
INFO - 2026-02-22 00:16:52 --> Output Class Initialized
INFO - 2026-02-22 00:16:52 --> Security Class Initialized
DEBUG - 2026-02-22 00:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:16:52 --> CSRF cookie sent
INFO - 2026-02-22 00:16:52 --> Input Class Initialized
INFO - 2026-02-22 00:16:52 --> Language Class Initialized
INFO - 2026-02-22 00:16:52 --> Language Class Initialized
INFO - 2026-02-22 00:16:52 --> Config Class Initialized
INFO - 2026-02-22 00:16:52 --> Loader Class Initialized
INFO - 2026-02-22 00:16:52 --> Helper loaded: url_helper
INFO - 2026-02-22 00:16:52 --> Helper loaded: form_helper
INFO - 2026-02-22 00:16:52 --> Helper loaded: html_helper
INFO - 2026-02-22 00:16:52 --> Helper loaded: file_helper
INFO - 2026-02-22 00:16:52 --> Helper loaded: email_helper
INFO - 2026-02-22 00:16:52 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:16:52 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:16:52 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:16:52 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:16:52 --> Database Driver Class Initialized
INFO - 2026-02-22 00:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:16:54 --> Upload Class Initialized
DEBUG - 2026-02-22 00:16:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:16:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:16:54 --> Encryption Class Initialized
INFO - 2026-02-22 00:16:54 --> Form Validation Class Initialized
INFO - 2026-02-22 00:16:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:16:54 --> Pagination Class Initialized
INFO - 2026-02-22 00:16:54 --> Email Class Initialized
INFO - 2026-02-22 00:16:54 --> Controller Class Initialized
DEBUG - 2026-02-22 00:16:54 --> Provisioning MX_Controller Initialized
INFO - 2026-02-22 00:16:54 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 00:16:54 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 00:16:54 --> Model "Provisioning_model" initialized
INFO - 2026-02-22 00:16:54 --> Model "Invoice_model" initialized
INFO - 2026-02-22 00:18:55 --> Config Class Initialized
INFO - 2026-02-22 00:18:55 --> Hooks Class Initialized
DEBUG - 2026-02-22 00:18:55 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:18:55 --> Utf8 Class Initialized
INFO - 2026-02-22 00:18:55 --> URI Class Initialized
INFO - 2026-02-22 00:18:55 --> Router Class Initialized
INFO - 2026-02-22 00:18:55 --> Output Class Initialized
INFO - 2026-02-22 00:18:55 --> Security Class Initialized
DEBUG - 2026-02-22 00:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:18:55 --> CSRF cookie sent
INFO - 2026-02-22 00:18:55 --> Input Class Initialized
INFO - 2026-02-22 00:18:55 --> Language Class Initialized
INFO - 2026-02-22 00:18:55 --> Language Class Initialized
INFO - 2026-02-22 00:18:55 --> Config Class Initialized
INFO - 2026-02-22 00:18:55 --> Loader Class Initialized
INFO - 2026-02-22 00:18:55 --> Helper loaded: url_helper
INFO - 2026-02-22 00:18:55 --> Helper loaded: form_helper
INFO - 2026-02-22 00:18:55 --> Helper loaded: html_helper
INFO - 2026-02-22 00:18:55 --> Helper loaded: file_helper
INFO - 2026-02-22 00:18:55 --> Helper loaded: email_helper
INFO - 2026-02-22 00:18:55 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:18:55 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:18:55 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:18:55 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:18:55 --> Database Driver Class Initialized
INFO - 2026-02-22 00:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:18:57 --> Upload Class Initialized
DEBUG - 2026-02-22 00:18:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:18:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:18:57 --> Encryption Class Initialized
INFO - 2026-02-22 00:18:57 --> Form Validation Class Initialized
INFO - 2026-02-22 00:18:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:18:57 --> Pagination Class Initialized
INFO - 2026-02-22 00:18:57 --> Email Class Initialized
INFO - 2026-02-22 00:18:57 --> Controller Class Initialized
DEBUG - 2026-02-22 00:18:57 --> Provisioning MX_Controller Initialized
INFO - 2026-02-22 00:18:57 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 00:18:57 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 00:18:57 --> Model "Provisioning_model" initialized
INFO - 2026-02-22 00:18:57 --> Model "Invoice_model" initialized
DEBUG - 2026-02-22 00:18:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 00:18:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 00:18:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 00:18:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 00:18:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 00:18:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/provisioning_logs.php
INFO - 2026-02-22 00:18:59 --> Final output sent to browser
DEBUG - 2026-02-22 00:18:59 --> Total execution time: 3.8769
INFO - 2026-02-22 00:18:59 --> Config Class Initialized
INFO - 2026-02-22 00:18:59 --> Hooks Class Initialized
DEBUG - 2026-02-22 00:18:59 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:18:59 --> Utf8 Class Initialized
INFO - 2026-02-22 00:18:59 --> URI Class Initialized
INFO - 2026-02-22 00:18:59 --> Router Class Initialized
INFO - 2026-02-22 00:18:59 --> Output Class Initialized
INFO - 2026-02-22 00:18:59 --> Security Class Initialized
DEBUG - 2026-02-22 00:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:18:59 --> CSRF cookie sent
INFO - 2026-02-22 00:18:59 --> Input Class Initialized
INFO - 2026-02-22 00:18:59 --> Language Class Initialized
INFO - 2026-02-22 00:18:59 --> Language Class Initialized
INFO - 2026-02-22 00:18:59 --> Config Class Initialized
INFO - 2026-02-22 00:18:59 --> Loader Class Initialized
INFO - 2026-02-22 00:18:59 --> Helper loaded: url_helper
INFO - 2026-02-22 00:18:59 --> Helper loaded: form_helper
INFO - 2026-02-22 00:18:59 --> Helper loaded: html_helper
INFO - 2026-02-22 00:18:59 --> Helper loaded: file_helper
INFO - 2026-02-22 00:18:59 --> Helper loaded: email_helper
INFO - 2026-02-22 00:18:59 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:18:59 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:18:59 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:18:59 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:18:59 --> Database Driver Class Initialized
INFO - 2026-02-22 00:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:19:01 --> Upload Class Initialized
DEBUG - 2026-02-22 00:19:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:19:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:19:01 --> Encryption Class Initialized
INFO - 2026-02-22 00:19:01 --> Form Validation Class Initialized
INFO - 2026-02-22 00:19:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:19:01 --> Pagination Class Initialized
INFO - 2026-02-22 00:19:01 --> Email Class Initialized
INFO - 2026-02-22 00:19:01 --> Controller Class Initialized
DEBUG - 2026-02-22 00:19:01 --> Provisioning MX_Controller Initialized
INFO - 2026-02-22 00:19:01 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 00:19:01 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 00:19:01 --> Model "Provisioning_model" initialized
INFO - 2026-02-22 00:19:01 --> Model "Invoice_model" initialized
INFO - 2026-02-22 00:19:02 --> Final output sent to browser
DEBUG - 2026-02-22 00:19:02 --> Total execution time: 2.7159
INFO - 2026-02-22 00:19:14 --> Config Class Initialized
INFO - 2026-02-22 00:19:14 --> Hooks Class Initialized
DEBUG - 2026-02-22 00:19:14 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:19:14 --> Utf8 Class Initialized
INFO - 2026-02-22 00:19:14 --> URI Class Initialized
INFO - 2026-02-22 00:19:14 --> Router Class Initialized
INFO - 2026-02-22 00:19:14 --> Output Class Initialized
INFO - 2026-02-22 00:19:14 --> Security Class Initialized
DEBUG - 2026-02-22 00:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:19:14 --> CSRF cookie sent
INFO - 2026-02-22 00:19:14 --> Input Class Initialized
INFO - 2026-02-22 00:19:14 --> Language Class Initialized
INFO - 2026-02-22 00:19:14 --> Language Class Initialized
INFO - 2026-02-22 00:19:14 --> Config Class Initialized
INFO - 2026-02-22 00:19:14 --> Loader Class Initialized
INFO - 2026-02-22 00:19:14 --> Helper loaded: url_helper
INFO - 2026-02-22 00:19:14 --> Helper loaded: form_helper
INFO - 2026-02-22 00:19:14 --> Helper loaded: html_helper
INFO - 2026-02-22 00:19:14 --> Helper loaded: file_helper
INFO - 2026-02-22 00:19:14 --> Helper loaded: email_helper
INFO - 2026-02-22 00:19:14 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:19:14 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:19:14 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:19:14 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:19:14 --> Database Driver Class Initialized
INFO - 2026-02-22 00:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:19:16 --> Upload Class Initialized
DEBUG - 2026-02-22 00:19:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:19:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:19:16 --> Encryption Class Initialized
INFO - 2026-02-22 00:19:16 --> Form Validation Class Initialized
INFO - 2026-02-22 00:19:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:19:16 --> Pagination Class Initialized
INFO - 2026-02-22 00:19:16 --> Email Class Initialized
INFO - 2026-02-22 00:19:16 --> Controller Class Initialized
DEBUG - 2026-02-22 00:19:16 --> Provisioning MX_Controller Initialized
INFO - 2026-02-22 00:19:16 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 00:19:16 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 00:19:16 --> Model "Provisioning_model" initialized
INFO - 2026-02-22 00:19:16 --> Model "Invoice_model" initialized
DEBUG - 2026-02-22 00:19:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 00:19:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 00:19:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 00:19:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 00:19:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 00:19:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/provisioning_logs.php
INFO - 2026-02-22 00:19:18 --> Final output sent to browser
DEBUG - 2026-02-22 00:19:18 --> Total execution time: 4.0756
INFO - 2026-02-22 00:19:18 --> Config Class Initialized
INFO - 2026-02-22 00:19:18 --> Hooks Class Initialized
DEBUG - 2026-02-22 00:19:18 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:19:18 --> Utf8 Class Initialized
INFO - 2026-02-22 00:19:18 --> URI Class Initialized
INFO - 2026-02-22 00:19:18 --> Router Class Initialized
INFO - 2026-02-22 00:19:18 --> Output Class Initialized
INFO - 2026-02-22 00:19:18 --> Security Class Initialized
DEBUG - 2026-02-22 00:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:19:18 --> CSRF cookie sent
INFO - 2026-02-22 00:19:18 --> Input Class Initialized
INFO - 2026-02-22 00:19:18 --> Language Class Initialized
INFO - 2026-02-22 00:19:18 --> Language Class Initialized
INFO - 2026-02-22 00:19:18 --> Config Class Initialized
INFO - 2026-02-22 00:19:18 --> Loader Class Initialized
INFO - 2026-02-22 00:19:18 --> Helper loaded: url_helper
INFO - 2026-02-22 00:19:18 --> Helper loaded: form_helper
INFO - 2026-02-22 00:19:18 --> Helper loaded: html_helper
INFO - 2026-02-22 00:19:18 --> Helper loaded: file_helper
INFO - 2026-02-22 00:19:18 --> Helper loaded: email_helper
INFO - 2026-02-22 00:19:18 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:19:18 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:19:18 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:19:18 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:19:18 --> Database Driver Class Initialized
INFO - 2026-02-22 00:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:19:20 --> Upload Class Initialized
DEBUG - 2026-02-22 00:19:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:19:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:19:20 --> Encryption Class Initialized
INFO - 2026-02-22 00:19:20 --> Form Validation Class Initialized
INFO - 2026-02-22 00:19:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:19:20 --> Pagination Class Initialized
INFO - 2026-02-22 00:19:20 --> Email Class Initialized
INFO - 2026-02-22 00:19:20 --> Controller Class Initialized
DEBUG - 2026-02-22 00:19:20 --> Provisioning MX_Controller Initialized
INFO - 2026-02-22 00:19:20 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 00:19:20 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 00:19:20 --> Model "Provisioning_model" initialized
INFO - 2026-02-22 00:19:20 --> Model "Invoice_model" initialized
INFO - 2026-02-22 00:19:22 --> Final output sent to browser
DEBUG - 2026-02-22 00:19:22 --> Total execution time: 3.2120
INFO - 2026-02-22 00:20:29 --> Config Class Initialized
INFO - 2026-02-22 00:20:29 --> Hooks Class Initialized
DEBUG - 2026-02-22 00:20:29 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:20:29 --> Utf8 Class Initialized
INFO - 2026-02-22 00:20:29 --> URI Class Initialized
INFO - 2026-02-22 00:20:29 --> Router Class Initialized
INFO - 2026-02-22 00:20:29 --> Output Class Initialized
INFO - 2026-02-22 00:20:29 --> Security Class Initialized
DEBUG - 2026-02-22 00:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:20:29 --> CSRF cookie sent
INFO - 2026-02-22 00:20:29 --> Input Class Initialized
INFO - 2026-02-22 00:20:29 --> Language Class Initialized
INFO - 2026-02-22 00:20:29 --> Language Class Initialized
INFO - 2026-02-22 00:20:29 --> Config Class Initialized
INFO - 2026-02-22 00:20:29 --> Loader Class Initialized
INFO - 2026-02-22 00:20:29 --> Helper loaded: url_helper
INFO - 2026-02-22 00:20:29 --> Helper loaded: form_helper
INFO - 2026-02-22 00:20:29 --> Helper loaded: html_helper
INFO - 2026-02-22 00:20:29 --> Helper loaded: file_helper
INFO - 2026-02-22 00:20:29 --> Helper loaded: email_helper
INFO - 2026-02-22 00:20:29 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:20:29 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:20:29 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:20:29 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:20:29 --> Database Driver Class Initialized
INFO - 2026-02-22 00:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:20:31 --> Upload Class Initialized
DEBUG - 2026-02-22 00:20:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:20:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:20:31 --> Encryption Class Initialized
INFO - 2026-02-22 00:20:31 --> Form Validation Class Initialized
INFO - 2026-02-22 00:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:20:31 --> Pagination Class Initialized
INFO - 2026-02-22 00:20:31 --> Email Class Initialized
INFO - 2026-02-22 00:20:31 --> Controller Class Initialized
DEBUG - 2026-02-22 00:20:31 --> Provisioning MX_Controller Initialized
INFO - 2026-02-22 00:20:31 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 00:20:31 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 00:20:31 --> Model "Provisioning_model" initialized
INFO - 2026-02-22 00:20:31 --> Model "Invoice_model" initialized
DEBUG - 2026-02-22 00:20:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 00:20:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 00:20:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 00:20:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 00:20:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 00:20:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/provisioning_logs.php
INFO - 2026-02-22 00:20:33 --> Final output sent to browser
DEBUG - 2026-02-22 00:20:33 --> Total execution time: 3.8901
INFO - 2026-02-22 00:20:33 --> Config Class Initialized
INFO - 2026-02-22 00:20:33 --> Hooks Class Initialized
DEBUG - 2026-02-22 00:20:33 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:20:33 --> Utf8 Class Initialized
INFO - 2026-02-22 00:20:33 --> URI Class Initialized
INFO - 2026-02-22 00:20:33 --> Router Class Initialized
INFO - 2026-02-22 00:20:33 --> Output Class Initialized
INFO - 2026-02-22 00:20:33 --> Security Class Initialized
DEBUG - 2026-02-22 00:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:20:33 --> CSRF cookie sent
INFO - 2026-02-22 00:20:33 --> Input Class Initialized
INFO - 2026-02-22 00:20:33 --> Language Class Initialized
INFO - 2026-02-22 00:20:33 --> Language Class Initialized
INFO - 2026-02-22 00:20:33 --> Config Class Initialized
INFO - 2026-02-22 00:20:33 --> Loader Class Initialized
INFO - 2026-02-22 00:20:33 --> Helper loaded: url_helper
INFO - 2026-02-22 00:20:33 --> Helper loaded: form_helper
INFO - 2026-02-22 00:20:33 --> Helper loaded: html_helper
INFO - 2026-02-22 00:20:33 --> Helper loaded: file_helper
INFO - 2026-02-22 00:20:33 --> Helper loaded: email_helper
INFO - 2026-02-22 00:20:33 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:20:33 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:20:33 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:20:33 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:20:33 --> Database Driver Class Initialized
INFO - 2026-02-22 00:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:20:35 --> Upload Class Initialized
DEBUG - 2026-02-22 00:20:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:20:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:20:35 --> Encryption Class Initialized
INFO - 2026-02-22 00:20:35 --> Form Validation Class Initialized
INFO - 2026-02-22 00:20:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:20:35 --> Pagination Class Initialized
INFO - 2026-02-22 00:20:35 --> Email Class Initialized
INFO - 2026-02-22 00:20:35 --> Controller Class Initialized
DEBUG - 2026-02-22 00:20:35 --> Provisioning MX_Controller Initialized
INFO - 2026-02-22 00:20:35 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 00:20:35 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 00:20:35 --> Model "Provisioning_model" initialized
INFO - 2026-02-22 00:20:35 --> Model "Invoice_model" initialized
INFO - 2026-02-22 00:20:36 --> Final output sent to browser
DEBUG - 2026-02-22 00:20:36 --> Total execution time: 3.4164
INFO - 2026-02-22 00:21:53 --> Config Class Initialized
INFO - 2026-02-22 00:21:53 --> Hooks Class Initialized
DEBUG - 2026-02-22 00:21:53 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:21:53 --> Utf8 Class Initialized
INFO - 2026-02-22 00:21:53 --> URI Class Initialized
INFO - 2026-02-22 00:21:53 --> Router Class Initialized
INFO - 2026-02-22 00:21:53 --> Output Class Initialized
INFO - 2026-02-22 00:21:53 --> Security Class Initialized
DEBUG - 2026-02-22 00:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:21:53 --> CSRF cookie sent
INFO - 2026-02-22 00:21:53 --> Input Class Initialized
INFO - 2026-02-22 00:21:53 --> Language Class Initialized
INFO - 2026-02-22 00:21:53 --> Language Class Initialized
INFO - 2026-02-22 00:21:53 --> Config Class Initialized
INFO - 2026-02-22 00:21:53 --> Loader Class Initialized
INFO - 2026-02-22 00:21:53 --> Helper loaded: url_helper
INFO - 2026-02-22 00:21:53 --> Helper loaded: form_helper
INFO - 2026-02-22 00:21:53 --> Helper loaded: html_helper
INFO - 2026-02-22 00:21:53 --> Helper loaded: file_helper
INFO - 2026-02-22 00:21:53 --> Helper loaded: email_helper
INFO - 2026-02-22 00:21:53 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:21:53 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:21:53 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:21:53 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:21:53 --> Database Driver Class Initialized
INFO - 2026-02-22 00:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:21:55 --> Upload Class Initialized
DEBUG - 2026-02-22 00:21:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:21:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:21:55 --> Encryption Class Initialized
INFO - 2026-02-22 00:21:55 --> Form Validation Class Initialized
INFO - 2026-02-22 00:21:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:21:55 --> Pagination Class Initialized
INFO - 2026-02-22 00:21:55 --> Email Class Initialized
INFO - 2026-02-22 00:21:55 --> Controller Class Initialized
DEBUG - 2026-02-22 00:21:55 --> Order MX_Controller Initialized
INFO - 2026-02-22 00:21:55 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 00:21:55 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 00:21:55 --> Model "Order_model" initialized
INFO - 2026-02-22 00:21:55 --> Model "Common_model" initialized
INFO - 2026-02-22 00:21:55 --> Model "Currency_model" initialized
DEBUG - 2026-02-22 00:21:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 00:21:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 00:21:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 00:21:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 00:21:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 00:21:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/order_list.php
INFO - 2026-02-22 00:21:55 --> Final output sent to browser
DEBUG - 2026-02-22 00:21:55 --> Total execution time: 2.4045
INFO - 2026-02-22 00:21:56 --> Config Class Initialized
INFO - 2026-02-22 00:21:56 --> Hooks Class Initialized
DEBUG - 2026-02-22 00:21:56 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:21:56 --> Utf8 Class Initialized
INFO - 2026-02-22 00:21:56 --> URI Class Initialized
INFO - 2026-02-22 00:21:56 --> Router Class Initialized
INFO - 2026-02-22 00:21:56 --> Output Class Initialized
INFO - 2026-02-22 00:21:56 --> Security Class Initialized
DEBUG - 2026-02-22 00:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:21:56 --> CSRF cookie sent
INFO - 2026-02-22 00:21:56 --> Input Class Initialized
INFO - 2026-02-22 00:21:56 --> Language Class Initialized
INFO - 2026-02-22 00:21:56 --> Language Class Initialized
INFO - 2026-02-22 00:21:56 --> Config Class Initialized
INFO - 2026-02-22 00:21:56 --> Loader Class Initialized
INFO - 2026-02-22 00:21:56 --> Helper loaded: url_helper
INFO - 2026-02-22 00:21:56 --> Helper loaded: form_helper
INFO - 2026-02-22 00:21:56 --> Helper loaded: html_helper
INFO - 2026-02-22 00:21:56 --> Helper loaded: file_helper
INFO - 2026-02-22 00:21:56 --> Helper loaded: email_helper
INFO - 2026-02-22 00:21:56 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:21:56 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:21:56 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:21:56 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:21:56 --> Database Driver Class Initialized
INFO - 2026-02-22 00:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:21:58 --> Upload Class Initialized
DEBUG - 2026-02-22 00:21:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:21:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:21:58 --> Encryption Class Initialized
INFO - 2026-02-22 00:21:58 --> Form Validation Class Initialized
INFO - 2026-02-22 00:21:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:21:58 --> Pagination Class Initialized
INFO - 2026-02-22 00:21:58 --> Email Class Initialized
INFO - 2026-02-22 00:21:58 --> Controller Class Initialized
DEBUG - 2026-02-22 00:21:58 --> Order MX_Controller Initialized
INFO - 2026-02-22 00:21:58 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 00:21:58 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 00:21:58 --> Model "Order_model" initialized
INFO - 2026-02-22 00:21:58 --> Model "Common_model" initialized
INFO - 2026-02-22 00:21:58 --> Model "Currency_model" initialized
INFO - 2026-02-22 00:22:17 --> Config Class Initialized
INFO - 2026-02-22 00:22:17 --> Config Class Initialized
INFO - 2026-02-22 00:22:17 --> Hooks Class Initialized
INFO - 2026-02-22 00:22:17 --> Hooks Class Initialized
DEBUG - 2026-02-22 00:22:17 --> UTF-8 Support Enabled
DEBUG - 2026-02-22 00:22:17 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:22:17 --> Utf8 Class Initialized
INFO - 2026-02-22 00:22:17 --> Utf8 Class Initialized
INFO - 2026-02-22 00:22:17 --> URI Class Initialized
INFO - 2026-02-22 00:22:17 --> URI Class Initialized
INFO - 2026-02-22 00:22:17 --> Router Class Initialized
INFO - 2026-02-22 00:22:17 --> Router Class Initialized
INFO - 2026-02-22 00:22:17 --> Output Class Initialized
INFO - 2026-02-22 00:22:17 --> Output Class Initialized
INFO - 2026-02-22 00:22:17 --> Security Class Initialized
INFO - 2026-02-22 00:22:17 --> Security Class Initialized
DEBUG - 2026-02-22 00:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:22:17 --> CSRF cookie sent
INFO - 2026-02-22 00:22:17 --> Input Class Initialized
INFO - 2026-02-22 00:22:17 --> Language Class Initialized
DEBUG - 2026-02-22 00:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:22:17 --> CSRF cookie sent
INFO - 2026-02-22 00:22:17 --> Input Class Initialized
INFO - 2026-02-22 00:22:17 --> Language Class Initialized
INFO - 2026-02-22 00:22:17 --> Language Class Initialized
INFO - 2026-02-22 00:22:17 --> Config Class Initialized
INFO - 2026-02-22 00:22:17 --> Config Class Initialized
INFO - 2026-02-22 00:22:17 --> Hooks Class Initialized
INFO - 2026-02-22 00:22:17 --> Config Class Initialized
INFO - 2026-02-22 00:22:17 --> Hooks Class Initialized
INFO - 2026-02-22 00:22:17 --> Language Class Initialized
INFO - 2026-02-22 00:22:17 --> Config Class Initialized
INFO - 2026-02-22 00:22:17 --> Config Class Initialized
INFO - 2026-02-22 00:22:17 --> Hooks Class Initialized
DEBUG - 2026-02-22 00:22:17 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:22:17 --> Utf8 Class Initialized
DEBUG - 2026-02-22 00:22:17 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:22:17 --> Utf8 Class Initialized
INFO - 2026-02-22 00:22:17 --> Loader Class Initialized
INFO - 2026-02-22 00:22:17 --> Config Class Initialized
INFO - 2026-02-22 00:22:17 --> Helper loaded: url_helper
INFO - 2026-02-22 00:22:17 --> URI Class Initialized
INFO - 2026-02-22 00:22:17 --> Loader Class Initialized
INFO - 2026-02-22 00:22:17 --> Hooks Class Initialized
INFO - 2026-02-22 00:22:17 --> Helper loaded: form_helper
INFO - 2026-02-22 00:22:17 --> URI Class Initialized
DEBUG - 2026-02-22 00:22:17 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:22:17 --> Helper loaded: url_helper
INFO - 2026-02-22 00:22:17 --> Router Class Initialized
INFO - 2026-02-22 00:22:17 --> Helper loaded: html_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: file_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: email_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: form_helper
INFO - 2026-02-22 00:22:17 --> Output Class Initialized
INFO - 2026-02-22 00:22:17 --> Router Class Initialized
DEBUG - 2026-02-22 00:22:17 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:22:17 --> Utf8 Class Initialized
INFO - 2026-02-22 00:22:17 --> Helper loaded: html_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: file_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: email_helper
INFO - 2026-02-22 00:22:17 --> Security Class Initialized
INFO - 2026-02-22 00:22:17 --> URI Class Initialized
INFO - 2026-02-22 00:22:17 --> Output Class Initialized
INFO - 2026-02-22 00:22:17 --> Helper loaded: cpanel_helper
DEBUG - 2026-02-22 00:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:22:17 --> CSRF cookie sent
INFO - 2026-02-22 00:22:17 --> Input Class Initialized
INFO - 2026-02-22 00:22:17 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:22:17 --> Language Class Initialized
INFO - 2026-02-22 00:22:17 --> Security Class Initialized
INFO - 2026-02-22 00:22:17 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:22:17 --> Router Class Initialized
INFO - 2026-02-22 00:22:17 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:22:17 --> Language Class Initialized
INFO - 2026-02-22 00:22:17 --> Config Class Initialized
DEBUG - 2026-02-22 00:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:22:17 --> CSRF cookie sent
INFO - 2026-02-22 00:22:17 --> Input Class Initialized
INFO - 2026-02-22 00:22:17 --> Output Class Initialized
INFO - 2026-02-22 00:22:17 --> Language Class Initialized
INFO - 2026-02-22 00:22:17 --> Utf8 Class Initialized
INFO - 2026-02-22 00:22:17 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:22:17 --> Language Class Initialized
INFO - 2026-02-22 00:22:17 --> Config Class Initialized
INFO - 2026-02-22 00:22:17 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:22:17 --> URI Class Initialized
INFO - 2026-02-22 00:22:17 --> Security Class Initialized
DEBUG - 2026-02-22 00:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:22:17 --> CSRF cookie sent
INFO - 2026-02-22 00:22:17 --> Input Class Initialized
INFO - 2026-02-22 00:22:17 --> Language Class Initialized
INFO - 2026-02-22 00:22:17 --> Router Class Initialized
INFO - 2026-02-22 00:22:17 --> Loader Class Initialized
INFO - 2026-02-22 00:22:17 --> Database Driver Class Initialized
INFO - 2026-02-22 00:22:17 --> Language Class Initialized
INFO - 2026-02-22 00:22:17 --> Config Class Initialized
INFO - 2026-02-22 00:22:17 --> Helper loaded: url_helper
INFO - 2026-02-22 00:22:17 --> Output Class Initialized
INFO - 2026-02-22 00:22:17 --> Helper loaded: form_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: html_helper
INFO - 2026-02-22 00:22:17 --> Loader Class Initialized
INFO - 2026-02-22 00:22:17 --> Helper loaded: file_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: email_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: url_helper
INFO - 2026-02-22 00:22:17 --> Database Driver Class Initialized
INFO - 2026-02-22 00:22:17 --> Helper loaded: form_helper
INFO - 2026-02-22 00:22:17 --> Loader Class Initialized
INFO - 2026-02-22 00:22:17 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: html_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: url_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: file_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: email_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: form_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:22:17 --> Security Class Initialized
INFO - 2026-02-22 00:22:17 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: html_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: file_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: email_helper
DEBUG - 2026-02-22 00:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:22:17 --> CSRF cookie sent
INFO - 2026-02-22 00:22:17 --> Input Class Initialized
INFO - 2026-02-22 00:22:17 --> Language Class Initialized
INFO - 2026-02-22 00:22:17 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:22:17 --> Language Class Initialized
INFO - 2026-02-22 00:22:17 --> Config Class Initialized
INFO - 2026-02-22 00:22:17 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:22:17 --> Loader Class Initialized
INFO - 2026-02-22 00:22:17 --> Helper loaded: url_helper
INFO - 2026-02-22 00:22:17 --> Database Driver Class Initialized
INFO - 2026-02-22 00:22:17 --> Helper loaded: form_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: html_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: file_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: email_helper
INFO - 2026-02-22 00:22:17 --> Database Driver Class Initialized
INFO - 2026-02-22 00:22:17 --> Database Driver Class Initialized
INFO - 2026-02-22 00:22:17 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:22:17 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:22:17 --> Database Driver Class Initialized
INFO - 2026-02-22 00:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:22:19 --> Upload Class Initialized
DEBUG - 2026-02-22 00:22:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:22:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:22:19 --> Encryption Class Initialized
INFO - 2026-02-22 00:22:19 --> Form Validation Class Initialized
INFO - 2026-02-22 00:22:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:22:19 --> Pagination Class Initialized
INFO - 2026-02-22 00:22:19 --> Email Class Initialized
INFO - 2026-02-22 00:22:19 --> Controller Class Initialized
ERROR - 2026-02-22 00:22:19 --> 404 Page Not Found: /index
INFO - 2026-02-22 00:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:22:19 --> Upload Class Initialized
DEBUG - 2026-02-22 00:22:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:22:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:22:19 --> Encryption Class Initialized
INFO - 2026-02-22 00:22:19 --> Form Validation Class Initialized
INFO - 2026-02-22 00:22:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:22:19 --> Pagination Class Initialized
INFO - 2026-02-22 00:22:19 --> Config Class Initialized
INFO - 2026-02-22 00:22:19 --> Hooks Class Initialized
INFO - 2026-02-22 00:22:19 --> Email Class Initialized
INFO - 2026-02-22 00:22:19 --> Controller Class Initialized
ERROR - 2026-02-22 00:22:19 --> 404 Page Not Found: /index
INFO - 2026-02-22 00:22:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-02-22 00:22:19 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:22:19 --> Utf8 Class Initialized
INFO - 2026-02-22 00:22:19 --> URI Class Initialized
INFO - 2026-02-22 00:22:19 --> Upload Class Initialized
DEBUG - 2026-02-22 00:22:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:22:19 --> Router Class Initialized
INFO - 2026-02-22 00:22:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:22:19 --> Encryption Class Initialized
INFO - 2026-02-22 00:22:19 --> Output Class Initialized
INFO - 2026-02-22 00:22:19 --> Form Validation Class Initialized
INFO - 2026-02-22 00:22:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:22:19 --> Security Class Initialized
INFO - 2026-02-22 00:22:19 --> Pagination Class Initialized
DEBUG - 2026-02-22 00:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:22:19 --> CSRF cookie sent
INFO - 2026-02-22 00:22:19 --> Input Class Initialized
INFO - 2026-02-22 00:22:19 --> Language Class Initialized
INFO - 2026-02-22 00:22:19 --> Language Class Initialized
INFO - 2026-02-22 00:22:19 --> Config Class Initialized
INFO - 2026-02-22 00:22:19 --> Config Class Initialized
INFO - 2026-02-22 00:22:19 --> Hooks Class Initialized
INFO - 2026-02-22 00:22:19 --> Email Class Initialized
INFO - 2026-02-22 00:22:19 --> Controller Class Initialized
DEBUG - 2026-02-22 00:22:19 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:22:19 --> Utf8 Class Initialized
ERROR - 2026-02-22 00:22:19 --> 404 Page Not Found: /index
INFO - 2026-02-22 00:22:19 --> URI Class Initialized
INFO - 2026-02-22 00:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:22:19 --> Loader Class Initialized
INFO - 2026-02-22 00:22:19 --> Helper loaded: url_helper
INFO - 2026-02-22 00:22:19 --> Router Class Initialized
INFO - 2026-02-22 00:22:19 --> Upload Class Initialized
INFO - 2026-02-22 00:22:19 --> Helper loaded: form_helper
INFO - 2026-02-22 00:22:19 --> Output Class Initialized
INFO - 2026-02-22 00:22:19 --> Helper loaded: html_helper
DEBUG - 2026-02-22 00:22:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:22:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:22:19 --> Encryption Class Initialized
INFO - 2026-02-22 00:22:19 --> Helper loaded: file_helper
INFO - 2026-02-22 00:22:19 --> Helper loaded: email_helper
INFO - 2026-02-22 00:22:19 --> Security Class Initialized
INFO - 2026-02-22 00:22:19 --> Form Validation Class Initialized
DEBUG - 2026-02-22 00:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:22:19 --> CSRF cookie sent
INFO - 2026-02-22 00:22:19 --> Input Class Initialized
INFO - 2026-02-22 00:22:19 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:22:19 --> Language Class Initialized
INFO - 2026-02-22 00:22:19 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:22:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:22:19 --> Pagination Class Initialized
INFO - 2026-02-22 00:22:19 --> Language Class Initialized
INFO - 2026-02-22 00:22:19 --> Config Class Initialized
INFO - 2026-02-22 00:22:19 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:22:19 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:22:19 --> Loader Class Initialized
INFO - 2026-02-22 00:22:19 --> Email Class Initialized
INFO - 2026-02-22 00:22:19 --> Controller Class Initialized
INFO - 2026-02-22 00:22:19 --> Helper loaded: url_helper
ERROR - 2026-02-22 00:22:19 --> 404 Page Not Found: /index
INFO - 2026-02-22 00:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:22:19 --> Helper loaded: form_helper
INFO - 2026-02-22 00:22:19 --> Helper loaded: html_helper
INFO - 2026-02-22 00:22:19 --> Helper loaded: file_helper
INFO - 2026-02-22 00:22:19 --> Helper loaded: email_helper
INFO - 2026-02-22 00:22:19 --> Upload Class Initialized
INFO - 2026-02-22 00:22:19 --> Helper loaded: whmaz_helper
DEBUG - 2026-02-22 00:22:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:22:19 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:22:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:22:19 --> Encryption Class Initialized
INFO - 2026-02-22 00:22:19 --> Database Driver Class Initialized
INFO - 2026-02-22 00:22:19 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:22:19 --> Form Validation Class Initialized
INFO - 2026-02-22 00:22:19 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:22:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:22:19 --> Pagination Class Initialized
INFO - 2026-02-22 00:22:19 --> Email Class Initialized
INFO - 2026-02-22 00:22:19 --> Controller Class Initialized
ERROR - 2026-02-22 00:22:19 --> 404 Page Not Found: /index
INFO - 2026-02-22 00:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:22:19 --> Database Driver Class Initialized
INFO - 2026-02-22 00:22:19 --> Upload Class Initialized
DEBUG - 2026-02-22 00:22:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:22:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:22:19 --> Encryption Class Initialized
INFO - 2026-02-22 00:22:19 --> Form Validation Class Initialized
INFO - 2026-02-22 00:22:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:22:19 --> Pagination Class Initialized
INFO - 2026-02-22 00:22:19 --> Email Class Initialized
INFO - 2026-02-22 00:22:19 --> Controller Class Initialized
ERROR - 2026-02-22 00:22:19 --> 404 Page Not Found: /index
INFO - 2026-02-22 00:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:22:21 --> Upload Class Initialized
DEBUG - 2026-02-22 00:22:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:22:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:22:21 --> Encryption Class Initialized
INFO - 2026-02-22 00:22:21 --> Form Validation Class Initialized
INFO - 2026-02-22 00:22:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:22:21 --> Pagination Class Initialized
INFO - 2026-02-22 00:22:21 --> Email Class Initialized
INFO - 2026-02-22 00:22:21 --> Controller Class Initialized
ERROR - 2026-02-22 00:22:21 --> 404 Page Not Found: /index
INFO - 2026-02-22 00:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:22:21 --> Upload Class Initialized
DEBUG - 2026-02-22 00:22:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:22:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:22:21 --> Encryption Class Initialized
INFO - 2026-02-22 00:22:21 --> Form Validation Class Initialized
INFO - 2026-02-22 00:22:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:22:21 --> Pagination Class Initialized
INFO - 2026-02-22 00:22:21 --> Email Class Initialized
INFO - 2026-02-22 00:22:21 --> Controller Class Initialized
ERROR - 2026-02-22 00:22:21 --> 404 Page Not Found: /index
INFO - 2026-02-22 00:23:12 --> Config Class Initialized
INFO - 2026-02-22 00:23:12 --> Hooks Class Initialized
DEBUG - 2026-02-22 00:23:12 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:23:12 --> Utf8 Class Initialized
INFO - 2026-02-22 00:23:12 --> URI Class Initialized
INFO - 2026-02-22 00:23:12 --> Router Class Initialized
INFO - 2026-02-22 00:23:12 --> Output Class Initialized
INFO - 2026-02-22 00:23:12 --> Security Class Initialized
DEBUG - 2026-02-22 00:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:23:12 --> CSRF cookie sent
INFO - 2026-02-22 00:23:12 --> Input Class Initialized
INFO - 2026-02-22 00:23:12 --> Language Class Initialized
INFO - 2026-02-22 00:23:12 --> Language Class Initialized
INFO - 2026-02-22 00:23:12 --> Config Class Initialized
INFO - 2026-02-22 00:23:12 --> Loader Class Initialized
INFO - 2026-02-22 00:23:12 --> Helper loaded: url_helper
INFO - 2026-02-22 00:23:12 --> Helper loaded: form_helper
INFO - 2026-02-22 00:23:12 --> Helper loaded: html_helper
INFO - 2026-02-22 00:23:12 --> Helper loaded: file_helper
INFO - 2026-02-22 00:23:12 --> Helper loaded: email_helper
INFO - 2026-02-22 00:23:12 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:23:12 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:23:12 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:23:12 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:23:12 --> Database Driver Class Initialized
INFO - 2026-02-22 00:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:23:14 --> Upload Class Initialized
DEBUG - 2026-02-22 00:23:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:23:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:23:14 --> Encryption Class Initialized
INFO - 2026-02-22 00:23:14 --> Form Validation Class Initialized
INFO - 2026-02-22 00:23:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:23:14 --> Pagination Class Initialized
INFO - 2026-02-22 00:23:14 --> Email Class Initialized
INFO - 2026-02-22 00:23:14 --> Controller Class Initialized
DEBUG - 2026-02-22 00:23:14 --> Order MX_Controller Initialized
INFO - 2026-02-22 00:23:14 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 00:23:14 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 00:23:14 --> Model "Order_model" initialized
INFO - 2026-02-22 00:23:14 --> Model "Common_model" initialized
INFO - 2026-02-22 00:23:14 --> Model "Currency_model" initialized
DEBUG - 2026-02-22 00:23:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 00:23:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 00:23:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 00:23:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 00:23:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 00:23:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/order_manage.php
INFO - 2026-02-22 00:23:18 --> Final output sent to browser
DEBUG - 2026-02-22 00:23:18 --> Total execution time: 6.0540
INFO - 2026-02-22 00:23:18 --> Config Class Initialized
INFO - 2026-02-22 00:23:18 --> Hooks Class Initialized
INFO - 2026-02-22 00:23:18 --> Config Class Initialized
INFO - 2026-02-22 00:23:18 --> Hooks Class Initialized
DEBUG - 2026-02-22 00:23:18 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:23:18 --> Utf8 Class Initialized
INFO - 2026-02-22 00:23:18 --> URI Class Initialized
DEBUG - 2026-02-22 00:23:18 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:23:18 --> Utf8 Class Initialized
INFO - 2026-02-22 00:23:18 --> URI Class Initialized
INFO - 2026-02-22 00:23:18 --> Router Class Initialized
INFO - 2026-02-22 00:23:18 --> Router Class Initialized
INFO - 2026-02-22 00:23:18 --> Output Class Initialized
INFO - 2026-02-22 00:23:18 --> Security Class Initialized
INFO - 2026-02-22 00:23:18 --> Output Class Initialized
DEBUG - 2026-02-22 00:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:23:18 --> CSRF cookie sent
INFO - 2026-02-22 00:23:18 --> Input Class Initialized
INFO - 2026-02-22 00:23:18 --> Security Class Initialized
INFO - 2026-02-22 00:23:18 --> Language Class Initialized
INFO - 2026-02-22 00:23:18 --> Language Class Initialized
INFO - 2026-02-22 00:23:18 --> Config Class Initialized
DEBUG - 2026-02-22 00:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:23:18 --> CSRF cookie sent
INFO - 2026-02-22 00:23:18 --> Input Class Initialized
INFO - 2026-02-22 00:23:18 --> Language Class Initialized
INFO - 2026-02-22 00:23:18 --> Language Class Initialized
INFO - 2026-02-22 00:23:18 --> Config Class Initialized
INFO - 2026-02-22 00:23:18 --> Loader Class Initialized
INFO - 2026-02-22 00:23:18 --> Helper loaded: url_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: form_helper
INFO - 2026-02-22 00:23:18 --> Loader Class Initialized
INFO - 2026-02-22 00:23:18 --> Helper loaded: html_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: file_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: email_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: url_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: form_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: html_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: file_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: email_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:23:18 --> Database Driver Class Initialized
INFO - 2026-02-22 00:23:18 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:23:18 --> Database Driver Class Initialized
INFO - 2026-02-22 00:23:18 --> Config Class Initialized
INFO - 2026-02-22 00:23:18 --> Hooks Class Initialized
DEBUG - 2026-02-22 00:23:18 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:23:18 --> Utf8 Class Initialized
INFO - 2026-02-22 00:23:18 --> URI Class Initialized
INFO - 2026-02-22 00:23:18 --> Router Class Initialized
INFO - 2026-02-22 00:23:18 --> Output Class Initialized
INFO - 2026-02-22 00:23:18 --> Security Class Initialized
DEBUG - 2026-02-22 00:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:23:18 --> CSRF cookie sent
INFO - 2026-02-22 00:23:18 --> Input Class Initialized
INFO - 2026-02-22 00:23:18 --> Language Class Initialized
INFO - 2026-02-22 00:23:18 --> Language Class Initialized
INFO - 2026-02-22 00:23:18 --> Config Class Initialized
INFO - 2026-02-22 00:23:18 --> Loader Class Initialized
INFO - 2026-02-22 00:23:18 --> Helper loaded: url_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: form_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: html_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: file_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: email_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:23:18 --> Database Driver Class Initialized
INFO - 2026-02-22 00:23:18 --> Config Class Initialized
INFO - 2026-02-22 00:23:18 --> Config Class Initialized
INFO - 2026-02-22 00:23:18 --> Hooks Class Initialized
INFO - 2026-02-22 00:23:18 --> Hooks Class Initialized
DEBUG - 2026-02-22 00:23:18 --> UTF-8 Support Enabled
DEBUG - 2026-02-22 00:23:18 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:23:18 --> Utf8 Class Initialized
INFO - 2026-02-22 00:23:18 --> Utf8 Class Initialized
INFO - 2026-02-22 00:23:18 --> URI Class Initialized
INFO - 2026-02-22 00:23:18 --> URI Class Initialized
INFO - 2026-02-22 00:23:18 --> Router Class Initialized
INFO - 2026-02-22 00:23:18 --> Router Class Initialized
INFO - 2026-02-22 00:23:18 --> Config Class Initialized
INFO - 2026-02-22 00:23:18 --> Hooks Class Initialized
INFO - 2026-02-22 00:23:18 --> Output Class Initialized
INFO - 2026-02-22 00:23:18 --> Output Class Initialized
INFO - 2026-02-22 00:23:18 --> Security Class Initialized
DEBUG - 2026-02-22 00:23:18 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:23:18 --> Utf8 Class Initialized
DEBUG - 2026-02-22 00:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:23:18 --> CSRF cookie sent
INFO - 2026-02-22 00:23:18 --> Input Class Initialized
INFO - 2026-02-22 00:23:18 --> Security Class Initialized
INFO - 2026-02-22 00:23:18 --> URI Class Initialized
INFO - 2026-02-22 00:23:18 --> Language Class Initialized
INFO - 2026-02-22 00:23:18 --> Language Class Initialized
DEBUG - 2026-02-22 00:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:23:18 --> Config Class Initialized
INFO - 2026-02-22 00:23:18 --> CSRF cookie sent
INFO - 2026-02-22 00:23:18 --> Input Class Initialized
INFO - 2026-02-22 00:23:18 --> Language Class Initialized
INFO - 2026-02-22 00:23:18 --> Language Class Initialized
INFO - 2026-02-22 00:23:18 --> Config Class Initialized
INFO - 2026-02-22 00:23:18 --> Loader Class Initialized
INFO - 2026-02-22 00:23:18 --> Router Class Initialized
INFO - 2026-02-22 00:23:18 --> Helper loaded: url_helper
INFO - 2026-02-22 00:23:18 --> Loader Class Initialized
INFO - 2026-02-22 00:23:18 --> Helper loaded: form_helper
INFO - 2026-02-22 00:23:18 --> Output Class Initialized
INFO - 2026-02-22 00:23:18 --> Helper loaded: url_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: html_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: file_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: email_helper
INFO - 2026-02-22 00:23:18 --> Security Class Initialized
INFO - 2026-02-22 00:23:18 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: ssp_helper
DEBUG - 2026-02-22 00:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:23:18 --> CSRF cookie sent
INFO - 2026-02-22 00:23:18 --> Input Class Initialized
INFO - 2026-02-22 00:23:18 --> Language Class Initialized
INFO - 2026-02-22 00:23:18 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:23:18 --> Language Class Initialized
INFO - 2026-02-22 00:23:18 --> Config Class Initialized
INFO - 2026-02-22 00:23:18 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:23:18 --> Loader Class Initialized
INFO - 2026-02-22 00:23:18 --> Helper loaded: url_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: form_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: html_helper
INFO - 2026-02-22 00:23:18 --> Database Driver Class Initialized
INFO - 2026-02-22 00:23:18 --> Helper loaded: file_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: email_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: form_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: html_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: file_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: email_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:23:18 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:23:18 --> Database Driver Class Initialized
INFO - 2026-02-22 00:23:18 --> Database Driver Class Initialized
INFO - 2026-02-22 00:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:23:20 --> Upload Class Initialized
DEBUG - 2026-02-22 00:23:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:23:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:23:20 --> Encryption Class Initialized
INFO - 2026-02-22 00:23:20 --> Form Validation Class Initialized
INFO - 2026-02-22 00:23:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:23:20 --> Pagination Class Initialized
INFO - 2026-02-22 00:23:20 --> Email Class Initialized
INFO - 2026-02-22 00:23:20 --> Controller Class Initialized
ERROR - 2026-02-22 00:23:20 --> 404 Page Not Found: /index
INFO - 2026-02-22 00:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:23:20 --> Upload Class Initialized
DEBUG - 2026-02-22 00:23:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:23:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:23:20 --> Encryption Class Initialized
INFO - 2026-02-22 00:23:20 --> Form Validation Class Initialized
INFO - 2026-02-22 00:23:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:23:20 --> Pagination Class Initialized
INFO - 2026-02-22 00:23:20 --> Email Class Initialized
INFO - 2026-02-22 00:23:20 --> Config Class Initialized
INFO - 2026-02-22 00:23:20 --> Hooks Class Initialized
INFO - 2026-02-22 00:23:20 --> Controller Class Initialized
ERROR - 2026-02-22 00:23:20 --> 404 Page Not Found: /index
INFO - 2026-02-22 00:23:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-02-22 00:23:20 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:23:20 --> Utf8 Class Initialized
INFO - 2026-02-22 00:23:20 --> URI Class Initialized
INFO - 2026-02-22 00:23:20 --> Upload Class Initialized
INFO - 2026-02-22 00:23:20 --> Router Class Initialized
DEBUG - 2026-02-22 00:23:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:23:20 --> Output Class Initialized
INFO - 2026-02-22 00:23:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:23:20 --> Encryption Class Initialized
INFO - 2026-02-22 00:23:20 --> Security Class Initialized
DEBUG - 2026-02-22 00:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:23:20 --> CSRF cookie sent
INFO - 2026-02-22 00:23:20 --> Input Class Initialized
INFO - 2026-02-22 00:23:20 --> Form Validation Class Initialized
INFO - 2026-02-22 00:23:20 --> Language Class Initialized
INFO - 2026-02-22 00:23:20 --> Language Class Initialized
INFO - 2026-02-22 00:23:20 --> Config Class Initialized
INFO - 2026-02-22 00:23:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:23:20 --> Pagination Class Initialized
INFO - 2026-02-22 00:23:20 --> Config Class Initialized
INFO - 2026-02-22 00:23:20 --> Hooks Class Initialized
INFO - 2026-02-22 00:23:20 --> Loader Class Initialized
DEBUG - 2026-02-22 00:23:20 --> UTF-8 Support Enabled
INFO - 2026-02-22 00:23:20 --> Utf8 Class Initialized
INFO - 2026-02-22 00:23:20 --> Helper loaded: url_helper
INFO - 2026-02-22 00:23:20 --> URI Class Initialized
INFO - 2026-02-22 00:23:20 --> Helper loaded: form_helper
INFO - 2026-02-22 00:23:20 --> Email Class Initialized
INFO - 2026-02-22 00:23:20 --> Controller Class Initialized
INFO - 2026-02-22 00:23:20 --> Helper loaded: html_helper
INFO - 2026-02-22 00:23:20 --> Router Class Initialized
ERROR - 2026-02-22 00:23:20 --> 404 Page Not Found: /index
INFO - 2026-02-22 00:23:20 --> Helper loaded: file_helper
INFO - 2026-02-22 00:23:20 --> Helper loaded: email_helper
INFO - 2026-02-22 00:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:23:20 --> Output Class Initialized
INFO - 2026-02-22 00:23:20 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:23:20 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:23:20 --> Upload Class Initialized
INFO - 2026-02-22 00:23:20 --> Security Class Initialized
INFO - 2026-02-22 00:23:20 --> Helper loaded: cpanel_helper
DEBUG - 2026-02-22 00:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2026-02-22 00:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 00:23:20 --> CSRF cookie sent
INFO - 2026-02-22 00:23:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:23:20 --> Input Class Initialized
INFO - 2026-02-22 00:23:20 --> Encryption Class Initialized
INFO - 2026-02-22 00:23:20 --> Language Class Initialized
INFO - 2026-02-22 00:23:20 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:23:20 --> Language Class Initialized
INFO - 2026-02-22 00:23:20 --> Config Class Initialized
INFO - 2026-02-22 00:23:20 --> Form Validation Class Initialized
INFO - 2026-02-22 00:23:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:23:20 --> Pagination Class Initialized
INFO - 2026-02-22 00:23:20 --> Loader Class Initialized
INFO - 2026-02-22 00:23:20 --> Helper loaded: url_helper
INFO - 2026-02-22 00:23:20 --> Helper loaded: form_helper
INFO - 2026-02-22 00:23:20 --> Database Driver Class Initialized
INFO - 2026-02-22 00:23:20 --> Helper loaded: html_helper
INFO - 2026-02-22 00:23:20 --> Email Class Initialized
INFO - 2026-02-22 00:23:20 --> Controller Class Initialized
INFO - 2026-02-22 00:23:20 --> Helper loaded: file_helper
ERROR - 2026-02-22 00:23:20 --> 404 Page Not Found: /index
INFO - 2026-02-22 00:23:20 --> Helper loaded: email_helper
INFO - 2026-02-22 00:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:23:20 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 00:23:20 --> Helper loaded: ssp_helper
INFO - 2026-02-22 00:23:20 --> Upload Class Initialized
DEBUG - 2026-02-22 00:23:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:23:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:23:20 --> Encryption Class Initialized
INFO - 2026-02-22 00:23:20 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 00:23:20 --> Helper loaded: domain_helper
INFO - 2026-02-22 00:23:20 --> Form Validation Class Initialized
INFO - 2026-02-22 00:23:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:23:20 --> Pagination Class Initialized
INFO - 2026-02-22 00:23:20 --> Email Class Initialized
INFO - 2026-02-22 00:23:20 --> Controller Class Initialized
ERROR - 2026-02-22 00:23:20 --> 404 Page Not Found: /index
INFO - 2026-02-22 00:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:23:20 --> Database Driver Class Initialized
INFO - 2026-02-22 00:23:20 --> Upload Class Initialized
DEBUG - 2026-02-22 00:23:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:23:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:23:20 --> Encryption Class Initialized
INFO - 2026-02-22 00:23:20 --> Form Validation Class Initialized
INFO - 2026-02-22 00:23:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:23:20 --> Pagination Class Initialized
INFO - 2026-02-22 00:23:20 --> Email Class Initialized
INFO - 2026-02-22 00:23:20 --> Controller Class Initialized
ERROR - 2026-02-22 00:23:20 --> 404 Page Not Found: /index
INFO - 2026-02-22 00:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:23:22 --> Upload Class Initialized
DEBUG - 2026-02-22 00:23:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:23:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:23:22 --> Encryption Class Initialized
INFO - 2026-02-22 00:23:22 --> Form Validation Class Initialized
INFO - 2026-02-22 00:23:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:23:22 --> Pagination Class Initialized
INFO - 2026-02-22 00:23:22 --> Email Class Initialized
INFO - 2026-02-22 00:23:22 --> Controller Class Initialized
ERROR - 2026-02-22 00:23:22 --> 404 Page Not Found: /index
INFO - 2026-02-22 00:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 00:23:22 --> Upload Class Initialized
DEBUG - 2026-02-22 00:23:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 00:23:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 00:23:22 --> Encryption Class Initialized
INFO - 2026-02-22 00:23:22 --> Form Validation Class Initialized
INFO - 2026-02-22 00:23:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 00:23:22 --> Pagination Class Initialized
INFO - 2026-02-22 00:23:22 --> Email Class Initialized
INFO - 2026-02-22 00:23:22 --> Controller Class Initialized
ERROR - 2026-02-22 00:23:22 --> 404 Page Not Found: /index
INFO - 2026-02-22 13:37:16 --> Config Class Initialized
INFO - 2026-02-22 13:37:16 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:37:16 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:37:16 --> Utf8 Class Initialized
INFO - 2026-02-22 13:37:16 --> URI Class Initialized
INFO - 2026-02-22 13:37:16 --> Router Class Initialized
INFO - 2026-02-22 13:37:16 --> Output Class Initialized
INFO - 2026-02-22 13:37:16 --> Security Class Initialized
DEBUG - 2026-02-22 13:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:37:16 --> CSRF cookie sent
INFO - 2026-02-22 13:37:16 --> Input Class Initialized
INFO - 2026-02-22 13:37:16 --> Language Class Initialized
INFO - 2026-02-22 13:37:16 --> Language Class Initialized
INFO - 2026-02-22 13:37:16 --> Config Class Initialized
INFO - 2026-02-22 13:37:16 --> Loader Class Initialized
INFO - 2026-02-22 13:37:16 --> Helper loaded: url_helper
INFO - 2026-02-22 13:37:16 --> Helper loaded: form_helper
INFO - 2026-02-22 13:37:16 --> Helper loaded: html_helper
INFO - 2026-02-22 13:37:16 --> Helper loaded: file_helper
INFO - 2026-02-22 13:37:16 --> Helper loaded: email_helper
INFO - 2026-02-22 13:37:16 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:37:16 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:37:16 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:37:16 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:37:16 --> Database Driver Class Initialized
INFO - 2026-02-22 13:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:37:20 --> Upload Class Initialized
DEBUG - 2026-02-22 13:37:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:37:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:37:20 --> Encryption Class Initialized
INFO - 2026-02-22 13:37:20 --> Form Validation Class Initialized
INFO - 2026-02-22 13:37:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:37:20 --> Pagination Class Initialized
INFO - 2026-02-22 13:37:20 --> Email Class Initialized
INFO - 2026-02-22 13:37:20 --> Controller Class Initialized
DEBUG - 2026-02-22 13:37:20 --> Dashboard MX_Controller Initialized
INFO - 2026-02-22 13:37:20 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:37:20 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:37:20 --> Config Class Initialized
INFO - 2026-02-22 13:37:20 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:37:20 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:37:20 --> Utf8 Class Initialized
INFO - 2026-02-22 13:37:20 --> URI Class Initialized
INFO - 2026-02-22 13:37:20 --> Router Class Initialized
INFO - 2026-02-22 13:37:20 --> Output Class Initialized
INFO - 2026-02-22 13:37:20 --> Security Class Initialized
DEBUG - 2026-02-22 13:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:37:20 --> CSRF cookie sent
INFO - 2026-02-22 13:37:20 --> Input Class Initialized
INFO - 2026-02-22 13:37:20 --> Language Class Initialized
INFO - 2026-02-22 13:37:20 --> Language Class Initialized
INFO - 2026-02-22 13:37:20 --> Config Class Initialized
INFO - 2026-02-22 13:37:20 --> Loader Class Initialized
INFO - 2026-02-22 13:37:20 --> Helper loaded: url_helper
INFO - 2026-02-22 13:37:20 --> Helper loaded: form_helper
INFO - 2026-02-22 13:37:20 --> Helper loaded: html_helper
INFO - 2026-02-22 13:37:20 --> Helper loaded: file_helper
INFO - 2026-02-22 13:37:20 --> Helper loaded: email_helper
INFO - 2026-02-22 13:37:20 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:37:20 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:37:20 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:37:20 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:37:20 --> Database Driver Class Initialized
INFO - 2026-02-22 13:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:37:23 --> Upload Class Initialized
DEBUG - 2026-02-22 13:37:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:37:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:37:23 --> Encryption Class Initialized
INFO - 2026-02-22 13:37:23 --> Form Validation Class Initialized
INFO - 2026-02-22 13:37:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:37:23 --> Pagination Class Initialized
INFO - 2026-02-22 13:37:23 --> Email Class Initialized
INFO - 2026-02-22 13:37:23 --> Controller Class Initialized
DEBUG - 2026-02-22 13:37:23 --> Authenticate MX_Controller Initialized
INFO - 2026-02-22 13:37:23 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:37:23 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:37:23 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-22 13:37:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
INFO - 2026-02-22 13:37:24 --> Model "Cart_model" initialized
DEBUG - 2026-02-22 13:37:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 13:37:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-02-22 13:37:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 13:37:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 13:37:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-02-22 13:37:24 --> Final output sent to browser
DEBUG - 2026-02-22 13:37:24 --> Total execution time: 3.9922
INFO - 2026-02-22 13:37:33 --> Config Class Initialized
INFO - 2026-02-22 13:37:33 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:37:33 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:37:33 --> Utf8 Class Initialized
INFO - 2026-02-22 13:37:33 --> URI Class Initialized
INFO - 2026-02-22 13:37:33 --> Router Class Initialized
INFO - 2026-02-22 13:37:33 --> Output Class Initialized
INFO - 2026-02-22 13:37:33 --> Security Class Initialized
DEBUG - 2026-02-22 13:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:37:33 --> CSRF cookie sent
INFO - 2026-02-22 13:37:33 --> CSRF token verified
INFO - 2026-02-22 13:37:33 --> Input Class Initialized
INFO - 2026-02-22 13:37:33 --> Language Class Initialized
INFO - 2026-02-22 13:37:33 --> Language Class Initialized
INFO - 2026-02-22 13:37:33 --> Config Class Initialized
INFO - 2026-02-22 13:37:33 --> Loader Class Initialized
INFO - 2026-02-22 13:37:33 --> Helper loaded: url_helper
INFO - 2026-02-22 13:37:33 --> Helper loaded: form_helper
INFO - 2026-02-22 13:37:33 --> Helper loaded: html_helper
INFO - 2026-02-22 13:37:33 --> Helper loaded: file_helper
INFO - 2026-02-22 13:37:33 --> Helper loaded: email_helper
INFO - 2026-02-22 13:37:33 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:37:33 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:37:33 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:37:33 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:37:33 --> Database Driver Class Initialized
INFO - 2026-02-22 13:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:37:36 --> Upload Class Initialized
DEBUG - 2026-02-22 13:37:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:37:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:37:36 --> Encryption Class Initialized
INFO - 2026-02-22 13:37:36 --> Form Validation Class Initialized
INFO - 2026-02-22 13:37:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:37:36 --> Pagination Class Initialized
INFO - 2026-02-22 13:37:36 --> Email Class Initialized
INFO - 2026-02-22 13:37:36 --> Controller Class Initialized
DEBUG - 2026-02-22 13:37:36 --> Authenticate MX_Controller Initialized
INFO - 2026-02-22 13:37:36 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:37:36 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:37:36 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 13:44:08 --> Config Class Initialized
INFO - 2026-02-22 13:44:08 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:44:08 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:44:08 --> Utf8 Class Initialized
INFO - 2026-02-22 13:44:08 --> URI Class Initialized
INFO - 2026-02-22 13:44:08 --> Router Class Initialized
INFO - 2026-02-22 13:44:08 --> Output Class Initialized
INFO - 2026-02-22 13:44:08 --> Security Class Initialized
DEBUG - 2026-02-22 13:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:44:08 --> CSRF cookie sent
INFO - 2026-02-22 13:44:08 --> Input Class Initialized
INFO - 2026-02-22 13:44:08 --> Language Class Initialized
INFO - 2026-02-22 13:44:08 --> Language Class Initialized
INFO - 2026-02-22 13:44:08 --> Config Class Initialized
INFO - 2026-02-22 13:44:08 --> Loader Class Initialized
INFO - 2026-02-22 13:44:08 --> Helper loaded: url_helper
INFO - 2026-02-22 13:44:08 --> Helper loaded: form_helper
INFO - 2026-02-22 13:44:08 --> Helper loaded: html_helper
INFO - 2026-02-22 13:44:08 --> Helper loaded: file_helper
INFO - 2026-02-22 13:44:08 --> Helper loaded: email_helper
INFO - 2026-02-22 13:44:08 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:44:08 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:44:08 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:44:08 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:44:08 --> Database Driver Class Initialized
INFO - 2026-02-22 13:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:46:20 --> Upload Class Initialized
DEBUG - 2026-02-22 13:46:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:46:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:46:20 --> Encryption Class Initialized
INFO - 2026-02-22 13:46:20 --> Form Validation Class Initialized
INFO - 2026-02-22 13:46:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:46:20 --> Pagination Class Initialized
INFO - 2026-02-22 13:46:20 --> Email Class Initialized
INFO - 2026-02-22 13:46:20 --> Controller Class Initialized
DEBUG - 2026-02-22 13:46:20 --> Authenticate MX_Controller Initialized
INFO - 2026-02-22 13:46:20 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:46:20 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:46:20 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 13:46:22 --> Config Class Initialized
INFO - 2026-02-22 13:46:22 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:46:22 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:46:22 --> Utf8 Class Initialized
INFO - 2026-02-22 13:46:22 --> URI Class Initialized
INFO - 2026-02-22 13:46:22 --> Router Class Initialized
INFO - 2026-02-22 13:46:22 --> Output Class Initialized
INFO - 2026-02-22 13:46:22 --> Security Class Initialized
DEBUG - 2026-02-22 13:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:46:22 --> CSRF cookie sent
INFO - 2026-02-22 13:46:22 --> Input Class Initialized
INFO - 2026-02-22 13:46:22 --> Language Class Initialized
INFO - 2026-02-22 13:46:22 --> Language Class Initialized
INFO - 2026-02-22 13:46:22 --> Config Class Initialized
INFO - 2026-02-22 13:46:22 --> Loader Class Initialized
INFO - 2026-02-22 13:46:22 --> Helper loaded: url_helper
INFO - 2026-02-22 13:46:22 --> Helper loaded: form_helper
INFO - 2026-02-22 13:46:22 --> Helper loaded: html_helper
INFO - 2026-02-22 13:46:22 --> Helper loaded: file_helper
INFO - 2026-02-22 13:46:22 --> Helper loaded: email_helper
INFO - 2026-02-22 13:46:22 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:46:22 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:46:22 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:46:22 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:46:22 --> Database Driver Class Initialized
INFO - 2026-02-22 13:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:46:24 --> Upload Class Initialized
DEBUG - 2026-02-22 13:46:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:46:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:46:24 --> Encryption Class Initialized
INFO - 2026-02-22 13:46:24 --> Form Validation Class Initialized
INFO - 2026-02-22 13:46:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:46:24 --> Pagination Class Initialized
INFO - 2026-02-22 13:46:24 --> Email Class Initialized
INFO - 2026-02-22 13:46:24 --> Controller Class Initialized
DEBUG - 2026-02-22 13:46:24 --> Authenticate MX_Controller Initialized
INFO - 2026-02-22 13:46:24 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:46:24 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:46:24 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-22 13:46:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 13:46:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 13:46:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-02-22 13:46:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 13:46:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 13:46:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-02-22 13:46:24 --> Final output sent to browser
DEBUG - 2026-02-22 13:46:24 --> Total execution time: 2.2119
INFO - 2026-02-22 13:46:27 --> Config Class Initialized
INFO - 2026-02-22 13:46:27 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:46:27 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:46:27 --> Utf8 Class Initialized
INFO - 2026-02-22 13:46:27 --> URI Class Initialized
INFO - 2026-02-22 13:46:27 --> Router Class Initialized
INFO - 2026-02-22 13:46:27 --> Output Class Initialized
INFO - 2026-02-22 13:46:27 --> Security Class Initialized
DEBUG - 2026-02-22 13:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:46:27 --> CSRF cookie sent
INFO - 2026-02-22 13:46:27 --> Input Class Initialized
INFO - 2026-02-22 13:46:27 --> Language Class Initialized
INFO - 2026-02-22 13:46:27 --> Language Class Initialized
INFO - 2026-02-22 13:46:27 --> Config Class Initialized
INFO - 2026-02-22 13:46:27 --> Loader Class Initialized
INFO - 2026-02-22 13:46:27 --> Helper loaded: url_helper
INFO - 2026-02-22 13:46:27 --> Helper loaded: form_helper
INFO - 2026-02-22 13:46:27 --> Helper loaded: html_helper
INFO - 2026-02-22 13:46:27 --> Helper loaded: file_helper
INFO - 2026-02-22 13:46:27 --> Helper loaded: email_helper
INFO - 2026-02-22 13:46:27 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:46:27 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:46:27 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:46:27 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:46:27 --> Database Driver Class Initialized
INFO - 2026-02-22 13:46:29 --> Config Class Initialized
INFO - 2026-02-22 13:46:29 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:46:29 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:46:29 --> Utf8 Class Initialized
INFO - 2026-02-22 13:46:29 --> URI Class Initialized
INFO - 2026-02-22 13:46:29 --> Router Class Initialized
INFO - 2026-02-22 13:46:29 --> Output Class Initialized
INFO - 2026-02-22 13:46:29 --> Security Class Initialized
DEBUG - 2026-02-22 13:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:46:29 --> CSRF cookie sent
INFO - 2026-02-22 13:46:29 --> Input Class Initialized
INFO - 2026-02-22 13:46:29 --> Language Class Initialized
INFO - 2026-02-22 13:46:29 --> Language Class Initialized
INFO - 2026-02-22 13:46:29 --> Config Class Initialized
INFO - 2026-02-22 13:46:29 --> Loader Class Initialized
INFO - 2026-02-22 13:46:29 --> Helper loaded: url_helper
INFO - 2026-02-22 13:46:29 --> Helper loaded: form_helper
INFO - 2026-02-22 13:46:29 --> Helper loaded: html_helper
INFO - 2026-02-22 13:46:29 --> Helper loaded: file_helper
INFO - 2026-02-22 13:46:29 --> Helper loaded: email_helper
INFO - 2026-02-22 13:46:29 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:46:29 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:46:29 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:46:29 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:46:29 --> Database Driver Class Initialized
INFO - 2026-02-22 13:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:46:29 --> Upload Class Initialized
DEBUG - 2026-02-22 13:46:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:46:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:46:29 --> Encryption Class Initialized
INFO - 2026-02-22 13:46:29 --> Form Validation Class Initialized
INFO - 2026-02-22 13:46:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:46:29 --> Pagination Class Initialized
INFO - 2026-02-22 13:46:29 --> Email Class Initialized
INFO - 2026-02-22 13:46:29 --> Controller Class Initialized
DEBUG - 2026-02-22 13:46:29 --> Authenticate MX_Controller Initialized
INFO - 2026-02-22 13:46:29 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:46:29 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:46:29 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-22 13:46:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 13:46:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 13:46:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-02-22 13:46:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 13:46:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 13:46:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-02-22 13:46:29 --> Final output sent to browser
DEBUG - 2026-02-22 13:46:29 --> Total execution time: 2.6062
INFO - 2026-02-22 13:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:46:31 --> Upload Class Initialized
DEBUG - 2026-02-22 13:46:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:46:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:46:31 --> Encryption Class Initialized
INFO - 2026-02-22 13:46:31 --> Form Validation Class Initialized
INFO - 2026-02-22 13:46:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:46:31 --> Pagination Class Initialized
INFO - 2026-02-22 13:46:31 --> Email Class Initialized
INFO - 2026-02-22 13:46:31 --> Controller Class Initialized
DEBUG - 2026-02-22 13:46:31 --> Authenticate MX_Controller Initialized
INFO - 2026-02-22 13:46:31 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:46:31 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:46:31 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-22 13:46:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 13:46:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 13:46:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-02-22 13:46:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 13:46:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 13:46:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-02-22 13:46:32 --> Final output sent to browser
DEBUG - 2026-02-22 13:46:32 --> Total execution time: 2.6678
INFO - 2026-02-22 13:46:34 --> Config Class Initialized
INFO - 2026-02-22 13:46:34 --> Hooks Class Initialized
INFO - 2026-02-22 13:46:34 --> Config Class Initialized
INFO - 2026-02-22 13:46:34 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:46:34 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:46:34 --> Utf8 Class Initialized
INFO - 2026-02-22 13:46:34 --> URI Class Initialized
DEBUG - 2026-02-22 13:46:34 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:46:34 --> Utf8 Class Initialized
INFO - 2026-02-22 13:46:34 --> URI Class Initialized
INFO - 2026-02-22 13:46:34 --> Router Class Initialized
INFO - 2026-02-22 13:46:34 --> Config Class Initialized
INFO - 2026-02-22 13:46:34 --> Router Class Initialized
INFO - 2026-02-22 13:46:34 --> Hooks Class Initialized
INFO - 2026-02-22 13:46:34 --> Output Class Initialized
DEBUG - 2026-02-22 13:46:34 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:46:34 --> Utf8 Class Initialized
INFO - 2026-02-22 13:46:34 --> Output Class Initialized
INFO - 2026-02-22 13:46:34 --> Security Class Initialized
INFO - 2026-02-22 13:46:34 --> URI Class Initialized
DEBUG - 2026-02-22 13:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:46:34 --> Security Class Initialized
INFO - 2026-02-22 13:46:34 --> CSRF cookie sent
INFO - 2026-02-22 13:46:34 --> Input Class Initialized
INFO - 2026-02-22 13:46:34 --> Language Class Initialized
INFO - 2026-02-22 13:46:34 --> Router Class Initialized
INFO - 2026-02-22 13:46:34 --> Language Class Initialized
INFO - 2026-02-22 13:46:34 --> Config Class Initialized
DEBUG - 2026-02-22 13:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:46:34 --> CSRF cookie sent
INFO - 2026-02-22 13:46:34 --> Input Class Initialized
INFO - 2026-02-22 13:46:34 --> Language Class Initialized
INFO - 2026-02-22 13:46:34 --> Output Class Initialized
INFO - 2026-02-22 13:46:34 --> Language Class Initialized
INFO - 2026-02-22 13:46:34 --> Config Class Initialized
INFO - 2026-02-22 13:46:34 --> Security Class Initialized
DEBUG - 2026-02-22 13:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:46:34 --> CSRF cookie sent
INFO - 2026-02-22 13:46:34 --> Input Class Initialized
INFO - 2026-02-22 13:46:34 --> Loader Class Initialized
INFO - 2026-02-22 13:46:34 --> Language Class Initialized
INFO - 2026-02-22 13:46:34 --> Language Class Initialized
INFO - 2026-02-22 13:46:34 --> Config Class Initialized
INFO - 2026-02-22 13:46:34 --> Helper loaded: url_helper
INFO - 2026-02-22 13:46:34 --> Loader Class Initialized
INFO - 2026-02-22 13:46:34 --> Helper loaded: form_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: html_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: url_helper
INFO - 2026-02-22 13:46:34 --> Loader Class Initialized
INFO - 2026-02-22 13:46:34 --> Helper loaded: file_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: email_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: url_helper
INFO - 2026-02-22 13:46:34 --> Config Class Initialized
INFO - 2026-02-22 13:46:34 --> Hooks Class Initialized
INFO - 2026-02-22 13:46:34 --> Helper loaded: form_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: form_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: html_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: html_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: file_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: email_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: ssp_helper
DEBUG - 2026-02-22 13:46:34 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:46:34 --> Utf8 Class Initialized
INFO - 2026-02-22 13:46:34 --> Helper loaded: file_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: email_helper
INFO - 2026-02-22 13:46:34 --> URI Class Initialized
INFO - 2026-02-22 13:46:34 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:46:34 --> Router Class Initialized
INFO - 2026-02-22 13:46:34 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:46:34 --> Config Class Initialized
INFO - 2026-02-22 13:46:34 --> Hooks Class Initialized
INFO - 2026-02-22 13:46:34 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:46:34 --> Output Class Initialized
INFO - 2026-02-22 13:46:34 --> Helper loaded: domain_helper
DEBUG - 2026-02-22 13:46:34 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:46:34 --> Utf8 Class Initialized
INFO - 2026-02-22 13:46:34 --> Security Class Initialized
INFO - 2026-02-22 13:46:34 --> URI Class Initialized
DEBUG - 2026-02-22 13:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:46:34 --> CSRF cookie sent
INFO - 2026-02-22 13:46:34 --> Input Class Initialized
INFO - 2026-02-22 13:46:34 --> Language Class Initialized
INFO - 2026-02-22 13:46:34 --> Language Class Initialized
INFO - 2026-02-22 13:46:34 --> Config Class Initialized
INFO - 2026-02-22 13:46:34 --> Router Class Initialized
INFO - 2026-02-22 13:46:34 --> Database Driver Class Initialized
INFO - 2026-02-22 13:46:34 --> Database Driver Class Initialized
INFO - 2026-02-22 13:46:34 --> Loader Class Initialized
INFO - 2026-02-22 13:46:34 --> Database Driver Class Initialized
INFO - 2026-02-22 13:46:34 --> Helper loaded: url_helper
INFO - 2026-02-22 13:46:34 --> Config Class Initialized
INFO - 2026-02-22 13:46:34 --> Hooks Class Initialized
INFO - 2026-02-22 13:46:34 --> Helper loaded: form_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: html_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: file_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: email_helper
DEBUG - 2026-02-22 13:46:34 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:46:34 --> Utf8 Class Initialized
INFO - 2026-02-22 13:46:34 --> Output Class Initialized
INFO - 2026-02-22 13:46:34 --> URI Class Initialized
INFO - 2026-02-22 13:46:34 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:46:34 --> Security Class Initialized
INFO - 2026-02-22 13:46:34 --> Helper loaded: ssp_helper
DEBUG - 2026-02-22 13:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:46:34 --> CSRF cookie sent
INFO - 2026-02-22 13:46:34 --> Input Class Initialized
INFO - 2026-02-22 13:46:34 --> Language Class Initialized
INFO - 2026-02-22 13:46:34 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:46:34 --> Router Class Initialized
INFO - 2026-02-22 13:46:34 --> Language Class Initialized
INFO - 2026-02-22 13:46:34 --> Config Class Initialized
INFO - 2026-02-22 13:46:34 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:46:34 --> Output Class Initialized
INFO - 2026-02-22 13:46:34 --> Loader Class Initialized
INFO - 2026-02-22 13:46:34 --> Security Class Initialized
INFO - 2026-02-22 13:46:34 --> Helper loaded: url_helper
DEBUG - 2026-02-22 13:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:46:34 --> CSRF cookie sent
INFO - 2026-02-22 13:46:34 --> Input Class Initialized
INFO - 2026-02-22 13:46:34 --> Language Class Initialized
INFO - 2026-02-22 13:46:34 --> Helper loaded: form_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: html_helper
INFO - 2026-02-22 13:46:34 --> Language Class Initialized
INFO - 2026-02-22 13:46:34 --> Config Class Initialized
INFO - 2026-02-22 13:46:34 --> Helper loaded: file_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: email_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:46:34 --> Database Driver Class Initialized
INFO - 2026-02-22 13:46:34 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:46:34 --> Loader Class Initialized
INFO - 2026-02-22 13:46:34 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: url_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: form_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: html_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: file_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: email_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:46:34 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:46:34 --> Database Driver Class Initialized
INFO - 2026-02-22 13:46:34 --> Database Driver Class Initialized
INFO - 2026-02-22 13:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:46:36 --> Upload Class Initialized
DEBUG - 2026-02-22 13:46:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:46:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:46:36 --> Encryption Class Initialized
INFO - 2026-02-22 13:46:36 --> Form Validation Class Initialized
INFO - 2026-02-22 13:46:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:46:36 --> Pagination Class Initialized
INFO - 2026-02-22 13:46:36 --> Email Class Initialized
INFO - 2026-02-22 13:46:36 --> Controller Class Initialized
ERROR - 2026-02-22 13:46:36 --> 404 Page Not Found: /index
INFO - 2026-02-22 13:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:46:36 --> Upload Class Initialized
DEBUG - 2026-02-22 13:46:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:46:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:46:36 --> Encryption Class Initialized
INFO - 2026-02-22 13:46:36 --> Form Validation Class Initialized
INFO - 2026-02-22 13:46:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:46:36 --> Pagination Class Initialized
INFO - 2026-02-22 13:46:36 --> Config Class Initialized
INFO - 2026-02-22 13:46:36 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:46:36 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:46:36 --> Utf8 Class Initialized
INFO - 2026-02-22 13:46:36 --> URI Class Initialized
INFO - 2026-02-22 13:46:36 --> Email Class Initialized
INFO - 2026-02-22 13:46:36 --> Controller Class Initialized
ERROR - 2026-02-22 13:46:36 --> 404 Page Not Found: /index
INFO - 2026-02-22 13:46:36 --> Router Class Initialized
INFO - 2026-02-22 13:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:46:36 --> Output Class Initialized
INFO - 2026-02-22 13:46:36 --> Upload Class Initialized
INFO - 2026-02-22 13:46:36 --> Security Class Initialized
DEBUG - 2026-02-22 13:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:46:36 --> CSRF cookie sent
INFO - 2026-02-22 13:46:36 --> Input Class Initialized
DEBUG - 2026-02-22 13:46:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:46:36 --> Language Class Initialized
INFO - 2026-02-22 13:46:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:46:36 --> Encryption Class Initialized
INFO - 2026-02-22 13:46:36 --> Language Class Initialized
INFO - 2026-02-22 13:46:36 --> Config Class Initialized
INFO - 2026-02-22 13:46:36 --> Form Validation Class Initialized
INFO - 2026-02-22 13:46:36 --> Loader Class Initialized
INFO - 2026-02-22 13:46:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:46:36 --> Pagination Class Initialized
INFO - 2026-02-22 13:46:36 --> Helper loaded: url_helper
INFO - 2026-02-22 13:46:36 --> Helper loaded: form_helper
INFO - 2026-02-22 13:46:36 --> Helper loaded: html_helper
INFO - 2026-02-22 13:46:36 --> Config Class Initialized
INFO - 2026-02-22 13:46:36 --> Hooks Class Initialized
INFO - 2026-02-22 13:46:36 --> Helper loaded: file_helper
INFO - 2026-02-22 13:46:36 --> Helper loaded: email_helper
INFO - 2026-02-22 13:46:36 --> Helper loaded: whmaz_helper
DEBUG - 2026-02-22 13:46:36 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:46:36 --> Utf8 Class Initialized
INFO - 2026-02-22 13:46:36 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:46:36 --> Email Class Initialized
INFO - 2026-02-22 13:46:36 --> URI Class Initialized
INFO - 2026-02-22 13:46:36 --> Controller Class Initialized
INFO - 2026-02-22 13:46:36 --> Helper loaded: cpanel_helper
ERROR - 2026-02-22 13:46:36 --> 404 Page Not Found: /index
INFO - 2026-02-22 13:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:46:36 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:46:36 --> Router Class Initialized
INFO - 2026-02-22 13:46:36 --> Upload Class Initialized
INFO - 2026-02-22 13:46:36 --> Output Class Initialized
DEBUG - 2026-02-22 13:46:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:46:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:46:36 --> Encryption Class Initialized
INFO - 2026-02-22 13:46:36 --> Security Class Initialized
DEBUG - 2026-02-22 13:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:46:36 --> CSRF cookie sent
INFO - 2026-02-22 13:46:36 --> Input Class Initialized
INFO - 2026-02-22 13:46:36 --> Language Class Initialized
INFO - 2026-02-22 13:46:36 --> Form Validation Class Initialized
INFO - 2026-02-22 13:46:36 --> Database Driver Class Initialized
INFO - 2026-02-22 13:46:36 --> Language Class Initialized
INFO - 2026-02-22 13:46:36 --> Config Class Initialized
INFO - 2026-02-22 13:46:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:46:36 --> Pagination Class Initialized
INFO - 2026-02-22 13:46:36 --> Loader Class Initialized
INFO - 2026-02-22 13:46:36 --> Helper loaded: url_helper
INFO - 2026-02-22 13:46:36 --> Email Class Initialized
INFO - 2026-02-22 13:46:36 --> Controller Class Initialized
INFO - 2026-02-22 13:46:36 --> Helper loaded: form_helper
ERROR - 2026-02-22 13:46:36 --> 404 Page Not Found: /index
INFO - 2026-02-22 13:46:36 --> Helper loaded: html_helper
INFO - 2026-02-22 13:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:46:36 --> Helper loaded: file_helper
INFO - 2026-02-22 13:46:36 --> Helper loaded: email_helper
INFO - 2026-02-22 13:46:36 --> Upload Class Initialized
INFO - 2026-02-22 13:46:36 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:46:36 --> Helper loaded: ssp_helper
DEBUG - 2026-02-22 13:46:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:46:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:46:36 --> Encryption Class Initialized
INFO - 2026-02-22 13:46:36 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:46:36 --> Form Validation Class Initialized
INFO - 2026-02-22 13:46:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:46:36 --> Pagination Class Initialized
INFO - 2026-02-22 13:46:36 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:46:36 --> Email Class Initialized
INFO - 2026-02-22 13:46:36 --> Controller Class Initialized
ERROR - 2026-02-22 13:46:36 --> 404 Page Not Found: /index
INFO - 2026-02-22 13:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:46:36 --> Upload Class Initialized
DEBUG - 2026-02-22 13:46:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:46:36 --> Database Driver Class Initialized
INFO - 2026-02-22 13:46:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:46:36 --> Encryption Class Initialized
INFO - 2026-02-22 13:46:36 --> Form Validation Class Initialized
INFO - 2026-02-22 13:46:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:46:36 --> Pagination Class Initialized
INFO - 2026-02-22 13:46:36 --> Email Class Initialized
INFO - 2026-02-22 13:46:36 --> Controller Class Initialized
ERROR - 2026-02-22 13:46:36 --> 404 Page Not Found: /index
INFO - 2026-02-22 13:46:38 --> Config Class Initialized
INFO - 2026-02-22 13:46:38 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:46:38 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:46:38 --> Utf8 Class Initialized
INFO - 2026-02-22 13:46:38 --> URI Class Initialized
INFO - 2026-02-22 13:46:38 --> Router Class Initialized
INFO - 2026-02-22 13:46:38 --> Output Class Initialized
INFO - 2026-02-22 13:46:38 --> Security Class Initialized
DEBUG - 2026-02-22 13:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:46:38 --> CSRF cookie sent
INFO - 2026-02-22 13:46:38 --> Input Class Initialized
INFO - 2026-02-22 13:46:38 --> Language Class Initialized
INFO - 2026-02-22 13:46:38 --> Language Class Initialized
INFO - 2026-02-22 13:46:38 --> Config Class Initialized
INFO - 2026-02-22 13:46:38 --> Loader Class Initialized
INFO - 2026-02-22 13:46:38 --> Helper loaded: url_helper
INFO - 2026-02-22 13:46:38 --> Helper loaded: form_helper
INFO - 2026-02-22 13:46:38 --> Helper loaded: html_helper
INFO - 2026-02-22 13:46:38 --> Helper loaded: file_helper
INFO - 2026-02-22 13:46:38 --> Helper loaded: email_helper
INFO - 2026-02-22 13:46:38 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:46:38 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:46:38 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:46:38 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:46:38 --> Database Driver Class Initialized
INFO - 2026-02-22 13:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:46:38 --> Upload Class Initialized
DEBUG - 2026-02-22 13:46:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:46:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:46:38 --> Encryption Class Initialized
INFO - 2026-02-22 13:46:38 --> Form Validation Class Initialized
INFO - 2026-02-22 13:46:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:46:38 --> Pagination Class Initialized
INFO - 2026-02-22 13:46:38 --> Email Class Initialized
INFO - 2026-02-22 13:46:38 --> Controller Class Initialized
ERROR - 2026-02-22 13:46:38 --> 404 Page Not Found: /index
INFO - 2026-02-22 13:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:46:39 --> Upload Class Initialized
DEBUG - 2026-02-22 13:46:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:46:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:46:39 --> Encryption Class Initialized
INFO - 2026-02-22 13:46:39 --> Form Validation Class Initialized
INFO - 2026-02-22 13:46:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:46:39 --> Pagination Class Initialized
INFO - 2026-02-22 13:46:39 --> Email Class Initialized
INFO - 2026-02-22 13:46:39 --> Controller Class Initialized
ERROR - 2026-02-22 13:46:39 --> 404 Page Not Found: /index
INFO - 2026-02-22 13:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:46:40 --> Upload Class Initialized
DEBUG - 2026-02-22 13:46:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:46:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:46:40 --> Encryption Class Initialized
INFO - 2026-02-22 13:46:40 --> Form Validation Class Initialized
INFO - 2026-02-22 13:46:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:46:40 --> Pagination Class Initialized
INFO - 2026-02-22 13:46:40 --> Email Class Initialized
INFO - 2026-02-22 13:46:40 --> Controller Class Initialized
DEBUG - 2026-02-22 13:46:40 --> Authenticate MX_Controller Initialized
INFO - 2026-02-22 13:46:40 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:46:40 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:46:40 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-22 13:46:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 13:46:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 13:46:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-02-22 13:46:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 13:46:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 13:46:40 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-02-22 13:46:40 --> Final output sent to browser
DEBUG - 2026-02-22 13:46:40 --> Total execution time: 2.7028
INFO - 2026-02-22 13:46:41 --> Config Class Initialized
INFO - 2026-02-22 13:46:41 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:46:41 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:46:41 --> Utf8 Class Initialized
INFO - 2026-02-22 13:46:41 --> URI Class Initialized
INFO - 2026-02-22 13:46:41 --> Config Class Initialized
INFO - 2026-02-22 13:46:41 --> Hooks Class Initialized
INFO - 2026-02-22 13:46:41 --> Router Class Initialized
DEBUG - 2026-02-22 13:46:41 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:46:41 --> Utf8 Class Initialized
INFO - 2026-02-22 13:46:41 --> Output Class Initialized
INFO - 2026-02-22 13:46:41 --> URI Class Initialized
INFO - 2026-02-22 13:46:41 --> Security Class Initialized
DEBUG - 2026-02-22 13:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:46:41 --> Router Class Initialized
INFO - 2026-02-22 13:46:41 --> CSRF cookie sent
INFO - 2026-02-22 13:46:41 --> Input Class Initialized
INFO - 2026-02-22 13:46:41 --> Language Class Initialized
INFO - 2026-02-22 13:46:41 --> Language Class Initialized
INFO - 2026-02-22 13:46:41 --> Config Class Initialized
INFO - 2026-02-22 13:46:41 --> Output Class Initialized
INFO - 2026-02-22 13:46:41 --> Security Class Initialized
INFO - 2026-02-22 13:46:41 --> Loader Class Initialized
INFO - 2026-02-22 13:46:41 --> Helper loaded: url_helper
DEBUG - 2026-02-22 13:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:46:41 --> CSRF cookie sent
INFO - 2026-02-22 13:46:41 --> Input Class Initialized
INFO - 2026-02-22 13:46:41 --> Language Class Initialized
INFO - 2026-02-22 13:46:41 --> Helper loaded: form_helper
INFO - 2026-02-22 13:46:41 --> Language Class Initialized
INFO - 2026-02-22 13:46:41 --> Config Class Initialized
INFO - 2026-02-22 13:46:41 --> Helper loaded: html_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: file_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: email_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:46:41 --> Loader Class Initialized
INFO - 2026-02-22 13:46:41 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: url_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: form_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: html_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: file_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: email_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:46:41 --> Database Driver Class Initialized
INFO - 2026-02-22 13:46:41 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:46:41 --> Database Driver Class Initialized
INFO - 2026-02-22 13:46:41 --> Config Class Initialized
INFO - 2026-02-22 13:46:41 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:46:41 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:46:41 --> Utf8 Class Initialized
INFO - 2026-02-22 13:46:41 --> URI Class Initialized
INFO - 2026-02-22 13:46:41 --> Router Class Initialized
INFO - 2026-02-22 13:46:41 --> Output Class Initialized
INFO - 2026-02-22 13:46:41 --> Security Class Initialized
DEBUG - 2026-02-22 13:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:46:41 --> CSRF cookie sent
INFO - 2026-02-22 13:46:41 --> Input Class Initialized
INFO - 2026-02-22 13:46:41 --> Language Class Initialized
INFO - 2026-02-22 13:46:41 --> Language Class Initialized
INFO - 2026-02-22 13:46:41 --> Config Class Initialized
INFO - 2026-02-22 13:46:41 --> Loader Class Initialized
INFO - 2026-02-22 13:46:41 --> Helper loaded: url_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: form_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: html_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: file_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: email_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:46:41 --> Config Class Initialized
INFO - 2026-02-22 13:46:41 --> Hooks Class Initialized
INFO - 2026-02-22 13:46:41 --> Helper loaded: cpanel_helper
DEBUG - 2026-02-22 13:46:41 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:46:41 --> Utf8 Class Initialized
INFO - 2026-02-22 13:46:41 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:46:41 --> URI Class Initialized
INFO - 2026-02-22 13:46:41 --> Router Class Initialized
INFO - 2026-02-22 13:46:41 --> Output Class Initialized
INFO - 2026-02-22 13:46:41 --> Database Driver Class Initialized
INFO - 2026-02-22 13:46:41 --> Security Class Initialized
DEBUG - 2026-02-22 13:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:46:41 --> CSRF cookie sent
INFO - 2026-02-22 13:46:41 --> Input Class Initialized
INFO - 2026-02-22 13:46:41 --> Language Class Initialized
INFO - 2026-02-22 13:46:41 --> Language Class Initialized
INFO - 2026-02-22 13:46:41 --> Config Class Initialized
INFO - 2026-02-22 13:46:41 --> Loader Class Initialized
INFO - 2026-02-22 13:46:41 --> Helper loaded: url_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: form_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: html_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: file_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: email_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:46:41 --> Database Driver Class Initialized
INFO - 2026-02-22 13:46:41 --> Config Class Initialized
INFO - 2026-02-22 13:46:41 --> Hooks Class Initialized
INFO - 2026-02-22 13:46:41 --> Config Class Initialized
INFO - 2026-02-22 13:46:41 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:46:41 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:46:41 --> Utf8 Class Initialized
DEBUG - 2026-02-22 13:46:41 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:46:41 --> Utf8 Class Initialized
INFO - 2026-02-22 13:46:41 --> URI Class Initialized
INFO - 2026-02-22 13:46:41 --> URI Class Initialized
INFO - 2026-02-22 13:46:41 --> Router Class Initialized
INFO - 2026-02-22 13:46:41 --> Router Class Initialized
INFO - 2026-02-22 13:46:41 --> Output Class Initialized
INFO - 2026-02-22 13:46:41 --> Output Class Initialized
INFO - 2026-02-22 13:46:41 --> Security Class Initialized
INFO - 2026-02-22 13:46:41 --> Security Class Initialized
DEBUG - 2026-02-22 13:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:46:41 --> CSRF cookie sent
DEBUG - 2026-02-22 13:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:46:41 --> Input Class Initialized
INFO - 2026-02-22 13:46:41 --> CSRF cookie sent
INFO - 2026-02-22 13:46:41 --> Input Class Initialized
INFO - 2026-02-22 13:46:41 --> Language Class Initialized
INFO - 2026-02-22 13:46:41 --> Language Class Initialized
INFO - 2026-02-22 13:46:41 --> Language Class Initialized
INFO - 2026-02-22 13:46:41 --> Language Class Initialized
INFO - 2026-02-22 13:46:41 --> Config Class Initialized
INFO - 2026-02-22 13:46:41 --> Config Class Initialized
INFO - 2026-02-22 13:46:41 --> Loader Class Initialized
INFO - 2026-02-22 13:46:41 --> Loader Class Initialized
INFO - 2026-02-22 13:46:41 --> Helper loaded: url_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: url_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: form_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: form_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: html_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: html_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: file_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: email_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: file_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: email_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:46:41 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:46:41 --> Database Driver Class Initialized
INFO - 2026-02-22 13:46:41 --> Database Driver Class Initialized
INFO - 2026-02-22 13:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:46:43 --> Upload Class Initialized
DEBUG - 2026-02-22 13:46:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:46:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:46:43 --> Encryption Class Initialized
INFO - 2026-02-22 13:46:43 --> Form Validation Class Initialized
INFO - 2026-02-22 13:46:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:46:43 --> Pagination Class Initialized
INFO - 2026-02-22 13:46:43 --> Email Class Initialized
INFO - 2026-02-22 13:46:43 --> Controller Class Initialized
ERROR - 2026-02-22 13:46:43 --> 404 Page Not Found: /index
INFO - 2026-02-22 13:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:46:43 --> Upload Class Initialized
DEBUG - 2026-02-22 13:46:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:46:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:46:43 --> Encryption Class Initialized
INFO - 2026-02-22 13:46:43 --> Form Validation Class Initialized
INFO - 2026-02-22 13:46:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:46:43 --> Pagination Class Initialized
INFO - 2026-02-22 13:46:43 --> Config Class Initialized
INFO - 2026-02-22 13:46:43 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:46:43 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:46:43 --> Utf8 Class Initialized
INFO - 2026-02-22 13:46:43 --> URI Class Initialized
INFO - 2026-02-22 13:46:43 --> Email Class Initialized
INFO - 2026-02-22 13:46:43 --> Controller Class Initialized
ERROR - 2026-02-22 13:46:43 --> 404 Page Not Found: /index
INFO - 2026-02-22 13:46:43 --> Router Class Initialized
INFO - 2026-02-22 13:46:43 --> Output Class Initialized
INFO - 2026-02-22 13:46:43 --> Security Class Initialized
DEBUG - 2026-02-22 13:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:46:43 --> CSRF cookie sent
INFO - 2026-02-22 13:46:43 --> Input Class Initialized
INFO - 2026-02-22 13:46:43 --> Language Class Initialized
INFO - 2026-02-22 13:46:43 --> Language Class Initialized
INFO - 2026-02-22 13:46:43 --> Config Class Initialized
INFO - 2026-02-22 13:46:43 --> Loader Class Initialized
INFO - 2026-02-22 13:46:43 --> Config Class Initialized
INFO - 2026-02-22 13:46:43 --> Hooks Class Initialized
INFO - 2026-02-22 13:46:43 --> Helper loaded: url_helper
DEBUG - 2026-02-22 13:46:43 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:46:43 --> Utf8 Class Initialized
INFO - 2026-02-22 13:46:43 --> Helper loaded: form_helper
INFO - 2026-02-22 13:46:43 --> URI Class Initialized
INFO - 2026-02-22 13:46:43 --> Helper loaded: html_helper
INFO - 2026-02-22 13:46:43 --> Helper loaded: file_helper
INFO - 2026-02-22 13:46:43 --> Helper loaded: email_helper
INFO - 2026-02-22 13:46:43 --> Router Class Initialized
INFO - 2026-02-22 13:46:43 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:46:43 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:46:43 --> Output Class Initialized
INFO - 2026-02-22 13:46:43 --> Security Class Initialized
INFO - 2026-02-22 13:46:43 --> Helper loaded: cpanel_helper
DEBUG - 2026-02-22 13:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:46:43 --> CSRF cookie sent
INFO - 2026-02-22 13:46:43 --> Input Class Initialized
INFO - 2026-02-22 13:46:43 --> Language Class Initialized
INFO - 2026-02-22 13:46:43 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:46:43 --> Language Class Initialized
INFO - 2026-02-22 13:46:43 --> Config Class Initialized
INFO - 2026-02-22 13:46:43 --> Loader Class Initialized
INFO - 2026-02-22 13:46:43 --> Helper loaded: url_helper
INFO - 2026-02-22 13:46:43 --> Helper loaded: form_helper
INFO - 2026-02-22 13:46:43 --> Helper loaded: html_helper
INFO - 2026-02-22 13:46:43 --> Helper loaded: file_helper
INFO - 2026-02-22 13:46:43 --> Helper loaded: email_helper
INFO - 2026-02-22 13:46:43 --> Database Driver Class Initialized
INFO - 2026-02-22 13:46:43 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:46:43 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:46:43 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:46:43 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:46:43 --> Database Driver Class Initialized
INFO - 2026-02-22 13:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:46:43 --> Upload Class Initialized
DEBUG - 2026-02-22 13:46:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:46:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:46:43 --> Encryption Class Initialized
INFO - 2026-02-22 13:46:43 --> Form Validation Class Initialized
INFO - 2026-02-22 13:46:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:46:43 --> Pagination Class Initialized
INFO - 2026-02-22 13:46:43 --> Email Class Initialized
INFO - 2026-02-22 13:46:43 --> Controller Class Initialized
ERROR - 2026-02-22 13:46:43 --> 404 Page Not Found: /index
INFO - 2026-02-22 13:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:46:43 --> Upload Class Initialized
DEBUG - 2026-02-22 13:46:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:46:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:46:43 --> Encryption Class Initialized
INFO - 2026-02-22 13:46:43 --> Form Validation Class Initialized
INFO - 2026-02-22 13:46:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:46:43 --> Pagination Class Initialized
INFO - 2026-02-22 13:46:43 --> Email Class Initialized
INFO - 2026-02-22 13:46:43 --> Controller Class Initialized
ERROR - 2026-02-22 13:46:43 --> 404 Page Not Found: /index
INFO - 2026-02-22 13:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:46:43 --> Upload Class Initialized
DEBUG - 2026-02-22 13:46:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:46:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:46:43 --> Encryption Class Initialized
INFO - 2026-02-22 13:46:43 --> Form Validation Class Initialized
INFO - 2026-02-22 13:46:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:46:43 --> Pagination Class Initialized
INFO - 2026-02-22 13:46:43 --> Email Class Initialized
INFO - 2026-02-22 13:46:43 --> Controller Class Initialized
ERROR - 2026-02-22 13:46:43 --> 404 Page Not Found: /index
INFO - 2026-02-22 13:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:46:43 --> Upload Class Initialized
DEBUG - 2026-02-22 13:46:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:46:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:46:43 --> Encryption Class Initialized
INFO - 2026-02-22 13:46:43 --> Form Validation Class Initialized
INFO - 2026-02-22 13:46:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:46:43 --> Pagination Class Initialized
INFO - 2026-02-22 13:46:43 --> Email Class Initialized
INFO - 2026-02-22 13:46:43 --> Controller Class Initialized
ERROR - 2026-02-22 13:46:43 --> 404 Page Not Found: /index
INFO - 2026-02-22 13:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:46:44 --> Upload Class Initialized
DEBUG - 2026-02-22 13:46:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:46:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:46:44 --> Encryption Class Initialized
INFO - 2026-02-22 13:46:44 --> Form Validation Class Initialized
INFO - 2026-02-22 13:46:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:46:44 --> Pagination Class Initialized
INFO - 2026-02-22 13:46:44 --> Email Class Initialized
INFO - 2026-02-22 13:46:44 --> Controller Class Initialized
ERROR - 2026-02-22 13:46:44 --> 404 Page Not Found: /index
INFO - 2026-02-22 13:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:46:44 --> Upload Class Initialized
DEBUG - 2026-02-22 13:46:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:46:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:46:44 --> Encryption Class Initialized
INFO - 2026-02-22 13:46:44 --> Form Validation Class Initialized
INFO - 2026-02-22 13:46:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:46:44 --> Pagination Class Initialized
INFO - 2026-02-22 13:46:44 --> Email Class Initialized
INFO - 2026-02-22 13:46:44 --> Controller Class Initialized
ERROR - 2026-02-22 13:46:44 --> 404 Page Not Found: /index
INFO - 2026-02-22 13:47:10 --> Config Class Initialized
INFO - 2026-02-22 13:47:10 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:47:10 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:47:10 --> Utf8 Class Initialized
INFO - 2026-02-22 13:47:10 --> URI Class Initialized
INFO - 2026-02-22 13:47:10 --> Router Class Initialized
INFO - 2026-02-22 13:47:10 --> Output Class Initialized
INFO - 2026-02-22 13:47:10 --> Security Class Initialized
DEBUG - 2026-02-22 13:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:47:10 --> CSRF cookie sent
INFO - 2026-02-22 13:47:10 --> Input Class Initialized
INFO - 2026-02-22 13:47:10 --> Language Class Initialized
INFO - 2026-02-22 13:47:10 --> Language Class Initialized
INFO - 2026-02-22 13:47:10 --> Config Class Initialized
INFO - 2026-02-22 13:47:10 --> Loader Class Initialized
INFO - 2026-02-22 13:47:10 --> Helper loaded: url_helper
INFO - 2026-02-22 13:47:10 --> Helper loaded: form_helper
INFO - 2026-02-22 13:47:10 --> Helper loaded: html_helper
INFO - 2026-02-22 13:47:10 --> Helper loaded: file_helper
INFO - 2026-02-22 13:47:10 --> Helper loaded: email_helper
INFO - 2026-02-22 13:47:10 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:47:10 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:47:10 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:47:10 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:47:10 --> Database Driver Class Initialized
INFO - 2026-02-22 13:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:47:13 --> Upload Class Initialized
DEBUG - 2026-02-22 13:47:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:47:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:47:13 --> Encryption Class Initialized
INFO - 2026-02-22 13:47:13 --> Form Validation Class Initialized
INFO - 2026-02-22 13:47:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:47:13 --> Pagination Class Initialized
INFO - 2026-02-22 13:47:13 --> Email Class Initialized
INFO - 2026-02-22 13:47:13 --> Controller Class Initialized
DEBUG - 2026-02-22 13:47:13 --> Authenticate MX_Controller Initialized
INFO - 2026-02-22 13:47:13 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:47:13 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:47:13 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-22 13:47:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 13:47:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 13:47:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-02-22 13:47:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 13:47:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 13:47:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_forgetpass.php
INFO - 2026-02-22 13:47:13 --> Final output sent to browser
DEBUG - 2026-02-22 13:47:13 --> Total execution time: 2.4930
INFO - 2026-02-22 13:47:17 --> Config Class Initialized
INFO - 2026-02-22 13:47:17 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:47:17 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:47:17 --> Utf8 Class Initialized
INFO - 2026-02-22 13:47:17 --> URI Class Initialized
INFO - 2026-02-22 13:47:17 --> Router Class Initialized
INFO - 2026-02-22 13:47:17 --> Output Class Initialized
INFO - 2026-02-22 13:47:17 --> Security Class Initialized
DEBUG - 2026-02-22 13:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:47:17 --> CSRF cookie sent
INFO - 2026-02-22 13:47:17 --> Input Class Initialized
INFO - 2026-02-22 13:47:17 --> Language Class Initialized
INFO - 2026-02-22 13:47:17 --> Language Class Initialized
INFO - 2026-02-22 13:47:17 --> Config Class Initialized
INFO - 2026-02-22 13:47:17 --> Loader Class Initialized
INFO - 2026-02-22 13:47:17 --> Helper loaded: url_helper
INFO - 2026-02-22 13:47:17 --> Helper loaded: form_helper
INFO - 2026-02-22 13:47:17 --> Helper loaded: html_helper
INFO - 2026-02-22 13:47:17 --> Helper loaded: file_helper
INFO - 2026-02-22 13:47:17 --> Helper loaded: email_helper
INFO - 2026-02-22 13:47:17 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:47:17 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:47:17 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:47:17 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:47:17 --> Database Driver Class Initialized
INFO - 2026-02-22 13:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:47:19 --> Upload Class Initialized
DEBUG - 2026-02-22 13:47:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:47:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:47:19 --> Encryption Class Initialized
INFO - 2026-02-22 13:47:19 --> Form Validation Class Initialized
INFO - 2026-02-22 13:47:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:47:19 --> Pagination Class Initialized
INFO - 2026-02-22 13:47:19 --> Email Class Initialized
INFO - 2026-02-22 13:47:19 --> Controller Class Initialized
DEBUG - 2026-02-22 13:47:19 --> Authenticate MX_Controller Initialized
INFO - 2026-02-22 13:47:19 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:47:19 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:47:19 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-22 13:47:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 13:47:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 13:47:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-02-22 13:47:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 13:47:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 13:47:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-02-22 13:47:20 --> Final output sent to browser
DEBUG - 2026-02-22 13:47:20 --> Total execution time: 2.9963
INFO - 2026-02-22 13:47:51 --> Config Class Initialized
INFO - 2026-02-22 13:47:51 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:47:51 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:47:51 --> Utf8 Class Initialized
INFO - 2026-02-22 13:47:51 --> URI Class Initialized
INFO - 2026-02-22 13:47:51 --> Router Class Initialized
INFO - 2026-02-22 13:47:51 --> Output Class Initialized
INFO - 2026-02-22 13:47:51 --> Security Class Initialized
DEBUG - 2026-02-22 13:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:47:51 --> CSRF cookie sent
INFO - 2026-02-22 13:47:51 --> CSRF token verified
INFO - 2026-02-22 13:47:51 --> Input Class Initialized
INFO - 2026-02-22 13:47:51 --> Language Class Initialized
INFO - 2026-02-22 13:47:51 --> Language Class Initialized
INFO - 2026-02-22 13:47:51 --> Config Class Initialized
INFO - 2026-02-22 13:47:51 --> Loader Class Initialized
INFO - 2026-02-22 13:47:51 --> Helper loaded: url_helper
INFO - 2026-02-22 13:47:51 --> Helper loaded: form_helper
INFO - 2026-02-22 13:47:51 --> Helper loaded: html_helper
INFO - 2026-02-22 13:47:51 --> Helper loaded: file_helper
INFO - 2026-02-22 13:47:51 --> Helper loaded: email_helper
INFO - 2026-02-22 13:47:51 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:47:51 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:47:51 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:47:51 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:47:51 --> Database Driver Class Initialized
INFO - 2026-02-22 13:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:47:53 --> Upload Class Initialized
DEBUG - 2026-02-22 13:47:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:47:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:47:53 --> Encryption Class Initialized
INFO - 2026-02-22 13:47:53 --> Form Validation Class Initialized
INFO - 2026-02-22 13:47:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:47:53 --> Pagination Class Initialized
INFO - 2026-02-22 13:47:53 --> Email Class Initialized
INFO - 2026-02-22 13:47:53 --> Controller Class Initialized
DEBUG - 2026-02-22 13:47:53 --> Authenticate MX_Controller Initialized
INFO - 2026-02-22 13:47:53 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:47:53 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:47:53 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 13:47:57 --> Config Class Initialized
INFO - 2026-02-22 13:47:57 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:47:57 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:47:57 --> Utf8 Class Initialized
INFO - 2026-02-22 13:47:57 --> URI Class Initialized
INFO - 2026-02-22 13:47:57 --> Router Class Initialized
INFO - 2026-02-22 13:47:57 --> Output Class Initialized
INFO - 2026-02-22 13:47:57 --> Security Class Initialized
DEBUG - 2026-02-22 13:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:47:57 --> CSRF cookie sent
INFO - 2026-02-22 13:47:57 --> Input Class Initialized
INFO - 2026-02-22 13:47:57 --> Language Class Initialized
INFO - 2026-02-22 13:47:57 --> Language Class Initialized
INFO - 2026-02-22 13:47:57 --> Config Class Initialized
INFO - 2026-02-22 13:47:57 --> Loader Class Initialized
INFO - 2026-02-22 13:47:57 --> Helper loaded: url_helper
INFO - 2026-02-22 13:47:57 --> Helper loaded: form_helper
INFO - 2026-02-22 13:47:57 --> Helper loaded: html_helper
INFO - 2026-02-22 13:47:57 --> Helper loaded: file_helper
INFO - 2026-02-22 13:47:57 --> Helper loaded: email_helper
INFO - 2026-02-22 13:47:57 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:47:57 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:47:57 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:47:57 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:47:57 --> Database Driver Class Initialized
INFO - 2026-02-22 13:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:47:59 --> Upload Class Initialized
DEBUG - 2026-02-22 13:47:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:47:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:47:59 --> Encryption Class Initialized
INFO - 2026-02-22 13:47:59 --> Form Validation Class Initialized
INFO - 2026-02-22 13:47:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:47:59 --> Pagination Class Initialized
INFO - 2026-02-22 13:47:59 --> Email Class Initialized
INFO - 2026-02-22 13:47:59 --> Controller Class Initialized
DEBUG - 2026-02-22 13:47:59 --> Dashboard MX_Controller Initialized
INFO - 2026-02-22 13:47:59 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:47:59 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:47:59 --> Model "Dashboard_model" initialized
DEBUG - 2026-02-22 13:47:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 13:47:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 13:47:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 13:47:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 13:47:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 13:47:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/dashboard_index.php
INFO - 2026-02-22 13:47:59 --> Final output sent to browser
DEBUG - 2026-02-22 13:47:59 --> Total execution time: 2.3126
INFO - 2026-02-22 13:47:59 --> Config Class Initialized
INFO - 2026-02-22 13:47:59 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:47:59 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:47:59 --> Utf8 Class Initialized
INFO - 2026-02-22 13:47:59 --> URI Class Initialized
INFO - 2026-02-22 13:47:59 --> Config Class Initialized
INFO - 2026-02-22 13:47:59 --> Config Class Initialized
INFO - 2026-02-22 13:47:59 --> Config Class Initialized
INFO - 2026-02-22 13:47:59 --> Hooks Class Initialized
INFO - 2026-02-22 13:47:59 --> Hooks Class Initialized
INFO - 2026-02-22 13:47:59 --> Router Class Initialized
DEBUG - 2026-02-22 13:47:59 --> UTF-8 Support Enabled
DEBUG - 2026-02-22 13:47:59 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:47:59 --> Utf8 Class Initialized
INFO - 2026-02-22 13:47:59 --> Utf8 Class Initialized
INFO - 2026-02-22 13:47:59 --> Hooks Class Initialized
INFO - 2026-02-22 13:47:59 --> URI Class Initialized
INFO - 2026-02-22 13:47:59 --> Output Class Initialized
INFO - 2026-02-22 13:47:59 --> URI Class Initialized
INFO - 2026-02-22 13:47:59 --> Security Class Initialized
INFO - 2026-02-22 13:47:59 --> Router Class Initialized
DEBUG - 2026-02-22 13:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:47:59 --> Input Class Initialized
INFO - 2026-02-22 13:47:59 --> Language Class Initialized
INFO - 2026-02-22 13:47:59 --> Router Class Initialized
INFO - 2026-02-22 13:47:59 --> Output Class Initialized
INFO - 2026-02-22 13:47:59 --> Language Class Initialized
INFO - 2026-02-22 13:47:59 --> Config Class Initialized
INFO - 2026-02-22 13:47:59 --> Security Class Initialized
INFO - 2026-02-22 13:47:59 --> Output Class Initialized
DEBUG - 2026-02-22 13:47:59 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:47:59 --> Utf8 Class Initialized
DEBUG - 2026-02-22 13:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:47:59 --> Security Class Initialized
INFO - 2026-02-22 13:47:59 --> Input Class Initialized
INFO - 2026-02-22 13:47:59 --> Language Class Initialized
INFO - 2026-02-22 13:47:59 --> Loader Class Initialized
INFO - 2026-02-22 13:47:59 --> URI Class Initialized
INFO - 2026-02-22 13:47:59 --> Language Class Initialized
INFO - 2026-02-22 13:47:59 --> Config Class Initialized
DEBUG - 2026-02-22 13:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:47:59 --> Helper loaded: url_helper
INFO - 2026-02-22 13:47:59 --> Input Class Initialized
INFO - 2026-02-22 13:47:59 --> Language Class Initialized
INFO - 2026-02-22 13:47:59 --> Helper loaded: form_helper
INFO - 2026-02-22 13:47:59 --> Router Class Initialized
INFO - 2026-02-22 13:47:59 --> Language Class Initialized
INFO - 2026-02-22 13:47:59 --> Config Class Initialized
INFO - 2026-02-22 13:47:59 --> Helper loaded: html_helper
INFO - 2026-02-22 13:47:59 --> Loader Class Initialized
INFO - 2026-02-22 13:47:59 --> Helper loaded: file_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: email_helper
INFO - 2026-02-22 13:47:59 --> Output Class Initialized
INFO - 2026-02-22 13:47:59 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:47:59 --> Loader Class Initialized
INFO - 2026-02-22 13:47:59 --> Helper loaded: url_helper
INFO - 2026-02-22 13:47:59 --> Security Class Initialized
INFO - 2026-02-22 13:47:59 --> Config Class Initialized
INFO - 2026-02-22 13:47:59 --> Hooks Class Initialized
INFO - 2026-02-22 13:47:59 --> Helper loaded: url_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: form_helper
DEBUG - 2026-02-22 13:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:47:59 --> Helper loaded: html_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: file_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: domain_helper
DEBUG - 2026-02-22 13:47:59 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:47:59 --> Utf8 Class Initialized
INFO - 2026-02-22 13:47:59 --> Input Class Initialized
INFO - 2026-02-22 13:47:59 --> Helper loaded: email_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: form_helper
INFO - 2026-02-22 13:47:59 --> Language Class Initialized
INFO - 2026-02-22 13:47:59 --> Helper loaded: html_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:47:59 --> URI Class Initialized
INFO - 2026-02-22 13:47:59 --> Helper loaded: file_helper
INFO - 2026-02-22 13:47:59 --> Language Class Initialized
INFO - 2026-02-22 13:47:59 --> Config Class Initialized
INFO - 2026-02-22 13:47:59 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: email_helper
INFO - 2026-02-22 13:47:59 --> Config Class Initialized
INFO - 2026-02-22 13:47:59 --> Hooks Class Initialized
INFO - 2026-02-22 13:47:59 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: ssp_helper
DEBUG - 2026-02-22 13:47:59 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:47:59 --> Utf8 Class Initialized
INFO - 2026-02-22 13:47:59 --> Loader Class Initialized
INFO - 2026-02-22 13:47:59 --> URI Class Initialized
INFO - 2026-02-22 13:47:59 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: url_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:47:59 --> Database Driver Class Initialized
INFO - 2026-02-22 13:47:59 --> Router Class Initialized
INFO - 2026-02-22 13:47:59 --> Helper loaded: form_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: html_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: file_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: email_helper
INFO - 2026-02-22 13:47:59 --> Output Class Initialized
INFO - 2026-02-22 13:47:59 --> Router Class Initialized
INFO - 2026-02-22 13:47:59 --> Security Class Initialized
INFO - 2026-02-22 13:47:59 --> Output Class Initialized
INFO - 2026-02-22 13:47:59 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: ssp_helper
DEBUG - 2026-02-22 13:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:47:59 --> Security Class Initialized
INFO - 2026-02-22 13:47:59 --> Input Class Initialized
INFO - 2026-02-22 13:47:59 --> Language Class Initialized
INFO - 2026-02-22 13:47:59 --> Database Driver Class Initialized
INFO - 2026-02-22 13:47:59 --> Database Driver Class Initialized
INFO - 2026-02-22 13:47:59 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:47:59 --> Language Class Initialized
DEBUG - 2026-02-22 13:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:47:59 --> Config Class Initialized
INFO - 2026-02-22 13:47:59 --> Input Class Initialized
INFO - 2026-02-22 13:47:59 --> Language Class Initialized
INFO - 2026-02-22 13:47:59 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:47:59 --> Language Class Initialized
INFO - 2026-02-22 13:47:59 --> Config Class Initialized
INFO - 2026-02-22 13:47:59 --> Loader Class Initialized
INFO - 2026-02-22 13:47:59 --> Loader Class Initialized
INFO - 2026-02-22 13:47:59 --> Helper loaded: url_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: url_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: form_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: form_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: html_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: html_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: file_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: email_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: file_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: email_helper
INFO - 2026-02-22 13:47:59 --> Database Driver Class Initialized
INFO - 2026-02-22 13:47:59 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:47:59 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:47:59 --> Database Driver Class Initialized
INFO - 2026-02-22 13:47:59 --> Database Driver Class Initialized
INFO - 2026-02-22 13:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:48:02 --> Upload Class Initialized
DEBUG - 2026-02-22 13:48:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:48:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:48:02 --> Encryption Class Initialized
INFO - 2026-02-22 13:48:02 --> Form Validation Class Initialized
INFO - 2026-02-22 13:48:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:48:02 --> Pagination Class Initialized
INFO - 2026-02-22 13:48:02 --> Email Class Initialized
INFO - 2026-02-22 13:48:02 --> Controller Class Initialized
DEBUG - 2026-02-22 13:48:02 --> Ticket MX_Controller Initialized
INFO - 2026-02-22 13:48:02 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:48:02 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:48:02 --> Model "Support_model" initialized
INFO - 2026-02-22 13:48:02 --> Model "Common_model" initialized
INFO - 2026-02-22 13:48:03 --> Final output sent to browser
DEBUG - 2026-02-22 13:48:03 --> Total execution time: 3.4829
INFO - 2026-02-22 13:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:48:03 --> Upload Class Initialized
DEBUG - 2026-02-22 13:48:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:48:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:48:03 --> Encryption Class Initialized
INFO - 2026-02-22 13:48:03 --> Form Validation Class Initialized
INFO - 2026-02-22 13:48:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:48:03 --> Pagination Class Initialized
INFO - 2026-02-22 13:48:03 --> Email Class Initialized
INFO - 2026-02-22 13:48:03 --> Controller Class Initialized
DEBUG - 2026-02-22 13:48:03 --> Dashboard MX_Controller Initialized
INFO - 2026-02-22 13:48:03 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:48:03 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:48:03 --> Model "Dashboard_model" initialized
INFO - 2026-02-22 13:48:04 --> Final output sent to browser
DEBUG - 2026-02-22 13:48:04 --> Total execution time: 4.2898
INFO - 2026-02-22 13:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:48:04 --> Upload Class Initialized
DEBUG - 2026-02-22 13:48:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:48:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:48:04 --> Encryption Class Initialized
INFO - 2026-02-22 13:48:04 --> Form Validation Class Initialized
INFO - 2026-02-22 13:48:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:48:04 --> Pagination Class Initialized
INFO - 2026-02-22 13:48:04 --> Email Class Initialized
INFO - 2026-02-22 13:48:04 --> Controller Class Initialized
DEBUG - 2026-02-22 13:48:04 --> Dashboard MX_Controller Initialized
INFO - 2026-02-22 13:48:04 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:48:04 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:48:04 --> Model "Dashboard_model" initialized
INFO - 2026-02-22 13:48:05 --> Final output sent to browser
DEBUG - 2026-02-22 13:48:05 --> Total execution time: 5.1547
INFO - 2026-02-22 13:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:48:05 --> Upload Class Initialized
DEBUG - 2026-02-22 13:48:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:48:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:48:05 --> Encryption Class Initialized
INFO - 2026-02-22 13:48:05 --> Form Validation Class Initialized
INFO - 2026-02-22 13:48:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:48:05 --> Pagination Class Initialized
INFO - 2026-02-22 13:48:05 --> Email Class Initialized
INFO - 2026-02-22 13:48:05 --> Controller Class Initialized
DEBUG - 2026-02-22 13:48:05 --> Invoice MX_Controller Initialized
INFO - 2026-02-22 13:48:05 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:48:05 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:48:05 --> Model "Billing_model" initialized
INFO - 2026-02-22 13:48:05 --> Model "Common_model" initialized
INFO - 2026-02-22 13:48:05 --> Model "Invoice_model" initialized
INFO - 2026-02-22 13:48:05 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 13:48:05 --> Final output sent to browser
DEBUG - 2026-02-22 13:48:05 --> Total execution time: 5.9302
INFO - 2026-02-22 13:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:48:05 --> Upload Class Initialized
DEBUG - 2026-02-22 13:48:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:48:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:48:05 --> Encryption Class Initialized
INFO - 2026-02-22 13:48:05 --> Form Validation Class Initialized
INFO - 2026-02-22 13:48:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:48:05 --> Pagination Class Initialized
INFO - 2026-02-22 13:48:05 --> Email Class Initialized
INFO - 2026-02-22 13:48:05 --> Controller Class Initialized
DEBUG - 2026-02-22 13:48:05 --> Order MX_Controller Initialized
INFO - 2026-02-22 13:48:05 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:48:05 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:48:06 --> Model "Order_model" initialized
INFO - 2026-02-22 13:48:06 --> Model "Common_model" initialized
INFO - 2026-02-22 13:48:06 --> Model "Currency_model" initialized
INFO - 2026-02-22 13:48:06 --> Final output sent to browser
DEBUG - 2026-02-22 13:48:06 --> Total execution time: 6.7490
INFO - 2026-02-22 13:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:48:06 --> Upload Class Initialized
DEBUG - 2026-02-22 13:48:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:48:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:48:06 --> Encryption Class Initialized
INFO - 2026-02-22 13:48:06 --> Form Validation Class Initialized
INFO - 2026-02-22 13:48:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:48:06 --> Pagination Class Initialized
INFO - 2026-02-22 13:48:06 --> Email Class Initialized
INFO - 2026-02-22 13:48:06 --> Controller Class Initialized
DEBUG - 2026-02-22 13:48:06 --> Dashboard MX_Controller Initialized
INFO - 2026-02-22 13:48:06 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:48:06 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:48:07 --> Model "Dashboard_model" initialized
INFO - 2026-02-22 13:48:07 --> Final output sent to browser
DEBUG - 2026-02-22 13:48:07 --> Total execution time: 7.5588
INFO - 2026-02-22 13:48:31 --> Config Class Initialized
INFO - 2026-02-22 13:48:31 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:48:31 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:48:31 --> Utf8 Class Initialized
INFO - 2026-02-22 13:48:31 --> URI Class Initialized
INFO - 2026-02-22 13:48:31 --> Router Class Initialized
INFO - 2026-02-22 13:48:31 --> Output Class Initialized
INFO - 2026-02-22 13:48:31 --> Security Class Initialized
DEBUG - 2026-02-22 13:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:48:31 --> CSRF cookie sent
INFO - 2026-02-22 13:48:31 --> Input Class Initialized
INFO - 2026-02-22 13:48:31 --> Language Class Initialized
INFO - 2026-02-22 13:48:31 --> Language Class Initialized
INFO - 2026-02-22 13:48:31 --> Config Class Initialized
INFO - 2026-02-22 13:48:31 --> Loader Class Initialized
INFO - 2026-02-22 13:48:31 --> Helper loaded: url_helper
INFO - 2026-02-22 13:48:31 --> Helper loaded: form_helper
INFO - 2026-02-22 13:48:31 --> Helper loaded: html_helper
INFO - 2026-02-22 13:48:31 --> Helper loaded: file_helper
INFO - 2026-02-22 13:48:31 --> Helper loaded: email_helper
INFO - 2026-02-22 13:48:31 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:48:31 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:48:31 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:48:31 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:48:31 --> Database Driver Class Initialized
INFO - 2026-02-22 13:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:49:12 --> Upload Class Initialized
DEBUG - 2026-02-22 13:49:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:49:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:49:12 --> Encryption Class Initialized
INFO - 2026-02-22 13:49:12 --> Form Validation Class Initialized
INFO - 2026-02-22 13:49:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:49:12 --> Pagination Class Initialized
INFO - 2026-02-22 13:49:12 --> Email Class Initialized
INFO - 2026-02-22 13:49:12 --> Controller Class Initialized
DEBUG - 2026-02-22 13:49:12 --> General_setting MX_Controller Initialized
INFO - 2026-02-22 13:49:12 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:49:12 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:49:12 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 13:49:12 --> Model "Dunningrule_model" initialized
INFO - 2026-02-22 13:49:12 --> Model "Emailtemplate_model" initialized
INFO - 2026-02-22 13:49:12 --> Model "Syscnf_model" initialized
INFO - 2026-02-22 13:49:12 --> Model "Cronschedule_model" initialized
INFO - 2026-02-22 13:49:12 --> Model "Common_model" initialized
DEBUG - 2026-02-22 13:49:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 13:49:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 13:49:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 13:49:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 13:49:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 13:49:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/general_setting_manage.php
INFO - 2026-02-22 13:49:15 --> Final output sent to browser
DEBUG - 2026-02-22 13:49:15 --> Total execution time: 44.0641
INFO - 2026-02-22 13:50:13 --> Config Class Initialized
INFO - 2026-02-22 13:50:13 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:50:13 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:50:13 --> Utf8 Class Initialized
INFO - 2026-02-22 13:50:13 --> URI Class Initialized
INFO - 2026-02-22 13:50:13 --> Router Class Initialized
INFO - 2026-02-22 13:50:13 --> Output Class Initialized
INFO - 2026-02-22 13:50:13 --> Security Class Initialized
DEBUG - 2026-02-22 13:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:50:13 --> CSRF cookie sent
INFO - 2026-02-22 13:50:13 --> CSRF token verified
INFO - 2026-02-22 13:50:13 --> Input Class Initialized
INFO - 2026-02-22 13:50:13 --> Language Class Initialized
INFO - 2026-02-22 13:50:13 --> Language Class Initialized
INFO - 2026-02-22 13:50:13 --> Config Class Initialized
INFO - 2026-02-22 13:50:13 --> Loader Class Initialized
INFO - 2026-02-22 13:50:13 --> Helper loaded: url_helper
INFO - 2026-02-22 13:50:13 --> Helper loaded: form_helper
INFO - 2026-02-22 13:50:13 --> Helper loaded: html_helper
INFO - 2026-02-22 13:50:13 --> Helper loaded: file_helper
INFO - 2026-02-22 13:50:13 --> Helper loaded: email_helper
INFO - 2026-02-22 13:50:13 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:50:13 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:50:13 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:50:13 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:50:13 --> Database Driver Class Initialized
INFO - 2026-02-22 13:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:50:16 --> Upload Class Initialized
DEBUG - 2026-02-22 13:50:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:50:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:50:16 --> Encryption Class Initialized
INFO - 2026-02-22 13:50:16 --> Form Validation Class Initialized
INFO - 2026-02-22 13:50:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:50:16 --> Pagination Class Initialized
INFO - 2026-02-22 13:50:16 --> Email Class Initialized
INFO - 2026-02-22 13:50:16 --> Controller Class Initialized
DEBUG - 2026-02-22 13:50:16 --> General_setting MX_Controller Initialized
INFO - 2026-02-22 13:50:16 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:50:16 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:50:16 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 13:50:16 --> Model "Dunningrule_model" initialized
INFO - 2026-02-22 13:50:16 --> Model "Emailtemplate_model" initialized
INFO - 2026-02-22 13:50:16 --> Model "Syscnf_model" initialized
INFO - 2026-02-22 13:50:16 --> Model "Cronschedule_model" initialized
INFO - 2026-02-22 13:50:16 --> Model "Common_model" initialized
INFO - 2026-02-22 13:50:17 --> Final output sent to browser
DEBUG - 2026-02-22 13:50:17 --> Total execution time: 3.7659
INFO - 2026-02-22 13:50:17 --> Config Class Initialized
INFO - 2026-02-22 13:50:17 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:50:17 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:50:17 --> Utf8 Class Initialized
INFO - 2026-02-22 13:50:17 --> URI Class Initialized
INFO - 2026-02-22 13:50:17 --> Router Class Initialized
INFO - 2026-02-22 13:50:17 --> Output Class Initialized
INFO - 2026-02-22 13:50:17 --> Security Class Initialized
DEBUG - 2026-02-22 13:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:50:17 --> CSRF cookie sent
INFO - 2026-02-22 13:50:17 --> Input Class Initialized
INFO - 2026-02-22 13:50:17 --> Language Class Initialized
INFO - 2026-02-22 13:50:17 --> Language Class Initialized
INFO - 2026-02-22 13:50:17 --> Config Class Initialized
INFO - 2026-02-22 13:50:17 --> Loader Class Initialized
INFO - 2026-02-22 13:50:17 --> Helper loaded: url_helper
INFO - 2026-02-22 13:50:17 --> Helper loaded: form_helper
INFO - 2026-02-22 13:50:17 --> Helper loaded: html_helper
INFO - 2026-02-22 13:50:17 --> Helper loaded: file_helper
INFO - 2026-02-22 13:50:17 --> Helper loaded: email_helper
INFO - 2026-02-22 13:50:17 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:50:17 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:50:17 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:50:17 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:50:17 --> Database Driver Class Initialized
INFO - 2026-02-22 13:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:50:19 --> Upload Class Initialized
DEBUG - 2026-02-22 13:50:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:50:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:50:19 --> Encryption Class Initialized
INFO - 2026-02-22 13:50:19 --> Form Validation Class Initialized
INFO - 2026-02-22 13:50:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:50:19 --> Pagination Class Initialized
INFO - 2026-02-22 13:50:19 --> Email Class Initialized
INFO - 2026-02-22 13:50:19 --> Controller Class Initialized
DEBUG - 2026-02-22 13:50:19 --> General_setting MX_Controller Initialized
INFO - 2026-02-22 13:50:19 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:50:19 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:50:19 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 13:50:19 --> Model "Dunningrule_model" initialized
INFO - 2026-02-22 13:50:19 --> Model "Emailtemplate_model" initialized
INFO - 2026-02-22 13:50:19 --> Model "Syscnf_model" initialized
INFO - 2026-02-22 13:50:19 --> Model "Cronschedule_model" initialized
INFO - 2026-02-22 13:50:19 --> Model "Common_model" initialized
DEBUG - 2026-02-22 13:50:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 13:50:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 13:50:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 13:50:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 13:50:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 13:50:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/general_setting_manage.php
INFO - 2026-02-22 13:50:23 --> Final output sent to browser
DEBUG - 2026-02-22 13:50:23 --> Total execution time: 5.5126
INFO - 2026-02-22 13:54:12 --> Config Class Initialized
INFO - 2026-02-22 13:54:12 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:54:12 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:54:12 --> Utf8 Class Initialized
INFO - 2026-02-22 13:54:12 --> URI Class Initialized
INFO - 2026-02-22 13:54:12 --> Router Class Initialized
INFO - 2026-02-22 13:54:12 --> Output Class Initialized
INFO - 2026-02-22 13:54:12 --> Security Class Initialized
DEBUG - 2026-02-22 13:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:54:12 --> CSRF cookie sent
INFO - 2026-02-22 13:54:12 --> Input Class Initialized
INFO - 2026-02-22 13:54:12 --> Language Class Initialized
INFO - 2026-02-22 13:54:12 --> Language Class Initialized
INFO - 2026-02-22 13:54:12 --> Config Class Initialized
INFO - 2026-02-22 13:54:12 --> Loader Class Initialized
INFO - 2026-02-22 13:54:12 --> Helper loaded: url_helper
INFO - 2026-02-22 13:54:12 --> Helper loaded: form_helper
INFO - 2026-02-22 13:54:12 --> Helper loaded: html_helper
INFO - 2026-02-22 13:54:12 --> Helper loaded: file_helper
INFO - 2026-02-22 13:54:12 --> Helper loaded: email_helper
INFO - 2026-02-22 13:54:12 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:54:12 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:54:12 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:54:12 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:54:12 --> Database Driver Class Initialized
INFO - 2026-02-22 13:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:54:14 --> Upload Class Initialized
DEBUG - 2026-02-22 13:54:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:54:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:54:14 --> Encryption Class Initialized
INFO - 2026-02-22 13:54:14 --> Form Validation Class Initialized
INFO - 2026-02-22 13:54:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:54:14 --> Pagination Class Initialized
INFO - 2026-02-22 13:54:14 --> Email Class Initialized
INFO - 2026-02-22 13:54:14 --> Controller Class Initialized
DEBUG - 2026-02-22 13:54:14 --> Invoice MX_Controller Initialized
INFO - 2026-02-22 13:54:14 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:54:14 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:54:14 --> Model "Billing_model" initialized
INFO - 2026-02-22 13:54:14 --> Model "Common_model" initialized
INFO - 2026-02-22 13:54:14 --> Model "Invoice_model" initialized
INFO - 2026-02-22 13:54:14 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-22 13:54:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 13:54:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 13:54:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 13:54:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 13:54:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 13:54:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/invoice_list.php
INFO - 2026-02-22 13:54:15 --> Final output sent to browser
DEBUG - 2026-02-22 13:54:15 --> Total execution time: 2.3483
INFO - 2026-02-22 13:54:15 --> Config Class Initialized
INFO - 2026-02-22 13:54:15 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:54:15 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:54:15 --> Utf8 Class Initialized
INFO - 2026-02-22 13:54:15 --> URI Class Initialized
INFO - 2026-02-22 13:54:15 --> Router Class Initialized
INFO - 2026-02-22 13:54:15 --> Output Class Initialized
INFO - 2026-02-22 13:54:15 --> Security Class Initialized
DEBUG - 2026-02-22 13:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:54:15 --> CSRF cookie sent
INFO - 2026-02-22 13:54:15 --> Input Class Initialized
INFO - 2026-02-22 13:54:15 --> Language Class Initialized
INFO - 2026-02-22 13:54:15 --> Language Class Initialized
INFO - 2026-02-22 13:54:15 --> Config Class Initialized
INFO - 2026-02-22 13:54:15 --> Loader Class Initialized
INFO - 2026-02-22 13:54:15 --> Helper loaded: url_helper
INFO - 2026-02-22 13:54:15 --> Helper loaded: form_helper
INFO - 2026-02-22 13:54:15 --> Helper loaded: html_helper
INFO - 2026-02-22 13:54:15 --> Helper loaded: file_helper
INFO - 2026-02-22 13:54:15 --> Helper loaded: email_helper
INFO - 2026-02-22 13:54:15 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:54:15 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:54:15 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:54:15 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:54:15 --> Database Driver Class Initialized
INFO - 2026-02-22 13:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:54:17 --> Upload Class Initialized
DEBUG - 2026-02-22 13:54:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:54:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:54:17 --> Encryption Class Initialized
INFO - 2026-02-22 13:54:17 --> Form Validation Class Initialized
INFO - 2026-02-22 13:54:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:54:17 --> Pagination Class Initialized
INFO - 2026-02-22 13:54:17 --> Email Class Initialized
INFO - 2026-02-22 13:54:17 --> Controller Class Initialized
DEBUG - 2026-02-22 13:54:17 --> Invoice MX_Controller Initialized
INFO - 2026-02-22 13:54:17 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:54:17 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:54:17 --> Model "Billing_model" initialized
INFO - 2026-02-22 13:54:17 --> Model "Common_model" initialized
INFO - 2026-02-22 13:54:17 --> Model "Invoice_model" initialized
INFO - 2026-02-22 13:54:17 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 13:56:07 --> Config Class Initialized
INFO - 2026-02-22 13:56:07 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:56:07 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:56:07 --> Utf8 Class Initialized
INFO - 2026-02-22 13:56:07 --> URI Class Initialized
DEBUG - 2026-02-22 13:56:07 --> No URI present. Default controller set.
INFO - 2026-02-22 13:56:07 --> Router Class Initialized
INFO - 2026-02-22 13:56:07 --> Output Class Initialized
INFO - 2026-02-22 13:56:07 --> Security Class Initialized
DEBUG - 2026-02-22 13:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:56:07 --> CSRF cookie sent
INFO - 2026-02-22 13:56:07 --> Input Class Initialized
INFO - 2026-02-22 13:56:07 --> Language Class Initialized
INFO - 2026-02-22 13:56:07 --> Language Class Initialized
INFO - 2026-02-22 13:56:07 --> Config Class Initialized
INFO - 2026-02-22 13:56:07 --> Loader Class Initialized
INFO - 2026-02-22 13:56:07 --> Helper loaded: url_helper
INFO - 2026-02-22 13:56:07 --> Helper loaded: form_helper
INFO - 2026-02-22 13:56:07 --> Helper loaded: html_helper
INFO - 2026-02-22 13:56:07 --> Helper loaded: file_helper
INFO - 2026-02-22 13:56:07 --> Helper loaded: email_helper
INFO - 2026-02-22 13:56:07 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:56:07 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:56:07 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:56:07 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:56:07 --> Database Driver Class Initialized
INFO - 2026-02-22 13:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:56:09 --> Upload Class Initialized
DEBUG - 2026-02-22 13:56:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:56:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:56:09 --> Encryption Class Initialized
INFO - 2026-02-22 13:56:09 --> Form Validation Class Initialized
INFO - 2026-02-22 13:56:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:56:09 --> Pagination Class Initialized
INFO - 2026-02-22 13:56:09 --> Email Class Initialized
INFO - 2026-02-22 13:56:09 --> Controller Class Initialized
DEBUG - 2026-02-22 13:56:09 --> Auth MX_Controller Initialized
INFO - 2026-02-22 13:56:09 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:56:09 --> Model "Auth_model" initialized
INFO - 2026-02-22 13:56:09 --> Model "Cart_model" initialized
INFO - 2026-02-22 13:56:09 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 13:56:09 --> Config Class Initialized
INFO - 2026-02-22 13:56:09 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:56:09 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:56:09 --> Utf8 Class Initialized
INFO - 2026-02-22 13:56:09 --> URI Class Initialized
INFO - 2026-02-22 13:56:09 --> Router Class Initialized
INFO - 2026-02-22 13:56:09 --> Output Class Initialized
INFO - 2026-02-22 13:56:09 --> Security Class Initialized
DEBUG - 2026-02-22 13:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:56:09 --> CSRF cookie sent
INFO - 2026-02-22 13:56:09 --> Input Class Initialized
INFO - 2026-02-22 13:56:09 --> Language Class Initialized
INFO - 2026-02-22 13:56:09 --> Language Class Initialized
INFO - 2026-02-22 13:56:09 --> Config Class Initialized
INFO - 2026-02-22 13:56:09 --> Loader Class Initialized
INFO - 2026-02-22 13:56:09 --> Helper loaded: url_helper
INFO - 2026-02-22 13:56:09 --> Helper loaded: form_helper
INFO - 2026-02-22 13:56:09 --> Helper loaded: html_helper
INFO - 2026-02-22 13:56:09 --> Helper loaded: file_helper
INFO - 2026-02-22 13:56:09 --> Helper loaded: email_helper
INFO - 2026-02-22 13:56:09 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:56:09 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:56:09 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:56:09 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:56:09 --> Database Driver Class Initialized
INFO - 2026-02-22 13:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:56:11 --> Upload Class Initialized
DEBUG - 2026-02-22 13:56:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:56:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:56:11 --> Encryption Class Initialized
INFO - 2026-02-22 13:56:11 --> Form Validation Class Initialized
INFO - 2026-02-22 13:56:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:56:11 --> Pagination Class Initialized
INFO - 2026-02-22 13:56:11 --> Email Class Initialized
INFO - 2026-02-22 13:56:11 --> Controller Class Initialized
DEBUG - 2026-02-22 13:56:11 --> Auth MX_Controller Initialized
INFO - 2026-02-22 13:56:11 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:56:11 --> Model "Auth_model" initialized
INFO - 2026-02-22 13:56:11 --> Model "Cart_model" initialized
INFO - 2026-02-22 13:56:11 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-22 13:56:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-22 13:56:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-22 13:56:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-22 13:56:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-02-22 13:56:12 --> Final output sent to browser
DEBUG - 2026-02-22 13:56:12 --> Total execution time: 2.1955
INFO - 2026-02-22 13:56:12 --> Config Class Initialized
INFO - 2026-02-22 13:56:12 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:56:12 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:56:12 --> Utf8 Class Initialized
INFO - 2026-02-22 13:56:12 --> URI Class Initialized
INFO - 2026-02-22 13:56:12 --> Router Class Initialized
INFO - 2026-02-22 13:56:12 --> Output Class Initialized
INFO - 2026-02-22 13:56:12 --> Security Class Initialized
DEBUG - 2026-02-22 13:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:56:12 --> CSRF cookie sent
INFO - 2026-02-22 13:56:12 --> Input Class Initialized
INFO - 2026-02-22 13:56:12 --> Language Class Initialized
INFO - 2026-02-22 13:56:12 --> Language Class Initialized
INFO - 2026-02-22 13:56:12 --> Config Class Initialized
INFO - 2026-02-22 13:56:12 --> Loader Class Initialized
INFO - 2026-02-22 13:56:12 --> Helper loaded: url_helper
INFO - 2026-02-22 13:56:12 --> Helper loaded: form_helper
INFO - 2026-02-22 13:56:12 --> Helper loaded: html_helper
INFO - 2026-02-22 13:56:12 --> Helper loaded: file_helper
INFO - 2026-02-22 13:56:12 --> Helper loaded: email_helper
INFO - 2026-02-22 13:56:12 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:56:12 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:56:12 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:56:12 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:56:12 --> Database Driver Class Initialized
INFO - 2026-02-22 13:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:56:14 --> Upload Class Initialized
DEBUG - 2026-02-22 13:56:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:56:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:56:14 --> Encryption Class Initialized
INFO - 2026-02-22 13:56:14 --> Form Validation Class Initialized
INFO - 2026-02-22 13:56:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:56:14 --> Pagination Class Initialized
INFO - 2026-02-22 13:56:14 --> Email Class Initialized
INFO - 2026-02-22 13:56:14 --> Controller Class Initialized
DEBUG - 2026-02-22 13:56:14 --> Cart MX_Controller Initialized
INFO - 2026-02-22 13:56:14 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:56:14 --> Model "Auth_model" initialized
INFO - 2026-02-22 13:56:14 --> Model "Cart_model" initialized
INFO - 2026-02-22 13:56:14 --> Model "Common_model" initialized
INFO - 2026-02-22 13:56:14 --> Model "Order_model" initialized
INFO - 2026-02-22 13:56:14 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 13:56:14 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-22 13:56:14 --> Final output sent to browser
DEBUG - 2026-02-22 13:56:14 --> Total execution time: 2.4191
INFO - 2026-02-22 13:56:26 --> Config Class Initialized
INFO - 2026-02-22 13:56:26 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:56:26 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:56:26 --> Utf8 Class Initialized
INFO - 2026-02-22 13:56:26 --> URI Class Initialized
INFO - 2026-02-22 13:56:26 --> Router Class Initialized
INFO - 2026-02-22 13:56:26 --> Output Class Initialized
INFO - 2026-02-22 13:56:26 --> Security Class Initialized
DEBUG - 2026-02-22 13:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:56:26 --> CSRF cookie sent
INFO - 2026-02-22 13:56:26 --> CSRF token verified
INFO - 2026-02-22 13:56:26 --> Input Class Initialized
INFO - 2026-02-22 13:56:26 --> Language Class Initialized
INFO - 2026-02-22 13:56:26 --> Language Class Initialized
INFO - 2026-02-22 13:56:26 --> Config Class Initialized
INFO - 2026-02-22 13:56:26 --> Loader Class Initialized
INFO - 2026-02-22 13:56:26 --> Helper loaded: url_helper
INFO - 2026-02-22 13:56:26 --> Helper loaded: form_helper
INFO - 2026-02-22 13:56:26 --> Helper loaded: html_helper
INFO - 2026-02-22 13:56:26 --> Helper loaded: file_helper
INFO - 2026-02-22 13:56:26 --> Helper loaded: email_helper
INFO - 2026-02-22 13:56:26 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:56:26 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:56:26 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:56:26 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:56:26 --> Database Driver Class Initialized
INFO - 2026-02-22 13:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:56:27 --> Upload Class Initialized
DEBUG - 2026-02-22 13:56:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:56:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:56:27 --> Encryption Class Initialized
INFO - 2026-02-22 13:56:27 --> Form Validation Class Initialized
INFO - 2026-02-22 13:56:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:56:27 --> Pagination Class Initialized
INFO - 2026-02-22 13:56:27 --> Email Class Initialized
INFO - 2026-02-22 13:56:27 --> Controller Class Initialized
DEBUG - 2026-02-22 13:56:27 --> Auth MX_Controller Initialized
INFO - 2026-02-22 13:56:27 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:56:27 --> Model "Auth_model" initialized
INFO - 2026-02-22 13:56:27 --> Model "Cart_model" initialized
INFO - 2026-02-22 13:56:27 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 13:56:31 --> Config Class Initialized
INFO - 2026-02-22 13:56:31 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:56:31 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:56:31 --> Utf8 Class Initialized
INFO - 2026-02-22 13:56:31 --> URI Class Initialized
INFO - 2026-02-22 13:56:31 --> Router Class Initialized
INFO - 2026-02-22 13:56:31 --> Output Class Initialized
INFO - 2026-02-22 13:56:31 --> Security Class Initialized
DEBUG - 2026-02-22 13:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:56:31 --> CSRF cookie sent
INFO - 2026-02-22 13:56:31 --> Input Class Initialized
INFO - 2026-02-22 13:56:31 --> Language Class Initialized
INFO - 2026-02-22 13:56:31 --> Language Class Initialized
INFO - 2026-02-22 13:56:31 --> Config Class Initialized
INFO - 2026-02-22 13:56:31 --> Loader Class Initialized
INFO - 2026-02-22 13:56:31 --> Helper loaded: url_helper
INFO - 2026-02-22 13:56:31 --> Helper loaded: form_helper
INFO - 2026-02-22 13:56:31 --> Helper loaded: html_helper
INFO - 2026-02-22 13:56:31 --> Helper loaded: file_helper
INFO - 2026-02-22 13:56:31 --> Helper loaded: email_helper
INFO - 2026-02-22 13:56:31 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:56:31 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:56:31 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:56:31 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:56:31 --> Database Driver Class Initialized
INFO - 2026-02-22 13:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:56:33 --> Upload Class Initialized
DEBUG - 2026-02-22 13:56:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:56:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:56:33 --> Encryption Class Initialized
INFO - 2026-02-22 13:56:33 --> Form Validation Class Initialized
INFO - 2026-02-22 13:56:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:56:33 --> Pagination Class Initialized
INFO - 2026-02-22 13:56:33 --> Email Class Initialized
INFO - 2026-02-22 13:56:33 --> Controller Class Initialized
DEBUG - 2026-02-22 13:56:33 --> Clientarea MX_Controller Initialized
INFO - 2026-02-22 13:56:33 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:56:33 --> Model "Auth_model" initialized
INFO - 2026-02-22 13:56:33 --> Model "Cart_model" initialized
INFO - 2026-02-22 13:56:33 --> Model "Clientarea_model" initialized
INFO - 2026-02-22 13:56:33 --> Model "Billing_model" initialized
INFO - 2026-02-22 13:56:33 --> Model "Common_model" initialized
INFO - 2026-02-22 13:56:33 --> Model "Order_model" initialized
INFO - 2026-02-22 13:56:33 --> Model "Support_model" initialized
DEBUG - 2026-02-22 13:56:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-22 13:56:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-22 13:56:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-22 13:56:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_index.php
INFO - 2026-02-22 13:56:33 --> Final output sent to browser
DEBUG - 2026-02-22 13:56:33 --> Total execution time: 2.3119
INFO - 2026-02-22 13:56:33 --> Config Class Initialized
INFO - 2026-02-22 13:56:33 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:56:33 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:56:33 --> Utf8 Class Initialized
INFO - 2026-02-22 13:56:33 --> URI Class Initialized
INFO - 2026-02-22 13:56:33 --> Router Class Initialized
INFO - 2026-02-22 13:56:33 --> Output Class Initialized
INFO - 2026-02-22 13:56:33 --> Security Class Initialized
DEBUG - 2026-02-22 13:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:56:33 --> CSRF cookie sent
INFO - 2026-02-22 13:56:33 --> Input Class Initialized
INFO - 2026-02-22 13:56:33 --> Language Class Initialized
INFO - 2026-02-22 13:56:33 --> Language Class Initialized
INFO - 2026-02-22 13:56:33 --> Config Class Initialized
INFO - 2026-02-22 13:56:33 --> Loader Class Initialized
INFO - 2026-02-22 13:56:33 --> Helper loaded: url_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: form_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: html_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: file_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: email_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:56:33 --> Config Class Initialized
INFO - 2026-02-22 13:56:33 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:56:33 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:56:33 --> Utf8 Class Initialized
INFO - 2026-02-22 13:56:33 --> URI Class Initialized
INFO - 2026-02-22 13:56:33 --> Config Class Initialized
INFO - 2026-02-22 13:56:33 --> Hooks Class Initialized
INFO - 2026-02-22 13:56:33 --> Router Class Initialized
INFO - 2026-02-22 13:56:33 --> Config Class Initialized
INFO - 2026-02-22 13:56:33 --> Hooks Class Initialized
INFO - 2026-02-22 13:56:33 --> Output Class Initialized
DEBUG - 2026-02-22 13:56:33 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:56:33 --> Utf8 Class Initialized
INFO - 2026-02-22 13:56:33 --> Database Driver Class Initialized
INFO - 2026-02-22 13:56:33 --> Security Class Initialized
INFO - 2026-02-22 13:56:33 --> URI Class Initialized
DEBUG - 2026-02-22 13:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:56:33 --> Input Class Initialized
INFO - 2026-02-22 13:56:33 --> Language Class Initialized
DEBUG - 2026-02-22 13:56:33 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:56:33 --> Utf8 Class Initialized
INFO - 2026-02-22 13:56:33 --> Router Class Initialized
INFO - 2026-02-22 13:56:33 --> Language Class Initialized
INFO - 2026-02-22 13:56:33 --> Config Class Initialized
INFO - 2026-02-22 13:56:33 --> URI Class Initialized
INFO - 2026-02-22 13:56:33 --> Output Class Initialized
INFO - 2026-02-22 13:56:33 --> Router Class Initialized
INFO - 2026-02-22 13:56:33 --> Loader Class Initialized
INFO - 2026-02-22 13:56:33 --> Helper loaded: url_helper
INFO - 2026-02-22 13:56:33 --> Output Class Initialized
INFO - 2026-02-22 13:56:33 --> Security Class Initialized
INFO - 2026-02-22 13:56:33 --> Security Class Initialized
DEBUG - 2026-02-22 13:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:56:33 --> Input Class Initialized
INFO - 2026-02-22 13:56:33 --> Language Class Initialized
DEBUG - 2026-02-22 13:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:56:33 --> Language Class Initialized
INFO - 2026-02-22 13:56:33 --> Config Class Initialized
INFO - 2026-02-22 13:56:33 --> Input Class Initialized
INFO - 2026-02-22 13:56:33 --> Language Class Initialized
INFO - 2026-02-22 13:56:33 --> Language Class Initialized
INFO - 2026-02-22 13:56:33 --> Config Class Initialized
INFO - 2026-02-22 13:56:33 --> Helper loaded: form_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: html_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: file_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: email_helper
INFO - 2026-02-22 13:56:33 --> Loader Class Initialized
INFO - 2026-02-22 13:56:33 --> Loader Class Initialized
INFO - 2026-02-22 13:56:33 --> Helper loaded: url_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: url_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: form_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: form_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: html_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: html_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: file_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: email_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: file_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: email_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:56:33 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:56:33 --> Database Driver Class Initialized
INFO - 2026-02-22 13:56:33 --> Database Driver Class Initialized
INFO - 2026-02-22 13:56:33 --> Database Driver Class Initialized
INFO - 2026-02-22 13:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:56:35 --> Upload Class Initialized
DEBUG - 2026-02-22 13:56:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:56:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:56:35 --> Encryption Class Initialized
INFO - 2026-02-22 13:56:35 --> Form Validation Class Initialized
INFO - 2026-02-22 13:56:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:56:35 --> Pagination Class Initialized
INFO - 2026-02-22 13:56:35 --> Email Class Initialized
INFO - 2026-02-22 13:56:35 --> Controller Class Initialized
DEBUG - 2026-02-22 13:56:35 --> Clientarea MX_Controller Initialized
INFO - 2026-02-22 13:56:35 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:56:35 --> Model "Auth_model" initialized
INFO - 2026-02-22 13:56:35 --> Model "Cart_model" initialized
INFO - 2026-02-22 13:56:35 --> Model "Clientarea_model" initialized
INFO - 2026-02-22 13:56:35 --> Model "Billing_model" initialized
INFO - 2026-02-22 13:56:35 --> Model "Common_model" initialized
INFO - 2026-02-22 13:56:35 --> Model "Order_model" initialized
INFO - 2026-02-22 13:56:35 --> Model "Support_model" initialized
INFO - 2026-02-22 13:56:36 --> Final output sent to browser
DEBUG - 2026-02-22 13:56:36 --> Total execution time: 2.7405
INFO - 2026-02-22 13:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:56:36 --> Upload Class Initialized
DEBUG - 2026-02-22 13:56:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:56:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:56:36 --> Encryption Class Initialized
INFO - 2026-02-22 13:56:36 --> Form Validation Class Initialized
INFO - 2026-02-22 13:56:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:56:36 --> Pagination Class Initialized
INFO - 2026-02-22 13:56:36 --> Email Class Initialized
INFO - 2026-02-22 13:56:36 --> Controller Class Initialized
DEBUG - 2026-02-22 13:56:36 --> Tickets MX_Controller Initialized
INFO - 2026-02-22 13:56:36 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:56:36 --> Model "Auth_model" initialized
INFO - 2026-02-22 13:56:36 --> Model "Cart_model" initialized
INFO - 2026-02-22 13:56:36 --> Model "Support_model" initialized
INFO - 2026-02-22 13:56:36 --> Model "Common_model" initialized
INFO - 2026-02-22 13:56:37 --> Final output sent to browser
DEBUG - 2026-02-22 13:56:37 --> Total execution time: 3.4367
INFO - 2026-02-22 13:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:56:37 --> Upload Class Initialized
DEBUG - 2026-02-22 13:56:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:56:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:56:37 --> Encryption Class Initialized
INFO - 2026-02-22 13:56:37 --> Form Validation Class Initialized
INFO - 2026-02-22 13:56:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:56:37 --> Pagination Class Initialized
INFO - 2026-02-22 13:56:37 --> Email Class Initialized
INFO - 2026-02-22 13:56:37 --> Controller Class Initialized
DEBUG - 2026-02-22 13:56:37 --> Cart MX_Controller Initialized
INFO - 2026-02-22 13:56:37 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:56:37 --> Model "Auth_model" initialized
INFO - 2026-02-22 13:56:37 --> Model "Cart_model" initialized
INFO - 2026-02-22 13:56:37 --> Model "Common_model" initialized
INFO - 2026-02-22 13:56:37 --> Model "Order_model" initialized
INFO - 2026-02-22 13:56:37 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 13:56:37 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-22 13:56:37 --> Final output sent to browser
DEBUG - 2026-02-22 13:56:37 --> Total execution time: 3.8094
INFO - 2026-02-22 13:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:56:37 --> Upload Class Initialized
DEBUG - 2026-02-22 13:56:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:56:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:56:37 --> Encryption Class Initialized
INFO - 2026-02-22 13:56:37 --> Form Validation Class Initialized
INFO - 2026-02-22 13:56:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:56:37 --> Pagination Class Initialized
INFO - 2026-02-22 13:56:37 --> Email Class Initialized
INFO - 2026-02-22 13:56:37 --> Controller Class Initialized
DEBUG - 2026-02-22 13:56:37 --> Billing MX_Controller Initialized
INFO - 2026-02-22 13:56:37 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:56:37 --> Model "Auth_model" initialized
INFO - 2026-02-22 13:56:37 --> Model "Cart_model" initialized
INFO - 2026-02-22 13:56:37 --> Model "Billing_model" initialized
INFO - 2026-02-22 13:56:37 --> Model "Common_model" initialized
INFO - 2026-02-22 13:56:37 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 13:56:38 --> Final output sent to browser
DEBUG - 2026-02-22 13:56:38 --> Total execution time: 4.5348
INFO - 2026-02-22 13:56:50 --> Config Class Initialized
INFO - 2026-02-22 13:56:50 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:56:50 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:56:50 --> Utf8 Class Initialized
INFO - 2026-02-22 13:56:50 --> URI Class Initialized
INFO - 2026-02-22 13:56:50 --> Router Class Initialized
INFO - 2026-02-22 13:56:50 --> Output Class Initialized
INFO - 2026-02-22 13:56:50 --> Security Class Initialized
DEBUG - 2026-02-22 13:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:56:50 --> CSRF cookie sent
INFO - 2026-02-22 13:56:50 --> Input Class Initialized
INFO - 2026-02-22 13:56:50 --> Language Class Initialized
INFO - 2026-02-22 13:56:50 --> Language Class Initialized
INFO - 2026-02-22 13:56:50 --> Config Class Initialized
INFO - 2026-02-22 13:56:50 --> Loader Class Initialized
INFO - 2026-02-22 13:56:50 --> Helper loaded: url_helper
INFO - 2026-02-22 13:56:50 --> Helper loaded: form_helper
INFO - 2026-02-22 13:56:50 --> Helper loaded: html_helper
INFO - 2026-02-22 13:56:50 --> Helper loaded: file_helper
INFO - 2026-02-22 13:56:50 --> Helper loaded: email_helper
INFO - 2026-02-22 13:56:50 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:56:50 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:56:50 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:56:50 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:56:50 --> Database Driver Class Initialized
INFO - 2026-02-22 13:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:56:52 --> Upload Class Initialized
DEBUG - 2026-02-22 13:56:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:56:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:56:52 --> Encryption Class Initialized
INFO - 2026-02-22 13:56:52 --> Form Validation Class Initialized
INFO - 2026-02-22 13:56:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:56:52 --> Pagination Class Initialized
INFO - 2026-02-22 13:56:52 --> Email Class Initialized
INFO - 2026-02-22 13:56:52 --> Controller Class Initialized
DEBUG - 2026-02-22 13:56:52 --> Billing MX_Controller Initialized
INFO - 2026-02-22 13:56:52 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:56:52 --> Model "Auth_model" initialized
INFO - 2026-02-22 13:56:52 --> Model "Cart_model" initialized
INFO - 2026-02-22 13:56:52 --> Model "Billing_model" initialized
INFO - 2026-02-22 13:56:52 --> Model "Common_model" initialized
INFO - 2026-02-22 13:56:52 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-22 13:56:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-22 13:56:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-02-22 13:56:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-22 13:56:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-22 13:56:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_invoices.php
INFO - 2026-02-22 13:56:53 --> Final output sent to browser
DEBUG - 2026-02-22 13:56:53 --> Total execution time: 3.0475
INFO - 2026-02-22 13:56:53 --> Config Class Initialized
INFO - 2026-02-22 13:56:53 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:56:53 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:56:53 --> Utf8 Class Initialized
INFO - 2026-02-22 13:56:53 --> URI Class Initialized
INFO - 2026-02-22 13:56:53 --> Router Class Initialized
INFO - 2026-02-22 13:56:53 --> Output Class Initialized
INFO - 2026-02-22 13:56:53 --> Security Class Initialized
DEBUG - 2026-02-22 13:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:56:53 --> CSRF cookie sent
INFO - 2026-02-22 13:56:53 --> Input Class Initialized
INFO - 2026-02-22 13:56:53 --> Language Class Initialized
INFO - 2026-02-22 13:56:53 --> Language Class Initialized
INFO - 2026-02-22 13:56:53 --> Config Class Initialized
INFO - 2026-02-22 13:56:53 --> Loader Class Initialized
INFO - 2026-02-22 13:56:53 --> Helper loaded: url_helper
INFO - 2026-02-22 13:56:53 --> Helper loaded: form_helper
INFO - 2026-02-22 13:56:53 --> Helper loaded: html_helper
INFO - 2026-02-22 13:56:53 --> Helper loaded: file_helper
INFO - 2026-02-22 13:56:53 --> Helper loaded: email_helper
INFO - 2026-02-22 13:56:53 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:56:53 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:56:53 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:56:53 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:56:53 --> Database Driver Class Initialized
INFO - 2026-02-22 13:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:56:55 --> Upload Class Initialized
DEBUG - 2026-02-22 13:56:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:56:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:56:55 --> Encryption Class Initialized
INFO - 2026-02-22 13:56:55 --> Form Validation Class Initialized
INFO - 2026-02-22 13:56:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:56:55 --> Pagination Class Initialized
INFO - 2026-02-22 13:56:55 --> Email Class Initialized
INFO - 2026-02-22 13:56:55 --> Controller Class Initialized
DEBUG - 2026-02-22 13:56:55 --> Cart MX_Controller Initialized
INFO - 2026-02-22 13:56:55 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:56:55 --> Model "Auth_model" initialized
INFO - 2026-02-22 13:56:55 --> Model "Cart_model" initialized
INFO - 2026-02-22 13:56:55 --> Model "Common_model" initialized
INFO - 2026-02-22 13:56:55 --> Model "Order_model" initialized
INFO - 2026-02-22 13:56:55 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 13:56:55 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-22 13:56:55 --> Final output sent to browser
DEBUG - 2026-02-22 13:56:55 --> Total execution time: 2.1704
INFO - 2026-02-22 13:58:02 --> Config Class Initialized
INFO - 2026-02-22 13:58:02 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:58:02 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:58:02 --> Utf8 Class Initialized
INFO - 2026-02-22 13:58:02 --> URI Class Initialized
INFO - 2026-02-22 13:58:02 --> Router Class Initialized
INFO - 2026-02-22 13:58:02 --> Output Class Initialized
INFO - 2026-02-22 13:58:02 --> Security Class Initialized
DEBUG - 2026-02-22 13:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:58:02 --> CSRF cookie sent
INFO - 2026-02-22 13:58:02 --> Input Class Initialized
INFO - 2026-02-22 13:58:02 --> Language Class Initialized
INFO - 2026-02-22 13:58:02 --> Language Class Initialized
INFO - 2026-02-22 13:58:02 --> Config Class Initialized
INFO - 2026-02-22 13:58:02 --> Loader Class Initialized
INFO - 2026-02-22 13:58:02 --> Helper loaded: url_helper
INFO - 2026-02-22 13:58:02 --> Helper loaded: form_helper
INFO - 2026-02-22 13:58:02 --> Helper loaded: html_helper
INFO - 2026-02-22 13:58:02 --> Helper loaded: file_helper
INFO - 2026-02-22 13:58:02 --> Helper loaded: email_helper
INFO - 2026-02-22 13:58:02 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:58:02 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:58:02 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:58:02 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:58:02 --> Database Driver Class Initialized
INFO - 2026-02-22 13:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:58:04 --> Upload Class Initialized
DEBUG - 2026-02-22 13:58:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:58:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:58:04 --> Encryption Class Initialized
INFO - 2026-02-22 13:58:04 --> Form Validation Class Initialized
INFO - 2026-02-22 13:58:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:58:04 --> Pagination Class Initialized
INFO - 2026-02-22 13:58:04 --> Email Class Initialized
INFO - 2026-02-22 13:58:04 --> Controller Class Initialized
DEBUG - 2026-02-22 13:58:04 --> Invoice MX_Controller Initialized
INFO - 2026-02-22 13:58:04 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:58:04 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:58:04 --> Model "Billing_model" initialized
INFO - 2026-02-22 13:58:04 --> Model "Common_model" initialized
INFO - 2026-02-22 13:58:04 --> Model "Invoice_model" initialized
INFO - 2026-02-22 13:58:04 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-22 13:58:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 13:58:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 13:58:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 13:58:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 13:58:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 13:58:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/invoice_list.php
INFO - 2026-02-22 13:58:04 --> Final output sent to browser
DEBUG - 2026-02-22 13:58:04 --> Total execution time: 2.4075
INFO - 2026-02-22 13:58:05 --> Config Class Initialized
INFO - 2026-02-22 13:58:05 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:58:05 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:58:05 --> Utf8 Class Initialized
INFO - 2026-02-22 13:58:05 --> URI Class Initialized
INFO - 2026-02-22 13:58:05 --> Router Class Initialized
INFO - 2026-02-22 13:58:05 --> Output Class Initialized
INFO - 2026-02-22 13:58:05 --> Security Class Initialized
DEBUG - 2026-02-22 13:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:58:05 --> CSRF cookie sent
INFO - 2026-02-22 13:58:05 --> Input Class Initialized
INFO - 2026-02-22 13:58:05 --> Language Class Initialized
INFO - 2026-02-22 13:58:05 --> Language Class Initialized
INFO - 2026-02-22 13:58:05 --> Config Class Initialized
INFO - 2026-02-22 13:58:05 --> Loader Class Initialized
INFO - 2026-02-22 13:58:05 --> Helper loaded: url_helper
INFO - 2026-02-22 13:58:05 --> Helper loaded: form_helper
INFO - 2026-02-22 13:58:05 --> Helper loaded: html_helper
INFO - 2026-02-22 13:58:05 --> Helper loaded: file_helper
INFO - 2026-02-22 13:58:05 --> Helper loaded: email_helper
INFO - 2026-02-22 13:58:05 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:58:05 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:58:05 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:58:05 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:58:05 --> Database Driver Class Initialized
INFO - 2026-02-22 13:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:58:07 --> Upload Class Initialized
DEBUG - 2026-02-22 13:58:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:58:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:58:07 --> Encryption Class Initialized
INFO - 2026-02-22 13:58:07 --> Form Validation Class Initialized
INFO - 2026-02-22 13:58:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:58:07 --> Pagination Class Initialized
INFO - 2026-02-22 13:58:07 --> Email Class Initialized
INFO - 2026-02-22 13:58:07 --> Controller Class Initialized
DEBUG - 2026-02-22 13:58:07 --> Invoice MX_Controller Initialized
INFO - 2026-02-22 13:58:07 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:58:07 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:58:07 --> Model "Billing_model" initialized
INFO - 2026-02-22 13:58:07 --> Model "Common_model" initialized
INFO - 2026-02-22 13:58:07 --> Model "Invoice_model" initialized
INFO - 2026-02-22 13:58:07 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 13:58:29 --> Config Class Initialized
INFO - 2026-02-22 13:58:29 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:58:29 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:58:29 --> Utf8 Class Initialized
INFO - 2026-02-22 13:58:29 --> URI Class Initialized
INFO - 2026-02-22 13:58:29 --> Router Class Initialized
INFO - 2026-02-22 13:58:29 --> Output Class Initialized
INFO - 2026-02-22 13:58:29 --> Security Class Initialized
DEBUG - 2026-02-22 13:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:58:29 --> CSRF cookie sent
INFO - 2026-02-22 13:58:29 --> Input Class Initialized
INFO - 2026-02-22 13:58:29 --> Language Class Initialized
INFO - 2026-02-22 13:58:29 --> Language Class Initialized
INFO - 2026-02-22 13:58:29 --> Config Class Initialized
INFO - 2026-02-22 13:58:29 --> Loader Class Initialized
INFO - 2026-02-22 13:58:29 --> Helper loaded: url_helper
INFO - 2026-02-22 13:58:29 --> Helper loaded: form_helper
INFO - 2026-02-22 13:58:29 --> Helper loaded: html_helper
INFO - 2026-02-22 13:58:29 --> Helper loaded: file_helper
INFO - 2026-02-22 13:58:29 --> Helper loaded: email_helper
INFO - 2026-02-22 13:58:29 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:58:29 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:58:29 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:58:29 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:58:29 --> Database Driver Class Initialized
INFO - 2026-02-22 13:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:58:31 --> Upload Class Initialized
DEBUG - 2026-02-22 13:58:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:58:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:58:31 --> Encryption Class Initialized
INFO - 2026-02-22 13:58:31 --> Form Validation Class Initialized
INFO - 2026-02-22 13:58:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:58:31 --> Pagination Class Initialized
INFO - 2026-02-22 13:58:31 --> Email Class Initialized
INFO - 2026-02-22 13:58:31 --> Controller Class Initialized
DEBUG - 2026-02-22 13:58:31 --> Order MX_Controller Initialized
INFO - 2026-02-22 13:58:31 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:58:31 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:58:32 --> Model "Order_model" initialized
INFO - 2026-02-22 13:58:32 --> Model "Common_model" initialized
INFO - 2026-02-22 13:58:32 --> Model "Currency_model" initialized
DEBUG - 2026-02-22 13:58:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 13:58:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 13:58:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 13:58:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 13:58:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 13:58:32 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/order_list.php
INFO - 2026-02-22 13:58:32 --> Final output sent to browser
DEBUG - 2026-02-22 13:58:32 --> Total execution time: 2.4556
INFO - 2026-02-22 13:58:32 --> Config Class Initialized
INFO - 2026-02-22 13:58:32 --> Hooks Class Initialized
DEBUG - 2026-02-22 13:58:32 --> UTF-8 Support Enabled
INFO - 2026-02-22 13:58:32 --> Utf8 Class Initialized
INFO - 2026-02-22 13:58:32 --> URI Class Initialized
INFO - 2026-02-22 13:58:32 --> Router Class Initialized
INFO - 2026-02-22 13:58:32 --> Output Class Initialized
INFO - 2026-02-22 13:58:32 --> Security Class Initialized
DEBUG - 2026-02-22 13:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 13:58:32 --> CSRF cookie sent
INFO - 2026-02-22 13:58:32 --> Input Class Initialized
INFO - 2026-02-22 13:58:32 --> Language Class Initialized
INFO - 2026-02-22 13:58:32 --> Language Class Initialized
INFO - 2026-02-22 13:58:32 --> Config Class Initialized
INFO - 2026-02-22 13:58:32 --> Loader Class Initialized
INFO - 2026-02-22 13:58:32 --> Helper loaded: url_helper
INFO - 2026-02-22 13:58:32 --> Helper loaded: form_helper
INFO - 2026-02-22 13:58:32 --> Helper loaded: html_helper
INFO - 2026-02-22 13:58:32 --> Helper loaded: file_helper
INFO - 2026-02-22 13:58:32 --> Helper loaded: email_helper
INFO - 2026-02-22 13:58:32 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 13:58:32 --> Helper loaded: ssp_helper
INFO - 2026-02-22 13:58:32 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 13:58:32 --> Helper loaded: domain_helper
INFO - 2026-02-22 13:58:32 --> Database Driver Class Initialized
INFO - 2026-02-22 13:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 13:58:34 --> Upload Class Initialized
DEBUG - 2026-02-22 13:58:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 13:58:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 13:58:34 --> Encryption Class Initialized
INFO - 2026-02-22 13:58:34 --> Form Validation Class Initialized
INFO - 2026-02-22 13:58:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 13:58:34 --> Pagination Class Initialized
INFO - 2026-02-22 13:58:34 --> Email Class Initialized
INFO - 2026-02-22 13:58:34 --> Controller Class Initialized
DEBUG - 2026-02-22 13:58:34 --> Order MX_Controller Initialized
INFO - 2026-02-22 13:58:34 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 13:58:34 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 13:58:34 --> Model "Order_model" initialized
INFO - 2026-02-22 13:58:34 --> Model "Common_model" initialized
INFO - 2026-02-22 13:58:34 --> Model "Currency_model" initialized
INFO - 2026-02-22 14:00:50 --> Config Class Initialized
INFO - 2026-02-22 14:00:50 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:00:50 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:00:50 --> Utf8 Class Initialized
INFO - 2026-02-22 14:00:50 --> URI Class Initialized
INFO - 2026-02-22 14:00:50 --> Router Class Initialized
INFO - 2026-02-22 14:00:50 --> Output Class Initialized
INFO - 2026-02-22 14:00:50 --> Security Class Initialized
DEBUG - 2026-02-22 14:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:00:50 --> CSRF cookie sent
INFO - 2026-02-22 14:00:50 --> Input Class Initialized
INFO - 2026-02-22 14:00:50 --> Language Class Initialized
INFO - 2026-02-22 14:00:50 --> Language Class Initialized
INFO - 2026-02-22 14:00:50 --> Config Class Initialized
INFO - 2026-02-22 14:00:50 --> Loader Class Initialized
INFO - 2026-02-22 14:00:50 --> Helper loaded: url_helper
INFO - 2026-02-22 14:00:50 --> Helper loaded: form_helper
INFO - 2026-02-22 14:00:50 --> Helper loaded: html_helper
INFO - 2026-02-22 14:00:50 --> Helper loaded: file_helper
INFO - 2026-02-22 14:00:50 --> Helper loaded: email_helper
INFO - 2026-02-22 14:00:50 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:00:50 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:00:50 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:00:50 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:00:50 --> Database Driver Class Initialized
INFO - 2026-02-22 14:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:00:52 --> Upload Class Initialized
DEBUG - 2026-02-22 14:00:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:00:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:00:52 --> Encryption Class Initialized
INFO - 2026-02-22 14:00:52 --> Form Validation Class Initialized
INFO - 2026-02-22 14:00:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:00:52 --> Pagination Class Initialized
INFO - 2026-02-22 14:00:52 --> Email Class Initialized
INFO - 2026-02-22 14:00:52 --> Controller Class Initialized
DEBUG - 2026-02-22 14:00:52 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:00:52 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:00:52 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:00:52 --> Model "Company_model" initialized
INFO - 2026-02-22 14:00:52 --> Model "Common_model" initialized
DEBUG - 2026-02-22 14:00:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:00:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:00:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:00:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:00:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:00:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/company_list.php
INFO - 2026-02-22 14:00:52 --> Final output sent to browser
DEBUG - 2026-02-22 14:00:52 --> Total execution time: 2.5303
INFO - 2026-02-22 14:00:53 --> Config Class Initialized
INFO - 2026-02-22 14:00:53 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:00:53 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:00:53 --> Utf8 Class Initialized
INFO - 2026-02-22 14:00:53 --> URI Class Initialized
INFO - 2026-02-22 14:00:53 --> Router Class Initialized
INFO - 2026-02-22 14:00:53 --> Output Class Initialized
INFO - 2026-02-22 14:00:53 --> Security Class Initialized
DEBUG - 2026-02-22 14:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:00:53 --> CSRF cookie sent
INFO - 2026-02-22 14:00:53 --> Input Class Initialized
INFO - 2026-02-22 14:00:53 --> Language Class Initialized
INFO - 2026-02-22 14:00:53 --> Language Class Initialized
INFO - 2026-02-22 14:00:53 --> Config Class Initialized
INFO - 2026-02-22 14:00:53 --> Loader Class Initialized
INFO - 2026-02-22 14:00:53 --> Helper loaded: url_helper
INFO - 2026-02-22 14:00:53 --> Helper loaded: form_helper
INFO - 2026-02-22 14:00:53 --> Helper loaded: html_helper
INFO - 2026-02-22 14:00:53 --> Helper loaded: file_helper
INFO - 2026-02-22 14:00:53 --> Helper loaded: email_helper
INFO - 2026-02-22 14:00:53 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:00:53 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:00:53 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:00:53 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:00:53 --> Database Driver Class Initialized
INFO - 2026-02-22 14:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:00:55 --> Upload Class Initialized
DEBUG - 2026-02-22 14:00:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:00:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:00:55 --> Encryption Class Initialized
INFO - 2026-02-22 14:00:55 --> Form Validation Class Initialized
INFO - 2026-02-22 14:00:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:00:55 --> Pagination Class Initialized
INFO - 2026-02-22 14:00:55 --> Email Class Initialized
INFO - 2026-02-22 14:00:55 --> Controller Class Initialized
DEBUG - 2026-02-22 14:00:55 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:00:55 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:00:55 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:00:55 --> Model "Company_model" initialized
INFO - 2026-02-22 14:00:55 --> Model "Common_model" initialized
INFO - 2026-02-22 14:01:21 --> Config Class Initialized
INFO - 2026-02-22 14:01:21 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:01:21 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:01:21 --> Utf8 Class Initialized
INFO - 2026-02-22 14:01:21 --> URI Class Initialized
INFO - 2026-02-22 14:01:21 --> Router Class Initialized
INFO - 2026-02-22 14:01:21 --> Output Class Initialized
INFO - 2026-02-22 14:01:21 --> Security Class Initialized
DEBUG - 2026-02-22 14:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:01:21 --> CSRF cookie sent
INFO - 2026-02-22 14:01:21 --> Input Class Initialized
INFO - 2026-02-22 14:01:21 --> Language Class Initialized
INFO - 2026-02-22 14:01:21 --> Language Class Initialized
INFO - 2026-02-22 14:01:21 --> Config Class Initialized
INFO - 2026-02-22 14:01:21 --> Loader Class Initialized
INFO - 2026-02-22 14:01:21 --> Helper loaded: url_helper
INFO - 2026-02-22 14:01:21 --> Helper loaded: form_helper
INFO - 2026-02-22 14:01:21 --> Helper loaded: html_helper
INFO - 2026-02-22 14:01:21 --> Helper loaded: file_helper
INFO - 2026-02-22 14:01:21 --> Helper loaded: email_helper
INFO - 2026-02-22 14:01:21 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:01:21 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:01:21 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:01:21 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:01:21 --> Database Driver Class Initialized
INFO - 2026-02-22 14:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:01:23 --> Upload Class Initialized
DEBUG - 2026-02-22 14:01:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:01:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:01:23 --> Encryption Class Initialized
INFO - 2026-02-22 14:01:23 --> Form Validation Class Initialized
INFO - 2026-02-22 14:01:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:01:23 --> Pagination Class Initialized
INFO - 2026-02-22 14:01:23 --> Email Class Initialized
INFO - 2026-02-22 14:01:23 --> Controller Class Initialized
DEBUG - 2026-02-22 14:01:23 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:01:23 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:01:23 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:01:23 --> Model "Company_model" initialized
INFO - 2026-02-22 14:01:23 --> Model "Common_model" initialized
DEBUG - 2026-02-22 14:01:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:01:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:01:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:01:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:01:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:01:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/company_list.php
INFO - 2026-02-22 14:01:23 --> Final output sent to browser
DEBUG - 2026-02-22 14:01:23 --> Total execution time: 2.3657
INFO - 2026-02-22 14:01:23 --> Config Class Initialized
INFO - 2026-02-22 14:01:23 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:01:23 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:01:23 --> Utf8 Class Initialized
INFO - 2026-02-22 14:01:23 --> URI Class Initialized
INFO - 2026-02-22 14:01:23 --> Router Class Initialized
INFO - 2026-02-22 14:01:23 --> Output Class Initialized
INFO - 2026-02-22 14:01:23 --> Security Class Initialized
DEBUG - 2026-02-22 14:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:01:23 --> CSRF cookie sent
INFO - 2026-02-22 14:01:23 --> Input Class Initialized
INFO - 2026-02-22 14:01:23 --> Language Class Initialized
INFO - 2026-02-22 14:01:23 --> Language Class Initialized
INFO - 2026-02-22 14:01:23 --> Config Class Initialized
INFO - 2026-02-22 14:01:23 --> Loader Class Initialized
INFO - 2026-02-22 14:01:23 --> Helper loaded: url_helper
INFO - 2026-02-22 14:01:23 --> Helper loaded: form_helper
INFO - 2026-02-22 14:01:23 --> Helper loaded: html_helper
INFO - 2026-02-22 14:01:23 --> Helper loaded: file_helper
INFO - 2026-02-22 14:01:23 --> Helper loaded: email_helper
INFO - 2026-02-22 14:01:23 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:01:23 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:01:23 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:01:23 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:01:23 --> Database Driver Class Initialized
INFO - 2026-02-22 14:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:01:25 --> Upload Class Initialized
DEBUG - 2026-02-22 14:01:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:01:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:01:25 --> Encryption Class Initialized
INFO - 2026-02-22 14:01:25 --> Form Validation Class Initialized
INFO - 2026-02-22 14:01:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:01:25 --> Pagination Class Initialized
INFO - 2026-02-22 14:01:25 --> Email Class Initialized
INFO - 2026-02-22 14:01:25 --> Controller Class Initialized
DEBUG - 2026-02-22 14:01:25 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:01:25 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:01:25 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:01:25 --> Model "Company_model" initialized
INFO - 2026-02-22 14:01:25 --> Model "Common_model" initialized
INFO - 2026-02-22 14:01:35 --> Config Class Initialized
INFO - 2026-02-22 14:01:35 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:01:35 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:01:35 --> Utf8 Class Initialized
INFO - 2026-02-22 14:01:35 --> URI Class Initialized
INFO - 2026-02-22 14:01:35 --> Router Class Initialized
INFO - 2026-02-22 14:01:35 --> Output Class Initialized
INFO - 2026-02-22 14:01:35 --> Security Class Initialized
DEBUG - 2026-02-22 14:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:01:35 --> CSRF cookie sent
INFO - 2026-02-22 14:01:35 --> Input Class Initialized
INFO - 2026-02-22 14:01:35 --> Language Class Initialized
INFO - 2026-02-22 14:01:35 --> Language Class Initialized
INFO - 2026-02-22 14:01:35 --> Config Class Initialized
INFO - 2026-02-22 14:01:35 --> Loader Class Initialized
INFO - 2026-02-22 14:01:35 --> Helper loaded: url_helper
INFO - 2026-02-22 14:01:35 --> Helper loaded: form_helper
INFO - 2026-02-22 14:01:35 --> Helper loaded: html_helper
INFO - 2026-02-22 14:01:35 --> Helper loaded: file_helper
INFO - 2026-02-22 14:01:35 --> Helper loaded: email_helper
INFO - 2026-02-22 14:01:35 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:01:35 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:01:35 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:01:35 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:01:35 --> Database Driver Class Initialized
INFO - 2026-02-22 14:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:01:37 --> Upload Class Initialized
DEBUG - 2026-02-22 14:01:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:01:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:01:37 --> Encryption Class Initialized
INFO - 2026-02-22 14:01:37 --> Form Validation Class Initialized
INFO - 2026-02-22 14:01:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:01:37 --> Pagination Class Initialized
INFO - 2026-02-22 14:01:37 --> Email Class Initialized
INFO - 2026-02-22 14:01:37 --> Controller Class Initialized
DEBUG - 2026-02-22 14:01:37 --> Order MX_Controller Initialized
INFO - 2026-02-22 14:01:37 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:01:37 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:01:37 --> Model "Order_model" initialized
INFO - 2026-02-22 14:01:37 --> Model "Common_model" initialized
INFO - 2026-02-22 14:01:37 --> Model "Currency_model" initialized
DEBUG - 2026-02-22 14:01:37 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:01:37 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:01:37 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:01:37 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:01:37 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:01:37 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/order_list.php
INFO - 2026-02-22 14:01:37 --> Final output sent to browser
DEBUG - 2026-02-22 14:01:37 --> Total execution time: 2.4819
INFO - 2026-02-22 14:01:38 --> Config Class Initialized
INFO - 2026-02-22 14:01:38 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:01:38 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:01:38 --> Utf8 Class Initialized
INFO - 2026-02-22 14:01:38 --> URI Class Initialized
INFO - 2026-02-22 14:01:38 --> Router Class Initialized
INFO - 2026-02-22 14:01:38 --> Output Class Initialized
INFO - 2026-02-22 14:01:38 --> Security Class Initialized
DEBUG - 2026-02-22 14:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:01:38 --> CSRF cookie sent
INFO - 2026-02-22 14:01:38 --> Input Class Initialized
INFO - 2026-02-22 14:01:38 --> Language Class Initialized
INFO - 2026-02-22 14:01:38 --> Language Class Initialized
INFO - 2026-02-22 14:01:38 --> Config Class Initialized
INFO - 2026-02-22 14:01:38 --> Loader Class Initialized
INFO - 2026-02-22 14:01:38 --> Helper loaded: url_helper
INFO - 2026-02-22 14:01:38 --> Helper loaded: form_helper
INFO - 2026-02-22 14:01:38 --> Helper loaded: html_helper
INFO - 2026-02-22 14:01:38 --> Helper loaded: file_helper
INFO - 2026-02-22 14:01:38 --> Helper loaded: email_helper
INFO - 2026-02-22 14:01:38 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:01:38 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:01:38 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:01:38 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:01:38 --> Database Driver Class Initialized
INFO - 2026-02-22 14:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:01:39 --> Upload Class Initialized
DEBUG - 2026-02-22 14:01:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:01:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:01:39 --> Encryption Class Initialized
INFO - 2026-02-22 14:01:39 --> Form Validation Class Initialized
INFO - 2026-02-22 14:01:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:01:39 --> Pagination Class Initialized
INFO - 2026-02-22 14:01:40 --> Email Class Initialized
INFO - 2026-02-22 14:01:40 --> Controller Class Initialized
DEBUG - 2026-02-22 14:01:40 --> Order MX_Controller Initialized
INFO - 2026-02-22 14:01:40 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:01:40 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:01:40 --> Model "Order_model" initialized
INFO - 2026-02-22 14:01:40 --> Model "Common_model" initialized
INFO - 2026-02-22 14:01:40 --> Model "Currency_model" initialized
INFO - 2026-02-22 14:01:48 --> Config Class Initialized
INFO - 2026-02-22 14:01:48 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:01:48 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:01:48 --> Utf8 Class Initialized
INFO - 2026-02-22 14:01:48 --> URI Class Initialized
INFO - 2026-02-22 14:01:48 --> Router Class Initialized
INFO - 2026-02-22 14:01:48 --> Output Class Initialized
INFO - 2026-02-22 14:01:48 --> Security Class Initialized
DEBUG - 2026-02-22 14:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:01:48 --> CSRF cookie sent
INFO - 2026-02-22 14:01:48 --> Input Class Initialized
INFO - 2026-02-22 14:01:48 --> Language Class Initialized
INFO - 2026-02-22 14:01:48 --> Language Class Initialized
INFO - 2026-02-22 14:01:48 --> Config Class Initialized
INFO - 2026-02-22 14:01:48 --> Loader Class Initialized
INFO - 2026-02-22 14:01:48 --> Helper loaded: url_helper
INFO - 2026-02-22 14:01:48 --> Helper loaded: form_helper
INFO - 2026-02-22 14:01:48 --> Helper loaded: html_helper
INFO - 2026-02-22 14:01:48 --> Helper loaded: file_helper
INFO - 2026-02-22 14:01:48 --> Helper loaded: email_helper
INFO - 2026-02-22 14:01:48 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:01:48 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:01:48 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:01:48 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:01:48 --> Database Driver Class Initialized
INFO - 2026-02-22 14:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:01:50 --> Upload Class Initialized
DEBUG - 2026-02-22 14:01:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:01:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:01:50 --> Encryption Class Initialized
INFO - 2026-02-22 14:01:50 --> Form Validation Class Initialized
INFO - 2026-02-22 14:01:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:01:50 --> Pagination Class Initialized
INFO - 2026-02-22 14:01:50 --> Email Class Initialized
INFO - 2026-02-22 14:01:50 --> Controller Class Initialized
DEBUG - 2026-02-22 14:01:50 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:01:50 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:01:50 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:01:50 --> Model "Company_model" initialized
INFO - 2026-02-22 14:01:50 --> Model "Common_model" initialized
DEBUG - 2026-02-22 14:01:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:01:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:01:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:01:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:01:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:01:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/company_list.php
INFO - 2026-02-22 14:01:51 --> Final output sent to browser
DEBUG - 2026-02-22 14:01:51 --> Total execution time: 2.4891
INFO - 2026-02-22 14:01:51 --> Config Class Initialized
INFO - 2026-02-22 14:01:51 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:01:51 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:01:51 --> Utf8 Class Initialized
INFO - 2026-02-22 14:01:51 --> URI Class Initialized
INFO - 2026-02-22 14:01:51 --> Router Class Initialized
INFO - 2026-02-22 14:01:51 --> Output Class Initialized
INFO - 2026-02-22 14:01:51 --> Security Class Initialized
DEBUG - 2026-02-22 14:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:01:51 --> CSRF cookie sent
INFO - 2026-02-22 14:01:51 --> Input Class Initialized
INFO - 2026-02-22 14:01:51 --> Language Class Initialized
INFO - 2026-02-22 14:01:51 --> Language Class Initialized
INFO - 2026-02-22 14:01:51 --> Config Class Initialized
INFO - 2026-02-22 14:01:51 --> Loader Class Initialized
INFO - 2026-02-22 14:01:51 --> Helper loaded: url_helper
INFO - 2026-02-22 14:01:51 --> Helper loaded: form_helper
INFO - 2026-02-22 14:01:51 --> Helper loaded: html_helper
INFO - 2026-02-22 14:01:51 --> Helper loaded: file_helper
INFO - 2026-02-22 14:01:51 --> Helper loaded: email_helper
INFO - 2026-02-22 14:01:51 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:01:51 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:01:51 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:01:51 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:01:51 --> Database Driver Class Initialized
INFO - 2026-02-22 14:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:01:53 --> Upload Class Initialized
DEBUG - 2026-02-22 14:01:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:01:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:01:53 --> Encryption Class Initialized
INFO - 2026-02-22 14:01:53 --> Form Validation Class Initialized
INFO - 2026-02-22 14:01:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:01:53 --> Pagination Class Initialized
INFO - 2026-02-22 14:01:53 --> Email Class Initialized
INFO - 2026-02-22 14:01:53 --> Controller Class Initialized
DEBUG - 2026-02-22 14:01:53 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:01:53 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:01:53 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:01:53 --> Model "Company_model" initialized
INFO - 2026-02-22 14:01:53 --> Model "Common_model" initialized
INFO - 2026-02-22 14:04:02 --> Config Class Initialized
INFO - 2026-02-22 14:04:02 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:04:02 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:04:02 --> Utf8 Class Initialized
INFO - 2026-02-22 14:04:02 --> URI Class Initialized
INFO - 2026-02-22 14:04:02 --> Router Class Initialized
INFO - 2026-02-22 14:04:02 --> Output Class Initialized
INFO - 2026-02-22 14:04:02 --> Security Class Initialized
DEBUG - 2026-02-22 14:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:04:02 --> CSRF cookie sent
INFO - 2026-02-22 14:04:02 --> Input Class Initialized
INFO - 2026-02-22 14:04:02 --> Language Class Initialized
INFO - 2026-02-22 14:04:02 --> Language Class Initialized
INFO - 2026-02-22 14:04:02 --> Config Class Initialized
INFO - 2026-02-22 14:04:02 --> Loader Class Initialized
INFO - 2026-02-22 14:04:02 --> Helper loaded: url_helper
INFO - 2026-02-22 14:04:02 --> Helper loaded: form_helper
INFO - 2026-02-22 14:04:02 --> Helper loaded: html_helper
INFO - 2026-02-22 14:04:02 --> Helper loaded: file_helper
INFO - 2026-02-22 14:04:02 --> Helper loaded: email_helper
INFO - 2026-02-22 14:04:02 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:04:02 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:04:02 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:04:02 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:04:02 --> Database Driver Class Initialized
INFO - 2026-02-22 14:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:04:04 --> Upload Class Initialized
DEBUG - 2026-02-22 14:04:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:04:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:04:04 --> Encryption Class Initialized
INFO - 2026-02-22 14:04:04 --> Form Validation Class Initialized
INFO - 2026-02-22 14:04:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:04:04 --> Pagination Class Initialized
INFO - 2026-02-22 14:04:04 --> Email Class Initialized
INFO - 2026-02-22 14:04:04 --> Controller Class Initialized
DEBUG - 2026-02-22 14:04:04 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:04:04 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:04:04 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:04:04 --> Model "Company_model" initialized
INFO - 2026-02-22 14:04:04 --> Model "Common_model" initialized
DEBUG - 2026-02-22 14:04:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:04:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:04:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:04:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:04:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:04:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/company_list.php
INFO - 2026-02-22 14:04:04 --> Final output sent to browser
DEBUG - 2026-02-22 14:04:04 --> Total execution time: 2.4273
INFO - 2026-02-22 14:04:05 --> Config Class Initialized
INFO - 2026-02-22 14:04:05 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:04:05 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:04:05 --> Utf8 Class Initialized
INFO - 2026-02-22 14:04:05 --> URI Class Initialized
INFO - 2026-02-22 14:04:05 --> Router Class Initialized
INFO - 2026-02-22 14:04:05 --> Output Class Initialized
INFO - 2026-02-22 14:04:05 --> Security Class Initialized
DEBUG - 2026-02-22 14:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:04:05 --> CSRF cookie sent
INFO - 2026-02-22 14:04:05 --> Input Class Initialized
INFO - 2026-02-22 14:04:05 --> Language Class Initialized
INFO - 2026-02-22 14:04:05 --> Language Class Initialized
INFO - 2026-02-22 14:04:05 --> Config Class Initialized
INFO - 2026-02-22 14:04:05 --> Loader Class Initialized
INFO - 2026-02-22 14:04:05 --> Helper loaded: url_helper
INFO - 2026-02-22 14:04:05 --> Helper loaded: form_helper
INFO - 2026-02-22 14:04:05 --> Helper loaded: html_helper
INFO - 2026-02-22 14:04:05 --> Helper loaded: file_helper
INFO - 2026-02-22 14:04:05 --> Helper loaded: email_helper
INFO - 2026-02-22 14:04:05 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:04:05 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:04:05 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:04:05 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:04:05 --> Database Driver Class Initialized
INFO - 2026-02-22 14:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:04:06 --> Upload Class Initialized
DEBUG - 2026-02-22 14:04:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:04:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:04:06 --> Encryption Class Initialized
INFO - 2026-02-22 14:04:06 --> Form Validation Class Initialized
INFO - 2026-02-22 14:04:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:04:06 --> Pagination Class Initialized
INFO - 2026-02-22 14:04:06 --> Email Class Initialized
INFO - 2026-02-22 14:04:06 --> Controller Class Initialized
DEBUG - 2026-02-22 14:04:06 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:04:06 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:04:06 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:04:06 --> Model "Company_model" initialized
INFO - 2026-02-22 14:04:06 --> Model "Common_model" initialized
INFO - 2026-02-22 14:04:23 --> Config Class Initialized
INFO - 2026-02-22 14:04:23 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:04:23 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:04:23 --> Utf8 Class Initialized
INFO - 2026-02-22 14:04:23 --> URI Class Initialized
INFO - 2026-02-22 14:04:23 --> Router Class Initialized
INFO - 2026-02-22 14:04:23 --> Output Class Initialized
INFO - 2026-02-22 14:04:23 --> Security Class Initialized
DEBUG - 2026-02-22 14:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:04:23 --> CSRF cookie sent
INFO - 2026-02-22 14:04:23 --> Input Class Initialized
INFO - 2026-02-22 14:04:23 --> Language Class Initialized
INFO - 2026-02-22 14:04:23 --> Language Class Initialized
INFO - 2026-02-22 14:04:23 --> Config Class Initialized
INFO - 2026-02-22 14:04:23 --> Loader Class Initialized
INFO - 2026-02-22 14:04:23 --> Helper loaded: url_helper
INFO - 2026-02-22 14:04:23 --> Helper loaded: form_helper
INFO - 2026-02-22 14:04:23 --> Helper loaded: html_helper
INFO - 2026-02-22 14:04:23 --> Helper loaded: file_helper
INFO - 2026-02-22 14:04:23 --> Helper loaded: email_helper
INFO - 2026-02-22 14:04:23 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:04:23 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:04:23 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:04:23 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:04:23 --> Database Driver Class Initialized
INFO - 2026-02-22 14:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:04:25 --> Upload Class Initialized
DEBUG - 2026-02-22 14:04:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:04:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:04:25 --> Encryption Class Initialized
INFO - 2026-02-22 14:04:25 --> Form Validation Class Initialized
INFO - 2026-02-22 14:04:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:04:25 --> Pagination Class Initialized
INFO - 2026-02-22 14:04:25 --> Email Class Initialized
INFO - 2026-02-22 14:04:25 --> Controller Class Initialized
DEBUG - 2026-02-22 14:04:25 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:04:25 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:04:25 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:04:25 --> Model "Company_model" initialized
INFO - 2026-02-22 14:04:25 --> Model "Common_model" initialized
INFO - 2026-02-22 14:04:30 --> Config Class Initialized
INFO - 2026-02-22 14:04:30 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:04:30 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:04:30 --> Utf8 Class Initialized
INFO - 2026-02-22 14:04:30 --> URI Class Initialized
INFO - 2026-02-22 14:04:30 --> Router Class Initialized
INFO - 2026-02-22 14:04:30 --> Output Class Initialized
INFO - 2026-02-22 14:04:30 --> Security Class Initialized
DEBUG - 2026-02-22 14:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:04:30 --> CSRF cookie sent
INFO - 2026-02-22 14:04:30 --> Input Class Initialized
INFO - 2026-02-22 14:04:30 --> Language Class Initialized
INFO - 2026-02-22 14:04:30 --> Language Class Initialized
INFO - 2026-02-22 14:04:30 --> Config Class Initialized
INFO - 2026-02-22 14:04:30 --> Loader Class Initialized
INFO - 2026-02-22 14:04:30 --> Helper loaded: url_helper
INFO - 2026-02-22 14:04:30 --> Helper loaded: form_helper
INFO - 2026-02-22 14:04:30 --> Helper loaded: html_helper
INFO - 2026-02-22 14:04:30 --> Helper loaded: file_helper
INFO - 2026-02-22 14:04:30 --> Helper loaded: email_helper
INFO - 2026-02-22 14:04:30 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:04:30 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:04:30 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:04:30 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:04:30 --> Database Driver Class Initialized
INFO - 2026-02-22 14:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:04:32 --> Upload Class Initialized
DEBUG - 2026-02-22 14:04:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:04:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:04:32 --> Encryption Class Initialized
INFO - 2026-02-22 14:04:32 --> Form Validation Class Initialized
INFO - 2026-02-22 14:04:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:04:32 --> Pagination Class Initialized
INFO - 2026-02-22 14:04:32 --> Email Class Initialized
INFO - 2026-02-22 14:04:32 --> Controller Class Initialized
DEBUG - 2026-02-22 14:04:32 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:04:32 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:04:32 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:04:32 --> Model "Company_model" initialized
INFO - 2026-02-22 14:04:32 --> Model "Common_model" initialized
INFO - 2026-02-22 14:04:50 --> Config Class Initialized
INFO - 2026-02-22 14:04:50 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:04:50 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:04:50 --> Utf8 Class Initialized
INFO - 2026-02-22 14:04:50 --> URI Class Initialized
INFO - 2026-02-22 14:04:50 --> Router Class Initialized
INFO - 2026-02-22 14:04:50 --> Output Class Initialized
INFO - 2026-02-22 14:04:50 --> Security Class Initialized
DEBUG - 2026-02-22 14:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:04:50 --> CSRF cookie sent
INFO - 2026-02-22 14:04:50 --> Input Class Initialized
INFO - 2026-02-22 14:04:50 --> Language Class Initialized
INFO - 2026-02-22 14:04:50 --> Language Class Initialized
INFO - 2026-02-22 14:04:50 --> Config Class Initialized
INFO - 2026-02-22 14:04:50 --> Loader Class Initialized
INFO - 2026-02-22 14:04:50 --> Helper loaded: url_helper
INFO - 2026-02-22 14:04:50 --> Helper loaded: form_helper
INFO - 2026-02-22 14:04:50 --> Helper loaded: html_helper
INFO - 2026-02-22 14:04:50 --> Helper loaded: file_helper
INFO - 2026-02-22 14:04:50 --> Helper loaded: email_helper
INFO - 2026-02-22 14:04:50 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:04:50 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:04:50 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:04:50 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:04:50 --> Database Driver Class Initialized
INFO - 2026-02-22 14:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:04:52 --> Upload Class Initialized
DEBUG - 2026-02-22 14:04:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:04:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:04:52 --> Encryption Class Initialized
INFO - 2026-02-22 14:04:52 --> Form Validation Class Initialized
INFO - 2026-02-22 14:04:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:04:52 --> Pagination Class Initialized
INFO - 2026-02-22 14:04:52 --> Email Class Initialized
INFO - 2026-02-22 14:04:52 --> Controller Class Initialized
DEBUG - 2026-02-22 14:04:52 --> Ticket MX_Controller Initialized
INFO - 2026-02-22 14:04:52 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:04:52 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:04:52 --> Model "Support_model" initialized
INFO - 2026-02-22 14:04:52 --> Model "Common_model" initialized
DEBUG - 2026-02-22 14:04:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:04:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:04:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:04:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:04:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:04:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/ticket_list.php
INFO - 2026-02-22 14:04:53 --> Final output sent to browser
DEBUG - 2026-02-22 14:04:53 --> Total execution time: 2.7917
INFO - 2026-02-22 14:04:53 --> Config Class Initialized
INFO - 2026-02-22 14:04:53 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:04:53 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:04:53 --> Utf8 Class Initialized
INFO - 2026-02-22 14:04:53 --> URI Class Initialized
INFO - 2026-02-22 14:04:53 --> Router Class Initialized
INFO - 2026-02-22 14:04:53 --> Output Class Initialized
INFO - 2026-02-22 14:04:53 --> Security Class Initialized
DEBUG - 2026-02-22 14:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:04:53 --> CSRF cookie sent
INFO - 2026-02-22 14:04:53 --> Input Class Initialized
INFO - 2026-02-22 14:04:53 --> Language Class Initialized
INFO - 2026-02-22 14:04:53 --> Language Class Initialized
INFO - 2026-02-22 14:04:53 --> Config Class Initialized
INFO - 2026-02-22 14:04:53 --> Loader Class Initialized
INFO - 2026-02-22 14:04:53 --> Helper loaded: url_helper
INFO - 2026-02-22 14:04:53 --> Helper loaded: form_helper
INFO - 2026-02-22 14:04:53 --> Helper loaded: html_helper
INFO - 2026-02-22 14:04:53 --> Helper loaded: file_helper
INFO - 2026-02-22 14:04:53 --> Helper loaded: email_helper
INFO - 2026-02-22 14:04:53 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:04:53 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:04:53 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:04:53 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:04:53 --> Database Driver Class Initialized
INFO - 2026-02-22 14:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:04:55 --> Upload Class Initialized
DEBUG - 2026-02-22 14:04:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:04:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:04:55 --> Encryption Class Initialized
INFO - 2026-02-22 14:04:55 --> Form Validation Class Initialized
INFO - 2026-02-22 14:04:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:04:55 --> Pagination Class Initialized
INFO - 2026-02-22 14:04:55 --> Email Class Initialized
INFO - 2026-02-22 14:04:55 --> Controller Class Initialized
DEBUG - 2026-02-22 14:04:55 --> Ticket MX_Controller Initialized
INFO - 2026-02-22 14:04:55 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:04:55 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:04:55 --> Model "Support_model" initialized
INFO - 2026-02-22 14:04:55 --> Model "Common_model" initialized
INFO - 2026-02-22 14:08:13 --> Config Class Initialized
INFO - 2026-02-22 14:08:13 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:08:13 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:08:13 --> Utf8 Class Initialized
INFO - 2026-02-22 14:08:13 --> URI Class Initialized
INFO - 2026-02-22 14:08:13 --> Router Class Initialized
INFO - 2026-02-22 14:08:13 --> Output Class Initialized
INFO - 2026-02-22 14:08:13 --> Security Class Initialized
DEBUG - 2026-02-22 14:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:08:13 --> CSRF cookie sent
INFO - 2026-02-22 14:08:13 --> Input Class Initialized
INFO - 2026-02-22 14:08:13 --> Language Class Initialized
INFO - 2026-02-22 14:08:13 --> Language Class Initialized
INFO - 2026-02-22 14:08:13 --> Config Class Initialized
INFO - 2026-02-22 14:08:13 --> Loader Class Initialized
INFO - 2026-02-22 14:08:13 --> Helper loaded: url_helper
INFO - 2026-02-22 14:08:13 --> Helper loaded: form_helper
INFO - 2026-02-22 14:08:13 --> Helper loaded: html_helper
INFO - 2026-02-22 14:08:13 --> Helper loaded: file_helper
INFO - 2026-02-22 14:08:13 --> Helper loaded: email_helper
INFO - 2026-02-22 14:08:13 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:08:13 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:08:13 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:08:13 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:08:13 --> Database Driver Class Initialized
INFO - 2026-02-22 14:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:08:14 --> Upload Class Initialized
DEBUG - 2026-02-22 14:08:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:08:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:08:14 --> Encryption Class Initialized
INFO - 2026-02-22 14:08:14 --> Form Validation Class Initialized
INFO - 2026-02-22 14:08:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:08:14 --> Pagination Class Initialized
INFO - 2026-02-22 14:08:14 --> Email Class Initialized
INFO - 2026-02-22 14:08:14 --> Controller Class Initialized
DEBUG - 2026-02-22 14:08:14 --> Ticket MX_Controller Initialized
INFO - 2026-02-22 14:08:14 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:08:14 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:08:14 --> Model "Support_model" initialized
INFO - 2026-02-22 14:08:14 --> Model "Common_model" initialized
DEBUG - 2026-02-22 14:08:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:08:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:08:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:08:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:08:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:08:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/ticket_list.php
INFO - 2026-02-22 14:08:15 --> Final output sent to browser
DEBUG - 2026-02-22 14:08:15 --> Total execution time: 2.4161
INFO - 2026-02-22 14:08:15 --> Config Class Initialized
INFO - 2026-02-22 14:08:15 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:08:15 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:08:15 --> Utf8 Class Initialized
INFO - 2026-02-22 14:08:15 --> URI Class Initialized
INFO - 2026-02-22 14:08:15 --> Router Class Initialized
INFO - 2026-02-22 14:08:15 --> Output Class Initialized
INFO - 2026-02-22 14:08:15 --> Security Class Initialized
DEBUG - 2026-02-22 14:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:08:15 --> CSRF cookie sent
INFO - 2026-02-22 14:08:15 --> Input Class Initialized
INFO - 2026-02-22 14:08:15 --> Language Class Initialized
INFO - 2026-02-22 14:08:15 --> Language Class Initialized
INFO - 2026-02-22 14:08:15 --> Config Class Initialized
INFO - 2026-02-22 14:08:15 --> Loader Class Initialized
INFO - 2026-02-22 14:08:15 --> Helper loaded: url_helper
INFO - 2026-02-22 14:08:15 --> Helper loaded: form_helper
INFO - 2026-02-22 14:08:15 --> Helper loaded: html_helper
INFO - 2026-02-22 14:08:15 --> Helper loaded: file_helper
INFO - 2026-02-22 14:08:15 --> Helper loaded: email_helper
INFO - 2026-02-22 14:08:15 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:08:15 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:08:15 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:08:15 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:08:15 --> Database Driver Class Initialized
INFO - 2026-02-22 14:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:08:17 --> Upload Class Initialized
DEBUG - 2026-02-22 14:08:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:08:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:08:17 --> Encryption Class Initialized
INFO - 2026-02-22 14:08:17 --> Form Validation Class Initialized
INFO - 2026-02-22 14:08:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:08:17 --> Pagination Class Initialized
INFO - 2026-02-22 14:08:17 --> Email Class Initialized
INFO - 2026-02-22 14:08:17 --> Controller Class Initialized
DEBUG - 2026-02-22 14:08:17 --> Ticket MX_Controller Initialized
INFO - 2026-02-22 14:08:17 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:08:17 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:08:17 --> Model "Support_model" initialized
INFO - 2026-02-22 14:08:17 --> Model "Common_model" initialized
INFO - 2026-02-22 14:12:47 --> Config Class Initialized
INFO - 2026-02-22 14:12:47 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:12:47 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:12:47 --> Utf8 Class Initialized
INFO - 2026-02-22 14:12:47 --> URI Class Initialized
INFO - 2026-02-22 14:12:47 --> Router Class Initialized
INFO - 2026-02-22 14:12:47 --> Output Class Initialized
INFO - 2026-02-22 14:12:47 --> Security Class Initialized
DEBUG - 2026-02-22 14:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:12:47 --> CSRF cookie sent
INFO - 2026-02-22 14:12:47 --> Input Class Initialized
INFO - 2026-02-22 14:12:47 --> Language Class Initialized
INFO - 2026-02-22 14:12:47 --> Language Class Initialized
INFO - 2026-02-22 14:12:47 --> Config Class Initialized
INFO - 2026-02-22 14:12:47 --> Loader Class Initialized
INFO - 2026-02-22 14:12:47 --> Helper loaded: url_helper
INFO - 2026-02-22 14:12:47 --> Helper loaded: form_helper
INFO - 2026-02-22 14:12:47 --> Helper loaded: html_helper
INFO - 2026-02-22 14:12:47 --> Helper loaded: file_helper
INFO - 2026-02-22 14:12:47 --> Helper loaded: email_helper
INFO - 2026-02-22 14:12:47 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:12:47 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:12:47 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:12:47 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:12:47 --> Database Driver Class Initialized
INFO - 2026-02-22 14:12:48 --> Config Class Initialized
INFO - 2026-02-22 14:12:48 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:12:48 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:12:48 --> Utf8 Class Initialized
INFO - 2026-02-22 14:12:48 --> URI Class Initialized
INFO - 2026-02-22 14:12:48 --> Router Class Initialized
INFO - 2026-02-22 14:12:48 --> Output Class Initialized
INFO - 2026-02-22 14:12:48 --> Security Class Initialized
DEBUG - 2026-02-22 14:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:12:48 --> CSRF cookie sent
INFO - 2026-02-22 14:12:48 --> Input Class Initialized
INFO - 2026-02-22 14:12:48 --> Language Class Initialized
INFO - 2026-02-22 14:12:48 --> Language Class Initialized
INFO - 2026-02-22 14:12:48 --> Config Class Initialized
INFO - 2026-02-22 14:12:48 --> Loader Class Initialized
INFO - 2026-02-22 14:12:48 --> Helper loaded: url_helper
INFO - 2026-02-22 14:12:48 --> Helper loaded: form_helper
INFO - 2026-02-22 14:12:48 --> Helper loaded: html_helper
INFO - 2026-02-22 14:12:48 --> Helper loaded: file_helper
INFO - 2026-02-22 14:12:48 --> Helper loaded: email_helper
INFO - 2026-02-22 14:12:48 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:12:48 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:12:48 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:12:48 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:12:48 --> Database Driver Class Initialized
INFO - 2026-02-22 14:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:12:49 --> Upload Class Initialized
DEBUG - 2026-02-22 14:12:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:12:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:12:49 --> Encryption Class Initialized
INFO - 2026-02-22 14:12:49 --> Form Validation Class Initialized
INFO - 2026-02-22 14:12:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:12:49 --> Pagination Class Initialized
INFO - 2026-02-22 14:12:49 --> Email Class Initialized
INFO - 2026-02-22 14:12:49 --> Controller Class Initialized
DEBUG - 2026-02-22 14:12:49 --> Ticket MX_Controller Initialized
INFO - 2026-02-22 14:12:49 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:12:49 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:12:49 --> Model "Support_model" initialized
INFO - 2026-02-22 14:12:49 --> Model "Common_model" initialized
INFO - 2026-02-22 14:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:12:51 --> Upload Class Initialized
DEBUG - 2026-02-22 14:12:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:12:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:12:51 --> Encryption Class Initialized
INFO - 2026-02-22 14:12:51 --> Form Validation Class Initialized
INFO - 2026-02-22 14:12:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:12:51 --> Pagination Class Initialized
INFO - 2026-02-22 14:12:51 --> Email Class Initialized
INFO - 2026-02-22 14:12:51 --> Controller Class Initialized
DEBUG - 2026-02-22 14:12:51 --> Ticket MX_Controller Initialized
INFO - 2026-02-22 14:12:51 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:12:51 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:12:51 --> Model "Support_model" initialized
INFO - 2026-02-22 14:12:51 --> Model "Common_model" initialized
DEBUG - 2026-02-22 14:12:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:12:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:12:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:12:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:12:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:12:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/ticket_list.php
INFO - 2026-02-22 14:12:52 --> Final output sent to browser
DEBUG - 2026-02-22 14:12:52 --> Total execution time: 3.6528
INFO - 2026-02-22 14:12:52 --> Config Class Initialized
INFO - 2026-02-22 14:12:52 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:12:52 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:12:52 --> Utf8 Class Initialized
INFO - 2026-02-22 14:12:52 --> URI Class Initialized
INFO - 2026-02-22 14:12:52 --> Router Class Initialized
INFO - 2026-02-22 14:12:52 --> Output Class Initialized
INFO - 2026-02-22 14:12:52 --> Security Class Initialized
DEBUG - 2026-02-22 14:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:12:52 --> CSRF cookie sent
INFO - 2026-02-22 14:12:52 --> Input Class Initialized
INFO - 2026-02-22 14:12:52 --> Language Class Initialized
INFO - 2026-02-22 14:12:52 --> Language Class Initialized
INFO - 2026-02-22 14:12:52 --> Config Class Initialized
INFO - 2026-02-22 14:12:52 --> Loader Class Initialized
INFO - 2026-02-22 14:12:52 --> Helper loaded: url_helper
INFO - 2026-02-22 14:12:52 --> Helper loaded: form_helper
INFO - 2026-02-22 14:12:52 --> Helper loaded: html_helper
INFO - 2026-02-22 14:12:52 --> Helper loaded: file_helper
INFO - 2026-02-22 14:12:52 --> Helper loaded: email_helper
INFO - 2026-02-22 14:12:52 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:12:52 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:12:52 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:12:52 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:12:52 --> Database Driver Class Initialized
INFO - 2026-02-22 14:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:12:54 --> Upload Class Initialized
DEBUG - 2026-02-22 14:12:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:12:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:12:54 --> Encryption Class Initialized
INFO - 2026-02-22 14:12:54 --> Form Validation Class Initialized
INFO - 2026-02-22 14:12:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:12:54 --> Pagination Class Initialized
INFO - 2026-02-22 14:12:54 --> Email Class Initialized
INFO - 2026-02-22 14:12:54 --> Controller Class Initialized
DEBUG - 2026-02-22 14:12:54 --> Ticket MX_Controller Initialized
INFO - 2026-02-22 14:12:54 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:12:54 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:12:54 --> Model "Support_model" initialized
INFO - 2026-02-22 14:12:54 --> Model "Common_model" initialized
INFO - 2026-02-22 14:12:54 --> Config Class Initialized
INFO - 2026-02-22 14:12:54 --> Hooks Class Initialized
INFO - 2026-02-22 14:12:54 --> Config Class Initialized
INFO - 2026-02-22 14:12:54 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:12:54 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:12:54 --> Utf8 Class Initialized
INFO - 2026-02-22 14:12:54 --> URI Class Initialized
DEBUG - 2026-02-22 14:12:54 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:12:54 --> Utf8 Class Initialized
INFO - 2026-02-22 14:12:54 --> Config Class Initialized
INFO - 2026-02-22 14:12:54 --> Hooks Class Initialized
INFO - 2026-02-22 14:12:54 --> URI Class Initialized
INFO - 2026-02-22 14:12:54 --> Config Class Initialized
INFO - 2026-02-22 14:12:54 --> Hooks Class Initialized
INFO - 2026-02-22 14:12:54 --> Router Class Initialized
DEBUG - 2026-02-22 14:12:54 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:12:54 --> Utf8 Class Initialized
INFO - 2026-02-22 14:12:54 --> Router Class Initialized
INFO - 2026-02-22 14:12:54 --> Output Class Initialized
INFO - 2026-02-22 14:12:54 --> URI Class Initialized
DEBUG - 2026-02-22 14:12:54 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:12:54 --> Utf8 Class Initialized
INFO - 2026-02-22 14:12:54 --> Security Class Initialized
INFO - 2026-02-22 14:12:54 --> URI Class Initialized
INFO - 2026-02-22 14:12:54 --> Output Class Initialized
INFO - 2026-02-22 14:12:54 --> Config Class Initialized
INFO - 2026-02-22 14:12:54 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:12:54 --> CSRF cookie sent
INFO - 2026-02-22 14:12:54 --> Input Class Initialized
INFO - 2026-02-22 14:12:54 --> Router Class Initialized
INFO - 2026-02-22 14:12:54 --> Language Class Initialized
INFO - 2026-02-22 14:12:54 --> Security Class Initialized
INFO - 2026-02-22 14:12:54 --> Router Class Initialized
INFO - 2026-02-22 14:12:54 --> Language Class Initialized
INFO - 2026-02-22 14:12:54 --> Config Class Initialized
DEBUG - 2026-02-22 14:12:54 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:12:54 --> Utf8 Class Initialized
INFO - 2026-02-22 14:12:54 --> Output Class Initialized
DEBUG - 2026-02-22 14:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:12:54 --> CSRF cookie sent
INFO - 2026-02-22 14:12:54 --> Input Class Initialized
INFO - 2026-02-22 14:12:54 --> Output Class Initialized
INFO - 2026-02-22 14:12:54 --> Language Class Initialized
INFO - 2026-02-22 14:12:54 --> URI Class Initialized
INFO - 2026-02-22 14:12:54 --> Security Class Initialized
INFO - 2026-02-22 14:12:54 --> Language Class Initialized
INFO - 2026-02-22 14:12:54 --> Config Class Initialized
INFO - 2026-02-22 14:12:54 --> Security Class Initialized
INFO - 2026-02-22 14:12:54 --> Loader Class Initialized
INFO - 2026-02-22 14:12:54 --> Router Class Initialized
DEBUG - 2026-02-22 14:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:12:54 --> CSRF cookie sent
INFO - 2026-02-22 14:12:54 --> Input Class Initialized
DEBUG - 2026-02-22 14:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:12:54 --> CSRF cookie sent
INFO - 2026-02-22 14:12:54 --> Input Class Initialized
INFO - 2026-02-22 14:12:54 --> Language Class Initialized
INFO - 2026-02-22 14:12:54 --> Language Class Initialized
INFO - 2026-02-22 14:12:54 --> Helper loaded: url_helper
INFO - 2026-02-22 14:12:54 --> Language Class Initialized
INFO - 2026-02-22 14:12:54 --> Config Class Initialized
INFO - 2026-02-22 14:12:54 --> Output Class Initialized
INFO - 2026-02-22 14:12:54 --> Language Class Initialized
INFO - 2026-02-22 14:12:54 --> Config Class Initialized
INFO - 2026-02-22 14:12:54 --> Helper loaded: form_helper
INFO - 2026-02-22 14:12:54 --> Loader Class Initialized
INFO - 2026-02-22 14:12:54 --> Helper loaded: html_helper
INFO - 2026-02-22 14:12:54 --> Security Class Initialized
INFO - 2026-02-22 14:12:54 --> Helper loaded: url_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: file_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: email_helper
DEBUG - 2026-02-22 14:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:12:54 --> CSRF cookie sent
INFO - 2026-02-22 14:12:54 --> Loader Class Initialized
INFO - 2026-02-22 14:12:54 --> Input Class Initialized
INFO - 2026-02-22 14:12:54 --> Language Class Initialized
INFO - 2026-02-22 14:12:54 --> Loader Class Initialized
INFO - 2026-02-22 14:12:54 --> Helper loaded: form_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: url_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: html_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:12:54 --> Language Class Initialized
INFO - 2026-02-22 14:12:54 --> Config Class Initialized
INFO - 2026-02-22 14:12:54 --> Helper loaded: url_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: file_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: email_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: form_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: html_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: form_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: file_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: email_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: html_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: file_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: email_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:12:54 --> Loader Class Initialized
INFO - 2026-02-22 14:12:54 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: url_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: form_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: html_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: file_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: email_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:12:54 --> Database Driver Class Initialized
INFO - 2026-02-22 14:12:54 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:12:54 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:12:54 --> Database Driver Class Initialized
INFO - 2026-02-22 14:12:54 --> Database Driver Class Initialized
INFO - 2026-02-22 14:12:54 --> Database Driver Class Initialized
INFO - 2026-02-22 14:12:54 --> Database Driver Class Initialized
INFO - 2026-02-22 14:12:56 --> Config Class Initialized
INFO - 2026-02-22 14:12:56 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:12:56 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:12:56 --> Utf8 Class Initialized
INFO - 2026-02-22 14:12:56 --> URI Class Initialized
INFO - 2026-02-22 14:12:56 --> Router Class Initialized
INFO - 2026-02-22 14:12:56 --> Output Class Initialized
INFO - 2026-02-22 14:12:56 --> Security Class Initialized
DEBUG - 2026-02-22 14:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:12:56 --> CSRF cookie sent
INFO - 2026-02-22 14:12:56 --> Input Class Initialized
INFO - 2026-02-22 14:12:56 --> Language Class Initialized
INFO - 2026-02-22 14:12:56 --> Language Class Initialized
INFO - 2026-02-22 14:12:56 --> Config Class Initialized
INFO - 2026-02-22 14:12:56 --> Loader Class Initialized
INFO - 2026-02-22 14:12:56 --> Helper loaded: url_helper
INFO - 2026-02-22 14:12:56 --> Helper loaded: form_helper
INFO - 2026-02-22 14:12:56 --> Helper loaded: html_helper
INFO - 2026-02-22 14:12:56 --> Helper loaded: file_helper
INFO - 2026-02-22 14:12:56 --> Helper loaded: email_helper
INFO - 2026-02-22 14:12:56 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:12:56 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:12:56 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:12:56 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:12:56 --> Database Driver Class Initialized
INFO - 2026-02-22 14:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:12:56 --> Upload Class Initialized
DEBUG - 2026-02-22 14:12:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:12:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:12:56 --> Encryption Class Initialized
INFO - 2026-02-22 14:12:56 --> Form Validation Class Initialized
INFO - 2026-02-22 14:12:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:12:56 --> Pagination Class Initialized
INFO - 2026-02-22 14:12:56 --> Email Class Initialized
INFO - 2026-02-22 14:12:56 --> Controller Class Initialized
ERROR - 2026-02-22 14:12:56 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:12:56 --> Upload Class Initialized
DEBUG - 2026-02-22 14:12:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:12:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:12:56 --> Encryption Class Initialized
INFO - 2026-02-22 14:12:56 --> Form Validation Class Initialized
INFO - 2026-02-22 14:12:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:12:56 --> Pagination Class Initialized
INFO - 2026-02-22 14:12:56 --> Config Class Initialized
INFO - 2026-02-22 14:12:56 --> Hooks Class Initialized
INFO - 2026-02-22 14:12:56 --> Email Class Initialized
INFO - 2026-02-22 14:12:56 --> Controller Class Initialized
ERROR - 2026-02-22 14:12:56 --> 404 Page Not Found: /index
DEBUG - 2026-02-22 14:12:56 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:12:56 --> Utf8 Class Initialized
INFO - 2026-02-22 14:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:12:56 --> URI Class Initialized
INFO - 2026-02-22 14:12:56 --> Upload Class Initialized
INFO - 2026-02-22 14:12:56 --> Router Class Initialized
DEBUG - 2026-02-22 14:12:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:12:56 --> Output Class Initialized
INFO - 2026-02-22 14:12:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:12:56 --> Encryption Class Initialized
INFO - 2026-02-22 14:12:56 --> Security Class Initialized
INFO - 2026-02-22 14:12:56 --> Form Validation Class Initialized
DEBUG - 2026-02-22 14:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:12:56 --> CSRF cookie sent
INFO - 2026-02-22 14:12:56 --> Input Class Initialized
INFO - 2026-02-22 14:12:56 --> Language Class Initialized
INFO - 2026-02-22 14:12:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:12:56 --> Pagination Class Initialized
INFO - 2026-02-22 14:12:56 --> Language Class Initialized
INFO - 2026-02-22 14:12:56 --> Config Class Initialized
INFO - 2026-02-22 14:12:56 --> Config Class Initialized
INFO - 2026-02-22 14:12:56 --> Hooks Class Initialized
INFO - 2026-02-22 14:12:56 --> Email Class Initialized
INFO - 2026-02-22 14:12:56 --> Controller Class Initialized
ERROR - 2026-02-22 14:12:56 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:12:56 --> Loader Class Initialized
DEBUG - 2026-02-22 14:12:56 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:12:56 --> Utf8 Class Initialized
INFO - 2026-02-22 14:12:56 --> Upload Class Initialized
INFO - 2026-02-22 14:12:56 --> URI Class Initialized
INFO - 2026-02-22 14:12:56 --> Helper loaded: url_helper
DEBUG - 2026-02-22 14:12:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:12:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:12:56 --> Encryption Class Initialized
INFO - 2026-02-22 14:12:56 --> Helper loaded: form_helper
INFO - 2026-02-22 14:12:56 --> Router Class Initialized
INFO - 2026-02-22 14:12:56 --> Helper loaded: html_helper
INFO - 2026-02-22 14:12:56 --> Helper loaded: file_helper
INFO - 2026-02-22 14:12:56 --> Helper loaded: email_helper
INFO - 2026-02-22 14:12:56 --> Form Validation Class Initialized
INFO - 2026-02-22 14:12:56 --> Output Class Initialized
INFO - 2026-02-22 14:12:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:12:56 --> Pagination Class Initialized
INFO - 2026-02-22 14:12:56 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:12:56 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:12:56 --> Security Class Initialized
DEBUG - 2026-02-22 14:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:12:56 --> CSRF cookie sent
INFO - 2026-02-22 14:12:56 --> Input Class Initialized
INFO - 2026-02-22 14:12:56 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:12:56 --> Language Class Initialized
INFO - 2026-02-22 14:12:56 --> Email Class Initialized
INFO - 2026-02-22 14:12:56 --> Controller Class Initialized
ERROR - 2026-02-22 14:12:56 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:12:56 --> Language Class Initialized
INFO - 2026-02-22 14:12:56 --> Config Class Initialized
INFO - 2026-02-22 14:12:56 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:12:56 --> Upload Class Initialized
INFO - 2026-02-22 14:12:56 --> Loader Class Initialized
DEBUG - 2026-02-22 14:12:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:12:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:12:56 --> Encryption Class Initialized
INFO - 2026-02-22 14:12:56 --> Helper loaded: url_helper
INFO - 2026-02-22 14:12:56 --> Form Validation Class Initialized
INFO - 2026-02-22 14:12:56 --> Helper loaded: form_helper
INFO - 2026-02-22 14:12:56 --> Helper loaded: html_helper
INFO - 2026-02-22 14:12:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:12:56 --> Pagination Class Initialized
INFO - 2026-02-22 14:12:56 --> Helper loaded: file_helper
INFO - 2026-02-22 14:12:56 --> Database Driver Class Initialized
INFO - 2026-02-22 14:12:56 --> Helper loaded: email_helper
INFO - 2026-02-22 14:12:56 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:12:56 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:12:56 --> Email Class Initialized
INFO - 2026-02-22 14:12:56 --> Controller Class Initialized
ERROR - 2026-02-22 14:12:56 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:12:56 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:12:56 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:12:56 --> Database Driver Class Initialized
INFO - 2026-02-22 14:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:12:58 --> Upload Class Initialized
DEBUG - 2026-02-22 14:12:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:12:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:12:58 --> Encryption Class Initialized
INFO - 2026-02-22 14:12:58 --> Form Validation Class Initialized
INFO - 2026-02-22 14:12:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:12:58 --> Pagination Class Initialized
INFO - 2026-02-22 14:12:58 --> Email Class Initialized
INFO - 2026-02-22 14:12:58 --> Controller Class Initialized
ERROR - 2026-02-22 14:12:58 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:12:58 --> Upload Class Initialized
DEBUG - 2026-02-22 14:12:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:12:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:12:58 --> Encryption Class Initialized
INFO - 2026-02-22 14:12:58 --> Form Validation Class Initialized
INFO - 2026-02-22 14:12:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:12:58 --> Pagination Class Initialized
INFO - 2026-02-22 14:12:58 --> Email Class Initialized
INFO - 2026-02-22 14:12:58 --> Controller Class Initialized
ERROR - 2026-02-22 14:12:58 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:12:58 --> Upload Class Initialized
DEBUG - 2026-02-22 14:12:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:12:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:12:58 --> Encryption Class Initialized
INFO - 2026-02-22 14:12:58 --> Form Validation Class Initialized
INFO - 2026-02-22 14:12:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:12:58 --> Pagination Class Initialized
INFO - 2026-02-22 14:12:58 --> Email Class Initialized
INFO - 2026-02-22 14:12:58 --> Controller Class Initialized
ERROR - 2026-02-22 14:12:58 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:15:21 --> Config Class Initialized
INFO - 2026-02-22 14:15:21 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:15:21 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:15:21 --> Utf8 Class Initialized
INFO - 2026-02-22 14:15:21 --> URI Class Initialized
INFO - 2026-02-22 14:15:21 --> Router Class Initialized
INFO - 2026-02-22 14:15:21 --> Output Class Initialized
INFO - 2026-02-22 14:15:21 --> Security Class Initialized
DEBUG - 2026-02-22 14:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:15:21 --> CSRF cookie sent
INFO - 2026-02-22 14:15:21 --> Input Class Initialized
INFO - 2026-02-22 14:15:21 --> Language Class Initialized
INFO - 2026-02-22 14:15:21 --> Language Class Initialized
INFO - 2026-02-22 14:15:21 --> Config Class Initialized
INFO - 2026-02-22 14:15:21 --> Loader Class Initialized
INFO - 2026-02-22 14:15:21 --> Helper loaded: url_helper
INFO - 2026-02-22 14:15:21 --> Helper loaded: form_helper
INFO - 2026-02-22 14:15:21 --> Helper loaded: html_helper
INFO - 2026-02-22 14:15:21 --> Helper loaded: file_helper
INFO - 2026-02-22 14:15:21 --> Helper loaded: email_helper
INFO - 2026-02-22 14:15:21 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:15:21 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:15:21 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:15:21 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:15:21 --> Database Driver Class Initialized
INFO - 2026-02-22 14:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:15:23 --> Upload Class Initialized
DEBUG - 2026-02-22 14:15:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:15:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:15:23 --> Encryption Class Initialized
INFO - 2026-02-22 14:15:23 --> Form Validation Class Initialized
INFO - 2026-02-22 14:15:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:15:23 --> Pagination Class Initialized
INFO - 2026-02-22 14:15:23 --> Email Class Initialized
INFO - 2026-02-22 14:15:23 --> Controller Class Initialized
DEBUG - 2026-02-22 14:15:23 --> Ticket MX_Controller Initialized
INFO - 2026-02-22 14:15:23 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:15:23 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:15:23 --> Model "Support_model" initialized
INFO - 2026-02-22 14:15:23 --> Model "Common_model" initialized
DEBUG - 2026-02-22 14:15:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:15:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:15:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:15:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:15:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:15:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/ticket_list.php
INFO - 2026-02-22 14:15:24 --> Final output sent to browser
DEBUG - 2026-02-22 14:15:24 --> Total execution time: 2.6850
INFO - 2026-02-22 14:15:24 --> Config Class Initialized
INFO - 2026-02-22 14:15:24 --> Hooks Class Initialized
INFO - 2026-02-22 14:15:24 --> Config Class Initialized
INFO - 2026-02-22 14:15:24 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:15:24 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:15:24 --> Utf8 Class Initialized
INFO - 2026-02-22 14:15:24 --> URI Class Initialized
DEBUG - 2026-02-22 14:15:24 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:15:24 --> Utf8 Class Initialized
INFO - 2026-02-22 14:15:24 --> URI Class Initialized
INFO - 2026-02-22 14:15:24 --> Router Class Initialized
INFO - 2026-02-22 14:15:24 --> Router Class Initialized
INFO - 2026-02-22 14:15:24 --> Output Class Initialized
INFO - 2026-02-22 14:15:24 --> Output Class Initialized
INFO - 2026-02-22 14:15:24 --> Security Class Initialized
INFO - 2026-02-22 14:15:24 --> Security Class Initialized
DEBUG - 2026-02-22 14:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:15:24 --> CSRF cookie sent
INFO - 2026-02-22 14:15:24 --> Input Class Initialized
INFO - 2026-02-22 14:15:24 --> Language Class Initialized
DEBUG - 2026-02-22 14:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:15:24 --> CSRF cookie sent
INFO - 2026-02-22 14:15:24 --> Input Class Initialized
INFO - 2026-02-22 14:15:24 --> Language Class Initialized
INFO - 2026-02-22 14:15:24 --> Language Class Initialized
INFO - 2026-02-22 14:15:24 --> Config Class Initialized
INFO - 2026-02-22 14:15:24 --> Language Class Initialized
INFO - 2026-02-22 14:15:24 --> Config Class Initialized
INFO - 2026-02-22 14:15:24 --> Loader Class Initialized
INFO - 2026-02-22 14:15:24 --> Loader Class Initialized
INFO - 2026-02-22 14:15:24 --> Helper loaded: url_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: url_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: form_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: form_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: html_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: html_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: file_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: email_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: file_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: email_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:15:24 --> Database Driver Class Initialized
INFO - 2026-02-22 14:15:24 --> Database Driver Class Initialized
INFO - 2026-02-22 14:15:24 --> Config Class Initialized
INFO - 2026-02-22 14:15:24 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:15:24 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:15:24 --> Utf8 Class Initialized
INFO - 2026-02-22 14:15:24 --> URI Class Initialized
INFO - 2026-02-22 14:15:24 --> Router Class Initialized
INFO - 2026-02-22 14:15:24 --> Output Class Initialized
INFO - 2026-02-22 14:15:24 --> Security Class Initialized
DEBUG - 2026-02-22 14:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:15:24 --> CSRF cookie sent
INFO - 2026-02-22 14:15:24 --> Input Class Initialized
INFO - 2026-02-22 14:15:24 --> Language Class Initialized
INFO - 2026-02-22 14:15:24 --> Language Class Initialized
INFO - 2026-02-22 14:15:24 --> Config Class Initialized
INFO - 2026-02-22 14:15:24 --> Loader Class Initialized
INFO - 2026-02-22 14:15:24 --> Helper loaded: url_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: form_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: html_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: file_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: email_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:15:24 --> Database Driver Class Initialized
INFO - 2026-02-22 14:15:24 --> Config Class Initialized
INFO - 2026-02-22 14:15:24 --> Hooks Class Initialized
INFO - 2026-02-22 14:15:24 --> Config Class Initialized
INFO - 2026-02-22 14:15:24 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:15:24 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:15:24 --> Utf8 Class Initialized
INFO - 2026-02-22 14:15:24 --> Config Class Initialized
INFO - 2026-02-22 14:15:24 --> Hooks Class Initialized
INFO - 2026-02-22 14:15:24 --> URI Class Initialized
DEBUG - 2026-02-22 14:15:24 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:15:24 --> Utf8 Class Initialized
INFO - 2026-02-22 14:15:24 --> URI Class Initialized
DEBUG - 2026-02-22 14:15:24 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:15:24 --> Utf8 Class Initialized
INFO - 2026-02-22 14:15:24 --> Router Class Initialized
INFO - 2026-02-22 14:15:24 --> URI Class Initialized
INFO - 2026-02-22 14:15:24 --> Output Class Initialized
INFO - 2026-02-22 14:15:24 --> Router Class Initialized
INFO - 2026-02-22 14:15:24 --> Security Class Initialized
INFO - 2026-02-22 14:15:24 --> Output Class Initialized
INFO - 2026-02-22 14:15:24 --> Router Class Initialized
DEBUG - 2026-02-22 14:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:15:24 --> CSRF cookie sent
INFO - 2026-02-22 14:15:24 --> Input Class Initialized
INFO - 2026-02-22 14:15:24 --> Language Class Initialized
INFO - 2026-02-22 14:15:24 --> Security Class Initialized
INFO - 2026-02-22 14:15:24 --> Language Class Initialized
INFO - 2026-02-22 14:15:24 --> Config Class Initialized
INFO - 2026-02-22 14:15:24 --> Output Class Initialized
DEBUG - 2026-02-22 14:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:15:24 --> CSRF cookie sent
INFO - 2026-02-22 14:15:24 --> Input Class Initialized
INFO - 2026-02-22 14:15:24 --> Language Class Initialized
INFO - 2026-02-22 14:15:24 --> Language Class Initialized
INFO - 2026-02-22 14:15:24 --> Security Class Initialized
INFO - 2026-02-22 14:15:24 --> Config Class Initialized
INFO - 2026-02-22 14:15:24 --> Loader Class Initialized
INFO - 2026-02-22 14:15:24 --> Helper loaded: url_helper
DEBUG - 2026-02-22 14:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:15:24 --> CSRF cookie sent
INFO - 2026-02-22 14:15:24 --> Input Class Initialized
INFO - 2026-02-22 14:15:24 --> Language Class Initialized
INFO - 2026-02-22 14:15:24 --> Helper loaded: form_helper
INFO - 2026-02-22 14:15:24 --> Loader Class Initialized
INFO - 2026-02-22 14:15:24 --> Helper loaded: html_helper
INFO - 2026-02-22 14:15:24 --> Language Class Initialized
INFO - 2026-02-22 14:15:24 --> Config Class Initialized
INFO - 2026-02-22 14:15:24 --> Helper loaded: file_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: email_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: url_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: form_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: html_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: file_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: email_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:15:24 --> Loader Class Initialized
INFO - 2026-02-22 14:15:24 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: url_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: form_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: html_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: file_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: email_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:15:24 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:15:24 --> Database Driver Class Initialized
INFO - 2026-02-22 14:15:24 --> Database Driver Class Initialized
INFO - 2026-02-22 14:15:24 --> Database Driver Class Initialized
INFO - 2026-02-22 14:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:15:26 --> Upload Class Initialized
DEBUG - 2026-02-22 14:15:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:15:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:15:26 --> Encryption Class Initialized
INFO - 2026-02-22 14:15:26 --> Form Validation Class Initialized
INFO - 2026-02-22 14:15:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:15:26 --> Pagination Class Initialized
INFO - 2026-02-22 14:15:26 --> Email Class Initialized
INFO - 2026-02-22 14:15:26 --> Controller Class Initialized
ERROR - 2026-02-22 14:15:26 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:15:26 --> Upload Class Initialized
DEBUG - 2026-02-22 14:15:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:15:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:15:26 --> Encryption Class Initialized
INFO - 2026-02-22 14:15:26 --> Form Validation Class Initialized
INFO - 2026-02-22 14:15:26 --> Config Class Initialized
INFO - 2026-02-22 14:15:26 --> Hooks Class Initialized
INFO - 2026-02-22 14:15:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:15:26 --> Pagination Class Initialized
DEBUG - 2026-02-22 14:15:26 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:15:26 --> Utf8 Class Initialized
INFO - 2026-02-22 14:15:26 --> URI Class Initialized
INFO - 2026-02-22 14:15:26 --> Router Class Initialized
INFO - 2026-02-22 14:15:26 --> Email Class Initialized
INFO - 2026-02-22 14:15:26 --> Controller Class Initialized
INFO - 2026-02-22 14:15:26 --> Output Class Initialized
ERROR - 2026-02-22 14:15:26 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:15:26 --> Security Class Initialized
DEBUG - 2026-02-22 14:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:15:26 --> CSRF cookie sent
INFO - 2026-02-22 14:15:26 --> Input Class Initialized
INFO - 2026-02-22 14:15:26 --> Language Class Initialized
INFO - 2026-02-22 14:15:26 --> Language Class Initialized
INFO - 2026-02-22 14:15:26 --> Config Class Initialized
INFO - 2026-02-22 14:15:26 --> Loader Class Initialized
INFO - 2026-02-22 14:15:26 --> Helper loaded: url_helper
INFO - 2026-02-22 14:15:26 --> Helper loaded: form_helper
INFO - 2026-02-22 14:15:26 --> Helper loaded: html_helper
INFO - 2026-02-22 14:15:26 --> Helper loaded: file_helper
INFO - 2026-02-22 14:15:26 --> Helper loaded: email_helper
INFO - 2026-02-22 14:15:26 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:15:26 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:15:26 --> Config Class Initialized
INFO - 2026-02-22 14:15:26 --> Hooks Class Initialized
INFO - 2026-02-22 14:15:26 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:15:26 --> Helper loaded: domain_helper
DEBUG - 2026-02-22 14:15:26 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:15:26 --> Utf8 Class Initialized
INFO - 2026-02-22 14:15:26 --> URI Class Initialized
INFO - 2026-02-22 14:15:26 --> Router Class Initialized
INFO - 2026-02-22 14:15:26 --> Output Class Initialized
INFO - 2026-02-22 14:15:26 --> Database Driver Class Initialized
INFO - 2026-02-22 14:15:26 --> Security Class Initialized
DEBUG - 2026-02-22 14:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:15:26 --> CSRF cookie sent
INFO - 2026-02-22 14:15:26 --> Input Class Initialized
INFO - 2026-02-22 14:15:26 --> Language Class Initialized
INFO - 2026-02-22 14:15:26 --> Language Class Initialized
INFO - 2026-02-22 14:15:26 --> Config Class Initialized
INFO - 2026-02-22 14:15:26 --> Loader Class Initialized
INFO - 2026-02-22 14:15:26 --> Helper loaded: url_helper
INFO - 2026-02-22 14:15:26 --> Helper loaded: form_helper
INFO - 2026-02-22 14:15:26 --> Helper loaded: html_helper
INFO - 2026-02-22 14:15:26 --> Helper loaded: file_helper
INFO - 2026-02-22 14:15:26 --> Helper loaded: email_helper
INFO - 2026-02-22 14:15:26 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:15:26 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:15:26 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:15:26 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:15:26 --> Database Driver Class Initialized
INFO - 2026-02-22 14:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:15:26 --> Upload Class Initialized
DEBUG - 2026-02-22 14:15:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:15:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:15:26 --> Encryption Class Initialized
INFO - 2026-02-22 14:15:26 --> Form Validation Class Initialized
INFO - 2026-02-22 14:15:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:15:26 --> Pagination Class Initialized
INFO - 2026-02-22 14:15:26 --> Email Class Initialized
INFO - 2026-02-22 14:15:26 --> Controller Class Initialized
ERROR - 2026-02-22 14:15:26 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:15:26 --> Upload Class Initialized
DEBUG - 2026-02-22 14:15:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:15:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:15:26 --> Encryption Class Initialized
INFO - 2026-02-22 14:15:26 --> Form Validation Class Initialized
INFO - 2026-02-22 14:15:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:15:26 --> Pagination Class Initialized
INFO - 2026-02-22 14:15:26 --> Config Class Initialized
INFO - 2026-02-22 14:15:26 --> Hooks Class Initialized
INFO - 2026-02-22 14:15:26 --> Email Class Initialized
DEBUG - 2026-02-22 14:15:26 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:15:26 --> Utf8 Class Initialized
INFO - 2026-02-22 14:15:26 --> Controller Class Initialized
ERROR - 2026-02-22 14:15:26 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:15:26 --> URI Class Initialized
INFO - 2026-02-22 14:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:15:26 --> Router Class Initialized
INFO - 2026-02-22 14:15:26 --> Upload Class Initialized
INFO - 2026-02-22 14:15:26 --> Output Class Initialized
DEBUG - 2026-02-22 14:15:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:15:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:15:26 --> Encryption Class Initialized
INFO - 2026-02-22 14:15:26 --> Security Class Initialized
DEBUG - 2026-02-22 14:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:15:26 --> CSRF cookie sent
INFO - 2026-02-22 14:15:26 --> Input Class Initialized
INFO - 2026-02-22 14:15:26 --> Language Class Initialized
INFO - 2026-02-22 14:15:26 --> Form Validation Class Initialized
INFO - 2026-02-22 14:15:26 --> Language Class Initialized
INFO - 2026-02-22 14:15:26 --> Config Class Initialized
INFO - 2026-02-22 14:15:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:15:26 --> Pagination Class Initialized
INFO - 2026-02-22 14:15:26 --> Loader Class Initialized
INFO - 2026-02-22 14:15:26 --> Helper loaded: url_helper
INFO - 2026-02-22 14:15:26 --> Email Class Initialized
INFO - 2026-02-22 14:15:26 --> Controller Class Initialized
ERROR - 2026-02-22 14:15:26 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:15:26 --> Helper loaded: form_helper
INFO - 2026-02-22 14:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:15:26 --> Helper loaded: html_helper
INFO - 2026-02-22 14:15:26 --> Helper loaded: file_helper
INFO - 2026-02-22 14:15:26 --> Helper loaded: email_helper
INFO - 2026-02-22 14:15:26 --> Upload Class Initialized
INFO - 2026-02-22 14:15:26 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:15:26 --> Helper loaded: ssp_helper
DEBUG - 2026-02-22 14:15:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:15:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:15:26 --> Encryption Class Initialized
INFO - 2026-02-22 14:15:26 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:15:26 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:15:26 --> Form Validation Class Initialized
INFO - 2026-02-22 14:15:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:15:26 --> Pagination Class Initialized
INFO - 2026-02-22 14:15:26 --> Database Driver Class Initialized
INFO - 2026-02-22 14:15:26 --> Email Class Initialized
INFO - 2026-02-22 14:15:26 --> Controller Class Initialized
ERROR - 2026-02-22 14:15:26 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:15:28 --> Upload Class Initialized
DEBUG - 2026-02-22 14:15:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:15:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:15:28 --> Encryption Class Initialized
INFO - 2026-02-22 14:15:28 --> Form Validation Class Initialized
INFO - 2026-02-22 14:15:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:15:28 --> Pagination Class Initialized
INFO - 2026-02-22 14:15:28 --> Email Class Initialized
INFO - 2026-02-22 14:15:28 --> Controller Class Initialized
ERROR - 2026-02-22 14:15:28 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:15:28 --> Upload Class Initialized
DEBUG - 2026-02-22 14:15:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:15:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:15:28 --> Encryption Class Initialized
INFO - 2026-02-22 14:15:28 --> Form Validation Class Initialized
INFO - 2026-02-22 14:15:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:15:28 --> Pagination Class Initialized
INFO - 2026-02-22 14:15:28 --> Email Class Initialized
INFO - 2026-02-22 14:15:28 --> Controller Class Initialized
DEBUG - 2026-02-22 14:15:28 --> Ticket MX_Controller Initialized
INFO - 2026-02-22 14:15:28 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:15:28 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:15:28 --> Model "Support_model" initialized
INFO - 2026-02-22 14:15:28 --> Model "Common_model" initialized
INFO - 2026-02-22 14:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:15:30 --> Upload Class Initialized
DEBUG - 2026-02-22 14:15:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:15:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:15:30 --> Encryption Class Initialized
INFO - 2026-02-22 14:15:30 --> Form Validation Class Initialized
INFO - 2026-02-22 14:15:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:15:30 --> Pagination Class Initialized
INFO - 2026-02-22 14:15:30 --> Email Class Initialized
INFO - 2026-02-22 14:15:30 --> Controller Class Initialized
ERROR - 2026-02-22 14:15:30 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:15:53 --> Config Class Initialized
INFO - 2026-02-22 14:15:53 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:15:53 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:15:53 --> Utf8 Class Initialized
INFO - 2026-02-22 14:15:53 --> URI Class Initialized
INFO - 2026-02-22 14:15:53 --> Router Class Initialized
INFO - 2026-02-22 14:15:53 --> Output Class Initialized
INFO - 2026-02-22 14:15:53 --> Security Class Initialized
DEBUG - 2026-02-22 14:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:15:53 --> CSRF cookie sent
INFO - 2026-02-22 14:15:53 --> Input Class Initialized
INFO - 2026-02-22 14:15:53 --> Language Class Initialized
INFO - 2026-02-22 14:15:53 --> Language Class Initialized
INFO - 2026-02-22 14:15:53 --> Config Class Initialized
INFO - 2026-02-22 14:15:53 --> Loader Class Initialized
INFO - 2026-02-22 14:15:53 --> Helper loaded: url_helper
INFO - 2026-02-22 14:15:53 --> Helper loaded: form_helper
INFO - 2026-02-22 14:15:53 --> Helper loaded: html_helper
INFO - 2026-02-22 14:15:53 --> Helper loaded: file_helper
INFO - 2026-02-22 14:15:53 --> Helper loaded: email_helper
INFO - 2026-02-22 14:15:53 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:15:53 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:15:53 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:15:53 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:15:53 --> Database Driver Class Initialized
INFO - 2026-02-22 14:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:15:54 --> Upload Class Initialized
DEBUG - 2026-02-22 14:15:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:15:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:15:54 --> Encryption Class Initialized
INFO - 2026-02-22 14:15:54 --> Form Validation Class Initialized
INFO - 2026-02-22 14:15:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:15:54 --> Pagination Class Initialized
INFO - 2026-02-22 14:15:54 --> Email Class Initialized
INFO - 2026-02-22 14:15:54 --> Controller Class Initialized
DEBUG - 2026-02-22 14:15:54 --> Ticket MX_Controller Initialized
INFO - 2026-02-22 14:15:54 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:15:54 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:15:54 --> Model "Support_model" initialized
INFO - 2026-02-22 14:15:54 --> Model "Common_model" initialized
DEBUG - 2026-02-22 14:15:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:15:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:15:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:15:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:15:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:15:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/ticket_list.php
INFO - 2026-02-22 14:15:55 --> Final output sent to browser
DEBUG - 2026-02-22 14:15:55 --> Total execution time: 2.6870
INFO - 2026-02-22 14:15:56 --> Config Class Initialized
INFO - 2026-02-22 14:15:56 --> Config Class Initialized
INFO - 2026-02-22 14:15:56 --> Hooks Class Initialized
INFO - 2026-02-22 14:15:56 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:15:56 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:15:56 --> Utf8 Class Initialized
DEBUG - 2026-02-22 14:15:56 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:15:56 --> Utf8 Class Initialized
INFO - 2026-02-22 14:15:56 --> URI Class Initialized
INFO - 2026-02-22 14:15:56 --> URI Class Initialized
INFO - 2026-02-22 14:15:56 --> Router Class Initialized
INFO - 2026-02-22 14:15:56 --> Output Class Initialized
INFO - 2026-02-22 14:15:56 --> Router Class Initialized
INFO - 2026-02-22 14:15:56 --> Security Class Initialized
INFO - 2026-02-22 14:15:56 --> Output Class Initialized
DEBUG - 2026-02-22 14:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:15:56 --> CSRF cookie sent
INFO - 2026-02-22 14:15:56 --> Input Class Initialized
INFO - 2026-02-22 14:15:56 --> Language Class Initialized
INFO - 2026-02-22 14:15:56 --> Security Class Initialized
INFO - 2026-02-22 14:15:56 --> Language Class Initialized
INFO - 2026-02-22 14:15:56 --> Config Class Initialized
DEBUG - 2026-02-22 14:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:15:56 --> CSRF cookie sent
INFO - 2026-02-22 14:15:56 --> Input Class Initialized
INFO - 2026-02-22 14:15:56 --> Language Class Initialized
INFO - 2026-02-22 14:15:56 --> Language Class Initialized
INFO - 2026-02-22 14:15:56 --> Config Class Initialized
INFO - 2026-02-22 14:15:56 --> Loader Class Initialized
INFO - 2026-02-22 14:15:56 --> Helper loaded: url_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: form_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: html_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: file_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: email_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:15:56 --> Loader Class Initialized
INFO - 2026-02-22 14:15:56 --> Helper loaded: url_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: form_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: html_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: file_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: email_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:15:56 --> Database Driver Class Initialized
INFO - 2026-02-22 14:15:56 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:15:56 --> Database Driver Class Initialized
INFO - 2026-02-22 14:15:56 --> Config Class Initialized
INFO - 2026-02-22 14:15:56 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:15:56 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:15:56 --> Utf8 Class Initialized
INFO - 2026-02-22 14:15:56 --> URI Class Initialized
INFO - 2026-02-22 14:15:56 --> Router Class Initialized
INFO - 2026-02-22 14:15:56 --> Output Class Initialized
INFO - 2026-02-22 14:15:56 --> Security Class Initialized
DEBUG - 2026-02-22 14:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:15:56 --> CSRF cookie sent
INFO - 2026-02-22 14:15:56 --> Input Class Initialized
INFO - 2026-02-22 14:15:56 --> Language Class Initialized
INFO - 2026-02-22 14:15:56 --> Language Class Initialized
INFO - 2026-02-22 14:15:56 --> Config Class Initialized
INFO - 2026-02-22 14:15:56 --> Loader Class Initialized
INFO - 2026-02-22 14:15:56 --> Helper loaded: url_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: form_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: html_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: file_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: email_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:15:56 --> Database Driver Class Initialized
INFO - 2026-02-22 14:15:56 --> Config Class Initialized
INFO - 2026-02-22 14:15:56 --> Config Class Initialized
INFO - 2026-02-22 14:15:56 --> Hooks Class Initialized
INFO - 2026-02-22 14:15:56 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:15:56 --> UTF-8 Support Enabled
DEBUG - 2026-02-22 14:15:56 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:15:56 --> Utf8 Class Initialized
INFO - 2026-02-22 14:15:56 --> Utf8 Class Initialized
INFO - 2026-02-22 14:15:56 --> Config Class Initialized
INFO - 2026-02-22 14:15:56 --> Hooks Class Initialized
INFO - 2026-02-22 14:15:56 --> URI Class Initialized
INFO - 2026-02-22 14:15:56 --> URI Class Initialized
DEBUG - 2026-02-22 14:15:56 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:15:56 --> Utf8 Class Initialized
INFO - 2026-02-22 14:15:56 --> URI Class Initialized
INFO - 2026-02-22 14:15:56 --> Router Class Initialized
INFO - 2026-02-22 14:15:56 --> Router Class Initialized
INFO - 2026-02-22 14:15:56 --> Router Class Initialized
INFO - 2026-02-22 14:15:56 --> Output Class Initialized
INFO - 2026-02-22 14:15:56 --> Output Class Initialized
INFO - 2026-02-22 14:15:56 --> Security Class Initialized
INFO - 2026-02-22 14:15:56 --> Security Class Initialized
DEBUG - 2026-02-22 14:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:15:56 --> CSRF cookie sent
INFO - 2026-02-22 14:15:56 --> Input Class Initialized
DEBUG - 2026-02-22 14:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:15:56 --> CSRF cookie sent
INFO - 2026-02-22 14:15:56 --> Input Class Initialized
INFO - 2026-02-22 14:15:56 --> Language Class Initialized
INFO - 2026-02-22 14:15:56 --> Language Class Initialized
INFO - 2026-02-22 14:15:56 --> Language Class Initialized
INFO - 2026-02-22 14:15:56 --> Config Class Initialized
INFO - 2026-02-22 14:15:56 --> Language Class Initialized
INFO - 2026-02-22 14:15:56 --> Config Class Initialized
INFO - 2026-02-22 14:15:56 --> Output Class Initialized
INFO - 2026-02-22 14:15:56 --> Loader Class Initialized
INFO - 2026-02-22 14:15:56 --> Loader Class Initialized
INFO - 2026-02-22 14:15:56 --> Helper loaded: url_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: url_helper
INFO - 2026-02-22 14:15:56 --> Security Class Initialized
INFO - 2026-02-22 14:15:56 --> Helper loaded: form_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: html_helper
DEBUG - 2026-02-22 14:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:15:56 --> Helper loaded: form_helper
INFO - 2026-02-22 14:15:56 --> CSRF cookie sent
INFO - 2026-02-22 14:15:56 --> Input Class Initialized
INFO - 2026-02-22 14:15:56 --> Helper loaded: file_helper
INFO - 2026-02-22 14:15:56 --> Language Class Initialized
INFO - 2026-02-22 14:15:56 --> Helper loaded: email_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: html_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: file_helper
INFO - 2026-02-22 14:15:56 --> Language Class Initialized
INFO - 2026-02-22 14:15:56 --> Config Class Initialized
INFO - 2026-02-22 14:15:56 --> Helper loaded: email_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:15:56 --> Loader Class Initialized
INFO - 2026-02-22 14:15:56 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: url_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: form_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: html_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: file_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: email_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:15:56 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:15:56 --> Database Driver Class Initialized
INFO - 2026-02-22 14:15:56 --> Database Driver Class Initialized
INFO - 2026-02-22 14:15:56 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:15:56 --> Database Driver Class Initialized
INFO - 2026-02-22 14:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:15:58 --> Upload Class Initialized
DEBUG - 2026-02-22 14:15:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:15:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:15:58 --> Encryption Class Initialized
INFO - 2026-02-22 14:15:58 --> Form Validation Class Initialized
INFO - 2026-02-22 14:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:15:58 --> Pagination Class Initialized
INFO - 2026-02-22 14:15:58 --> Email Class Initialized
INFO - 2026-02-22 14:15:58 --> Controller Class Initialized
ERROR - 2026-02-22 14:15:58 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:15:58 --> Upload Class Initialized
DEBUG - 2026-02-22 14:15:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:15:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:15:58 --> Encryption Class Initialized
INFO - 2026-02-22 14:15:58 --> Form Validation Class Initialized
INFO - 2026-02-22 14:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:15:58 --> Pagination Class Initialized
INFO - 2026-02-22 14:15:58 --> Email Class Initialized
INFO - 2026-02-22 14:15:58 --> Controller Class Initialized
ERROR - 2026-02-22 14:15:58 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:15:58 --> Upload Class Initialized
INFO - 2026-02-22 14:15:58 --> Config Class Initialized
INFO - 2026-02-22 14:15:58 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:15:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:15:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:15:58 --> Encryption Class Initialized
DEBUG - 2026-02-22 14:15:58 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:15:58 --> Utf8 Class Initialized
INFO - 2026-02-22 14:15:58 --> URI Class Initialized
INFO - 2026-02-22 14:15:58 --> Form Validation Class Initialized
INFO - 2026-02-22 14:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:15:58 --> Pagination Class Initialized
INFO - 2026-02-22 14:15:58 --> Router Class Initialized
INFO - 2026-02-22 14:15:58 --> Output Class Initialized
INFO - 2026-02-22 14:15:58 --> Email Class Initialized
INFO - 2026-02-22 14:15:58 --> Controller Class Initialized
INFO - 2026-02-22 14:15:58 --> Security Class Initialized
ERROR - 2026-02-22 14:15:58 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:15:58 --> Config Class Initialized
INFO - 2026-02-22 14:15:58 --> Hooks Class Initialized
INFO - 2026-02-22 14:15:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-02-22 14:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:15:58 --> CSRF cookie sent
INFO - 2026-02-22 14:15:58 --> Input Class Initialized
INFO - 2026-02-22 14:15:58 --> Language Class Initialized
DEBUG - 2026-02-22 14:15:58 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:15:58 --> Utf8 Class Initialized
INFO - 2026-02-22 14:15:58 --> Upload Class Initialized
INFO - 2026-02-22 14:15:58 --> Language Class Initialized
INFO - 2026-02-22 14:15:58 --> Config Class Initialized
INFO - 2026-02-22 14:15:58 --> URI Class Initialized
DEBUG - 2026-02-22 14:15:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:15:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:15:58 --> Encryption Class Initialized
INFO - 2026-02-22 14:15:58 --> Router Class Initialized
INFO - 2026-02-22 14:15:58 --> Loader Class Initialized
INFO - 2026-02-22 14:15:58 --> Output Class Initialized
INFO - 2026-02-22 14:15:58 --> Form Validation Class Initialized
INFO - 2026-02-22 14:15:58 --> Helper loaded: url_helper
INFO - 2026-02-22 14:15:58 --> Security Class Initialized
INFO - 2026-02-22 14:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:15:58 --> Pagination Class Initialized
INFO - 2026-02-22 14:15:58 --> Helper loaded: form_helper
DEBUG - 2026-02-22 14:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:15:58 --> CSRF cookie sent
INFO - 2026-02-22 14:15:58 --> Input Class Initialized
INFO - 2026-02-22 14:15:58 --> Helper loaded: html_helper
INFO - 2026-02-22 14:15:58 --> Language Class Initialized
INFO - 2026-02-22 14:15:58 --> Config Class Initialized
INFO - 2026-02-22 14:15:58 --> Hooks Class Initialized
INFO - 2026-02-22 14:15:58 --> Helper loaded: file_helper
INFO - 2026-02-22 14:15:58 --> Helper loaded: email_helper
INFO - 2026-02-22 14:15:58 --> Language Class Initialized
INFO - 2026-02-22 14:15:58 --> Config Class Initialized
DEBUG - 2026-02-22 14:15:58 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:15:58 --> Utf8 Class Initialized
INFO - 2026-02-22 14:15:58 --> Email Class Initialized
INFO - 2026-02-22 14:15:58 --> Controller Class Initialized
INFO - 2026-02-22 14:15:58 --> Helper loaded: whmaz_helper
ERROR - 2026-02-22 14:15:58 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:15:58 --> URI Class Initialized
INFO - 2026-02-22 14:15:58 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:15:58 --> Loader Class Initialized
INFO - 2026-02-22 14:15:58 --> Helper loaded: url_helper
INFO - 2026-02-22 14:15:58 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:15:58 --> Upload Class Initialized
INFO - 2026-02-22 14:15:58 --> Helper loaded: form_helper
INFO - 2026-02-22 14:15:58 --> Router Class Initialized
INFO - 2026-02-22 14:15:58 --> Helper loaded: html_helper
INFO - 2026-02-22 14:15:58 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:15:58 --> Helper loaded: file_helper
INFO - 2026-02-22 14:15:58 --> Helper loaded: email_helper
DEBUG - 2026-02-22 14:15:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:15:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:15:58 --> Output Class Initialized
INFO - 2026-02-22 14:15:58 --> Encryption Class Initialized
INFO - 2026-02-22 14:15:58 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:15:58 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:15:58 --> Security Class Initialized
INFO - 2026-02-22 14:15:58 --> Form Validation Class Initialized
INFO - 2026-02-22 14:15:58 --> Helper loaded: cpanel_helper
DEBUG - 2026-02-22 14:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:15:58 --> CSRF cookie sent
INFO - 2026-02-22 14:15:58 --> Input Class Initialized
INFO - 2026-02-22 14:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:15:58 --> Language Class Initialized
INFO - 2026-02-22 14:15:58 --> Pagination Class Initialized
INFO - 2026-02-22 14:15:58 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:15:58 --> Language Class Initialized
INFO - 2026-02-22 14:15:58 --> Config Class Initialized
INFO - 2026-02-22 14:15:58 --> Database Driver Class Initialized
INFO - 2026-02-22 14:15:58 --> Email Class Initialized
INFO - 2026-02-22 14:15:58 --> Controller Class Initialized
INFO - 2026-02-22 14:15:58 --> Loader Class Initialized
ERROR - 2026-02-22 14:15:58 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:15:58 --> Helper loaded: url_helper
INFO - 2026-02-22 14:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:15:58 --> Database Driver Class Initialized
INFO - 2026-02-22 14:15:58 --> Helper loaded: form_helper
INFO - 2026-02-22 14:15:58 --> Helper loaded: html_helper
INFO - 2026-02-22 14:15:58 --> Helper loaded: file_helper
INFO - 2026-02-22 14:15:58 --> Upload Class Initialized
INFO - 2026-02-22 14:15:58 --> Helper loaded: email_helper
INFO - 2026-02-22 14:15:58 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:15:58 --> Helper loaded: ssp_helper
DEBUG - 2026-02-22 14:15:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:15:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:15:58 --> Encryption Class Initialized
INFO - 2026-02-22 14:15:58 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:15:58 --> Form Validation Class Initialized
INFO - 2026-02-22 14:15:58 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:15:58 --> Pagination Class Initialized
INFO - 2026-02-22 14:15:58 --> Email Class Initialized
INFO - 2026-02-22 14:15:58 --> Controller Class Initialized
ERROR - 2026-02-22 14:15:58 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:15:58 --> Database Driver Class Initialized
INFO - 2026-02-22 14:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:16:00 --> Upload Class Initialized
DEBUG - 2026-02-22 14:16:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:16:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:16:00 --> Encryption Class Initialized
INFO - 2026-02-22 14:16:00 --> Form Validation Class Initialized
INFO - 2026-02-22 14:16:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:16:00 --> Pagination Class Initialized
INFO - 2026-02-22 14:16:00 --> Email Class Initialized
INFO - 2026-02-22 14:16:00 --> Controller Class Initialized
ERROR - 2026-02-22 14:16:00 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:16:00 --> Upload Class Initialized
DEBUG - 2026-02-22 14:16:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:16:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:16:00 --> Encryption Class Initialized
INFO - 2026-02-22 14:16:00 --> Form Validation Class Initialized
INFO - 2026-02-22 14:16:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:16:00 --> Pagination Class Initialized
INFO - 2026-02-22 14:16:00 --> Email Class Initialized
INFO - 2026-02-22 14:16:00 --> Controller Class Initialized
ERROR - 2026-02-22 14:16:00 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:16:01 --> Upload Class Initialized
DEBUG - 2026-02-22 14:16:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:16:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:16:01 --> Encryption Class Initialized
INFO - 2026-02-22 14:16:01 --> Form Validation Class Initialized
INFO - 2026-02-22 14:16:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:16:01 --> Pagination Class Initialized
INFO - 2026-02-22 14:16:01 --> Email Class Initialized
INFO - 2026-02-22 14:16:01 --> Controller Class Initialized
DEBUG - 2026-02-22 14:16:01 --> Ticket MX_Controller Initialized
INFO - 2026-02-22 14:16:01 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:16:01 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:16:01 --> Model "Support_model" initialized
INFO - 2026-02-22 14:16:01 --> Model "Common_model" initialized
INFO - 2026-02-22 14:16:23 --> Config Class Initialized
INFO - 2026-02-22 14:16:23 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:16:23 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:16:23 --> Utf8 Class Initialized
INFO - 2026-02-22 14:16:23 --> URI Class Initialized
INFO - 2026-02-22 14:16:23 --> Router Class Initialized
INFO - 2026-02-22 14:16:23 --> Output Class Initialized
INFO - 2026-02-22 14:16:23 --> Security Class Initialized
DEBUG - 2026-02-22 14:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:16:23 --> CSRF cookie sent
INFO - 2026-02-22 14:16:23 --> Input Class Initialized
INFO - 2026-02-22 14:16:23 --> Language Class Initialized
INFO - 2026-02-22 14:16:23 --> Language Class Initialized
INFO - 2026-02-22 14:16:23 --> Config Class Initialized
INFO - 2026-02-22 14:16:23 --> Loader Class Initialized
INFO - 2026-02-22 14:16:23 --> Helper loaded: url_helper
INFO - 2026-02-22 14:16:23 --> Helper loaded: form_helper
INFO - 2026-02-22 14:16:23 --> Helper loaded: html_helper
INFO - 2026-02-22 14:16:23 --> Helper loaded: file_helper
INFO - 2026-02-22 14:16:23 --> Helper loaded: email_helper
INFO - 2026-02-22 14:16:23 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:16:23 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:16:23 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:16:23 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:16:23 --> Database Driver Class Initialized
INFO - 2026-02-22 14:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:16:25 --> Upload Class Initialized
DEBUG - 2026-02-22 14:16:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:16:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:16:25 --> Encryption Class Initialized
INFO - 2026-02-22 14:16:25 --> Form Validation Class Initialized
INFO - 2026-02-22 14:16:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:16:25 --> Pagination Class Initialized
INFO - 2026-02-22 14:16:25 --> Email Class Initialized
INFO - 2026-02-22 14:16:25 --> Controller Class Initialized
DEBUG - 2026-02-22 14:16:25 --> Email_template MX_Controller Initialized
INFO - 2026-02-22 14:16:25 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:16:25 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:16:25 --> Model "Emailtemplate_model" initialized
DEBUG - 2026-02-22 14:16:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:16:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:16:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:16:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:16:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:16:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/email_template_list.php
INFO - 2026-02-22 14:16:26 --> Final output sent to browser
DEBUG - 2026-02-22 14:16:26 --> Total execution time: 2.3977
INFO - 2026-02-22 14:16:26 --> Config Class Initialized
INFO - 2026-02-22 14:16:26 --> Config Class Initialized
INFO - 2026-02-22 14:16:26 --> Hooks Class Initialized
INFO - 2026-02-22 14:16:26 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:16:26 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:16:26 --> Utf8 Class Initialized
DEBUG - 2026-02-22 14:16:26 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:16:26 --> Utf8 Class Initialized
INFO - 2026-02-22 14:16:26 --> URI Class Initialized
INFO - 2026-02-22 14:16:26 --> URI Class Initialized
INFO - 2026-02-22 14:16:26 --> Router Class Initialized
INFO - 2026-02-22 14:16:26 --> Router Class Initialized
INFO - 2026-02-22 14:16:26 --> Output Class Initialized
INFO - 2026-02-22 14:16:26 --> Security Class Initialized
INFO - 2026-02-22 14:16:26 --> Output Class Initialized
DEBUG - 2026-02-22 14:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:16:26 --> CSRF cookie sent
INFO - 2026-02-22 14:16:26 --> Input Class Initialized
INFO - 2026-02-22 14:16:26 --> Language Class Initialized
INFO - 2026-02-22 14:16:26 --> Security Class Initialized
INFO - 2026-02-22 14:16:26 --> Language Class Initialized
INFO - 2026-02-22 14:16:26 --> Config Class Initialized
DEBUG - 2026-02-22 14:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:16:26 --> CSRF cookie sent
INFO - 2026-02-22 14:16:26 --> Input Class Initialized
INFO - 2026-02-22 14:16:26 --> Language Class Initialized
INFO - 2026-02-22 14:16:26 --> Loader Class Initialized
INFO - 2026-02-22 14:16:26 --> Language Class Initialized
INFO - 2026-02-22 14:16:26 --> Config Class Initialized
INFO - 2026-02-22 14:16:26 --> Helper loaded: url_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: form_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: html_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: file_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: email_helper
INFO - 2026-02-22 14:16:26 --> Loader Class Initialized
INFO - 2026-02-22 14:16:26 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: url_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: form_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: html_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: file_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: email_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:16:26 --> Database Driver Class Initialized
INFO - 2026-02-22 14:16:26 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:16:26 --> Database Driver Class Initialized
INFO - 2026-02-22 14:16:26 --> Config Class Initialized
INFO - 2026-02-22 14:16:26 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:16:26 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:16:26 --> Utf8 Class Initialized
INFO - 2026-02-22 14:16:26 --> URI Class Initialized
INFO - 2026-02-22 14:16:26 --> Router Class Initialized
INFO - 2026-02-22 14:16:26 --> Output Class Initialized
INFO - 2026-02-22 14:16:26 --> Security Class Initialized
DEBUG - 2026-02-22 14:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:16:26 --> CSRF cookie sent
INFO - 2026-02-22 14:16:26 --> Input Class Initialized
INFO - 2026-02-22 14:16:26 --> Language Class Initialized
INFO - 2026-02-22 14:16:26 --> Language Class Initialized
INFO - 2026-02-22 14:16:26 --> Config Class Initialized
INFO - 2026-02-22 14:16:26 --> Loader Class Initialized
INFO - 2026-02-22 14:16:26 --> Helper loaded: url_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: form_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: html_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: file_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: email_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:16:26 --> Database Driver Class Initialized
INFO - 2026-02-22 14:16:26 --> Config Class Initialized
INFO - 2026-02-22 14:16:26 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:16:26 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:16:26 --> Utf8 Class Initialized
INFO - 2026-02-22 14:16:26 --> Config Class Initialized
INFO - 2026-02-22 14:16:26 --> URI Class Initialized
INFO - 2026-02-22 14:16:26 --> Hooks Class Initialized
INFO - 2026-02-22 14:16:26 --> Config Class Initialized
INFO - 2026-02-22 14:16:26 --> Router Class Initialized
INFO - 2026-02-22 14:16:26 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:16:26 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:16:26 --> Utf8 Class Initialized
INFO - 2026-02-22 14:16:26 --> Output Class Initialized
INFO - 2026-02-22 14:16:26 --> URI Class Initialized
DEBUG - 2026-02-22 14:16:26 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:16:26 --> Utf8 Class Initialized
INFO - 2026-02-22 14:16:26 --> Security Class Initialized
DEBUG - 2026-02-22 14:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:16:26 --> CSRF cookie sent
INFO - 2026-02-22 14:16:26 --> Input Class Initialized
INFO - 2026-02-22 14:16:26 --> URI Class Initialized
INFO - 2026-02-22 14:16:26 --> Language Class Initialized
INFO - 2026-02-22 14:16:26 --> Router Class Initialized
INFO - 2026-02-22 14:16:26 --> Language Class Initialized
INFO - 2026-02-22 14:16:26 --> Config Class Initialized
INFO - 2026-02-22 14:16:26 --> Output Class Initialized
INFO - 2026-02-22 14:16:26 --> Router Class Initialized
INFO - 2026-02-22 14:16:26 --> Loader Class Initialized
INFO - 2026-02-22 14:16:26 --> Security Class Initialized
INFO - 2026-02-22 14:16:26 --> Helper loaded: url_helper
INFO - 2026-02-22 14:16:26 --> Output Class Initialized
DEBUG - 2026-02-22 14:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:16:26 --> CSRF cookie sent
INFO - 2026-02-22 14:16:26 --> Input Class Initialized
INFO - 2026-02-22 14:16:26 --> Helper loaded: form_helper
INFO - 2026-02-22 14:16:26 --> Language Class Initialized
INFO - 2026-02-22 14:16:26 --> Helper loaded: html_helper
INFO - 2026-02-22 14:16:26 --> Security Class Initialized
INFO - 2026-02-22 14:16:26 --> Language Class Initialized
INFO - 2026-02-22 14:16:26 --> Config Class Initialized
INFO - 2026-02-22 14:16:26 --> Helper loaded: file_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: email_helper
DEBUG - 2026-02-22 14:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:16:26 --> CSRF cookie sent
INFO - 2026-02-22 14:16:26 --> Input Class Initialized
INFO - 2026-02-22 14:16:26 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:16:26 --> Language Class Initialized
INFO - 2026-02-22 14:16:26 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:16:26 --> Loader Class Initialized
INFO - 2026-02-22 14:16:26 --> Language Class Initialized
INFO - 2026-02-22 14:16:26 --> Config Class Initialized
INFO - 2026-02-22 14:16:26 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: url_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: form_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: html_helper
INFO - 2026-02-22 14:16:26 --> Loader Class Initialized
INFO - 2026-02-22 14:16:26 --> Helper loaded: file_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: email_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: url_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: form_helper
INFO - 2026-02-22 14:16:26 --> Database Driver Class Initialized
INFO - 2026-02-22 14:16:26 --> Helper loaded: html_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: file_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: email_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:16:26 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:16:26 --> Database Driver Class Initialized
INFO - 2026-02-22 14:16:26 --> Database Driver Class Initialized
INFO - 2026-02-22 14:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:16:28 --> Upload Class Initialized
DEBUG - 2026-02-22 14:16:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:16:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:16:28 --> Encryption Class Initialized
INFO - 2026-02-22 14:16:28 --> Form Validation Class Initialized
INFO - 2026-02-22 14:16:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:16:28 --> Pagination Class Initialized
INFO - 2026-02-22 14:16:28 --> Email Class Initialized
INFO - 2026-02-22 14:16:28 --> Controller Class Initialized
ERROR - 2026-02-22 14:16:28 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:16:28 --> Upload Class Initialized
DEBUG - 2026-02-22 14:16:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:16:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:16:28 --> Encryption Class Initialized
INFO - 2026-02-22 14:16:28 --> Form Validation Class Initialized
INFO - 2026-02-22 14:16:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:16:28 --> Pagination Class Initialized
INFO - 2026-02-22 14:16:28 --> Email Class Initialized
INFO - 2026-02-22 14:16:28 --> Controller Class Initialized
ERROR - 2026-02-22 14:16:28 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:16:28 --> Config Class Initialized
INFO - 2026-02-22 14:16:28 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:16:28 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:16:28 --> Utf8 Class Initialized
INFO - 2026-02-22 14:16:28 --> Upload Class Initialized
INFO - 2026-02-22 14:16:28 --> URI Class Initialized
DEBUG - 2026-02-22 14:16:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:16:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:16:28 --> Encryption Class Initialized
INFO - 2026-02-22 14:16:28 --> Router Class Initialized
INFO - 2026-02-22 14:16:28 --> Output Class Initialized
INFO - 2026-02-22 14:16:28 --> Form Validation Class Initialized
INFO - 2026-02-22 14:16:28 --> Config Class Initialized
INFO - 2026-02-22 14:16:28 --> Hooks Class Initialized
INFO - 2026-02-22 14:16:28 --> Security Class Initialized
DEBUG - 2026-02-22 14:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:16:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:16:28 --> CSRF cookie sent
INFO - 2026-02-22 14:16:28 --> Input Class Initialized
INFO - 2026-02-22 14:16:28 --> Pagination Class Initialized
DEBUG - 2026-02-22 14:16:28 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:16:28 --> Utf8 Class Initialized
INFO - 2026-02-22 14:16:28 --> Language Class Initialized
INFO - 2026-02-22 14:16:28 --> URI Class Initialized
INFO - 2026-02-22 14:16:28 --> Language Class Initialized
INFO - 2026-02-22 14:16:28 --> Config Class Initialized
INFO - 2026-02-22 14:16:28 --> Router Class Initialized
INFO - 2026-02-22 14:16:28 --> Loader Class Initialized
INFO - 2026-02-22 14:16:28 --> Output Class Initialized
INFO - 2026-02-22 14:16:28 --> Helper loaded: url_helper
INFO - 2026-02-22 14:16:28 --> Email Class Initialized
INFO - 2026-02-22 14:16:28 --> Controller Class Initialized
INFO - 2026-02-22 14:16:28 --> Security Class Initialized
ERROR - 2026-02-22 14:16:28 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:16:28 --> Helper loaded: form_helper
INFO - 2026-02-22 14:16:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-02-22 14:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:16:28 --> CSRF cookie sent
INFO - 2026-02-22 14:16:28 --> Input Class Initialized
INFO - 2026-02-22 14:16:28 --> Helper loaded: html_helper
INFO - 2026-02-22 14:16:28 --> Language Class Initialized
INFO - 2026-02-22 14:16:28 --> Helper loaded: file_helper
INFO - 2026-02-22 14:16:28 --> Helper loaded: email_helper
INFO - 2026-02-22 14:16:28 --> Language Class Initialized
INFO - 2026-02-22 14:16:28 --> Config Class Initialized
INFO - 2026-02-22 14:16:28 --> Upload Class Initialized
INFO - 2026-02-22 14:16:28 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:16:28 --> Helper loaded: ssp_helper
DEBUG - 2026-02-22 14:16:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:16:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:16:28 --> Encryption Class Initialized
INFO - 2026-02-22 14:16:28 --> Loader Class Initialized
INFO - 2026-02-22 14:16:28 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:16:28 --> Helper loaded: url_helper
INFO - 2026-02-22 14:16:28 --> Form Validation Class Initialized
INFO - 2026-02-22 14:16:28 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:16:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:16:28 --> Pagination Class Initialized
INFO - 2026-02-22 14:16:28 --> Helper loaded: form_helper
INFO - 2026-02-22 14:16:28 --> Helper loaded: html_helper
INFO - 2026-02-22 14:16:28 --> Helper loaded: file_helper
INFO - 2026-02-22 14:16:28 --> Helper loaded: email_helper
INFO - 2026-02-22 14:16:28 --> Config Class Initialized
INFO - 2026-02-22 14:16:28 --> Hooks Class Initialized
INFO - 2026-02-22 14:16:28 --> Helper loaded: whmaz_helper
DEBUG - 2026-02-22 14:16:28 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:16:28 --> Utf8 Class Initialized
INFO - 2026-02-22 14:16:28 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:16:28 --> Email Class Initialized
INFO - 2026-02-22 14:16:28 --> URI Class Initialized
INFO - 2026-02-22 14:16:28 --> Controller Class Initialized
ERROR - 2026-02-22 14:16:28 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:16:28 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:16:28 --> Router Class Initialized
INFO - 2026-02-22 14:16:28 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:16:28 --> Database Driver Class Initialized
INFO - 2026-02-22 14:16:28 --> Upload Class Initialized
INFO - 2026-02-22 14:16:28 --> Output Class Initialized
INFO - 2026-02-22 14:16:28 --> Security Class Initialized
DEBUG - 2026-02-22 14:16:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:16:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:16:28 --> Encryption Class Initialized
DEBUG - 2026-02-22 14:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:16:28 --> CSRF cookie sent
INFO - 2026-02-22 14:16:28 --> Input Class Initialized
INFO - 2026-02-22 14:16:28 --> Language Class Initialized
INFO - 2026-02-22 14:16:28 --> Form Validation Class Initialized
INFO - 2026-02-22 14:16:28 --> Language Class Initialized
INFO - 2026-02-22 14:16:28 --> Config Class Initialized
INFO - 2026-02-22 14:16:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:16:28 --> Pagination Class Initialized
INFO - 2026-02-22 14:16:28 --> Database Driver Class Initialized
INFO - 2026-02-22 14:16:28 --> Loader Class Initialized
INFO - 2026-02-22 14:16:28 --> Helper loaded: url_helper
INFO - 2026-02-22 14:16:28 --> Email Class Initialized
INFO - 2026-02-22 14:16:28 --> Controller Class Initialized
ERROR - 2026-02-22 14:16:28 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:16:28 --> Helper loaded: form_helper
INFO - 2026-02-22 14:16:28 --> Helper loaded: html_helper
INFO - 2026-02-22 14:16:28 --> Upload Class Initialized
INFO - 2026-02-22 14:16:28 --> Helper loaded: file_helper
INFO - 2026-02-22 14:16:28 --> Helper loaded: email_helper
DEBUG - 2026-02-22 14:16:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:16:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:16:28 --> Encryption Class Initialized
INFO - 2026-02-22 14:16:28 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:16:28 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:16:28 --> Form Validation Class Initialized
INFO - 2026-02-22 14:16:28 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:16:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:16:28 --> Pagination Class Initialized
INFO - 2026-02-22 14:16:28 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:16:28 --> Email Class Initialized
INFO - 2026-02-22 14:16:28 --> Controller Class Initialized
ERROR - 2026-02-22 14:16:28 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:16:28 --> Database Driver Class Initialized
INFO - 2026-02-22 14:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:16:31 --> Upload Class Initialized
DEBUG - 2026-02-22 14:16:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:16:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:16:31 --> Encryption Class Initialized
INFO - 2026-02-22 14:16:31 --> Form Validation Class Initialized
INFO - 2026-02-22 14:16:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:16:31 --> Pagination Class Initialized
INFO - 2026-02-22 14:16:31 --> Email Class Initialized
INFO - 2026-02-22 14:16:31 --> Controller Class Initialized
DEBUG - 2026-02-22 14:16:31 --> Email_template MX_Controller Initialized
INFO - 2026-02-22 14:16:31 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:16:31 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:16:31 --> Model "Emailtemplate_model" initialized
INFO - 2026-02-22 14:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:16:32 --> Upload Class Initialized
DEBUG - 2026-02-22 14:16:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:16:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:16:32 --> Encryption Class Initialized
INFO - 2026-02-22 14:16:32 --> Form Validation Class Initialized
INFO - 2026-02-22 14:16:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:16:32 --> Pagination Class Initialized
INFO - 2026-02-22 14:16:32 --> Email Class Initialized
INFO - 2026-02-22 14:16:32 --> Controller Class Initialized
ERROR - 2026-02-22 14:16:32 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:16:33 --> Upload Class Initialized
DEBUG - 2026-02-22 14:16:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:16:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:16:33 --> Encryption Class Initialized
INFO - 2026-02-22 14:16:33 --> Form Validation Class Initialized
INFO - 2026-02-22 14:16:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:16:33 --> Pagination Class Initialized
INFO - 2026-02-22 14:16:33 --> Email Class Initialized
INFO - 2026-02-22 14:16:33 --> Controller Class Initialized
ERROR - 2026-02-22 14:16:33 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:17:38 --> Config Class Initialized
INFO - 2026-02-22 14:17:38 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:17:38 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:17:38 --> Utf8 Class Initialized
INFO - 2026-02-22 14:17:38 --> URI Class Initialized
INFO - 2026-02-22 14:17:38 --> Router Class Initialized
INFO - 2026-02-22 14:17:38 --> Output Class Initialized
INFO - 2026-02-22 14:17:38 --> Security Class Initialized
DEBUG - 2026-02-22 14:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:17:38 --> CSRF cookie sent
INFO - 2026-02-22 14:17:38 --> Input Class Initialized
INFO - 2026-02-22 14:17:38 --> Language Class Initialized
INFO - 2026-02-22 14:17:38 --> Language Class Initialized
INFO - 2026-02-22 14:17:38 --> Config Class Initialized
INFO - 2026-02-22 14:17:38 --> Loader Class Initialized
INFO - 2026-02-22 14:17:38 --> Helper loaded: url_helper
INFO - 2026-02-22 14:17:38 --> Helper loaded: form_helper
INFO - 2026-02-22 14:17:38 --> Helper loaded: html_helper
INFO - 2026-02-22 14:17:38 --> Helper loaded: file_helper
INFO - 2026-02-22 14:17:38 --> Helper loaded: email_helper
INFO - 2026-02-22 14:17:38 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:17:38 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:17:38 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:17:38 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:17:38 --> Database Driver Class Initialized
INFO - 2026-02-22 14:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:17:40 --> Upload Class Initialized
DEBUG - 2026-02-22 14:17:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:17:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:17:40 --> Encryption Class Initialized
INFO - 2026-02-22 14:17:40 --> Form Validation Class Initialized
INFO - 2026-02-22 14:17:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:17:40 --> Pagination Class Initialized
INFO - 2026-02-22 14:17:40 --> Email Class Initialized
INFO - 2026-02-22 14:17:40 --> Controller Class Initialized
DEBUG - 2026-02-22 14:17:40 --> Clientarea MX_Controller Initialized
INFO - 2026-02-22 14:17:40 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:17:40 --> Model "Auth_model" initialized
INFO - 2026-02-22 14:17:40 --> Model "Cart_model" initialized
INFO - 2026-02-22 14:17:40 --> Model "Clientarea_model" initialized
INFO - 2026-02-22 14:17:40 --> Model "Billing_model" initialized
INFO - 2026-02-22 14:17:40 --> Model "Common_model" initialized
INFO - 2026-02-22 14:17:40 --> Model "Order_model" initialized
INFO - 2026-02-22 14:17:40 --> Model "Support_model" initialized
DEBUG - 2026-02-22 14:17:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-22 14:17:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-02-22 14:17:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-22 14:17:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-22 14:17:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_services.php
INFO - 2026-02-22 14:17:42 --> Final output sent to browser
DEBUG - 2026-02-22 14:17:42 --> Total execution time: 4.2517
INFO - 2026-02-22 14:17:42 --> Config Class Initialized
INFO - 2026-02-22 14:17:42 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:17:42 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:17:42 --> Utf8 Class Initialized
INFO - 2026-02-22 14:17:42 --> URI Class Initialized
INFO - 2026-02-22 14:17:42 --> Router Class Initialized
INFO - 2026-02-22 14:17:42 --> Output Class Initialized
INFO - 2026-02-22 14:17:42 --> Security Class Initialized
DEBUG - 2026-02-22 14:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:17:42 --> CSRF cookie sent
INFO - 2026-02-22 14:17:42 --> Input Class Initialized
INFO - 2026-02-22 14:17:42 --> Language Class Initialized
INFO - 2026-02-22 14:17:42 --> Language Class Initialized
INFO - 2026-02-22 14:17:42 --> Config Class Initialized
INFO - 2026-02-22 14:17:42 --> Loader Class Initialized
INFO - 2026-02-22 14:17:42 --> Helper loaded: url_helper
INFO - 2026-02-22 14:17:42 --> Helper loaded: form_helper
INFO - 2026-02-22 14:17:42 --> Helper loaded: html_helper
INFO - 2026-02-22 14:17:42 --> Helper loaded: file_helper
INFO - 2026-02-22 14:17:42 --> Helper loaded: email_helper
INFO - 2026-02-22 14:17:42 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:17:42 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:17:42 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:17:42 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:17:42 --> Database Driver Class Initialized
INFO - 2026-02-22 14:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:17:45 --> Upload Class Initialized
DEBUG - 2026-02-22 14:17:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:17:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:17:45 --> Encryption Class Initialized
INFO - 2026-02-22 14:17:45 --> Form Validation Class Initialized
INFO - 2026-02-22 14:17:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:17:45 --> Pagination Class Initialized
INFO - 2026-02-22 14:17:45 --> Email Class Initialized
INFO - 2026-02-22 14:17:45 --> Controller Class Initialized
DEBUG - 2026-02-22 14:17:45 --> Cart MX_Controller Initialized
INFO - 2026-02-22 14:17:45 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:17:45 --> Model "Auth_model" initialized
INFO - 2026-02-22 14:17:45 --> Model "Cart_model" initialized
INFO - 2026-02-22 14:17:45 --> Model "Common_model" initialized
INFO - 2026-02-22 14:17:45 --> Model "Order_model" initialized
INFO - 2026-02-22 14:17:45 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 14:17:45 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-22 14:17:45 --> Final output sent to browser
DEBUG - 2026-02-22 14:17:45 --> Total execution time: 3.0027
INFO - 2026-02-22 14:17:59 --> Config Class Initialized
INFO - 2026-02-22 14:17:59 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:17:59 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:17:59 --> Utf8 Class Initialized
INFO - 2026-02-22 14:17:59 --> URI Class Initialized
INFO - 2026-02-22 14:17:59 --> Router Class Initialized
INFO - 2026-02-22 14:17:59 --> Output Class Initialized
INFO - 2026-02-22 14:17:59 --> Security Class Initialized
DEBUG - 2026-02-22 14:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:17:59 --> CSRF cookie sent
INFO - 2026-02-22 14:17:59 --> Input Class Initialized
INFO - 2026-02-22 14:17:59 --> Language Class Initialized
INFO - 2026-02-22 14:17:59 --> Language Class Initialized
INFO - 2026-02-22 14:17:59 --> Config Class Initialized
INFO - 2026-02-22 14:17:59 --> Loader Class Initialized
INFO - 2026-02-22 14:17:59 --> Helper loaded: url_helper
INFO - 2026-02-22 14:17:59 --> Helper loaded: form_helper
INFO - 2026-02-22 14:17:59 --> Helper loaded: html_helper
INFO - 2026-02-22 14:17:59 --> Helper loaded: file_helper
INFO - 2026-02-22 14:17:59 --> Helper loaded: email_helper
INFO - 2026-02-22 14:17:59 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:17:59 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:17:59 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:17:59 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:17:59 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:02 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:02 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:02 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:02 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:02 --> Email Class Initialized
INFO - 2026-02-22 14:18:02 --> Controller Class Initialized
DEBUG - 2026-02-22 14:18:02 --> Service_category MX_Controller Initialized
INFO - 2026-02-22 14:18:02 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:18:02 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:18:02 --> Model "Servicecategory_model" initialized
DEBUG - 2026-02-22 14:18:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:18:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:18:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:18:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:18:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:18:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_category_list.php
INFO - 2026-02-22 14:18:03 --> Final output sent to browser
DEBUG - 2026-02-22 14:18:03 --> Total execution time: 3.5688
INFO - 2026-02-22 14:18:03 --> Config Class Initialized
INFO - 2026-02-22 14:18:03 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:18:03 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:03 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:03 --> Config Class Initialized
INFO - 2026-02-22 14:18:03 --> Hooks Class Initialized
INFO - 2026-02-22 14:18:03 --> URI Class Initialized
DEBUG - 2026-02-22 14:18:03 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:03 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:03 --> URI Class Initialized
INFO - 2026-02-22 14:18:03 --> Router Class Initialized
INFO - 2026-02-22 14:18:03 --> Output Class Initialized
INFO - 2026-02-22 14:18:03 --> Router Class Initialized
INFO - 2026-02-22 14:18:03 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:03 --> Output Class Initialized
INFO - 2026-02-22 14:18:03 --> CSRF cookie sent
INFO - 2026-02-22 14:18:03 --> Input Class Initialized
INFO - 2026-02-22 14:18:03 --> Language Class Initialized
INFO - 2026-02-22 14:18:03 --> Language Class Initialized
INFO - 2026-02-22 14:18:03 --> Config Class Initialized
INFO - 2026-02-22 14:18:03 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:03 --> CSRF cookie sent
INFO - 2026-02-22 14:18:03 --> Input Class Initialized
INFO - 2026-02-22 14:18:03 --> Language Class Initialized
INFO - 2026-02-22 14:18:03 --> Loader Class Initialized
INFO - 2026-02-22 14:18:03 --> Language Class Initialized
INFO - 2026-02-22 14:18:03 --> Config Class Initialized
INFO - 2026-02-22 14:18:03 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:03 --> Loader Class Initialized
INFO - 2026-02-22 14:18:03 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:03 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:03 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:03 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:03 --> Config Class Initialized
INFO - 2026-02-22 14:18:03 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:18:03 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:03 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:03 --> URI Class Initialized
INFO - 2026-02-22 14:18:03 --> Router Class Initialized
INFO - 2026-02-22 14:18:03 --> Output Class Initialized
INFO - 2026-02-22 14:18:03 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:03 --> CSRF cookie sent
INFO - 2026-02-22 14:18:03 --> Input Class Initialized
INFO - 2026-02-22 14:18:03 --> Language Class Initialized
INFO - 2026-02-22 14:18:03 --> Language Class Initialized
INFO - 2026-02-22 14:18:03 --> Config Class Initialized
INFO - 2026-02-22 14:18:03 --> Loader Class Initialized
INFO - 2026-02-22 14:18:03 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:03 --> Config Class Initialized
INFO - 2026-02-22 14:18:03 --> Config Class Initialized
INFO - 2026-02-22 14:18:03 --> Hooks Class Initialized
INFO - 2026-02-22 14:18:03 --> Config Class Initialized
INFO - 2026-02-22 14:18:03 --> Hooks Class Initialized
INFO - 2026-02-22 14:18:03 --> Hooks Class Initialized
INFO - 2026-02-22 14:18:03 --> Helper loaded: cpanel_helper
DEBUG - 2026-02-22 14:18:03 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:03 --> Utf8 Class Initialized
DEBUG - 2026-02-22 14:18:03 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:03 --> Utf8 Class Initialized
DEBUG - 2026-02-22 14:18:03 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:03 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:03 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:03 --> URI Class Initialized
INFO - 2026-02-22 14:18:03 --> URI Class Initialized
INFO - 2026-02-22 14:18:03 --> URI Class Initialized
INFO - 2026-02-22 14:18:03 --> Router Class Initialized
INFO - 2026-02-22 14:18:03 --> Router Class Initialized
INFO - 2026-02-22 14:18:03 --> Router Class Initialized
INFO - 2026-02-22 14:18:03 --> Output Class Initialized
INFO - 2026-02-22 14:18:03 --> Output Class Initialized
INFO - 2026-02-22 14:18:03 --> Output Class Initialized
INFO - 2026-02-22 14:18:03 --> Security Class Initialized
INFO - 2026-02-22 14:18:03 --> Security Class Initialized
INFO - 2026-02-22 14:18:03 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:03 --> CSRF cookie sent
INFO - 2026-02-22 14:18:03 --> Input Class Initialized
DEBUG - 2026-02-22 14:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-02-22 14:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:03 --> CSRF cookie sent
INFO - 2026-02-22 14:18:03 --> CSRF cookie sent
INFO - 2026-02-22 14:18:03 --> Input Class Initialized
INFO - 2026-02-22 14:18:03 --> Input Class Initialized
INFO - 2026-02-22 14:18:03 --> Language Class Initialized
INFO - 2026-02-22 14:18:03 --> Language Class Initialized
INFO - 2026-02-22 14:18:03 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:03 --> Language Class Initialized
INFO - 2026-02-22 14:18:03 --> Config Class Initialized
INFO - 2026-02-22 14:18:03 --> Language Class Initialized
INFO - 2026-02-22 14:18:03 --> Language Class Initialized
INFO - 2026-02-22 14:18:03 --> Config Class Initialized
INFO - 2026-02-22 14:18:03 --> Language Class Initialized
INFO - 2026-02-22 14:18:03 --> Config Class Initialized
INFO - 2026-02-22 14:18:03 --> Loader Class Initialized
INFO - 2026-02-22 14:18:03 --> Loader Class Initialized
INFO - 2026-02-22 14:18:03 --> Loader Class Initialized
INFO - 2026-02-22 14:18:03 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:03 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:03 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:03 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:03 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:03 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:05 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:05 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:05 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:05 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:05 --> Email Class Initialized
INFO - 2026-02-22 14:18:05 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:05 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:05 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:05 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:05 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:05 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:05 --> Config Class Initialized
INFO - 2026-02-22 14:18:05 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:18:05 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:05 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:05 --> URI Class Initialized
INFO - 2026-02-22 14:18:05 --> Router Class Initialized
INFO - 2026-02-22 14:18:05 --> Email Class Initialized
INFO - 2026-02-22 14:18:05 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:05 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:05 --> Output Class Initialized
INFO - 2026-02-22 14:18:05 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:05 --> CSRF cookie sent
INFO - 2026-02-22 14:18:05 --> Input Class Initialized
INFO - 2026-02-22 14:18:05 --> Language Class Initialized
INFO - 2026-02-22 14:18:05 --> Language Class Initialized
INFO - 2026-02-22 14:18:05 --> Config Class Initialized
INFO - 2026-02-22 14:18:05 --> Loader Class Initialized
INFO - 2026-02-22 14:18:05 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:05 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:05 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:05 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:05 --> Config Class Initialized
INFO - 2026-02-22 14:18:05 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:05 --> Hooks Class Initialized
INFO - 2026-02-22 14:18:05 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:05 --> Helper loaded: ssp_helper
DEBUG - 2026-02-22 14:18:05 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:05 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:05 --> URI Class Initialized
INFO - 2026-02-22 14:18:05 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:05 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:05 --> Router Class Initialized
INFO - 2026-02-22 14:18:05 --> Output Class Initialized
INFO - 2026-02-22 14:18:05 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:05 --> CSRF cookie sent
INFO - 2026-02-22 14:18:05 --> Input Class Initialized
INFO - 2026-02-22 14:18:05 --> Language Class Initialized
INFO - 2026-02-22 14:18:05 --> Language Class Initialized
INFO - 2026-02-22 14:18:05 --> Config Class Initialized
INFO - 2026-02-22 14:18:05 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:05 --> Upload Class Initialized
INFO - 2026-02-22 14:18:05 --> Loader Class Initialized
DEBUG - 2026-02-22 14:18:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:05 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:05 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:05 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:05 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:05 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:05 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:05 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:05 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:05 --> Email Class Initialized
INFO - 2026-02-22 14:18:05 --> Controller Class Initialized
INFO - 2026-02-22 14:18:05 --> Helper loaded: whmaz_helper
ERROR - 2026-02-22 14:18:05 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:05 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:05 --> Upload Class Initialized
INFO - 2026-02-22 14:18:05 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:05 --> Helper loaded: domain_helper
DEBUG - 2026-02-22 14:18:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:05 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:05 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:05 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:05 --> Email Class Initialized
INFO - 2026-02-22 14:18:05 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:05 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:05 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:05 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:05 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:05 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:05 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:05 --> Email Class Initialized
INFO - 2026-02-22 14:18:05 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:05 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:05 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:05 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:05 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:05 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:05 --> Email Class Initialized
INFO - 2026-02-22 14:18:05 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:05 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:08 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:08 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:08 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:08 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:08 --> Email Class Initialized
INFO - 2026-02-22 14:18:08 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:08 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:08 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:08 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:08 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:08 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:08 --> Email Class Initialized
INFO - 2026-02-22 14:18:08 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:08 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:10 --> Config Class Initialized
INFO - 2026-02-22 14:18:10 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:18:10 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:10 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:10 --> URI Class Initialized
INFO - 2026-02-22 14:18:10 --> Router Class Initialized
INFO - 2026-02-22 14:18:10 --> Output Class Initialized
INFO - 2026-02-22 14:18:10 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:10 --> CSRF cookie sent
INFO - 2026-02-22 14:18:10 --> Input Class Initialized
INFO - 2026-02-22 14:18:10 --> Language Class Initialized
INFO - 2026-02-22 14:18:10 --> Language Class Initialized
INFO - 2026-02-22 14:18:10 --> Config Class Initialized
INFO - 2026-02-22 14:18:10 --> Loader Class Initialized
INFO - 2026-02-22 14:18:10 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:10 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:10 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:10 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:10 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:10 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:10 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:10 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:10 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:10 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:13 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:13 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:13 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:13 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:13 --> Email Class Initialized
INFO - 2026-02-22 14:18:13 --> Controller Class Initialized
DEBUG - 2026-02-22 14:18:13 --> Service_group MX_Controller Initialized
INFO - 2026-02-22 14:18:13 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:18:13 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:18:13 --> Model "Servicegroup_model" initialized
INFO - 2026-02-22 14:18:13 --> Model "Common_model" initialized
DEBUG - 2026-02-22 14:18:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:18:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:18:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:18:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:18:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:18:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_group_list.php
INFO - 2026-02-22 14:18:14 --> Final output sent to browser
DEBUG - 2026-02-22 14:18:14 --> Total execution time: 3.2908
INFO - 2026-02-22 14:18:14 --> Config Class Initialized
INFO - 2026-02-22 14:18:14 --> Config Class Initialized
INFO - 2026-02-22 14:18:14 --> Hooks Class Initialized
INFO - 2026-02-22 14:18:14 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:18:14 --> UTF-8 Support Enabled
DEBUG - 2026-02-22 14:18:14 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:14 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:14 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:14 --> URI Class Initialized
INFO - 2026-02-22 14:18:14 --> URI Class Initialized
INFO - 2026-02-22 14:18:14 --> Router Class Initialized
INFO - 2026-02-22 14:18:14 --> Router Class Initialized
INFO - 2026-02-22 14:18:14 --> Output Class Initialized
INFO - 2026-02-22 14:18:14 --> Output Class Initialized
INFO - 2026-02-22 14:18:14 --> Security Class Initialized
INFO - 2026-02-22 14:18:14 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:14 --> CSRF cookie sent
INFO - 2026-02-22 14:18:14 --> Input Class Initialized
DEBUG - 2026-02-22 14:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:14 --> CSRF cookie sent
INFO - 2026-02-22 14:18:14 --> Input Class Initialized
INFO - 2026-02-22 14:18:14 --> Language Class Initialized
INFO - 2026-02-22 14:18:14 --> Language Class Initialized
INFO - 2026-02-22 14:18:14 --> Language Class Initialized
INFO - 2026-02-22 14:18:14 --> Config Class Initialized
INFO - 2026-02-22 14:18:14 --> Language Class Initialized
INFO - 2026-02-22 14:18:14 --> Config Class Initialized
INFO - 2026-02-22 14:18:14 --> Loader Class Initialized
INFO - 2026-02-22 14:18:14 --> Loader Class Initialized
INFO - 2026-02-22 14:18:14 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:14 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:14 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:14 --> Config Class Initialized
INFO - 2026-02-22 14:18:14 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:18:14 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:14 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:14 --> URI Class Initialized
INFO - 2026-02-22 14:18:14 --> Router Class Initialized
INFO - 2026-02-22 14:18:14 --> Output Class Initialized
INFO - 2026-02-22 14:18:14 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:14 --> CSRF cookie sent
INFO - 2026-02-22 14:18:14 --> Input Class Initialized
INFO - 2026-02-22 14:18:14 --> Language Class Initialized
INFO - 2026-02-22 14:18:14 --> Language Class Initialized
INFO - 2026-02-22 14:18:14 --> Config Class Initialized
INFO - 2026-02-22 14:18:14 --> Loader Class Initialized
INFO - 2026-02-22 14:18:14 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:14 --> Config Class Initialized
INFO - 2026-02-22 14:18:14 --> Config Class Initialized
INFO - 2026-02-22 14:18:14 --> Hooks Class Initialized
INFO - 2026-02-22 14:18:14 --> Hooks Class Initialized
INFO - 2026-02-22 14:18:14 --> Config Class Initialized
INFO - 2026-02-22 14:18:14 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:18:14 --> UTF-8 Support Enabled
DEBUG - 2026-02-22 14:18:14 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:14 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:14 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:14 --> URI Class Initialized
INFO - 2026-02-22 14:18:14 --> Database Driver Class Initialized
DEBUG - 2026-02-22 14:18:14 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:14 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:14 --> URI Class Initialized
INFO - 2026-02-22 14:18:14 --> URI Class Initialized
INFO - 2026-02-22 14:18:14 --> Router Class Initialized
INFO - 2026-02-22 14:18:14 --> Router Class Initialized
INFO - 2026-02-22 14:18:14 --> Output Class Initialized
INFO - 2026-02-22 14:18:14 --> Router Class Initialized
INFO - 2026-02-22 14:18:14 --> Security Class Initialized
INFO - 2026-02-22 14:18:14 --> Output Class Initialized
INFO - 2026-02-22 14:18:14 --> Output Class Initialized
DEBUG - 2026-02-22 14:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:14 --> CSRF cookie sent
INFO - 2026-02-22 14:18:14 --> Input Class Initialized
INFO - 2026-02-22 14:18:14 --> Language Class Initialized
INFO - 2026-02-22 14:18:14 --> Security Class Initialized
INFO - 2026-02-22 14:18:14 --> Security Class Initialized
INFO - 2026-02-22 14:18:14 --> Language Class Initialized
INFO - 2026-02-22 14:18:14 --> Config Class Initialized
DEBUG - 2026-02-22 14:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:14 --> CSRF cookie sent
INFO - 2026-02-22 14:18:14 --> Input Class Initialized
INFO - 2026-02-22 14:18:14 --> Language Class Initialized
DEBUG - 2026-02-22 14:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:14 --> CSRF cookie sent
INFO - 2026-02-22 14:18:14 --> Input Class Initialized
INFO - 2026-02-22 14:18:14 --> Language Class Initialized
INFO - 2026-02-22 14:18:14 --> Language Class Initialized
INFO - 2026-02-22 14:18:14 --> Config Class Initialized
INFO - 2026-02-22 14:18:14 --> Language Class Initialized
INFO - 2026-02-22 14:18:14 --> Config Class Initialized
INFO - 2026-02-22 14:18:14 --> Loader Class Initialized
INFO - 2026-02-22 14:18:14 --> Loader Class Initialized
INFO - 2026-02-22 14:18:14 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:14 --> Loader Class Initialized
INFO - 2026-02-22 14:18:14 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:14 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:14 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:14 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:14 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:16 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:16 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:16 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:16 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:16 --> Email Class Initialized
INFO - 2026-02-22 14:18:16 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:16 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:16 --> Config Class Initialized
INFO - 2026-02-22 14:18:16 --> Hooks Class Initialized
INFO - 2026-02-22 14:18:16 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:16 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:16 --> Utf8 Class Initialized
DEBUG - 2026-02-22 14:18:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:16 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:16 --> URI Class Initialized
INFO - 2026-02-22 14:18:16 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:16 --> Router Class Initialized
INFO - 2026-02-22 14:18:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:16 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:16 --> Output Class Initialized
INFO - 2026-02-22 14:18:16 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:16 --> CSRF cookie sent
INFO - 2026-02-22 14:18:16 --> Input Class Initialized
INFO - 2026-02-22 14:18:16 --> Email Class Initialized
INFO - 2026-02-22 14:18:16 --> Controller Class Initialized
INFO - 2026-02-22 14:18:16 --> Language Class Initialized
ERROR - 2026-02-22 14:18:16 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:16 --> Language Class Initialized
INFO - 2026-02-22 14:18:16 --> Config Class Initialized
INFO - 2026-02-22 14:18:16 --> Loader Class Initialized
INFO - 2026-02-22 14:18:16 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:16 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:16 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:16 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:16 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:16 --> Config Class Initialized
INFO - 2026-02-22 14:18:16 --> Hooks Class Initialized
INFO - 2026-02-22 14:18:16 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:16 --> Helper loaded: ssp_helper
DEBUG - 2026-02-22 14:18:16 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:16 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:16 --> URI Class Initialized
INFO - 2026-02-22 14:18:16 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:16 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:16 --> Router Class Initialized
INFO - 2026-02-22 14:18:16 --> Output Class Initialized
INFO - 2026-02-22 14:18:16 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:16 --> CSRF cookie sent
INFO - 2026-02-22 14:18:16 --> Input Class Initialized
INFO - 2026-02-22 14:18:16 --> Language Class Initialized
INFO - 2026-02-22 14:18:16 --> Language Class Initialized
INFO - 2026-02-22 14:18:16 --> Config Class Initialized
INFO - 2026-02-22 14:18:16 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:16 --> Loader Class Initialized
INFO - 2026-02-22 14:18:16 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:16 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:16 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:16 --> Upload Class Initialized
INFO - 2026-02-22 14:18:16 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:16 --> Helper loaded: email_helper
DEBUG - 2026-02-22 14:18:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:16 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:16 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:16 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:16 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:16 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:16 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:16 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:16 --> Email Class Initialized
INFO - 2026-02-22 14:18:16 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:16 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:16 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:16 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:16 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:16 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:16 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:16 --> Email Class Initialized
INFO - 2026-02-22 14:18:16 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:16 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:16 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:16 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:16 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:16 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:16 --> Email Class Initialized
INFO - 2026-02-22 14:18:16 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:16 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:16 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:16 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:16 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:16 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:16 --> Email Class Initialized
INFO - 2026-02-22 14:18:16 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:16 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:18 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:18 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:18 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:18 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:18 --> Email Class Initialized
INFO - 2026-02-22 14:18:18 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:18 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:18 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:18 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:18 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:18 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:18 --> Email Class Initialized
INFO - 2026-02-22 14:18:18 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:18 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:20 --> Config Class Initialized
INFO - 2026-02-22 14:18:20 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:18:20 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:20 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:20 --> URI Class Initialized
INFO - 2026-02-22 14:18:20 --> Router Class Initialized
INFO - 2026-02-22 14:18:20 --> Output Class Initialized
INFO - 2026-02-22 14:18:20 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:20 --> CSRF cookie sent
INFO - 2026-02-22 14:18:20 --> Input Class Initialized
INFO - 2026-02-22 14:18:20 --> Language Class Initialized
INFO - 2026-02-22 14:18:20 --> Language Class Initialized
INFO - 2026-02-22 14:18:20 --> Config Class Initialized
INFO - 2026-02-22 14:18:20 --> Loader Class Initialized
INFO - 2026-02-22 14:18:20 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:20 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:20 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:20 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:20 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:20 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:20 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:20 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:20 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:20 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:23 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:23 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:23 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:23 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:23 --> Email Class Initialized
INFO - 2026-02-22 14:18:23 --> Controller Class Initialized
DEBUG - 2026-02-22 14:18:23 --> Service_module MX_Controller Initialized
INFO - 2026-02-22 14:18:23 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:18:23 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:18:23 --> Model "Servicemodule_model" initialized
DEBUG - 2026-02-22 14:18:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:18:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:18:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:18:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:18:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:18:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_module_list.php
INFO - 2026-02-22 14:18:24 --> Final output sent to browser
DEBUG - 2026-02-22 14:18:24 --> Total execution time: 3.2584
INFO - 2026-02-22 14:18:24 --> Config Class Initialized
INFO - 2026-02-22 14:18:24 --> Hooks Class Initialized
INFO - 2026-02-22 14:18:24 --> Config Class Initialized
INFO - 2026-02-22 14:18:24 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:18:24 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:24 --> Utf8 Class Initialized
DEBUG - 2026-02-22 14:18:24 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:24 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:24 --> URI Class Initialized
INFO - 2026-02-22 14:18:24 --> URI Class Initialized
INFO - 2026-02-22 14:18:24 --> Router Class Initialized
INFO - 2026-02-22 14:18:24 --> Router Class Initialized
INFO - 2026-02-22 14:18:24 --> Output Class Initialized
INFO - 2026-02-22 14:18:24 --> Output Class Initialized
INFO - 2026-02-22 14:18:24 --> Security Class Initialized
INFO - 2026-02-22 14:18:24 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:24 --> CSRF cookie sent
INFO - 2026-02-22 14:18:24 --> Input Class Initialized
DEBUG - 2026-02-22 14:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:24 --> CSRF cookie sent
INFO - 2026-02-22 14:18:24 --> Input Class Initialized
INFO - 2026-02-22 14:18:24 --> Language Class Initialized
INFO - 2026-02-22 14:18:24 --> Language Class Initialized
INFO - 2026-02-22 14:18:24 --> Language Class Initialized
INFO - 2026-02-22 14:18:24 --> Config Class Initialized
INFO - 2026-02-22 14:18:24 --> Language Class Initialized
INFO - 2026-02-22 14:18:24 --> Config Class Initialized
INFO - 2026-02-22 14:18:24 --> Loader Class Initialized
INFO - 2026-02-22 14:18:24 --> Loader Class Initialized
INFO - 2026-02-22 14:18:24 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:24 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:24 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:24 --> Config Class Initialized
INFO - 2026-02-22 14:18:24 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:18:24 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:24 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:24 --> URI Class Initialized
INFO - 2026-02-22 14:18:24 --> Config Class Initialized
INFO - 2026-02-22 14:18:24 --> Config Class Initialized
INFO - 2026-02-22 14:18:24 --> Hooks Class Initialized
INFO - 2026-02-22 14:18:24 --> Hooks Class Initialized
INFO - 2026-02-22 14:18:24 --> Router Class Initialized
DEBUG - 2026-02-22 14:18:24 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:24 --> Utf8 Class Initialized
DEBUG - 2026-02-22 14:18:24 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:24 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:24 --> URI Class Initialized
INFO - 2026-02-22 14:18:24 --> Output Class Initialized
INFO - 2026-02-22 14:18:24 --> URI Class Initialized
INFO - 2026-02-22 14:18:24 --> Security Class Initialized
INFO - 2026-02-22 14:18:24 --> Router Class Initialized
INFO - 2026-02-22 14:18:24 --> Router Class Initialized
DEBUG - 2026-02-22 14:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:24 --> CSRF cookie sent
INFO - 2026-02-22 14:18:24 --> Input Class Initialized
INFO - 2026-02-22 14:18:24 --> Language Class Initialized
INFO - 2026-02-22 14:18:24 --> Output Class Initialized
INFO - 2026-02-22 14:18:24 --> Language Class Initialized
INFO - 2026-02-22 14:18:24 --> Output Class Initialized
INFO - 2026-02-22 14:18:24 --> Config Class Initialized
INFO - 2026-02-22 14:18:24 --> Security Class Initialized
INFO - 2026-02-22 14:18:24 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:24 --> CSRF cookie sent
INFO - 2026-02-22 14:18:24 --> Input Class Initialized
INFO - 2026-02-22 14:18:24 --> Language Class Initialized
DEBUG - 2026-02-22 14:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:24 --> CSRF cookie sent
INFO - 2026-02-22 14:18:24 --> Input Class Initialized
INFO - 2026-02-22 14:18:24 --> Language Class Initialized
INFO - 2026-02-22 14:18:24 --> Loader Class Initialized
INFO - 2026-02-22 14:18:24 --> Config Class Initialized
INFO - 2026-02-22 14:18:24 --> Hooks Class Initialized
INFO - 2026-02-22 14:18:24 --> Language Class Initialized
INFO - 2026-02-22 14:18:24 --> Config Class Initialized
INFO - 2026-02-22 14:18:24 --> Language Class Initialized
INFO - 2026-02-22 14:18:24 --> Config Class Initialized
INFO - 2026-02-22 14:18:24 --> Helper loaded: url_helper
DEBUG - 2026-02-22 14:18:24 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:24 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:24 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:24 --> URI Class Initialized
INFO - 2026-02-22 14:18:24 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:24 --> Loader Class Initialized
INFO - 2026-02-22 14:18:24 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:24 --> Loader Class Initialized
INFO - 2026-02-22 14:18:24 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:24 --> Router Class Initialized
INFO - 2026-02-22 14:18:24 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:24 --> Output Class Initialized
INFO - 2026-02-22 14:18:24 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:24 --> Security Class Initialized
INFO - 2026-02-22 14:18:24 --> Database Driver Class Initialized
DEBUG - 2026-02-22 14:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:24 --> CSRF cookie sent
INFO - 2026-02-22 14:18:24 --> Input Class Initialized
INFO - 2026-02-22 14:18:24 --> Language Class Initialized
INFO - 2026-02-22 14:18:24 --> Language Class Initialized
INFO - 2026-02-22 14:18:24 --> Config Class Initialized
INFO - 2026-02-22 14:18:24 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:24 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:24 --> Loader Class Initialized
INFO - 2026-02-22 14:18:24 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:24 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:24 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:26 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:26 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:26 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:26 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:26 --> Email Class Initialized
INFO - 2026-02-22 14:18:26 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:26 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:26 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:26 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:26 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:26 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:26 --> Email Class Initialized
INFO - 2026-02-22 14:18:26 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:26 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:26 --> Config Class Initialized
INFO - 2026-02-22 14:18:26 --> Hooks Class Initialized
INFO - 2026-02-22 14:18:26 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:26 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:26 --> Utf8 Class Initialized
DEBUG - 2026-02-22 14:18:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:26 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:26 --> URI Class Initialized
INFO - 2026-02-22 14:18:26 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:26 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:26 --> Router Class Initialized
INFO - 2026-02-22 14:18:26 --> Config Class Initialized
INFO - 2026-02-22 14:18:26 --> Hooks Class Initialized
INFO - 2026-02-22 14:18:26 --> Email Class Initialized
INFO - 2026-02-22 14:18:26 --> Output Class Initialized
INFO - 2026-02-22 14:18:26 --> Controller Class Initialized
DEBUG - 2026-02-22 14:18:26 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:26 --> Utf8 Class Initialized
ERROR - 2026-02-22 14:18:26 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:26 --> URI Class Initialized
INFO - 2026-02-22 14:18:26 --> Security Class Initialized
INFO - 2026-02-22 14:18:26 --> Router Class Initialized
DEBUG - 2026-02-22 14:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:26 --> CSRF cookie sent
INFO - 2026-02-22 14:18:26 --> Input Class Initialized
INFO - 2026-02-22 14:18:26 --> Language Class Initialized
INFO - 2026-02-22 14:18:26 --> Output Class Initialized
INFO - 2026-02-22 14:18:26 --> Language Class Initialized
INFO - 2026-02-22 14:18:26 --> Config Class Initialized
INFO - 2026-02-22 14:18:26 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:26 --> CSRF cookie sent
INFO - 2026-02-22 14:18:26 --> Input Class Initialized
INFO - 2026-02-22 14:18:26 --> Language Class Initialized
INFO - 2026-02-22 14:18:26 --> Language Class Initialized
INFO - 2026-02-22 14:18:26 --> Config Class Initialized
INFO - 2026-02-22 14:18:26 --> Loader Class Initialized
INFO - 2026-02-22 14:18:26 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:26 --> Loader Class Initialized
INFO - 2026-02-22 14:18:26 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:26 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:26 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:26 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:26 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:26 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:26 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:26 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:26 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:26 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:26 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:26 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:26 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:26 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:26 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:26 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:26 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:26 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:26 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:27 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:27 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:27 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:27 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:27 --> Email Class Initialized
INFO - 2026-02-22 14:18:27 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:27 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:27 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:27 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:27 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:27 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:27 --> Email Class Initialized
INFO - 2026-02-22 14:18:27 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:27 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:27 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:27 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:27 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:27 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:27 --> Email Class Initialized
INFO - 2026-02-22 14:18:27 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:27 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:27 --> Config Class Initialized
INFO - 2026-02-22 14:18:27 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:18:27 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:27 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:27 --> URI Class Initialized
INFO - 2026-02-22 14:18:27 --> Router Class Initialized
INFO - 2026-02-22 14:18:27 --> Output Class Initialized
INFO - 2026-02-22 14:18:27 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:27 --> CSRF cookie sent
INFO - 2026-02-22 14:18:27 --> Input Class Initialized
INFO - 2026-02-22 14:18:27 --> Language Class Initialized
INFO - 2026-02-22 14:18:27 --> Language Class Initialized
INFO - 2026-02-22 14:18:27 --> Config Class Initialized
INFO - 2026-02-22 14:18:27 --> Loader Class Initialized
INFO - 2026-02-22 14:18:27 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:27 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:27 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:27 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:27 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:27 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:27 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:27 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:27 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:27 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:28 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:28 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:28 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:28 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:28 --> Email Class Initialized
INFO - 2026-02-22 14:18:28 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:28 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:28 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:28 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:28 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:28 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:28 --> Email Class Initialized
INFO - 2026-02-22 14:18:28 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:28 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:29 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:29 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:29 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:29 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:29 --> Email Class Initialized
INFO - 2026-02-22 14:18:29 --> Controller Class Initialized
DEBUG - 2026-02-22 14:18:29 --> Server MX_Controller Initialized
INFO - 2026-02-22 14:18:29 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:18:29 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:18:29 --> Model "Server_model" initialized
DEBUG - 2026-02-22 14:18:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:18:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:18:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:18:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:18:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:18:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/server_list.php
INFO - 2026-02-22 14:18:31 --> Final output sent to browser
DEBUG - 2026-02-22 14:18:31 --> Total execution time: 3.2409
INFO - 2026-02-22 14:18:31 --> Config Class Initialized
INFO - 2026-02-22 14:18:31 --> Config Class Initialized
INFO - 2026-02-22 14:18:31 --> Hooks Class Initialized
INFO - 2026-02-22 14:18:31 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:18:31 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:31 --> Utf8 Class Initialized
DEBUG - 2026-02-22 14:18:31 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:31 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:31 --> URI Class Initialized
INFO - 2026-02-22 14:18:31 --> URI Class Initialized
INFO - 2026-02-22 14:18:31 --> Router Class Initialized
INFO - 2026-02-22 14:18:31 --> Router Class Initialized
INFO - 2026-02-22 14:18:31 --> Output Class Initialized
INFO - 2026-02-22 14:18:31 --> Output Class Initialized
INFO - 2026-02-22 14:18:31 --> Security Class Initialized
INFO - 2026-02-22 14:18:31 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:31 --> CSRF cookie sent
INFO - 2026-02-22 14:18:31 --> Input Class Initialized
DEBUG - 2026-02-22 14:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:31 --> CSRF cookie sent
INFO - 2026-02-22 14:18:31 --> Input Class Initialized
INFO - 2026-02-22 14:18:31 --> Language Class Initialized
INFO - 2026-02-22 14:18:31 --> Language Class Initialized
INFO - 2026-02-22 14:18:31 --> Language Class Initialized
INFO - 2026-02-22 14:18:31 --> Config Class Initialized
INFO - 2026-02-22 14:18:31 --> Language Class Initialized
INFO - 2026-02-22 14:18:31 --> Config Class Initialized
INFO - 2026-02-22 14:18:31 --> Loader Class Initialized
INFO - 2026-02-22 14:18:31 --> Loader Class Initialized
INFO - 2026-02-22 14:18:31 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:31 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:31 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:31 --> Config Class Initialized
INFO - 2026-02-22 14:18:31 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:18:31 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:31 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:31 --> URI Class Initialized
INFO - 2026-02-22 14:18:31 --> Router Class Initialized
INFO - 2026-02-22 14:18:31 --> Output Class Initialized
INFO - 2026-02-22 14:18:31 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:31 --> CSRF cookie sent
INFO - 2026-02-22 14:18:31 --> Input Class Initialized
INFO - 2026-02-22 14:18:31 --> Language Class Initialized
INFO - 2026-02-22 14:18:31 --> Language Class Initialized
INFO - 2026-02-22 14:18:31 --> Config Class Initialized
INFO - 2026-02-22 14:18:31 --> Loader Class Initialized
INFO - 2026-02-22 14:18:31 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:31 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:31 --> Config Class Initialized
INFO - 2026-02-22 14:18:31 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:18:31 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:31 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:31 --> URI Class Initialized
INFO - 2026-02-22 14:18:31 --> Router Class Initialized
INFO - 2026-02-22 14:18:31 --> Output Class Initialized
INFO - 2026-02-22 14:18:31 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:31 --> CSRF cookie sent
INFO - 2026-02-22 14:18:31 --> Input Class Initialized
INFO - 2026-02-22 14:18:31 --> Language Class Initialized
INFO - 2026-02-22 14:18:31 --> Language Class Initialized
INFO - 2026-02-22 14:18:31 --> Config Class Initialized
INFO - 2026-02-22 14:18:31 --> Loader Class Initialized
INFO - 2026-02-22 14:18:31 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:31 --> Config Class Initialized
INFO - 2026-02-22 14:18:31 --> Hooks Class Initialized
INFO - 2026-02-22 14:18:31 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:31 --> Config Class Initialized
INFO - 2026-02-22 14:18:31 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:18:31 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:31 --> Utf8 Class Initialized
DEBUG - 2026-02-22 14:18:31 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:31 --> URI Class Initialized
INFO - 2026-02-22 14:18:31 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:31 --> URI Class Initialized
INFO - 2026-02-22 14:18:31 --> Router Class Initialized
INFO - 2026-02-22 14:18:31 --> Output Class Initialized
INFO - 2026-02-22 14:18:31 --> Router Class Initialized
INFO - 2026-02-22 14:18:31 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:31 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:31 --> CSRF cookie sent
INFO - 2026-02-22 14:18:31 --> Input Class Initialized
INFO - 2026-02-22 14:18:31 --> Output Class Initialized
INFO - 2026-02-22 14:18:31 --> Language Class Initialized
INFO - 2026-02-22 14:18:31 --> Language Class Initialized
INFO - 2026-02-22 14:18:31 --> Config Class Initialized
INFO - 2026-02-22 14:18:31 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:31 --> CSRF cookie sent
INFO - 2026-02-22 14:18:31 --> Input Class Initialized
INFO - 2026-02-22 14:18:31 --> Language Class Initialized
INFO - 2026-02-22 14:18:31 --> Loader Class Initialized
INFO - 2026-02-22 14:18:31 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:31 --> Language Class Initialized
INFO - 2026-02-22 14:18:31 --> Config Class Initialized
INFO - 2026-02-22 14:18:31 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:31 --> Loader Class Initialized
INFO - 2026-02-22 14:18:31 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:31 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:31 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:31 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:31 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:33 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:33 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:33 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:33 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:33 --> Email Class Initialized
INFO - 2026-02-22 14:18:33 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:33 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:33 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:33 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:33 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:33 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:33 --> Config Class Initialized
INFO - 2026-02-22 14:18:33 --> Hooks Class Initialized
INFO - 2026-02-22 14:18:33 --> Email Class Initialized
INFO - 2026-02-22 14:18:33 --> Controller Class Initialized
DEBUG - 2026-02-22 14:18:33 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:33 --> Utf8 Class Initialized
ERROR - 2026-02-22 14:18:33 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:33 --> URI Class Initialized
INFO - 2026-02-22 14:18:33 --> Router Class Initialized
INFO - 2026-02-22 14:18:33 --> Output Class Initialized
INFO - 2026-02-22 14:18:33 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:33 --> CSRF cookie sent
INFO - 2026-02-22 14:18:33 --> Input Class Initialized
INFO - 2026-02-22 14:18:33 --> Language Class Initialized
INFO - 2026-02-22 14:18:33 --> Language Class Initialized
INFO - 2026-02-22 14:18:33 --> Config Class Initialized
INFO - 2026-02-22 14:18:33 --> Config Class Initialized
INFO - 2026-02-22 14:18:33 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:18:33 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:33 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:33 --> Loader Class Initialized
INFO - 2026-02-22 14:18:33 --> URI Class Initialized
INFO - 2026-02-22 14:18:33 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:33 --> Router Class Initialized
INFO - 2026-02-22 14:18:33 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:33 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:33 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:33 --> Output Class Initialized
INFO - 2026-02-22 14:18:33 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:33 --> Security Class Initialized
INFO - 2026-02-22 14:18:33 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:33 --> Helper loaded: ssp_helper
DEBUG - 2026-02-22 14:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:33 --> CSRF cookie sent
INFO - 2026-02-22 14:18:33 --> Input Class Initialized
INFO - 2026-02-22 14:18:33 --> Language Class Initialized
INFO - 2026-02-22 14:18:33 --> Language Class Initialized
INFO - 2026-02-22 14:18:33 --> Config Class Initialized
INFO - 2026-02-22 14:18:33 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:33 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:33 --> Loader Class Initialized
INFO - 2026-02-22 14:18:33 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:33 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:33 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:33 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:33 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:33 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:33 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:33 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:33 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:33 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:33 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:34 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:34 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:34 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:34 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:34 --> Email Class Initialized
INFO - 2026-02-22 14:18:34 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:34 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:34 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:34 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:34 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:34 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:34 --> Email Class Initialized
INFO - 2026-02-22 14:18:34 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:34 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:34 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:34 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:34 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:34 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:34 --> Email Class Initialized
INFO - 2026-02-22 14:18:34 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:34 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:34 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:34 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:34 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:34 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:34 --> Email Class Initialized
INFO - 2026-02-22 14:18:34 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:34 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:35 --> Config Class Initialized
INFO - 2026-02-22 14:18:35 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:18:35 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:35 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:35 --> URI Class Initialized
INFO - 2026-02-22 14:18:35 --> Router Class Initialized
INFO - 2026-02-22 14:18:35 --> Output Class Initialized
INFO - 2026-02-22 14:18:35 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:35 --> CSRF cookie sent
INFO - 2026-02-22 14:18:35 --> Input Class Initialized
INFO - 2026-02-22 14:18:35 --> Language Class Initialized
INFO - 2026-02-22 14:18:35 --> Language Class Initialized
INFO - 2026-02-22 14:18:35 --> Config Class Initialized
INFO - 2026-02-22 14:18:35 --> Loader Class Initialized
INFO - 2026-02-22 14:18:35 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:35 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:35 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:35 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:35 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:35 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:35 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:35 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:35 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:35 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:36 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:36 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:36 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:36 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:36 --> Email Class Initialized
INFO - 2026-02-22 14:18:36 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:36 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:36 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:36 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:36 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:36 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:36 --> Email Class Initialized
INFO - 2026-02-22 14:18:36 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:36 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:38 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:38 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:38 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:38 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:38 --> Email Class Initialized
INFO - 2026-02-22 14:18:38 --> Controller Class Initialized
DEBUG - 2026-02-22 14:18:38 --> Service_product MX_Controller Initialized
INFO - 2026-02-22 14:18:38 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:18:38 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:18:38 --> Model "Serviceproduct_model" initialized
INFO - 2026-02-22 14:18:38 --> Model "Common_model" initialized
DEBUG - 2026-02-22 14:18:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:18:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:18:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:18:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:18:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:18:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/service_product_list.php
INFO - 2026-02-22 14:18:39 --> Final output sent to browser
DEBUG - 2026-02-22 14:18:39 --> Total execution time: 3.9654
INFO - 2026-02-22 14:18:39 --> Config Class Initialized
INFO - 2026-02-22 14:18:39 --> Hooks Class Initialized
INFO - 2026-02-22 14:18:39 --> Config Class Initialized
INFO - 2026-02-22 14:18:39 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:18:39 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:39 --> Utf8 Class Initialized
DEBUG - 2026-02-22 14:18:39 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:39 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:39 --> URI Class Initialized
INFO - 2026-02-22 14:18:39 --> URI Class Initialized
INFO - 2026-02-22 14:18:39 --> Router Class Initialized
INFO - 2026-02-22 14:18:39 --> Router Class Initialized
INFO - 2026-02-22 14:18:39 --> Output Class Initialized
INFO - 2026-02-22 14:18:39 --> Output Class Initialized
INFO - 2026-02-22 14:18:39 --> Security Class Initialized
INFO - 2026-02-22 14:18:39 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:39 --> CSRF cookie sent
INFO - 2026-02-22 14:18:39 --> Input Class Initialized
INFO - 2026-02-22 14:18:39 --> Language Class Initialized
DEBUG - 2026-02-22 14:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:39 --> CSRF cookie sent
INFO - 2026-02-22 14:18:39 --> Input Class Initialized
INFO - 2026-02-22 14:18:39 --> Language Class Initialized
INFO - 2026-02-22 14:18:39 --> Config Class Initialized
INFO - 2026-02-22 14:18:39 --> Language Class Initialized
INFO - 2026-02-22 14:18:39 --> Language Class Initialized
INFO - 2026-02-22 14:18:39 --> Config Class Initialized
INFO - 2026-02-22 14:18:39 --> Loader Class Initialized
INFO - 2026-02-22 14:18:39 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:39 --> Loader Class Initialized
INFO - 2026-02-22 14:18:39 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:39 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:39 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:39 --> Config Class Initialized
INFO - 2026-02-22 14:18:39 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:18:39 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:39 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:39 --> URI Class Initialized
INFO - 2026-02-22 14:18:39 --> Router Class Initialized
INFO - 2026-02-22 14:18:39 --> Config Class Initialized
INFO - 2026-02-22 14:18:39 --> Hooks Class Initialized
INFO - 2026-02-22 14:18:39 --> Output Class Initialized
DEBUG - 2026-02-22 14:18:39 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:39 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:39 --> Security Class Initialized
INFO - 2026-02-22 14:18:39 --> Config Class Initialized
INFO - 2026-02-22 14:18:39 --> Hooks Class Initialized
INFO - 2026-02-22 14:18:39 --> Config Class Initialized
INFO - 2026-02-22 14:18:39 --> Hooks Class Initialized
INFO - 2026-02-22 14:18:39 --> URI Class Initialized
DEBUG - 2026-02-22 14:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-02-22 14:18:39 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:39 --> CSRF cookie sent
INFO - 2026-02-22 14:18:39 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:39 --> Input Class Initialized
DEBUG - 2026-02-22 14:18:39 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:39 --> Language Class Initialized
INFO - 2026-02-22 14:18:39 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:39 --> URI Class Initialized
INFO - 2026-02-22 14:18:39 --> Router Class Initialized
INFO - 2026-02-22 14:18:39 --> URI Class Initialized
INFO - 2026-02-22 14:18:39 --> Language Class Initialized
INFO - 2026-02-22 14:18:39 --> Config Class Initialized
INFO - 2026-02-22 14:18:39 --> Output Class Initialized
INFO - 2026-02-22 14:18:39 --> Router Class Initialized
INFO - 2026-02-22 14:18:39 --> Security Class Initialized
INFO - 2026-02-22 14:18:39 --> Router Class Initialized
INFO - 2026-02-22 14:18:39 --> Output Class Initialized
DEBUG - 2026-02-22 14:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:39 --> Security Class Initialized
INFO - 2026-02-22 14:18:39 --> Loader Class Initialized
INFO - 2026-02-22 14:18:39 --> CSRF cookie sent
INFO - 2026-02-22 14:18:39 --> Input Class Initialized
INFO - 2026-02-22 14:18:39 --> Output Class Initialized
INFO - 2026-02-22 14:18:39 --> Language Class Initialized
DEBUG - 2026-02-22 14:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:39 --> CSRF cookie sent
INFO - 2026-02-22 14:18:39 --> Input Class Initialized
INFO - 2026-02-22 14:18:39 --> Language Class Initialized
INFO - 2026-02-22 14:18:39 --> Config Class Initialized
INFO - 2026-02-22 14:18:39 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:39 --> Language Class Initialized
INFO - 2026-02-22 14:18:39 --> Security Class Initialized
INFO - 2026-02-22 14:18:39 --> Language Class Initialized
INFO - 2026-02-22 14:18:39 --> Config Class Initialized
DEBUG - 2026-02-22 14:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:39 --> CSRF cookie sent
INFO - 2026-02-22 14:18:39 --> Input Class Initialized
INFO - 2026-02-22 14:18:39 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:39 --> Language Class Initialized
INFO - 2026-02-22 14:18:39 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:39 --> Loader Class Initialized
INFO - 2026-02-22 14:18:39 --> Language Class Initialized
INFO - 2026-02-22 14:18:39 --> Config Class Initialized
INFO - 2026-02-22 14:18:39 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:39 --> Loader Class Initialized
INFO - 2026-02-22 14:18:39 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:39 --> Loader Class Initialized
INFO - 2026-02-22 14:18:39 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:39 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:39 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:39 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:39 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:39 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:39 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:39 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:41 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:41 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:41 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:41 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:41 --> Email Class Initialized
INFO - 2026-02-22 14:18:41 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:41 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:41 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:41 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:41 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:41 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:41 --> Config Class Initialized
INFO - 2026-02-22 14:18:41 --> Hooks Class Initialized
INFO - 2026-02-22 14:18:41 --> Email Class Initialized
INFO - 2026-02-22 14:18:41 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:41 --> 404 Page Not Found: /index
DEBUG - 2026-02-22 14:18:41 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:41 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:41 --> URI Class Initialized
INFO - 2026-02-22 14:18:41 --> Router Class Initialized
INFO - 2026-02-22 14:18:41 --> Output Class Initialized
INFO - 2026-02-22 14:18:41 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:41 --> CSRF cookie sent
INFO - 2026-02-22 14:18:41 --> Input Class Initialized
INFO - 2026-02-22 14:18:41 --> Language Class Initialized
INFO - 2026-02-22 14:18:41 --> Config Class Initialized
INFO - 2026-02-22 14:18:41 --> Hooks Class Initialized
INFO - 2026-02-22 14:18:41 --> Language Class Initialized
INFO - 2026-02-22 14:18:41 --> Config Class Initialized
DEBUG - 2026-02-22 14:18:41 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:41 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:41 --> URI Class Initialized
INFO - 2026-02-22 14:18:41 --> Loader Class Initialized
INFO - 2026-02-22 14:18:41 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:41 --> Router Class Initialized
INFO - 2026-02-22 14:18:41 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:41 --> Output Class Initialized
INFO - 2026-02-22 14:18:41 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:41 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:41 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:41 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:41 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:41 --> CSRF cookie sent
INFO - 2026-02-22 14:18:41 --> Input Class Initialized
INFO - 2026-02-22 14:18:41 --> Language Class Initialized
INFO - 2026-02-22 14:18:41 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:41 --> Language Class Initialized
INFO - 2026-02-22 14:18:41 --> Config Class Initialized
INFO - 2026-02-22 14:18:41 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:41 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:41 --> Loader Class Initialized
INFO - 2026-02-22 14:18:41 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:41 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:41 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:41 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:41 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:41 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:41 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:41 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:41 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:41 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:41 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:42 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:42 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:42 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:42 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:42 --> Email Class Initialized
INFO - 2026-02-22 14:18:42 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:42 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:42 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:42 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:42 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:42 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:42 --> Config Class Initialized
INFO - 2026-02-22 14:18:42 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:18:42 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:42 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:42 --> Email Class Initialized
INFO - 2026-02-22 14:18:42 --> Controller Class Initialized
INFO - 2026-02-22 14:18:42 --> URI Class Initialized
ERROR - 2026-02-22 14:18:42 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:42 --> Router Class Initialized
INFO - 2026-02-22 14:18:42 --> Upload Class Initialized
INFO - 2026-02-22 14:18:42 --> Output Class Initialized
DEBUG - 2026-02-22 14:18:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:42 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:42 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:42 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:42 --> CSRF cookie sent
INFO - 2026-02-22 14:18:42 --> Input Class Initialized
INFO - 2026-02-22 14:18:42 --> Language Class Initialized
INFO - 2026-02-22 14:18:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:42 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:42 --> Language Class Initialized
INFO - 2026-02-22 14:18:42 --> Config Class Initialized
INFO - 2026-02-22 14:18:42 --> Loader Class Initialized
INFO - 2026-02-22 14:18:42 --> Email Class Initialized
INFO - 2026-02-22 14:18:42 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:42 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:42 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:42 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:42 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:42 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:42 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:42 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:42 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:42 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:42 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:42 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:42 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:42 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:42 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:42 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:42 --> Email Class Initialized
INFO - 2026-02-22 14:18:42 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:42 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:44 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:44 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:44 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:44 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:44 --> Email Class Initialized
INFO - 2026-02-22 14:18:44 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:44 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:44 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:44 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:44 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:44 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:44 --> Email Class Initialized
INFO - 2026-02-22 14:18:44 --> Controller Class Initialized
DEBUG - 2026-02-22 14:18:44 --> Service_product MX_Controller Initialized
INFO - 2026-02-22 14:18:44 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:18:44 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:18:44 --> Model "Serviceproduct_model" initialized
INFO - 2026-02-22 14:18:44 --> Model "Common_model" initialized
INFO - 2026-02-22 14:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:46 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:46 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:46 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:46 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:46 --> Email Class Initialized
INFO - 2026-02-22 14:18:46 --> Controller Class Initialized
ERROR - 2026-02-22 14:18:46 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:18:57 --> Config Class Initialized
INFO - 2026-02-22 14:18:57 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:18:57 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:18:57 --> Utf8 Class Initialized
INFO - 2026-02-22 14:18:57 --> URI Class Initialized
INFO - 2026-02-22 14:18:57 --> Router Class Initialized
INFO - 2026-02-22 14:18:57 --> Output Class Initialized
INFO - 2026-02-22 14:18:57 --> Security Class Initialized
DEBUG - 2026-02-22 14:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:18:57 --> CSRF cookie sent
INFO - 2026-02-22 14:18:57 --> Input Class Initialized
INFO - 2026-02-22 14:18:57 --> Language Class Initialized
INFO - 2026-02-22 14:18:57 --> Language Class Initialized
INFO - 2026-02-22 14:18:57 --> Config Class Initialized
INFO - 2026-02-22 14:18:57 --> Loader Class Initialized
INFO - 2026-02-22 14:18:57 --> Helper loaded: url_helper
INFO - 2026-02-22 14:18:57 --> Helper loaded: form_helper
INFO - 2026-02-22 14:18:57 --> Helper loaded: html_helper
INFO - 2026-02-22 14:18:57 --> Helper loaded: file_helper
INFO - 2026-02-22 14:18:57 --> Helper loaded: email_helper
INFO - 2026-02-22 14:18:57 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:18:57 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:18:57 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:18:57 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:18:57 --> Database Driver Class Initialized
INFO - 2026-02-22 14:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:18:59 --> Upload Class Initialized
DEBUG - 2026-02-22 14:18:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:18:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:18:59 --> Encryption Class Initialized
INFO - 2026-02-22 14:18:59 --> Form Validation Class Initialized
INFO - 2026-02-22 14:18:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:18:59 --> Pagination Class Initialized
INFO - 2026-02-22 14:18:59 --> Email Class Initialized
INFO - 2026-02-22 14:18:59 --> Controller Class Initialized
DEBUG - 2026-02-22 14:18:59 --> Package MX_Controller Initialized
INFO - 2026-02-22 14:18:59 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:18:59 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:18:59 --> Model "Package_model" initialized
INFO - 2026-02-22 14:18:59 --> Model "Common_model" initialized
DEBUG - 2026-02-22 14:18:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:18:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:18:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:18:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:18:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:18:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/package_list.php
INFO - 2026-02-22 14:18:59 --> Final output sent to browser
DEBUG - 2026-02-22 14:18:59 --> Total execution time: 2.6034
INFO - 2026-02-22 14:19:00 --> Config Class Initialized
INFO - 2026-02-22 14:19:00 --> Hooks Class Initialized
INFO - 2026-02-22 14:19:00 --> Config Class Initialized
INFO - 2026-02-22 14:19:00 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:19:00 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:19:00 --> Utf8 Class Initialized
INFO - 2026-02-22 14:19:00 --> URI Class Initialized
DEBUG - 2026-02-22 14:19:00 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:19:00 --> Utf8 Class Initialized
INFO - 2026-02-22 14:19:00 --> URI Class Initialized
INFO - 2026-02-22 14:19:00 --> Router Class Initialized
INFO - 2026-02-22 14:19:00 --> Router Class Initialized
INFO - 2026-02-22 14:19:00 --> Output Class Initialized
INFO - 2026-02-22 14:19:00 --> Output Class Initialized
INFO - 2026-02-22 14:19:00 --> Security Class Initialized
INFO - 2026-02-22 14:19:00 --> Security Class Initialized
DEBUG - 2026-02-22 14:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:19:00 --> CSRF cookie sent
INFO - 2026-02-22 14:19:00 --> Input Class Initialized
DEBUG - 2026-02-22 14:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:19:00 --> CSRF cookie sent
INFO - 2026-02-22 14:19:00 --> Input Class Initialized
INFO - 2026-02-22 14:19:00 --> Language Class Initialized
INFO - 2026-02-22 14:19:00 --> Language Class Initialized
INFO - 2026-02-22 14:19:00 --> Language Class Initialized
INFO - 2026-02-22 14:19:00 --> Config Class Initialized
INFO - 2026-02-22 14:19:00 --> Language Class Initialized
INFO - 2026-02-22 14:19:00 --> Config Class Initialized
INFO - 2026-02-22 14:19:00 --> Loader Class Initialized
INFO - 2026-02-22 14:19:00 --> Loader Class Initialized
INFO - 2026-02-22 14:19:00 --> Helper loaded: url_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: url_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: form_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: form_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: html_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: html_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: file_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: email_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: file_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: email_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:19:00 --> Database Driver Class Initialized
INFO - 2026-02-22 14:19:00 --> Database Driver Class Initialized
INFO - 2026-02-22 14:19:00 --> Config Class Initialized
INFO - 2026-02-22 14:19:00 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:19:00 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:19:00 --> Utf8 Class Initialized
INFO - 2026-02-22 14:19:00 --> URI Class Initialized
INFO - 2026-02-22 14:19:00 --> Router Class Initialized
INFO - 2026-02-22 14:19:00 --> Output Class Initialized
INFO - 2026-02-22 14:19:00 --> Security Class Initialized
DEBUG - 2026-02-22 14:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:19:00 --> CSRF cookie sent
INFO - 2026-02-22 14:19:00 --> Input Class Initialized
INFO - 2026-02-22 14:19:00 --> Language Class Initialized
INFO - 2026-02-22 14:19:00 --> Config Class Initialized
INFO - 2026-02-22 14:19:00 --> Hooks Class Initialized
INFO - 2026-02-22 14:19:00 --> Config Class Initialized
INFO - 2026-02-22 14:19:00 --> Hooks Class Initialized
INFO - 2026-02-22 14:19:00 --> Language Class Initialized
INFO - 2026-02-22 14:19:00 --> Config Class Initialized
DEBUG - 2026-02-22 14:19:00 --> UTF-8 Support Enabled
DEBUG - 2026-02-22 14:19:00 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:19:00 --> Utf8 Class Initialized
INFO - 2026-02-22 14:19:00 --> Utf8 Class Initialized
INFO - 2026-02-22 14:19:00 --> URI Class Initialized
INFO - 2026-02-22 14:19:00 --> URI Class Initialized
INFO - 2026-02-22 14:19:00 --> Loader Class Initialized
INFO - 2026-02-22 14:19:00 --> Helper loaded: url_helper
INFO - 2026-02-22 14:19:00 --> Router Class Initialized
INFO - 2026-02-22 14:19:00 --> Router Class Initialized
INFO - 2026-02-22 14:19:00 --> Helper loaded: form_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: html_helper
INFO - 2026-02-22 14:19:00 --> Output Class Initialized
INFO - 2026-02-22 14:19:00 --> Output Class Initialized
INFO - 2026-02-22 14:19:00 --> Helper loaded: file_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: email_helper
INFO - 2026-02-22 14:19:00 --> Security Class Initialized
INFO - 2026-02-22 14:19:00 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:19:00 --> Security Class Initialized
DEBUG - 2026-02-22 14:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:19:00 --> CSRF cookie sent
INFO - 2026-02-22 14:19:00 --> Input Class Initialized
INFO - 2026-02-22 14:19:00 --> Config Class Initialized
INFO - 2026-02-22 14:19:00 --> Hooks Class Initialized
INFO - 2026-02-22 14:19:00 --> Language Class Initialized
INFO - 2026-02-22 14:19:00 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:19:00 --> Language Class Initialized
INFO - 2026-02-22 14:19:00 --> Config Class Initialized
INFO - 2026-02-22 14:19:00 --> Helper loaded: domain_helper
DEBUG - 2026-02-22 14:19:00 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:19:00 --> Utf8 Class Initialized
DEBUG - 2026-02-22 14:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:19:00 --> CSRF cookie sent
INFO - 2026-02-22 14:19:00 --> Input Class Initialized
INFO - 2026-02-22 14:19:00 --> URI Class Initialized
INFO - 2026-02-22 14:19:00 --> Language Class Initialized
INFO - 2026-02-22 14:19:00 --> Language Class Initialized
INFO - 2026-02-22 14:19:00 --> Loader Class Initialized
INFO - 2026-02-22 14:19:00 --> Router Class Initialized
INFO - 2026-02-22 14:19:00 --> Config Class Initialized
INFO - 2026-02-22 14:19:00 --> Helper loaded: url_helper
INFO - 2026-02-22 14:19:00 --> Output Class Initialized
INFO - 2026-02-22 14:19:00 --> Helper loaded: form_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: html_helper
INFO - 2026-02-22 14:19:00 --> Security Class Initialized
INFO - 2026-02-22 14:19:00 --> Helper loaded: file_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: email_helper
INFO - 2026-02-22 14:19:00 --> Loader Class Initialized
DEBUG - 2026-02-22 14:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:19:00 --> CSRF cookie sent
INFO - 2026-02-22 14:19:00 --> Input Class Initialized
INFO - 2026-02-22 14:19:00 --> Language Class Initialized
INFO - 2026-02-22 14:19:00 --> Helper loaded: url_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:19:00 --> Database Driver Class Initialized
INFO - 2026-02-22 14:19:00 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:19:00 --> Language Class Initialized
INFO - 2026-02-22 14:19:00 --> Config Class Initialized
INFO - 2026-02-22 14:19:00 --> Helper loaded: form_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:19:00 --> Loader Class Initialized
INFO - 2026-02-22 14:19:00 --> Helper loaded: url_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: html_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: form_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: file_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: email_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: html_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: file_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: email_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:19:00 --> Database Driver Class Initialized
INFO - 2026-02-22 14:19:00 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:19:00 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:19:00 --> Database Driver Class Initialized
INFO - 2026-02-22 14:19:00 --> Database Driver Class Initialized
INFO - 2026-02-22 14:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:19:02 --> Upload Class Initialized
DEBUG - 2026-02-22 14:19:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:19:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:19:02 --> Encryption Class Initialized
INFO - 2026-02-22 14:19:02 --> Form Validation Class Initialized
INFO - 2026-02-22 14:19:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:19:02 --> Pagination Class Initialized
INFO - 2026-02-22 14:19:02 --> Email Class Initialized
INFO - 2026-02-22 14:19:02 --> Controller Class Initialized
ERROR - 2026-02-22 14:19:02 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:19:02 --> Upload Class Initialized
DEBUG - 2026-02-22 14:19:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:19:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:19:02 --> Encryption Class Initialized
INFO - 2026-02-22 14:19:02 --> Form Validation Class Initialized
INFO - 2026-02-22 14:19:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:19:02 --> Pagination Class Initialized
INFO - 2026-02-22 14:19:02 --> Config Class Initialized
INFO - 2026-02-22 14:19:02 --> Hooks Class Initialized
INFO - 2026-02-22 14:19:02 --> Email Class Initialized
DEBUG - 2026-02-22 14:19:02 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:19:02 --> Controller Class Initialized
INFO - 2026-02-22 14:19:02 --> Utf8 Class Initialized
ERROR - 2026-02-22 14:19:02 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:19:02 --> URI Class Initialized
INFO - 2026-02-22 14:19:02 --> Upload Class Initialized
INFO - 2026-02-22 14:19:02 --> Router Class Initialized
DEBUG - 2026-02-22 14:19:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:19:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:19:02 --> Encryption Class Initialized
INFO - 2026-02-22 14:19:02 --> Output Class Initialized
INFO - 2026-02-22 14:19:02 --> Form Validation Class Initialized
INFO - 2026-02-22 14:19:02 --> Security Class Initialized
INFO - 2026-02-22 14:19:02 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2026-02-22 14:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:19:02 --> CSRF cookie sent
INFO - 2026-02-22 14:19:02 --> Input Class Initialized
INFO - 2026-02-22 14:19:02 --> Pagination Class Initialized
INFO - 2026-02-22 14:19:02 --> Language Class Initialized
INFO - 2026-02-22 14:19:02 --> Language Class Initialized
INFO - 2026-02-22 14:19:02 --> Config Class Initialized
INFO - 2026-02-22 14:19:02 --> Loader Class Initialized
INFO - 2026-02-22 14:19:02 --> Helper loaded: url_helper
INFO - 2026-02-22 14:19:02 --> Email Class Initialized
INFO - 2026-02-22 14:19:02 --> Controller Class Initialized
ERROR - 2026-02-22 14:19:02 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:19:02 --> Helper loaded: form_helper
INFO - 2026-02-22 14:19:02 --> Config Class Initialized
INFO - 2026-02-22 14:19:02 --> Hooks Class Initialized
INFO - 2026-02-22 14:19:02 --> Helper loaded: html_helper
INFO - 2026-02-22 14:19:02 --> Helper loaded: file_helper
DEBUG - 2026-02-22 14:19:02 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:19:02 --> Utf8 Class Initialized
INFO - 2026-02-22 14:19:02 --> Helper loaded: email_helper
INFO - 2026-02-22 14:19:02 --> Upload Class Initialized
INFO - 2026-02-22 14:19:02 --> URI Class Initialized
DEBUG - 2026-02-22 14:19:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:19:02 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:19:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:19:02 --> Encryption Class Initialized
INFO - 2026-02-22 14:19:02 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:19:02 --> Router Class Initialized
INFO - 2026-02-22 14:19:02 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:19:02 --> Form Validation Class Initialized
INFO - 2026-02-22 14:19:02 --> Output Class Initialized
INFO - 2026-02-22 14:19:02 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:19:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:19:02 --> Pagination Class Initialized
INFO - 2026-02-22 14:19:02 --> Security Class Initialized
DEBUG - 2026-02-22 14:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:19:02 --> Email Class Initialized
INFO - 2026-02-22 14:19:02 --> CSRF cookie sent
INFO - 2026-02-22 14:19:02 --> Input Class Initialized
INFO - 2026-02-22 14:19:02 --> Controller Class Initialized
INFO - 2026-02-22 14:19:02 --> Language Class Initialized
ERROR - 2026-02-22 14:19:02 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:19:02 --> Language Class Initialized
INFO - 2026-02-22 14:19:02 --> Config Class Initialized
INFO - 2026-02-22 14:19:02 --> Config Class Initialized
INFO - 2026-02-22 14:19:02 --> Hooks Class Initialized
INFO - 2026-02-22 14:19:02 --> Upload Class Initialized
INFO - 2026-02-22 14:19:02 --> Database Driver Class Initialized
DEBUG - 2026-02-22 14:19:02 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:19:02 --> Utf8 Class Initialized
DEBUG - 2026-02-22 14:19:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:19:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:19:02 --> Encryption Class Initialized
INFO - 2026-02-22 14:19:02 --> URI Class Initialized
INFO - 2026-02-22 14:19:02 --> Loader Class Initialized
INFO - 2026-02-22 14:19:02 --> Form Validation Class Initialized
INFO - 2026-02-22 14:19:02 --> Helper loaded: url_helper
INFO - 2026-02-22 14:19:02 --> Router Class Initialized
INFO - 2026-02-22 14:19:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:19:02 --> Pagination Class Initialized
INFO - 2026-02-22 14:19:02 --> Helper loaded: form_helper
INFO - 2026-02-22 14:19:02 --> Output Class Initialized
INFO - 2026-02-22 14:19:02 --> Helper loaded: html_helper
INFO - 2026-02-22 14:19:02 --> Email Class Initialized
INFO - 2026-02-22 14:19:02 --> Controller Class Initialized
INFO - 2026-02-22 14:19:02 --> Helper loaded: file_helper
INFO - 2026-02-22 14:19:02 --> Helper loaded: email_helper
ERROR - 2026-02-22 14:19:02 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:19:02 --> Security Class Initialized
DEBUG - 2026-02-22 14:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:19:02 --> CSRF cookie sent
INFO - 2026-02-22 14:19:02 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:19:02 --> Input Class Initialized
INFO - 2026-02-22 14:19:02 --> Language Class Initialized
INFO - 2026-02-22 14:19:02 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:19:02 --> Language Class Initialized
INFO - 2026-02-22 14:19:02 --> Config Class Initialized
INFO - 2026-02-22 14:19:02 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:19:02 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:19:02 --> Loader Class Initialized
INFO - 2026-02-22 14:19:02 --> Helper loaded: url_helper
INFO - 2026-02-22 14:19:02 --> Helper loaded: form_helper
INFO - 2026-02-22 14:19:02 --> Helper loaded: html_helper
INFO - 2026-02-22 14:19:02 --> Helper loaded: file_helper
INFO - 2026-02-22 14:19:02 --> Helper loaded: email_helper
INFO - 2026-02-22 14:19:02 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:19:02 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:19:02 --> Database Driver Class Initialized
INFO - 2026-02-22 14:19:02 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:19:02 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:19:02 --> Database Driver Class Initialized
INFO - 2026-02-22 14:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:19:03 --> Upload Class Initialized
DEBUG - 2026-02-22 14:19:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:19:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:19:03 --> Encryption Class Initialized
INFO - 2026-02-22 14:19:03 --> Form Validation Class Initialized
INFO - 2026-02-22 14:19:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:19:03 --> Pagination Class Initialized
INFO - 2026-02-22 14:19:03 --> Email Class Initialized
INFO - 2026-02-22 14:19:03 --> Controller Class Initialized
ERROR - 2026-02-22 14:19:03 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:19:05 --> Upload Class Initialized
DEBUG - 2026-02-22 14:19:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:19:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:19:05 --> Encryption Class Initialized
INFO - 2026-02-22 14:19:05 --> Form Validation Class Initialized
INFO - 2026-02-22 14:19:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:19:05 --> Pagination Class Initialized
INFO - 2026-02-22 14:19:05 --> Email Class Initialized
INFO - 2026-02-22 14:19:05 --> Controller Class Initialized
ERROR - 2026-02-22 14:19:05 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:19:06 --> Upload Class Initialized
DEBUG - 2026-02-22 14:19:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:19:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:19:06 --> Encryption Class Initialized
INFO - 2026-02-22 14:19:06 --> Form Validation Class Initialized
INFO - 2026-02-22 14:19:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:19:06 --> Pagination Class Initialized
INFO - 2026-02-22 14:19:06 --> Email Class Initialized
INFO - 2026-02-22 14:19:06 --> Controller Class Initialized
ERROR - 2026-02-22 14:19:06 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:19:06 --> Upload Class Initialized
DEBUG - 2026-02-22 14:19:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:19:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:19:06 --> Encryption Class Initialized
INFO - 2026-02-22 14:19:06 --> Form Validation Class Initialized
INFO - 2026-02-22 14:19:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:19:06 --> Pagination Class Initialized
INFO - 2026-02-22 14:19:06 --> Email Class Initialized
INFO - 2026-02-22 14:19:06 --> Controller Class Initialized
DEBUG - 2026-02-22 14:19:06 --> Package MX_Controller Initialized
INFO - 2026-02-22 14:19:06 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:19:06 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:19:06 --> Model "Package_model" initialized
INFO - 2026-02-22 14:19:06 --> Model "Common_model" initialized
INFO - 2026-02-22 14:20:03 --> Config Class Initialized
INFO - 2026-02-22 14:20:03 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:20:03 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:20:03 --> Utf8 Class Initialized
INFO - 2026-02-22 14:20:03 --> URI Class Initialized
INFO - 2026-02-22 14:20:03 --> Router Class Initialized
INFO - 2026-02-22 14:20:03 --> Output Class Initialized
INFO - 2026-02-22 14:20:03 --> Security Class Initialized
DEBUG - 2026-02-22 14:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:20:03 --> CSRF cookie sent
INFO - 2026-02-22 14:20:03 --> Input Class Initialized
INFO - 2026-02-22 14:20:03 --> Language Class Initialized
INFO - 2026-02-22 14:20:03 --> Language Class Initialized
INFO - 2026-02-22 14:20:03 --> Config Class Initialized
INFO - 2026-02-22 14:20:03 --> Loader Class Initialized
INFO - 2026-02-22 14:20:03 --> Helper loaded: url_helper
INFO - 2026-02-22 14:20:03 --> Helper loaded: form_helper
INFO - 2026-02-22 14:20:03 --> Helper loaded: html_helper
INFO - 2026-02-22 14:20:03 --> Helper loaded: file_helper
INFO - 2026-02-22 14:20:03 --> Helper loaded: email_helper
INFO - 2026-02-22 14:20:03 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:20:03 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:20:03 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:20:03 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:20:03 --> Database Driver Class Initialized
INFO - 2026-02-22 14:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:20:05 --> Upload Class Initialized
DEBUG - 2026-02-22 14:20:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:20:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:20:05 --> Encryption Class Initialized
INFO - 2026-02-22 14:20:05 --> Form Validation Class Initialized
INFO - 2026-02-22 14:20:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:20:05 --> Pagination Class Initialized
INFO - 2026-02-22 14:20:05 --> Email Class Initialized
INFO - 2026-02-22 14:20:05 --> Controller Class Initialized
DEBUG - 2026-02-22 14:20:05 --> Billing MX_Controller Initialized
INFO - 2026-02-22 14:20:05 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:20:05 --> Model "Auth_model" initialized
INFO - 2026-02-22 14:20:05 --> Model "Cart_model" initialized
INFO - 2026-02-22 14:20:05 --> Model "Billing_model" initialized
INFO - 2026-02-22 14:20:05 --> Model "Common_model" initialized
INFO - 2026-02-22 14:20:05 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-22 14:20:06 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-22 14:20:06 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-02-22 14:20:06 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-22 14:20:06 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-22 14:20:06 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_invoices.php
INFO - 2026-02-22 14:20:06 --> Final output sent to browser
DEBUG - 2026-02-22 14:20:06 --> Total execution time: 3.0844
INFO - 2026-02-22 14:20:07 --> Config Class Initialized
INFO - 2026-02-22 14:20:07 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:20:07 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:20:07 --> Utf8 Class Initialized
INFO - 2026-02-22 14:20:07 --> URI Class Initialized
INFO - 2026-02-22 14:20:07 --> Router Class Initialized
INFO - 2026-02-22 14:20:07 --> Output Class Initialized
INFO - 2026-02-22 14:20:07 --> Security Class Initialized
DEBUG - 2026-02-22 14:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:20:07 --> CSRF cookie sent
INFO - 2026-02-22 14:20:07 --> Input Class Initialized
INFO - 2026-02-22 14:20:07 --> Language Class Initialized
INFO - 2026-02-22 14:20:07 --> Language Class Initialized
INFO - 2026-02-22 14:20:07 --> Config Class Initialized
INFO - 2026-02-22 14:20:07 --> Loader Class Initialized
INFO - 2026-02-22 14:20:07 --> Helper loaded: url_helper
INFO - 2026-02-22 14:20:07 --> Helper loaded: form_helper
INFO - 2026-02-22 14:20:07 --> Helper loaded: html_helper
INFO - 2026-02-22 14:20:07 --> Helper loaded: file_helper
INFO - 2026-02-22 14:20:07 --> Helper loaded: email_helper
INFO - 2026-02-22 14:20:07 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:20:07 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:20:07 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:20:07 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:20:07 --> Database Driver Class Initialized
INFO - 2026-02-22 14:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:20:08 --> Upload Class Initialized
DEBUG - 2026-02-22 14:20:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:20:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:20:08 --> Encryption Class Initialized
INFO - 2026-02-22 14:20:08 --> Form Validation Class Initialized
INFO - 2026-02-22 14:20:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:20:08 --> Pagination Class Initialized
INFO - 2026-02-22 14:20:08 --> Email Class Initialized
INFO - 2026-02-22 14:20:08 --> Controller Class Initialized
DEBUG - 2026-02-22 14:20:08 --> Cart MX_Controller Initialized
INFO - 2026-02-22 14:20:08 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:20:08 --> Model "Auth_model" initialized
INFO - 2026-02-22 14:20:08 --> Model "Cart_model" initialized
INFO - 2026-02-22 14:20:08 --> Model "Common_model" initialized
INFO - 2026-02-22 14:20:08 --> Model "Order_model" initialized
INFO - 2026-02-22 14:20:08 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 14:20:08 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-22 14:20:09 --> Final output sent to browser
DEBUG - 2026-02-22 14:20:09 --> Total execution time: 2.1410
INFO - 2026-02-22 14:20:09 --> Config Class Initialized
INFO - 2026-02-22 14:20:09 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:20:09 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:20:09 --> Utf8 Class Initialized
INFO - 2026-02-22 14:20:09 --> URI Class Initialized
INFO - 2026-02-22 14:20:09 --> Router Class Initialized
INFO - 2026-02-22 14:20:09 --> Output Class Initialized
INFO - 2026-02-22 14:20:09 --> Security Class Initialized
DEBUG - 2026-02-22 14:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:20:09 --> CSRF cookie sent
INFO - 2026-02-22 14:20:09 --> Input Class Initialized
INFO - 2026-02-22 14:20:09 --> Language Class Initialized
INFO - 2026-02-22 14:20:09 --> Language Class Initialized
INFO - 2026-02-22 14:20:09 --> Config Class Initialized
INFO - 2026-02-22 14:20:09 --> Loader Class Initialized
INFO - 2026-02-22 14:20:09 --> Helper loaded: url_helper
INFO - 2026-02-22 14:20:09 --> Helper loaded: form_helper
INFO - 2026-02-22 14:20:09 --> Helper loaded: html_helper
INFO - 2026-02-22 14:20:09 --> Helper loaded: file_helper
INFO - 2026-02-22 14:20:09 --> Helper loaded: email_helper
INFO - 2026-02-22 14:20:09 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:20:09 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:20:09 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:20:09 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:20:09 --> Database Driver Class Initialized
INFO - 2026-02-22 14:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:20:11 --> Upload Class Initialized
DEBUG - 2026-02-22 14:20:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:20:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:20:11 --> Encryption Class Initialized
INFO - 2026-02-22 14:20:11 --> Form Validation Class Initialized
INFO - 2026-02-22 14:20:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:20:11 --> Pagination Class Initialized
INFO - 2026-02-22 14:20:11 --> Email Class Initialized
INFO - 2026-02-22 14:20:11 --> Controller Class Initialized
DEBUG - 2026-02-22 14:20:11 --> Pay MX_Controller Initialized
INFO - 2026-02-22 14:20:11 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:20:11 --> Model "Auth_model" initialized
INFO - 2026-02-22 14:20:11 --> Model "Cart_model" initialized
INFO - 2026-02-22 14:20:11 --> Model "Payment_model" initialized
INFO - 2026-02-22 14:20:11 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-22 14:20:11 --> Model "Billing_model" initialized
INFO - 2026-02-22 14:20:11 --> Model "Invoice_model" initialized
DEBUG - 2026-02-22 14:20:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-22 14:20:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-22 14:20:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-22 14:20:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_pay.php
INFO - 2026-02-22 14:20:15 --> Final output sent to browser
DEBUG - 2026-02-22 14:20:15 --> Total execution time: 5.5699
INFO - 2026-02-22 14:20:16 --> Config Class Initialized
INFO - 2026-02-22 14:20:16 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:20:16 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:20:16 --> Utf8 Class Initialized
INFO - 2026-02-22 14:20:16 --> URI Class Initialized
INFO - 2026-02-22 14:20:16 --> Router Class Initialized
INFO - 2026-02-22 14:20:16 --> Output Class Initialized
INFO - 2026-02-22 14:20:16 --> Security Class Initialized
DEBUG - 2026-02-22 14:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:20:16 --> CSRF cookie sent
INFO - 2026-02-22 14:20:16 --> Input Class Initialized
INFO - 2026-02-22 14:20:16 --> Language Class Initialized
INFO - 2026-02-22 14:20:16 --> Language Class Initialized
INFO - 2026-02-22 14:20:16 --> Config Class Initialized
INFO - 2026-02-22 14:20:16 --> Loader Class Initialized
INFO - 2026-02-22 14:20:16 --> Helper loaded: url_helper
INFO - 2026-02-22 14:20:16 --> Helper loaded: form_helper
INFO - 2026-02-22 14:20:16 --> Helper loaded: html_helper
INFO - 2026-02-22 14:20:16 --> Helper loaded: file_helper
INFO - 2026-02-22 14:20:16 --> Helper loaded: email_helper
INFO - 2026-02-22 14:20:16 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:20:16 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:20:16 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:20:16 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:20:16 --> Database Driver Class Initialized
INFO - 2026-02-22 14:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:20:17 --> Upload Class Initialized
DEBUG - 2026-02-22 14:20:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:20:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:20:17 --> Encryption Class Initialized
INFO - 2026-02-22 14:20:17 --> Form Validation Class Initialized
INFO - 2026-02-22 14:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:20:17 --> Pagination Class Initialized
INFO - 2026-02-22 14:20:17 --> Email Class Initialized
INFO - 2026-02-22 14:20:17 --> Controller Class Initialized
DEBUG - 2026-02-22 14:20:17 --> Cart MX_Controller Initialized
INFO - 2026-02-22 14:20:17 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:20:17 --> Model "Auth_model" initialized
INFO - 2026-02-22 14:20:17 --> Model "Cart_model" initialized
INFO - 2026-02-22 14:20:17 --> Model "Common_model" initialized
INFO - 2026-02-22 14:20:17 --> Model "Order_model" initialized
INFO - 2026-02-22 14:20:17 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 14:20:17 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-22 14:20:18 --> Final output sent to browser
DEBUG - 2026-02-22 14:20:18 --> Total execution time: 2.2188
INFO - 2026-02-22 14:20:28 --> Config Class Initialized
INFO - 2026-02-22 14:20:28 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:20:28 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:20:28 --> Utf8 Class Initialized
INFO - 2026-02-22 14:20:28 --> URI Class Initialized
INFO - 2026-02-22 14:20:28 --> Router Class Initialized
INFO - 2026-02-22 14:20:28 --> Output Class Initialized
INFO - 2026-02-22 14:20:28 --> Security Class Initialized
DEBUG - 2026-02-22 14:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:20:28 --> CSRF cookie sent
INFO - 2026-02-22 14:20:28 --> CSRF token verified
INFO - 2026-02-22 14:20:28 --> Input Class Initialized
INFO - 2026-02-22 14:20:28 --> Language Class Initialized
INFO - 2026-02-22 14:20:28 --> Language Class Initialized
INFO - 2026-02-22 14:20:28 --> Config Class Initialized
INFO - 2026-02-22 14:20:28 --> Loader Class Initialized
INFO - 2026-02-22 14:20:28 --> Helper loaded: url_helper
INFO - 2026-02-22 14:20:28 --> Helper loaded: form_helper
INFO - 2026-02-22 14:20:28 --> Helper loaded: html_helper
INFO - 2026-02-22 14:20:28 --> Helper loaded: file_helper
INFO - 2026-02-22 14:20:28 --> Helper loaded: email_helper
INFO - 2026-02-22 14:20:28 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:20:28 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:20:28 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:20:28 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:20:28 --> Database Driver Class Initialized
INFO - 2026-02-22 14:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:20:31 --> Upload Class Initialized
DEBUG - 2026-02-22 14:20:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:20:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:20:31 --> Encryption Class Initialized
INFO - 2026-02-22 14:20:31 --> Form Validation Class Initialized
INFO - 2026-02-22 14:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:20:31 --> Pagination Class Initialized
INFO - 2026-02-22 14:20:31 --> Email Class Initialized
INFO - 2026-02-22 14:20:31 --> Controller Class Initialized
DEBUG - 2026-02-22 14:20:31 --> Pay MX_Controller Initialized
INFO - 2026-02-22 14:20:31 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:20:31 --> Model "Auth_model" initialized
INFO - 2026-02-22 14:20:31 --> Model "Cart_model" initialized
INFO - 2026-02-22 14:20:31 --> Model "Payment_model" initialized
INFO - 2026-02-22 14:20:31 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-22 14:20:31 --> Model "Billing_model" initialized
INFO - 2026-02-22 14:20:31 --> Model "Invoice_model" initialized
INFO - 2026-02-22 14:20:38 --> Final output sent to browser
DEBUG - 2026-02-22 14:20:38 --> Total execution time: 10.6209
INFO - 2026-02-22 14:21:33 --> Config Class Initialized
INFO - 2026-02-22 14:21:33 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:21:33 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:21:33 --> Utf8 Class Initialized
INFO - 2026-02-22 14:21:33 --> URI Class Initialized
INFO - 2026-02-22 14:21:33 --> Router Class Initialized
INFO - 2026-02-22 14:21:33 --> Output Class Initialized
INFO - 2026-02-22 14:21:33 --> Security Class Initialized
DEBUG - 2026-02-22 14:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:21:33 --> Input Class Initialized
INFO - 2026-02-22 14:21:33 --> Language Class Initialized
INFO - 2026-02-22 14:21:33 --> Language Class Initialized
INFO - 2026-02-22 14:21:33 --> Config Class Initialized
INFO - 2026-02-22 14:21:33 --> Loader Class Initialized
INFO - 2026-02-22 14:21:33 --> Helper loaded: url_helper
INFO - 2026-02-22 14:21:33 --> Helper loaded: form_helper
INFO - 2026-02-22 14:21:33 --> Helper loaded: html_helper
INFO - 2026-02-22 14:21:33 --> Helper loaded: file_helper
INFO - 2026-02-22 14:21:33 --> Helper loaded: email_helper
INFO - 2026-02-22 14:21:33 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:21:33 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:21:33 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:21:33 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:21:33 --> Database Driver Class Initialized
INFO - 2026-02-22 14:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:21:36 --> Upload Class Initialized
DEBUG - 2026-02-22 14:21:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:21:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:21:36 --> Encryption Class Initialized
INFO - 2026-02-22 14:21:36 --> Form Validation Class Initialized
INFO - 2026-02-22 14:21:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:21:36 --> Pagination Class Initialized
INFO - 2026-02-22 14:21:36 --> Email Class Initialized
INFO - 2026-02-22 14:21:36 --> Controller Class Initialized
DEBUG - 2026-02-22 14:21:36 --> Pay MX_Controller Initialized
INFO - 2026-02-22 14:21:36 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:21:36 --> Model "Auth_model" initialized
INFO - 2026-02-22 14:21:36 --> Model "Cart_model" initialized
INFO - 2026-02-22 14:21:36 --> Model "Payment_model" initialized
INFO - 2026-02-22 14:21:36 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-22 14:21:36 --> Model "Billing_model" initialized
INFO - 2026-02-22 14:21:36 --> Model "Invoice_model" initialized
INFO - 2026-02-22 14:21:41 --> Model "Provisioning_model" initialized
INFO - 2026-02-22 14:21:42 --> Provisioning: Renewing service #719
INFO - 2026-02-22 14:21:42 --> Service renewed: #719, Actions: 
INFO - 2026-02-22 14:21:45 --> Provisioning completed for invoice #556 - Total: 2, Success: 1, Failed: 1
INFO - 2026-02-22 14:21:45 --> provisionPaidServices completed for invoice #556 - Success: 1/2
INFO - 2026-02-22 14:21:57 --> Model "Syscnf_model" initialized
INFO - 2026-02-22 14:22:07 --> Payment confirmation emails sent for transaction #8 - Customer: Yes, Admin: Yes
INFO - 2026-02-22 14:22:07 --> Invoice #556 marked as PAID. Total: 25.95, Paid: 25.95
INFO - 2026-02-22 14:22:09 --> Config Class Initialized
INFO - 2026-02-22 14:22:09 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:22:09 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:22:09 --> Utf8 Class Initialized
INFO - 2026-02-22 14:22:09 --> URI Class Initialized
INFO - 2026-02-22 14:22:09 --> Router Class Initialized
INFO - 2026-02-22 14:22:09 --> Output Class Initialized
INFO - 2026-02-22 14:22:09 --> Security Class Initialized
DEBUG - 2026-02-22 14:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:22:09 --> CSRF cookie sent
INFO - 2026-02-22 14:22:09 --> Input Class Initialized
INFO - 2026-02-22 14:22:09 --> Language Class Initialized
INFO - 2026-02-22 14:22:09 --> Language Class Initialized
INFO - 2026-02-22 14:22:09 --> Config Class Initialized
INFO - 2026-02-22 14:22:09 --> Loader Class Initialized
INFO - 2026-02-22 14:22:09 --> Helper loaded: url_helper
INFO - 2026-02-22 14:22:09 --> Helper loaded: form_helper
INFO - 2026-02-22 14:22:09 --> Helper loaded: html_helper
INFO - 2026-02-22 14:22:09 --> Helper loaded: file_helper
INFO - 2026-02-22 14:22:09 --> Helper loaded: email_helper
INFO - 2026-02-22 14:22:09 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:22:09 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:22:09 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:22:09 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:22:09 --> Database Driver Class Initialized
INFO - 2026-02-22 14:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:22:11 --> Upload Class Initialized
DEBUG - 2026-02-22 14:22:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:22:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:22:11 --> Encryption Class Initialized
INFO - 2026-02-22 14:22:11 --> Form Validation Class Initialized
INFO - 2026-02-22 14:22:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:22:11 --> Pagination Class Initialized
INFO - 2026-02-22 14:22:11 --> Email Class Initialized
INFO - 2026-02-22 14:22:11 --> Controller Class Initialized
DEBUG - 2026-02-22 14:22:11 --> Billing MX_Controller Initialized
INFO - 2026-02-22 14:22:11 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:22:11 --> Model "Auth_model" initialized
INFO - 2026-02-22 14:22:11 --> Model "Cart_model" initialized
INFO - 2026-02-22 14:22:11 --> Model "Billing_model" initialized
INFO - 2026-02-22 14:22:11 --> Model "Common_model" initialized
INFO - 2026-02-22 14:22:11 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-22 14:22:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_invoice_pdf_html.php
DEBUG - 2026-02-22 14:22:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-22 14:22:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-02-22 14:22:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-22 14:22:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-22 14:22:14 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_viewinvoice.php
INFO - 2026-02-22 14:22:14 --> Final output sent to browser
DEBUG - 2026-02-22 14:22:14 --> Total execution time: 4.5401
INFO - 2026-02-22 14:22:14 --> Config Class Initialized
INFO - 2026-02-22 14:22:14 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:22:14 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:22:14 --> Utf8 Class Initialized
INFO - 2026-02-22 14:22:14 --> URI Class Initialized
INFO - 2026-02-22 14:22:14 --> Router Class Initialized
INFO - 2026-02-22 14:22:14 --> Output Class Initialized
INFO - 2026-02-22 14:22:14 --> Security Class Initialized
DEBUG - 2026-02-22 14:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:22:14 --> CSRF cookie sent
INFO - 2026-02-22 14:22:14 --> Input Class Initialized
INFO - 2026-02-22 14:22:14 --> Language Class Initialized
INFO - 2026-02-22 14:22:14 --> Language Class Initialized
INFO - 2026-02-22 14:22:14 --> Config Class Initialized
INFO - 2026-02-22 14:22:14 --> Loader Class Initialized
INFO - 2026-02-22 14:22:14 --> Helper loaded: url_helper
INFO - 2026-02-22 14:22:14 --> Helper loaded: form_helper
INFO - 2026-02-22 14:22:14 --> Helper loaded: html_helper
INFO - 2026-02-22 14:22:14 --> Helper loaded: file_helper
INFO - 2026-02-22 14:22:14 --> Helper loaded: email_helper
INFO - 2026-02-22 14:22:14 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:22:14 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:22:14 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:22:14 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:22:14 --> Database Driver Class Initialized
INFO - 2026-02-22 14:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:22:16 --> Upload Class Initialized
DEBUG - 2026-02-22 14:22:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:22:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:22:16 --> Encryption Class Initialized
INFO - 2026-02-22 14:22:16 --> Form Validation Class Initialized
INFO - 2026-02-22 14:22:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:22:16 --> Pagination Class Initialized
INFO - 2026-02-22 14:22:16 --> Email Class Initialized
INFO - 2026-02-22 14:22:16 --> Controller Class Initialized
DEBUG - 2026-02-22 14:22:16 --> Cart MX_Controller Initialized
INFO - 2026-02-22 14:22:16 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:22:16 --> Model "Auth_model" initialized
INFO - 2026-02-22 14:22:16 --> Model "Cart_model" initialized
INFO - 2026-02-22 14:22:16 --> Model "Common_model" initialized
INFO - 2026-02-22 14:22:16 --> Model "Order_model" initialized
INFO - 2026-02-22 14:22:16 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 14:22:16 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-22 14:22:17 --> Final output sent to browser
DEBUG - 2026-02-22 14:22:17 --> Total execution time: 2.6532
INFO - 2026-02-22 14:24:19 --> Config Class Initialized
INFO - 2026-02-22 14:24:19 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:24:19 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:24:19 --> Utf8 Class Initialized
INFO - 2026-02-22 14:24:19 --> URI Class Initialized
INFO - 2026-02-22 14:24:19 --> Router Class Initialized
INFO - 2026-02-22 14:24:19 --> Output Class Initialized
INFO - 2026-02-22 14:24:19 --> Security Class Initialized
DEBUG - 2026-02-22 14:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:24:19 --> CSRF cookie sent
INFO - 2026-02-22 14:24:19 --> Input Class Initialized
INFO - 2026-02-22 14:24:19 --> Language Class Initialized
INFO - 2026-02-22 14:24:19 --> Language Class Initialized
INFO - 2026-02-22 14:24:19 --> Config Class Initialized
INFO - 2026-02-22 14:24:19 --> Loader Class Initialized
INFO - 2026-02-22 14:24:19 --> Helper loaded: url_helper
INFO - 2026-02-22 14:24:19 --> Helper loaded: form_helper
INFO - 2026-02-22 14:24:19 --> Helper loaded: html_helper
INFO - 2026-02-22 14:24:19 --> Helper loaded: file_helper
INFO - 2026-02-22 14:24:19 --> Helper loaded: email_helper
INFO - 2026-02-22 14:24:19 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:24:19 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:24:19 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:24:19 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:24:19 --> Database Driver Class Initialized
INFO - 2026-02-22 14:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:24:22 --> Upload Class Initialized
DEBUG - 2026-02-22 14:24:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:24:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:24:22 --> Encryption Class Initialized
INFO - 2026-02-22 14:24:22 --> Form Validation Class Initialized
INFO - 2026-02-22 14:24:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:24:22 --> Pagination Class Initialized
INFO - 2026-02-22 14:24:22 --> Email Class Initialized
INFO - 2026-02-22 14:24:22 --> Controller Class Initialized
DEBUG - 2026-02-22 14:24:22 --> Clientarea MX_Controller Initialized
INFO - 2026-02-22 14:24:22 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:24:22 --> Model "Auth_model" initialized
INFO - 2026-02-22 14:24:22 --> Model "Cart_model" initialized
INFO - 2026-02-22 14:24:22 --> Model "Clientarea_model" initialized
INFO - 2026-02-22 14:24:22 --> Model "Billing_model" initialized
INFO - 2026-02-22 14:24:22 --> Model "Common_model" initialized
INFO - 2026-02-22 14:24:22 --> Model "Order_model" initialized
INFO - 2026-02-22 14:24:22 --> Model "Support_model" initialized
DEBUG - 2026-02-22 14:24:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-22 14:24:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-02-22 14:24:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-22 14:24:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-22 14:24:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_services.php
INFO - 2026-02-22 14:24:23 --> Final output sent to browser
DEBUG - 2026-02-22 14:24:23 --> Total execution time: 3.3239
INFO - 2026-02-22 14:24:23 --> Config Class Initialized
INFO - 2026-02-22 14:24:23 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:24:23 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:24:23 --> Utf8 Class Initialized
INFO - 2026-02-22 14:24:23 --> URI Class Initialized
INFO - 2026-02-22 14:24:23 --> Router Class Initialized
INFO - 2026-02-22 14:24:23 --> Output Class Initialized
INFO - 2026-02-22 14:24:23 --> Security Class Initialized
DEBUG - 2026-02-22 14:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:24:23 --> CSRF cookie sent
INFO - 2026-02-22 14:24:23 --> Input Class Initialized
INFO - 2026-02-22 14:24:23 --> Language Class Initialized
INFO - 2026-02-22 14:24:23 --> Language Class Initialized
INFO - 2026-02-22 14:24:23 --> Config Class Initialized
INFO - 2026-02-22 14:24:23 --> Loader Class Initialized
INFO - 2026-02-22 14:24:23 --> Helper loaded: url_helper
INFO - 2026-02-22 14:24:23 --> Helper loaded: form_helper
INFO - 2026-02-22 14:24:23 --> Helper loaded: html_helper
INFO - 2026-02-22 14:24:23 --> Helper loaded: file_helper
INFO - 2026-02-22 14:24:23 --> Helper loaded: email_helper
INFO - 2026-02-22 14:24:23 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:24:23 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:24:23 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:24:23 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:24:23 --> Database Driver Class Initialized
INFO - 2026-02-22 14:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:24:25 --> Upload Class Initialized
DEBUG - 2026-02-22 14:24:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:24:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:24:25 --> Encryption Class Initialized
INFO - 2026-02-22 14:24:25 --> Form Validation Class Initialized
INFO - 2026-02-22 14:24:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:24:25 --> Pagination Class Initialized
INFO - 2026-02-22 14:24:25 --> Email Class Initialized
INFO - 2026-02-22 14:24:25 --> Controller Class Initialized
DEBUG - 2026-02-22 14:24:25 --> Cart MX_Controller Initialized
INFO - 2026-02-22 14:24:25 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:24:25 --> Model "Auth_model" initialized
INFO - 2026-02-22 14:24:25 --> Model "Cart_model" initialized
INFO - 2026-02-22 14:24:25 --> Model "Common_model" initialized
INFO - 2026-02-22 14:24:25 --> Model "Order_model" initialized
INFO - 2026-02-22 14:24:25 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 14:24:25 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-22 14:24:26 --> Final output sent to browser
DEBUG - 2026-02-22 14:24:26 --> Total execution time: 2.7332
INFO - 2026-02-22 14:24:27 --> Config Class Initialized
INFO - 2026-02-22 14:24:27 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:24:27 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:24:27 --> Utf8 Class Initialized
INFO - 2026-02-22 14:24:27 --> URI Class Initialized
INFO - 2026-02-22 14:24:27 --> Router Class Initialized
INFO - 2026-02-22 14:24:27 --> Output Class Initialized
INFO - 2026-02-22 14:24:27 --> Security Class Initialized
DEBUG - 2026-02-22 14:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:24:27 --> CSRF cookie sent
INFO - 2026-02-22 14:24:27 --> Input Class Initialized
INFO - 2026-02-22 14:24:27 --> Language Class Initialized
INFO - 2026-02-22 14:24:27 --> Language Class Initialized
INFO - 2026-02-22 14:24:27 --> Config Class Initialized
INFO - 2026-02-22 14:24:27 --> Loader Class Initialized
INFO - 2026-02-22 14:24:27 --> Helper loaded: url_helper
INFO - 2026-02-22 14:24:27 --> Helper loaded: form_helper
INFO - 2026-02-22 14:24:27 --> Helper loaded: html_helper
INFO - 2026-02-22 14:24:27 --> Helper loaded: file_helper
INFO - 2026-02-22 14:24:27 --> Helper loaded: email_helper
INFO - 2026-02-22 14:24:27 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:24:27 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:24:27 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:24:27 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:24:27 --> Database Driver Class Initialized
INFO - 2026-02-22 14:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:24:29 --> Upload Class Initialized
DEBUG - 2026-02-22 14:24:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:24:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:24:29 --> Encryption Class Initialized
INFO - 2026-02-22 14:24:29 --> Form Validation Class Initialized
INFO - 2026-02-22 14:24:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:24:29 --> Pagination Class Initialized
INFO - 2026-02-22 14:24:29 --> Email Class Initialized
INFO - 2026-02-22 14:24:29 --> Controller Class Initialized
DEBUG - 2026-02-22 14:24:29 --> Clientarea MX_Controller Initialized
INFO - 2026-02-22 14:24:29 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:24:29 --> Model "Auth_model" initialized
INFO - 2026-02-22 14:24:29 --> Model "Cart_model" initialized
INFO - 2026-02-22 14:24:29 --> Model "Clientarea_model" initialized
INFO - 2026-02-22 14:24:29 --> Model "Billing_model" initialized
INFO - 2026-02-22 14:24:29 --> Model "Common_model" initialized
INFO - 2026-02-22 14:24:29 --> Model "Order_model" initialized
INFO - 2026-02-22 14:24:29 --> Model "Support_model" initialized
DEBUG - 2026-02-22 14:24:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-02-22 14:24:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/service_nav.php
DEBUG - 2026-02-22 14:24:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-02-22 14:24:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-02-22 14:24:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_service_detail.php
INFO - 2026-02-22 14:24:31 --> Final output sent to browser
DEBUG - 2026-02-22 14:24:31 --> Total execution time: 3.6931
INFO - 2026-02-22 14:24:31 --> Config Class Initialized
INFO - 2026-02-22 14:24:31 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:24:31 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:24:31 --> Utf8 Class Initialized
INFO - 2026-02-22 14:24:31 --> URI Class Initialized
INFO - 2026-02-22 14:24:31 --> Router Class Initialized
INFO - 2026-02-22 14:24:31 --> Output Class Initialized
INFO - 2026-02-22 14:24:31 --> Security Class Initialized
DEBUG - 2026-02-22 14:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:24:31 --> CSRF cookie sent
INFO - 2026-02-22 14:24:31 --> Input Class Initialized
INFO - 2026-02-22 14:24:31 --> Language Class Initialized
INFO - 2026-02-22 14:24:31 --> Language Class Initialized
INFO - 2026-02-22 14:24:31 --> Config Class Initialized
INFO - 2026-02-22 14:24:31 --> Loader Class Initialized
INFO - 2026-02-22 14:24:31 --> Helper loaded: url_helper
INFO - 2026-02-22 14:24:31 --> Helper loaded: form_helper
INFO - 2026-02-22 14:24:31 --> Helper loaded: html_helper
INFO - 2026-02-22 14:24:31 --> Helper loaded: file_helper
INFO - 2026-02-22 14:24:31 --> Helper loaded: email_helper
INFO - 2026-02-22 14:24:31 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:24:31 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:24:31 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:24:31 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:24:31 --> Database Driver Class Initialized
INFO - 2026-02-22 14:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:24:33 --> Upload Class Initialized
DEBUG - 2026-02-22 14:24:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:24:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:24:33 --> Encryption Class Initialized
INFO - 2026-02-22 14:24:33 --> Form Validation Class Initialized
INFO - 2026-02-22 14:24:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:24:33 --> Pagination Class Initialized
INFO - 2026-02-22 14:24:33 --> Email Class Initialized
INFO - 2026-02-22 14:24:33 --> Controller Class Initialized
DEBUG - 2026-02-22 14:24:33 --> Cart MX_Controller Initialized
INFO - 2026-02-22 14:24:33 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:24:33 --> Model "Auth_model" initialized
INFO - 2026-02-22 14:24:33 --> Model "Cart_model" initialized
INFO - 2026-02-22 14:24:33 --> Model "Common_model" initialized
INFO - 2026-02-22 14:24:33 --> Model "Order_model" initialized
INFO - 2026-02-22 14:24:33 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 14:24:33 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-22 14:24:34 --> Final output sent to browser
DEBUG - 2026-02-22 14:24:34 --> Total execution time: 2.6463
INFO - 2026-02-22 14:24:37 --> Config Class Initialized
INFO - 2026-02-22 14:24:37 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:24:37 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:24:37 --> Utf8 Class Initialized
INFO - 2026-02-22 14:24:37 --> URI Class Initialized
INFO - 2026-02-22 14:24:37 --> Router Class Initialized
INFO - 2026-02-22 14:24:37 --> Output Class Initialized
INFO - 2026-02-22 14:24:37 --> Security Class Initialized
DEBUG - 2026-02-22 14:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:24:37 --> CSRF cookie sent
INFO - 2026-02-22 14:24:37 --> CSRF token verified
INFO - 2026-02-22 14:24:37 --> Input Class Initialized
INFO - 2026-02-22 14:24:37 --> Language Class Initialized
INFO - 2026-02-22 14:24:37 --> Language Class Initialized
INFO - 2026-02-22 14:24:37 --> Config Class Initialized
INFO - 2026-02-22 14:24:37 --> Loader Class Initialized
INFO - 2026-02-22 14:24:37 --> Helper loaded: url_helper
INFO - 2026-02-22 14:24:37 --> Helper loaded: form_helper
INFO - 2026-02-22 14:24:37 --> Helper loaded: html_helper
INFO - 2026-02-22 14:24:37 --> Helper loaded: file_helper
INFO - 2026-02-22 14:24:37 --> Helper loaded: email_helper
INFO - 2026-02-22 14:24:37 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:24:37 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:24:37 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:24:37 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:24:37 --> Database Driver Class Initialized
INFO - 2026-02-22 14:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:24:39 --> Upload Class Initialized
DEBUG - 2026-02-22 14:24:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:24:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:24:39 --> Encryption Class Initialized
INFO - 2026-02-22 14:24:39 --> Form Validation Class Initialized
INFO - 2026-02-22 14:24:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:24:39 --> Pagination Class Initialized
INFO - 2026-02-22 14:24:39 --> Email Class Initialized
INFO - 2026-02-22 14:24:39 --> Controller Class Initialized
DEBUG - 2026-02-22 14:24:39 --> Clientarea MX_Controller Initialized
INFO - 2026-02-22 14:24:39 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:24:39 --> Model "Auth_model" initialized
INFO - 2026-02-22 14:24:39 --> Model "Cart_model" initialized
INFO - 2026-02-22 14:24:39 --> Model "Clientarea_model" initialized
INFO - 2026-02-22 14:24:39 --> Model "Billing_model" initialized
INFO - 2026-02-22 14:24:39 --> Model "Common_model" initialized
INFO - 2026-02-22 14:24:39 --> Model "Order_model" initialized
INFO - 2026-02-22 14:24:39 --> Model "Support_model" initialized
DEBUG - 2026-02-22 14:24:47 --> WHM API2 Response for Email::listpops: {"cpanelresult":{"postevent":{"result":1},"apiversion":2,"module":"Email","event":{"result":1},"preevent":{"result":1},"data":[{"suspended_incoming":0,"suspended_login":0,"login":"Main Account","email":"narike8u"}],"func":"listpops"}}

DEBUG - 2026-02-22 14:24:50 --> WHM API2 Response for MysqlFE::listdbs: {"cpanelresult":{"func":"listdbs","event":{"result":1},"apiversion":2,"data":[],"preevent":{"result":1},"module":"MysqlFE","postevent":{"result":1}}}

DEBUG - 2026-02-22 14:24:52 --> WHM API2 Response for AddonDomain::listaddondomains: {"cpanelresult":{"apiversion":2,"event":{"result":1},"func":"listaddondomains","postevent":{"result":1},"module":"AddonDomain","preevent":{"result":1},"data":[]}}

DEBUG - 2026-02-22 14:24:54 --> WHM API2 Response for SubDomain::listsubdomains: {"cpanelresult":{"func":"listsubdomains","event":{"result":1},"apiversion":2,"data":[],"preevent":{"result":1},"module":"SubDomain","postevent":{"result":1}}}

INFO - 2026-02-22 14:24:54 --> Final output sent to browser
DEBUG - 2026-02-22 14:24:54 --> Total execution time: 16.5126
INFO - 2026-02-22 14:27:45 --> Config Class Initialized
INFO - 2026-02-22 14:27:45 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:27:45 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:27:45 --> Utf8 Class Initialized
INFO - 2026-02-22 14:27:45 --> URI Class Initialized
INFO - 2026-02-22 14:27:45 --> Router Class Initialized
INFO - 2026-02-22 14:27:45 --> Output Class Initialized
INFO - 2026-02-22 14:27:45 --> Security Class Initialized
DEBUG - 2026-02-22 14:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:27:45 --> CSRF cookie sent
INFO - 2026-02-22 14:27:45 --> Input Class Initialized
INFO - 2026-02-22 14:27:45 --> Language Class Initialized
INFO - 2026-02-22 14:27:45 --> Language Class Initialized
INFO - 2026-02-22 14:27:45 --> Config Class Initialized
INFO - 2026-02-22 14:27:45 --> Loader Class Initialized
INFO - 2026-02-22 14:27:45 --> Helper loaded: url_helper
INFO - 2026-02-22 14:27:45 --> Helper loaded: form_helper
INFO - 2026-02-22 14:27:45 --> Helper loaded: html_helper
INFO - 2026-02-22 14:27:45 --> Helper loaded: file_helper
INFO - 2026-02-22 14:27:45 --> Helper loaded: email_helper
INFO - 2026-02-22 14:27:45 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:27:45 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:27:45 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:27:45 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:27:45 --> Database Driver Class Initialized
INFO - 2026-02-22 14:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:27:48 --> Upload Class Initialized
DEBUG - 2026-02-22 14:27:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:27:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:27:48 --> Encryption Class Initialized
INFO - 2026-02-22 14:27:48 --> Form Validation Class Initialized
INFO - 2026-02-22 14:27:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:27:48 --> Pagination Class Initialized
INFO - 2026-02-22 14:27:48 --> Email Class Initialized
INFO - 2026-02-22 14:27:48 --> Controller Class Initialized
DEBUG - 2026-02-22 14:27:48 --> Package MX_Controller Initialized
INFO - 2026-02-22 14:27:48 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:27:48 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:27:48 --> Model "Package_model" initialized
INFO - 2026-02-22 14:27:48 --> Model "Common_model" initialized
DEBUG - 2026-02-22 14:27:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:27:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:27:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:27:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:27:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:27:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/package_list.php
INFO - 2026-02-22 14:27:49 --> Final output sent to browser
DEBUG - 2026-02-22 14:27:49 --> Total execution time: 3.6606
INFO - 2026-02-22 14:27:49 --> Config Class Initialized
INFO - 2026-02-22 14:27:49 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:27:49 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:27:49 --> Utf8 Class Initialized
INFO - 2026-02-22 14:27:49 --> URI Class Initialized
INFO - 2026-02-22 14:27:49 --> Router Class Initialized
INFO - 2026-02-22 14:27:49 --> Output Class Initialized
INFO - 2026-02-22 14:27:49 --> Security Class Initialized
DEBUG - 2026-02-22 14:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:27:49 --> CSRF cookie sent
INFO - 2026-02-22 14:27:49 --> Input Class Initialized
INFO - 2026-02-22 14:27:49 --> Language Class Initialized
INFO - 2026-02-22 14:27:49 --> Language Class Initialized
INFO - 2026-02-22 14:27:49 --> Config Class Initialized
INFO - 2026-02-22 14:27:49 --> Loader Class Initialized
INFO - 2026-02-22 14:27:49 --> Helper loaded: url_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: form_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: html_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: file_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: email_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:27:49 --> Database Driver Class Initialized
INFO - 2026-02-22 14:27:49 --> Config Class Initialized
INFO - 2026-02-22 14:27:49 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:27:49 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:27:49 --> Utf8 Class Initialized
INFO - 2026-02-22 14:27:49 --> URI Class Initialized
INFO - 2026-02-22 14:27:49 --> Router Class Initialized
INFO - 2026-02-22 14:27:49 --> Output Class Initialized
INFO - 2026-02-22 14:27:49 --> Security Class Initialized
DEBUG - 2026-02-22 14:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:27:49 --> CSRF cookie sent
INFO - 2026-02-22 14:27:49 --> Input Class Initialized
INFO - 2026-02-22 14:27:49 --> Language Class Initialized
INFO - 2026-02-22 14:27:49 --> Language Class Initialized
INFO - 2026-02-22 14:27:49 --> Config Class Initialized
INFO - 2026-02-22 14:27:49 --> Loader Class Initialized
INFO - 2026-02-22 14:27:49 --> Helper loaded: url_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: form_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: html_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: file_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: email_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:27:49 --> Database Driver Class Initialized
INFO - 2026-02-22 14:27:49 --> Config Class Initialized
INFO - 2026-02-22 14:27:49 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:27:49 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:27:49 --> Utf8 Class Initialized
INFO - 2026-02-22 14:27:49 --> URI Class Initialized
INFO - 2026-02-22 14:27:49 --> Router Class Initialized
INFO - 2026-02-22 14:27:49 --> Output Class Initialized
INFO - 2026-02-22 14:27:49 --> Security Class Initialized
INFO - 2026-02-22 14:27:49 --> Config Class Initialized
INFO - 2026-02-22 14:27:49 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:27:49 --> CSRF cookie sent
INFO - 2026-02-22 14:27:49 --> Input Class Initialized
INFO - 2026-02-22 14:27:49 --> Language Class Initialized
DEBUG - 2026-02-22 14:27:49 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:27:49 --> Utf8 Class Initialized
INFO - 2026-02-22 14:27:49 --> URI Class Initialized
INFO - 2026-02-22 14:27:49 --> Language Class Initialized
INFO - 2026-02-22 14:27:49 --> Config Class Initialized
INFO - 2026-02-22 14:27:49 --> Router Class Initialized
INFO - 2026-02-22 14:27:49 --> Config Class Initialized
INFO - 2026-02-22 14:27:49 --> Hooks Class Initialized
INFO - 2026-02-22 14:27:49 --> Output Class Initialized
INFO - 2026-02-22 14:27:49 --> Loader Class Initialized
DEBUG - 2026-02-22 14:27:49 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:27:49 --> Utf8 Class Initialized
INFO - 2026-02-22 14:27:49 --> URI Class Initialized
INFO - 2026-02-22 14:27:49 --> Helper loaded: url_helper
INFO - 2026-02-22 14:27:49 --> Security Class Initialized
INFO - 2026-02-22 14:27:49 --> Helper loaded: form_helper
DEBUG - 2026-02-22 14:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:27:49 --> CSRF cookie sent
INFO - 2026-02-22 14:27:49 --> Input Class Initialized
INFO - 2026-02-22 14:27:49 --> Language Class Initialized
INFO - 2026-02-22 14:27:49 --> Helper loaded: html_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: file_helper
INFO - 2026-02-22 14:27:49 --> Config Class Initialized
INFO - 2026-02-22 14:27:49 --> Hooks Class Initialized
INFO - 2026-02-22 14:27:49 --> Helper loaded: email_helper
INFO - 2026-02-22 14:27:49 --> Language Class Initialized
INFO - 2026-02-22 14:27:49 --> Config Class Initialized
DEBUG - 2026-02-22 14:27:49 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:27:49 --> Utf8 Class Initialized
INFO - 2026-02-22 14:27:49 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:27:49 --> URI Class Initialized
INFO - 2026-02-22 14:27:49 --> Loader Class Initialized
INFO - 2026-02-22 14:27:49 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: url_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: form_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: html_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: file_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: email_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:27:49 --> Router Class Initialized
INFO - 2026-02-22 14:27:49 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:27:49 --> Output Class Initialized
INFO - 2026-02-22 14:27:49 --> Database Driver Class Initialized
INFO - 2026-02-22 14:27:49 --> Router Class Initialized
INFO - 2026-02-22 14:27:49 --> Output Class Initialized
INFO - 2026-02-22 14:27:49 --> Database Driver Class Initialized
INFO - 2026-02-22 14:27:49 --> Security Class Initialized
DEBUG - 2026-02-22 14:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:27:49 --> CSRF cookie sent
INFO - 2026-02-22 14:27:49 --> Input Class Initialized
INFO - 2026-02-22 14:27:49 --> Language Class Initialized
INFO - 2026-02-22 14:27:49 --> Language Class Initialized
INFO - 2026-02-22 14:27:49 --> Config Class Initialized
INFO - 2026-02-22 14:27:49 --> Security Class Initialized
DEBUG - 2026-02-22 14:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:27:49 --> CSRF cookie sent
INFO - 2026-02-22 14:27:49 --> Input Class Initialized
INFO - 2026-02-22 14:27:49 --> Language Class Initialized
INFO - 2026-02-22 14:27:49 --> Language Class Initialized
INFO - 2026-02-22 14:27:49 --> Config Class Initialized
INFO - 2026-02-22 14:27:49 --> Loader Class Initialized
INFO - 2026-02-22 14:27:49 --> Helper loaded: url_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: form_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: html_helper
INFO - 2026-02-22 14:27:49 --> Loader Class Initialized
INFO - 2026-02-22 14:27:49 --> Helper loaded: file_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: email_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: url_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: form_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: html_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: file_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: email_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:27:49 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:27:49 --> Database Driver Class Initialized
INFO - 2026-02-22 14:27:49 --> Database Driver Class Initialized
INFO - 2026-02-22 14:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:27:53 --> Upload Class Initialized
DEBUG - 2026-02-22 14:27:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:27:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:27:53 --> Encryption Class Initialized
INFO - 2026-02-22 14:27:53 --> Form Validation Class Initialized
INFO - 2026-02-22 14:27:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:27:53 --> Pagination Class Initialized
INFO - 2026-02-22 14:27:53 --> Email Class Initialized
INFO - 2026-02-22 14:27:53 --> Controller Class Initialized
ERROR - 2026-02-22 14:27:53 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:27:53 --> Upload Class Initialized
DEBUG - 2026-02-22 14:27:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:27:53 --> Config Class Initialized
INFO - 2026-02-22 14:27:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:27:53 --> Hooks Class Initialized
INFO - 2026-02-22 14:27:53 --> Encryption Class Initialized
INFO - 2026-02-22 14:27:53 --> Form Validation Class Initialized
DEBUG - 2026-02-22 14:27:53 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:27:53 --> Utf8 Class Initialized
INFO - 2026-02-22 14:27:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:27:53 --> Pagination Class Initialized
INFO - 2026-02-22 14:27:53 --> URI Class Initialized
INFO - 2026-02-22 14:27:53 --> Email Class Initialized
INFO - 2026-02-22 14:27:53 --> Controller Class Initialized
ERROR - 2026-02-22 14:27:53 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:27:53 --> Router Class Initialized
INFO - 2026-02-22 14:27:53 --> Output Class Initialized
INFO - 2026-02-22 14:27:53 --> Security Class Initialized
DEBUG - 2026-02-22 14:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:27:53 --> CSRF cookie sent
INFO - 2026-02-22 14:27:53 --> Input Class Initialized
INFO - 2026-02-22 14:27:53 --> Language Class Initialized
INFO - 2026-02-22 14:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:27:53 --> Language Class Initialized
INFO - 2026-02-22 14:27:53 --> Config Class Initialized
INFO - 2026-02-22 14:27:53 --> Upload Class Initialized
INFO - 2026-02-22 14:27:53 --> Config Class Initialized
INFO - 2026-02-22 14:27:53 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:27:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:27:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:27:53 --> Encryption Class Initialized
INFO - 2026-02-22 14:27:53 --> Loader Class Initialized
DEBUG - 2026-02-22 14:27:53 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:27:53 --> Utf8 Class Initialized
INFO - 2026-02-22 14:27:53 --> URI Class Initialized
INFO - 2026-02-22 14:27:53 --> Helper loaded: url_helper
INFO - 2026-02-22 14:27:53 --> Form Validation Class Initialized
INFO - 2026-02-22 14:27:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:27:53 --> Pagination Class Initialized
INFO - 2026-02-22 14:27:53 --> Router Class Initialized
INFO - 2026-02-22 14:27:53 --> Helper loaded: form_helper
INFO - 2026-02-22 14:27:53 --> Helper loaded: html_helper
INFO - 2026-02-22 14:27:53 --> Output Class Initialized
INFO - 2026-02-22 14:27:53 --> Helper loaded: file_helper
INFO - 2026-02-22 14:27:53 --> Helper loaded: email_helper
INFO - 2026-02-22 14:27:53 --> Security Class Initialized
INFO - 2026-02-22 14:27:53 --> Email Class Initialized
INFO - 2026-02-22 14:27:53 --> Controller Class Initialized
ERROR - 2026-02-22 14:27:53 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:27:53 --> Helper loaded: whmaz_helper
DEBUG - 2026-02-22 14:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:27:53 --> CSRF cookie sent
INFO - 2026-02-22 14:27:53 --> Input Class Initialized
INFO - 2026-02-22 14:27:53 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:27:53 --> Language Class Initialized
INFO - 2026-02-22 14:27:53 --> Language Class Initialized
INFO - 2026-02-22 14:27:53 --> Config Class Initialized
INFO - 2026-02-22 14:27:53 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:27:53 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:27:53 --> Loader Class Initialized
INFO - 2026-02-22 14:27:53 --> Helper loaded: url_helper
INFO - 2026-02-22 14:27:53 --> Helper loaded: form_helper
INFO - 2026-02-22 14:27:53 --> Helper loaded: html_helper
INFO - 2026-02-22 14:27:53 --> Helper loaded: file_helper
INFO - 2026-02-22 14:27:53 --> Helper loaded: email_helper
INFO - 2026-02-22 14:27:53 --> Config Class Initialized
INFO - 2026-02-22 14:27:53 --> Hooks Class Initialized
INFO - 2026-02-22 14:27:53 --> Database Driver Class Initialized
INFO - 2026-02-22 14:27:53 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:27:53 --> Helper loaded: ssp_helper
DEBUG - 2026-02-22 14:27:53 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:27:53 --> Utf8 Class Initialized
INFO - 2026-02-22 14:27:53 --> URI Class Initialized
INFO - 2026-02-22 14:27:53 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:27:53 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:27:53 --> Router Class Initialized
INFO - 2026-02-22 14:27:53 --> Output Class Initialized
INFO - 2026-02-22 14:27:53 --> Security Class Initialized
DEBUG - 2026-02-22 14:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:27:53 --> CSRF cookie sent
INFO - 2026-02-22 14:27:53 --> Input Class Initialized
INFO - 2026-02-22 14:27:53 --> Language Class Initialized
INFO - 2026-02-22 14:27:53 --> Language Class Initialized
INFO - 2026-02-22 14:27:53 --> Config Class Initialized
INFO - 2026-02-22 14:27:53 --> Database Driver Class Initialized
INFO - 2026-02-22 14:27:53 --> Loader Class Initialized
INFO - 2026-02-22 14:27:53 --> Helper loaded: url_helper
INFO - 2026-02-22 14:27:53 --> Helper loaded: form_helper
INFO - 2026-02-22 14:27:53 --> Helper loaded: html_helper
INFO - 2026-02-22 14:27:53 --> Helper loaded: file_helper
INFO - 2026-02-22 14:27:53 --> Helper loaded: email_helper
INFO - 2026-02-22 14:27:53 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:27:53 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:27:53 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:27:53 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:27:53 --> Database Driver Class Initialized
INFO - 2026-02-22 14:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:27:54 --> Upload Class Initialized
DEBUG - 2026-02-22 14:27:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:27:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:27:54 --> Encryption Class Initialized
INFO - 2026-02-22 14:27:54 --> Form Validation Class Initialized
INFO - 2026-02-22 14:27:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:27:54 --> Pagination Class Initialized
INFO - 2026-02-22 14:27:54 --> Email Class Initialized
INFO - 2026-02-22 14:27:54 --> Controller Class Initialized
ERROR - 2026-02-22 14:27:54 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:27:54 --> Upload Class Initialized
DEBUG - 2026-02-22 14:27:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:27:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:27:54 --> Encryption Class Initialized
INFO - 2026-02-22 14:27:54 --> Form Validation Class Initialized
INFO - 2026-02-22 14:27:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:27:54 --> Pagination Class Initialized
INFO - 2026-02-22 14:27:54 --> Config Class Initialized
INFO - 2026-02-22 14:27:54 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:27:54 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:27:54 --> Email Class Initialized
INFO - 2026-02-22 14:27:54 --> Utf8 Class Initialized
INFO - 2026-02-22 14:27:54 --> Controller Class Initialized
ERROR - 2026-02-22 14:27:54 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:27:54 --> URI Class Initialized
INFO - 2026-02-22 14:27:54 --> Router Class Initialized
INFO - 2026-02-22 14:27:54 --> Output Class Initialized
INFO - 2026-02-22 14:27:54 --> Security Class Initialized
DEBUG - 2026-02-22 14:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:27:54 --> CSRF cookie sent
INFO - 2026-02-22 14:27:54 --> Input Class Initialized
INFO - 2026-02-22 14:27:54 --> Language Class Initialized
INFO - 2026-02-22 14:27:54 --> Language Class Initialized
INFO - 2026-02-22 14:27:54 --> Config Class Initialized
INFO - 2026-02-22 14:27:54 --> Loader Class Initialized
INFO - 2026-02-22 14:27:54 --> Helper loaded: url_helper
INFO - 2026-02-22 14:27:54 --> Helper loaded: form_helper
INFO - 2026-02-22 14:27:54 --> Helper loaded: html_helper
INFO - 2026-02-22 14:27:54 --> Helper loaded: file_helper
INFO - 2026-02-22 14:27:54 --> Helper loaded: email_helper
INFO - 2026-02-22 14:27:54 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:27:54 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:27:54 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:27:54 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:27:54 --> Database Driver Class Initialized
INFO - 2026-02-22 14:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:27:56 --> Upload Class Initialized
DEBUG - 2026-02-22 14:27:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:27:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:27:56 --> Encryption Class Initialized
INFO - 2026-02-22 14:27:56 --> Form Validation Class Initialized
INFO - 2026-02-22 14:27:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:27:56 --> Pagination Class Initialized
INFO - 2026-02-22 14:27:56 --> Email Class Initialized
INFO - 2026-02-22 14:27:56 --> Controller Class Initialized
DEBUG - 2026-02-22 14:27:56 --> Clientarea MX_Controller Initialized
INFO - 2026-02-22 14:27:56 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:27:56 --> Model "Auth_model" initialized
INFO - 2026-02-22 14:27:56 --> Model "Cart_model" initialized
INFO - 2026-02-22 14:27:56 --> Model "Clientarea_model" initialized
INFO - 2026-02-22 14:27:56 --> Model "Billing_model" initialized
INFO - 2026-02-22 14:27:56 --> Model "Common_model" initialized
INFO - 2026-02-22 14:27:56 --> Model "Order_model" initialized
INFO - 2026-02-22 14:27:56 --> Model "Support_model" initialized
INFO - 2026-02-22 14:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:28:25 --> Upload Class Initialized
DEBUG - 2026-02-22 14:28:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:28:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:28:25 --> Encryption Class Initialized
INFO - 2026-02-22 14:28:25 --> Form Validation Class Initialized
INFO - 2026-02-22 14:28:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:28:25 --> Pagination Class Initialized
INFO - 2026-02-22 14:28:25 --> Email Class Initialized
INFO - 2026-02-22 14:28:25 --> Controller Class Initialized
DEBUG - 2026-02-22 14:28:25 --> Package MX_Controller Initialized
INFO - 2026-02-22 14:28:25 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:28:25 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:28:25 --> Model "Package_model" initialized
INFO - 2026-02-22 14:28:25 --> Model "Common_model" initialized
INFO - 2026-02-22 14:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:28:28 --> Upload Class Initialized
DEBUG - 2026-02-22 14:28:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:28:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:28:28 --> Encryption Class Initialized
INFO - 2026-02-22 14:28:28 --> Form Validation Class Initialized
INFO - 2026-02-22 14:28:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:28:28 --> Pagination Class Initialized
INFO - 2026-02-22 14:28:29 --> Email Class Initialized
INFO - 2026-02-22 14:28:29 --> Controller Class Initialized
ERROR - 2026-02-22 14:28:29 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:28:29 --> Upload Class Initialized
DEBUG - 2026-02-22 14:28:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:28:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:28:29 --> Encryption Class Initialized
INFO - 2026-02-22 14:28:29 --> Form Validation Class Initialized
INFO - 2026-02-22 14:28:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:28:29 --> Pagination Class Initialized
INFO - 2026-02-22 14:28:29 --> Email Class Initialized
INFO - 2026-02-22 14:28:29 --> Controller Class Initialized
ERROR - 2026-02-22 14:28:29 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:28:29 --> Upload Class Initialized
DEBUG - 2026-02-22 14:28:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:28:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:28:29 --> Encryption Class Initialized
INFO - 2026-02-22 14:28:29 --> Form Validation Class Initialized
INFO - 2026-02-22 14:28:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:28:29 --> Pagination Class Initialized
INFO - 2026-02-22 14:28:29 --> Email Class Initialized
INFO - 2026-02-22 14:28:29 --> Controller Class Initialized
ERROR - 2026-02-22 14:28:29 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:30:21 --> Config Class Initialized
INFO - 2026-02-22 14:30:21 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:30:21 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:30:21 --> Utf8 Class Initialized
INFO - 2026-02-22 14:30:21 --> URI Class Initialized
INFO - 2026-02-22 14:30:21 --> Config Class Initialized
INFO - 2026-02-22 14:30:21 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:30:21 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:30:21 --> Utf8 Class Initialized
INFO - 2026-02-22 14:30:21 --> Router Class Initialized
INFO - 2026-02-22 14:30:21 --> URI Class Initialized
INFO - 2026-02-22 14:30:21 --> Config Class Initialized
INFO - 2026-02-22 14:30:21 --> Hooks Class Initialized
INFO - 2026-02-22 14:30:21 --> Router Class Initialized
DEBUG - 2026-02-22 14:30:21 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:30:21 --> Utf8 Class Initialized
INFO - 2026-02-22 14:30:21 --> URI Class Initialized
INFO - 2026-02-22 14:30:21 --> Output Class Initialized
INFO - 2026-02-22 14:30:21 --> Config Class Initialized
INFO - 2026-02-22 14:30:21 --> Hooks Class Initialized
INFO - 2026-02-22 14:30:21 --> Security Class Initialized
INFO - 2026-02-22 14:30:21 --> Router Class Initialized
DEBUG - 2026-02-22 14:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:30:21 --> CSRF cookie sent
INFO - 2026-02-22 14:30:21 --> Input Class Initialized
DEBUG - 2026-02-22 14:30:21 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:30:21 --> Utf8 Class Initialized
INFO - 2026-02-22 14:30:21 --> Language Class Initialized
INFO - 2026-02-22 14:30:21 --> Output Class Initialized
INFO - 2026-02-22 14:30:21 --> URI Class Initialized
INFO - 2026-02-22 14:30:21 --> Language Class Initialized
INFO - 2026-02-22 14:30:21 --> Config Class Initialized
INFO - 2026-02-22 14:30:21 --> Security Class Initialized
INFO - 2026-02-22 14:30:21 --> Router Class Initialized
DEBUG - 2026-02-22 14:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:30:21 --> CSRF cookie sent
INFO - 2026-02-22 14:30:21 --> Input Class Initialized
INFO - 2026-02-22 14:30:21 --> Language Class Initialized
INFO - 2026-02-22 14:30:21 --> Loader Class Initialized
INFO - 2026-02-22 14:30:21 --> Output Class Initialized
INFO - 2026-02-22 14:30:21 --> Language Class Initialized
INFO - 2026-02-22 14:30:21 --> Config Class Initialized
INFO - 2026-02-22 14:30:21 --> Config Class Initialized
INFO - 2026-02-22 14:30:21 --> Hooks Class Initialized
INFO - 2026-02-22 14:30:21 --> Helper loaded: url_helper
INFO - 2026-02-22 14:30:21 --> Security Class Initialized
DEBUG - 2026-02-22 14:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:30:21 --> Helper loaded: form_helper
INFO - 2026-02-22 14:30:21 --> CSRF cookie sent
INFO - 2026-02-22 14:30:21 --> Input Class Initialized
DEBUG - 2026-02-22 14:30:21 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:30:21 --> Utf8 Class Initialized
INFO - 2026-02-22 14:30:21 --> Language Class Initialized
INFO - 2026-02-22 14:30:21 --> Output Class Initialized
INFO - 2026-02-22 14:30:21 --> Helper loaded: html_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: file_helper
INFO - 2026-02-22 14:30:21 --> URI Class Initialized
INFO - 2026-02-22 14:30:21 --> Helper loaded: email_helper
INFO - 2026-02-22 14:30:21 --> Language Class Initialized
INFO - 2026-02-22 14:30:21 --> Config Class Initialized
INFO - 2026-02-22 14:30:21 --> Security Class Initialized
INFO - 2026-02-22 14:30:21 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: ssp_helper
DEBUG - 2026-02-22 14:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:30:21 --> Loader Class Initialized
INFO - 2026-02-22 14:30:21 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: url_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: form_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: html_helper
INFO - 2026-02-22 14:30:21 --> Router Class Initialized
INFO - 2026-02-22 14:30:21 --> Helper loaded: file_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: email_helper
INFO - 2026-02-22 14:30:21 --> CSRF cookie sent
INFO - 2026-02-22 14:30:21 --> Input Class Initialized
INFO - 2026-02-22 14:30:21 --> Language Class Initialized
INFO - 2026-02-22 14:30:21 --> Output Class Initialized
INFO - 2026-02-22 14:30:21 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:30:21 --> Language Class Initialized
INFO - 2026-02-22 14:30:21 --> Config Class Initialized
INFO - 2026-02-22 14:30:21 --> Security Class Initialized
INFO - 2026-02-22 14:30:21 --> Helper loaded: cpanel_helper
DEBUG - 2026-02-22 14:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:30:21 --> CSRF cookie sent
INFO - 2026-02-22 14:30:21 --> Input Class Initialized
INFO - 2026-02-22 14:30:21 --> Language Class Initialized
INFO - 2026-02-22 14:30:21 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:30:21 --> Loader Class Initialized
INFO - 2026-02-22 14:30:21 --> Language Class Initialized
INFO - 2026-02-22 14:30:21 --> Config Class Initialized
INFO - 2026-02-22 14:30:21 --> Helper loaded: url_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: form_helper
INFO - 2026-02-22 14:30:21 --> Config Class Initialized
INFO - 2026-02-22 14:30:21 --> Hooks Class Initialized
INFO - 2026-02-22 14:30:21 --> Loader Class Initialized
DEBUG - 2026-02-22 14:30:21 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:30:21 --> Utf8 Class Initialized
INFO - 2026-02-22 14:30:21 --> URI Class Initialized
INFO - 2026-02-22 14:30:21 --> Helper loaded: url_helper
INFO - 2026-02-22 14:30:21 --> Database Driver Class Initialized
INFO - 2026-02-22 14:30:21 --> Helper loaded: form_helper
INFO - 2026-02-22 14:30:21 --> Router Class Initialized
INFO - 2026-02-22 14:30:21 --> Helper loaded: html_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: file_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: email_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:30:21 --> Loader Class Initialized
INFO - 2026-02-22 14:30:21 --> Helper loaded: url_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: form_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: html_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: file_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: email_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: html_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: file_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: email_helper
INFO - 2026-02-22 14:30:21 --> Output Class Initialized
INFO - 2026-02-22 14:30:21 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:30:21 --> Security Class Initialized
INFO - 2026-02-22 14:30:21 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:30:21 --> Database Driver Class Initialized
DEBUG - 2026-02-22 14:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:30:21 --> CSRF cookie sent
INFO - 2026-02-22 14:30:21 --> Input Class Initialized
INFO - 2026-02-22 14:30:21 --> Language Class Initialized
INFO - 2026-02-22 14:30:21 --> Database Driver Class Initialized
INFO - 2026-02-22 14:30:21 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:30:21 --> Language Class Initialized
INFO - 2026-02-22 14:30:21 --> Config Class Initialized
INFO - 2026-02-22 14:30:21 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:30:21 --> Database Driver Class Initialized
INFO - 2026-02-22 14:30:21 --> Loader Class Initialized
INFO - 2026-02-22 14:30:21 --> Helper loaded: url_helper
INFO - 2026-02-22 14:30:21 --> Database Driver Class Initialized
INFO - 2026-02-22 14:30:21 --> Helper loaded: form_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: html_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: file_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: email_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:30:21 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:30:21 --> Database Driver Class Initialized
INFO - 2026-02-22 14:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:30:23 --> Upload Class Initialized
DEBUG - 2026-02-22 14:30:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:30:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:30:23 --> Encryption Class Initialized
INFO - 2026-02-22 14:30:23 --> Form Validation Class Initialized
INFO - 2026-02-22 14:30:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:30:23 --> Pagination Class Initialized
INFO - 2026-02-22 14:30:23 --> Email Class Initialized
INFO - 2026-02-22 14:30:23 --> Controller Class Initialized
ERROR - 2026-02-22 14:30:23 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:30:23 --> Upload Class Initialized
DEBUG - 2026-02-22 14:30:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:30:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:30:23 --> Encryption Class Initialized
INFO - 2026-02-22 14:30:23 --> Form Validation Class Initialized
INFO - 2026-02-22 14:30:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:30:23 --> Pagination Class Initialized
INFO - 2026-02-22 14:30:23 --> Config Class Initialized
INFO - 2026-02-22 14:30:23 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:30:23 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:30:23 --> Utf8 Class Initialized
INFO - 2026-02-22 14:30:23 --> URI Class Initialized
INFO - 2026-02-22 14:30:23 --> Email Class Initialized
INFO - 2026-02-22 14:30:23 --> Controller Class Initialized
ERROR - 2026-02-22 14:30:23 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:30:23 --> Router Class Initialized
INFO - 2026-02-22 14:30:23 --> Output Class Initialized
INFO - 2026-02-22 14:30:23 --> Security Class Initialized
DEBUG - 2026-02-22 14:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:30:23 --> CSRF cookie sent
INFO - 2026-02-22 14:30:23 --> Input Class Initialized
INFO - 2026-02-22 14:30:23 --> Language Class Initialized
INFO - 2026-02-22 14:30:23 --> Language Class Initialized
INFO - 2026-02-22 14:30:23 --> Config Class Initialized
INFO - 2026-02-22 14:30:23 --> Loader Class Initialized
INFO - 2026-02-22 14:30:23 --> Config Class Initialized
INFO - 2026-02-22 14:30:23 --> Hooks Class Initialized
INFO - 2026-02-22 14:30:23 --> Helper loaded: url_helper
DEBUG - 2026-02-22 14:30:23 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:30:23 --> Utf8 Class Initialized
INFO - 2026-02-22 14:30:23 --> URI Class Initialized
INFO - 2026-02-22 14:30:23 --> Helper loaded: form_helper
INFO - 2026-02-22 14:30:23 --> Helper loaded: html_helper
INFO - 2026-02-22 14:30:23 --> Router Class Initialized
INFO - 2026-02-22 14:30:23 --> Helper loaded: file_helper
INFO - 2026-02-22 14:30:23 --> Helper loaded: email_helper
INFO - 2026-02-22 14:30:23 --> Output Class Initialized
INFO - 2026-02-22 14:30:23 --> Security Class Initialized
INFO - 2026-02-22 14:30:23 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:30:23 --> Helper loaded: ssp_helper
DEBUG - 2026-02-22 14:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:30:23 --> CSRF cookie sent
INFO - 2026-02-22 14:30:23 --> Input Class Initialized
INFO - 2026-02-22 14:30:23 --> Language Class Initialized
INFO - 2026-02-22 14:30:23 --> Language Class Initialized
INFO - 2026-02-22 14:30:23 --> Config Class Initialized
INFO - 2026-02-22 14:30:23 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:30:23 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:30:23 --> Loader Class Initialized
INFO - 2026-02-22 14:30:23 --> Helper loaded: url_helper
INFO - 2026-02-22 14:30:23 --> Helper loaded: form_helper
INFO - 2026-02-22 14:30:23 --> Helper loaded: html_helper
INFO - 2026-02-22 14:30:23 --> Database Driver Class Initialized
INFO - 2026-02-22 14:30:23 --> Helper loaded: file_helper
INFO - 2026-02-22 14:30:23 --> Helper loaded: email_helper
INFO - 2026-02-22 14:30:23 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:30:23 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:30:23 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:30:23 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:30:23 --> Database Driver Class Initialized
INFO - 2026-02-22 14:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:30:23 --> Upload Class Initialized
DEBUG - 2026-02-22 14:30:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:30:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:30:23 --> Encryption Class Initialized
INFO - 2026-02-22 14:30:23 --> Form Validation Class Initialized
INFO - 2026-02-22 14:30:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:30:23 --> Pagination Class Initialized
INFO - 2026-02-22 14:30:23 --> Email Class Initialized
INFO - 2026-02-22 14:30:23 --> Controller Class Initialized
ERROR - 2026-02-22 14:30:23 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:30:24 --> Upload Class Initialized
DEBUG - 2026-02-22 14:30:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:30:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:30:24 --> Encryption Class Initialized
INFO - 2026-02-22 14:30:24 --> Form Validation Class Initialized
INFO - 2026-02-22 14:30:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:30:24 --> Pagination Class Initialized
INFO - 2026-02-22 14:30:24 --> Email Class Initialized
INFO - 2026-02-22 14:30:24 --> Controller Class Initialized
ERROR - 2026-02-22 14:30:24 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:30:24 --> Upload Class Initialized
DEBUG - 2026-02-22 14:30:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:30:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:30:24 --> Encryption Class Initialized
INFO - 2026-02-22 14:30:24 --> Form Validation Class Initialized
INFO - 2026-02-22 14:30:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:30:24 --> Pagination Class Initialized
INFO - 2026-02-22 14:30:24 --> Email Class Initialized
INFO - 2026-02-22 14:30:24 --> Controller Class Initialized
ERROR - 2026-02-22 14:30:24 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:30:24 --> Upload Class Initialized
DEBUG - 2026-02-22 14:30:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:30:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:30:24 --> Encryption Class Initialized
INFO - 2026-02-22 14:30:24 --> Form Validation Class Initialized
INFO - 2026-02-22 14:30:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:30:24 --> Pagination Class Initialized
INFO - 2026-02-22 14:30:24 --> Email Class Initialized
INFO - 2026-02-22 14:30:24 --> Controller Class Initialized
ERROR - 2026-02-22 14:30:24 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:30:25 --> Upload Class Initialized
DEBUG - 2026-02-22 14:30:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:30:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:30:25 --> Encryption Class Initialized
INFO - 2026-02-22 14:30:25 --> Form Validation Class Initialized
INFO - 2026-02-22 14:30:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:30:25 --> Pagination Class Initialized
INFO - 2026-02-22 14:30:25 --> Email Class Initialized
INFO - 2026-02-22 14:30:25 --> Controller Class Initialized
ERROR - 2026-02-22 14:30:25 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:30:25 --> Upload Class Initialized
DEBUG - 2026-02-22 14:30:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:30:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:30:25 --> Encryption Class Initialized
INFO - 2026-02-22 14:30:25 --> Form Validation Class Initialized
INFO - 2026-02-22 14:30:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:30:25 --> Pagination Class Initialized
INFO - 2026-02-22 14:30:25 --> Email Class Initialized
INFO - 2026-02-22 14:30:25 --> Controller Class Initialized
ERROR - 2026-02-22 14:30:25 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:32:57 --> Config Class Initialized
INFO - 2026-02-22 14:32:57 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:32:57 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:32:57 --> Utf8 Class Initialized
INFO - 2026-02-22 14:32:58 --> URI Class Initialized
INFO - 2026-02-22 14:32:58 --> Router Class Initialized
INFO - 2026-02-22 14:32:58 --> Output Class Initialized
INFO - 2026-02-22 14:32:58 --> Security Class Initialized
DEBUG - 2026-02-22 14:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:32:58 --> CSRF cookie sent
INFO - 2026-02-22 14:32:58 --> Input Class Initialized
INFO - 2026-02-22 14:32:58 --> Language Class Initialized
INFO - 2026-02-22 14:32:58 --> Language Class Initialized
INFO - 2026-02-22 14:32:58 --> Config Class Initialized
INFO - 2026-02-22 14:32:58 --> Loader Class Initialized
INFO - 2026-02-22 14:32:58 --> Helper loaded: url_helper
INFO - 2026-02-22 14:32:58 --> Helper loaded: form_helper
INFO - 2026-02-22 14:32:58 --> Helper loaded: html_helper
INFO - 2026-02-22 14:32:58 --> Helper loaded: file_helper
INFO - 2026-02-22 14:32:58 --> Helper loaded: email_helper
INFO - 2026-02-22 14:32:58 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:32:58 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:32:58 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:32:58 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:32:58 --> Database Driver Class Initialized
INFO - 2026-02-22 14:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:33:00 --> Upload Class Initialized
DEBUG - 2026-02-22 14:33:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:33:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:33:00 --> Encryption Class Initialized
INFO - 2026-02-22 14:33:00 --> Form Validation Class Initialized
INFO - 2026-02-22 14:33:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:33:00 --> Pagination Class Initialized
INFO - 2026-02-22 14:33:00 --> Email Class Initialized
INFO - 2026-02-22 14:33:00 --> Controller Class Initialized
DEBUG - 2026-02-22 14:33:00 --> Clientarea MX_Controller Initialized
INFO - 2026-02-22 14:33:00 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:33:00 --> Model "Auth_model" initialized
INFO - 2026-02-22 14:33:00 --> Model "Cart_model" initialized
INFO - 2026-02-22 14:33:00 --> Model "Clientarea_model" initialized
INFO - 2026-02-22 14:33:00 --> Model "Billing_model" initialized
INFO - 2026-02-22 14:33:00 --> Model "Common_model" initialized
INFO - 2026-02-22 14:33:00 --> Model "Order_model" initialized
INFO - 2026-02-22 14:33:00 --> Model "Support_model" initialized
INFO - 2026-02-22 14:33:35 --> Config Class Initialized
INFO - 2026-02-22 14:33:35 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:33:35 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:33:35 --> Utf8 Class Initialized
INFO - 2026-02-22 14:33:35 --> URI Class Initialized
INFO - 2026-02-22 14:33:35 --> Router Class Initialized
INFO - 2026-02-22 14:33:35 --> Output Class Initialized
INFO - 2026-02-22 14:33:35 --> Security Class Initialized
DEBUG - 2026-02-22 14:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:33:35 --> CSRF cookie sent
INFO - 2026-02-22 14:33:35 --> Input Class Initialized
INFO - 2026-02-22 14:33:35 --> Language Class Initialized
INFO - 2026-02-22 14:33:35 --> Language Class Initialized
INFO - 2026-02-22 14:33:35 --> Config Class Initialized
INFO - 2026-02-22 14:33:35 --> Loader Class Initialized
INFO - 2026-02-22 14:33:35 --> Helper loaded: url_helper
INFO - 2026-02-22 14:33:35 --> Helper loaded: form_helper
INFO - 2026-02-22 14:33:35 --> Helper loaded: html_helper
INFO - 2026-02-22 14:33:35 --> Helper loaded: file_helper
INFO - 2026-02-22 14:33:35 --> Helper loaded: email_helper
INFO - 2026-02-22 14:33:35 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:33:35 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:33:35 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:33:35 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:33:35 --> Database Driver Class Initialized
INFO - 2026-02-22 14:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:33:37 --> Upload Class Initialized
DEBUG - 2026-02-22 14:33:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:33:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:33:37 --> Encryption Class Initialized
INFO - 2026-02-22 14:33:37 --> Form Validation Class Initialized
INFO - 2026-02-22 14:33:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:33:37 --> Pagination Class Initialized
INFO - 2026-02-22 14:33:37 --> Email Class Initialized
INFO - 2026-02-22 14:33:37 --> Controller Class Initialized
DEBUG - 2026-02-22 14:33:37 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:33:37 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:33:37 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:33:37 --> Model "Company_model" initialized
INFO - 2026-02-22 14:33:37 --> Model "Common_model" initialized
DEBUG - 2026-02-22 14:33:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:33:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:33:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:33:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:33:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:33:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/company_list.php
INFO - 2026-02-22 14:33:38 --> Final output sent to browser
DEBUG - 2026-02-22 14:33:38 --> Total execution time: 2.3938
INFO - 2026-02-22 14:33:38 --> Config Class Initialized
INFO - 2026-02-22 14:33:38 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:33:38 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:33:38 --> Utf8 Class Initialized
INFO - 2026-02-22 14:33:38 --> URI Class Initialized
INFO - 2026-02-22 14:33:38 --> Config Class Initialized
INFO - 2026-02-22 14:33:38 --> Hooks Class Initialized
INFO - 2026-02-22 14:33:38 --> Router Class Initialized
DEBUG - 2026-02-22 14:33:38 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:33:38 --> Utf8 Class Initialized
INFO - 2026-02-22 14:33:38 --> URI Class Initialized
INFO - 2026-02-22 14:33:38 --> Output Class Initialized
INFO - 2026-02-22 14:33:38 --> Security Class Initialized
INFO - 2026-02-22 14:33:38 --> Router Class Initialized
DEBUG - 2026-02-22 14:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:33:38 --> CSRF cookie sent
INFO - 2026-02-22 14:33:38 --> Input Class Initialized
INFO - 2026-02-22 14:33:38 --> Language Class Initialized
INFO - 2026-02-22 14:33:38 --> Output Class Initialized
INFO - 2026-02-22 14:33:38 --> Language Class Initialized
INFO - 2026-02-22 14:33:38 --> Config Class Initialized
INFO - 2026-02-22 14:33:38 --> Security Class Initialized
DEBUG - 2026-02-22 14:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:33:38 --> CSRF cookie sent
INFO - 2026-02-22 14:33:38 --> Input Class Initialized
INFO - 2026-02-22 14:33:38 --> Language Class Initialized
INFO - 2026-02-22 14:33:38 --> Loader Class Initialized
INFO - 2026-02-22 14:33:38 --> Helper loaded: url_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: form_helper
INFO - 2026-02-22 14:33:38 --> Language Class Initialized
INFO - 2026-02-22 14:33:38 --> Config Class Initialized
INFO - 2026-02-22 14:33:38 --> Helper loaded: html_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: file_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: email_helper
INFO - 2026-02-22 14:33:38 --> Loader Class Initialized
INFO - 2026-02-22 14:33:38 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: url_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: form_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: html_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: file_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: email_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:33:38 --> Database Driver Class Initialized
INFO - 2026-02-22 14:33:38 --> Database Driver Class Initialized
INFO - 2026-02-22 14:33:38 --> Config Class Initialized
INFO - 2026-02-22 14:33:38 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:33:38 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:33:38 --> Utf8 Class Initialized
INFO - 2026-02-22 14:33:38 --> URI Class Initialized
INFO - 2026-02-22 14:33:38 --> Router Class Initialized
INFO - 2026-02-22 14:33:38 --> Output Class Initialized
INFO - 2026-02-22 14:33:38 --> Security Class Initialized
DEBUG - 2026-02-22 14:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:33:38 --> CSRF cookie sent
INFO - 2026-02-22 14:33:38 --> Input Class Initialized
INFO - 2026-02-22 14:33:38 --> Language Class Initialized
INFO - 2026-02-22 14:33:38 --> Language Class Initialized
INFO - 2026-02-22 14:33:38 --> Config Class Initialized
INFO - 2026-02-22 14:33:38 --> Loader Class Initialized
INFO - 2026-02-22 14:33:38 --> Helper loaded: url_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: form_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: html_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: file_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: email_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:33:38 --> Database Driver Class Initialized
INFO - 2026-02-22 14:33:38 --> Config Class Initialized
INFO - 2026-02-22 14:33:38 --> Hooks Class Initialized
INFO - 2026-02-22 14:33:38 --> Config Class Initialized
INFO - 2026-02-22 14:33:38 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:33:38 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:33:38 --> Utf8 Class Initialized
DEBUG - 2026-02-22 14:33:38 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:33:38 --> Utf8 Class Initialized
INFO - 2026-02-22 14:33:38 --> URI Class Initialized
INFO - 2026-02-22 14:33:38 --> Config Class Initialized
INFO - 2026-02-22 14:33:38 --> Hooks Class Initialized
INFO - 2026-02-22 14:33:38 --> URI Class Initialized
INFO - 2026-02-22 14:33:38 --> Router Class Initialized
DEBUG - 2026-02-22 14:33:38 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:33:38 --> Utf8 Class Initialized
INFO - 2026-02-22 14:33:38 --> Router Class Initialized
INFO - 2026-02-22 14:33:38 --> URI Class Initialized
INFO - 2026-02-22 14:33:38 --> Output Class Initialized
INFO - 2026-02-22 14:33:38 --> Output Class Initialized
INFO - 2026-02-22 14:33:38 --> Security Class Initialized
INFO - 2026-02-22 14:33:38 --> Router Class Initialized
INFO - 2026-02-22 14:33:38 --> Security Class Initialized
DEBUG - 2026-02-22 14:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:33:38 --> CSRF cookie sent
INFO - 2026-02-22 14:33:38 --> Input Class Initialized
INFO - 2026-02-22 14:33:38 --> Language Class Initialized
INFO - 2026-02-22 14:33:38 --> Output Class Initialized
DEBUG - 2026-02-22 14:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:33:38 --> CSRF cookie sent
INFO - 2026-02-22 14:33:38 --> Input Class Initialized
INFO - 2026-02-22 14:33:38 --> Language Class Initialized
INFO - 2026-02-22 14:33:38 --> Language Class Initialized
INFO - 2026-02-22 14:33:38 --> Config Class Initialized
INFO - 2026-02-22 14:33:38 --> Security Class Initialized
INFO - 2026-02-22 14:33:38 --> Language Class Initialized
INFO - 2026-02-22 14:33:38 --> Config Class Initialized
DEBUG - 2026-02-22 14:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:33:38 --> CSRF cookie sent
INFO - 2026-02-22 14:33:38 --> Input Class Initialized
INFO - 2026-02-22 14:33:38 --> Language Class Initialized
INFO - 2026-02-22 14:33:38 --> Loader Class Initialized
INFO - 2026-02-22 14:33:38 --> Language Class Initialized
INFO - 2026-02-22 14:33:38 --> Config Class Initialized
INFO - 2026-02-22 14:33:38 --> Loader Class Initialized
INFO - 2026-02-22 14:33:38 --> Helper loaded: url_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: url_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: form_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: html_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: form_helper
INFO - 2026-02-22 14:33:38 --> Loader Class Initialized
INFO - 2026-02-22 14:33:38 --> Helper loaded: html_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: file_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: email_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: file_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: email_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: url_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: form_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: html_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: file_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: email_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:33:38 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:33:38 --> Database Driver Class Initialized
INFO - 2026-02-22 14:33:38 --> Database Driver Class Initialized
INFO - 2026-02-22 14:33:38 --> Database Driver Class Initialized
INFO - 2026-02-22 14:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:33:40 --> Upload Class Initialized
DEBUG - 2026-02-22 14:33:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:33:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:33:40 --> Encryption Class Initialized
INFO - 2026-02-22 14:33:40 --> Form Validation Class Initialized
INFO - 2026-02-22 14:33:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:33:40 --> Pagination Class Initialized
INFO - 2026-02-22 14:33:40 --> Email Class Initialized
INFO - 2026-02-22 14:33:40 --> Controller Class Initialized
ERROR - 2026-02-22 14:33:40 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:33:40 --> Upload Class Initialized
DEBUG - 2026-02-22 14:33:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:33:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:33:40 --> Encryption Class Initialized
INFO - 2026-02-22 14:33:40 --> Form Validation Class Initialized
INFO - 2026-02-22 14:33:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:33:40 --> Pagination Class Initialized
INFO - 2026-02-22 14:33:40 --> Email Class Initialized
INFO - 2026-02-22 14:33:40 --> Controller Class Initialized
ERROR - 2026-02-22 14:33:40 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:33:40 --> Config Class Initialized
INFO - 2026-02-22 14:33:40 --> Hooks Class Initialized
INFO - 2026-02-22 14:33:40 --> Upload Class Initialized
DEBUG - 2026-02-22 14:33:40 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:33:40 --> Utf8 Class Initialized
INFO - 2026-02-22 14:33:40 --> URI Class Initialized
DEBUG - 2026-02-22 14:33:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:33:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:33:40 --> Encryption Class Initialized
INFO - 2026-02-22 14:33:40 --> Router Class Initialized
INFO - 2026-02-22 14:33:40 --> Form Validation Class Initialized
INFO - 2026-02-22 14:33:40 --> Output Class Initialized
INFO - 2026-02-22 14:33:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:33:40 --> Pagination Class Initialized
INFO - 2026-02-22 14:33:40 --> Security Class Initialized
DEBUG - 2026-02-22 14:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:33:40 --> CSRF cookie sent
INFO - 2026-02-22 14:33:40 --> Input Class Initialized
INFO - 2026-02-22 14:33:40 --> Config Class Initialized
INFO - 2026-02-22 14:33:40 --> Hooks Class Initialized
INFO - 2026-02-22 14:33:40 --> Language Class Initialized
INFO - 2026-02-22 14:33:40 --> Email Class Initialized
INFO - 2026-02-22 14:33:40 --> Language Class Initialized
INFO - 2026-02-22 14:33:40 --> Config Class Initialized
INFO - 2026-02-22 14:33:40 --> Controller Class Initialized
DEBUG - 2026-02-22 14:33:40 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:33:40 --> Utf8 Class Initialized
ERROR - 2026-02-22 14:33:40 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:33:40 --> URI Class Initialized
INFO - 2026-02-22 14:33:40 --> Loader Class Initialized
INFO - 2026-02-22 14:33:40 --> Upload Class Initialized
INFO - 2026-02-22 14:33:40 --> Router Class Initialized
INFO - 2026-02-22 14:33:40 --> Helper loaded: url_helper
DEBUG - 2026-02-22 14:33:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:33:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:33:40 --> Encryption Class Initialized
INFO - 2026-02-22 14:33:40 --> Output Class Initialized
INFO - 2026-02-22 14:33:40 --> Helper loaded: form_helper
INFO - 2026-02-22 14:33:40 --> Helper loaded: html_helper
INFO - 2026-02-22 14:33:40 --> Helper loaded: file_helper
INFO - 2026-02-22 14:33:40 --> Helper loaded: email_helper
INFO - 2026-02-22 14:33:40 --> Security Class Initialized
INFO - 2026-02-22 14:33:40 --> Form Validation Class Initialized
INFO - 2026-02-22 14:33:40 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:33:40 --> Helper loaded: ssp_helper
DEBUG - 2026-02-22 14:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:33:40 --> CSRF cookie sent
INFO - 2026-02-22 14:33:40 --> Input Class Initialized
INFO - 2026-02-22 14:33:40 --> Language Class Initialized
INFO - 2026-02-22 14:33:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:33:40 --> Pagination Class Initialized
INFO - 2026-02-22 14:33:40 --> Config Class Initialized
INFO - 2026-02-22 14:33:40 --> Hooks Class Initialized
INFO - 2026-02-22 14:33:40 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:33:40 --> Language Class Initialized
INFO - 2026-02-22 14:33:40 --> Config Class Initialized
DEBUG - 2026-02-22 14:33:40 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:33:40 --> Utf8 Class Initialized
INFO - 2026-02-22 14:33:40 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:33:40 --> URI Class Initialized
INFO - 2026-02-22 14:33:40 --> Router Class Initialized
INFO - 2026-02-22 14:33:40 --> Email Class Initialized
INFO - 2026-02-22 14:33:40 --> Controller Class Initialized
INFO - 2026-02-22 14:33:40 --> Loader Class Initialized
ERROR - 2026-02-22 14:33:40 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:33:40 --> Output Class Initialized
INFO - 2026-02-22 14:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:33:40 --> Helper loaded: url_helper
INFO - 2026-02-22 14:33:40 --> Database Driver Class Initialized
INFO - 2026-02-22 14:33:40 --> Security Class Initialized
INFO - 2026-02-22 14:33:40 --> Helper loaded: form_helper
INFO - 2026-02-22 14:33:40 --> Upload Class Initialized
INFO - 2026-02-22 14:33:40 --> Helper loaded: html_helper
INFO - 2026-02-22 14:33:40 --> Helper loaded: file_helper
DEBUG - 2026-02-22 14:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:33:40 --> CSRF cookie sent
INFO - 2026-02-22 14:33:40 --> Input Class Initialized
INFO - 2026-02-22 14:33:40 --> Helper loaded: email_helper
INFO - 2026-02-22 14:33:40 --> Language Class Initialized
DEBUG - 2026-02-22 14:33:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:33:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:33:40 --> Encryption Class Initialized
INFO - 2026-02-22 14:33:40 --> Language Class Initialized
INFO - 2026-02-22 14:33:40 --> Config Class Initialized
INFO - 2026-02-22 14:33:40 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:33:40 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:33:40 --> Form Validation Class Initialized
INFO - 2026-02-22 14:33:40 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:33:40 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:33:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:33:40 --> Pagination Class Initialized
INFO - 2026-02-22 14:33:40 --> Loader Class Initialized
INFO - 2026-02-22 14:33:40 --> Helper loaded: url_helper
INFO - 2026-02-22 14:33:40 --> Helper loaded: form_helper
INFO - 2026-02-22 14:33:40 --> Helper loaded: html_helper
INFO - 2026-02-22 14:33:40 --> Helper loaded: file_helper
INFO - 2026-02-22 14:33:40 --> Email Class Initialized
INFO - 2026-02-22 14:33:40 --> Database Driver Class Initialized
INFO - 2026-02-22 14:33:40 --> Helper loaded: email_helper
INFO - 2026-02-22 14:33:40 --> Controller Class Initialized
ERROR - 2026-02-22 14:33:40 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:33:40 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:33:40 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:33:40 --> Upload Class Initialized
INFO - 2026-02-22 14:33:40 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:33:40 --> Helper loaded: domain_helper
DEBUG - 2026-02-22 14:33:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:33:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:33:40 --> Encryption Class Initialized
INFO - 2026-02-22 14:33:40 --> Form Validation Class Initialized
INFO - 2026-02-22 14:33:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:33:40 --> Pagination Class Initialized
INFO - 2026-02-22 14:33:40 --> Database Driver Class Initialized
INFO - 2026-02-22 14:33:40 --> Email Class Initialized
INFO - 2026-02-22 14:33:40 --> Controller Class Initialized
ERROR - 2026-02-22 14:33:40 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:33:42 --> Upload Class Initialized
DEBUG - 2026-02-22 14:33:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:33:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:33:42 --> Encryption Class Initialized
INFO - 2026-02-22 14:33:42 --> Form Validation Class Initialized
INFO - 2026-02-22 14:33:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:33:42 --> Pagination Class Initialized
INFO - 2026-02-22 14:33:42 --> Email Class Initialized
INFO - 2026-02-22 14:33:42 --> Controller Class Initialized
ERROR - 2026-02-22 14:33:42 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:33:42 --> Upload Class Initialized
DEBUG - 2026-02-22 14:33:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:33:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:33:42 --> Encryption Class Initialized
INFO - 2026-02-22 14:33:42 --> Form Validation Class Initialized
INFO - 2026-02-22 14:33:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:33:42 --> Pagination Class Initialized
INFO - 2026-02-22 14:33:42 --> Email Class Initialized
INFO - 2026-02-22 14:33:42 --> Controller Class Initialized
DEBUG - 2026-02-22 14:33:42 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:33:42 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:33:42 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:33:42 --> Model "Company_model" initialized
INFO - 2026-02-22 14:33:42 --> Model "Common_model" initialized
INFO - 2026-02-22 14:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:33:44 --> Upload Class Initialized
DEBUG - 2026-02-22 14:33:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:33:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:33:44 --> Encryption Class Initialized
INFO - 2026-02-22 14:33:44 --> Form Validation Class Initialized
INFO - 2026-02-22 14:33:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:33:44 --> Pagination Class Initialized
INFO - 2026-02-22 14:33:44 --> Email Class Initialized
INFO - 2026-02-22 14:33:44 --> Controller Class Initialized
ERROR - 2026-02-22 14:33:44 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:33:50 --> Config Class Initialized
INFO - 2026-02-22 14:33:50 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:33:50 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:33:50 --> Utf8 Class Initialized
INFO - 2026-02-22 14:33:50 --> URI Class Initialized
INFO - 2026-02-22 14:33:50 --> Router Class Initialized
INFO - 2026-02-22 14:33:50 --> Output Class Initialized
INFO - 2026-02-22 14:33:50 --> Security Class Initialized
DEBUG - 2026-02-22 14:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:33:50 --> CSRF cookie sent
INFO - 2026-02-22 14:33:50 --> Input Class Initialized
INFO - 2026-02-22 14:33:50 --> Language Class Initialized
INFO - 2026-02-22 14:33:50 --> Language Class Initialized
INFO - 2026-02-22 14:33:50 --> Config Class Initialized
INFO - 2026-02-22 14:33:50 --> Loader Class Initialized
INFO - 2026-02-22 14:33:50 --> Helper loaded: url_helper
INFO - 2026-02-22 14:33:50 --> Helper loaded: form_helper
INFO - 2026-02-22 14:33:50 --> Helper loaded: html_helper
INFO - 2026-02-22 14:33:50 --> Helper loaded: file_helper
INFO - 2026-02-22 14:33:50 --> Helper loaded: email_helper
INFO - 2026-02-22 14:33:50 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:33:50 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:33:50 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:33:50 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:33:50 --> Database Driver Class Initialized
INFO - 2026-02-22 14:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:33:51 --> Upload Class Initialized
DEBUG - 2026-02-22 14:33:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:33:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:33:51 --> Encryption Class Initialized
INFO - 2026-02-22 14:33:51 --> Form Validation Class Initialized
INFO - 2026-02-22 14:33:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:33:51 --> Pagination Class Initialized
INFO - 2026-02-22 14:33:51 --> Email Class Initialized
INFO - 2026-02-22 14:33:51 --> Controller Class Initialized
DEBUG - 2026-02-22 14:33:51 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:33:51 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:33:51 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:33:51 --> Model "Company_model" initialized
INFO - 2026-02-22 14:33:51 --> Model "Common_model" initialized
DEBUG - 2026-02-22 14:33:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:33:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:33:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:33:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:33:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:33:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/company_manage.php
INFO - 2026-02-22 14:33:52 --> Final output sent to browser
DEBUG - 2026-02-22 14:33:52 --> Total execution time: 2.7722
INFO - 2026-02-22 14:33:53 --> Config Class Initialized
INFO - 2026-02-22 14:33:53 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:33:53 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:33:53 --> Utf8 Class Initialized
INFO - 2026-02-22 14:33:53 --> URI Class Initialized
INFO - 2026-02-22 14:33:53 --> Config Class Initialized
INFO - 2026-02-22 14:33:53 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:33:53 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:33:53 --> Utf8 Class Initialized
INFO - 2026-02-22 14:33:53 --> URI Class Initialized
INFO - 2026-02-22 14:33:53 --> Router Class Initialized
INFO - 2026-02-22 14:33:53 --> Router Class Initialized
INFO - 2026-02-22 14:33:53 --> Output Class Initialized
INFO - 2026-02-22 14:33:53 --> Output Class Initialized
INFO - 2026-02-22 14:33:53 --> Security Class Initialized
DEBUG - 2026-02-22 14:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:33:53 --> CSRF cookie sent
INFO - 2026-02-22 14:33:53 --> Input Class Initialized
INFO - 2026-02-22 14:33:53 --> Language Class Initialized
INFO - 2026-02-22 14:33:53 --> Security Class Initialized
DEBUG - 2026-02-22 14:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:33:53 --> CSRF cookie sent
INFO - 2026-02-22 14:33:53 --> Input Class Initialized
INFO - 2026-02-22 14:33:53 --> Language Class Initialized
INFO - 2026-02-22 14:33:53 --> Language Class Initialized
INFO - 2026-02-22 14:33:53 --> Config Class Initialized
INFO - 2026-02-22 14:33:53 --> Loader Class Initialized
INFO - 2026-02-22 14:33:53 --> Language Class Initialized
INFO - 2026-02-22 14:33:53 --> Config Class Initialized
INFO - 2026-02-22 14:33:53 --> Loader Class Initialized
INFO - 2026-02-22 14:33:53 --> Helper loaded: url_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: form_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: html_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: file_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: email_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: url_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: form_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: html_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: file_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: email_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:33:53 --> Database Driver Class Initialized
INFO - 2026-02-22 14:33:53 --> Database Driver Class Initialized
INFO - 2026-02-22 14:33:53 --> Config Class Initialized
INFO - 2026-02-22 14:33:53 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:33:53 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:33:53 --> Utf8 Class Initialized
INFO - 2026-02-22 14:33:53 --> URI Class Initialized
INFO - 2026-02-22 14:33:53 --> Router Class Initialized
INFO - 2026-02-22 14:33:53 --> Output Class Initialized
INFO - 2026-02-22 14:33:53 --> Security Class Initialized
DEBUG - 2026-02-22 14:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:33:53 --> CSRF cookie sent
INFO - 2026-02-22 14:33:53 --> Input Class Initialized
INFO - 2026-02-22 14:33:53 --> Language Class Initialized
INFO - 2026-02-22 14:33:53 --> Language Class Initialized
INFO - 2026-02-22 14:33:53 --> Config Class Initialized
INFO - 2026-02-22 14:33:53 --> Loader Class Initialized
INFO - 2026-02-22 14:33:53 --> Helper loaded: url_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: form_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: html_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: file_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: email_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:33:53 --> Database Driver Class Initialized
INFO - 2026-02-22 14:33:53 --> Config Class Initialized
INFO - 2026-02-22 14:33:53 --> Hooks Class Initialized
INFO - 2026-02-22 14:33:53 --> Config Class Initialized
INFO - 2026-02-22 14:33:53 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:33:53 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:33:53 --> Utf8 Class Initialized
INFO - 2026-02-22 14:33:53 --> Config Class Initialized
INFO - 2026-02-22 14:33:53 --> Hooks Class Initialized
INFO - 2026-02-22 14:33:53 --> URI Class Initialized
DEBUG - 2026-02-22 14:33:53 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:33:53 --> Utf8 Class Initialized
INFO - 2026-02-22 14:33:53 --> URI Class Initialized
DEBUG - 2026-02-22 14:33:53 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:33:53 --> Utf8 Class Initialized
INFO - 2026-02-22 14:33:53 --> Router Class Initialized
INFO - 2026-02-22 14:33:53 --> URI Class Initialized
INFO - 2026-02-22 14:33:53 --> Router Class Initialized
INFO - 2026-02-22 14:33:53 --> Output Class Initialized
INFO - 2026-02-22 14:33:53 --> Security Class Initialized
INFO - 2026-02-22 14:33:53 --> Output Class Initialized
INFO - 2026-02-22 14:33:53 --> Router Class Initialized
DEBUG - 2026-02-22 14:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:33:53 --> CSRF cookie sent
INFO - 2026-02-22 14:33:53 --> Input Class Initialized
INFO - 2026-02-22 14:33:53 --> Security Class Initialized
INFO - 2026-02-22 14:33:53 --> Language Class Initialized
INFO - 2026-02-22 14:33:53 --> Output Class Initialized
INFO - 2026-02-22 14:33:53 --> Language Class Initialized
INFO - 2026-02-22 14:33:53 --> Config Class Initialized
DEBUG - 2026-02-22 14:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:33:53 --> CSRF cookie sent
INFO - 2026-02-22 14:33:53 --> Input Class Initialized
INFO - 2026-02-22 14:33:53 --> Language Class Initialized
INFO - 2026-02-22 14:33:53 --> Security Class Initialized
INFO - 2026-02-22 14:33:53 --> Language Class Initialized
INFO - 2026-02-22 14:33:53 --> Config Class Initialized
DEBUG - 2026-02-22 14:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:33:53 --> CSRF cookie sent
INFO - 2026-02-22 14:33:53 --> Input Class Initialized
INFO - 2026-02-22 14:33:53 --> Language Class Initialized
INFO - 2026-02-22 14:33:53 --> Loader Class Initialized
INFO - 2026-02-22 14:33:53 --> Language Class Initialized
INFO - 2026-02-22 14:33:53 --> Config Class Initialized
INFO - 2026-02-22 14:33:53 --> Helper loaded: url_helper
INFO - 2026-02-22 14:33:53 --> Loader Class Initialized
INFO - 2026-02-22 14:33:53 --> Helper loaded: form_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: url_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: html_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: file_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: email_helper
INFO - 2026-02-22 14:33:53 --> Loader Class Initialized
INFO - 2026-02-22 14:33:53 --> Helper loaded: form_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: html_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: url_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: file_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: email_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: form_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: html_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: file_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: email_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:33:53 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:33:53 --> Database Driver Class Initialized
INFO - 2026-02-22 14:33:53 --> Database Driver Class Initialized
INFO - 2026-02-22 14:33:53 --> Database Driver Class Initialized
INFO - 2026-02-22 14:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:33:54 --> Upload Class Initialized
DEBUG - 2026-02-22 14:33:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:33:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:33:54 --> Encryption Class Initialized
INFO - 2026-02-22 14:33:54 --> Form Validation Class Initialized
INFO - 2026-02-22 14:33:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:33:54 --> Pagination Class Initialized
INFO - 2026-02-22 14:33:54 --> Email Class Initialized
INFO - 2026-02-22 14:33:54 --> Controller Class Initialized
ERROR - 2026-02-22 14:33:54 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:33:54 --> Config Class Initialized
INFO - 2026-02-22 14:33:54 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:33:54 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:33:54 --> Utf8 Class Initialized
INFO - 2026-02-22 14:33:54 --> URI Class Initialized
INFO - 2026-02-22 14:33:54 --> Router Class Initialized
INFO - 2026-02-22 14:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:33:54 --> Output Class Initialized
INFO - 2026-02-22 14:33:54 --> Upload Class Initialized
INFO - 2026-02-22 14:33:54 --> Security Class Initialized
DEBUG - 2026-02-22 14:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-02-22 14:33:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:33:54 --> CSRF cookie sent
INFO - 2026-02-22 14:33:54 --> Input Class Initialized
INFO - 2026-02-22 14:33:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:33:54 --> Encryption Class Initialized
INFO - 2026-02-22 14:33:54 --> Language Class Initialized
INFO - 2026-02-22 14:33:54 --> Language Class Initialized
INFO - 2026-02-22 14:33:54 --> Config Class Initialized
INFO - 2026-02-22 14:33:54 --> Form Validation Class Initialized
INFO - 2026-02-22 14:33:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:33:54 --> Pagination Class Initialized
INFO - 2026-02-22 14:33:54 --> Loader Class Initialized
INFO - 2026-02-22 14:33:54 --> Helper loaded: url_helper
INFO - 2026-02-22 14:33:54 --> Helper loaded: form_helper
INFO - 2026-02-22 14:33:54 --> Email Class Initialized
INFO - 2026-02-22 14:33:54 --> Controller Class Initialized
INFO - 2026-02-22 14:33:54 --> Helper loaded: html_helper
ERROR - 2026-02-22 14:33:54 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:33:54 --> Helper loaded: file_helper
INFO - 2026-02-22 14:33:54 --> Helper loaded: email_helper
INFO - 2026-02-22 14:33:54 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:33:54 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:33:54 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:33:54 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:33:54 --> Database Driver Class Initialized
INFO - 2026-02-22 14:33:54 --> Config Class Initialized
INFO - 2026-02-22 14:33:54 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:33:54 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:33:54 --> Utf8 Class Initialized
INFO - 2026-02-22 14:33:54 --> URI Class Initialized
INFO - 2026-02-22 14:33:54 --> Router Class Initialized
INFO - 2026-02-22 14:33:54 --> Output Class Initialized
INFO - 2026-02-22 14:33:54 --> Security Class Initialized
DEBUG - 2026-02-22 14:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:33:54 --> CSRF cookie sent
INFO - 2026-02-22 14:33:54 --> Input Class Initialized
INFO - 2026-02-22 14:33:54 --> Language Class Initialized
INFO - 2026-02-22 14:33:54 --> Language Class Initialized
INFO - 2026-02-22 14:33:54 --> Config Class Initialized
INFO - 2026-02-22 14:33:54 --> Loader Class Initialized
INFO - 2026-02-22 14:33:54 --> Helper loaded: url_helper
INFO - 2026-02-22 14:33:54 --> Helper loaded: form_helper
INFO - 2026-02-22 14:33:54 --> Helper loaded: html_helper
INFO - 2026-02-22 14:33:54 --> Helper loaded: file_helper
INFO - 2026-02-22 14:33:54 --> Helper loaded: email_helper
INFO - 2026-02-22 14:33:54 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:33:54 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:33:54 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:33:54 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:33:54 --> Database Driver Class Initialized
INFO - 2026-02-22 14:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:33:55 --> Upload Class Initialized
DEBUG - 2026-02-22 14:33:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:33:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:33:55 --> Encryption Class Initialized
INFO - 2026-02-22 14:33:55 --> Form Validation Class Initialized
INFO - 2026-02-22 14:33:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:33:55 --> Pagination Class Initialized
INFO - 2026-02-22 14:33:55 --> Email Class Initialized
INFO - 2026-02-22 14:33:55 --> Controller Class Initialized
ERROR - 2026-02-22 14:33:55 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:33:55 --> Upload Class Initialized
DEBUG - 2026-02-22 14:33:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:33:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:33:55 --> Encryption Class Initialized
INFO - 2026-02-22 14:33:55 --> Form Validation Class Initialized
INFO - 2026-02-22 14:33:55 --> Config Class Initialized
INFO - 2026-02-22 14:33:55 --> Hooks Class Initialized
INFO - 2026-02-22 14:33:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:33:55 --> Pagination Class Initialized
DEBUG - 2026-02-22 14:33:55 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:33:55 --> Utf8 Class Initialized
INFO - 2026-02-22 14:33:55 --> URI Class Initialized
INFO - 2026-02-22 14:33:55 --> Router Class Initialized
INFO - 2026-02-22 14:33:55 --> Output Class Initialized
INFO - 2026-02-22 14:33:55 --> Email Class Initialized
INFO - 2026-02-22 14:33:55 --> Controller Class Initialized
ERROR - 2026-02-22 14:33:55 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:33:55 --> Security Class Initialized
INFO - 2026-02-22 14:33:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-02-22 14:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:33:55 --> CSRF cookie sent
INFO - 2026-02-22 14:33:55 --> Input Class Initialized
INFO - 2026-02-22 14:33:55 --> Upload Class Initialized
INFO - 2026-02-22 14:33:55 --> Language Class Initialized
INFO - 2026-02-22 14:33:55 --> Language Class Initialized
INFO - 2026-02-22 14:33:55 --> Config Class Initialized
DEBUG - 2026-02-22 14:33:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:33:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:33:55 --> Encryption Class Initialized
INFO - 2026-02-22 14:33:55 --> Loader Class Initialized
INFO - 2026-02-22 14:33:55 --> Form Validation Class Initialized
INFO - 2026-02-22 14:33:55 --> Helper loaded: url_helper
INFO - 2026-02-22 14:33:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:33:55 --> Pagination Class Initialized
INFO - 2026-02-22 14:33:55 --> Helper loaded: form_helper
INFO - 2026-02-22 14:33:55 --> Helper loaded: html_helper
INFO - 2026-02-22 14:33:55 --> Helper loaded: file_helper
INFO - 2026-02-22 14:33:55 --> Helper loaded: email_helper
INFO - 2026-02-22 14:33:55 --> Config Class Initialized
INFO - 2026-02-22 14:33:55 --> Hooks Class Initialized
INFO - 2026-02-22 14:33:55 --> Email Class Initialized
INFO - 2026-02-22 14:33:55 --> Controller Class Initialized
DEBUG - 2026-02-22 14:33:55 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:33:55 --> Utf8 Class Initialized
INFO - 2026-02-22 14:33:55 --> Helper loaded: whmaz_helper
ERROR - 2026-02-22 14:33:55 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:33:55 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:33:55 --> URI Class Initialized
INFO - 2026-02-22 14:33:55 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:33:55 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:33:55 --> Router Class Initialized
INFO - 2026-02-22 14:33:55 --> Output Class Initialized
INFO - 2026-02-22 14:33:55 --> Security Class Initialized
DEBUG - 2026-02-22 14:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:33:55 --> CSRF cookie sent
INFO - 2026-02-22 14:33:55 --> Input Class Initialized
INFO - 2026-02-22 14:33:55 --> Language Class Initialized
INFO - 2026-02-22 14:33:55 --> Language Class Initialized
INFO - 2026-02-22 14:33:55 --> Config Class Initialized
INFO - 2026-02-22 14:33:55 --> Config Class Initialized
INFO - 2026-02-22 14:33:55 --> Hooks Class Initialized
INFO - 2026-02-22 14:33:55 --> Database Driver Class Initialized
DEBUG - 2026-02-22 14:33:55 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:33:55 --> Utf8 Class Initialized
INFO - 2026-02-22 14:33:55 --> Loader Class Initialized
INFO - 2026-02-22 14:33:55 --> URI Class Initialized
INFO - 2026-02-22 14:33:55 --> Helper loaded: url_helper
INFO - 2026-02-22 14:33:55 --> Helper loaded: form_helper
INFO - 2026-02-22 14:33:55 --> Router Class Initialized
INFO - 2026-02-22 14:33:55 --> Helper loaded: html_helper
INFO - 2026-02-22 14:33:55 --> Helper loaded: file_helper
INFO - 2026-02-22 14:33:55 --> Helper loaded: email_helper
INFO - 2026-02-22 14:33:55 --> Output Class Initialized
INFO - 2026-02-22 14:33:55 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:33:55 --> Security Class Initialized
INFO - 2026-02-22 14:33:55 --> Helper loaded: ssp_helper
DEBUG - 2026-02-22 14:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:33:55 --> CSRF cookie sent
INFO - 2026-02-22 14:33:55 --> Input Class Initialized
INFO - 2026-02-22 14:33:55 --> Language Class Initialized
INFO - 2026-02-22 14:33:55 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:33:55 --> Language Class Initialized
INFO - 2026-02-22 14:33:55 --> Config Class Initialized
INFO - 2026-02-22 14:33:55 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:33:55 --> Loader Class Initialized
INFO - 2026-02-22 14:33:55 --> Helper loaded: url_helper
INFO - 2026-02-22 14:33:55 --> Helper loaded: form_helper
INFO - 2026-02-22 14:33:55 --> Helper loaded: html_helper
INFO - 2026-02-22 14:33:55 --> Helper loaded: file_helper
INFO - 2026-02-22 14:33:55 --> Helper loaded: email_helper
INFO - 2026-02-22 14:33:55 --> Database Driver Class Initialized
INFO - 2026-02-22 14:33:55 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:33:55 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:33:55 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:33:55 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:33:55 --> Database Driver Class Initialized
INFO - 2026-02-22 14:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:33:55 --> Upload Class Initialized
DEBUG - 2026-02-22 14:33:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:33:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:33:55 --> Encryption Class Initialized
INFO - 2026-02-22 14:33:55 --> Form Validation Class Initialized
INFO - 2026-02-22 14:33:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:33:55 --> Pagination Class Initialized
INFO - 2026-02-22 14:33:55 --> Email Class Initialized
INFO - 2026-02-22 14:33:55 --> Controller Class Initialized
ERROR - 2026-02-22 14:33:55 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:33:56 --> Upload Class Initialized
DEBUG - 2026-02-22 14:33:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:33:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:33:56 --> Encryption Class Initialized
INFO - 2026-02-22 14:33:56 --> Form Validation Class Initialized
INFO - 2026-02-22 14:33:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:33:56 --> Pagination Class Initialized
INFO - 2026-02-22 14:33:56 --> Email Class Initialized
INFO - 2026-02-22 14:33:56 --> Controller Class Initialized
DEBUG - 2026-02-22 14:33:56 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:33:56 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:33:56 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:33:56 --> Model "Company_model" initialized
INFO - 2026-02-22 14:33:56 --> Model "Common_model" initialized
INFO - 2026-02-22 14:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:33:57 --> Upload Class Initialized
DEBUG - 2026-02-22 14:33:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:33:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:33:57 --> Encryption Class Initialized
INFO - 2026-02-22 14:33:57 --> Form Validation Class Initialized
INFO - 2026-02-22 14:33:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:33:57 --> Pagination Class Initialized
INFO - 2026-02-22 14:33:57 --> Email Class Initialized
INFO - 2026-02-22 14:33:57 --> Controller Class Initialized
DEBUG - 2026-02-22 14:33:57 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:33:57 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:33:57 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:33:57 --> Model "Company_model" initialized
INFO - 2026-02-22 14:33:57 --> Model "Common_model" initialized
INFO - 2026-02-22 14:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:33:59 --> Upload Class Initialized
DEBUG - 2026-02-22 14:33:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:33:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:33:59 --> Encryption Class Initialized
INFO - 2026-02-22 14:33:59 --> Form Validation Class Initialized
INFO - 2026-02-22 14:33:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:33:59 --> Pagination Class Initialized
INFO - 2026-02-22 14:33:59 --> Email Class Initialized
INFO - 2026-02-22 14:33:59 --> Controller Class Initialized
ERROR - 2026-02-22 14:33:59 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:33:59 --> Upload Class Initialized
DEBUG - 2026-02-22 14:33:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:33:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:33:59 --> Encryption Class Initialized
INFO - 2026-02-22 14:33:59 --> Form Validation Class Initialized
INFO - 2026-02-22 14:33:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:33:59 --> Pagination Class Initialized
INFO - 2026-02-22 14:33:59 --> Email Class Initialized
INFO - 2026-02-22 14:33:59 --> Controller Class Initialized
ERROR - 2026-02-22 14:33:59 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:33:59 --> Upload Class Initialized
DEBUG - 2026-02-22 14:33:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:33:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:33:59 --> Encryption Class Initialized
INFO - 2026-02-22 14:33:59 --> Form Validation Class Initialized
INFO - 2026-02-22 14:33:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:33:59 --> Pagination Class Initialized
INFO - 2026-02-22 14:33:59 --> Email Class Initialized
INFO - 2026-02-22 14:33:59 --> Controller Class Initialized
DEBUG - 2026-02-22 14:33:59 --> Invoice MX_Controller Initialized
INFO - 2026-02-22 14:33:59 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:33:59 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:33:59 --> Model "Billing_model" initialized
INFO - 2026-02-22 14:33:59 --> Model "Common_model" initialized
INFO - 2026-02-22 14:33:59 --> Model "Invoice_model" initialized
INFO - 2026-02-22 14:33:59 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 14:34:12 --> Config Class Initialized
INFO - 2026-02-22 14:34:12 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:34:12 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:34:12 --> Utf8 Class Initialized
INFO - 2026-02-22 14:34:12 --> URI Class Initialized
INFO - 2026-02-22 14:34:12 --> Router Class Initialized
INFO - 2026-02-22 14:34:12 --> Output Class Initialized
INFO - 2026-02-22 14:34:12 --> Security Class Initialized
DEBUG - 2026-02-22 14:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:34:12 --> CSRF cookie sent
INFO - 2026-02-22 14:34:12 --> Input Class Initialized
INFO - 2026-02-22 14:34:12 --> Language Class Initialized
INFO - 2026-02-22 14:34:12 --> Language Class Initialized
INFO - 2026-02-22 14:34:12 --> Config Class Initialized
INFO - 2026-02-22 14:34:12 --> Loader Class Initialized
INFO - 2026-02-22 14:34:12 --> Helper loaded: url_helper
INFO - 2026-02-22 14:34:12 --> Helper loaded: form_helper
INFO - 2026-02-22 14:34:12 --> Helper loaded: html_helper
INFO - 2026-02-22 14:34:12 --> Helper loaded: file_helper
INFO - 2026-02-22 14:34:12 --> Helper loaded: email_helper
INFO - 2026-02-22 14:34:12 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:34:12 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:34:12 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:34:12 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:34:12 --> Database Driver Class Initialized
INFO - 2026-02-22 14:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:34:14 --> Upload Class Initialized
DEBUG - 2026-02-22 14:34:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:34:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:34:14 --> Encryption Class Initialized
INFO - 2026-02-22 14:34:14 --> Form Validation Class Initialized
INFO - 2026-02-22 14:34:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:34:14 --> Pagination Class Initialized
INFO - 2026-02-22 14:34:14 --> Email Class Initialized
INFO - 2026-02-22 14:34:14 --> Controller Class Initialized
DEBUG - 2026-02-22 14:34:14 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:34:14 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:34:14 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:34:14 --> Model "Company_model" initialized
INFO - 2026-02-22 14:34:14 --> Model "Common_model" initialized
INFO - 2026-02-22 14:34:41 --> Config Class Initialized
INFO - 2026-02-22 14:34:41 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:34:41 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:34:41 --> Utf8 Class Initialized
INFO - 2026-02-22 14:34:41 --> URI Class Initialized
INFO - 2026-02-22 14:34:41 --> Router Class Initialized
INFO - 2026-02-22 14:34:41 --> Output Class Initialized
INFO - 2026-02-22 14:34:41 --> Security Class Initialized
DEBUG - 2026-02-22 14:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:34:41 --> CSRF cookie sent
INFO - 2026-02-22 14:34:41 --> CSRF token verified
INFO - 2026-02-22 14:34:41 --> Input Class Initialized
INFO - 2026-02-22 14:34:41 --> Language Class Initialized
INFO - 2026-02-22 14:34:41 --> Language Class Initialized
INFO - 2026-02-22 14:34:41 --> Config Class Initialized
INFO - 2026-02-22 14:34:41 --> Loader Class Initialized
INFO - 2026-02-22 14:34:41 --> Helper loaded: url_helper
INFO - 2026-02-22 14:34:41 --> Helper loaded: form_helper
INFO - 2026-02-22 14:34:41 --> Helper loaded: html_helper
INFO - 2026-02-22 14:34:41 --> Helper loaded: file_helper
INFO - 2026-02-22 14:34:41 --> Helper loaded: email_helper
INFO - 2026-02-22 14:34:41 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:34:41 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:34:41 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:34:41 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:34:41 --> Database Driver Class Initialized
INFO - 2026-02-22 14:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:34:43 --> Upload Class Initialized
DEBUG - 2026-02-22 14:34:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:34:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:34:43 --> Encryption Class Initialized
INFO - 2026-02-22 14:34:43 --> Form Validation Class Initialized
INFO - 2026-02-22 14:34:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:34:43 --> Pagination Class Initialized
INFO - 2026-02-22 14:34:43 --> Email Class Initialized
INFO - 2026-02-22 14:34:43 --> Controller Class Initialized
DEBUG - 2026-02-22 14:34:43 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:34:43 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:34:43 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:34:43 --> Model "Company_model" initialized
INFO - 2026-02-22 14:34:43 --> Model "Common_model" initialized
DEBUG - 2026-02-22 14:34:50 --> WHM API2 Response for Email::listpops: {"cpanelresult":{"preevent":{"result":1},"data":[{"suspended_incoming":0,"suspended_login":0,"login":"Main Account","email":"narike8u"}],"postevent":{"result":1},"module":"Email","func":"listpops","apiversion":2,"event":{"result":1}}}

DEBUG - 2026-02-22 14:34:51 --> WHM API2 Response for MysqlFE::listdbs: {"cpanelresult":{"apiversion":2,"postevent":{"result":1},"event":{"result":1},"module":"MysqlFE","preevent":{"result":1},"data":[],"func":"listdbs"}}

DEBUG - 2026-02-22 14:34:53 --> WHM API2 Response for AddonDomain::listaddondomains: {"cpanelresult":{"data":[],"func":"listaddondomains","preevent":{"result":1},"module":"AddonDomain","event":{"result":1},"postevent":{"result":1},"apiversion":2}}

DEBUG - 2026-02-22 14:34:55 --> WHM API2 Response for SubDomain::listsubdomains: {"cpanelresult":{"preevent":{"result":1},"data":[],"postevent":{"result":1},"module":"SubDomain","func":"listsubdomains","apiversion":2,"event":{"result":1}}}

INFO - 2026-02-22 14:35:05 --> Config Class Initialized
INFO - 2026-02-22 14:35:05 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:35:05 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:35:05 --> Utf8 Class Initialized
INFO - 2026-02-22 14:35:05 --> URI Class Initialized
INFO - 2026-02-22 14:35:05 --> Router Class Initialized
INFO - 2026-02-22 14:35:05 --> Output Class Initialized
INFO - 2026-02-22 14:35:05 --> Security Class Initialized
DEBUG - 2026-02-22 14:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:35:05 --> CSRF cookie sent
INFO - 2026-02-22 14:42:56 --> Config Class Initialized
INFO - 2026-02-22 14:42:56 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:42:56 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:42:56 --> Utf8 Class Initialized
INFO - 2026-02-22 14:42:56 --> URI Class Initialized
INFO - 2026-02-22 14:42:56 --> Router Class Initialized
INFO - 2026-02-22 14:42:56 --> Output Class Initialized
INFO - 2026-02-22 14:42:56 --> Security Class Initialized
DEBUG - 2026-02-22 14:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:42:56 --> CSRF cookie sent
INFO - 2026-02-22 14:42:56 --> Input Class Initialized
INFO - 2026-02-22 14:42:56 --> Language Class Initialized
INFO - 2026-02-22 14:42:56 --> Language Class Initialized
INFO - 2026-02-22 14:42:56 --> Config Class Initialized
INFO - 2026-02-22 14:42:56 --> Loader Class Initialized
INFO - 2026-02-22 14:42:56 --> Helper loaded: url_helper
INFO - 2026-02-22 14:42:56 --> Helper loaded: form_helper
INFO - 2026-02-22 14:42:56 --> Helper loaded: html_helper
INFO - 2026-02-22 14:42:56 --> Helper loaded: file_helper
INFO - 2026-02-22 14:42:56 --> Helper loaded: email_helper
INFO - 2026-02-22 14:42:56 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:42:56 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:42:56 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:42:56 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:42:56 --> Database Driver Class Initialized
INFO - 2026-02-22 14:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:42:58 --> Upload Class Initialized
DEBUG - 2026-02-22 14:42:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:42:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:42:58 --> Encryption Class Initialized
INFO - 2026-02-22 14:42:58 --> Form Validation Class Initialized
INFO - 2026-02-22 14:42:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:42:58 --> Pagination Class Initialized
INFO - 2026-02-22 14:42:58 --> Email Class Initialized
INFO - 2026-02-22 14:42:58 --> Controller Class Initialized
DEBUG - 2026-02-22 14:42:58 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:42:58 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:42:58 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:42:58 --> Model "Company_model" initialized
INFO - 2026-02-22 14:42:58 --> Model "Common_model" initialized
DEBUG - 2026-02-22 14:43:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:43:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:43:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:43:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:43:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:43:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/company_manage.php
INFO - 2026-02-22 14:43:00 --> Final output sent to browser
DEBUG - 2026-02-22 14:43:00 --> Total execution time: 3.7894
INFO - 2026-02-22 14:43:00 --> Config Class Initialized
INFO - 2026-02-22 14:43:00 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:43:00 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:43:00 --> Utf8 Class Initialized
INFO - 2026-02-22 14:43:00 --> URI Class Initialized
INFO - 2026-02-22 14:43:00 --> Router Class Initialized
INFO - 2026-02-22 14:43:00 --> Output Class Initialized
INFO - 2026-02-22 14:43:00 --> Security Class Initialized
DEBUG - 2026-02-22 14:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:43:00 --> CSRF cookie sent
INFO - 2026-02-22 14:43:00 --> Input Class Initialized
INFO - 2026-02-22 14:43:00 --> Language Class Initialized
INFO - 2026-02-22 14:43:00 --> Language Class Initialized
INFO - 2026-02-22 14:43:00 --> Config Class Initialized
INFO - 2026-02-22 14:43:00 --> Loader Class Initialized
INFO - 2026-02-22 14:43:00 --> Helper loaded: url_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: form_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: html_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: file_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: email_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:43:00 --> Database Driver Class Initialized
INFO - 2026-02-22 14:43:00 --> Config Class Initialized
INFO - 2026-02-22 14:43:00 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:43:00 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:43:00 --> Utf8 Class Initialized
INFO - 2026-02-22 14:43:00 --> URI Class Initialized
INFO - 2026-02-22 14:43:00 --> Router Class Initialized
INFO - 2026-02-22 14:43:00 --> Output Class Initialized
INFO - 2026-02-22 14:43:00 --> Security Class Initialized
DEBUG - 2026-02-22 14:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:43:00 --> CSRF cookie sent
INFO - 2026-02-22 14:43:00 --> Input Class Initialized
INFO - 2026-02-22 14:43:00 --> Language Class Initialized
INFO - 2026-02-22 14:43:00 --> Language Class Initialized
INFO - 2026-02-22 14:43:00 --> Config Class Initialized
INFO - 2026-02-22 14:43:00 --> Loader Class Initialized
INFO - 2026-02-22 14:43:00 --> Helper loaded: url_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: form_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: html_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: file_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: email_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:43:00 --> Database Driver Class Initialized
INFO - 2026-02-22 14:43:00 --> Config Class Initialized
INFO - 2026-02-22 14:43:00 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:43:00 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:43:00 --> Utf8 Class Initialized
INFO - 2026-02-22 14:43:00 --> URI Class Initialized
INFO - 2026-02-22 14:43:00 --> Router Class Initialized
INFO - 2026-02-22 14:43:00 --> Output Class Initialized
INFO - 2026-02-22 14:43:00 --> Security Class Initialized
DEBUG - 2026-02-22 14:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:43:00 --> CSRF cookie sent
INFO - 2026-02-22 14:43:00 --> Input Class Initialized
INFO - 2026-02-22 14:43:00 --> Language Class Initialized
INFO - 2026-02-22 14:43:00 --> Language Class Initialized
INFO - 2026-02-22 14:43:00 --> Config Class Initialized
INFO - 2026-02-22 14:43:00 --> Loader Class Initialized
INFO - 2026-02-22 14:43:00 --> Helper loaded: url_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: form_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: html_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: file_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: email_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:43:00 --> Config Class Initialized
INFO - 2026-02-22 14:43:00 --> Hooks Class Initialized
INFO - 2026-02-22 14:43:00 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:43:00 --> Config Class Initialized
INFO - 2026-02-22 14:43:00 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:43:00 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:43:00 --> Utf8 Class Initialized
INFO - 2026-02-22 14:43:00 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:43:00 --> URI Class Initialized
DEBUG - 2026-02-22 14:43:00 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:43:00 --> Utf8 Class Initialized
INFO - 2026-02-22 14:43:00 --> URI Class Initialized
INFO - 2026-02-22 14:43:00 --> Config Class Initialized
INFO - 2026-02-22 14:43:00 --> Hooks Class Initialized
INFO - 2026-02-22 14:43:00 --> Router Class Initialized
INFO - 2026-02-22 14:43:00 --> Output Class Initialized
INFO - 2026-02-22 14:43:00 --> Database Driver Class Initialized
DEBUG - 2026-02-22 14:43:00 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:43:00 --> Utf8 Class Initialized
INFO - 2026-02-22 14:43:00 --> Router Class Initialized
INFO - 2026-02-22 14:43:00 --> Security Class Initialized
INFO - 2026-02-22 14:43:00 --> URI Class Initialized
INFO - 2026-02-22 14:43:00 --> Output Class Initialized
DEBUG - 2026-02-22 14:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:43:00 --> CSRF cookie sent
INFO - 2026-02-22 14:43:00 --> Input Class Initialized
INFO - 2026-02-22 14:43:00 --> Router Class Initialized
INFO - 2026-02-22 14:43:00 --> Language Class Initialized
INFO - 2026-02-22 14:43:00 --> Security Class Initialized
DEBUG - 2026-02-22 14:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:43:00 --> CSRF cookie sent
INFO - 2026-02-22 14:43:00 --> Input Class Initialized
INFO - 2026-02-22 14:43:00 --> Output Class Initialized
INFO - 2026-02-22 14:43:00 --> Language Class Initialized
INFO - 2026-02-22 14:43:00 --> Config Class Initialized
INFO - 2026-02-22 14:43:00 --> Language Class Initialized
INFO - 2026-02-22 14:43:00 --> Language Class Initialized
INFO - 2026-02-22 14:43:00 --> Config Class Initialized
INFO - 2026-02-22 14:43:00 --> Security Class Initialized
DEBUG - 2026-02-22 14:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:43:00 --> CSRF cookie sent
INFO - 2026-02-22 14:43:00 --> Input Class Initialized
INFO - 2026-02-22 14:43:00 --> Language Class Initialized
INFO - 2026-02-22 14:43:00 --> Loader Class Initialized
INFO - 2026-02-22 14:43:00 --> Language Class Initialized
INFO - 2026-02-22 14:43:00 --> Config Class Initialized
INFO - 2026-02-22 14:43:00 --> Loader Class Initialized
INFO - 2026-02-22 14:43:00 --> Helper loaded: url_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: form_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: url_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: html_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: file_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: email_helper
INFO - 2026-02-22 14:43:00 --> Loader Class Initialized
INFO - 2026-02-22 14:43:00 --> Helper loaded: form_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: url_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: html_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: file_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: email_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: form_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: html_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: file_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: email_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:43:00 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:43:00 --> Database Driver Class Initialized
INFO - 2026-02-22 14:43:00 --> Database Driver Class Initialized
INFO - 2026-02-22 14:43:00 --> Database Driver Class Initialized
INFO - 2026-02-22 14:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:43:02 --> Upload Class Initialized
DEBUG - 2026-02-22 14:43:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:43:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:43:02 --> Encryption Class Initialized
INFO - 2026-02-22 14:43:02 --> Form Validation Class Initialized
INFO - 2026-02-22 14:43:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:43:02 --> Pagination Class Initialized
INFO - 2026-02-22 14:43:02 --> Email Class Initialized
INFO - 2026-02-22 14:43:02 --> Controller Class Initialized
ERROR - 2026-02-22 14:43:02 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:43:02 --> Upload Class Initialized
DEBUG - 2026-02-22 14:43:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:43:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:43:02 --> Encryption Class Initialized
INFO - 2026-02-22 14:43:02 --> Form Validation Class Initialized
INFO - 2026-02-22 14:43:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:43:02 --> Pagination Class Initialized
INFO - 2026-02-22 14:43:02 --> Config Class Initialized
INFO - 2026-02-22 14:43:02 --> Hooks Class Initialized
INFO - 2026-02-22 14:43:02 --> Email Class Initialized
INFO - 2026-02-22 14:43:02 --> Controller Class Initialized
ERROR - 2026-02-22 14:43:02 --> 404 Page Not Found: /index
DEBUG - 2026-02-22 14:43:02 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:43:02 --> Utf8 Class Initialized
INFO - 2026-02-22 14:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:43:02 --> URI Class Initialized
INFO - 2026-02-22 14:43:02 --> Upload Class Initialized
INFO - 2026-02-22 14:43:02 --> Router Class Initialized
DEBUG - 2026-02-22 14:43:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:43:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:43:02 --> Encryption Class Initialized
INFO - 2026-02-22 14:43:02 --> Output Class Initialized
INFO - 2026-02-22 14:43:02 --> Form Validation Class Initialized
INFO - 2026-02-22 14:43:02 --> Security Class Initialized
INFO - 2026-02-22 14:43:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:43:02 --> Pagination Class Initialized
DEBUG - 2026-02-22 14:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:43:02 --> CSRF cookie sent
INFO - 2026-02-22 14:43:02 --> Input Class Initialized
INFO - 2026-02-22 14:43:02 --> Language Class Initialized
INFO - 2026-02-22 14:43:02 --> Language Class Initialized
INFO - 2026-02-22 14:43:02 --> Config Class Initialized
INFO - 2026-02-22 14:43:02 --> Email Class Initialized
INFO - 2026-02-22 14:43:02 --> Controller Class Initialized
ERROR - 2026-02-22 14:43:02 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:43:02 --> Config Class Initialized
INFO - 2026-02-22 14:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:43:02 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:43:02 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:43:02 --> Utf8 Class Initialized
INFO - 2026-02-22 14:43:02 --> Loader Class Initialized
INFO - 2026-02-22 14:43:02 --> Upload Class Initialized
INFO - 2026-02-22 14:43:02 --> URI Class Initialized
INFO - 2026-02-22 14:43:02 --> Helper loaded: url_helper
DEBUG - 2026-02-22 14:43:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:43:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:43:02 --> Encryption Class Initialized
INFO - 2026-02-22 14:43:02 --> Router Class Initialized
INFO - 2026-02-22 14:43:02 --> Helper loaded: form_helper
INFO - 2026-02-22 14:43:02 --> Helper loaded: html_helper
INFO - 2026-02-22 14:43:02 --> Output Class Initialized
INFO - 2026-02-22 14:43:02 --> Form Validation Class Initialized
INFO - 2026-02-22 14:43:02 --> Helper loaded: file_helper
INFO - 2026-02-22 14:43:02 --> Helper loaded: email_helper
INFO - 2026-02-22 14:43:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:43:02 --> Pagination Class Initialized
INFO - 2026-02-22 14:43:02 --> Security Class Initialized
INFO - 2026-02-22 14:43:02 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:43:02 --> Helper loaded: ssp_helper
DEBUG - 2026-02-22 14:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:43:02 --> CSRF cookie sent
INFO - 2026-02-22 14:43:02 --> Input Class Initialized
INFO - 2026-02-22 14:43:02 --> Language Class Initialized
INFO - 2026-02-22 14:43:02 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:43:02 --> Email Class Initialized
INFO - 2026-02-22 14:43:02 --> Controller Class Initialized
INFO - 2026-02-22 14:43:02 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:43:02 --> Language Class Initialized
INFO - 2026-02-22 14:43:02 --> Config Class Initialized
ERROR - 2026-02-22 14:43:02 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:43:02 --> Config Class Initialized
INFO - 2026-02-22 14:43:02 --> Hooks Class Initialized
INFO - 2026-02-22 14:43:02 --> Upload Class Initialized
INFO - 2026-02-22 14:43:02 --> Loader Class Initialized
DEBUG - 2026-02-22 14:43:02 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:43:02 --> Utf8 Class Initialized
DEBUG - 2026-02-22 14:43:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:43:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:43:02 --> Encryption Class Initialized
INFO - 2026-02-22 14:43:02 --> Helper loaded: url_helper
INFO - 2026-02-22 14:43:02 --> URI Class Initialized
INFO - 2026-02-22 14:43:02 --> Form Validation Class Initialized
INFO - 2026-02-22 14:43:02 --> Database Driver Class Initialized
INFO - 2026-02-22 14:43:02 --> Helper loaded: form_helper
INFO - 2026-02-22 14:43:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:43:02 --> Pagination Class Initialized
INFO - 2026-02-22 14:43:02 --> Router Class Initialized
INFO - 2026-02-22 14:43:02 --> Helper loaded: html_helper
INFO - 2026-02-22 14:43:02 --> Helper loaded: file_helper
INFO - 2026-02-22 14:43:02 --> Helper loaded: email_helper
INFO - 2026-02-22 14:43:02 --> Output Class Initialized
INFO - 2026-02-22 14:43:02 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:43:02 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:43:02 --> Email Class Initialized
INFO - 2026-02-22 14:43:02 --> Security Class Initialized
INFO - 2026-02-22 14:43:02 --> Controller Class Initialized
INFO - 2026-02-22 14:43:02 --> Config Class Initialized
INFO - 2026-02-22 14:43:02 --> Hooks Class Initialized
ERROR - 2026-02-22 14:43:02 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:43:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-02-22 14:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:43:02 --> CSRF cookie sent
INFO - 2026-02-22 14:43:02 --> Input Class Initialized
DEBUG - 2026-02-22 14:43:02 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:43:02 --> Utf8 Class Initialized
INFO - 2026-02-22 14:43:02 --> Language Class Initialized
INFO - 2026-02-22 14:43:02 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:43:02 --> URI Class Initialized
INFO - 2026-02-22 14:43:02 --> Upload Class Initialized
INFO - 2026-02-22 14:43:02 --> Language Class Initialized
INFO - 2026-02-22 14:43:02 --> Config Class Initialized
INFO - 2026-02-22 14:43:02 --> Helper loaded: domain_helper
DEBUG - 2026-02-22 14:43:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:43:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:43:02 --> Encryption Class Initialized
INFO - 2026-02-22 14:43:02 --> Router Class Initialized
INFO - 2026-02-22 14:43:02 --> Output Class Initialized
INFO - 2026-02-22 14:43:02 --> Loader Class Initialized
INFO - 2026-02-22 14:43:02 --> Form Validation Class Initialized
INFO - 2026-02-22 14:43:02 --> Security Class Initialized
INFO - 2026-02-22 14:43:02 --> Helper loaded: url_helper
INFO - 2026-02-22 14:43:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:43:02 --> Pagination Class Initialized
DEBUG - 2026-02-22 14:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:43:02 --> CSRF cookie sent
INFO - 2026-02-22 14:43:02 --> Input Class Initialized
INFO - 2026-02-22 14:43:02 --> Language Class Initialized
INFO - 2026-02-22 14:43:02 --> Helper loaded: form_helper
INFO - 2026-02-22 14:43:02 --> Language Class Initialized
INFO - 2026-02-22 14:43:02 --> Config Class Initialized
INFO - 2026-02-22 14:43:02 --> Helper loaded: html_helper
INFO - 2026-02-22 14:43:02 --> Helper loaded: file_helper
INFO - 2026-02-22 14:43:02 --> Helper loaded: email_helper
INFO - 2026-02-22 14:43:02 --> Config Class Initialized
INFO - 2026-02-22 14:43:02 --> Hooks Class Initialized
INFO - 2026-02-22 14:43:02 --> Database Driver Class Initialized
INFO - 2026-02-22 14:43:02 --> Email Class Initialized
INFO - 2026-02-22 14:43:02 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:43:02 --> Controller Class Initialized
INFO - 2026-02-22 14:43:02 --> Loader Class Initialized
INFO - 2026-02-22 14:43:02 --> Helper loaded: ssp_helper
ERROR - 2026-02-22 14:43:02 --> 404 Page Not Found: /index
DEBUG - 2026-02-22 14:43:02 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:43:02 --> Utf8 Class Initialized
INFO - 2026-02-22 14:43:02 --> Helper loaded: url_helper
INFO - 2026-02-22 14:43:02 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:43:02 --> URI Class Initialized
INFO - 2026-02-22 14:43:02 --> Helper loaded: form_helper
INFO - 2026-02-22 14:43:02 --> Helper loaded: html_helper
INFO - 2026-02-22 14:43:02 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:43:02 --> Helper loaded: file_helper
INFO - 2026-02-22 14:43:02 --> Helper loaded: email_helper
INFO - 2026-02-22 14:43:02 --> Router Class Initialized
INFO - 2026-02-22 14:43:02 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:43:02 --> Output Class Initialized
INFO - 2026-02-22 14:43:02 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:43:02 --> Security Class Initialized
DEBUG - 2026-02-22 14:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:43:02 --> CSRF cookie sent
INFO - 2026-02-22 14:43:02 --> Input Class Initialized
INFO - 2026-02-22 14:43:02 --> Language Class Initialized
INFO - 2026-02-22 14:43:02 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:43:02 --> Language Class Initialized
INFO - 2026-02-22 14:43:02 --> Config Class Initialized
INFO - 2026-02-22 14:43:02 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:43:02 --> Database Driver Class Initialized
INFO - 2026-02-22 14:43:02 --> Loader Class Initialized
INFO - 2026-02-22 14:43:02 --> Helper loaded: url_helper
INFO - 2026-02-22 14:43:02 --> Helper loaded: form_helper
INFO - 2026-02-22 14:43:02 --> Helper loaded: html_helper
INFO - 2026-02-22 14:43:02 --> Helper loaded: file_helper
INFO - 2026-02-22 14:43:02 --> Helper loaded: email_helper
INFO - 2026-02-22 14:43:02 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:43:02 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:43:02 --> Database Driver Class Initialized
INFO - 2026-02-22 14:43:02 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:43:02 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:43:02 --> Database Driver Class Initialized
INFO - 2026-02-22 14:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:43:04 --> Upload Class Initialized
DEBUG - 2026-02-22 14:43:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:43:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:43:04 --> Encryption Class Initialized
INFO - 2026-02-22 14:43:04 --> Form Validation Class Initialized
INFO - 2026-02-22 14:43:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:43:04 --> Pagination Class Initialized
INFO - 2026-02-22 14:43:04 --> Email Class Initialized
INFO - 2026-02-22 14:43:04 --> Controller Class Initialized
ERROR - 2026-02-22 14:43:04 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:43:04 --> Upload Class Initialized
DEBUG - 2026-02-22 14:43:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:43:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:43:04 --> Encryption Class Initialized
INFO - 2026-02-22 14:43:04 --> Form Validation Class Initialized
INFO - 2026-02-22 14:43:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:43:04 --> Pagination Class Initialized
INFO - 2026-02-22 14:43:04 --> Email Class Initialized
INFO - 2026-02-22 14:43:04 --> Controller Class Initialized
ERROR - 2026-02-22 14:43:04 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:43:04 --> Upload Class Initialized
DEBUG - 2026-02-22 14:43:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:43:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:43:04 --> Encryption Class Initialized
INFO - 2026-02-22 14:43:04 --> Form Validation Class Initialized
INFO - 2026-02-22 14:43:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:43:04 --> Pagination Class Initialized
INFO - 2026-02-22 14:43:04 --> Email Class Initialized
INFO - 2026-02-22 14:43:04 --> Controller Class Initialized
DEBUG - 2026-02-22 14:43:04 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:43:04 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:43:04 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:43:04 --> Model "Company_model" initialized
INFO - 2026-02-22 14:43:04 --> Model "Common_model" initialized
INFO - 2026-02-22 14:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:43:06 --> Upload Class Initialized
DEBUG - 2026-02-22 14:43:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:43:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:43:06 --> Encryption Class Initialized
INFO - 2026-02-22 14:43:06 --> Form Validation Class Initialized
INFO - 2026-02-22 14:43:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:43:06 --> Pagination Class Initialized
INFO - 2026-02-22 14:43:06 --> Email Class Initialized
INFO - 2026-02-22 14:43:06 --> Controller Class Initialized
DEBUG - 2026-02-22 14:43:06 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:43:06 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:43:06 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:43:06 --> Model "Company_model" initialized
INFO - 2026-02-22 14:43:06 --> Model "Common_model" initialized
INFO - 2026-02-22 14:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:43:08 --> Upload Class Initialized
DEBUG - 2026-02-22 14:43:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:43:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:43:08 --> Encryption Class Initialized
INFO - 2026-02-22 14:43:08 --> Form Validation Class Initialized
INFO - 2026-02-22 14:43:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:43:08 --> Pagination Class Initialized
INFO - 2026-02-22 14:43:08 --> Email Class Initialized
INFO - 2026-02-22 14:43:08 --> Controller Class Initialized
DEBUG - 2026-02-22 14:43:08 --> Invoice MX_Controller Initialized
INFO - 2026-02-22 14:43:08 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:43:08 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:43:08 --> Model "Billing_model" initialized
INFO - 2026-02-22 14:43:08 --> Model "Common_model" initialized
INFO - 2026-02-22 14:43:08 --> Model "Invoice_model" initialized
INFO - 2026-02-22 14:43:08 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 14:43:11 --> Config Class Initialized
INFO - 2026-02-22 14:43:11 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:43:11 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:43:11 --> Utf8 Class Initialized
INFO - 2026-02-22 14:43:11 --> URI Class Initialized
INFO - 2026-02-22 14:43:11 --> Router Class Initialized
INFO - 2026-02-22 14:43:11 --> Output Class Initialized
INFO - 2026-02-22 14:43:11 --> Security Class Initialized
DEBUG - 2026-02-22 14:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:43:11 --> CSRF cookie sent
INFO - 2026-02-22 14:43:11 --> Input Class Initialized
INFO - 2026-02-22 14:43:11 --> Language Class Initialized
INFO - 2026-02-22 14:43:11 --> Language Class Initialized
INFO - 2026-02-22 14:43:11 --> Config Class Initialized
INFO - 2026-02-22 14:43:11 --> Loader Class Initialized
INFO - 2026-02-22 14:43:11 --> Helper loaded: url_helper
INFO - 2026-02-22 14:43:11 --> Helper loaded: form_helper
INFO - 2026-02-22 14:43:11 --> Helper loaded: html_helper
INFO - 2026-02-22 14:43:11 --> Helper loaded: file_helper
INFO - 2026-02-22 14:43:11 --> Helper loaded: email_helper
INFO - 2026-02-22 14:43:11 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:43:11 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:43:11 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:43:11 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:43:11 --> Database Driver Class Initialized
INFO - 2026-02-22 14:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:43:13 --> Upload Class Initialized
DEBUG - 2026-02-22 14:43:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:43:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:43:13 --> Encryption Class Initialized
INFO - 2026-02-22 14:43:13 --> Form Validation Class Initialized
INFO - 2026-02-22 14:43:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:43:13 --> Pagination Class Initialized
INFO - 2026-02-22 14:43:13 --> Email Class Initialized
INFO - 2026-02-22 14:43:13 --> Controller Class Initialized
DEBUG - 2026-02-22 14:43:13 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:43:13 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:43:13 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:43:13 --> Model "Company_model" initialized
INFO - 2026-02-22 14:43:13 --> Model "Common_model" initialized
INFO - 2026-02-22 14:43:20 --> Config Class Initialized
INFO - 2026-02-22 14:43:20 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:43:20 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:43:20 --> Utf8 Class Initialized
INFO - 2026-02-22 14:43:20 --> URI Class Initialized
INFO - 2026-02-22 14:43:20 --> Router Class Initialized
INFO - 2026-02-22 14:43:20 --> Output Class Initialized
INFO - 2026-02-22 14:43:20 --> Security Class Initialized
DEBUG - 2026-02-22 14:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:43:20 --> CSRF cookie sent
INFO - 2026-02-22 14:43:20 --> CSRF token verified
INFO - 2026-02-22 14:43:20 --> Input Class Initialized
INFO - 2026-02-22 14:43:20 --> Language Class Initialized
INFO - 2026-02-22 14:43:20 --> Language Class Initialized
INFO - 2026-02-22 14:43:20 --> Config Class Initialized
INFO - 2026-02-22 14:43:20 --> Loader Class Initialized
INFO - 2026-02-22 14:43:20 --> Helper loaded: url_helper
INFO - 2026-02-22 14:43:20 --> Helper loaded: form_helper
INFO - 2026-02-22 14:43:20 --> Helper loaded: html_helper
INFO - 2026-02-22 14:43:20 --> Helper loaded: file_helper
INFO - 2026-02-22 14:43:20 --> Helper loaded: email_helper
INFO - 2026-02-22 14:43:20 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:43:20 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:43:20 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:43:20 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:43:20 --> Database Driver Class Initialized
INFO - 2026-02-22 14:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:43:22 --> Upload Class Initialized
DEBUG - 2026-02-22 14:43:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:43:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:43:22 --> Encryption Class Initialized
INFO - 2026-02-22 14:43:22 --> Form Validation Class Initialized
INFO - 2026-02-22 14:43:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:43:22 --> Pagination Class Initialized
INFO - 2026-02-22 14:43:22 --> Email Class Initialized
INFO - 2026-02-22 14:43:22 --> Controller Class Initialized
DEBUG - 2026-02-22 14:43:22 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:43:22 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:43:22 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:43:22 --> Model "Company_model" initialized
INFO - 2026-02-22 14:43:22 --> Model "Common_model" initialized
INFO - 2026-02-22 14:43:26 --> cPanel account suspended: narike8u
INFO - 2026-02-22 14:43:27 --> Config Class Initialized
INFO - 2026-02-22 14:43:27 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:43:27 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:43:27 --> Utf8 Class Initialized
INFO - 2026-02-22 14:43:27 --> URI Class Initialized
INFO - 2026-02-22 14:43:27 --> Router Class Initialized
INFO - 2026-02-22 14:43:27 --> Output Class Initialized
INFO - 2026-02-22 14:43:27 --> Security Class Initialized
INFO - 2026-02-22 14:43:27 --> Config Class Initialized
INFO - 2026-02-22 14:43:27 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:43:27 --> CSRF cookie sent
INFO - 2026-02-22 14:43:27 --> Input Class Initialized
INFO - 2026-02-22 14:43:27 --> Language Class Initialized
DEBUG - 2026-02-22 14:43:27 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:43:27 --> Utf8 Class Initialized
INFO - 2026-02-22 14:43:27 --> Language Class Initialized
INFO - 2026-02-22 14:43:27 --> Config Class Initialized
INFO - 2026-02-22 14:43:27 --> URI Class Initialized
INFO - 2026-02-22 14:43:27 --> Loader Class Initialized
INFO - 2026-02-22 14:43:27 --> Router Class Initialized
INFO - 2026-02-22 14:43:27 --> Helper loaded: url_helper
INFO - 2026-02-22 14:43:27 --> Output Class Initialized
INFO - 2026-02-22 14:43:27 --> Helper loaded: form_helper
INFO - 2026-02-22 14:43:27 --> Helper loaded: html_helper
INFO - 2026-02-22 14:43:27 --> Security Class Initialized
INFO - 2026-02-22 14:43:27 --> Helper loaded: file_helper
INFO - 2026-02-22 14:43:27 --> Helper loaded: email_helper
DEBUG - 2026-02-22 14:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:43:27 --> CSRF cookie sent
INFO - 2026-02-22 14:43:27 --> Input Class Initialized
INFO - 2026-02-22 14:43:27 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:43:27 --> Language Class Initialized
INFO - 2026-02-22 14:43:27 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:43:27 --> Language Class Initialized
INFO - 2026-02-22 14:43:27 --> Config Class Initialized
INFO - 2026-02-22 14:43:27 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:43:27 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:43:27 --> Loader Class Initialized
INFO - 2026-02-22 14:43:27 --> Helper loaded: url_helper
INFO - 2026-02-22 14:43:27 --> Helper loaded: form_helper
INFO - 2026-02-22 14:43:27 --> Helper loaded: html_helper
INFO - 2026-02-22 14:43:27 --> Helper loaded: file_helper
INFO - 2026-02-22 14:43:27 --> Helper loaded: email_helper
INFO - 2026-02-22 14:43:27 --> Database Driver Class Initialized
INFO - 2026-02-22 14:43:27 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:43:27 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:43:27 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:43:27 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:43:27 --> Database Driver Class Initialized
INFO - 2026-02-22 14:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:43:29 --> Upload Class Initialized
DEBUG - 2026-02-22 14:43:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:43:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:43:29 --> Encryption Class Initialized
INFO - 2026-02-22 14:43:29 --> Form Validation Class Initialized
INFO - 2026-02-22 14:43:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:43:29 --> Pagination Class Initialized
INFO - 2026-02-22 14:43:29 --> Email Class Initialized
INFO - 2026-02-22 14:43:29 --> Controller Class Initialized
DEBUG - 2026-02-22 14:43:29 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:43:29 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:43:29 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:43:29 --> Model "Company_model" initialized
INFO - 2026-02-22 14:43:29 --> Model "Common_model" initialized
INFO - 2026-02-22 14:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:43:30 --> Upload Class Initialized
DEBUG - 2026-02-22 14:43:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:43:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:43:30 --> Encryption Class Initialized
INFO - 2026-02-22 14:43:30 --> Form Validation Class Initialized
INFO - 2026-02-22 14:43:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:43:30 --> Pagination Class Initialized
INFO - 2026-02-22 14:43:30 --> Email Class Initialized
INFO - 2026-02-22 14:43:30 --> Controller Class Initialized
DEBUG - 2026-02-22 14:43:30 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:43:30 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:43:30 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:43:30 --> Model "Company_model" initialized
INFO - 2026-02-22 14:43:30 --> Model "Common_model" initialized
INFO - 2026-02-22 14:44:18 --> Config Class Initialized
INFO - 2026-02-22 14:44:18 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:44:18 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:44:18 --> Utf8 Class Initialized
INFO - 2026-02-22 14:44:18 --> URI Class Initialized
INFO - 2026-02-22 14:44:18 --> Router Class Initialized
INFO - 2026-02-22 14:44:18 --> Output Class Initialized
INFO - 2026-02-22 14:44:18 --> Security Class Initialized
DEBUG - 2026-02-22 14:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:44:18 --> CSRF cookie sent
INFO - 2026-02-22 14:44:18 --> CSRF token verified
INFO - 2026-02-22 14:44:18 --> Input Class Initialized
INFO - 2026-02-22 14:44:18 --> Language Class Initialized
INFO - 2026-02-22 14:44:18 --> Language Class Initialized
INFO - 2026-02-22 14:44:18 --> Config Class Initialized
INFO - 2026-02-22 14:44:18 --> Loader Class Initialized
INFO - 2026-02-22 14:44:18 --> Helper loaded: url_helper
INFO - 2026-02-22 14:44:18 --> Helper loaded: form_helper
INFO - 2026-02-22 14:44:18 --> Helper loaded: html_helper
INFO - 2026-02-22 14:44:18 --> Helper loaded: file_helper
INFO - 2026-02-22 14:44:18 --> Helper loaded: email_helper
INFO - 2026-02-22 14:44:18 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:44:18 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:44:18 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:44:18 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:44:18 --> Database Driver Class Initialized
INFO - 2026-02-22 14:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:44:20 --> Upload Class Initialized
DEBUG - 2026-02-22 14:44:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:44:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:44:20 --> Encryption Class Initialized
INFO - 2026-02-22 14:44:20 --> Form Validation Class Initialized
INFO - 2026-02-22 14:44:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:44:20 --> Pagination Class Initialized
INFO - 2026-02-22 14:44:20 --> Email Class Initialized
INFO - 2026-02-22 14:44:20 --> Controller Class Initialized
DEBUG - 2026-02-22 14:44:20 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:44:20 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:44:20 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:44:20 --> Model "Company_model" initialized
INFO - 2026-02-22 14:44:20 --> Model "Common_model" initialized
INFO - 2026-02-22 14:44:24 --> cPanel account unsuspended: narike8u
INFO - 2026-02-22 14:44:25 --> Config Class Initialized
INFO - 2026-02-22 14:44:25 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:44:25 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:44:25 --> Utf8 Class Initialized
INFO - 2026-02-22 14:44:25 --> URI Class Initialized
INFO - 2026-02-22 14:44:25 --> Router Class Initialized
INFO - 2026-02-22 14:44:25 --> Output Class Initialized
INFO - 2026-02-22 14:44:25 --> Config Class Initialized
INFO - 2026-02-22 14:44:25 --> Hooks Class Initialized
INFO - 2026-02-22 14:44:25 --> Security Class Initialized
DEBUG - 2026-02-22 14:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:44:25 --> CSRF cookie sent
INFO - 2026-02-22 14:44:25 --> Input Class Initialized
DEBUG - 2026-02-22 14:44:25 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:44:25 --> Utf8 Class Initialized
INFO - 2026-02-22 14:44:25 --> Language Class Initialized
INFO - 2026-02-22 14:44:25 --> URI Class Initialized
INFO - 2026-02-22 14:44:25 --> Language Class Initialized
INFO - 2026-02-22 14:44:25 --> Config Class Initialized
INFO - 2026-02-22 14:44:25 --> Router Class Initialized
INFO - 2026-02-22 14:44:25 --> Loader Class Initialized
INFO - 2026-02-22 14:44:25 --> Output Class Initialized
INFO - 2026-02-22 14:44:25 --> Helper loaded: url_helper
INFO - 2026-02-22 14:44:25 --> Helper loaded: form_helper
INFO - 2026-02-22 14:44:25 --> Security Class Initialized
INFO - 2026-02-22 14:44:25 --> Helper loaded: html_helper
INFO - 2026-02-22 14:44:25 --> Helper loaded: file_helper
INFO - 2026-02-22 14:44:25 --> Helper loaded: email_helper
DEBUG - 2026-02-22 14:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:44:25 --> CSRF cookie sent
INFO - 2026-02-22 14:44:25 --> Input Class Initialized
INFO - 2026-02-22 14:44:25 --> Language Class Initialized
INFO - 2026-02-22 14:44:25 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:44:25 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:44:25 --> Language Class Initialized
INFO - 2026-02-22 14:44:25 --> Config Class Initialized
INFO - 2026-02-22 14:44:25 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:44:25 --> Loader Class Initialized
INFO - 2026-02-22 14:44:25 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:44:25 --> Helper loaded: url_helper
INFO - 2026-02-22 14:44:25 --> Helper loaded: form_helper
INFO - 2026-02-22 14:44:25 --> Helper loaded: html_helper
INFO - 2026-02-22 14:44:25 --> Helper loaded: file_helper
INFO - 2026-02-22 14:44:25 --> Helper loaded: email_helper
INFO - 2026-02-22 14:44:25 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:44:25 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:44:25 --> Database Driver Class Initialized
INFO - 2026-02-22 14:44:25 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:44:25 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:44:25 --> Database Driver Class Initialized
INFO - 2026-02-22 14:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:44:27 --> Upload Class Initialized
DEBUG - 2026-02-22 14:44:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:44:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:44:27 --> Encryption Class Initialized
INFO - 2026-02-22 14:44:27 --> Form Validation Class Initialized
INFO - 2026-02-22 14:44:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:44:27 --> Pagination Class Initialized
INFO - 2026-02-22 14:44:27 --> Email Class Initialized
INFO - 2026-02-22 14:44:27 --> Controller Class Initialized
DEBUG - 2026-02-22 14:44:27 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:44:27 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:44:27 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:44:27 --> Model "Company_model" initialized
INFO - 2026-02-22 14:44:27 --> Model "Common_model" initialized
INFO - 2026-02-22 14:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:44:29 --> Upload Class Initialized
DEBUG - 2026-02-22 14:44:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:44:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:44:29 --> Encryption Class Initialized
INFO - 2026-02-22 14:44:29 --> Form Validation Class Initialized
INFO - 2026-02-22 14:44:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:44:29 --> Pagination Class Initialized
INFO - 2026-02-22 14:44:29 --> Email Class Initialized
INFO - 2026-02-22 14:44:29 --> Controller Class Initialized
DEBUG - 2026-02-22 14:44:29 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:44:29 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:44:29 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:44:29 --> Model "Company_model" initialized
INFO - 2026-02-22 14:44:29 --> Model "Common_model" initialized
INFO - 2026-02-22 14:44:54 --> Config Class Initialized
INFO - 2026-02-22 14:44:54 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:44:54 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:44:54 --> Utf8 Class Initialized
INFO - 2026-02-22 14:44:54 --> URI Class Initialized
INFO - 2026-02-22 14:44:54 --> Router Class Initialized
INFO - 2026-02-22 14:44:54 --> Output Class Initialized
INFO - 2026-02-22 14:44:54 --> Security Class Initialized
DEBUG - 2026-02-22 14:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:44:54 --> CSRF cookie sent
INFO - 2026-02-22 14:44:54 --> CSRF token verified
INFO - 2026-02-22 14:44:54 --> Input Class Initialized
INFO - 2026-02-22 14:44:54 --> Language Class Initialized
INFO - 2026-02-22 14:44:54 --> Language Class Initialized
INFO - 2026-02-22 14:44:54 --> Config Class Initialized
INFO - 2026-02-22 14:44:54 --> Loader Class Initialized
INFO - 2026-02-22 14:44:54 --> Helper loaded: url_helper
INFO - 2026-02-22 14:44:54 --> Helper loaded: form_helper
INFO - 2026-02-22 14:44:54 --> Helper loaded: html_helper
INFO - 2026-02-22 14:44:54 --> Helper loaded: file_helper
INFO - 2026-02-22 14:44:54 --> Helper loaded: email_helper
INFO - 2026-02-22 14:44:54 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:44:54 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:44:54 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:44:54 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:44:54 --> Database Driver Class Initialized
INFO - 2026-02-22 14:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:44:56 --> Upload Class Initialized
DEBUG - 2026-02-22 14:44:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:44:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:44:56 --> Encryption Class Initialized
INFO - 2026-02-22 14:44:56 --> Form Validation Class Initialized
INFO - 2026-02-22 14:44:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:44:56 --> Pagination Class Initialized
INFO - 2026-02-22 14:44:56 --> Email Class Initialized
INFO - 2026-02-22 14:44:56 --> Controller Class Initialized
DEBUG - 2026-02-22 14:44:56 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:44:56 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:44:56 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:44:56 --> Model "Company_model" initialized
INFO - 2026-02-22 14:44:56 --> Model "Common_model" initialized
INFO - 2026-02-22 14:45:06 --> cPanel account terminated: narike8u
INFO - 2026-02-22 14:45:07 --> Config Class Initialized
INFO - 2026-02-22 14:45:07 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:45:07 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:45:07 --> Utf8 Class Initialized
INFO - 2026-02-22 14:45:07 --> Config Class Initialized
INFO - 2026-02-22 14:45:07 --> Hooks Class Initialized
INFO - 2026-02-22 14:45:07 --> URI Class Initialized
DEBUG - 2026-02-22 14:45:07 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:45:07 --> Utf8 Class Initialized
INFO - 2026-02-22 14:45:07 --> Router Class Initialized
INFO - 2026-02-22 14:45:07 --> URI Class Initialized
INFO - 2026-02-22 14:45:07 --> Output Class Initialized
INFO - 2026-02-22 14:45:07 --> Router Class Initialized
INFO - 2026-02-22 14:45:07 --> Security Class Initialized
DEBUG - 2026-02-22 14:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:45:07 --> Output Class Initialized
INFO - 2026-02-22 14:45:07 --> CSRF cookie sent
INFO - 2026-02-22 14:45:07 --> Input Class Initialized
INFO - 2026-02-22 14:45:07 --> Language Class Initialized
INFO - 2026-02-22 14:45:07 --> Language Class Initialized
INFO - 2026-02-22 14:45:07 --> Config Class Initialized
INFO - 2026-02-22 14:45:07 --> Security Class Initialized
DEBUG - 2026-02-22 14:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:45:07 --> CSRF cookie sent
INFO - 2026-02-22 14:45:07 --> Input Class Initialized
INFO - 2026-02-22 14:45:07 --> Language Class Initialized
INFO - 2026-02-22 14:45:07 --> Language Class Initialized
INFO - 2026-02-22 14:45:07 --> Config Class Initialized
INFO - 2026-02-22 14:45:07 --> Loader Class Initialized
INFO - 2026-02-22 14:45:07 --> Helper loaded: url_helper
INFO - 2026-02-22 14:45:07 --> Helper loaded: form_helper
INFO - 2026-02-22 14:45:07 --> Loader Class Initialized
INFO - 2026-02-22 14:45:07 --> Helper loaded: html_helper
INFO - 2026-02-22 14:45:07 --> Helper loaded: file_helper
INFO - 2026-02-22 14:45:07 --> Helper loaded: email_helper
INFO - 2026-02-22 14:45:07 --> Helper loaded: url_helper
INFO - 2026-02-22 14:45:07 --> Helper loaded: form_helper
INFO - 2026-02-22 14:45:07 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:45:07 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:45:07 --> Helper loaded: html_helper
INFO - 2026-02-22 14:45:07 --> Helper loaded: file_helper
INFO - 2026-02-22 14:45:07 --> Helper loaded: email_helper
INFO - 2026-02-22 14:45:07 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:45:07 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:45:07 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:45:07 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:45:07 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:45:07 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:45:07 --> Database Driver Class Initialized
INFO - 2026-02-22 14:45:07 --> Database Driver Class Initialized
INFO - 2026-02-22 14:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:45:09 --> Upload Class Initialized
DEBUG - 2026-02-22 14:45:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:45:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:45:09 --> Encryption Class Initialized
INFO - 2026-02-22 14:45:09 --> Form Validation Class Initialized
INFO - 2026-02-22 14:45:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:45:09 --> Pagination Class Initialized
INFO - 2026-02-22 14:45:09 --> Email Class Initialized
INFO - 2026-02-22 14:45:09 --> Controller Class Initialized
DEBUG - 2026-02-22 14:45:09 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:45:09 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:45:09 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:45:09 --> Model "Company_model" initialized
INFO - 2026-02-22 14:45:09 --> Model "Common_model" initialized
INFO - 2026-02-22 14:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:45:11 --> Upload Class Initialized
DEBUG - 2026-02-22 14:45:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:45:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:45:11 --> Encryption Class Initialized
INFO - 2026-02-22 14:45:11 --> Form Validation Class Initialized
INFO - 2026-02-22 14:45:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:45:11 --> Pagination Class Initialized
INFO - 2026-02-22 14:45:11 --> Email Class Initialized
INFO - 2026-02-22 14:45:11 --> Controller Class Initialized
DEBUG - 2026-02-22 14:45:11 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:45:11 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:45:11 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:45:11 --> Model "Company_model" initialized
INFO - 2026-02-22 14:45:11 --> Model "Common_model" initialized
INFO - 2026-02-22 14:45:33 --> Config Class Initialized
INFO - 2026-02-22 14:45:33 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:45:33 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:45:33 --> Utf8 Class Initialized
INFO - 2026-02-22 14:45:33 --> URI Class Initialized
INFO - 2026-02-22 14:45:33 --> Router Class Initialized
INFO - 2026-02-22 14:45:33 --> Output Class Initialized
INFO - 2026-02-22 14:45:33 --> Security Class Initialized
DEBUG - 2026-02-22 14:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:45:33 --> CSRF cookie sent
INFO - 2026-02-22 14:45:33 --> CSRF token verified
INFO - 2026-02-22 14:45:33 --> Input Class Initialized
INFO - 2026-02-22 14:45:33 --> Language Class Initialized
INFO - 2026-02-22 14:45:33 --> Language Class Initialized
INFO - 2026-02-22 14:45:33 --> Config Class Initialized
INFO - 2026-02-22 14:45:33 --> Loader Class Initialized
INFO - 2026-02-22 14:45:33 --> Helper loaded: url_helper
INFO - 2026-02-22 14:45:33 --> Helper loaded: form_helper
INFO - 2026-02-22 14:45:33 --> Helper loaded: html_helper
INFO - 2026-02-22 14:45:33 --> Helper loaded: file_helper
INFO - 2026-02-22 14:45:33 --> Helper loaded: email_helper
INFO - 2026-02-22 14:45:33 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:45:33 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:45:33 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:45:33 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:45:33 --> Database Driver Class Initialized
INFO - 2026-02-22 14:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:45:35 --> Upload Class Initialized
DEBUG - 2026-02-22 14:45:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:45:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:45:35 --> Encryption Class Initialized
INFO - 2026-02-22 14:45:35 --> Form Validation Class Initialized
INFO - 2026-02-22 14:45:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:45:35 --> Pagination Class Initialized
INFO - 2026-02-22 14:45:35 --> Email Class Initialized
INFO - 2026-02-22 14:45:35 --> Controller Class Initialized
DEBUG - 2026-02-22 14:45:35 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:45:35 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:45:35 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:45:35 --> Model "Company_model" initialized
INFO - 2026-02-22 14:45:35 --> Model "Common_model" initialized
INFO - 2026-02-22 14:45:36 --> Config Class Initialized
INFO - 2026-02-22 14:45:36 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:45:36 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:45:36 --> Utf8 Class Initialized
INFO - 2026-02-22 14:45:36 --> URI Class Initialized
INFO - 2026-02-22 14:45:36 --> Router Class Initialized
INFO - 2026-02-22 14:45:36 --> Output Class Initialized
INFO - 2026-02-22 14:45:36 --> Security Class Initialized
DEBUG - 2026-02-22 14:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:45:36 --> CSRF cookie sent
INFO - 2026-02-22 14:45:36 --> Input Class Initialized
INFO - 2026-02-22 14:45:36 --> Language Class Initialized
INFO - 2026-02-22 14:45:36 --> Language Class Initialized
INFO - 2026-02-22 14:45:36 --> Config Class Initialized
INFO - 2026-02-22 14:45:36 --> Loader Class Initialized
INFO - 2026-02-22 14:45:36 --> Helper loaded: url_helper
INFO - 2026-02-22 14:45:36 --> Helper loaded: form_helper
INFO - 2026-02-22 14:45:36 --> Helper loaded: html_helper
INFO - 2026-02-22 14:45:36 --> Helper loaded: file_helper
INFO - 2026-02-22 14:45:36 --> Helper loaded: email_helper
INFO - 2026-02-22 14:45:36 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:45:36 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:45:36 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:45:36 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:45:36 --> Database Driver Class Initialized
INFO - 2026-02-22 14:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:45:39 --> Upload Class Initialized
DEBUG - 2026-02-22 14:45:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:45:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:45:39 --> Encryption Class Initialized
INFO - 2026-02-22 14:45:39 --> Form Validation Class Initialized
INFO - 2026-02-22 14:45:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:45:39 --> Pagination Class Initialized
INFO - 2026-02-22 14:45:39 --> Email Class Initialized
INFO - 2026-02-22 14:45:39 --> Controller Class Initialized
DEBUG - 2026-02-22 14:45:39 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:45:39 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:45:39 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:45:39 --> Model "Company_model" initialized
INFO - 2026-02-22 14:45:39 --> Model "Common_model" initialized
INFO - 2026-02-22 14:47:53 --> Config Class Initialized
INFO - 2026-02-22 14:47:53 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:47:53 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:47:53 --> Utf8 Class Initialized
INFO - 2026-02-22 14:47:53 --> URI Class Initialized
INFO - 2026-02-22 14:47:53 --> Router Class Initialized
INFO - 2026-02-22 14:47:53 --> Output Class Initialized
INFO - 2026-02-22 14:47:53 --> Security Class Initialized
DEBUG - 2026-02-22 14:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:47:53 --> CSRF cookie sent
INFO - 2026-02-22 14:47:53 --> Input Class Initialized
INFO - 2026-02-22 14:47:53 --> Language Class Initialized
INFO - 2026-02-22 14:47:53 --> Language Class Initialized
INFO - 2026-02-22 14:47:53 --> Config Class Initialized
INFO - 2026-02-22 14:47:53 --> Loader Class Initialized
INFO - 2026-02-22 14:47:53 --> Helper loaded: url_helper
INFO - 2026-02-22 14:47:53 --> Helper loaded: form_helper
INFO - 2026-02-22 14:47:53 --> Helper loaded: html_helper
INFO - 2026-02-22 14:47:53 --> Helper loaded: file_helper
INFO - 2026-02-22 14:47:53 --> Helper loaded: email_helper
INFO - 2026-02-22 14:47:53 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:47:53 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:47:53 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:47:53 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:47:53 --> Database Driver Class Initialized
INFO - 2026-02-22 14:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:47:55 --> Upload Class Initialized
DEBUG - 2026-02-22 14:47:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:47:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:47:55 --> Encryption Class Initialized
INFO - 2026-02-22 14:47:55 --> Form Validation Class Initialized
INFO - 2026-02-22 14:47:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:47:55 --> Pagination Class Initialized
INFO - 2026-02-22 14:47:55 --> Email Class Initialized
INFO - 2026-02-22 14:47:55 --> Controller Class Initialized
ERROR - 2026-02-22 14:47:55 --> 404 Page Not Found: whmazadmin/Pages/index
INFO - 2026-02-22 14:48:07 --> Config Class Initialized
INFO - 2026-02-22 14:48:07 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:48:07 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:07 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:07 --> URI Class Initialized
INFO - 2026-02-22 14:48:07 --> Router Class Initialized
INFO - 2026-02-22 14:48:07 --> Output Class Initialized
INFO - 2026-02-22 14:48:07 --> Security Class Initialized
DEBUG - 2026-02-22 14:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:07 --> CSRF cookie sent
INFO - 2026-02-22 14:48:07 --> Input Class Initialized
INFO - 2026-02-22 14:48:07 --> Language Class Initialized
INFO - 2026-02-22 14:48:07 --> Language Class Initialized
INFO - 2026-02-22 14:48:07 --> Config Class Initialized
INFO - 2026-02-22 14:48:07 --> Loader Class Initialized
INFO - 2026-02-22 14:48:07 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:07 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:07 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:07 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:07 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:07 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:07 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:07 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:07 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:07 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:09 --> Upload Class Initialized
DEBUG - 2026-02-22 14:48:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:09 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:09 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:09 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:09 --> Email Class Initialized
INFO - 2026-02-22 14:48:09 --> Controller Class Initialized
DEBUG - 2026-02-22 14:48:09 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:48:09 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:48:09 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:48:09 --> Model "Company_model" initialized
INFO - 2026-02-22 14:48:09 --> Model "Common_model" initialized
DEBUG - 2026-02-22 14:48:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:48:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:48:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:48:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:48:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:48:11 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/company_manage.php
INFO - 2026-02-22 14:48:11 --> Final output sent to browser
DEBUG - 2026-02-22 14:48:11 --> Total execution time: 3.4049
INFO - 2026-02-22 14:48:11 --> Config Class Initialized
INFO - 2026-02-22 14:48:11 --> Hooks Class Initialized
INFO - 2026-02-22 14:48:11 --> Config Class Initialized
INFO - 2026-02-22 14:48:11 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:48:11 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:11 --> Utf8 Class Initialized
DEBUG - 2026-02-22 14:48:11 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:11 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:11 --> URI Class Initialized
INFO - 2026-02-22 14:48:11 --> URI Class Initialized
INFO - 2026-02-22 14:48:11 --> Router Class Initialized
INFO - 2026-02-22 14:48:11 --> Router Class Initialized
INFO - 2026-02-22 14:48:11 --> Output Class Initialized
INFO - 2026-02-22 14:48:11 --> Security Class Initialized
INFO - 2026-02-22 14:48:11 --> Output Class Initialized
DEBUG - 2026-02-22 14:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:11 --> CSRF cookie sent
INFO - 2026-02-22 14:48:11 --> Input Class Initialized
INFO - 2026-02-22 14:48:11 --> Language Class Initialized
INFO - 2026-02-22 14:48:11 --> Security Class Initialized
INFO - 2026-02-22 14:48:11 --> Language Class Initialized
INFO - 2026-02-22 14:48:11 --> Config Class Initialized
DEBUG - 2026-02-22 14:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:11 --> CSRF cookie sent
INFO - 2026-02-22 14:48:11 --> Input Class Initialized
INFO - 2026-02-22 14:48:11 --> Language Class Initialized
INFO - 2026-02-22 14:48:11 --> Language Class Initialized
INFO - 2026-02-22 14:48:11 --> Config Class Initialized
INFO - 2026-02-22 14:48:11 --> Loader Class Initialized
INFO - 2026-02-22 14:48:11 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:11 --> Loader Class Initialized
INFO - 2026-02-22 14:48:11 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:11 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:11 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:11 --> Config Class Initialized
INFO - 2026-02-22 14:48:11 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:48:11 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:11 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:11 --> URI Class Initialized
INFO - 2026-02-22 14:48:11 --> Router Class Initialized
INFO - 2026-02-22 14:48:11 --> Output Class Initialized
INFO - 2026-02-22 14:48:11 --> Security Class Initialized
DEBUG - 2026-02-22 14:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:11 --> CSRF cookie sent
INFO - 2026-02-22 14:48:11 --> Input Class Initialized
INFO - 2026-02-22 14:48:11 --> Language Class Initialized
INFO - 2026-02-22 14:48:11 --> Language Class Initialized
INFO - 2026-02-22 14:48:11 --> Config Class Initialized
INFO - 2026-02-22 14:48:11 --> Config Class Initialized
INFO - 2026-02-22 14:48:11 --> Hooks Class Initialized
INFO - 2026-02-22 14:48:11 --> Loader Class Initialized
INFO - 2026-02-22 14:48:11 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: email_helper
DEBUG - 2026-02-22 14:48:11 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:11 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:11 --> URI Class Initialized
INFO - 2026-02-22 14:48:11 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:11 --> Config Class Initialized
INFO - 2026-02-22 14:48:11 --> Hooks Class Initialized
INFO - 2026-02-22 14:48:11 --> Helper loaded: domain_helper
DEBUG - 2026-02-22 14:48:11 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:11 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:11 --> URI Class Initialized
INFO - 2026-02-22 14:48:11 --> Router Class Initialized
INFO - 2026-02-22 14:48:11 --> Config Class Initialized
INFO - 2026-02-22 14:48:11 --> Hooks Class Initialized
INFO - 2026-02-22 14:48:11 --> Output Class Initialized
DEBUG - 2026-02-22 14:48:11 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:11 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:11 --> Router Class Initialized
INFO - 2026-02-22 14:48:11 --> URI Class Initialized
INFO - 2026-02-22 14:48:11 --> Security Class Initialized
INFO - 2026-02-22 14:48:11 --> Output Class Initialized
DEBUG - 2026-02-22 14:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:11 --> Security Class Initialized
INFO - 2026-02-22 14:48:11 --> CSRF cookie sent
INFO - 2026-02-22 14:48:11 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:11 --> Input Class Initialized
INFO - 2026-02-22 14:48:11 --> Language Class Initialized
DEBUG - 2026-02-22 14:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:11 --> CSRF cookie sent
INFO - 2026-02-22 14:48:11 --> Input Class Initialized
INFO - 2026-02-22 14:48:11 --> Language Class Initialized
INFO - 2026-02-22 14:48:11 --> Language Class Initialized
INFO - 2026-02-22 14:48:11 --> Config Class Initialized
INFO - 2026-02-22 14:48:11 --> Language Class Initialized
INFO - 2026-02-22 14:48:11 --> Config Class Initialized
INFO - 2026-02-22 14:48:11 --> Router Class Initialized
INFO - 2026-02-22 14:48:11 --> Loader Class Initialized
INFO - 2026-02-22 14:48:11 --> Loader Class Initialized
INFO - 2026-02-22 14:48:11 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:11 --> Output Class Initialized
INFO - 2026-02-22 14:48:11 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:11 --> Security Class Initialized
INFO - 2026-02-22 14:48:11 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: html_helper
DEBUG - 2026-02-22 14:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:11 --> CSRF cookie sent
INFO - 2026-02-22 14:48:11 --> Input Class Initialized
INFO - 2026-02-22 14:48:11 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:11 --> Language Class Initialized
INFO - 2026-02-22 14:48:11 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:11 --> Language Class Initialized
INFO - 2026-02-22 14:48:11 --> Config Class Initialized
INFO - 2026-02-22 14:48:11 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:11 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:11 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:11 --> Loader Class Initialized
INFO - 2026-02-22 14:48:11 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:11 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:11 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:11 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:11 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:13 --> Upload Class Initialized
DEBUG - 2026-02-22 14:48:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:13 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:13 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:13 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:13 --> Email Class Initialized
INFO - 2026-02-22 14:48:13 --> Controller Class Initialized
ERROR - 2026-02-22 14:48:13 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:13 --> Upload Class Initialized
DEBUG - 2026-02-22 14:48:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:13 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:13 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:13 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:13 --> Config Class Initialized
INFO - 2026-02-22 14:48:13 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:48:13 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:13 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:13 --> URI Class Initialized
INFO - 2026-02-22 14:48:13 --> Email Class Initialized
INFO - 2026-02-22 14:48:13 --> Controller Class Initialized
ERROR - 2026-02-22 14:48:13 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:48:13 --> Router Class Initialized
INFO - 2026-02-22 14:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:13 --> Output Class Initialized
INFO - 2026-02-22 14:48:13 --> Upload Class Initialized
DEBUG - 2026-02-22 14:48:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:13 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:13 --> Security Class Initialized
DEBUG - 2026-02-22 14:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:13 --> CSRF cookie sent
INFO - 2026-02-22 14:48:13 --> Input Class Initialized
INFO - 2026-02-22 14:48:13 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:13 --> Language Class Initialized
INFO - 2026-02-22 14:48:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:13 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:13 --> Language Class Initialized
INFO - 2026-02-22 14:48:13 --> Config Class Initialized
INFO - 2026-02-22 14:48:13 --> Loader Class Initialized
INFO - 2026-02-22 14:48:13 --> Email Class Initialized
INFO - 2026-02-22 14:48:13 --> Controller Class Initialized
INFO - 2026-02-22 14:48:13 --> Config Class Initialized
INFO - 2026-02-22 14:48:13 --> Hooks Class Initialized
INFO - 2026-02-22 14:48:13 --> Helper loaded: url_helper
ERROR - 2026-02-22 14:48:13 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:48:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-02-22 14:48:13 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:13 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:13 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:13 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:13 --> URI Class Initialized
INFO - 2026-02-22 14:48:13 --> Upload Class Initialized
INFO - 2026-02-22 14:48:13 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:13 --> Helper loaded: email_helper
DEBUG - 2026-02-22 14:48:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:13 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:13 --> Router Class Initialized
INFO - 2026-02-22 14:48:13 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:13 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:13 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:13 --> Output Class Initialized
INFO - 2026-02-22 14:48:13 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:13 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:13 --> Security Class Initialized
INFO - 2026-02-22 14:48:13 --> Helper loaded: domain_helper
DEBUG - 2026-02-22 14:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:13 --> CSRF cookie sent
INFO - 2026-02-22 14:48:13 --> Input Class Initialized
INFO - 2026-02-22 14:48:13 --> Language Class Initialized
INFO - 2026-02-22 14:48:13 --> Language Class Initialized
INFO - 2026-02-22 14:48:13 --> Config Class Initialized
INFO - 2026-02-22 14:48:13 --> Config Class Initialized
INFO - 2026-02-22 14:48:13 --> Hooks Class Initialized
INFO - 2026-02-22 14:48:13 --> Email Class Initialized
INFO - 2026-02-22 14:48:13 --> Controller Class Initialized
ERROR - 2026-02-22 14:48:13 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:48:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-02-22 14:48:13 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:13 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:13 --> Loader Class Initialized
INFO - 2026-02-22 14:48:13 --> URI Class Initialized
INFO - 2026-02-22 14:48:13 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:13 --> Upload Class Initialized
INFO - 2026-02-22 14:48:13 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:13 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:13 --> Router Class Initialized
INFO - 2026-02-22 14:48:13 --> Helper loaded: html_helper
DEBUG - 2026-02-22 14:48:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:13 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:13 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:13 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:13 --> Output Class Initialized
INFO - 2026-02-22 14:48:13 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:13 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:13 --> Security Class Initialized
INFO - 2026-02-22 14:48:13 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:13 --> Config Class Initialized
INFO - 2026-02-22 14:48:13 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:13 --> Hooks Class Initialized
INFO - 2026-02-22 14:48:13 --> Helper loaded: domain_helper
DEBUG - 2026-02-22 14:48:13 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:13 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:13 --> Pagination Class Initialized
DEBUG - 2026-02-22 14:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:13 --> CSRF cookie sent
INFO - 2026-02-22 14:48:13 --> Input Class Initialized
INFO - 2026-02-22 14:48:13 --> Language Class Initialized
INFO - 2026-02-22 14:48:13 --> URI Class Initialized
INFO - 2026-02-22 14:48:13 --> Language Class Initialized
INFO - 2026-02-22 14:48:13 --> Config Class Initialized
INFO - 2026-02-22 14:48:13 --> Router Class Initialized
INFO - 2026-02-22 14:48:13 --> Output Class Initialized
INFO - 2026-02-22 14:48:13 --> Security Class Initialized
INFO - 2026-02-22 14:48:13 --> Email Class Initialized
INFO - 2026-02-22 14:48:13 --> Controller Class Initialized
DEBUG - 2026-02-22 14:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:13 --> CSRF cookie sent
INFO - 2026-02-22 14:48:13 --> Input Class Initialized
ERROR - 2026-02-22 14:48:13 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:48:13 --> Loader Class Initialized
INFO - 2026-02-22 14:48:13 --> Language Class Initialized
INFO - 2026-02-22 14:48:13 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:13 --> Language Class Initialized
INFO - 2026-02-22 14:48:13 --> Config Class Initialized
INFO - 2026-02-22 14:48:13 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:13 --> Upload Class Initialized
INFO - 2026-02-22 14:48:13 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:13 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:13 --> Loader Class Initialized
DEBUG - 2026-02-22 14:48:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:13 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:13 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:13 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:13 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:13 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:13 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:13 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:13 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:13 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:13 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:13 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:13 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:13 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:13 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:13 --> Email Class Initialized
INFO - 2026-02-22 14:48:13 --> Controller Class Initialized
INFO - 2026-02-22 14:48:13 --> Helper loaded: whmaz_helper
ERROR - 2026-02-22 14:48:13 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:48:13 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:13 --> Config Class Initialized
INFO - 2026-02-22 14:48:13 --> Hooks Class Initialized
INFO - 2026-02-22 14:48:13 --> Helper loaded: cpanel_helper
DEBUG - 2026-02-22 14:48:13 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:13 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:13 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:13 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:13 --> URI Class Initialized
INFO - 2026-02-22 14:48:13 --> Router Class Initialized
INFO - 2026-02-22 14:48:13 --> Output Class Initialized
INFO - 2026-02-22 14:48:13 --> Security Class Initialized
DEBUG - 2026-02-22 14:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:13 --> CSRF cookie sent
INFO - 2026-02-22 14:48:13 --> Input Class Initialized
INFO - 2026-02-22 14:48:13 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:13 --> Language Class Initialized
INFO - 2026-02-22 14:48:13 --> Language Class Initialized
INFO - 2026-02-22 14:48:13 --> Config Class Initialized
INFO - 2026-02-22 14:48:13 --> Loader Class Initialized
INFO - 2026-02-22 14:48:13 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:13 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:13 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:13 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:13 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:13 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:13 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:13 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:13 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:13 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:15 --> Upload Class Initialized
DEBUG - 2026-02-22 14:48:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:15 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:15 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:15 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:15 --> Email Class Initialized
INFO - 2026-02-22 14:48:15 --> Controller Class Initialized
DEBUG - 2026-02-22 14:48:15 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:48:15 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:48:15 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:48:15 --> Model "Company_model" initialized
INFO - 2026-02-22 14:48:15 --> Model "Common_model" initialized
INFO - 2026-02-22 14:48:16 --> Config Class Initialized
INFO - 2026-02-22 14:48:16 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:48:16 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:16 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:16 --> URI Class Initialized
INFO - 2026-02-22 14:48:16 --> Router Class Initialized
INFO - 2026-02-22 14:48:16 --> Output Class Initialized
INFO - 2026-02-22 14:48:16 --> Security Class Initialized
DEBUG - 2026-02-22 14:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:16 --> CSRF cookie sent
INFO - 2026-02-22 14:48:16 --> Input Class Initialized
INFO - 2026-02-22 14:48:16 --> Language Class Initialized
INFO - 2026-02-22 14:48:16 --> Language Class Initialized
INFO - 2026-02-22 14:48:16 --> Config Class Initialized
INFO - 2026-02-22 14:48:16 --> Loader Class Initialized
INFO - 2026-02-22 14:48:16 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:16 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:16 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:16 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:16 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:16 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:16 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:16 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:16 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:16 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:17 --> Upload Class Initialized
DEBUG - 2026-02-22 14:48:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:17 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:17 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:17 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:17 --> Email Class Initialized
INFO - 2026-02-22 14:48:17 --> Controller Class Initialized
DEBUG - 2026-02-22 14:48:17 --> Company MX_Controller Initialized
INFO - 2026-02-22 14:48:17 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:48:17 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:48:17 --> Model "Company_model" initialized
INFO - 2026-02-22 14:48:17 --> Model "Common_model" initialized
INFO - 2026-02-22 14:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:19 --> Upload Class Initialized
DEBUG - 2026-02-22 14:48:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:19 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:19 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:19 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:19 --> Email Class Initialized
INFO - 2026-02-22 14:48:19 --> Controller Class Initialized
ERROR - 2026-02-22 14:48:19 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:19 --> Upload Class Initialized
DEBUG - 2026-02-22 14:48:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:19 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:19 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:19 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:19 --> Email Class Initialized
INFO - 2026-02-22 14:48:19 --> Controller Class Initialized
ERROR - 2026-02-22 14:48:19 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:19 --> Upload Class Initialized
DEBUG - 2026-02-22 14:48:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:19 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:19 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:19 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:19 --> Email Class Initialized
INFO - 2026-02-22 14:48:19 --> Controller Class Initialized
DEBUG - 2026-02-22 14:48:19 --> Invoice MX_Controller Initialized
INFO - 2026-02-22 14:48:19 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:48:19 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:48:19 --> Model "Billing_model" initialized
INFO - 2026-02-22 14:48:19 --> Model "Common_model" initialized
INFO - 2026-02-22 14:48:19 --> Model "Invoice_model" initialized
INFO - 2026-02-22 14:48:19 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 14:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:21 --> Upload Class Initialized
DEBUG - 2026-02-22 14:48:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:21 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:21 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:21 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:21 --> Email Class Initialized
INFO - 2026-02-22 14:48:21 --> Controller Class Initialized
DEBUG - 2026-02-22 14:48:21 --> Email_template MX_Controller Initialized
INFO - 2026-02-22 14:48:21 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:48:21 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:48:21 --> Model "Emailtemplate_model" initialized
DEBUG - 2026-02-22 14:48:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:48:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:48:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:48:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:48:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:48:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/email_template_list.php
INFO - 2026-02-22 14:48:21 --> Final output sent to browser
DEBUG - 2026-02-22 14:48:21 --> Total execution time: 5.0517
INFO - 2026-02-22 14:48:21 --> Config Class Initialized
INFO - 2026-02-22 14:48:21 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:48:21 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:21 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:21 --> URI Class Initialized
INFO - 2026-02-22 14:48:21 --> Config Class Initialized
INFO - 2026-02-22 14:48:21 --> Hooks Class Initialized
INFO - 2026-02-22 14:48:21 --> Router Class Initialized
DEBUG - 2026-02-22 14:48:21 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:21 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:21 --> URI Class Initialized
INFO - 2026-02-22 14:48:21 --> Output Class Initialized
INFO - 2026-02-22 14:48:21 --> Security Class Initialized
INFO - 2026-02-22 14:48:21 --> Router Class Initialized
DEBUG - 2026-02-22 14:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:21 --> CSRF cookie sent
INFO - 2026-02-22 14:48:21 --> Input Class Initialized
INFO - 2026-02-22 14:48:21 --> Language Class Initialized
INFO - 2026-02-22 14:48:21 --> Output Class Initialized
INFO - 2026-02-22 14:48:21 --> Language Class Initialized
INFO - 2026-02-22 14:48:21 --> Config Class Initialized
INFO - 2026-02-22 14:48:21 --> Security Class Initialized
DEBUG - 2026-02-22 14:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:21 --> CSRF cookie sent
INFO - 2026-02-22 14:48:21 --> Input Class Initialized
INFO - 2026-02-22 14:48:21 --> Language Class Initialized
INFO - 2026-02-22 14:48:21 --> Loader Class Initialized
INFO - 2026-02-22 14:48:21 --> Language Class Initialized
INFO - 2026-02-22 14:48:21 --> Config Class Initialized
INFO - 2026-02-22 14:48:21 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:21 --> Loader Class Initialized
INFO - 2026-02-22 14:48:21 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:21 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:21 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:21 --> Config Class Initialized
INFO - 2026-02-22 14:48:21 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:48:21 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:21 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:21 --> URI Class Initialized
INFO - 2026-02-22 14:48:21 --> Config Class Initialized
INFO - 2026-02-22 14:48:21 --> Hooks Class Initialized
INFO - 2026-02-22 14:48:21 --> Config Class Initialized
INFO - 2026-02-22 14:48:21 --> Hooks Class Initialized
INFO - 2026-02-22 14:48:21 --> Router Class Initialized
DEBUG - 2026-02-22 14:48:21 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:21 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:21 --> URI Class Initialized
INFO - 2026-02-22 14:48:21 --> Config Class Initialized
INFO - 2026-02-22 14:48:21 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:48:21 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:21 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:21 --> Output Class Initialized
INFO - 2026-02-22 14:48:21 --> URI Class Initialized
INFO - 2026-02-22 14:48:21 --> Router Class Initialized
DEBUG - 2026-02-22 14:48:21 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:21 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:21 --> Security Class Initialized
INFO - 2026-02-22 14:48:21 --> URI Class Initialized
INFO - 2026-02-22 14:48:21 --> Output Class Initialized
DEBUG - 2026-02-22 14:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:21 --> Router Class Initialized
INFO - 2026-02-22 14:48:21 --> CSRF cookie sent
INFO - 2026-02-22 14:48:21 --> Input Class Initialized
INFO - 2026-02-22 14:48:21 --> Language Class Initialized
INFO - 2026-02-22 14:48:21 --> Security Class Initialized
INFO - 2026-02-22 14:48:21 --> Router Class Initialized
INFO - 2026-02-22 14:48:21 --> Language Class Initialized
INFO - 2026-02-22 14:48:21 --> Config Class Initialized
DEBUG - 2026-02-22 14:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:21 --> CSRF cookie sent
INFO - 2026-02-22 14:48:21 --> Input Class Initialized
INFO - 2026-02-22 14:48:21 --> Output Class Initialized
INFO - 2026-02-22 14:48:21 --> Language Class Initialized
INFO - 2026-02-22 14:48:21 --> Language Class Initialized
INFO - 2026-02-22 14:48:21 --> Config Class Initialized
INFO - 2026-02-22 14:48:21 --> Output Class Initialized
INFO - 2026-02-22 14:48:21 --> Security Class Initialized
INFO - 2026-02-22 14:48:21 --> Security Class Initialized
DEBUG - 2026-02-22 14:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:21 --> CSRF cookie sent
INFO - 2026-02-22 14:48:21 --> Input Class Initialized
INFO - 2026-02-22 14:48:21 --> Loader Class Initialized
INFO - 2026-02-22 14:48:21 --> Language Class Initialized
INFO - 2026-02-22 14:48:21 --> Loader Class Initialized
DEBUG - 2026-02-22 14:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:21 --> CSRF cookie sent
INFO - 2026-02-22 14:48:21 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:21 --> Input Class Initialized
INFO - 2026-02-22 14:48:21 --> Language Class Initialized
INFO - 2026-02-22 14:48:21 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:21 --> Config Class Initialized
INFO - 2026-02-22 14:48:21 --> Language Class Initialized
INFO - 2026-02-22 14:48:21 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:21 --> Language Class Initialized
INFO - 2026-02-22 14:48:21 --> Config Class Initialized
INFO - 2026-02-22 14:48:21 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:21 --> Loader Class Initialized
INFO - 2026-02-22 14:48:21 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:21 --> Loader Class Initialized
INFO - 2026-02-22 14:48:21 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:21 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:21 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:21 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:21 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:21 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:23 --> Upload Class Initialized
DEBUG - 2026-02-22 14:48:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:23 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:23 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:23 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:23 --> Email Class Initialized
INFO - 2026-02-22 14:48:23 --> Controller Class Initialized
ERROR - 2026-02-22 14:48:23 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:23 --> Upload Class Initialized
DEBUG - 2026-02-22 14:48:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:23 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:23 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:23 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:23 --> Config Class Initialized
INFO - 2026-02-22 14:48:23 --> Hooks Class Initialized
INFO - 2026-02-22 14:48:23 --> Email Class Initialized
INFO - 2026-02-22 14:48:23 --> Controller Class Initialized
ERROR - 2026-02-22 14:48:23 --> 404 Page Not Found: /index
DEBUG - 2026-02-22 14:48:23 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:23 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:23 --> URI Class Initialized
INFO - 2026-02-22 14:48:23 --> Router Class Initialized
INFO - 2026-02-22 14:48:23 --> Output Class Initialized
INFO - 2026-02-22 14:48:23 --> Security Class Initialized
DEBUG - 2026-02-22 14:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:23 --> CSRF cookie sent
INFO - 2026-02-22 14:48:23 --> Input Class Initialized
INFO - 2026-02-22 14:48:23 --> Language Class Initialized
INFO - 2026-02-22 14:48:23 --> Language Class Initialized
INFO - 2026-02-22 14:48:23 --> Config Class Initialized
INFO - 2026-02-22 14:48:23 --> Config Class Initialized
INFO - 2026-02-22 14:48:23 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:48:23 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:23 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:23 --> URI Class Initialized
INFO - 2026-02-22 14:48:23 --> Loader Class Initialized
INFO - 2026-02-22 14:48:23 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:23 --> Router Class Initialized
INFO - 2026-02-22 14:48:23 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:23 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:23 --> Output Class Initialized
INFO - 2026-02-22 14:48:23 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:23 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:23 --> Security Class Initialized
DEBUG - 2026-02-22 14:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:23 --> CSRF cookie sent
INFO - 2026-02-22 14:48:23 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:23 --> Input Class Initialized
INFO - 2026-02-22 14:48:23 --> Language Class Initialized
INFO - 2026-02-22 14:48:23 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:23 --> Language Class Initialized
INFO - 2026-02-22 14:48:23 --> Config Class Initialized
INFO - 2026-02-22 14:48:23 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:23 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:23 --> Loader Class Initialized
INFO - 2026-02-22 14:48:23 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:23 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:23 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:23 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:23 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:23 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:23 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:23 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:23 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:23 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:23 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:23 --> Upload Class Initialized
DEBUG - 2026-02-22 14:48:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:23 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:23 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:23 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:23 --> Email Class Initialized
INFO - 2026-02-22 14:48:23 --> Controller Class Initialized
ERROR - 2026-02-22 14:48:23 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:23 --> Upload Class Initialized
DEBUG - 2026-02-22 14:48:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:23 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:23 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:23 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:23 --> Config Class Initialized
INFO - 2026-02-22 14:48:23 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:48:23 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:23 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:23 --> URI Class Initialized
INFO - 2026-02-22 14:48:23 --> Email Class Initialized
INFO - 2026-02-22 14:48:23 --> Controller Class Initialized
ERROR - 2026-02-22 14:48:23 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:48:23 --> Router Class Initialized
INFO - 2026-02-22 14:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:23 --> Output Class Initialized
INFO - 2026-02-22 14:48:23 --> Upload Class Initialized
INFO - 2026-02-22 14:48:23 --> Security Class Initialized
DEBUG - 2026-02-22 14:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:23 --> CSRF cookie sent
INFO - 2026-02-22 14:48:23 --> Input Class Initialized
INFO - 2026-02-22 14:48:23 --> Language Class Initialized
DEBUG - 2026-02-22 14:48:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:23 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:23 --> Language Class Initialized
INFO - 2026-02-22 14:48:23 --> Config Class Initialized
INFO - 2026-02-22 14:48:23 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:23 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:23 --> Loader Class Initialized
INFO - 2026-02-22 14:48:23 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:23 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:23 --> Email Class Initialized
INFO - 2026-02-22 14:48:23 --> Controller Class Initialized
INFO - 2026-02-22 14:48:23 --> Helper loaded: html_helper
ERROR - 2026-02-22 14:48:23 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:48:23 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:23 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:23 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:23 --> Upload Class Initialized
INFO - 2026-02-22 14:48:23 --> Helper loaded: ssp_helper
DEBUG - 2026-02-22 14:48:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:23 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:23 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:23 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:23 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:23 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:23 --> Email Class Initialized
INFO - 2026-02-22 14:48:23 --> Controller Class Initialized
ERROR - 2026-02-22 14:48:23 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:48:23 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:26 --> Upload Class Initialized
DEBUG - 2026-02-22 14:48:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:26 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:26 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:26 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:26 --> Email Class Initialized
INFO - 2026-02-22 14:48:26 --> Controller Class Initialized
ERROR - 2026-02-22 14:48:26 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:26 --> Upload Class Initialized
DEBUG - 2026-02-22 14:48:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:26 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:26 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:26 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:26 --> Email Class Initialized
INFO - 2026-02-22 14:48:26 --> Controller Class Initialized
DEBUG - 2026-02-22 14:48:26 --> Email_template MX_Controller Initialized
INFO - 2026-02-22 14:48:26 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:48:26 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:48:26 --> Model "Emailtemplate_model" initialized
INFO - 2026-02-22 14:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:28 --> Upload Class Initialized
DEBUG - 2026-02-22 14:48:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:28 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:28 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:28 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:28 --> Email Class Initialized
INFO - 2026-02-22 14:48:28 --> Controller Class Initialized
ERROR - 2026-02-22 14:48:28 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:48:34 --> Config Class Initialized
INFO - 2026-02-22 14:48:34 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:48:34 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:34 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:34 --> URI Class Initialized
INFO - 2026-02-22 14:48:34 --> Router Class Initialized
INFO - 2026-02-22 14:48:34 --> Output Class Initialized
INFO - 2026-02-22 14:48:34 --> Security Class Initialized
DEBUG - 2026-02-22 14:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:34 --> CSRF cookie sent
INFO - 2026-02-22 14:48:34 --> Input Class Initialized
INFO - 2026-02-22 14:48:34 --> Language Class Initialized
INFO - 2026-02-22 14:48:34 --> Language Class Initialized
INFO - 2026-02-22 14:48:34 --> Config Class Initialized
INFO - 2026-02-22 14:48:34 --> Loader Class Initialized
INFO - 2026-02-22 14:48:34 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:34 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:34 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:34 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:34 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:34 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:34 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:34 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:34 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:34 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:36 --> Upload Class Initialized
DEBUG - 2026-02-22 14:48:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:36 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:36 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:36 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:36 --> Email Class Initialized
INFO - 2026-02-22 14:48:36 --> Controller Class Initialized
DEBUG - 2026-02-22 14:48:36 --> Domain_pricing MX_Controller Initialized
INFO - 2026-02-22 14:48:36 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:48:36 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:48:36 --> Model "Domainpricing_model" initialized
INFO - 2026-02-22 14:48:36 --> Model "Common_model" initialized
DEBUG - 2026-02-22 14:48:37 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:48:37 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:48:37 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:48:37 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:48:37 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:48:37 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/domain_pricing_list.php
INFO - 2026-02-22 14:48:37 --> Final output sent to browser
DEBUG - 2026-02-22 14:48:37 --> Total execution time: 2.5461
INFO - 2026-02-22 14:48:37 --> Config Class Initialized
INFO - 2026-02-22 14:48:37 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:48:37 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:37 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:37 --> URI Class Initialized
INFO - 2026-02-22 14:48:37 --> Router Class Initialized
INFO - 2026-02-22 14:48:37 --> Output Class Initialized
INFO - 2026-02-22 14:48:37 --> Security Class Initialized
DEBUG - 2026-02-22 14:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:37 --> CSRF cookie sent
INFO - 2026-02-22 14:48:37 --> Input Class Initialized
INFO - 2026-02-22 14:48:37 --> Language Class Initialized
INFO - 2026-02-22 14:48:37 --> Language Class Initialized
INFO - 2026-02-22 14:48:37 --> Config Class Initialized
INFO - 2026-02-22 14:48:37 --> Loader Class Initialized
INFO - 2026-02-22 14:48:37 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:37 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:37 --> Config Class Initialized
INFO - 2026-02-22 14:48:37 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:48:37 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:37 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:37 --> URI Class Initialized
INFO - 2026-02-22 14:48:37 --> Router Class Initialized
INFO - 2026-02-22 14:48:37 --> Output Class Initialized
INFO - 2026-02-22 14:48:37 --> Security Class Initialized
DEBUG - 2026-02-22 14:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:37 --> CSRF cookie sent
INFO - 2026-02-22 14:48:37 --> Input Class Initialized
INFO - 2026-02-22 14:48:37 --> Language Class Initialized
INFO - 2026-02-22 14:48:37 --> Language Class Initialized
INFO - 2026-02-22 14:48:37 --> Config Class Initialized
INFO - 2026-02-22 14:48:37 --> Loader Class Initialized
INFO - 2026-02-22 14:48:37 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:37 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:37 --> Config Class Initialized
INFO - 2026-02-22 14:48:37 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:48:37 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:37 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:37 --> URI Class Initialized
INFO - 2026-02-22 14:48:37 --> Router Class Initialized
INFO - 2026-02-22 14:48:37 --> Output Class Initialized
INFO - 2026-02-22 14:48:37 --> Security Class Initialized
DEBUG - 2026-02-22 14:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:37 --> CSRF cookie sent
INFO - 2026-02-22 14:48:37 --> Input Class Initialized
INFO - 2026-02-22 14:48:37 --> Language Class Initialized
INFO - 2026-02-22 14:48:37 --> Language Class Initialized
INFO - 2026-02-22 14:48:37 --> Config Class Initialized
INFO - 2026-02-22 14:48:37 --> Loader Class Initialized
INFO - 2026-02-22 14:48:37 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:37 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:37 --> Config Class Initialized
INFO - 2026-02-22 14:48:37 --> Hooks Class Initialized
INFO - 2026-02-22 14:48:37 --> Config Class Initialized
INFO - 2026-02-22 14:48:37 --> Hooks Class Initialized
INFO - 2026-02-22 14:48:37 --> Config Class Initialized
INFO - 2026-02-22 14:48:37 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:48:37 --> UTF-8 Support Enabled
DEBUG - 2026-02-22 14:48:37 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:37 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:37 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:37 --> URI Class Initialized
INFO - 2026-02-22 14:48:37 --> URI Class Initialized
DEBUG - 2026-02-22 14:48:37 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:37 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:37 --> URI Class Initialized
INFO - 2026-02-22 14:48:37 --> Router Class Initialized
INFO - 2026-02-22 14:48:37 --> Router Class Initialized
INFO - 2026-02-22 14:48:37 --> Output Class Initialized
INFO - 2026-02-22 14:48:37 --> Output Class Initialized
INFO - 2026-02-22 14:48:37 --> Router Class Initialized
INFO - 2026-02-22 14:48:37 --> Security Class Initialized
INFO - 2026-02-22 14:48:37 --> Security Class Initialized
INFO - 2026-02-22 14:48:37 --> Output Class Initialized
DEBUG - 2026-02-22 14:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-02-22 14:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:37 --> CSRF cookie sent
INFO - 2026-02-22 14:48:37 --> Input Class Initialized
INFO - 2026-02-22 14:48:37 --> CSRF cookie sent
INFO - 2026-02-22 14:48:37 --> Input Class Initialized
INFO - 2026-02-22 14:48:37 --> Language Class Initialized
INFO - 2026-02-22 14:48:37 --> Language Class Initialized
INFO - 2026-02-22 14:48:37 --> Security Class Initialized
INFO - 2026-02-22 14:48:37 --> Language Class Initialized
INFO - 2026-02-22 14:48:37 --> Config Class Initialized
INFO - 2026-02-22 14:48:37 --> Language Class Initialized
INFO - 2026-02-22 14:48:37 --> Config Class Initialized
DEBUG - 2026-02-22 14:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:37 --> CSRF cookie sent
INFO - 2026-02-22 14:48:37 --> Input Class Initialized
INFO - 2026-02-22 14:48:37 --> Language Class Initialized
INFO - 2026-02-22 14:48:37 --> Loader Class Initialized
INFO - 2026-02-22 14:48:37 --> Language Class Initialized
INFO - 2026-02-22 14:48:37 --> Config Class Initialized
INFO - 2026-02-22 14:48:37 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:37 --> Loader Class Initialized
INFO - 2026-02-22 14:48:37 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:37 --> Loader Class Initialized
INFO - 2026-02-22 14:48:37 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:37 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:37 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:37 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:37 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:37 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:39 --> Upload Class Initialized
DEBUG - 2026-02-22 14:48:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:39 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:39 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:39 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:39 --> Email Class Initialized
INFO - 2026-02-22 14:48:39 --> Controller Class Initialized
ERROR - 2026-02-22 14:48:39 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:39 --> Upload Class Initialized
DEBUG - 2026-02-22 14:48:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:39 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:39 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:39 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:39 --> Config Class Initialized
INFO - 2026-02-22 14:48:39 --> Hooks Class Initialized
INFO - 2026-02-22 14:48:39 --> Email Class Initialized
INFO - 2026-02-22 14:48:39 --> Controller Class Initialized
ERROR - 2026-02-22 14:48:39 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:48:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-02-22 14:48:39 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:39 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:39 --> URI Class Initialized
INFO - 2026-02-22 14:48:39 --> Upload Class Initialized
INFO - 2026-02-22 14:48:39 --> Router Class Initialized
DEBUG - 2026-02-22 14:48:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:39 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:39 --> Output Class Initialized
INFO - 2026-02-22 14:48:39 --> Security Class Initialized
INFO - 2026-02-22 14:48:39 --> Form Validation Class Initialized
DEBUG - 2026-02-22 14:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:39 --> CSRF cookie sent
INFO - 2026-02-22 14:48:39 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:39 --> Input Class Initialized
INFO - 2026-02-22 14:48:39 --> Language Class Initialized
INFO - 2026-02-22 14:48:39 --> Language Class Initialized
INFO - 2026-02-22 14:48:39 --> Config Class Initialized
INFO - 2026-02-22 14:48:39 --> Config Class Initialized
INFO - 2026-02-22 14:48:39 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:48:39 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:39 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:39 --> Email Class Initialized
INFO - 2026-02-22 14:48:39 --> Controller Class Initialized
INFO - 2026-02-22 14:48:39 --> URI Class Initialized
ERROR - 2026-02-22 14:48:39 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:48:39 --> Loader Class Initialized
INFO - 2026-02-22 14:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:39 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:39 --> Router Class Initialized
INFO - 2026-02-22 14:48:39 --> Upload Class Initialized
INFO - 2026-02-22 14:48:39 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:39 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:39 --> Output Class Initialized
DEBUG - 2026-02-22 14:48:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:39 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:39 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:39 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:39 --> Security Class Initialized
INFO - 2026-02-22 14:48:39 --> Helper loaded: whmaz_helper
DEBUG - 2026-02-22 14:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:39 --> CSRF cookie sent
INFO - 2026-02-22 14:48:39 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:39 --> Input Class Initialized
INFO - 2026-02-22 14:48:39 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:39 --> Language Class Initialized
INFO - 2026-02-22 14:48:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:39 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:39 --> Language Class Initialized
INFO - 2026-02-22 14:48:39 --> Config Class Initialized
INFO - 2026-02-22 14:48:39 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:39 --> Config Class Initialized
INFO - 2026-02-22 14:48:39 --> Hooks Class Initialized
INFO - 2026-02-22 14:48:39 --> Helper loaded: domain_helper
DEBUG - 2026-02-22 14:48:39 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:48:39 --> Utf8 Class Initialized
INFO - 2026-02-22 14:48:39 --> Loader Class Initialized
INFO - 2026-02-22 14:48:39 --> URI Class Initialized
INFO - 2026-02-22 14:48:39 --> Email Class Initialized
INFO - 2026-02-22 14:48:39 --> Controller Class Initialized
INFO - 2026-02-22 14:48:39 --> Helper loaded: url_helper
ERROR - 2026-02-22 14:48:39 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:39 --> Router Class Initialized
INFO - 2026-02-22 14:48:39 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:39 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:39 --> Output Class Initialized
INFO - 2026-02-22 14:48:39 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:39 --> Upload Class Initialized
INFO - 2026-02-22 14:48:39 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:39 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:39 --> Security Class Initialized
INFO - 2026-02-22 14:48:39 --> Helper loaded: whmaz_helper
DEBUG - 2026-02-22 14:48:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2026-02-22 14:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:48:39 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:39 --> CSRF cookie sent
INFO - 2026-02-22 14:48:39 --> Input Class Initialized
INFO - 2026-02-22 14:48:39 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:39 --> Language Class Initialized
INFO - 2026-02-22 14:48:39 --> Language Class Initialized
INFO - 2026-02-22 14:48:39 --> Config Class Initialized
INFO - 2026-02-22 14:48:39 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:48:39 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:39 --> Loader Class Initialized
INFO - 2026-02-22 14:48:39 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:39 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:39 --> Helper loaded: url_helper
INFO - 2026-02-22 14:48:39 --> Helper loaded: form_helper
INFO - 2026-02-22 14:48:39 --> Helper loaded: html_helper
INFO - 2026-02-22 14:48:39 --> Helper loaded: file_helper
INFO - 2026-02-22 14:48:39 --> Helper loaded: email_helper
INFO - 2026-02-22 14:48:39 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:48:39 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:48:39 --> Email Class Initialized
INFO - 2026-02-22 14:48:39 --> Controller Class Initialized
INFO - 2026-02-22 14:48:39 --> Helper loaded: cpanel_helper
ERROR - 2026-02-22 14:48:39 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:39 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:48:39 --> Upload Class Initialized
INFO - 2026-02-22 14:48:39 --> Database Driver Class Initialized
DEBUG - 2026-02-22 14:48:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:39 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:39 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:39 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:39 --> Database Driver Class Initialized
INFO - 2026-02-22 14:48:39 --> Email Class Initialized
INFO - 2026-02-22 14:48:39 --> Controller Class Initialized
ERROR - 2026-02-22 14:48:39 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:41 --> Upload Class Initialized
DEBUG - 2026-02-22 14:48:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:41 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:41 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:41 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:41 --> Email Class Initialized
INFO - 2026-02-22 14:48:41 --> Controller Class Initialized
DEBUG - 2026-02-22 14:48:41 --> Domain_pricing MX_Controller Initialized
INFO - 2026-02-22 14:48:41 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:48:41 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:48:41 --> Model "Domainpricing_model" initialized
INFO - 2026-02-22 14:48:41 --> Model "Common_model" initialized
INFO - 2026-02-22 14:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:43 --> Upload Class Initialized
DEBUG - 2026-02-22 14:48:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:43 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:43 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:43 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:43 --> Email Class Initialized
INFO - 2026-02-22 14:48:43 --> Controller Class Initialized
ERROR - 2026-02-22 14:48:43 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:48:43 --> Upload Class Initialized
DEBUG - 2026-02-22 14:48:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:48:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:48:43 --> Encryption Class Initialized
INFO - 2026-02-22 14:48:43 --> Form Validation Class Initialized
INFO - 2026-02-22 14:48:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:48:43 --> Pagination Class Initialized
INFO - 2026-02-22 14:48:43 --> Email Class Initialized
INFO - 2026-02-22 14:48:43 --> Controller Class Initialized
ERROR - 2026-02-22 14:48:43 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:49:01 --> Config Class Initialized
INFO - 2026-02-22 14:49:01 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:49:01 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:49:01 --> Utf8 Class Initialized
INFO - 2026-02-22 14:49:01 --> URI Class Initialized
INFO - 2026-02-22 14:49:01 --> Router Class Initialized
INFO - 2026-02-22 14:49:01 --> Output Class Initialized
INFO - 2026-02-22 14:49:01 --> Security Class Initialized
DEBUG - 2026-02-22 14:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:49:01 --> CSRF cookie sent
INFO - 2026-02-22 14:49:01 --> Input Class Initialized
INFO - 2026-02-22 14:49:01 --> Language Class Initialized
INFO - 2026-02-22 14:49:01 --> Language Class Initialized
INFO - 2026-02-22 14:49:01 --> Config Class Initialized
INFO - 2026-02-22 14:49:01 --> Loader Class Initialized
INFO - 2026-02-22 14:49:01 --> Helper loaded: url_helper
INFO - 2026-02-22 14:49:01 --> Helper loaded: form_helper
INFO - 2026-02-22 14:49:01 --> Helper loaded: html_helper
INFO - 2026-02-22 14:49:01 --> Helper loaded: file_helper
INFO - 2026-02-22 14:49:01 --> Helper loaded: email_helper
INFO - 2026-02-22 14:49:01 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:49:01 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:49:01 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:49:01 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:49:01 --> Database Driver Class Initialized
INFO - 2026-02-22 14:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:49:04 --> Upload Class Initialized
DEBUG - 2026-02-22 14:49:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:49:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:49:04 --> Encryption Class Initialized
INFO - 2026-02-22 14:49:04 --> Form Validation Class Initialized
INFO - 2026-02-22 14:49:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:49:04 --> Pagination Class Initialized
INFO - 2026-02-22 14:49:04 --> Email Class Initialized
INFO - 2026-02-22 14:49:04 --> Controller Class Initialized
DEBUG - 2026-02-22 14:49:04 --> Domain_register MX_Controller Initialized
INFO - 2026-02-22 14:49:04 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:49:04 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:49:04 --> Model "Domainregister_model" initialized
DEBUG - 2026-02-22 14:49:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:49:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:49:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:49:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:49:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:49:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/domain_register_list.php
INFO - 2026-02-22 14:49:04 --> Final output sent to browser
DEBUG - 2026-02-22 14:49:04 --> Total execution time: 2.7684
INFO - 2026-02-22 14:49:04 --> Config Class Initialized
INFO - 2026-02-22 14:49:04 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:49:04 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:49:04 --> Utf8 Class Initialized
INFO - 2026-02-22 14:49:04 --> URI Class Initialized
INFO - 2026-02-22 14:49:04 --> Config Class Initialized
INFO - 2026-02-22 14:49:04 --> Hooks Class Initialized
INFO - 2026-02-22 14:49:04 --> Router Class Initialized
DEBUG - 2026-02-22 14:49:04 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:49:04 --> Utf8 Class Initialized
INFO - 2026-02-22 14:49:04 --> Output Class Initialized
INFO - 2026-02-22 14:49:04 --> Security Class Initialized
DEBUG - 2026-02-22 14:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:49:04 --> CSRF cookie sent
INFO - 2026-02-22 14:49:04 --> Input Class Initialized
INFO - 2026-02-22 14:49:04 --> Language Class Initialized
INFO - 2026-02-22 14:49:04 --> Language Class Initialized
INFO - 2026-02-22 14:49:04 --> Config Class Initialized
INFO - 2026-02-22 14:49:04 --> URI Class Initialized
INFO - 2026-02-22 14:49:04 --> Loader Class Initialized
INFO - 2026-02-22 14:49:04 --> Router Class Initialized
INFO - 2026-02-22 14:49:04 --> Helper loaded: url_helper
INFO - 2026-02-22 14:49:04 --> Output Class Initialized
INFO - 2026-02-22 14:49:04 --> Helper loaded: form_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: html_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: file_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: email_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:49:04 --> Security Class Initialized
DEBUG - 2026-02-22 14:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:49:04 --> CSRF cookie sent
INFO - 2026-02-22 14:49:04 --> Input Class Initialized
INFO - 2026-02-22 14:49:04 --> Language Class Initialized
INFO - 2026-02-22 14:49:04 --> Language Class Initialized
INFO - 2026-02-22 14:49:04 --> Config Class Initialized
INFO - 2026-02-22 14:49:04 --> Loader Class Initialized
INFO - 2026-02-22 14:49:04 --> Database Driver Class Initialized
INFO - 2026-02-22 14:49:04 --> Helper loaded: url_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: form_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: html_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: file_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: email_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:49:04 --> Database Driver Class Initialized
INFO - 2026-02-22 14:49:04 --> Config Class Initialized
INFO - 2026-02-22 14:49:04 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:49:04 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:49:04 --> Utf8 Class Initialized
INFO - 2026-02-22 14:49:04 --> URI Class Initialized
INFO - 2026-02-22 14:49:04 --> Router Class Initialized
INFO - 2026-02-22 14:49:04 --> Output Class Initialized
INFO - 2026-02-22 14:49:04 --> Config Class Initialized
INFO - 2026-02-22 14:49:04 --> Hooks Class Initialized
INFO - 2026-02-22 14:49:04 --> Config Class Initialized
INFO - 2026-02-22 14:49:04 --> Hooks Class Initialized
INFO - 2026-02-22 14:49:04 --> Security Class Initialized
INFO - 2026-02-22 14:49:04 --> Config Class Initialized
INFO - 2026-02-22 14:49:04 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:49:04 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:49:04 --> Utf8 Class Initialized
DEBUG - 2026-02-22 14:49:04 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:49:04 --> Utf8 Class Initialized
INFO - 2026-02-22 14:49:04 --> URI Class Initialized
DEBUG - 2026-02-22 14:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:49:04 --> CSRF cookie sent
INFO - 2026-02-22 14:49:04 --> Input Class Initialized
INFO - 2026-02-22 14:49:04 --> URI Class Initialized
INFO - 2026-02-22 14:49:04 --> Language Class Initialized
DEBUG - 2026-02-22 14:49:04 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:49:04 --> Utf8 Class Initialized
INFO - 2026-02-22 14:49:04 --> Router Class Initialized
INFO - 2026-02-22 14:49:04 --> Language Class Initialized
INFO - 2026-02-22 14:49:04 --> Router Class Initialized
INFO - 2026-02-22 14:49:04 --> Config Class Initialized
INFO - 2026-02-22 14:49:04 --> URI Class Initialized
INFO - 2026-02-22 14:49:04 --> Output Class Initialized
INFO - 2026-02-22 14:49:04 --> Output Class Initialized
INFO - 2026-02-22 14:49:04 --> Security Class Initialized
INFO - 2026-02-22 14:49:04 --> Router Class Initialized
INFO - 2026-02-22 14:49:04 --> Security Class Initialized
DEBUG - 2026-02-22 14:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:49:04 --> CSRF cookie sent
INFO - 2026-02-22 14:49:04 --> Input Class Initialized
DEBUG - 2026-02-22 14:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:49:04 --> CSRF cookie sent
INFO - 2026-02-22 14:49:04 --> Input Class Initialized
INFO - 2026-02-22 14:49:04 --> Loader Class Initialized
INFO - 2026-02-22 14:49:04 --> Language Class Initialized
INFO - 2026-02-22 14:49:04 --> Language Class Initialized
INFO - 2026-02-22 14:49:04 --> Output Class Initialized
INFO - 2026-02-22 14:49:04 --> Language Class Initialized
INFO - 2026-02-22 14:49:04 --> Config Class Initialized
INFO - 2026-02-22 14:49:04 --> Language Class Initialized
INFO - 2026-02-22 14:49:04 --> Config Class Initialized
INFO - 2026-02-22 14:49:04 --> Helper loaded: url_helper
INFO - 2026-02-22 14:49:04 --> Security Class Initialized
INFO - 2026-02-22 14:49:04 --> Helper loaded: form_helper
INFO - 2026-02-22 14:49:04 --> Loader Class Initialized
INFO - 2026-02-22 14:49:04 --> Loader Class Initialized
INFO - 2026-02-22 14:49:04 --> Helper loaded: html_helper
DEBUG - 2026-02-22 14:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:49:04 --> CSRF cookie sent
INFO - 2026-02-22 14:49:04 --> Input Class Initialized
INFO - 2026-02-22 14:49:04 --> Language Class Initialized
INFO - 2026-02-22 14:49:04 --> Helper loaded: url_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: file_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: url_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: email_helper
INFO - 2026-02-22 14:49:04 --> Language Class Initialized
INFO - 2026-02-22 14:49:04 --> Config Class Initialized
INFO - 2026-02-22 14:49:04 --> Helper loaded: form_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: form_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: html_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: html_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: file_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: email_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: file_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: email_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:49:04 --> Loader Class Initialized
INFO - 2026-02-22 14:49:04 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: url_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: form_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: html_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: file_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: email_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:49:04 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:49:04 --> Database Driver Class Initialized
INFO - 2026-02-22 14:49:04 --> Database Driver Class Initialized
INFO - 2026-02-22 14:49:04 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:49:04 --> Database Driver Class Initialized
INFO - 2026-02-22 14:49:04 --> Database Driver Class Initialized
INFO - 2026-02-22 14:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:49:06 --> Upload Class Initialized
DEBUG - 2026-02-22 14:49:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:49:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:49:06 --> Encryption Class Initialized
INFO - 2026-02-22 14:49:06 --> Form Validation Class Initialized
INFO - 2026-02-22 14:49:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:49:06 --> Pagination Class Initialized
INFO - 2026-02-22 14:49:06 --> Email Class Initialized
INFO - 2026-02-22 14:49:06 --> Controller Class Initialized
ERROR - 2026-02-22 14:49:06 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:49:06 --> Upload Class Initialized
DEBUG - 2026-02-22 14:49:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:49:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:49:06 --> Encryption Class Initialized
INFO - 2026-02-22 14:49:06 --> Form Validation Class Initialized
INFO - 2026-02-22 14:49:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:49:06 --> Pagination Class Initialized
INFO - 2026-02-22 14:49:06 --> Config Class Initialized
INFO - 2026-02-22 14:49:06 --> Hooks Class Initialized
INFO - 2026-02-22 14:49:06 --> Email Class Initialized
INFO - 2026-02-22 14:49:06 --> Controller Class Initialized
DEBUG - 2026-02-22 14:49:06 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:49:06 --> Utf8 Class Initialized
ERROR - 2026-02-22 14:49:06 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:49:06 --> URI Class Initialized
INFO - 2026-02-22 14:49:06 --> Router Class Initialized
INFO - 2026-02-22 14:49:06 --> Output Class Initialized
INFO - 2026-02-22 14:49:06 --> Security Class Initialized
DEBUG - 2026-02-22 14:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:49:06 --> CSRF cookie sent
INFO - 2026-02-22 14:49:06 --> Input Class Initialized
INFO - 2026-02-22 14:49:06 --> Language Class Initialized
INFO - 2026-02-22 14:49:06 --> Language Class Initialized
INFO - 2026-02-22 14:49:06 --> Config Class Initialized
INFO - 2026-02-22 14:49:06 --> Config Class Initialized
INFO - 2026-02-22 14:49:06 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:49:06 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:49:06 --> Utf8 Class Initialized
INFO - 2026-02-22 14:49:06 --> Loader Class Initialized
INFO - 2026-02-22 14:49:06 --> URI Class Initialized
INFO - 2026-02-22 14:49:06 --> Helper loaded: url_helper
INFO - 2026-02-22 14:49:06 --> Router Class Initialized
INFO - 2026-02-22 14:49:06 --> Helper loaded: form_helper
INFO - 2026-02-22 14:49:06 --> Helper loaded: html_helper
INFO - 2026-02-22 14:49:06 --> Output Class Initialized
INFO - 2026-02-22 14:49:06 --> Helper loaded: file_helper
INFO - 2026-02-22 14:49:06 --> Helper loaded: email_helper
INFO - 2026-02-22 14:49:06 --> Security Class Initialized
INFO - 2026-02-22 14:49:06 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:49:06 --> Helper loaded: ssp_helper
DEBUG - 2026-02-22 14:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:49:06 --> CSRF cookie sent
INFO - 2026-02-22 14:49:06 --> Input Class Initialized
INFO - 2026-02-22 14:49:06 --> Language Class Initialized
INFO - 2026-02-22 14:49:06 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:49:06 --> Language Class Initialized
INFO - 2026-02-22 14:49:06 --> Config Class Initialized
INFO - 2026-02-22 14:49:06 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:49:06 --> Loader Class Initialized
INFO - 2026-02-22 14:49:06 --> Helper loaded: url_helper
INFO - 2026-02-22 14:49:06 --> Helper loaded: form_helper
INFO - 2026-02-22 14:49:06 --> Helper loaded: html_helper
INFO - 2026-02-22 14:49:06 --> Helper loaded: file_helper
INFO - 2026-02-22 14:49:06 --> Helper loaded: email_helper
INFO - 2026-02-22 14:49:06 --> Database Driver Class Initialized
INFO - 2026-02-22 14:49:06 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:49:06 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:49:06 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:49:06 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:49:06 --> Database Driver Class Initialized
INFO - 2026-02-22 14:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:49:06 --> Upload Class Initialized
DEBUG - 2026-02-22 14:49:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:49:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:49:06 --> Encryption Class Initialized
INFO - 2026-02-22 14:49:06 --> Form Validation Class Initialized
INFO - 2026-02-22 14:49:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:49:06 --> Pagination Class Initialized
INFO - 2026-02-22 14:49:06 --> Email Class Initialized
INFO - 2026-02-22 14:49:06 --> Controller Class Initialized
ERROR - 2026-02-22 14:49:06 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:49:06 --> Upload Class Initialized
DEBUG - 2026-02-22 14:49:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:49:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:49:06 --> Encryption Class Initialized
INFO - 2026-02-22 14:49:06 --> Config Class Initialized
INFO - 2026-02-22 14:49:06 --> Hooks Class Initialized
INFO - 2026-02-22 14:49:06 --> Form Validation Class Initialized
DEBUG - 2026-02-22 14:49:06 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:49:06 --> Utf8 Class Initialized
INFO - 2026-02-22 14:49:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:49:06 --> Pagination Class Initialized
INFO - 2026-02-22 14:49:06 --> URI Class Initialized
INFO - 2026-02-22 14:49:06 --> Router Class Initialized
INFO - 2026-02-22 14:49:06 --> Output Class Initialized
INFO - 2026-02-22 14:49:06 --> Email Class Initialized
INFO - 2026-02-22 14:49:06 --> Controller Class Initialized
ERROR - 2026-02-22 14:49:06 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:49:06 --> Security Class Initialized
INFO - 2026-02-22 14:49:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-02-22 14:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:49:06 --> CSRF cookie sent
INFO - 2026-02-22 14:49:06 --> Input Class Initialized
INFO - 2026-02-22 14:49:06 --> Language Class Initialized
INFO - 2026-02-22 14:49:06 --> Upload Class Initialized
INFO - 2026-02-22 14:49:06 --> Language Class Initialized
INFO - 2026-02-22 14:49:06 --> Config Class Initialized
DEBUG - 2026-02-22 14:49:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:49:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:49:06 --> Encryption Class Initialized
INFO - 2026-02-22 14:49:06 --> Form Validation Class Initialized
INFO - 2026-02-22 14:49:06 --> Loader Class Initialized
INFO - 2026-02-22 14:49:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:49:06 --> Pagination Class Initialized
INFO - 2026-02-22 14:49:06 --> Helper loaded: url_helper
INFO - 2026-02-22 14:49:06 --> Helper loaded: form_helper
INFO - 2026-02-22 14:49:06 --> Helper loaded: html_helper
INFO - 2026-02-22 14:49:06 --> Helper loaded: file_helper
INFO - 2026-02-22 14:49:06 --> Email Class Initialized
INFO - 2026-02-22 14:49:06 --> Helper loaded: email_helper
INFO - 2026-02-22 14:49:06 --> Controller Class Initialized
ERROR - 2026-02-22 14:49:06 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:49:06 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:49:06 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:49:06 --> Upload Class Initialized
INFO - 2026-02-22 14:49:06 --> Helper loaded: cpanel_helper
DEBUG - 2026-02-22 14:49:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:49:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:49:06 --> Encryption Class Initialized
INFO - 2026-02-22 14:49:06 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:49:06 --> Form Validation Class Initialized
INFO - 2026-02-22 14:49:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:49:06 --> Pagination Class Initialized
INFO - 2026-02-22 14:49:06 --> Email Class Initialized
INFO - 2026-02-22 14:49:06 --> Controller Class Initialized
ERROR - 2026-02-22 14:49:06 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:49:06 --> Database Driver Class Initialized
INFO - 2026-02-22 14:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:49:09 --> Upload Class Initialized
DEBUG - 2026-02-22 14:49:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:49:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:49:09 --> Encryption Class Initialized
INFO - 2026-02-22 14:49:09 --> Form Validation Class Initialized
INFO - 2026-02-22 14:49:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:49:09 --> Pagination Class Initialized
INFO - 2026-02-22 14:49:09 --> Email Class Initialized
INFO - 2026-02-22 14:49:09 --> Controller Class Initialized
ERROR - 2026-02-22 14:49:09 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:49:09 --> Upload Class Initialized
DEBUG - 2026-02-22 14:49:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:49:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:49:09 --> Encryption Class Initialized
INFO - 2026-02-22 14:49:09 --> Form Validation Class Initialized
INFO - 2026-02-22 14:49:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:49:09 --> Pagination Class Initialized
INFO - 2026-02-22 14:49:09 --> Email Class Initialized
INFO - 2026-02-22 14:49:09 --> Controller Class Initialized
ERROR - 2026-02-22 14:49:09 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:49:09 --> Upload Class Initialized
DEBUG - 2026-02-22 14:49:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:49:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:49:09 --> Encryption Class Initialized
INFO - 2026-02-22 14:49:09 --> Form Validation Class Initialized
INFO - 2026-02-22 14:49:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:49:09 --> Pagination Class Initialized
INFO - 2026-02-22 14:49:09 --> Email Class Initialized
INFO - 2026-02-22 14:49:09 --> Controller Class Initialized
DEBUG - 2026-02-22 14:49:09 --> Domain_register MX_Controller Initialized
INFO - 2026-02-22 14:49:09 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:49:09 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:49:09 --> Model "Domainregister_model" initialized
INFO - 2026-02-22 14:50:07 --> Config Class Initialized
INFO - 2026-02-22 14:50:07 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:50:07 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:50:07 --> Utf8 Class Initialized
INFO - 2026-02-22 14:50:07 --> URI Class Initialized
INFO - 2026-02-22 14:50:07 --> Router Class Initialized
INFO - 2026-02-22 14:50:07 --> Output Class Initialized
INFO - 2026-02-22 14:50:07 --> Security Class Initialized
DEBUG - 2026-02-22 14:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:50:07 --> CSRF cookie sent
INFO - 2026-02-22 14:50:07 --> Input Class Initialized
INFO - 2026-02-22 14:50:07 --> Language Class Initialized
INFO - 2026-02-22 14:50:07 --> Language Class Initialized
INFO - 2026-02-22 14:50:07 --> Config Class Initialized
INFO - 2026-02-22 14:50:07 --> Loader Class Initialized
INFO - 2026-02-22 14:50:07 --> Helper loaded: url_helper
INFO - 2026-02-22 14:50:07 --> Helper loaded: form_helper
INFO - 2026-02-22 14:50:07 --> Helper loaded: html_helper
INFO - 2026-02-22 14:50:07 --> Helper loaded: file_helper
INFO - 2026-02-22 14:50:07 --> Helper loaded: email_helper
INFO - 2026-02-22 14:50:07 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:50:07 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:50:07 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:50:07 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:50:07 --> Database Driver Class Initialized
INFO - 2026-02-22 14:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:50:09 --> Upload Class Initialized
DEBUG - 2026-02-22 14:50:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:50:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:50:09 --> Encryption Class Initialized
INFO - 2026-02-22 14:50:09 --> Form Validation Class Initialized
INFO - 2026-02-22 14:50:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:50:09 --> Pagination Class Initialized
INFO - 2026-02-22 14:50:09 --> Email Class Initialized
INFO - 2026-02-22 14:50:09 --> Controller Class Initialized
ERROR - 2026-02-22 14:50:09 --> 404 Page Not Found: whmazadmin/Pages/index
INFO - 2026-02-22 14:50:16 --> Config Class Initialized
INFO - 2026-02-22 14:50:16 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:50:16 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:50:16 --> Utf8 Class Initialized
INFO - 2026-02-22 14:50:16 --> URI Class Initialized
INFO - 2026-02-22 14:50:16 --> Router Class Initialized
INFO - 2026-02-22 14:50:16 --> Output Class Initialized
INFO - 2026-02-22 14:50:16 --> Security Class Initialized
DEBUG - 2026-02-22 14:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:50:16 --> CSRF cookie sent
INFO - 2026-02-22 14:50:16 --> Input Class Initialized
INFO - 2026-02-22 14:50:16 --> Language Class Initialized
INFO - 2026-02-22 14:50:16 --> Language Class Initialized
INFO - 2026-02-22 14:50:16 --> Config Class Initialized
INFO - 2026-02-22 14:50:16 --> Loader Class Initialized
INFO - 2026-02-22 14:50:16 --> Helper loaded: url_helper
INFO - 2026-02-22 14:50:16 --> Helper loaded: form_helper
INFO - 2026-02-22 14:50:16 --> Helper loaded: html_helper
INFO - 2026-02-22 14:50:16 --> Helper loaded: file_helper
INFO - 2026-02-22 14:50:16 --> Helper loaded: email_helper
INFO - 2026-02-22 14:50:16 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:50:16 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:50:16 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:50:16 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:50:16 --> Database Driver Class Initialized
INFO - 2026-02-22 14:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:50:18 --> Upload Class Initialized
DEBUG - 2026-02-22 14:50:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:50:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:50:18 --> Encryption Class Initialized
INFO - 2026-02-22 14:50:18 --> Form Validation Class Initialized
INFO - 2026-02-22 14:50:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:50:18 --> Pagination Class Initialized
INFO - 2026-02-22 14:50:18 --> Email Class Initialized
INFO - 2026-02-22 14:50:18 --> Controller Class Initialized
DEBUG - 2026-02-22 14:50:18 --> Page MX_Controller Initialized
INFO - 2026-02-22 14:50:18 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:50:18 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:50:18 --> Model "Page_model" initialized
DEBUG - 2026-02-22 14:50:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:50:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:50:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:50:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:50:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:50:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/page_list.php
INFO - 2026-02-22 14:50:19 --> Final output sent to browser
DEBUG - 2026-02-22 14:50:19 --> Total execution time: 2.8908
INFO - 2026-02-22 14:50:19 --> Config Class Initialized
INFO - 2026-02-22 14:50:19 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:50:19 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:50:19 --> Utf8 Class Initialized
INFO - 2026-02-22 14:50:19 --> URI Class Initialized
INFO - 2026-02-22 14:50:19 --> Router Class Initialized
INFO - 2026-02-22 14:50:19 --> Output Class Initialized
INFO - 2026-02-22 14:50:19 --> Security Class Initialized
DEBUG - 2026-02-22 14:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:50:19 --> CSRF cookie sent
INFO - 2026-02-22 14:50:19 --> Input Class Initialized
INFO - 2026-02-22 14:50:19 --> Language Class Initialized
INFO - 2026-02-22 14:50:19 --> Language Class Initialized
INFO - 2026-02-22 14:50:19 --> Config Class Initialized
INFO - 2026-02-22 14:50:19 --> Loader Class Initialized
INFO - 2026-02-22 14:50:19 --> Config Class Initialized
INFO - 2026-02-22 14:50:19 --> Hooks Class Initialized
INFO - 2026-02-22 14:50:19 --> Helper loaded: url_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: form_helper
DEBUG - 2026-02-22 14:50:19 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:50:19 --> Utf8 Class Initialized
INFO - 2026-02-22 14:50:19 --> Helper loaded: html_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: file_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: email_helper
INFO - 2026-02-22 14:50:19 --> URI Class Initialized
INFO - 2026-02-22 14:50:19 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:50:19 --> Router Class Initialized
INFO - 2026-02-22 14:50:19 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:50:19 --> Output Class Initialized
INFO - 2026-02-22 14:50:19 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:50:19 --> Security Class Initialized
DEBUG - 2026-02-22 14:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:50:19 --> CSRF cookie sent
INFO - 2026-02-22 14:50:19 --> Input Class Initialized
INFO - 2026-02-22 14:50:19 --> Language Class Initialized
INFO - 2026-02-22 14:50:19 --> Language Class Initialized
INFO - 2026-02-22 14:50:19 --> Config Class Initialized
INFO - 2026-02-22 14:50:19 --> Loader Class Initialized
INFO - 2026-02-22 14:50:19 --> Database Driver Class Initialized
INFO - 2026-02-22 14:50:19 --> Helper loaded: url_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: form_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: html_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: file_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: email_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:50:19 --> Database Driver Class Initialized
INFO - 2026-02-22 14:50:19 --> Config Class Initialized
INFO - 2026-02-22 14:50:19 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:50:19 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:50:19 --> Utf8 Class Initialized
INFO - 2026-02-22 14:50:19 --> Config Class Initialized
INFO - 2026-02-22 14:50:19 --> Hooks Class Initialized
INFO - 2026-02-22 14:50:19 --> URI Class Initialized
INFO - 2026-02-22 14:50:19 --> Config Class Initialized
INFO - 2026-02-22 14:50:19 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:50:19 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:50:19 --> Utf8 Class Initialized
INFO - 2026-02-22 14:50:19 --> Config Class Initialized
INFO - 2026-02-22 14:50:19 --> Hooks Class Initialized
INFO - 2026-02-22 14:50:19 --> URI Class Initialized
DEBUG - 2026-02-22 14:50:19 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:50:19 --> Utf8 Class Initialized
DEBUG - 2026-02-22 14:50:19 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:50:19 --> Utf8 Class Initialized
INFO - 2026-02-22 14:50:19 --> Router Class Initialized
INFO - 2026-02-22 14:50:19 --> Router Class Initialized
INFO - 2026-02-22 14:50:19 --> URI Class Initialized
INFO - 2026-02-22 14:50:19 --> URI Class Initialized
INFO - 2026-02-22 14:50:19 --> Output Class Initialized
INFO - 2026-02-22 14:50:19 --> Output Class Initialized
INFO - 2026-02-22 14:50:19 --> Router Class Initialized
INFO - 2026-02-22 14:50:19 --> Security Class Initialized
INFO - 2026-02-22 14:50:19 --> Router Class Initialized
INFO - 2026-02-22 14:50:19 --> Security Class Initialized
DEBUG - 2026-02-22 14:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:50:19 --> CSRF cookie sent
INFO - 2026-02-22 14:50:19 --> Input Class Initialized
INFO - 2026-02-22 14:50:19 --> Language Class Initialized
INFO - 2026-02-22 14:50:19 --> Output Class Initialized
DEBUG - 2026-02-22 14:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:50:19 --> Language Class Initialized
INFO - 2026-02-22 14:50:19 --> Config Class Initialized
INFO - 2026-02-22 14:50:19 --> CSRF cookie sent
INFO - 2026-02-22 14:50:19 --> Input Class Initialized
INFO - 2026-02-22 14:50:19 --> Output Class Initialized
INFO - 2026-02-22 14:50:19 --> Language Class Initialized
INFO - 2026-02-22 14:50:19 --> Security Class Initialized
INFO - 2026-02-22 14:50:19 --> Language Class Initialized
INFO - 2026-02-22 14:50:19 --> Security Class Initialized
INFO - 2026-02-22 14:50:19 --> Config Class Initialized
DEBUG - 2026-02-22 14:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:50:19 --> CSRF cookie sent
INFO - 2026-02-22 14:50:19 --> Input Class Initialized
INFO - 2026-02-22 14:50:19 --> Loader Class Initialized
INFO - 2026-02-22 14:50:19 --> Language Class Initialized
DEBUG - 2026-02-22 14:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:50:19 --> CSRF cookie sent
INFO - 2026-02-22 14:50:19 --> Input Class Initialized
INFO - 2026-02-22 14:50:19 --> Helper loaded: url_helper
INFO - 2026-02-22 14:50:19 --> Language Class Initialized
INFO - 2026-02-22 14:50:19 --> Language Class Initialized
INFO - 2026-02-22 14:50:19 --> Config Class Initialized
INFO - 2026-02-22 14:50:19 --> Language Class Initialized
INFO - 2026-02-22 14:50:19 --> Config Class Initialized
INFO - 2026-02-22 14:50:19 --> Helper loaded: form_helper
INFO - 2026-02-22 14:50:19 --> Loader Class Initialized
INFO - 2026-02-22 14:50:19 --> Helper loaded: html_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: file_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: email_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: url_helper
INFO - 2026-02-22 14:50:19 --> Loader Class Initialized
INFO - 2026-02-22 14:50:19 --> Loader Class Initialized
INFO - 2026-02-22 14:50:19 --> Helper loaded: url_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: url_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: form_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: html_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: form_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: form_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: file_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: email_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: html_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: html_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: file_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: file_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: email_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: email_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:50:19 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:50:19 --> Database Driver Class Initialized
INFO - 2026-02-22 14:50:19 --> Database Driver Class Initialized
INFO - 2026-02-22 14:50:19 --> Database Driver Class Initialized
INFO - 2026-02-22 14:50:19 --> Database Driver Class Initialized
INFO - 2026-02-22 14:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:50:21 --> Upload Class Initialized
DEBUG - 2026-02-22 14:50:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:50:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:50:21 --> Encryption Class Initialized
INFO - 2026-02-22 14:50:21 --> Form Validation Class Initialized
INFO - 2026-02-22 14:50:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:50:21 --> Pagination Class Initialized
INFO - 2026-02-22 14:50:21 --> Email Class Initialized
INFO - 2026-02-22 14:50:21 --> Controller Class Initialized
ERROR - 2026-02-22 14:50:21 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:50:21 --> Upload Class Initialized
DEBUG - 2026-02-22 14:50:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:50:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:50:21 --> Encryption Class Initialized
INFO - 2026-02-22 14:50:21 --> Form Validation Class Initialized
INFO - 2026-02-22 14:50:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:50:21 --> Pagination Class Initialized
INFO - 2026-02-22 14:50:21 --> Config Class Initialized
INFO - 2026-02-22 14:50:21 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:50:21 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:50:21 --> Utf8 Class Initialized
INFO - 2026-02-22 14:50:21 --> Email Class Initialized
INFO - 2026-02-22 14:50:21 --> Controller Class Initialized
INFO - 2026-02-22 14:50:21 --> URI Class Initialized
ERROR - 2026-02-22 14:50:21 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:50:21 --> Router Class Initialized
INFO - 2026-02-22 14:50:21 --> Upload Class Initialized
INFO - 2026-02-22 14:50:21 --> Output Class Initialized
DEBUG - 2026-02-22 14:50:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:50:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:50:21 --> Encryption Class Initialized
INFO - 2026-02-22 14:50:21 --> Security Class Initialized
DEBUG - 2026-02-22 14:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:50:21 --> CSRF cookie sent
INFO - 2026-02-22 14:50:21 --> Input Class Initialized
INFO - 2026-02-22 14:50:21 --> Language Class Initialized
INFO - 2026-02-22 14:50:21 --> Form Validation Class Initialized
INFO - 2026-02-22 14:50:21 --> Language Class Initialized
INFO - 2026-02-22 14:50:21 --> Config Class Initialized
INFO - 2026-02-22 14:50:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:50:21 --> Pagination Class Initialized
INFO - 2026-02-22 14:50:21 --> Config Class Initialized
INFO - 2026-02-22 14:50:21 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:50:21 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:50:21 --> Utf8 Class Initialized
INFO - 2026-02-22 14:50:21 --> Loader Class Initialized
INFO - 2026-02-22 14:50:21 --> URI Class Initialized
INFO - 2026-02-22 14:50:21 --> Email Class Initialized
INFO - 2026-02-22 14:50:21 --> Helper loaded: url_helper
INFO - 2026-02-22 14:50:21 --> Controller Class Initialized
ERROR - 2026-02-22 14:50:21 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:50:21 --> Router Class Initialized
INFO - 2026-02-22 14:50:21 --> Helper loaded: form_helper
INFO - 2026-02-22 14:50:21 --> Helper loaded: html_helper
INFO - 2026-02-22 14:50:21 --> Output Class Initialized
INFO - 2026-02-22 14:50:21 --> Helper loaded: file_helper
INFO - 2026-02-22 14:50:21 --> Helper loaded: email_helper
INFO - 2026-02-22 14:50:21 --> Upload Class Initialized
INFO - 2026-02-22 14:50:21 --> Security Class Initialized
INFO - 2026-02-22 14:50:21 --> Helper loaded: whmaz_helper
DEBUG - 2026-02-22 14:50:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:50:21 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:50:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:50:21 --> Encryption Class Initialized
DEBUG - 2026-02-22 14:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:50:21 --> CSRF cookie sent
INFO - 2026-02-22 14:50:21 --> Input Class Initialized
INFO - 2026-02-22 14:50:21 --> Language Class Initialized
INFO - 2026-02-22 14:50:21 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:50:21 --> Language Class Initialized
INFO - 2026-02-22 14:50:21 --> Config Class Initialized
INFO - 2026-02-22 14:50:21 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:50:21 --> Form Validation Class Initialized
INFO - 2026-02-22 14:50:21 --> Loader Class Initialized
INFO - 2026-02-22 14:50:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:50:21 --> Pagination Class Initialized
INFO - 2026-02-22 14:50:21 --> Helper loaded: url_helper
INFO - 2026-02-22 14:50:21 --> Helper loaded: form_helper
INFO - 2026-02-22 14:50:21 --> Config Class Initialized
INFO - 2026-02-22 14:50:21 --> Hooks Class Initialized
INFO - 2026-02-22 14:50:21 --> Helper loaded: html_helper
INFO - 2026-02-22 14:50:21 --> Helper loaded: file_helper
INFO - 2026-02-22 14:50:21 --> Helper loaded: email_helper
DEBUG - 2026-02-22 14:50:21 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:50:21 --> Utf8 Class Initialized
INFO - 2026-02-22 14:50:21 --> Database Driver Class Initialized
INFO - 2026-02-22 14:50:21 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:50:21 --> Email Class Initialized
INFO - 2026-02-22 14:50:21 --> Controller Class Initialized
INFO - 2026-02-22 14:50:21 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:50:21 --> URI Class Initialized
ERROR - 2026-02-22 14:50:21 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:50:21 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:50:21 --> Router Class Initialized
INFO - 2026-02-22 14:50:21 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:50:21 --> Upload Class Initialized
INFO - 2026-02-22 14:50:21 --> Output Class Initialized
DEBUG - 2026-02-22 14:50:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:50:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:50:21 --> Encryption Class Initialized
INFO - 2026-02-22 14:50:21 --> Security Class Initialized
DEBUG - 2026-02-22 14:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:50:21 --> Form Validation Class Initialized
INFO - 2026-02-22 14:50:21 --> CSRF cookie sent
INFO - 2026-02-22 14:50:21 --> Input Class Initialized
INFO - 2026-02-22 14:50:21 --> Language Class Initialized
INFO - 2026-02-22 14:50:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:50:21 --> Pagination Class Initialized
INFO - 2026-02-22 14:50:21 --> Language Class Initialized
INFO - 2026-02-22 14:50:21 --> Config Class Initialized
INFO - 2026-02-22 14:50:21 --> Database Driver Class Initialized
INFO - 2026-02-22 14:50:21 --> Loader Class Initialized
INFO - 2026-02-22 14:50:21 --> Email Class Initialized
INFO - 2026-02-22 14:50:21 --> Controller Class Initialized
ERROR - 2026-02-22 14:50:21 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:50:21 --> Helper loaded: url_helper
INFO - 2026-02-22 14:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:50:21 --> Helper loaded: form_helper
INFO - 2026-02-22 14:50:21 --> Upload Class Initialized
INFO - 2026-02-22 14:50:21 --> Helper loaded: html_helper
INFO - 2026-02-22 14:50:21 --> Helper loaded: file_helper
INFO - 2026-02-22 14:50:21 --> Helper loaded: email_helper
DEBUG - 2026-02-22 14:50:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:50:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:50:21 --> Encryption Class Initialized
INFO - 2026-02-22 14:50:21 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:50:21 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:50:21 --> Form Validation Class Initialized
INFO - 2026-02-22 14:50:21 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:50:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:50:21 --> Pagination Class Initialized
INFO - 2026-02-22 14:50:21 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:50:21 --> Email Class Initialized
INFO - 2026-02-22 14:50:21 --> Controller Class Initialized
ERROR - 2026-02-22 14:50:21 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:50:21 --> Database Driver Class Initialized
INFO - 2026-02-22 14:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:50:23 --> Upload Class Initialized
DEBUG - 2026-02-22 14:50:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:50:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:50:23 --> Encryption Class Initialized
INFO - 2026-02-22 14:50:23 --> Form Validation Class Initialized
INFO - 2026-02-22 14:50:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:50:23 --> Pagination Class Initialized
INFO - 2026-02-22 14:50:23 --> Email Class Initialized
INFO - 2026-02-22 14:50:23 --> Controller Class Initialized
ERROR - 2026-02-22 14:50:23 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:50:23 --> Upload Class Initialized
DEBUG - 2026-02-22 14:50:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:50:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:50:23 --> Encryption Class Initialized
INFO - 2026-02-22 14:50:23 --> Form Validation Class Initialized
INFO - 2026-02-22 14:50:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:50:23 --> Pagination Class Initialized
INFO - 2026-02-22 14:50:23 --> Email Class Initialized
INFO - 2026-02-22 14:50:23 --> Controller Class Initialized
DEBUG - 2026-02-22 14:50:23 --> Page MX_Controller Initialized
INFO - 2026-02-22 14:50:23 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:50:23 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:50:23 --> Model "Page_model" initialized
INFO - 2026-02-22 14:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:50:26 --> Upload Class Initialized
DEBUG - 2026-02-22 14:50:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:50:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:50:26 --> Encryption Class Initialized
INFO - 2026-02-22 14:50:26 --> Form Validation Class Initialized
INFO - 2026-02-22 14:50:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:50:26 --> Pagination Class Initialized
INFO - 2026-02-22 14:50:26 --> Email Class Initialized
INFO - 2026-02-22 14:50:26 --> Controller Class Initialized
ERROR - 2026-02-22 14:50:26 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:52:02 --> Config Class Initialized
INFO - 2026-02-22 14:52:02 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:52:02 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:02 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:02 --> URI Class Initialized
INFO - 2026-02-22 14:52:02 --> Router Class Initialized
INFO - 2026-02-22 14:52:02 --> Output Class Initialized
INFO - 2026-02-22 14:52:02 --> Security Class Initialized
DEBUG - 2026-02-22 14:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:02 --> CSRF cookie sent
INFO - 2026-02-22 14:52:02 --> Input Class Initialized
INFO - 2026-02-22 14:52:02 --> Language Class Initialized
INFO - 2026-02-22 14:52:02 --> Language Class Initialized
INFO - 2026-02-22 14:52:02 --> Config Class Initialized
INFO - 2026-02-22 14:52:02 --> Loader Class Initialized
INFO - 2026-02-22 14:52:02 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:02 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:02 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:02 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:02 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:02 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:02 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:02 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:02 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:02 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:04 --> Upload Class Initialized
DEBUG - 2026-02-22 14:52:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:04 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:04 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:04 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:04 --> Email Class Initialized
INFO - 2026-02-22 14:52:04 --> Controller Class Initialized
DEBUG - 2026-02-22 14:52:04 --> Page MX_Controller Initialized
INFO - 2026-02-22 14:52:04 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:52:04 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:52:04 --> Model "Page_model" initialized
DEBUG - 2026-02-22 14:52:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:52:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:52:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:52:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:52:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:52:05 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/page_list.php
INFO - 2026-02-22 14:52:05 --> Final output sent to browser
DEBUG - 2026-02-22 14:52:05 --> Total execution time: 3.1011
INFO - 2026-02-22 14:52:05 --> Config Class Initialized
INFO - 2026-02-22 14:52:05 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:52:05 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:05 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:05 --> URI Class Initialized
INFO - 2026-02-22 14:52:05 --> Router Class Initialized
INFO - 2026-02-22 14:52:05 --> Output Class Initialized
INFO - 2026-02-22 14:52:05 --> Security Class Initialized
DEBUG - 2026-02-22 14:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:05 --> CSRF cookie sent
INFO - 2026-02-22 14:52:05 --> Input Class Initialized
INFO - 2026-02-22 14:52:05 --> Language Class Initialized
INFO - 2026-02-22 14:52:05 --> Language Class Initialized
INFO - 2026-02-22 14:52:05 --> Config Class Initialized
INFO - 2026-02-22 14:52:05 --> Loader Class Initialized
INFO - 2026-02-22 14:52:05 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:05 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:05 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:05 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:05 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:05 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:05 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:05 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:05 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:05 --> Config Class Initialized
INFO - 2026-02-22 14:52:05 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:52:05 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:05 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:05 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:05 --> URI Class Initialized
INFO - 2026-02-22 14:52:05 --> Router Class Initialized
INFO - 2026-02-22 14:52:05 --> Output Class Initialized
INFO - 2026-02-22 14:52:05 --> Security Class Initialized
DEBUG - 2026-02-22 14:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:05 --> CSRF cookie sent
INFO - 2026-02-22 14:52:05 --> Input Class Initialized
INFO - 2026-02-22 14:52:05 --> Language Class Initialized
INFO - 2026-02-22 14:52:05 --> Language Class Initialized
INFO - 2026-02-22 14:52:05 --> Config Class Initialized
INFO - 2026-02-22 14:52:05 --> Loader Class Initialized
INFO - 2026-02-22 14:52:05 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:05 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:05 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:05 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:05 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:05 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:05 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:05 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:05 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:05 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:06 --> Config Class Initialized
INFO - 2026-02-22 14:52:06 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:52:06 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:06 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:06 --> URI Class Initialized
INFO - 2026-02-22 14:52:06 --> Router Class Initialized
INFO - 2026-02-22 14:52:06 --> Output Class Initialized
INFO - 2026-02-22 14:52:06 --> Security Class Initialized
DEBUG - 2026-02-22 14:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:06 --> CSRF cookie sent
INFO - 2026-02-22 14:52:06 --> Input Class Initialized
INFO - 2026-02-22 14:52:06 --> Language Class Initialized
INFO - 2026-02-22 14:52:06 --> Language Class Initialized
INFO - 2026-02-22 14:52:06 --> Config Class Initialized
INFO - 2026-02-22 14:52:06 --> Loader Class Initialized
INFO - 2026-02-22 14:52:06 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:06 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:06 --> Config Class Initialized
INFO - 2026-02-22 14:52:06 --> Hooks Class Initialized
INFO - 2026-02-22 14:52:06 --> Config Class Initialized
INFO - 2026-02-22 14:52:06 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:52:06 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:06 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:06 --> Config Class Initialized
INFO - 2026-02-22 14:52:06 --> Hooks Class Initialized
INFO - 2026-02-22 14:52:06 --> URI Class Initialized
DEBUG - 2026-02-22 14:52:06 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:06 --> Utf8 Class Initialized
DEBUG - 2026-02-22 14:52:06 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:06 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:06 --> Router Class Initialized
INFO - 2026-02-22 14:52:06 --> URI Class Initialized
INFO - 2026-02-22 14:52:06 --> URI Class Initialized
INFO - 2026-02-22 14:52:06 --> Output Class Initialized
INFO - 2026-02-22 14:52:06 --> Security Class Initialized
INFO - 2026-02-22 14:52:06 --> Router Class Initialized
INFO - 2026-02-22 14:52:06 --> Router Class Initialized
DEBUG - 2026-02-22 14:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:06 --> CSRF cookie sent
INFO - 2026-02-22 14:52:06 --> Input Class Initialized
INFO - 2026-02-22 14:52:06 --> Language Class Initialized
INFO - 2026-02-22 14:52:06 --> Output Class Initialized
INFO - 2026-02-22 14:52:06 --> Language Class Initialized
INFO - 2026-02-22 14:52:06 --> Config Class Initialized
INFO - 2026-02-22 14:52:06 --> Security Class Initialized
INFO - 2026-02-22 14:52:06 --> Output Class Initialized
DEBUG - 2026-02-22 14:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:06 --> CSRF cookie sent
INFO - 2026-02-22 14:52:06 --> Input Class Initialized
INFO - 2026-02-22 14:52:06 --> Language Class Initialized
INFO - 2026-02-22 14:52:06 --> Security Class Initialized
INFO - 2026-02-22 14:52:06 --> Loader Class Initialized
INFO - 2026-02-22 14:52:06 --> Language Class Initialized
INFO - 2026-02-22 14:52:06 --> Config Class Initialized
INFO - 2026-02-22 14:52:06 --> Helper loaded: url_helper
DEBUG - 2026-02-22 14:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:06 --> CSRF cookie sent
INFO - 2026-02-22 14:52:06 --> Input Class Initialized
INFO - 2026-02-22 14:52:06 --> Language Class Initialized
INFO - 2026-02-22 14:52:06 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:06 --> Language Class Initialized
INFO - 2026-02-22 14:52:06 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:06 --> Config Class Initialized
INFO - 2026-02-22 14:52:06 --> Loader Class Initialized
INFO - 2026-02-22 14:52:06 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:06 --> Loader Class Initialized
INFO - 2026-02-22 14:52:06 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:06 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:06 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:06 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:06 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:07 --> Upload Class Initialized
DEBUG - 2026-02-22 14:52:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:07 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:07 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:07 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:07 --> Email Class Initialized
INFO - 2026-02-22 14:52:07 --> Controller Class Initialized
ERROR - 2026-02-22 14:52:07 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:07 --> Upload Class Initialized
DEBUG - 2026-02-22 14:52:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:07 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:07 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:07 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:07 --> Config Class Initialized
INFO - 2026-02-22 14:52:07 --> Hooks Class Initialized
INFO - 2026-02-22 14:52:07 --> Email Class Initialized
DEBUG - 2026-02-22 14:52:07 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:07 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:07 --> Controller Class Initialized
ERROR - 2026-02-22 14:52:07 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:52:07 --> URI Class Initialized
INFO - 2026-02-22 14:52:07 --> Router Class Initialized
INFO - 2026-02-22 14:52:07 --> Output Class Initialized
INFO - 2026-02-22 14:52:07 --> Security Class Initialized
DEBUG - 2026-02-22 14:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:07 --> CSRF cookie sent
INFO - 2026-02-22 14:52:07 --> Input Class Initialized
INFO - 2026-02-22 14:52:07 --> Language Class Initialized
INFO - 2026-02-22 14:52:07 --> Language Class Initialized
INFO - 2026-02-22 14:52:07 --> Config Class Initialized
INFO - 2026-02-22 14:52:07 --> Config Class Initialized
INFO - 2026-02-22 14:52:07 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:52:07 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:07 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:07 --> Loader Class Initialized
INFO - 2026-02-22 14:52:07 --> URI Class Initialized
INFO - 2026-02-22 14:52:07 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:07 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:07 --> Router Class Initialized
INFO - 2026-02-22 14:52:07 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:07 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:07 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:07 --> Output Class Initialized
INFO - 2026-02-22 14:52:07 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:07 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:07 --> Security Class Initialized
DEBUG - 2026-02-22 14:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:07 --> CSRF cookie sent
INFO - 2026-02-22 14:52:07 --> Input Class Initialized
INFO - 2026-02-22 14:52:07 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:07 --> Language Class Initialized
INFO - 2026-02-22 14:52:07 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:07 --> Language Class Initialized
INFO - 2026-02-22 14:52:07 --> Config Class Initialized
INFO - 2026-02-22 14:52:07 --> Loader Class Initialized
INFO - 2026-02-22 14:52:07 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:07 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:07 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:07 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:07 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:07 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:07 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:07 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:07 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:07 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:07 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:07 --> Upload Class Initialized
DEBUG - 2026-02-22 14:52:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:07 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:07 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:07 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:07 --> Email Class Initialized
INFO - 2026-02-22 14:52:07 --> Controller Class Initialized
ERROR - 2026-02-22 14:52:07 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:07 --> Upload Class Initialized
DEBUG - 2026-02-22 14:52:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:07 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:07 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:07 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:07 --> Config Class Initialized
INFO - 2026-02-22 14:52:07 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:52:07 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:07 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:07 --> Email Class Initialized
INFO - 2026-02-22 14:52:07 --> Controller Class Initialized
INFO - 2026-02-22 14:52:07 --> URI Class Initialized
ERROR - 2026-02-22 14:52:07 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:07 --> Router Class Initialized
INFO - 2026-02-22 14:52:07 --> Upload Class Initialized
INFO - 2026-02-22 14:52:07 --> Output Class Initialized
DEBUG - 2026-02-22 14:52:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:07 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:07 --> Security Class Initialized
DEBUG - 2026-02-22 14:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:08 --> CSRF cookie sent
INFO - 2026-02-22 14:52:08 --> Input Class Initialized
INFO - 2026-02-22 14:52:08 --> Language Class Initialized
INFO - 2026-02-22 14:52:08 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:08 --> Language Class Initialized
INFO - 2026-02-22 14:52:08 --> Config Class Initialized
INFO - 2026-02-22 14:52:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:08 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:08 --> Loader Class Initialized
INFO - 2026-02-22 14:52:08 --> Email Class Initialized
INFO - 2026-02-22 14:52:08 --> Controller Class Initialized
ERROR - 2026-02-22 14:52:08 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:52:08 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:08 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:08 --> Upload Class Initialized
INFO - 2026-02-22 14:52:08 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:08 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:08 --> Helper loaded: email_helper
DEBUG - 2026-02-22 14:52:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:08 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:08 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:08 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:08 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:08 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:08 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:08 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:08 --> Email Class Initialized
INFO - 2026-02-22 14:52:08 --> Controller Class Initialized
ERROR - 2026-02-22 14:52:08 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:52:08 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:10 --> Upload Class Initialized
DEBUG - 2026-02-22 14:52:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:10 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:10 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:10 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:10 --> Email Class Initialized
INFO - 2026-02-22 14:52:10 --> Controller Class Initialized
ERROR - 2026-02-22 14:52:10 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:10 --> Upload Class Initialized
DEBUG - 2026-02-22 14:52:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:10 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:10 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:10 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:10 --> Email Class Initialized
INFO - 2026-02-22 14:52:10 --> Controller Class Initialized
DEBUG - 2026-02-22 14:52:10 --> Page MX_Controller Initialized
INFO - 2026-02-22 14:52:10 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:52:10 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:52:10 --> Model "Page_model" initialized
INFO - 2026-02-22 14:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:13 --> Upload Class Initialized
DEBUG - 2026-02-22 14:52:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:13 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:13 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:13 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:13 --> Email Class Initialized
INFO - 2026-02-22 14:52:13 --> Controller Class Initialized
ERROR - 2026-02-22 14:52:13 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:52:15 --> Config Class Initialized
INFO - 2026-02-22 14:52:15 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:52:15 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:15 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:15 --> URI Class Initialized
INFO - 2026-02-22 14:52:15 --> Router Class Initialized
INFO - 2026-02-22 14:52:15 --> Output Class Initialized
INFO - 2026-02-22 14:52:15 --> Security Class Initialized
DEBUG - 2026-02-22 14:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:15 --> CSRF cookie sent
INFO - 2026-02-22 14:52:15 --> Input Class Initialized
INFO - 2026-02-22 14:52:15 --> Language Class Initialized
INFO - 2026-02-22 14:52:15 --> Language Class Initialized
INFO - 2026-02-22 14:52:15 --> Config Class Initialized
INFO - 2026-02-22 14:52:15 --> Loader Class Initialized
INFO - 2026-02-22 14:52:15 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:15 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:15 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:15 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:15 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:15 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:15 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:15 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:15 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:15 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:17 --> Upload Class Initialized
DEBUG - 2026-02-22 14:52:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:17 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:17 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:17 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:17 --> Email Class Initialized
INFO - 2026-02-22 14:52:17 --> Controller Class Initialized
DEBUG - 2026-02-22 14:52:17 --> Dashboard MX_Controller Initialized
INFO - 2026-02-22 14:52:17 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:52:17 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:52:17 --> Model "Dashboard_model" initialized
DEBUG - 2026-02-22 14:52:17 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:52:17 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:52:17 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:52:17 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:52:17 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:52:17 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/dashboard_index.php
INFO - 2026-02-22 14:52:17 --> Final output sent to browser
DEBUG - 2026-02-22 14:52:17 --> Total execution time: 2.6088
INFO - 2026-02-22 14:52:18 --> Config Class Initialized
INFO - 2026-02-22 14:52:18 --> Hooks Class Initialized
INFO - 2026-02-22 14:52:18 --> Config Class Initialized
INFO - 2026-02-22 14:52:18 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:52:18 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:18 --> Utf8 Class Initialized
DEBUG - 2026-02-22 14:52:18 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:18 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:18 --> URI Class Initialized
INFO - 2026-02-22 14:52:18 --> URI Class Initialized
INFO - 2026-02-22 14:52:18 --> Router Class Initialized
INFO - 2026-02-22 14:52:18 --> Router Class Initialized
INFO - 2026-02-22 14:52:18 --> Output Class Initialized
INFO - 2026-02-22 14:52:18 --> Output Class Initialized
INFO - 2026-02-22 14:52:18 --> Security Class Initialized
DEBUG - 2026-02-22 14:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:18 --> CSRF cookie sent
INFO - 2026-02-22 14:52:18 --> Input Class Initialized
INFO - 2026-02-22 14:52:18 --> Security Class Initialized
DEBUG - 2026-02-22 14:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:18 --> CSRF cookie sent
INFO - 2026-02-22 14:52:18 --> Input Class Initialized
INFO - 2026-02-22 14:52:18 --> Language Class Initialized
INFO - 2026-02-22 14:52:18 --> Language Class Initialized
INFO - 2026-02-22 14:52:18 --> Language Class Initialized
INFO - 2026-02-22 14:52:18 --> Config Class Initialized
INFO - 2026-02-22 14:52:18 --> Loader Class Initialized
INFO - 2026-02-22 14:52:18 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:18 --> Language Class Initialized
INFO - 2026-02-22 14:52:18 --> Config Class Initialized
INFO - 2026-02-22 14:52:18 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:18 --> Loader Class Initialized
INFO - 2026-02-22 14:52:18 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:18 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:18 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:18 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:18 --> Config Class Initialized
INFO - 2026-02-22 14:52:18 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:52:18 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:18 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:18 --> URI Class Initialized
INFO - 2026-02-22 14:52:18 --> Config Class Initialized
INFO - 2026-02-22 14:52:18 --> Hooks Class Initialized
INFO - 2026-02-22 14:52:18 --> Router Class Initialized
DEBUG - 2026-02-22 14:52:18 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:18 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:18 --> Output Class Initialized
INFO - 2026-02-22 14:52:18 --> URI Class Initialized
INFO - 2026-02-22 14:52:18 --> Security Class Initialized
INFO - 2026-02-22 14:52:18 --> Router Class Initialized
DEBUG - 2026-02-22 14:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:18 --> CSRF cookie sent
INFO - 2026-02-22 14:52:18 --> Input Class Initialized
INFO - 2026-02-22 14:52:18 --> Language Class Initialized
INFO - 2026-02-22 14:52:18 --> Output Class Initialized
INFO - 2026-02-22 14:52:18 --> Language Class Initialized
INFO - 2026-02-22 14:52:18 --> Config Class Initialized
INFO - 2026-02-22 14:52:18 --> Security Class Initialized
DEBUG - 2026-02-22 14:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:18 --> CSRF cookie sent
INFO - 2026-02-22 14:52:18 --> Input Class Initialized
INFO - 2026-02-22 14:52:18 --> Language Class Initialized
INFO - 2026-02-22 14:52:18 --> Loader Class Initialized
INFO - 2026-02-22 14:52:18 --> Language Class Initialized
INFO - 2026-02-22 14:52:18 --> Config Class Initialized
INFO - 2026-02-22 14:52:18 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:18 --> Loader Class Initialized
INFO - 2026-02-22 14:52:18 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:18 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:18 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:18 --> Config Class Initialized
INFO - 2026-02-22 14:52:18 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:52:18 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:18 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:18 --> Config Class Initialized
INFO - 2026-02-22 14:52:18 --> Hooks Class Initialized
INFO - 2026-02-22 14:52:18 --> URI Class Initialized
DEBUG - 2026-02-22 14:52:18 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:18 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:18 --> Router Class Initialized
INFO - 2026-02-22 14:52:18 --> URI Class Initialized
INFO - 2026-02-22 14:52:18 --> Output Class Initialized
INFO - 2026-02-22 14:52:18 --> Router Class Initialized
INFO - 2026-02-22 14:52:18 --> Security Class Initialized
DEBUG - 2026-02-22 14:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:18 --> CSRF cookie sent
INFO - 2026-02-22 14:52:18 --> Input Class Initialized
INFO - 2026-02-22 14:52:18 --> Language Class Initialized
INFO - 2026-02-22 14:52:18 --> Output Class Initialized
INFO - 2026-02-22 14:52:18 --> Language Class Initialized
INFO - 2026-02-22 14:52:18 --> Config Class Initialized
INFO - 2026-02-22 14:52:18 --> Security Class Initialized
DEBUG - 2026-02-22 14:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:18 --> CSRF cookie sent
INFO - 2026-02-22 14:52:18 --> Input Class Initialized
INFO - 2026-02-22 14:52:18 --> Loader Class Initialized
INFO - 2026-02-22 14:52:18 --> Language Class Initialized
INFO - 2026-02-22 14:52:18 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:18 --> Language Class Initialized
INFO - 2026-02-22 14:52:18 --> Config Class Initialized
INFO - 2026-02-22 14:52:18 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:18 --> Loader Class Initialized
INFO - 2026-02-22 14:52:18 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:18 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:18 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:18 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:20 --> Upload Class Initialized
DEBUG - 2026-02-22 14:52:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:20 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:20 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:20 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:20 --> Email Class Initialized
INFO - 2026-02-22 14:52:20 --> Controller Class Initialized
ERROR - 2026-02-22 14:52:20 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:20 --> Upload Class Initialized
DEBUG - 2026-02-22 14:52:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:20 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:20 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:20 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:20 --> Config Class Initialized
INFO - 2026-02-22 14:52:20 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:52:20 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:20 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:20 --> URI Class Initialized
INFO - 2026-02-22 14:52:20 --> Email Class Initialized
INFO - 2026-02-22 14:52:20 --> Controller Class Initialized
ERROR - 2026-02-22 14:52:20 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:20 --> Router Class Initialized
INFO - 2026-02-22 14:52:20 --> Upload Class Initialized
INFO - 2026-02-22 14:52:20 --> Output Class Initialized
DEBUG - 2026-02-22 14:52:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:20 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:20 --> Security Class Initialized
INFO - 2026-02-22 14:52:20 --> Form Validation Class Initialized
DEBUG - 2026-02-22 14:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:20 --> Input Class Initialized
INFO - 2026-02-22 14:52:20 --> Language Class Initialized
INFO - 2026-02-22 14:52:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:20 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:20 --> Language Class Initialized
INFO - 2026-02-22 14:52:20 --> Config Class Initialized
INFO - 2026-02-22 14:52:20 --> Email Class Initialized
INFO - 2026-02-22 14:52:20 --> Controller Class Initialized
INFO - 2026-02-22 14:52:20 --> Loader Class Initialized
ERROR - 2026-02-22 14:52:20 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:20 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:20 --> Config Class Initialized
INFO - 2026-02-22 14:52:20 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:52:20 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:20 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:20 --> Upload Class Initialized
INFO - 2026-02-22 14:52:20 --> URI Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: html_helper
DEBUG - 2026-02-22 14:52:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:20 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:20 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:20 --> Router Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:20 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:20 --> Output Class Initialized
INFO - 2026-02-22 14:52:20 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:20 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:20 --> Security Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: domain_helper
DEBUG - 2026-02-22 14:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:20 --> Input Class Initialized
INFO - 2026-02-22 14:52:20 --> Config Class Initialized
INFO - 2026-02-22 14:52:20 --> Hooks Class Initialized
INFO - 2026-02-22 14:52:20 --> Language Class Initialized
INFO - 2026-02-22 14:52:20 --> Language Class Initialized
INFO - 2026-02-22 14:52:20 --> Config Class Initialized
INFO - 2026-02-22 14:52:20 --> Email Class Initialized
INFO - 2026-02-22 14:52:20 --> Controller Class Initialized
DEBUG - 2026-02-22 14:52:20 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:20 --> Utf8 Class Initialized
ERROR - 2026-02-22 14:52:20 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:20 --> URI Class Initialized
INFO - 2026-02-22 14:52:20 --> Loader Class Initialized
INFO - 2026-02-22 14:52:20 --> Router Class Initialized
INFO - 2026-02-22 14:52:20 --> Upload Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:20 --> Output Class Initialized
DEBUG - 2026-02-22 14:52:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:20 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:20 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:20 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:20 --> Security Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:20 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:20 --> Form Validation Class Initialized
DEBUG - 2026-02-22 14:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:20 --> Input Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:20 --> Language Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:20 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:20 --> Language Class Initialized
INFO - 2026-02-22 14:52:20 --> Config Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:20 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:20 --> Email Class Initialized
INFO - 2026-02-22 14:52:20 --> Controller Class Initialized
INFO - 2026-02-22 14:52:20 --> Config Class Initialized
INFO - 2026-02-22 14:52:20 --> Hooks Class Initialized
ERROR - 2026-02-22 14:52:20 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:20 --> Loader Class Initialized
DEBUG - 2026-02-22 14:52:20 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:20 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:20 --> Upload Class Initialized
INFO - 2026-02-22 14:52:20 --> URI Class Initialized
DEBUG - 2026-02-22 14:52:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:20 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:20 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:20 --> Router Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:20 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:20 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:20 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:20 --> Output Class Initialized
INFO - 2026-02-22 14:52:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:20 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:20 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:20 --> Security Class Initialized
INFO - 2026-02-22 14:52:20 --> Config Class Initialized
INFO - 2026-02-22 14:52:20 --> Hooks Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:20 --> Email Class Initialized
DEBUG - 2026-02-22 14:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:20 --> Controller Class Initialized
INFO - 2026-02-22 14:52:20 --> Input Class Initialized
ERROR - 2026-02-22 14:52:20 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:52:20 --> Language Class Initialized
DEBUG - 2026-02-22 14:52:20 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:20 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:20 --> URI Class Initialized
INFO - 2026-02-22 14:52:20 --> Language Class Initialized
INFO - 2026-02-22 14:52:20 --> Config Class Initialized
INFO - 2026-02-22 14:52:20 --> Router Class Initialized
INFO - 2026-02-22 14:52:20 --> Output Class Initialized
INFO - 2026-02-22 14:52:20 --> Loader Class Initialized
INFO - 2026-02-22 14:52:20 --> Security Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: url_helper
DEBUG - 2026-02-22 14:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:20 --> Input Class Initialized
INFO - 2026-02-22 14:52:20 --> Language Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:20 --> Language Class Initialized
INFO - 2026-02-22 14:52:20 --> Config Class Initialized
INFO - 2026-02-22 14:52:20 --> Config Class Initialized
INFO - 2026-02-22 14:52:20 --> Hooks Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:20 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: file_helper
DEBUG - 2026-02-22 14:52:20 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:20 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:20 --> URI Class Initialized
INFO - 2026-02-22 14:52:20 --> Loader Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:20 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:20 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:20 --> Router Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:20 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:20 --> Output Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:20 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:20 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:20 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:20 --> Security Class Initialized
DEBUG - 2026-02-22 14:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:20 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:20 --> Input Class Initialized
INFO - 2026-02-22 14:52:20 --> Language Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:20 --> Language Class Initialized
INFO - 2026-02-22 14:52:20 --> Config Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:20 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:20 --> Loader Class Initialized
INFO - 2026-02-22 14:52:20 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:20 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:20 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:20 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:20 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:20 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:20 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:20 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:20 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:20 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:20 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:22 --> Upload Class Initialized
DEBUG - 2026-02-22 14:52:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:22 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:22 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:22 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:22 --> Email Class Initialized
INFO - 2026-02-22 14:52:22 --> Controller Class Initialized
DEBUG - 2026-02-22 14:52:22 --> Dashboard MX_Controller Initialized
INFO - 2026-02-22 14:52:22 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:52:22 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:52:22 --> Model "Dashboard_model" initialized
INFO - 2026-02-22 14:52:23 --> Final output sent to browser
DEBUG - 2026-02-22 14:52:23 --> Total execution time: 3.1437
INFO - 2026-02-22 14:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:23 --> Upload Class Initialized
DEBUG - 2026-02-22 14:52:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:23 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:23 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:23 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:23 --> Config Class Initialized
INFO - 2026-02-22 14:52:23 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:52:23 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:23 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:23 --> Email Class Initialized
INFO - 2026-02-22 14:52:23 --> Controller Class Initialized
INFO - 2026-02-22 14:52:23 --> URI Class Initialized
DEBUG - 2026-02-22 14:52:23 --> Ticket MX_Controller Initialized
INFO - 2026-02-22 14:52:23 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:52:23 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:52:23 --> Router Class Initialized
INFO - 2026-02-22 14:52:23 --> Model "Support_model" initialized
INFO - 2026-02-22 14:52:23 --> Output Class Initialized
INFO - 2026-02-22 14:52:23 --> Model "Common_model" initialized
INFO - 2026-02-22 14:52:23 --> Security Class Initialized
DEBUG - 2026-02-22 14:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:23 --> CSRF cookie sent
INFO - 2026-02-22 14:52:23 --> Input Class Initialized
INFO - 2026-02-22 14:52:23 --> Language Class Initialized
INFO - 2026-02-22 14:52:23 --> Language Class Initialized
INFO - 2026-02-22 14:52:23 --> Config Class Initialized
INFO - 2026-02-22 14:52:23 --> Loader Class Initialized
INFO - 2026-02-22 14:52:23 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:23 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:23 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:23 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:23 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:23 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:23 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:23 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:23 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:23 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:24 --> Final output sent to browser
DEBUG - 2026-02-22 14:52:24 --> Total execution time: 3.9413
INFO - 2026-02-22 14:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:24 --> Upload Class Initialized
DEBUG - 2026-02-22 14:52:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:24 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:24 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:24 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:24 --> Config Class Initialized
INFO - 2026-02-22 14:52:24 --> Hooks Class Initialized
INFO - 2026-02-22 14:52:24 --> Email Class Initialized
INFO - 2026-02-22 14:52:24 --> Controller Class Initialized
DEBUG - 2026-02-22 14:52:24 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:24 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:24 --> URI Class Initialized
DEBUG - 2026-02-22 14:52:24 --> Order MX_Controller Initialized
INFO - 2026-02-22 14:52:24 --> Router Class Initialized
INFO - 2026-02-22 14:52:24 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:52:24 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:52:24 --> Output Class Initialized
INFO - 2026-02-22 14:52:24 --> Security Class Initialized
DEBUG - 2026-02-22 14:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:24 --> CSRF cookie sent
INFO - 2026-02-22 14:52:24 --> Input Class Initialized
INFO - 2026-02-22 14:52:24 --> Language Class Initialized
INFO - 2026-02-22 14:52:24 --> Language Class Initialized
INFO - 2026-02-22 14:52:24 --> Config Class Initialized
INFO - 2026-02-22 14:52:24 --> Loader Class Initialized
INFO - 2026-02-22 14:52:24 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:24 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:24 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:24 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:24 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:24 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:24 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:24 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:24 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:24 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:24 --> Model "Order_model" initialized
INFO - 2026-02-22 14:52:24 --> Model "Common_model" initialized
INFO - 2026-02-22 14:52:24 --> Model "Currency_model" initialized
INFO - 2026-02-22 14:52:24 --> Final output sent to browser
DEBUG - 2026-02-22 14:52:24 --> Total execution time: 4.8738
INFO - 2026-02-22 14:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:24 --> Upload Class Initialized
DEBUG - 2026-02-22 14:52:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:24 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:24 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:24 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:24 --> Email Class Initialized
INFO - 2026-02-22 14:52:24 --> Controller Class Initialized
DEBUG - 2026-02-22 14:52:24 --> Dashboard MX_Controller Initialized
INFO - 2026-02-22 14:52:24 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:52:24 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:52:25 --> Config Class Initialized
INFO - 2026-02-22 14:52:25 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:52:25 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:25 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:25 --> URI Class Initialized
INFO - 2026-02-22 14:52:25 --> Router Class Initialized
INFO - 2026-02-22 14:52:25 --> Output Class Initialized
INFO - 2026-02-22 14:52:25 --> Security Class Initialized
DEBUG - 2026-02-22 14:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:25 --> CSRF cookie sent
INFO - 2026-02-22 14:52:25 --> Input Class Initialized
INFO - 2026-02-22 14:52:25 --> Language Class Initialized
INFO - 2026-02-22 14:52:25 --> Language Class Initialized
INFO - 2026-02-22 14:52:25 --> Config Class Initialized
INFO - 2026-02-22 14:52:25 --> Loader Class Initialized
INFO - 2026-02-22 14:52:25 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:25 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:25 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:25 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:25 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:25 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:25 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:25 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:25 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:25 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:25 --> Model "Dashboard_model" initialized
INFO - 2026-02-22 14:52:25 --> Final output sent to browser
DEBUG - 2026-02-22 14:52:25 --> Total execution time: 5.6501
INFO - 2026-02-22 14:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:25 --> Upload Class Initialized
DEBUG - 2026-02-22 14:52:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:25 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:25 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:25 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:25 --> Email Class Initialized
INFO - 2026-02-22 14:52:25 --> Controller Class Initialized
DEBUG - 2026-02-22 14:52:25 --> Invoice MX_Controller Initialized
INFO - 2026-02-22 14:52:25 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:52:25 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:52:25 --> Model "Billing_model" initialized
INFO - 2026-02-22 14:52:25 --> Model "Common_model" initialized
INFO - 2026-02-22 14:52:25 --> Model "Invoice_model" initialized
INFO - 2026-02-22 14:52:25 --> Model "Appsetting_model" initialized
INFO - 2026-02-22 14:52:26 --> Final output sent to browser
DEBUG - 2026-02-22 14:52:26 --> Total execution time: 6.4910
INFO - 2026-02-22 14:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:26 --> Upload Class Initialized
DEBUG - 2026-02-22 14:52:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:26 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:26 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:26 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:26 --> Email Class Initialized
INFO - 2026-02-22 14:52:26 --> Controller Class Initialized
DEBUG - 2026-02-22 14:52:26 --> Dashboard MX_Controller Initialized
INFO - 2026-02-22 14:52:26 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:52:26 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:52:27 --> Model "Dashboard_model" initialized
INFO - 2026-02-22 14:52:27 --> Final output sent to browser
DEBUG - 2026-02-22 14:52:27 --> Total execution time: 7.3996
INFO - 2026-02-22 14:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:27 --> Upload Class Initialized
DEBUG - 2026-02-22 14:52:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:27 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:27 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:27 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:27 --> Email Class Initialized
INFO - 2026-02-22 14:52:27 --> Controller Class Initialized
ERROR - 2026-02-22 14:52:27 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:27 --> Upload Class Initialized
DEBUG - 2026-02-22 14:52:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:27 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:27 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:27 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:27 --> Email Class Initialized
INFO - 2026-02-22 14:52:27 --> Controller Class Initialized
ERROR - 2026-02-22 14:52:27 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:27 --> Upload Class Initialized
DEBUG - 2026-02-22 14:52:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:27 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:27 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:27 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:27 --> Email Class Initialized
INFO - 2026-02-22 14:52:27 --> Controller Class Initialized
DEBUG - 2026-02-22 14:52:27 --> Page MX_Controller Initialized
INFO - 2026-02-22 14:52:27 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:52:27 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:52:27 --> Model "Page_model" initialized
DEBUG - 2026-02-22 14:52:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-22 14:52:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-22 14:52:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-22 14:52:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-22 14:52:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-22 14:52:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/page_list.php
INFO - 2026-02-22 14:52:28 --> Final output sent to browser
DEBUG - 2026-02-22 14:52:28 --> Total execution time: 3.0340
INFO - 2026-02-22 14:52:28 --> Config Class Initialized
INFO - 2026-02-22 14:52:28 --> Hooks Class Initialized
INFO - 2026-02-22 14:52:28 --> Config Class Initialized
INFO - 2026-02-22 14:52:28 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:52:28 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:28 --> Utf8 Class Initialized
DEBUG - 2026-02-22 14:52:28 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:28 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:28 --> URI Class Initialized
INFO - 2026-02-22 14:52:28 --> URI Class Initialized
INFO - 2026-02-22 14:52:28 --> Router Class Initialized
INFO - 2026-02-22 14:52:28 --> Router Class Initialized
INFO - 2026-02-22 14:52:28 --> Output Class Initialized
INFO - 2026-02-22 14:52:28 --> Output Class Initialized
INFO - 2026-02-22 14:52:28 --> Security Class Initialized
DEBUG - 2026-02-22 14:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:28 --> CSRF cookie sent
INFO - 2026-02-22 14:52:28 --> Input Class Initialized
INFO - 2026-02-22 14:52:28 --> Security Class Initialized
INFO - 2026-02-22 14:52:28 --> Language Class Initialized
INFO - 2026-02-22 14:52:28 --> Language Class Initialized
INFO - 2026-02-22 14:52:28 --> Config Class Initialized
DEBUG - 2026-02-22 14:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:28 --> CSRF cookie sent
INFO - 2026-02-22 14:52:28 --> Input Class Initialized
INFO - 2026-02-22 14:52:28 --> Language Class Initialized
INFO - 2026-02-22 14:52:28 --> Language Class Initialized
INFO - 2026-02-22 14:52:28 --> Config Class Initialized
INFO - 2026-02-22 14:52:28 --> Loader Class Initialized
INFO - 2026-02-22 14:52:28 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:28 --> Loader Class Initialized
INFO - 2026-02-22 14:52:28 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:28 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:28 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:28 --> Config Class Initialized
INFO - 2026-02-22 14:52:28 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:52:28 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:28 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:28 --> URI Class Initialized
INFO - 2026-02-22 14:52:28 --> Router Class Initialized
INFO - 2026-02-22 14:52:28 --> Output Class Initialized
INFO - 2026-02-22 14:52:28 --> Security Class Initialized
DEBUG - 2026-02-22 14:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:28 --> CSRF cookie sent
INFO - 2026-02-22 14:52:28 --> Input Class Initialized
INFO - 2026-02-22 14:52:28 --> Language Class Initialized
INFO - 2026-02-22 14:52:28 --> Language Class Initialized
INFO - 2026-02-22 14:52:28 --> Config Class Initialized
INFO - 2026-02-22 14:52:28 --> Loader Class Initialized
INFO - 2026-02-22 14:52:28 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:28 --> Config Class Initialized
INFO - 2026-02-22 14:52:28 --> Hooks Class Initialized
INFO - 2026-02-22 14:52:28 --> Helper loaded: form_helper
DEBUG - 2026-02-22 14:52:28 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:28 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:28 --> Config Class Initialized
INFO - 2026-02-22 14:52:28 --> Hooks Class Initialized
INFO - 2026-02-22 14:52:28 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: email_helper
DEBUG - 2026-02-22 14:52:28 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:28 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:28 --> URI Class Initialized
INFO - 2026-02-22 14:52:28 --> URI Class Initialized
INFO - 2026-02-22 14:52:28 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:28 --> Config Class Initialized
INFO - 2026-02-22 14:52:28 --> Router Class Initialized
INFO - 2026-02-22 14:52:28 --> Hooks Class Initialized
INFO - 2026-02-22 14:52:28 --> Router Class Initialized
INFO - 2026-02-22 14:52:28 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:28 --> Output Class Initialized
INFO - 2026-02-22 14:52:28 --> Output Class Initialized
DEBUG - 2026-02-22 14:52:28 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:28 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:28 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:28 --> Security Class Initialized
INFO - 2026-02-22 14:52:28 --> URI Class Initialized
INFO - 2026-02-22 14:52:28 --> Security Class Initialized
DEBUG - 2026-02-22 14:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:28 --> CSRF cookie sent
INFO - 2026-02-22 14:52:28 --> Input Class Initialized
INFO - 2026-02-22 14:52:28 --> Language Class Initialized
DEBUG - 2026-02-22 14:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:28 --> CSRF cookie sent
INFO - 2026-02-22 14:52:28 --> Input Class Initialized
INFO - 2026-02-22 14:52:28 --> Language Class Initialized
INFO - 2026-02-22 14:52:28 --> Language Class Initialized
INFO - 2026-02-22 14:52:28 --> Config Class Initialized
INFO - 2026-02-22 14:52:28 --> Router Class Initialized
INFO - 2026-02-22 14:52:28 --> Language Class Initialized
INFO - 2026-02-22 14:52:28 --> Config Class Initialized
INFO - 2026-02-22 14:52:28 --> Output Class Initialized
INFO - 2026-02-22 14:52:28 --> Loader Class Initialized
INFO - 2026-02-22 14:52:28 --> Loader Class Initialized
INFO - 2026-02-22 14:52:28 --> Security Class Initialized
INFO - 2026-02-22 14:52:28 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: url_helper
DEBUG - 2026-02-22 14:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:28 --> CSRF cookie sent
INFO - 2026-02-22 14:52:28 --> Input Class Initialized
INFO - 2026-02-22 14:52:28 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:28 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:28 --> Language Class Initialized
INFO - 2026-02-22 14:52:28 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:28 --> Language Class Initialized
INFO - 2026-02-22 14:52:28 --> Config Class Initialized
INFO - 2026-02-22 14:52:28 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:28 --> Loader Class Initialized
INFO - 2026-02-22 14:52:28 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:28 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:28 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:28 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:28 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:30 --> Upload Class Initialized
DEBUG - 2026-02-22 14:52:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:30 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:30 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:30 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:30 --> Email Class Initialized
INFO - 2026-02-22 14:52:30 --> Controller Class Initialized
ERROR - 2026-02-22 14:52:30 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:30 --> Upload Class Initialized
INFO - 2026-02-22 14:52:30 --> Config Class Initialized
INFO - 2026-02-22 14:52:30 --> Hooks Class Initialized
DEBUG - 2026-02-22 14:52:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:30 --> Encryption Class Initialized
DEBUG - 2026-02-22 14:52:30 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:30 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:30 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:30 --> URI Class Initialized
INFO - 2026-02-22 14:52:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:30 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:30 --> Router Class Initialized
INFO - 2026-02-22 14:52:30 --> Output Class Initialized
INFO - 2026-02-22 14:52:30 --> Email Class Initialized
INFO - 2026-02-22 14:52:30 --> Controller Class Initialized
ERROR - 2026-02-22 14:52:30 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:52:30 --> Security Class Initialized
INFO - 2026-02-22 14:52:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-02-22 14:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:30 --> CSRF cookie sent
INFO - 2026-02-22 14:52:30 --> Input Class Initialized
INFO - 2026-02-22 14:52:30 --> Language Class Initialized
INFO - 2026-02-22 14:52:30 --> Upload Class Initialized
INFO - 2026-02-22 14:52:30 --> Language Class Initialized
INFO - 2026-02-22 14:52:30 --> Config Class Initialized
DEBUG - 2026-02-22 14:52:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:30 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:30 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:30 --> Loader Class Initialized
INFO - 2026-02-22 14:52:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:30 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:30 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:30 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:30 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:30 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:30 --> Config Class Initialized
INFO - 2026-02-22 14:52:30 --> Hooks Class Initialized
INFO - 2026-02-22 14:52:30 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:30 --> Email Class Initialized
INFO - 2026-02-22 14:52:30 --> Controller Class Initialized
ERROR - 2026-02-22 14:52:30 --> 404 Page Not Found: /index
DEBUG - 2026-02-22 14:52:30 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:30 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:30 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:30 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:30 --> URI Class Initialized
INFO - 2026-02-22 14:52:30 --> Upload Class Initialized
INFO - 2026-02-22 14:52:30 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:30 --> Router Class Initialized
INFO - 2026-02-22 14:52:30 --> Helper loaded: domain_helper
DEBUG - 2026-02-22 14:52:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:30 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:30 --> Output Class Initialized
INFO - 2026-02-22 14:52:30 --> Security Class Initialized
INFO - 2026-02-22 14:52:30 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:30 --> Pagination Class Initialized
DEBUG - 2026-02-22 14:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:30 --> CSRF cookie sent
INFO - 2026-02-22 14:52:30 --> Input Class Initialized
INFO - 2026-02-22 14:52:30 --> Language Class Initialized
INFO - 2026-02-22 14:52:30 --> Language Class Initialized
INFO - 2026-02-22 14:52:30 --> Config Class Initialized
INFO - 2026-02-22 14:52:30 --> Config Class Initialized
INFO - 2026-02-22 14:52:30 --> Hooks Class Initialized
INFO - 2026-02-22 14:52:30 --> Email Class Initialized
INFO - 2026-02-22 14:52:30 --> Controller Class Initialized
DEBUG - 2026-02-22 14:52:30 --> UTF-8 Support Enabled
INFO - 2026-02-22 14:52:30 --> Utf8 Class Initialized
INFO - 2026-02-22 14:52:30 --> Database Driver Class Initialized
ERROR - 2026-02-22 14:52:30 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:52:30 --> URI Class Initialized
INFO - 2026-02-22 14:52:30 --> Loader Class Initialized
INFO - 2026-02-22 14:52:30 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:30 --> Router Class Initialized
INFO - 2026-02-22 14:52:30 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:30 --> Output Class Initialized
INFO - 2026-02-22 14:52:30 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:30 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:30 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:30 --> Security Class Initialized
INFO - 2026-02-22 14:52:30 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:30 --> Helper loaded: ssp_helper
DEBUG - 2026-02-22 14:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-22 14:52:30 --> CSRF cookie sent
INFO - 2026-02-22 14:52:30 --> Input Class Initialized
INFO - 2026-02-22 14:52:30 --> Language Class Initialized
INFO - 2026-02-22 14:52:30 --> Language Class Initialized
INFO - 2026-02-22 14:52:30 --> Config Class Initialized
INFO - 2026-02-22 14:52:30 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:30 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:30 --> Loader Class Initialized
INFO - 2026-02-22 14:52:30 --> Helper loaded: url_helper
INFO - 2026-02-22 14:52:30 --> Helper loaded: form_helper
INFO - 2026-02-22 14:52:30 --> Helper loaded: html_helper
INFO - 2026-02-22 14:52:30 --> Helper loaded: file_helper
INFO - 2026-02-22 14:52:30 --> Helper loaded: email_helper
INFO - 2026-02-22 14:52:30 --> Helper loaded: whmaz_helper
INFO - 2026-02-22 14:52:30 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:30 --> Helper loaded: ssp_helper
INFO - 2026-02-22 14:52:30 --> Helper loaded: cpanel_helper
INFO - 2026-02-22 14:52:30 --> Helper loaded: domain_helper
INFO - 2026-02-22 14:52:30 --> Database Driver Class Initialized
INFO - 2026-02-22 14:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:31 --> Upload Class Initialized
DEBUG - 2026-02-22 14:52:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:31 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:31 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:31 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:31 --> Email Class Initialized
INFO - 2026-02-22 14:52:31 --> Controller Class Initialized
ERROR - 2026-02-22 14:52:31 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:31 --> Upload Class Initialized
DEBUG - 2026-02-22 14:52:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:31 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:31 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:31 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:31 --> Email Class Initialized
INFO - 2026-02-22 14:52:31 --> Controller Class Initialized
ERROR - 2026-02-22 14:52:31 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:32 --> Upload Class Initialized
DEBUG - 2026-02-22 14:52:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:32 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:32 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:32 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:32 --> Email Class Initialized
INFO - 2026-02-22 14:52:32 --> Controller Class Initialized
ERROR - 2026-02-22 14:52:32 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:32 --> Upload Class Initialized
DEBUG - 2026-02-22 14:52:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:32 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:32 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:32 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:32 --> Email Class Initialized
INFO - 2026-02-22 14:52:32 --> Controller Class Initialized
ERROR - 2026-02-22 14:52:32 --> 404 Page Not Found: /index
INFO - 2026-02-22 14:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-22 14:52:32 --> Upload Class Initialized
DEBUG - 2026-02-22 14:52:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-22 14:52:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-22 14:52:32 --> Encryption Class Initialized
INFO - 2026-02-22 14:52:32 --> Form Validation Class Initialized
INFO - 2026-02-22 14:52:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-22 14:52:32 --> Pagination Class Initialized
INFO - 2026-02-22 14:52:32 --> Email Class Initialized
INFO - 2026-02-22 14:52:32 --> Controller Class Initialized
DEBUG - 2026-02-22 14:52:32 --> Page MX_Controller Initialized
INFO - 2026-02-22 14:52:32 --> Model "Loginattempt_model" initialized
INFO - 2026-02-22 14:52:32 --> Model "Adminauth_model" initialized
INFO - 2026-02-22 14:52:32 --> Model "Page_model" initialized

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-06-20 04:39:20 --> Config Class Initialized
INFO - 2026-06-20 04:39:20 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:39:20 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:39:20 --> Utf8 Class Initialized
INFO - 2026-06-20 04:39:20 --> URI Class Initialized
DEBUG - 2026-06-20 04:39:20 --> No URI present. Default controller set.
INFO - 2026-06-20 04:39:20 --> Router Class Initialized
INFO - 2026-06-20 04:39:20 --> Output Class Initialized
INFO - 2026-06-20 04:39:20 --> Security Class Initialized
DEBUG - 2026-06-20 04:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:39:20 --> CSRF cookie sent
INFO - 2026-06-20 04:39:20 --> Input Class Initialized
INFO - 2026-06-20 04:39:20 --> Language Class Initialized
INFO - 2026-06-20 04:39:20 --> Language Class Initialized
INFO - 2026-06-20 04:39:20 --> Config Class Initialized
INFO - 2026-06-20 04:39:20 --> Loader Class Initialized
INFO - 2026-06-20 04:39:20 --> Helper loaded: url_helper
INFO - 2026-06-20 04:39:20 --> Helper loaded: form_helper
INFO - 2026-06-20 04:39:20 --> Helper loaded: html_helper
INFO - 2026-06-20 04:39:20 --> Helper loaded: file_helper
INFO - 2026-06-20 04:39:20 --> Helper loaded: email_helper
INFO - 2026-06-20 04:39:20 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:39:20 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:39:20 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:39:20 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:39:20 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:39:20 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:39:20 --> Database Driver Class Initialized
INFO - 2026-06-20 04:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:39:23 --> Upload Class Initialized
DEBUG - 2026-06-20 04:39:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:39:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:39:23 --> Encryption Class Initialized
INFO - 2026-06-20 04:39:23 --> Form Validation Class Initialized
INFO - 2026-06-20 04:39:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:39:23 --> Pagination Class Initialized
INFO - 2026-06-20 04:39:23 --> Email Class Initialized
INFO - 2026-06-20 04:39:23 --> Controller Class Initialized
DEBUG - 2026-06-20 04:39:23 --> Auth MX_Controller Initialized
INFO - 2026-06-20 04:39:23 --> Model "Loginattempt_model" initialized
INFO - 2026-06-20 04:39:23 --> Model "Auth_model" initialized
INFO - 2026-06-20 04:39:23 --> Model "Cart_model" initialized
INFO - 2026-06-20 04:39:23 --> Model "Appsetting_model" initialized
INFO - 2026-06-20 04:39:23 --> Config Class Initialized
INFO - 2026-06-20 04:39:23 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:39:23 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:39:23 --> Utf8 Class Initialized
INFO - 2026-06-20 04:39:23 --> URI Class Initialized
INFO - 2026-06-20 04:39:23 --> Router Class Initialized
INFO - 2026-06-20 04:39:23 --> Output Class Initialized
INFO - 2026-06-20 04:39:23 --> Security Class Initialized
DEBUG - 2026-06-20 04:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:39:23 --> CSRF cookie sent
INFO - 2026-06-20 04:39:23 --> Input Class Initialized
INFO - 2026-06-20 04:39:23 --> Language Class Initialized
INFO - 2026-06-20 04:39:23 --> Language Class Initialized
INFO - 2026-06-20 04:39:23 --> Config Class Initialized
INFO - 2026-06-20 04:39:23 --> Loader Class Initialized
INFO - 2026-06-20 04:39:23 --> Helper loaded: url_helper
INFO - 2026-06-20 04:39:23 --> Helper loaded: form_helper
INFO - 2026-06-20 04:39:23 --> Helper loaded: html_helper
INFO - 2026-06-20 04:39:23 --> Helper loaded: file_helper
INFO - 2026-06-20 04:39:23 --> Helper loaded: email_helper
INFO - 2026-06-20 04:39:23 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:39:23 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:39:23 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:39:23 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:39:23 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:39:23 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:39:23 --> Database Driver Class Initialized
INFO - 2026-06-20 04:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:39:25 --> Upload Class Initialized
DEBUG - 2026-06-20 04:39:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:39:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:39:25 --> Encryption Class Initialized
INFO - 2026-06-20 04:39:25 --> Form Validation Class Initialized
INFO - 2026-06-20 04:39:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:39:25 --> Pagination Class Initialized
INFO - 2026-06-20 04:39:25 --> Email Class Initialized
INFO - 2026-06-20 04:39:25 --> Controller Class Initialized
DEBUG - 2026-06-20 04:39:25 --> Auth MX_Controller Initialized
INFO - 2026-06-20 04:39:25 --> Model "Loginattempt_model" initialized
INFO - 2026-06-20 04:39:25 --> Model "Auth_model" initialized
INFO - 2026-06-20 04:39:25 --> Model "Cart_model" initialized
INFO - 2026-06-20 04:39:25 --> Model "Appsetting_model" initialized
DEBUG - 2026-06-20 04:39:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-06-20 04:39:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-06-20 04:39:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-06-20 04:39:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-06-20 04:39:25 --> Final output sent to browser
DEBUG - 2026-06-20 04:39:25 --> Total execution time: 2.4020
INFO - 2026-06-20 04:39:26 --> Config Class Initialized
INFO - 2026-06-20 04:39:26 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:39:26 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:39:26 --> Utf8 Class Initialized
INFO - 2026-06-20 04:39:26 --> URI Class Initialized
INFO - 2026-06-20 04:39:26 --> Router Class Initialized
INFO - 2026-06-20 04:39:26 --> Output Class Initialized
INFO - 2026-06-20 04:39:26 --> Security Class Initialized
DEBUG - 2026-06-20 04:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:39:26 --> CSRF cookie sent
INFO - 2026-06-20 04:39:26 --> Input Class Initialized
INFO - 2026-06-20 04:39:26 --> Language Class Initialized
INFO - 2026-06-20 04:39:26 --> Language Class Initialized
INFO - 2026-06-20 04:39:26 --> Config Class Initialized
INFO - 2026-06-20 04:39:26 --> Loader Class Initialized
INFO - 2026-06-20 04:39:26 --> Helper loaded: url_helper
INFO - 2026-06-20 04:39:26 --> Helper loaded: form_helper
INFO - 2026-06-20 04:39:26 --> Helper loaded: html_helper
INFO - 2026-06-20 04:39:26 --> Helper loaded: file_helper
INFO - 2026-06-20 04:39:26 --> Helper loaded: email_helper
INFO - 2026-06-20 04:39:26 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:39:26 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:39:26 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:39:26 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:39:26 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:39:26 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:39:26 --> Database Driver Class Initialized
INFO - 2026-06-20 04:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:39:28 --> Upload Class Initialized
DEBUG - 2026-06-20 04:39:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:39:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:39:28 --> Encryption Class Initialized
INFO - 2026-06-20 04:39:28 --> Form Validation Class Initialized
INFO - 2026-06-20 04:39:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:39:28 --> Pagination Class Initialized
INFO - 2026-06-20 04:39:28 --> Email Class Initialized
INFO - 2026-06-20 04:39:28 --> Controller Class Initialized
DEBUG - 2026-06-20 04:39:28 --> Cart MX_Controller Initialized
INFO - 2026-06-20 04:39:28 --> Model "Loginattempt_model" initialized
INFO - 2026-06-20 04:39:28 --> Model "Auth_model" initialized
INFO - 2026-06-20 04:39:28 --> Model "Cart_model" initialized
INFO - 2026-06-20 04:39:28 --> Model "Common_model" initialized
INFO - 2026-06-20 04:39:28 --> Model "Order_model" initialized
INFO - 2026-06-20 04:39:28 --> Model "Appsetting_model" initialized
INFO - 2026-06-20 04:39:28 --> Model "PaymentGateway_model" initialized
INFO - 2026-06-20 04:39:28 --> Model "Promocode_model" initialized
INFO - 2026-06-20 04:39:28 --> Final output sent to browser
DEBUG - 2026-06-20 04:39:28 --> Total execution time: 2.3714
INFO - 2026-06-20 04:39:37 --> Config Class Initialized
INFO - 2026-06-20 04:39:37 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:39:37 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:39:37 --> Utf8 Class Initialized
INFO - 2026-06-20 04:39:37 --> URI Class Initialized
INFO - 2026-06-20 04:39:37 --> Router Class Initialized
INFO - 2026-06-20 04:39:37 --> Output Class Initialized
INFO - 2026-06-20 04:39:37 --> Security Class Initialized
DEBUG - 2026-06-20 04:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:39:37 --> CSRF cookie sent
INFO - 2026-06-20 04:39:37 --> Input Class Initialized
INFO - 2026-06-20 04:39:37 --> Language Class Initialized
INFO - 2026-06-20 04:39:37 --> Language Class Initialized
INFO - 2026-06-20 04:39:37 --> Config Class Initialized
INFO - 2026-06-20 04:39:37 --> Loader Class Initialized
INFO - 2026-06-20 04:39:37 --> Helper loaded: url_helper
INFO - 2026-06-20 04:39:37 --> Helper loaded: form_helper
INFO - 2026-06-20 04:39:37 --> Helper loaded: html_helper
INFO - 2026-06-20 04:39:37 --> Helper loaded: file_helper
INFO - 2026-06-20 04:39:37 --> Helper loaded: email_helper
INFO - 2026-06-20 04:39:37 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:39:37 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:39:37 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:39:37 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:39:37 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:39:37 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:39:37 --> Database Driver Class Initialized
INFO - 2026-06-20 04:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:39:39 --> Upload Class Initialized
DEBUG - 2026-06-20 04:39:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:39:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:39:39 --> Encryption Class Initialized
INFO - 2026-06-20 04:39:39 --> Form Validation Class Initialized
INFO - 2026-06-20 04:39:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:39:39 --> Pagination Class Initialized
INFO - 2026-06-20 04:39:39 --> Email Class Initialized
INFO - 2026-06-20 04:39:39 --> Controller Class Initialized
DEBUG - 2026-06-20 04:39:39 --> Cart MX_Controller Initialized
INFO - 2026-06-20 04:39:39 --> Model "Loginattempt_model" initialized
INFO - 2026-06-20 04:39:39 --> Model "Auth_model" initialized
INFO - 2026-06-20 04:39:39 --> Model "Cart_model" initialized
INFO - 2026-06-20 04:39:39 --> Model "Common_model" initialized
INFO - 2026-06-20 04:39:39 --> Model "Order_model" initialized
INFO - 2026-06-20 04:39:39 --> Model "Appsetting_model" initialized
INFO - 2026-06-20 04:39:39 --> Model "PaymentGateway_model" initialized
INFO - 2026-06-20 04:39:39 --> Model "Promocode_model" initialized
DEBUG - 2026-06-20 04:39:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-06-20 04:39:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-06-20 04:39:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-06-20 04:39:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-06-20 04:39:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-06-20 04:39:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/cart_regnewdomain.php
INFO - 2026-06-20 04:39:41 --> Final output sent to browser
DEBUG - 2026-06-20 04:39:41 --> Total execution time: 3.9202
INFO - 2026-06-20 04:39:42 --> Config Class Initialized
INFO - 2026-06-20 04:39:42 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:39:42 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:39:42 --> Utf8 Class Initialized
INFO - 2026-06-20 04:39:42 --> URI Class Initialized
INFO - 2026-06-20 04:39:42 --> Router Class Initialized
INFO - 2026-06-20 04:39:42 --> Output Class Initialized
INFO - 2026-06-20 04:39:42 --> Security Class Initialized
DEBUG - 2026-06-20 04:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:39:42 --> CSRF cookie sent
INFO - 2026-06-20 04:39:42 --> Input Class Initialized
INFO - 2026-06-20 04:39:42 --> Language Class Initialized
INFO - 2026-06-20 04:39:42 --> Language Class Initialized
INFO - 2026-06-20 04:39:42 --> Config Class Initialized
INFO - 2026-06-20 04:39:42 --> Loader Class Initialized
INFO - 2026-06-20 04:39:42 --> Helper loaded: url_helper
INFO - 2026-06-20 04:39:42 --> Helper loaded: form_helper
INFO - 2026-06-20 04:39:42 --> Helper loaded: html_helper
INFO - 2026-06-20 04:39:42 --> Helper loaded: file_helper
INFO - 2026-06-20 04:39:42 --> Helper loaded: email_helper
INFO - 2026-06-20 04:39:42 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:39:42 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:39:42 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:39:42 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:39:42 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:39:42 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:39:42 --> Database Driver Class Initialized
INFO - 2026-06-20 04:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:39:43 --> Upload Class Initialized
DEBUG - 2026-06-20 04:39:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:39:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:39:43 --> Encryption Class Initialized
INFO - 2026-06-20 04:39:43 --> Form Validation Class Initialized
INFO - 2026-06-20 04:39:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:39:43 --> Pagination Class Initialized
INFO - 2026-06-20 04:39:43 --> Email Class Initialized
INFO - 2026-06-20 04:39:43 --> Controller Class Initialized
DEBUG - 2026-06-20 04:39:43 --> Cart MX_Controller Initialized
INFO - 2026-06-20 04:39:43 --> Model "Loginattempt_model" initialized
INFO - 2026-06-20 04:39:43 --> Model "Auth_model" initialized
INFO - 2026-06-20 04:39:43 --> Model "Cart_model" initialized
INFO - 2026-06-20 04:39:43 --> Model "Common_model" initialized
INFO - 2026-06-20 04:39:43 --> Model "Order_model" initialized
INFO - 2026-06-20 04:39:43 --> Model "Appsetting_model" initialized
INFO - 2026-06-20 04:39:43 --> Model "PaymentGateway_model" initialized
INFO - 2026-06-20 04:39:43 --> Model "Promocode_model" initialized
INFO - 2026-06-20 04:39:44 --> Final output sent to browser
DEBUG - 2026-06-20 04:39:44 --> Total execution time: 2.2283
INFO - 2026-06-20 04:39:45 --> Config Class Initialized
INFO - 2026-06-20 04:39:45 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:39:45 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:39:45 --> Utf8 Class Initialized
INFO - 2026-06-20 04:39:45 --> URI Class Initialized
INFO - 2026-06-20 04:39:45 --> Config Class Initialized
INFO - 2026-06-20 04:39:45 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:39:45 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:39:45 --> Utf8 Class Initialized
INFO - 2026-06-20 04:39:45 --> Router Class Initialized
INFO - 2026-06-20 04:39:45 --> URI Class Initialized
INFO - 2026-06-20 04:39:45 --> Output Class Initialized
INFO - 2026-06-20 04:39:45 --> Security Class Initialized
INFO - 2026-06-20 04:39:45 --> Router Class Initialized
INFO - 2026-06-20 04:39:45 --> Config Class Initialized
INFO - 2026-06-20 04:39:45 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:39:45 --> CSRF cookie sent
INFO - 2026-06-20 04:39:45 --> Input Class Initialized
DEBUG - 2026-06-20 04:39:45 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:39:45 --> Utf8 Class Initialized
INFO - 2026-06-20 04:39:45 --> Output Class Initialized
INFO - 2026-06-20 04:39:45 --> Language Class Initialized
INFO - 2026-06-20 04:39:45 --> URI Class Initialized
INFO - 2026-06-20 04:39:45 --> Language Class Initialized
INFO - 2026-06-20 04:39:45 --> Config Class Initialized
INFO - 2026-06-20 04:39:45 --> Security Class Initialized
INFO - 2026-06-20 04:39:45 --> Router Class Initialized
DEBUG - 2026-06-20 04:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:39:45 --> CSRF cookie sent
INFO - 2026-06-20 04:39:45 --> Input Class Initialized
INFO - 2026-06-20 04:39:45 --> Output Class Initialized
INFO - 2026-06-20 04:39:45 --> Language Class Initialized
INFO - 2026-06-20 04:39:45 --> Loader Class Initialized
INFO - 2026-06-20 04:39:45 --> Security Class Initialized
INFO - 2026-06-20 04:39:45 --> Language Class Initialized
INFO - 2026-06-20 04:39:45 --> Config Class Initialized
INFO - 2026-06-20 04:39:45 --> Helper loaded: url_helper
DEBUG - 2026-06-20 04:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:39:45 --> CSRF cookie sent
INFO - 2026-06-20 04:39:45 --> Input Class Initialized
INFO - 2026-06-20 04:39:45 --> Language Class Initialized
INFO - 2026-06-20 04:39:45 --> Language Class Initialized
INFO - 2026-06-20 04:39:45 --> Config Class Initialized
INFO - 2026-06-20 04:39:45 --> Helper loaded: form_helper
INFO - 2026-06-20 04:39:45 --> Helper loaded: html_helper
INFO - 2026-06-20 04:39:45 --> Loader Class Initialized
INFO - 2026-06-20 04:39:45 --> Helper loaded: file_helper
INFO - 2026-06-20 04:39:45 --> Helper loaded: email_helper
INFO - 2026-06-20 04:39:45 --> Helper loaded: url_helper
INFO - 2026-06-20 04:39:45 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:39:45 --> Helper loaded: form_helper
INFO - 2026-06-20 04:39:45 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:39:45 --> Helper loaded: html_helper
INFO - 2026-06-20 04:39:45 --> Helper loaded: file_helper
INFO - 2026-06-20 04:39:45 --> Helper loaded: email_helper
INFO - 2026-06-20 04:39:45 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:39:45 --> Config Class Initialized
INFO - 2026-06-20 04:39:45 --> Hooks Class Initialized
INFO - 2026-06-20 04:39:45 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:39:45 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:39:45 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:39:45 --> Loader Class Initialized
DEBUG - 2026-06-20 04:39:45 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:39:45 --> Utf8 Class Initialized
INFO - 2026-06-20 04:39:45 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: url_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: form_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:39:46 --> Config Class Initialized
INFO - 2026-06-20 04:39:46 --> Hooks Class Initialized
INFO - 2026-06-20 04:39:46 --> URI Class Initialized
DEBUG - 2026-06-20 04:39:46 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:39:46 --> Utf8 Class Initialized
INFO - 2026-06-20 04:39:46 --> Router Class Initialized
INFO - 2026-06-20 04:39:46 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: html_helper
INFO - 2026-06-20 04:39:46 --> URI Class Initialized
INFO - 2026-06-20 04:39:46 --> Helper loaded: file_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: email_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:39:46 --> Config Class Initialized
INFO - 2026-06-20 04:39:46 --> Hooks Class Initialized
INFO - 2026-06-20 04:39:46 --> Router Class Initialized
INFO - 2026-06-20 04:39:46 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:39:46 --> Database Driver Class Initialized
DEBUG - 2026-06-20 04:39:46 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:39:46 --> Utf8 Class Initialized
INFO - 2026-06-20 04:39:46 --> Output Class Initialized
INFO - 2026-06-20 04:39:46 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:39:46 --> Output Class Initialized
INFO - 2026-06-20 04:39:46 --> Database Driver Class Initialized
INFO - 2026-06-20 04:39:46 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:39:46 --> URI Class Initialized
INFO - 2026-06-20 04:39:46 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:39:46 --> Security Class Initialized
INFO - 2026-06-20 04:39:46 --> Security Class Initialized
DEBUG - 2026-06-20 04:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:39:46 --> CSRF cookie sent
INFO - 2026-06-20 04:39:46 --> Input Class Initialized
INFO - 2026-06-20 04:39:46 --> Router Class Initialized
INFO - 2026-06-20 04:39:46 --> Language Class Initialized
INFO - 2026-06-20 04:39:46 --> Language Class Initialized
INFO - 2026-06-20 04:39:46 --> Config Class Initialized
INFO - 2026-06-20 04:39:46 --> Output Class Initialized
INFO - 2026-06-20 04:39:46 --> Database Driver Class Initialized
INFO - 2026-06-20 04:39:46 --> Security Class Initialized
DEBUG - 2026-06-20 04:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:39:46 --> CSRF cookie sent
INFO - 2026-06-20 04:39:46 --> Input Class Initialized
INFO - 2026-06-20 04:39:46 --> Language Class Initialized
DEBUG - 2026-06-20 04:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:39:46 --> CSRF cookie sent
INFO - 2026-06-20 04:39:46 --> Input Class Initialized
INFO - 2026-06-20 04:39:46 --> Language Class Initialized
INFO - 2026-06-20 04:39:46 --> Language Class Initialized
INFO - 2026-06-20 04:39:46 --> Config Class Initialized
INFO - 2026-06-20 04:39:46 --> Loader Class Initialized
INFO - 2026-06-20 04:39:46 --> Language Class Initialized
INFO - 2026-06-20 04:39:46 --> Config Class Initialized
INFO - 2026-06-20 04:39:46 --> Helper loaded: url_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: form_helper
INFO - 2026-06-20 04:39:46 --> Loader Class Initialized
INFO - 2026-06-20 04:39:46 --> Helper loaded: html_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: file_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: email_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: url_helper
INFO - 2026-06-20 04:39:46 --> Loader Class Initialized
INFO - 2026-06-20 04:39:46 --> Helper loaded: form_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: html_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: file_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: email_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: url_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: form_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: html_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: file_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: email_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:39:46 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:39:46 --> Database Driver Class Initialized
INFO - 2026-06-20 04:39:46 --> Database Driver Class Initialized
INFO - 2026-06-20 04:39:46 --> Database Driver Class Initialized
INFO - 2026-06-20 04:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:39:47 --> Upload Class Initialized
DEBUG - 2026-06-20 04:39:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:39:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:39:47 --> Encryption Class Initialized
INFO - 2026-06-20 04:39:47 --> Form Validation Class Initialized
INFO - 2026-06-20 04:39:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:39:47 --> Pagination Class Initialized
INFO - 2026-06-20 04:39:47 --> Email Class Initialized
INFO - 2026-06-20 04:39:47 --> Controller Class Initialized
ERROR - 2026-06-20 04:39:47 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:39:47 --> Upload Class Initialized
DEBUG - 2026-06-20 04:39:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:39:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:39:47 --> Encryption Class Initialized
INFO - 2026-06-20 04:39:47 --> Form Validation Class Initialized
INFO - 2026-06-20 04:39:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:39:47 --> Pagination Class Initialized
INFO - 2026-06-20 04:39:47 --> Config Class Initialized
INFO - 2026-06-20 04:39:47 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:39:47 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:39:47 --> Utf8 Class Initialized
INFO - 2026-06-20 04:39:47 --> URI Class Initialized
INFO - 2026-06-20 04:39:47 --> Email Class Initialized
INFO - 2026-06-20 04:39:47 --> Controller Class Initialized
ERROR - 2026-06-20 04:39:47 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:39:47 --> Router Class Initialized
INFO - 2026-06-20 04:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:39:47 --> Output Class Initialized
INFO - 2026-06-20 04:39:47 --> Upload Class Initialized
INFO - 2026-06-20 04:39:47 --> Security Class Initialized
DEBUG - 2026-06-20 04:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:39:47 --> CSRF cookie sent
INFO - 2026-06-20 04:39:47 --> Input Class Initialized
INFO - 2026-06-20 04:39:47 --> Language Class Initialized
DEBUG - 2026-06-20 04:39:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:39:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:39:47 --> Encryption Class Initialized
INFO - 2026-06-20 04:39:47 --> Language Class Initialized
INFO - 2026-06-20 04:39:47 --> Config Class Initialized
INFO - 2026-06-20 04:39:47 --> Form Validation Class Initialized
INFO - 2026-06-20 04:39:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:39:47 --> Pagination Class Initialized
INFO - 2026-06-20 04:39:47 --> Loader Class Initialized
INFO - 2026-06-20 04:39:47 --> Helper loaded: url_helper
INFO - 2026-06-20 04:39:47 --> Helper loaded: form_helper
INFO - 2026-06-20 04:39:47 --> Helper loaded: html_helper
INFO - 2026-06-20 04:39:47 --> Email Class Initialized
INFO - 2026-06-20 04:39:47 --> Controller Class Initialized
INFO - 2026-06-20 04:39:47 --> Helper loaded: file_helper
INFO - 2026-06-20 04:39:47 --> Helper loaded: email_helper
ERROR - 2026-06-20 04:39:47 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:39:47 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:39:47 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:39:47 --> Upload Class Initialized
DEBUG - 2026-06-20 04:39:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:39:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:39:47 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:39:47 --> Encryption Class Initialized
INFO - 2026-06-20 04:39:47 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:39:47 --> Form Validation Class Initialized
INFO - 2026-06-20 04:39:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:39:47 --> Pagination Class Initialized
INFO - 2026-06-20 04:39:47 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:39:47 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:39:47 --> Email Class Initialized
INFO - 2026-06-20 04:39:47 --> Controller Class Initialized
ERROR - 2026-06-20 04:39:47 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:39:47 --> Upload Class Initialized
DEBUG - 2026-06-20 04:39:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:39:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:39:47 --> Encryption Class Initialized
INFO - 2026-06-20 04:39:47 --> Form Validation Class Initialized
INFO - 2026-06-20 04:39:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:39:47 --> Pagination Class Initialized
INFO - 2026-06-20 04:39:47 --> Database Driver Class Initialized
INFO - 2026-06-20 04:39:47 --> Email Class Initialized
INFO - 2026-06-20 04:39:47 --> Controller Class Initialized
ERROR - 2026-06-20 04:39:47 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:39:47 --> Upload Class Initialized
DEBUG - 2026-06-20 04:39:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:39:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:39:47 --> Encryption Class Initialized
INFO - 2026-06-20 04:39:47 --> Form Validation Class Initialized
INFO - 2026-06-20 04:39:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:39:47 --> Pagination Class Initialized
INFO - 2026-06-20 04:39:47 --> Email Class Initialized
INFO - 2026-06-20 04:39:47 --> Controller Class Initialized
ERROR - 2026-06-20 04:39:47 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:39:49 --> Upload Class Initialized
DEBUG - 2026-06-20 04:39:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:39:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:39:49 --> Encryption Class Initialized
INFO - 2026-06-20 04:39:49 --> Form Validation Class Initialized
INFO - 2026-06-20 04:39:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:39:49 --> Pagination Class Initialized
INFO - 2026-06-20 04:39:49 --> Email Class Initialized
INFO - 2026-06-20 04:39:49 --> Controller Class Initialized
ERROR - 2026-06-20 04:39:49 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:40:11 --> Config Class Initialized
INFO - 2026-06-20 04:40:11 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:40:11 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:40:11 --> Utf8 Class Initialized
INFO - 2026-06-20 04:40:11 --> URI Class Initialized
INFO - 2026-06-20 04:40:11 --> Router Class Initialized
INFO - 2026-06-20 04:40:11 --> Output Class Initialized
INFO - 2026-06-20 04:40:11 --> Security Class Initialized
DEBUG - 2026-06-20 04:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:40:11 --> CSRF cookie sent
INFO - 2026-06-20 04:40:11 --> Input Class Initialized
INFO - 2026-06-20 04:40:11 --> Language Class Initialized
INFO - 2026-06-20 04:40:11 --> Language Class Initialized
INFO - 2026-06-20 04:40:11 --> Config Class Initialized
INFO - 2026-06-20 04:40:11 --> Loader Class Initialized
INFO - 2026-06-20 04:40:11 --> Helper loaded: url_helper
INFO - 2026-06-20 04:40:11 --> Helper loaded: form_helper
INFO - 2026-06-20 04:40:11 --> Helper loaded: html_helper
INFO - 2026-06-20 04:40:11 --> Helper loaded: file_helper
INFO - 2026-06-20 04:40:11 --> Helper loaded: email_helper
INFO - 2026-06-20 04:40:11 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:40:11 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:40:11 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:40:11 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:40:11 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:40:11 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:40:11 --> Database Driver Class Initialized
INFO - 2026-06-20 04:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:40:13 --> Upload Class Initialized
DEBUG - 2026-06-20 04:40:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:40:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:40:13 --> Encryption Class Initialized
INFO - 2026-06-20 04:40:13 --> Form Validation Class Initialized
INFO - 2026-06-20 04:40:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:40:13 --> Pagination Class Initialized
INFO - 2026-06-20 04:40:13 --> Email Class Initialized
INFO - 2026-06-20 04:40:13 --> Controller Class Initialized
DEBUG - 2026-06-20 04:40:13 --> Cart MX_Controller Initialized
INFO - 2026-06-20 04:40:13 --> Model "Loginattempt_model" initialized
INFO - 2026-06-20 04:40:13 --> Model "Auth_model" initialized
INFO - 2026-06-20 04:40:13 --> Model "Cart_model" initialized
INFO - 2026-06-20 04:40:13 --> Model "Common_model" initialized
INFO - 2026-06-20 04:40:13 --> Model "Order_model" initialized
INFO - 2026-06-20 04:40:13 --> Model "Appsetting_model" initialized
INFO - 2026-06-20 04:40:13 --> Model "PaymentGateway_model" initialized
INFO - 2026-06-20 04:40:13 --> Model "Promocode_model" initialized
DEBUG - 2026-06-20 04:40:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-06-20 04:40:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-06-20 04:40:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-06-20 04:40:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-06-20 04:40:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-06-20 04:40:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/cart_transferdomain.php
INFO - 2026-06-20 04:40:15 --> Final output sent to browser
DEBUG - 2026-06-20 04:40:15 --> Total execution time: 4.0265
INFO - 2026-06-20 04:40:16 --> Config Class Initialized
INFO - 2026-06-20 04:40:16 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:40:16 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:40:16 --> Utf8 Class Initialized
INFO - 2026-06-20 04:40:16 --> URI Class Initialized
INFO - 2026-06-20 04:40:16 --> Router Class Initialized
INFO - 2026-06-20 04:40:16 --> Output Class Initialized
INFO - 2026-06-20 04:40:16 --> Security Class Initialized
DEBUG - 2026-06-20 04:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:40:16 --> CSRF cookie sent
INFO - 2026-06-20 04:40:16 --> Input Class Initialized
INFO - 2026-06-20 04:40:16 --> Language Class Initialized
INFO - 2026-06-20 04:40:16 --> Language Class Initialized
INFO - 2026-06-20 04:40:16 --> Config Class Initialized
INFO - 2026-06-20 04:40:16 --> Loader Class Initialized
INFO - 2026-06-20 04:40:16 --> Helper loaded: url_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: form_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: html_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: file_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: email_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:40:16 --> Database Driver Class Initialized
INFO - 2026-06-20 04:40:16 --> Config Class Initialized
INFO - 2026-06-20 04:40:16 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:40:16 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:40:16 --> Utf8 Class Initialized
INFO - 2026-06-20 04:40:16 --> URI Class Initialized
INFO - 2026-06-20 04:40:16 --> Router Class Initialized
INFO - 2026-06-20 04:40:16 --> Output Class Initialized
INFO - 2026-06-20 04:40:16 --> Security Class Initialized
DEBUG - 2026-06-20 04:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:40:16 --> CSRF cookie sent
INFO - 2026-06-20 04:40:16 --> Input Class Initialized
INFO - 2026-06-20 04:40:16 --> Language Class Initialized
INFO - 2026-06-20 04:40:16 --> Language Class Initialized
INFO - 2026-06-20 04:40:16 --> Config Class Initialized
INFO - 2026-06-20 04:40:16 --> Loader Class Initialized
INFO - 2026-06-20 04:40:16 --> Helper loaded: url_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: form_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: html_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: file_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: email_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:40:16 --> Database Driver Class Initialized
INFO - 2026-06-20 04:40:16 --> Config Class Initialized
INFO - 2026-06-20 04:40:16 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:40:16 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:40:16 --> Utf8 Class Initialized
INFO - 2026-06-20 04:40:16 --> URI Class Initialized
INFO - 2026-06-20 04:40:16 --> Router Class Initialized
INFO - 2026-06-20 04:40:16 --> Output Class Initialized
INFO - 2026-06-20 04:40:16 --> Security Class Initialized
DEBUG - 2026-06-20 04:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:40:16 --> CSRF cookie sent
INFO - 2026-06-20 04:40:16 --> Input Class Initialized
INFO - 2026-06-20 04:40:16 --> Language Class Initialized
INFO - 2026-06-20 04:40:16 --> Language Class Initialized
INFO - 2026-06-20 04:40:16 --> Config Class Initialized
INFO - 2026-06-20 04:40:16 --> Loader Class Initialized
INFO - 2026-06-20 04:40:16 --> Helper loaded: url_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: form_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: html_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: file_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: email_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:40:16 --> Database Driver Class Initialized
INFO - 2026-06-20 04:40:16 --> Config Class Initialized
INFO - 2026-06-20 04:40:16 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:40:16 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:40:16 --> Utf8 Class Initialized
INFO - 2026-06-20 04:40:16 --> Config Class Initialized
INFO - 2026-06-20 04:40:16 --> Hooks Class Initialized
INFO - 2026-06-20 04:40:16 --> URI Class Initialized
DEBUG - 2026-06-20 04:40:16 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:40:16 --> Utf8 Class Initialized
INFO - 2026-06-20 04:40:16 --> Router Class Initialized
INFO - 2026-06-20 04:40:16 --> URI Class Initialized
INFO - 2026-06-20 04:40:16 --> Output Class Initialized
INFO - 2026-06-20 04:40:16 --> Security Class Initialized
INFO - 2026-06-20 04:40:16 --> Config Class Initialized
INFO - 2026-06-20 04:40:16 --> Hooks Class Initialized
INFO - 2026-06-20 04:40:16 --> Router Class Initialized
DEBUG - 2026-06-20 04:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:40:16 --> CSRF cookie sent
INFO - 2026-06-20 04:40:16 --> Input Class Initialized
INFO - 2026-06-20 04:40:16 --> Language Class Initialized
DEBUG - 2026-06-20 04:40:16 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:40:16 --> Utf8 Class Initialized
INFO - 2026-06-20 04:40:16 --> Language Class Initialized
INFO - 2026-06-20 04:40:16 --> Config Class Initialized
INFO - 2026-06-20 04:40:16 --> Output Class Initialized
INFO - 2026-06-20 04:40:16 --> URI Class Initialized
INFO - 2026-06-20 04:40:16 --> Security Class Initialized
INFO - 2026-06-20 04:40:16 --> Loader Class Initialized
DEBUG - 2026-06-20 04:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:40:16 --> CSRF cookie sent
INFO - 2026-06-20 04:40:16 --> Input Class Initialized
INFO - 2026-06-20 04:40:16 --> Helper loaded: url_helper
INFO - 2026-06-20 04:40:16 --> Router Class Initialized
INFO - 2026-06-20 04:40:16 --> Language Class Initialized
INFO - 2026-06-20 04:40:16 --> Helper loaded: form_helper
INFO - 2026-06-20 04:40:16 --> Language Class Initialized
INFO - 2026-06-20 04:40:16 --> Config Class Initialized
INFO - 2026-06-20 04:40:16 --> Helper loaded: html_helper
INFO - 2026-06-20 04:40:16 --> Output Class Initialized
INFO - 2026-06-20 04:40:16 --> Helper loaded: file_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: email_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:40:16 --> Security Class Initialized
INFO - 2026-06-20 04:40:16 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:40:16 --> Loader Class Initialized
DEBUG - 2026-06-20 04:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:40:16 --> CSRF cookie sent
INFO - 2026-06-20 04:40:16 --> Input Class Initialized
INFO - 2026-06-20 04:40:16 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:40:16 --> Language Class Initialized
INFO - 2026-06-20 04:40:16 --> Helper loaded: url_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:40:16 --> Language Class Initialized
INFO - 2026-06-20 04:40:16 --> Config Class Initialized
INFO - 2026-06-20 04:40:16 --> Helper loaded: form_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: html_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: file_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: email_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:40:16 --> Loader Class Initialized
INFO - 2026-06-20 04:40:16 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: url_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: form_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: html_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: file_helper
INFO - 2026-06-20 04:40:16 --> Database Driver Class Initialized
INFO - 2026-06-20 04:40:16 --> Helper loaded: email_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:40:16 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:40:16 --> Database Driver Class Initialized
INFO - 2026-06-20 04:40:16 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:40:16 --> Database Driver Class Initialized
INFO - 2026-06-20 04:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:40:17 --> Upload Class Initialized
DEBUG - 2026-06-20 04:40:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:40:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:40:17 --> Encryption Class Initialized
INFO - 2026-06-20 04:40:17 --> Form Validation Class Initialized
INFO - 2026-06-20 04:40:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:40:17 --> Pagination Class Initialized
INFO - 2026-06-20 04:40:17 --> Email Class Initialized
INFO - 2026-06-20 04:40:17 --> Controller Class Initialized
ERROR - 2026-06-20 04:40:17 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:40:17 --> Config Class Initialized
INFO - 2026-06-20 04:40:17 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:40:17 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:40:17 --> Utf8 Class Initialized
INFO - 2026-06-20 04:40:17 --> URI Class Initialized
INFO - 2026-06-20 04:40:17 --> Router Class Initialized
INFO - 2026-06-20 04:40:17 --> Output Class Initialized
INFO - 2026-06-20 04:40:17 --> Security Class Initialized
DEBUG - 2026-06-20 04:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:40:17 --> CSRF cookie sent
INFO - 2026-06-20 04:40:17 --> Input Class Initialized
INFO - 2026-06-20 04:40:17 --> Language Class Initialized
INFO - 2026-06-20 04:40:17 --> Language Class Initialized
INFO - 2026-06-20 04:40:17 --> Config Class Initialized
INFO - 2026-06-20 04:40:17 --> Loader Class Initialized
INFO - 2026-06-20 04:40:17 --> Helper loaded: url_helper
INFO - 2026-06-20 04:40:17 --> Helper loaded: form_helper
INFO - 2026-06-20 04:40:17 --> Helper loaded: html_helper
INFO - 2026-06-20 04:40:17 --> Helper loaded: file_helper
INFO - 2026-06-20 04:40:17 --> Helper loaded: email_helper
INFO - 2026-06-20 04:40:17 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:40:17 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:40:17 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:40:17 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:40:17 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:40:17 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:40:17 --> Database Driver Class Initialized
INFO - 2026-06-20 04:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:40:18 --> Upload Class Initialized
DEBUG - 2026-06-20 04:40:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:40:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:40:18 --> Encryption Class Initialized
INFO - 2026-06-20 04:40:18 --> Form Validation Class Initialized
INFO - 2026-06-20 04:40:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:40:18 --> Pagination Class Initialized
INFO - 2026-06-20 04:40:18 --> Email Class Initialized
INFO - 2026-06-20 04:40:18 --> Controller Class Initialized
ERROR - 2026-06-20 04:40:18 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:40:18 --> Upload Class Initialized
DEBUG - 2026-06-20 04:40:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:40:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:40:18 --> Encryption Class Initialized
INFO - 2026-06-20 04:40:18 --> Form Validation Class Initialized
INFO - 2026-06-20 04:40:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:40:18 --> Pagination Class Initialized
INFO - 2026-06-20 04:40:18 --> Config Class Initialized
INFO - 2026-06-20 04:40:18 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:40:18 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:40:18 --> Utf8 Class Initialized
INFO - 2026-06-20 04:40:18 --> URI Class Initialized
INFO - 2026-06-20 04:40:18 --> Email Class Initialized
INFO - 2026-06-20 04:40:18 --> Controller Class Initialized
ERROR - 2026-06-20 04:40:18 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:40:18 --> Router Class Initialized
INFO - 2026-06-20 04:40:18 --> Output Class Initialized
INFO - 2026-06-20 04:40:18 --> Upload Class Initialized
INFO - 2026-06-20 04:40:18 --> Security Class Initialized
DEBUG - 2026-06-20 04:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:40:18 --> CSRF cookie sent
INFO - 2026-06-20 04:40:18 --> Input Class Initialized
DEBUG - 2026-06-20 04:40:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:40:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:40:18 --> Language Class Initialized
INFO - 2026-06-20 04:40:18 --> Encryption Class Initialized
INFO - 2026-06-20 04:40:18 --> Language Class Initialized
INFO - 2026-06-20 04:40:18 --> Config Class Initialized
INFO - 2026-06-20 04:40:18 --> Form Validation Class Initialized
INFO - 2026-06-20 04:40:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:40:18 --> Pagination Class Initialized
INFO - 2026-06-20 04:40:18 --> Loader Class Initialized
INFO - 2026-06-20 04:40:18 --> Helper loaded: url_helper
INFO - 2026-06-20 04:40:18 --> Helper loaded: form_helper
INFO - 2026-06-20 04:40:18 --> Email Class Initialized
INFO - 2026-06-20 04:40:18 --> Controller Class Initialized
INFO - 2026-06-20 04:40:18 --> Helper loaded: html_helper
ERROR - 2026-06-20 04:40:18 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:40:18 --> Helper loaded: file_helper
INFO - 2026-06-20 04:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:40:18 --> Helper loaded: email_helper
INFO - 2026-06-20 04:40:18 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:40:18 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:40:18 --> Upload Class Initialized
INFO - 2026-06-20 04:40:18 --> Helper loaded: cpanel_helper
DEBUG - 2026-06-20 04:40:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:40:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:40:18 --> Encryption Class Initialized
INFO - 2026-06-20 04:40:18 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:40:18 --> Form Validation Class Initialized
INFO - 2026-06-20 04:40:18 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:40:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:40:18 --> Pagination Class Initialized
INFO - 2026-06-20 04:40:18 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:40:18 --> Email Class Initialized
INFO - 2026-06-20 04:40:18 --> Controller Class Initialized
ERROR - 2026-06-20 04:40:18 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:40:18 --> Database Driver Class Initialized
INFO - 2026-06-20 04:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:40:20 --> Upload Class Initialized
DEBUG - 2026-06-20 04:40:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:40:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:40:20 --> Encryption Class Initialized
INFO - 2026-06-20 04:40:20 --> Form Validation Class Initialized
INFO - 2026-06-20 04:40:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:40:20 --> Pagination Class Initialized
INFO - 2026-06-20 04:40:20 --> Email Class Initialized
INFO - 2026-06-20 04:40:20 --> Controller Class Initialized
ERROR - 2026-06-20 04:40:20 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:40:20 --> Upload Class Initialized
DEBUG - 2026-06-20 04:40:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:40:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:40:20 --> Encryption Class Initialized
INFO - 2026-06-20 04:40:20 --> Form Validation Class Initialized
INFO - 2026-06-20 04:40:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:40:20 --> Pagination Class Initialized
INFO - 2026-06-20 04:40:20 --> Email Class Initialized
INFO - 2026-06-20 04:40:20 --> Controller Class Initialized
ERROR - 2026-06-20 04:40:20 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:40:20 --> Upload Class Initialized
DEBUG - 2026-06-20 04:40:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:40:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:40:20 --> Encryption Class Initialized
INFO - 2026-06-20 04:40:20 --> Form Validation Class Initialized
INFO - 2026-06-20 04:40:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:40:20 --> Pagination Class Initialized
INFO - 2026-06-20 04:40:20 --> Email Class Initialized
INFO - 2026-06-20 04:40:20 --> Controller Class Initialized
DEBUG - 2026-06-20 04:40:20 --> Cart MX_Controller Initialized
INFO - 2026-06-20 04:40:20 --> Model "Loginattempt_model" initialized
INFO - 2026-06-20 04:40:20 --> Model "Auth_model" initialized
INFO - 2026-06-20 04:40:20 --> Model "Cart_model" initialized
INFO - 2026-06-20 04:40:20 --> Model "Common_model" initialized
INFO - 2026-06-20 04:40:20 --> Model "Order_model" initialized
INFO - 2026-06-20 04:40:20 --> Model "Appsetting_model" initialized
INFO - 2026-06-20 04:40:20 --> Model "PaymentGateway_model" initialized
INFO - 2026-06-20 04:40:20 --> Model "Promocode_model" initialized
INFO - 2026-06-20 04:40:20 --> Final output sent to browser
DEBUG - 2026-06-20 04:40:20 --> Total execution time: 3.0556
INFO - 2026-06-20 04:40:42 --> Config Class Initialized
INFO - 2026-06-20 04:40:42 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:40:42 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:40:42 --> Utf8 Class Initialized
INFO - 2026-06-20 04:40:42 --> URI Class Initialized
INFO - 2026-06-20 04:40:42 --> Router Class Initialized
INFO - 2026-06-20 04:40:42 --> Output Class Initialized
INFO - 2026-06-20 04:40:42 --> Security Class Initialized
DEBUG - 2026-06-20 04:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:40:42 --> CSRF cookie sent
INFO - 2026-06-20 04:40:42 --> Input Class Initialized
INFO - 2026-06-20 04:40:42 --> Language Class Initialized
INFO - 2026-06-20 04:40:42 --> Language Class Initialized
INFO - 2026-06-20 04:40:42 --> Config Class Initialized
INFO - 2026-06-20 04:40:42 --> Loader Class Initialized
INFO - 2026-06-20 04:40:42 --> Helper loaded: url_helper
INFO - 2026-06-20 04:40:42 --> Helper loaded: form_helper
INFO - 2026-06-20 04:40:42 --> Helper loaded: html_helper
INFO - 2026-06-20 04:40:42 --> Helper loaded: file_helper
INFO - 2026-06-20 04:40:42 --> Helper loaded: email_helper
INFO - 2026-06-20 04:40:42 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:40:42 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:40:42 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:40:42 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:40:42 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:40:42 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:40:42 --> Database Driver Class Initialized
INFO - 2026-06-20 04:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:40:44 --> Upload Class Initialized
DEBUG - 2026-06-20 04:40:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:40:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:40:44 --> Encryption Class Initialized
INFO - 2026-06-20 04:40:44 --> Form Validation Class Initialized
INFO - 2026-06-20 04:40:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:40:44 --> Pagination Class Initialized
INFO - 2026-06-20 04:40:44 --> Email Class Initialized
INFO - 2026-06-20 04:40:44 --> Controller Class Initialized
DEBUG - 2026-06-20 04:40:44 --> Cart MX_Controller Initialized
INFO - 2026-06-20 04:40:44 --> Model "Loginattempt_model" initialized
INFO - 2026-06-20 04:40:44 --> Model "Auth_model" initialized
INFO - 2026-06-20 04:40:44 --> Model "Cart_model" initialized
INFO - 2026-06-20 04:40:44 --> Model "Common_model" initialized
INFO - 2026-06-20 04:40:44 --> Model "Order_model" initialized
INFO - 2026-06-20 04:40:44 --> Model "Appsetting_model" initialized
INFO - 2026-06-20 04:40:44 --> Model "PaymentGateway_model" initialized
INFO - 2026-06-20 04:40:44 --> Model "Promocode_model" initialized
INFO - 2026-06-20 04:40:45 --> Final output sent to browser
DEBUG - 2026-06-20 04:40:45 --> Total execution time: 2.4484
INFO - 2026-06-20 04:40:57 --> Config Class Initialized
INFO - 2026-06-20 04:40:57 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:40:57 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:40:57 --> Utf8 Class Initialized
INFO - 2026-06-20 04:40:57 --> URI Class Initialized
INFO - 2026-06-20 04:40:57 --> Router Class Initialized
INFO - 2026-06-20 04:40:57 --> Output Class Initialized
INFO - 2026-06-20 04:40:57 --> Security Class Initialized
DEBUG - 2026-06-20 04:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:40:57 --> CSRF cookie sent
INFO - 2026-06-20 04:40:57 --> Input Class Initialized
INFO - 2026-06-20 04:40:57 --> Language Class Initialized
INFO - 2026-06-20 04:40:57 --> Language Class Initialized
INFO - 2026-06-20 04:40:57 --> Config Class Initialized
INFO - 2026-06-20 04:40:57 --> Loader Class Initialized
INFO - 2026-06-20 04:40:57 --> Helper loaded: url_helper
INFO - 2026-06-20 04:40:57 --> Helper loaded: form_helper
INFO - 2026-06-20 04:40:57 --> Helper loaded: html_helper
INFO - 2026-06-20 04:40:57 --> Helper loaded: file_helper
INFO - 2026-06-20 04:40:57 --> Helper loaded: email_helper
INFO - 2026-06-20 04:40:57 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:40:57 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:40:57 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:40:57 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:40:57 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:40:57 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:40:58 --> Database Driver Class Initialized
INFO - 2026-06-20 04:40:59 --> Config Class Initialized
INFO - 2026-06-20 04:40:59 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:40:59 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:40:59 --> Utf8 Class Initialized
INFO - 2026-06-20 04:40:59 --> URI Class Initialized
INFO - 2026-06-20 04:40:59 --> Router Class Initialized
INFO - 2026-06-20 04:40:59 --> Output Class Initialized
INFO - 2026-06-20 04:40:59 --> Security Class Initialized
DEBUG - 2026-06-20 04:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:40:59 --> CSRF cookie sent
INFO - 2026-06-20 04:40:59 --> Input Class Initialized
INFO - 2026-06-20 04:40:59 --> Language Class Initialized
INFO - 2026-06-20 04:40:59 --> Language Class Initialized
INFO - 2026-06-20 04:40:59 --> Config Class Initialized
INFO - 2026-06-20 04:40:59 --> Loader Class Initialized
INFO - 2026-06-20 04:40:59 --> Helper loaded: url_helper
INFO - 2026-06-20 04:40:59 --> Helper loaded: form_helper
INFO - 2026-06-20 04:40:59 --> Helper loaded: html_helper
INFO - 2026-06-20 04:40:59 --> Helper loaded: file_helper
INFO - 2026-06-20 04:40:59 --> Helper loaded: email_helper
INFO - 2026-06-20 04:40:59 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:40:59 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:40:59 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:40:59 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:40:59 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:40:59 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:40:59 --> Database Driver Class Initialized
INFO - 2026-06-20 04:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:40:59 --> Upload Class Initialized
DEBUG - 2026-06-20 04:40:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:40:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:40:59 --> Encryption Class Initialized
INFO - 2026-06-20 04:40:59 --> Form Validation Class Initialized
INFO - 2026-06-20 04:40:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:40:59 --> Pagination Class Initialized
INFO - 2026-06-20 04:40:59 --> Email Class Initialized
INFO - 2026-06-20 04:40:59 --> Controller Class Initialized
DEBUG - 2026-06-20 04:40:59 --> Auth MX_Controller Initialized
INFO - 2026-06-20 04:40:59 --> Model "Loginattempt_model" initialized
INFO - 2026-06-20 04:40:59 --> Model "Auth_model" initialized
INFO - 2026-06-20 04:40:59 --> Model "Cart_model" initialized
INFO - 2026-06-20 04:40:59 --> Model "Appsetting_model" initialized
INFO - 2026-06-20 04:41:00 --> Config Class Initialized
INFO - 2026-06-20 04:41:00 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:41:00 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:00 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:00 --> URI Class Initialized
INFO - 2026-06-20 04:41:00 --> Router Class Initialized
INFO - 2026-06-20 04:41:00 --> Output Class Initialized
INFO - 2026-06-20 04:41:00 --> Security Class Initialized
DEBUG - 2026-06-20 04:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:00 --> CSRF cookie sent
INFO - 2026-06-20 04:41:00 --> Input Class Initialized
INFO - 2026-06-20 04:41:00 --> Language Class Initialized
INFO - 2026-06-20 04:41:00 --> Language Class Initialized
INFO - 2026-06-20 04:41:00 --> Config Class Initialized
INFO - 2026-06-20 04:41:00 --> Loader Class Initialized
INFO - 2026-06-20 04:41:00 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:00 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:00 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:00 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:00 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:00 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:00 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:00 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:00 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:00 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:00 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:00 --> Database Driver Class Initialized
DEBUG - 2026-06-20 04:41:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-06-20 04:41:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-06-20 04:41:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-06-20 04:41:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-06-20 04:41:00 --> Final output sent to browser
DEBUG - 2026-06-20 04:41:00 --> Total execution time: 2.2589
INFO - 2026-06-20 04:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:01 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:01 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:01 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:01 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:01 --> Email Class Initialized
INFO - 2026-06-20 04:41:01 --> Controller Class Initialized
DEBUG - 2026-06-20 04:41:01 --> Cart MX_Controller Initialized
INFO - 2026-06-20 04:41:01 --> Model "Loginattempt_model" initialized
INFO - 2026-06-20 04:41:01 --> Model "Auth_model" initialized
INFO - 2026-06-20 04:41:01 --> Model "Cart_model" initialized
INFO - 2026-06-20 04:41:01 --> Model "Common_model" initialized
INFO - 2026-06-20 04:41:01 --> Model "Order_model" initialized
INFO - 2026-06-20 04:41:01 --> Model "Appsetting_model" initialized
INFO - 2026-06-20 04:41:01 --> Model "PaymentGateway_model" initialized
INFO - 2026-06-20 04:41:01 --> Model "Promocode_model" initialized
DEBUG - 2026-06-20 04:41:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-06-20 04:41:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-06-20 04:41:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-06-20 04:41:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-06-20 04:41:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-06-20 04:41:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/cart_services.php
INFO - 2026-06-20 04:41:02 --> Final output sent to browser
DEBUG - 2026-06-20 04:41:02 --> Total execution time: 3.3633
INFO - 2026-06-20 04:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:02 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:02 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:02 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:02 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:02 --> Email Class Initialized
INFO - 2026-06-20 04:41:02 --> Controller Class Initialized
DEBUG - 2026-06-20 04:41:02 --> Cart MX_Controller Initialized
INFO - 2026-06-20 04:41:02 --> Model "Loginattempt_model" initialized
INFO - 2026-06-20 04:41:02 --> Model "Auth_model" initialized
INFO - 2026-06-20 04:41:02 --> Model "Cart_model" initialized
INFO - 2026-06-20 04:41:02 --> Model "Common_model" initialized
INFO - 2026-06-20 04:41:02 --> Model "Order_model" initialized
INFO - 2026-06-20 04:41:02 --> Model "Appsetting_model" initialized
INFO - 2026-06-20 04:41:02 --> Model "PaymentGateway_model" initialized
INFO - 2026-06-20 04:41:02 --> Model "Promocode_model" initialized
DEBUG - 2026-06-20 04:41:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-06-20 04:41:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-06-20 04:41:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-06-20 04:41:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-06-20 04:41:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-06-20 04:41:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/cart_services.php
INFO - 2026-06-20 04:41:04 --> Final output sent to browser
DEBUG - 2026-06-20 04:41:04 --> Total execution time: 4.3372
INFO - 2026-06-20 04:41:04 --> Config Class Initialized
INFO - 2026-06-20 04:41:04 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:41:04 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:04 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:04 --> URI Class Initialized
INFO - 2026-06-20 04:41:04 --> Router Class Initialized
INFO - 2026-06-20 04:41:04 --> Output Class Initialized
INFO - 2026-06-20 04:41:04 --> Security Class Initialized
DEBUG - 2026-06-20 04:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:04 --> CSRF cookie sent
INFO - 2026-06-20 04:41:04 --> Input Class Initialized
INFO - 2026-06-20 04:41:04 --> Language Class Initialized
INFO - 2026-06-20 04:41:04 --> Language Class Initialized
INFO - 2026-06-20 04:41:04 --> Config Class Initialized
INFO - 2026-06-20 04:41:04 --> Loader Class Initialized
INFO - 2026-06-20 04:41:04 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:04 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:04 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:04 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:04 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:04 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:04 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:04 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:05 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:05 --> Config Class Initialized
INFO - 2026-06-20 04:41:05 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:41:05 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:05 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:05 --> URI Class Initialized
INFO - 2026-06-20 04:41:05 --> Router Class Initialized
INFO - 2026-06-20 04:41:05 --> Output Class Initialized
INFO - 2026-06-20 04:41:05 --> Security Class Initialized
DEBUG - 2026-06-20 04:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:05 --> CSRF cookie sent
INFO - 2026-06-20 04:41:05 --> Input Class Initialized
INFO - 2026-06-20 04:41:05 --> Language Class Initialized
INFO - 2026-06-20 04:41:05 --> Language Class Initialized
INFO - 2026-06-20 04:41:05 --> Config Class Initialized
INFO - 2026-06-20 04:41:05 --> Loader Class Initialized
INFO - 2026-06-20 04:41:05 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:05 --> Config Class Initialized
INFO - 2026-06-20 04:41:05 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:41:05 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:05 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:05 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:05 --> URI Class Initialized
INFO - 2026-06-20 04:41:05 --> Router Class Initialized
INFO - 2026-06-20 04:41:05 --> Output Class Initialized
INFO - 2026-06-20 04:41:05 --> Security Class Initialized
DEBUG - 2026-06-20 04:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:05 --> CSRF cookie sent
INFO - 2026-06-20 04:41:05 --> Input Class Initialized
INFO - 2026-06-20 04:41:05 --> Language Class Initialized
INFO - 2026-06-20 04:41:05 --> Language Class Initialized
INFO - 2026-06-20 04:41:05 --> Config Class Initialized
INFO - 2026-06-20 04:41:05 --> Loader Class Initialized
INFO - 2026-06-20 04:41:05 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:05 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:05 --> Config Class Initialized
INFO - 2026-06-20 04:41:05 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:41:05 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:05 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:05 --> URI Class Initialized
INFO - 2026-06-20 04:41:05 --> Router Class Initialized
INFO - 2026-06-20 04:41:05 --> Output Class Initialized
INFO - 2026-06-20 04:41:05 --> Config Class Initialized
INFO - 2026-06-20 04:41:05 --> Hooks Class Initialized
INFO - 2026-06-20 04:41:05 --> Security Class Initialized
DEBUG - 2026-06-20 04:41:05 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:05 --> Utf8 Class Initialized
DEBUG - 2026-06-20 04:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:05 --> CSRF cookie sent
INFO - 2026-06-20 04:41:05 --> Input Class Initialized
INFO - 2026-06-20 04:41:05 --> Language Class Initialized
INFO - 2026-06-20 04:41:05 --> Config Class Initialized
INFO - 2026-06-20 04:41:05 --> Hooks Class Initialized
INFO - 2026-06-20 04:41:05 --> Language Class Initialized
INFO - 2026-06-20 04:41:05 --> Config Class Initialized
DEBUG - 2026-06-20 04:41:05 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:05 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:05 --> Loader Class Initialized
INFO - 2026-06-20 04:41:05 --> URI Class Initialized
INFO - 2026-06-20 04:41:05 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:05 --> Router Class Initialized
INFO - 2026-06-20 04:41:05 --> URI Class Initialized
INFO - 2026-06-20 04:41:05 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:05 --> Router Class Initialized
INFO - 2026-06-20 04:41:05 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:05 --> Output Class Initialized
INFO - 2026-06-20 04:41:05 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:05 --> Security Class Initialized
INFO - 2026-06-20 04:41:05 --> Output Class Initialized
INFO - 2026-06-20 04:41:05 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:05 --> Security Class Initialized
DEBUG - 2026-06-20 04:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:05 --> CSRF cookie sent
INFO - 2026-06-20 04:41:05 --> Input Class Initialized
INFO - 2026-06-20 04:41:05 --> Language Class Initialized
INFO - 2026-06-20 04:41:05 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:05 --> Language Class Initialized
INFO - 2026-06-20 04:41:05 --> Config Class Initialized
DEBUG - 2026-06-20 04:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:05 --> CSRF cookie sent
INFO - 2026-06-20 04:41:05 --> Input Class Initialized
INFO - 2026-06-20 04:41:05 --> Language Class Initialized
INFO - 2026-06-20 04:41:05 --> Language Class Initialized
INFO - 2026-06-20 04:41:05 --> Config Class Initialized
INFO - 2026-06-20 04:41:05 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:05 --> Loader Class Initialized
INFO - 2026-06-20 04:41:05 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:05 --> Loader Class Initialized
INFO - 2026-06-20 04:41:05 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:05 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:05 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:05 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:06 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:06 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:06 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:06 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:06 --> Email Class Initialized
INFO - 2026-06-20 04:41:06 --> Controller Class Initialized
ERROR - 2026-06-20 04:41:06 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:41:06 --> Config Class Initialized
INFO - 2026-06-20 04:41:06 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:41:06 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:06 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:06 --> URI Class Initialized
INFO - 2026-06-20 04:41:06 --> Router Class Initialized
INFO - 2026-06-20 04:41:06 --> Output Class Initialized
INFO - 2026-06-20 04:41:06 --> Security Class Initialized
DEBUG - 2026-06-20 04:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:06 --> CSRF cookie sent
INFO - 2026-06-20 04:41:06 --> Input Class Initialized
INFO - 2026-06-20 04:41:06 --> Language Class Initialized
INFO - 2026-06-20 04:41:06 --> Language Class Initialized
INFO - 2026-06-20 04:41:06 --> Config Class Initialized
INFO - 2026-06-20 04:41:06 --> Loader Class Initialized
INFO - 2026-06-20 04:41:06 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:06 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:06 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:06 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:06 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:06 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:06 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:06 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:06 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:06 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:06 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:06 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:06 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:06 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:06 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:06 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:06 --> Email Class Initialized
INFO - 2026-06-20 04:41:06 --> Controller Class Initialized
ERROR - 2026-06-20 04:41:06 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:06 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:06 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:06 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:06 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:06 --> Config Class Initialized
INFO - 2026-06-20 04:41:06 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:41:06 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:06 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:06 --> Email Class Initialized
INFO - 2026-06-20 04:41:06 --> Controller Class Initialized
ERROR - 2026-06-20 04:41:06 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:41:06 --> URI Class Initialized
INFO - 2026-06-20 04:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:07 --> Router Class Initialized
INFO - 2026-06-20 04:41:07 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:07 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:07 --> Output Class Initialized
INFO - 2026-06-20 04:41:07 --> Security Class Initialized
INFO - 2026-06-20 04:41:07 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:07 --> Pagination Class Initialized
DEBUG - 2026-06-20 04:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:07 --> CSRF cookie sent
INFO - 2026-06-20 04:41:07 --> Input Class Initialized
INFO - 2026-06-20 04:41:07 --> Language Class Initialized
INFO - 2026-06-20 04:41:07 --> Language Class Initialized
INFO - 2026-06-20 04:41:07 --> Config Class Initialized
INFO - 2026-06-20 04:41:07 --> Email Class Initialized
INFO - 2026-06-20 04:41:07 --> Controller Class Initialized
ERROR - 2026-06-20 04:41:07 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:41:07 --> Loader Class Initialized
INFO - 2026-06-20 04:41:07 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:07 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:07 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:07 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:07 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:07 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:07 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:07 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:07 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:07 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:07 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:07 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:07 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:07 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:07 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:07 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:07 --> Email Class Initialized
INFO - 2026-06-20 04:41:07 --> Controller Class Initialized
ERROR - 2026-06-20 04:41:07 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:07 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:07 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:07 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:07 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:07 --> Email Class Initialized
INFO - 2026-06-20 04:41:07 --> Controller Class Initialized
ERROR - 2026-06-20 04:41:07 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:08 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:08 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:08 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:08 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:08 --> Email Class Initialized
INFO - 2026-06-20 04:41:08 --> Controller Class Initialized
DEBUG - 2026-06-20 04:41:08 --> Cart MX_Controller Initialized
INFO - 2026-06-20 04:41:08 --> Model "Loginattempt_model" initialized
INFO - 2026-06-20 04:41:08 --> Model "Auth_model" initialized
INFO - 2026-06-20 04:41:08 --> Model "Cart_model" initialized
INFO - 2026-06-20 04:41:08 --> Model "Common_model" initialized
INFO - 2026-06-20 04:41:08 --> Model "Order_model" initialized
INFO - 2026-06-20 04:41:08 --> Model "Appsetting_model" initialized
INFO - 2026-06-20 04:41:08 --> Model "PaymentGateway_model" initialized
INFO - 2026-06-20 04:41:08 --> Model "Promocode_model" initialized
INFO - 2026-06-20 04:41:09 --> Final output sent to browser
DEBUG - 2026-06-20 04:41:09 --> Total execution time: 2.4396
INFO - 2026-06-20 04:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:09 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:09 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:09 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:09 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:09 --> Email Class Initialized
INFO - 2026-06-20 04:41:09 --> Controller Class Initialized
ERROR - 2026-06-20 04:41:09 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:41:25 --> Config Class Initialized
INFO - 2026-06-20 04:41:25 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:41:25 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:25 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:25 --> URI Class Initialized
INFO - 2026-06-20 04:41:25 --> Router Class Initialized
INFO - 2026-06-20 04:41:25 --> Output Class Initialized
INFO - 2026-06-20 04:41:25 --> Security Class Initialized
DEBUG - 2026-06-20 04:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:25 --> Input Class Initialized
INFO - 2026-06-20 04:41:25 --> Language Class Initialized
INFO - 2026-06-20 04:41:25 --> Language Class Initialized
INFO - 2026-06-20 04:41:25 --> Config Class Initialized
INFO - 2026-06-20 04:41:25 --> Loader Class Initialized
INFO - 2026-06-20 04:41:25 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:25 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:25 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:25 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:25 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:25 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:25 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:25 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:25 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:25 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:25 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:25 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:27 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:27 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:27 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:27 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:27 --> Email Class Initialized
INFO - 2026-06-20 04:41:27 --> Controller Class Initialized
DEBUG - 2026-06-20 04:41:27 --> Cart MX_Controller Initialized
INFO - 2026-06-20 04:41:27 --> Model "Loginattempt_model" initialized
INFO - 2026-06-20 04:41:27 --> Model "Auth_model" initialized
INFO - 2026-06-20 04:41:27 --> Model "Cart_model" initialized
INFO - 2026-06-20 04:41:27 --> Model "Common_model" initialized
INFO - 2026-06-20 04:41:27 --> Model "Order_model" initialized
INFO - 2026-06-20 04:41:27 --> Model "Appsetting_model" initialized
INFO - 2026-06-20 04:41:27 --> Model "PaymentGateway_model" initialized
INFO - 2026-06-20 04:41:27 --> Model "Promocode_model" initialized
INFO - 2026-06-20 04:41:28 --> Final output sent to browser
DEBUG - 2026-06-20 04:41:28 --> Total execution time: 3.3038
INFO - 2026-06-20 04:41:29 --> Config Class Initialized
INFO - 2026-06-20 04:41:29 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:41:29 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:29 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:29 --> URI Class Initialized
INFO - 2026-06-20 04:41:29 --> Router Class Initialized
INFO - 2026-06-20 04:41:29 --> Output Class Initialized
INFO - 2026-06-20 04:41:29 --> Security Class Initialized
DEBUG - 2026-06-20 04:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:29 --> Input Class Initialized
INFO - 2026-06-20 04:41:29 --> Language Class Initialized
INFO - 2026-06-20 04:41:29 --> Language Class Initialized
INFO - 2026-06-20 04:41:29 --> Config Class Initialized
INFO - 2026-06-20 04:41:29 --> Loader Class Initialized
INFO - 2026-06-20 04:41:29 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:29 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:29 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:29 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:29 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:29 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:29 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:29 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:29 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:29 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:29 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:29 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:30 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:30 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:30 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:30 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:30 --> Email Class Initialized
INFO - 2026-06-20 04:41:30 --> Controller Class Initialized
DEBUG - 2026-06-20 04:41:30 --> Cart MX_Controller Initialized
INFO - 2026-06-20 04:41:30 --> Model "Loginattempt_model" initialized
INFO - 2026-06-20 04:41:30 --> Model "Auth_model" initialized
INFO - 2026-06-20 04:41:30 --> Model "Cart_model" initialized
INFO - 2026-06-20 04:41:30 --> Model "Common_model" initialized
INFO - 2026-06-20 04:41:30 --> Model "Order_model" initialized
INFO - 2026-06-20 04:41:30 --> Model "Appsetting_model" initialized
INFO - 2026-06-20 04:41:30 --> Model "PaymentGateway_model" initialized
INFO - 2026-06-20 04:41:30 --> Model "Promocode_model" initialized
INFO - 2026-06-20 04:41:32 --> Final output sent to browser
DEBUG - 2026-06-20 04:41:32 --> Total execution time: 3.1608
INFO - 2026-06-20 04:41:32 --> Config Class Initialized
INFO - 2026-06-20 04:41:32 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:41:32 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:32 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:32 --> URI Class Initialized
INFO - 2026-06-20 04:41:32 --> Router Class Initialized
INFO - 2026-06-20 04:41:32 --> Output Class Initialized
INFO - 2026-06-20 04:41:32 --> Security Class Initialized
DEBUG - 2026-06-20 04:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:32 --> CSRF cookie sent
INFO - 2026-06-20 04:41:32 --> Input Class Initialized
INFO - 2026-06-20 04:41:32 --> Language Class Initialized
INFO - 2026-06-20 04:41:32 --> Language Class Initialized
INFO - 2026-06-20 04:41:32 --> Config Class Initialized
INFO - 2026-06-20 04:41:32 --> Loader Class Initialized
INFO - 2026-06-20 04:41:32 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:32 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:32 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:32 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:32 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:32 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:32 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:32 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:32 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:32 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:32 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:32 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:34 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:34 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:34 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:34 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:34 --> Email Class Initialized
INFO - 2026-06-20 04:41:34 --> Controller Class Initialized
DEBUG - 2026-06-20 04:41:34 --> Cart MX_Controller Initialized
INFO - 2026-06-20 04:41:34 --> Model "Loginattempt_model" initialized
INFO - 2026-06-20 04:41:34 --> Model "Auth_model" initialized
INFO - 2026-06-20 04:41:34 --> Model "Cart_model" initialized
INFO - 2026-06-20 04:41:34 --> Model "Common_model" initialized
INFO - 2026-06-20 04:41:34 --> Model "Order_model" initialized
INFO - 2026-06-20 04:41:34 --> Model "Appsetting_model" initialized
INFO - 2026-06-20 04:41:34 --> Model "PaymentGateway_model" initialized
INFO - 2026-06-20 04:41:34 --> Model "Promocode_model" initialized
DEBUG - 2026-06-20 04:41:37 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-06-20 04:41:37 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-06-20 04:41:37 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-06-20 04:41:37 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-06-20 04:41:37 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-06-20 04:41:37 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/view_card.php
INFO - 2026-06-20 04:41:37 --> Final output sent to browser
DEBUG - 2026-06-20 04:41:37 --> Total execution time: 5.2751
INFO - 2026-06-20 04:41:37 --> Config Class Initialized
INFO - 2026-06-20 04:41:37 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:41:37 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:37 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:37 --> URI Class Initialized
INFO - 2026-06-20 04:41:37 --> Router Class Initialized
INFO - 2026-06-20 04:41:37 --> Output Class Initialized
INFO - 2026-06-20 04:41:37 --> Security Class Initialized
DEBUG - 2026-06-20 04:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:37 --> CSRF cookie sent
INFO - 2026-06-20 04:41:37 --> Input Class Initialized
INFO - 2026-06-20 04:41:37 --> Language Class Initialized
INFO - 2026-06-20 04:41:37 --> Language Class Initialized
INFO - 2026-06-20 04:41:37 --> Config Class Initialized
INFO - 2026-06-20 04:41:37 --> Loader Class Initialized
INFO - 2026-06-20 04:41:37 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:37 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:37 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:37 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:37 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:37 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:37 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:37 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:37 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:37 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:37 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:37 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:38 --> Config Class Initialized
INFO - 2026-06-20 04:41:38 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:41:38 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:38 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:38 --> URI Class Initialized
INFO - 2026-06-20 04:41:38 --> Router Class Initialized
INFO - 2026-06-20 04:41:38 --> Output Class Initialized
INFO - 2026-06-20 04:41:38 --> Security Class Initialized
DEBUG - 2026-06-20 04:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:38 --> CSRF cookie sent
INFO - 2026-06-20 04:41:38 --> Input Class Initialized
INFO - 2026-06-20 04:41:38 --> Language Class Initialized
INFO - 2026-06-20 04:41:38 --> Language Class Initialized
INFO - 2026-06-20 04:41:38 --> Config Class Initialized
INFO - 2026-06-20 04:41:38 --> Loader Class Initialized
INFO - 2026-06-20 04:41:38 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:38 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:38 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:38 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:38 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:38 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:38 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:38 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:38 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:38 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:38 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:38 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:40 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:40 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:40 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:40 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:40 --> Email Class Initialized
INFO - 2026-06-20 04:41:40 --> Controller Class Initialized
DEBUG - 2026-06-20 04:41:40 --> Cart MX_Controller Initialized
INFO - 2026-06-20 04:41:40 --> Model "Loginattempt_model" initialized
INFO - 2026-06-20 04:41:40 --> Model "Auth_model" initialized
INFO - 2026-06-20 04:41:40 --> Model "Cart_model" initialized
INFO - 2026-06-20 04:41:40 --> Model "Common_model" initialized
INFO - 2026-06-20 04:41:40 --> Model "Order_model" initialized
INFO - 2026-06-20 04:41:40 --> Model "Appsetting_model" initialized
INFO - 2026-06-20 04:41:40 --> Model "PaymentGateway_model" initialized
INFO - 2026-06-20 04:41:40 --> Model "Promocode_model" initialized
DEBUG - 2026-06-20 04:41:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-06-20 04:41:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-06-20 04:41:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-06-20 04:41:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-06-20 04:41:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-06-20 04:41:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/cart_services.php
INFO - 2026-06-20 04:41:41 --> Final output sent to browser
DEBUG - 2026-06-20 04:41:41 --> Total execution time: 3.6072
INFO - 2026-06-20 04:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:41 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:41 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:41 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:41 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:41 --> Email Class Initialized
INFO - 2026-06-20 04:41:41 --> Controller Class Initialized
ERROR - 2026-06-20 04:41:41 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:41:42 --> Config Class Initialized
INFO - 2026-06-20 04:41:42 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:41:42 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:42 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:42 --> URI Class Initialized
INFO - 2026-06-20 04:41:42 --> Router Class Initialized
INFO - 2026-06-20 04:41:42 --> Output Class Initialized
INFO - 2026-06-20 04:41:42 --> Security Class Initialized
DEBUG - 2026-06-20 04:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:42 --> CSRF cookie sent
INFO - 2026-06-20 04:41:42 --> Input Class Initialized
INFO - 2026-06-20 04:41:42 --> Language Class Initialized
INFO - 2026-06-20 04:41:42 --> Language Class Initialized
INFO - 2026-06-20 04:41:42 --> Config Class Initialized
INFO - 2026-06-20 04:41:42 --> Loader Class Initialized
INFO - 2026-06-20 04:41:42 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:42 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:42 --> Config Class Initialized
INFO - 2026-06-20 04:41:42 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:41:42 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:42 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:42 --> URI Class Initialized
INFO - 2026-06-20 04:41:42 --> Router Class Initialized
INFO - 2026-06-20 04:41:42 --> Output Class Initialized
INFO - 2026-06-20 04:41:42 --> Security Class Initialized
DEBUG - 2026-06-20 04:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:42 --> CSRF cookie sent
INFO - 2026-06-20 04:41:42 --> Input Class Initialized
INFO - 2026-06-20 04:41:42 --> Language Class Initialized
INFO - 2026-06-20 04:41:42 --> Language Class Initialized
INFO - 2026-06-20 04:41:42 --> Config Class Initialized
INFO - 2026-06-20 04:41:42 --> Loader Class Initialized
INFO - 2026-06-20 04:41:42 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:42 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:42 --> Config Class Initialized
INFO - 2026-06-20 04:41:42 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:41:42 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:42 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:42 --> URI Class Initialized
INFO - 2026-06-20 04:41:42 --> Router Class Initialized
INFO - 2026-06-20 04:41:42 --> Output Class Initialized
INFO - 2026-06-20 04:41:42 --> Security Class Initialized
DEBUG - 2026-06-20 04:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:42 --> CSRF cookie sent
INFO - 2026-06-20 04:41:42 --> Input Class Initialized
INFO - 2026-06-20 04:41:42 --> Language Class Initialized
INFO - 2026-06-20 04:41:42 --> Language Class Initialized
INFO - 2026-06-20 04:41:42 --> Config Class Initialized
INFO - 2026-06-20 04:41:42 --> Loader Class Initialized
INFO - 2026-06-20 04:41:42 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:42 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:42 --> Config Class Initialized
INFO - 2026-06-20 04:41:42 --> Hooks Class Initialized
INFO - 2026-06-20 04:41:42 --> Config Class Initialized
INFO - 2026-06-20 04:41:42 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:41:42 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:42 --> Config Class Initialized
INFO - 2026-06-20 04:41:42 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:42 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:41:42 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:42 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:42 --> URI Class Initialized
DEBUG - 2026-06-20 04:41:42 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:42 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:42 --> URI Class Initialized
INFO - 2026-06-20 04:41:42 --> URI Class Initialized
INFO - 2026-06-20 04:41:42 --> Router Class Initialized
INFO - 2026-06-20 04:41:42 --> Output Class Initialized
INFO - 2026-06-20 04:41:42 --> Router Class Initialized
INFO - 2026-06-20 04:41:42 --> Router Class Initialized
INFO - 2026-06-20 04:41:42 --> Security Class Initialized
INFO - 2026-06-20 04:41:42 --> Output Class Initialized
INFO - 2026-06-20 04:41:42 --> Output Class Initialized
DEBUG - 2026-06-20 04:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:42 --> CSRF cookie sent
INFO - 2026-06-20 04:41:42 --> Input Class Initialized
INFO - 2026-06-20 04:41:42 --> Language Class Initialized
INFO - 2026-06-20 04:41:42 --> Security Class Initialized
INFO - 2026-06-20 04:41:42 --> Language Class Initialized
INFO - 2026-06-20 04:41:42 --> Security Class Initialized
INFO - 2026-06-20 04:41:42 --> Config Class Initialized
DEBUG - 2026-06-20 04:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:42 --> CSRF cookie sent
INFO - 2026-06-20 04:41:42 --> Input Class Initialized
DEBUG - 2026-06-20 04:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:42 --> CSRF cookie sent
INFO - 2026-06-20 04:41:42 --> Input Class Initialized
INFO - 2026-06-20 04:41:42 --> Language Class Initialized
INFO - 2026-06-20 04:41:42 --> Language Class Initialized
INFO - 2026-06-20 04:41:42 --> Language Class Initialized
INFO - 2026-06-20 04:41:42 --> Config Class Initialized
INFO - 2026-06-20 04:41:42 --> Loader Class Initialized
INFO - 2026-06-20 04:41:42 --> Language Class Initialized
INFO - 2026-06-20 04:41:42 --> Config Class Initialized
INFO - 2026-06-20 04:41:42 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:42 --> Loader Class Initialized
INFO - 2026-06-20 04:41:42 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:42 --> Loader Class Initialized
INFO - 2026-06-20 04:41:42 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:42 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:42 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:42 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:42 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:42 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:43 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:43 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:43 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:43 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:43 --> Email Class Initialized
INFO - 2026-06-20 04:41:43 --> Controller Class Initialized
ERROR - 2026-06-20 04:41:43 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:41:43 --> Config Class Initialized
INFO - 2026-06-20 04:41:43 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:41:43 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:43 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:43 --> URI Class Initialized
INFO - 2026-06-20 04:41:43 --> Router Class Initialized
INFO - 2026-06-20 04:41:43 --> Output Class Initialized
INFO - 2026-06-20 04:41:43 --> Security Class Initialized
DEBUG - 2026-06-20 04:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:43 --> CSRF cookie sent
INFO - 2026-06-20 04:41:43 --> Input Class Initialized
INFO - 2026-06-20 04:41:43 --> Language Class Initialized
INFO - 2026-06-20 04:41:43 --> Language Class Initialized
INFO - 2026-06-20 04:41:43 --> Config Class Initialized
INFO - 2026-06-20 04:41:43 --> Loader Class Initialized
INFO - 2026-06-20 04:41:43 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:43 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:43 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:43 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:43 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:43 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:43 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:43 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:43 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:43 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:43 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:43 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:44 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:44 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:44 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:44 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:44 --> Email Class Initialized
INFO - 2026-06-20 04:41:44 --> Controller Class Initialized
ERROR - 2026-06-20 04:41:44 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:44 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:44 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:44 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:44 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:44 --> Config Class Initialized
INFO - 2026-06-20 04:41:44 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:41:44 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:44 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:44 --> Email Class Initialized
INFO - 2026-06-20 04:41:44 --> Controller Class Initialized
INFO - 2026-06-20 04:41:44 --> URI Class Initialized
ERROR - 2026-06-20 04:41:44 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:44 --> Router Class Initialized
INFO - 2026-06-20 04:41:44 --> Upload Class Initialized
INFO - 2026-06-20 04:41:44 --> Output Class Initialized
DEBUG - 2026-06-20 04:41:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:44 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:44 --> Security Class Initialized
INFO - 2026-06-20 04:41:44 --> Form Validation Class Initialized
DEBUG - 2026-06-20 04:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:44 --> CSRF cookie sent
INFO - 2026-06-20 04:41:44 --> Input Class Initialized
INFO - 2026-06-20 04:41:44 --> Language Class Initialized
INFO - 2026-06-20 04:41:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:44 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:44 --> Language Class Initialized
INFO - 2026-06-20 04:41:44 --> Config Class Initialized
INFO - 2026-06-20 04:41:44 --> Loader Class Initialized
INFO - 2026-06-20 04:41:44 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:44 --> Email Class Initialized
INFO - 2026-06-20 04:41:44 --> Controller Class Initialized
INFO - 2026-06-20 04:41:44 --> Config Class Initialized
INFO - 2026-06-20 04:41:44 --> Hooks Class Initialized
ERROR - 2026-06-20 04:41:44 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:41:44 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:44 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:44 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:44 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:44 --> Helper loaded: whmaz_helper
DEBUG - 2026-06-20 04:41:44 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:44 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:44 --> Upload Class Initialized
INFO - 2026-06-20 04:41:44 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:44 --> URI Class Initialized
INFO - 2026-06-20 04:41:44 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:44 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:44 --> Router Class Initialized
INFO - 2026-06-20 04:41:44 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:44 --> Output Class Initialized
DEBUG - 2026-06-20 04:41:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:44 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:44 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:44 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:44 --> Security Class Initialized
INFO - 2026-06-20 04:41:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:44 --> Pagination Class Initialized
DEBUG - 2026-06-20 04:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:44 --> CSRF cookie sent
INFO - 2026-06-20 04:41:44 --> Input Class Initialized
INFO - 2026-06-20 04:41:44 --> Language Class Initialized
INFO - 2026-06-20 04:41:44 --> Email Class Initialized
INFO - 2026-06-20 04:41:44 --> Language Class Initialized
INFO - 2026-06-20 04:41:44 --> Config Class Initialized
INFO - 2026-06-20 04:41:44 --> Controller Class Initialized
ERROR - 2026-06-20 04:41:44 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:41:44 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:44 --> Loader Class Initialized
INFO - 2026-06-20 04:41:44 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:44 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:44 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:44 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:44 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:44 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:44 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:44 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:44 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:44 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:44 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:44 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:44 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:44 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:44 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:44 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:44 --> Email Class Initialized
INFO - 2026-06-20 04:41:44 --> Controller Class Initialized
ERROR - 2026-06-20 04:41:44 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:46 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:46 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:46 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:46 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:46 --> Email Class Initialized
INFO - 2026-06-20 04:41:46 --> Controller Class Initialized
DEBUG - 2026-06-20 04:41:46 --> Cart MX_Controller Initialized
INFO - 2026-06-20 04:41:46 --> Model "Loginattempt_model" initialized
INFO - 2026-06-20 04:41:46 --> Model "Auth_model" initialized
INFO - 2026-06-20 04:41:46 --> Model "Cart_model" initialized
INFO - 2026-06-20 04:41:46 --> Model "Common_model" initialized
INFO - 2026-06-20 04:41:46 --> Model "Order_model" initialized
INFO - 2026-06-20 04:41:46 --> Model "Appsetting_model" initialized
INFO - 2026-06-20 04:41:46 --> Model "PaymentGateway_model" initialized
INFO - 2026-06-20 04:41:46 --> Model "Promocode_model" initialized
DEBUG - 2026-06-20 04:41:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-06-20 04:41:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-06-20 04:41:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-06-20 04:41:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-06-20 04:41:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-06-20 04:41:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/view_card.php
INFO - 2026-06-20 04:41:49 --> Final output sent to browser
DEBUG - 2026-06-20 04:41:49 --> Total execution time: 4.9936
INFO - 2026-06-20 04:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:49 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:49 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:49 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:49 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:49 --> Email Class Initialized
INFO - 2026-06-20 04:41:49 --> Controller Class Initialized
DEBUG - 2026-06-20 04:41:49 --> Cart MX_Controller Initialized
INFO - 2026-06-20 04:41:49 --> Model "Loginattempt_model" initialized
INFO - 2026-06-20 04:41:49 --> Model "Auth_model" initialized
INFO - 2026-06-20 04:41:49 --> Model "Cart_model" initialized
INFO - 2026-06-20 04:41:49 --> Model "Common_model" initialized
INFO - 2026-06-20 04:41:49 --> Model "Order_model" initialized
INFO - 2026-06-20 04:41:49 --> Model "Appsetting_model" initialized
INFO - 2026-06-20 04:41:49 --> Model "PaymentGateway_model" initialized
INFO - 2026-06-20 04:41:49 --> Model "Promocode_model" initialized
INFO - 2026-06-20 04:41:49 --> Final output sent to browser
DEBUG - 2026-06-20 04:41:49 --> Total execution time: 5.7457
INFO - 2026-06-20 04:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:49 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:49 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:49 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:49 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:49 --> Email Class Initialized
INFO - 2026-06-20 04:41:49 --> Controller Class Initialized
ERROR - 2026-06-20 04:41:49 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:41:49 --> Config Class Initialized
INFO - 2026-06-20 04:41:49 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:41:49 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:49 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:49 --> URI Class Initialized
INFO - 2026-06-20 04:41:49 --> Router Class Initialized
INFO - 2026-06-20 04:41:49 --> Output Class Initialized
INFO - 2026-06-20 04:41:49 --> Security Class Initialized
DEBUG - 2026-06-20 04:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:49 --> CSRF cookie sent
INFO - 2026-06-20 04:41:49 --> Input Class Initialized
INFO - 2026-06-20 04:41:49 --> Language Class Initialized
INFO - 2026-06-20 04:41:49 --> Language Class Initialized
INFO - 2026-06-20 04:41:49 --> Config Class Initialized
INFO - 2026-06-20 04:41:49 --> Loader Class Initialized
INFO - 2026-06-20 04:41:49 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:49 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:49 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:49 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:49 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:49 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:49 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:49 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:49 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:49 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:49 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:49 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:50 --> Config Class Initialized
INFO - 2026-06-20 04:41:50 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:41:50 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:50 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:50 --> URI Class Initialized
INFO - 2026-06-20 04:41:50 --> Router Class Initialized
INFO - 2026-06-20 04:41:50 --> Output Class Initialized
INFO - 2026-06-20 04:41:50 --> Security Class Initialized
DEBUG - 2026-06-20 04:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:50 --> CSRF cookie sent
INFO - 2026-06-20 04:41:50 --> Input Class Initialized
INFO - 2026-06-20 04:41:50 --> Language Class Initialized
INFO - 2026-06-20 04:41:50 --> Language Class Initialized
INFO - 2026-06-20 04:41:50 --> Config Class Initialized
INFO - 2026-06-20 04:41:50 --> Loader Class Initialized
INFO - 2026-06-20 04:41:50 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:50 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:50 --> Config Class Initialized
INFO - 2026-06-20 04:41:50 --> Hooks Class Initialized
INFO - 2026-06-20 04:41:50 --> Config Class Initialized
INFO - 2026-06-20 04:41:50 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:41:50 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:50 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:50 --> URI Class Initialized
DEBUG - 2026-06-20 04:41:50 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:50 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:50 --> URI Class Initialized
INFO - 2026-06-20 04:41:50 --> Config Class Initialized
INFO - 2026-06-20 04:41:50 --> Hooks Class Initialized
INFO - 2026-06-20 04:41:50 --> Router Class Initialized
INFO - 2026-06-20 04:41:50 --> Config Class Initialized
INFO - 2026-06-20 04:41:50 --> Hooks Class Initialized
INFO - 2026-06-20 04:41:50 --> Router Class Initialized
DEBUG - 2026-06-20 04:41:50 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:50 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:50 --> Output Class Initialized
INFO - 2026-06-20 04:41:50 --> URI Class Initialized
DEBUG - 2026-06-20 04:41:50 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:50 --> Output Class Initialized
INFO - 2026-06-20 04:41:50 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:50 --> Security Class Initialized
INFO - 2026-06-20 04:41:50 --> URI Class Initialized
INFO - 2026-06-20 04:41:50 --> Router Class Initialized
INFO - 2026-06-20 04:41:50 --> Security Class Initialized
DEBUG - 2026-06-20 04:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:50 --> CSRF cookie sent
INFO - 2026-06-20 04:41:50 --> Input Class Initialized
INFO - 2026-06-20 04:41:50 --> Language Class Initialized
DEBUG - 2026-06-20 04:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:50 --> CSRF cookie sent
INFO - 2026-06-20 04:41:50 --> Input Class Initialized
INFO - 2026-06-20 04:41:50 --> Output Class Initialized
INFO - 2026-06-20 04:41:50 --> Language Class Initialized
INFO - 2026-06-20 04:41:50 --> Router Class Initialized
INFO - 2026-06-20 04:41:50 --> Language Class Initialized
INFO - 2026-06-20 04:41:50 --> Language Class Initialized
INFO - 2026-06-20 04:41:50 --> Config Class Initialized
INFO - 2026-06-20 04:41:50 --> Config Class Initialized
INFO - 2026-06-20 04:41:50 --> Security Class Initialized
INFO - 2026-06-20 04:41:50 --> Output Class Initialized
DEBUG - 2026-06-20 04:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:50 --> CSRF cookie sent
INFO - 2026-06-20 04:41:50 --> Input Class Initialized
INFO - 2026-06-20 04:41:50 --> Language Class Initialized
INFO - 2026-06-20 04:41:50 --> Security Class Initialized
INFO - 2026-06-20 04:41:50 --> Language Class Initialized
INFO - 2026-06-20 04:41:50 --> Config Class Initialized
INFO - 2026-06-20 04:41:50 --> Loader Class Initialized
INFO - 2026-06-20 04:41:50 --> Loader Class Initialized
DEBUG - 2026-06-20 04:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:50 --> CSRF cookie sent
INFO - 2026-06-20 04:41:50 --> Input Class Initialized
INFO - 2026-06-20 04:41:50 --> Language Class Initialized
INFO - 2026-06-20 04:41:50 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:50 --> Language Class Initialized
INFO - 2026-06-20 04:41:50 --> Config Class Initialized
INFO - 2026-06-20 04:41:50 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:50 --> Loader Class Initialized
INFO - 2026-06-20 04:41:50 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:50 --> Loader Class Initialized
INFO - 2026-06-20 04:41:50 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:50 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:50 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:50 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:50 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:50 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:51 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:51 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:51 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:51 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:51 --> Email Class Initialized
INFO - 2026-06-20 04:41:51 --> Controller Class Initialized
ERROR - 2026-06-20 04:41:51 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:41:51 --> Config Class Initialized
INFO - 2026-06-20 04:41:51 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:41:51 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:51 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:51 --> URI Class Initialized
INFO - 2026-06-20 04:41:51 --> Router Class Initialized
INFO - 2026-06-20 04:41:51 --> Output Class Initialized
INFO - 2026-06-20 04:41:51 --> Security Class Initialized
DEBUG - 2026-06-20 04:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:51 --> CSRF cookie sent
INFO - 2026-06-20 04:41:51 --> Input Class Initialized
INFO - 2026-06-20 04:41:51 --> Language Class Initialized
INFO - 2026-06-20 04:41:51 --> Language Class Initialized
INFO - 2026-06-20 04:41:51 --> Config Class Initialized
INFO - 2026-06-20 04:41:51 --> Loader Class Initialized
INFO - 2026-06-20 04:41:51 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:51 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:51 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:51 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:51 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:51 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:41:51 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:51 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:51 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:41:51 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:51 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:51 --> Database Driver Class Initialized
INFO - 2026-06-20 04:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:52 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:52 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:52 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:52 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:52 --> Email Class Initialized
INFO - 2026-06-20 04:41:52 --> Controller Class Initialized
ERROR - 2026-06-20 04:41:52 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:52 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:52 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:52 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:52 --> Config Class Initialized
INFO - 2026-06-20 04:41:52 --> Hooks Class Initialized
INFO - 2026-06-20 04:41:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:52 --> Pagination Class Initialized
DEBUG - 2026-06-20 04:41:52 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:41:52 --> Utf8 Class Initialized
INFO - 2026-06-20 04:41:52 --> URI Class Initialized
INFO - 2026-06-20 04:41:52 --> Router Class Initialized
INFO - 2026-06-20 04:41:52 --> Email Class Initialized
INFO - 2026-06-20 04:41:52 --> Controller Class Initialized
INFO - 2026-06-20 04:41:52 --> Output Class Initialized
ERROR - 2026-06-20 04:41:52 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:52 --> Security Class Initialized
INFO - 2026-06-20 04:41:52 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:41:52 --> CSRF cookie sent
INFO - 2026-06-20 04:41:52 --> Input Class Initialized
INFO - 2026-06-20 04:41:52 --> Language Class Initialized
DEBUG - 2026-06-20 04:41:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:52 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:52 --> Language Class Initialized
INFO - 2026-06-20 04:41:52 --> Config Class Initialized
INFO - 2026-06-20 04:41:52 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:52 --> Loader Class Initialized
INFO - 2026-06-20 04:41:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:52 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:52 --> Helper loaded: url_helper
INFO - 2026-06-20 04:41:52 --> Helper loaded: form_helper
INFO - 2026-06-20 04:41:52 --> Helper loaded: html_helper
INFO - 2026-06-20 04:41:52 --> Helper loaded: file_helper
INFO - 2026-06-20 04:41:52 --> Helper loaded: email_helper
INFO - 2026-06-20 04:41:52 --> Email Class Initialized
INFO - 2026-06-20 04:41:52 --> Controller Class Initialized
INFO - 2026-06-20 04:41:52 --> Helper loaded: whmaz_helper
ERROR - 2026-06-20 04:41:52 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:41:52 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:52 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:41:52 --> Upload Class Initialized
INFO - 2026-06-20 04:41:52 --> Helper loaded: plesk_helper
DEBUG - 2026-06-20 04:41:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:52 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:52 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:41:52 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:52 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:52 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:41:52 --> Email Class Initialized
INFO - 2026-06-20 04:41:52 --> Controller Class Initialized
ERROR - 2026-06-20 04:41:52 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:52 --> Upload Class Initialized
INFO - 2026-06-20 04:41:52 --> Database Driver Class Initialized
DEBUG - 2026-06-20 04:41:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:52 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:52 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:52 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:52 --> Email Class Initialized
INFO - 2026-06-20 04:41:52 --> Controller Class Initialized
ERROR - 2026-06-20 04:41:52 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:53 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:53 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:53 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:53 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:53 --> Email Class Initialized
INFO - 2026-06-20 04:41:53 --> Controller Class Initialized
DEBUG - 2026-06-20 04:41:53 --> Cart MX_Controller Initialized
INFO - 2026-06-20 04:41:53 --> Model "Loginattempt_model" initialized
INFO - 2026-06-20 04:41:53 --> Model "Auth_model" initialized
INFO - 2026-06-20 04:41:53 --> Model "Cart_model" initialized
INFO - 2026-06-20 04:41:53 --> Model "Common_model" initialized
INFO - 2026-06-20 04:41:53 --> Model "Order_model" initialized
INFO - 2026-06-20 04:41:53 --> Model "Appsetting_model" initialized
INFO - 2026-06-20 04:41:53 --> Model "PaymentGateway_model" initialized
INFO - 2026-06-20 04:41:53 --> Model "Promocode_model" initialized
INFO - 2026-06-20 04:41:53 --> Final output sent to browser
DEBUG - 2026-06-20 04:41:53 --> Total execution time: 2.3308
INFO - 2026-06-20 04:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:41:53 --> Upload Class Initialized
DEBUG - 2026-06-20 04:41:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:41:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:41:53 --> Encryption Class Initialized
INFO - 2026-06-20 04:41:53 --> Form Validation Class Initialized
INFO - 2026-06-20 04:41:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:41:53 --> Pagination Class Initialized
INFO - 2026-06-20 04:41:53 --> Email Class Initialized
INFO - 2026-06-20 04:41:53 --> Controller Class Initialized
ERROR - 2026-06-20 04:41:53 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:47:24 --> Config Class Initialized
INFO - 2026-06-20 04:47:24 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:47:24 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:47:24 --> Utf8 Class Initialized
INFO - 2026-06-20 04:47:24 --> URI Class Initialized
INFO - 2026-06-20 04:47:24 --> Router Class Initialized
INFO - 2026-06-20 04:47:24 --> Output Class Initialized
INFO - 2026-06-20 04:47:24 --> Security Class Initialized
DEBUG - 2026-06-20 04:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:47:24 --> CSRF cookie sent
INFO - 2026-06-20 04:47:24 --> Input Class Initialized
INFO - 2026-06-20 04:47:24 --> Language Class Initialized
INFO - 2026-06-20 04:47:24 --> Language Class Initialized
INFO - 2026-06-20 04:47:24 --> Config Class Initialized
INFO - 2026-06-20 04:47:24 --> Loader Class Initialized
INFO - 2026-06-20 04:47:24 --> Helper loaded: url_helper
INFO - 2026-06-20 04:47:24 --> Helper loaded: form_helper
INFO - 2026-06-20 04:47:24 --> Helper loaded: html_helper
INFO - 2026-06-20 04:47:24 --> Helper loaded: file_helper
INFO - 2026-06-20 04:47:24 --> Helper loaded: email_helper
INFO - 2026-06-20 04:47:24 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:47:24 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:47:24 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:47:24 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:47:24 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:47:24 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:47:24 --> Database Driver Class Initialized
INFO - 2026-06-20 04:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:47:26 --> Upload Class Initialized
DEBUG - 2026-06-20 04:47:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:47:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:47:26 --> Encryption Class Initialized
INFO - 2026-06-20 04:47:26 --> Form Validation Class Initialized
INFO - 2026-06-20 04:47:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:47:26 --> Pagination Class Initialized
INFO - 2026-06-20 04:47:26 --> Email Class Initialized
INFO - 2026-06-20 04:47:26 --> Controller Class Initialized
DEBUG - 2026-06-20 04:47:26 --> Cart MX_Controller Initialized
INFO - 2026-06-20 04:47:26 --> Model "Loginattempt_model" initialized
INFO - 2026-06-20 04:47:26 --> Model "Auth_model" initialized
INFO - 2026-06-20 04:47:26 --> Model "Cart_model" initialized
INFO - 2026-06-20 04:47:26 --> Model "Common_model" initialized
INFO - 2026-06-20 04:47:26 --> Model "Order_model" initialized
INFO - 2026-06-20 04:47:26 --> Model "Appsetting_model" initialized
INFO - 2026-06-20 04:47:26 --> Model "PaymentGateway_model" initialized
INFO - 2026-06-20 04:47:26 --> Model "Promocode_model" initialized
DEBUG - 2026-06-20 04:47:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-06-20 04:47:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-06-20 04:47:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-06-20 04:47:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-06-20 04:47:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-06-20 04:47:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/view_card.php
INFO - 2026-06-20 04:47:29 --> Final output sent to browser
DEBUG - 2026-06-20 04:47:29 --> Total execution time: 5.0736
INFO - 2026-06-20 04:47:30 --> Config Class Initialized
INFO - 2026-06-20 04:47:30 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:47:30 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:47:30 --> Utf8 Class Initialized
INFO - 2026-06-20 04:47:30 --> URI Class Initialized
INFO - 2026-06-20 04:47:30 --> Router Class Initialized
INFO - 2026-06-20 04:47:30 --> Output Class Initialized
INFO - 2026-06-20 04:47:30 --> Security Class Initialized
DEBUG - 2026-06-20 04:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:47:30 --> CSRF cookie sent
INFO - 2026-06-20 04:47:30 --> Input Class Initialized
INFO - 2026-06-20 04:47:30 --> Language Class Initialized
INFO - 2026-06-20 04:47:30 --> Language Class Initialized
INFO - 2026-06-20 04:47:30 --> Config Class Initialized
INFO - 2026-06-20 04:47:30 --> Loader Class Initialized
INFO - 2026-06-20 04:47:30 --> Helper loaded: url_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: form_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: html_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: file_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: email_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:47:30 --> Database Driver Class Initialized
INFO - 2026-06-20 04:47:30 --> Config Class Initialized
INFO - 2026-06-20 04:47:30 --> Hooks Class Initialized
INFO - 2026-06-20 04:47:30 --> Config Class Initialized
INFO - 2026-06-20 04:47:30 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:47:30 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:47:30 --> Utf8 Class Initialized
DEBUG - 2026-06-20 04:47:30 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:47:30 --> Utf8 Class Initialized
INFO - 2026-06-20 04:47:30 --> URI Class Initialized
INFO - 2026-06-20 04:47:30 --> URI Class Initialized
INFO - 2026-06-20 04:47:30 --> Config Class Initialized
INFO - 2026-06-20 04:47:30 --> Hooks Class Initialized
INFO - 2026-06-20 04:47:30 --> Router Class Initialized
INFO - 2026-06-20 04:47:30 --> Config Class Initialized
INFO - 2026-06-20 04:47:30 --> Hooks Class Initialized
INFO - 2026-06-20 04:47:30 --> Router Class Initialized
DEBUG - 2026-06-20 04:47:30 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:47:30 --> Utf8 Class Initialized
INFO - 2026-06-20 04:47:30 --> Output Class Initialized
INFO - 2026-06-20 04:47:30 --> URI Class Initialized
INFO - 2026-06-20 04:47:30 --> Security Class Initialized
INFO - 2026-06-20 04:47:30 --> Output Class Initialized
DEBUG - 2026-06-20 04:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:47:30 --> CSRF cookie sent
INFO - 2026-06-20 04:47:30 --> Input Class Initialized
INFO - 2026-06-20 04:47:30 --> Language Class Initialized
DEBUG - 2026-06-20 04:47:30 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:47:30 --> Utf8 Class Initialized
INFO - 2026-06-20 04:47:30 --> Config Class Initialized
INFO - 2026-06-20 04:47:30 --> Hooks Class Initialized
INFO - 2026-06-20 04:47:30 --> Security Class Initialized
INFO - 2026-06-20 04:47:30 --> Router Class Initialized
INFO - 2026-06-20 04:47:30 --> URI Class Initialized
INFO - 2026-06-20 04:47:30 --> Language Class Initialized
INFO - 2026-06-20 04:47:30 --> Config Class Initialized
DEBUG - 2026-06-20 04:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:47:30 --> CSRF cookie sent
INFO - 2026-06-20 04:47:30 --> Input Class Initialized
DEBUG - 2026-06-20 04:47:30 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:47:30 --> Utf8 Class Initialized
INFO - 2026-06-20 04:47:30 --> Language Class Initialized
INFO - 2026-06-20 04:47:30 --> Output Class Initialized
INFO - 2026-06-20 04:47:30 --> Router Class Initialized
INFO - 2026-06-20 04:47:30 --> URI Class Initialized
INFO - 2026-06-20 04:47:30 --> Language Class Initialized
INFO - 2026-06-20 04:47:30 --> Config Class Initialized
INFO - 2026-06-20 04:47:30 --> Output Class Initialized
INFO - 2026-06-20 04:47:30 --> Security Class Initialized
INFO - 2026-06-20 04:47:30 --> Loader Class Initialized
INFO - 2026-06-20 04:47:30 --> Security Class Initialized
DEBUG - 2026-06-20 04:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:47:30 --> Helper loaded: url_helper
INFO - 2026-06-20 04:47:30 --> CSRF cookie sent
INFO - 2026-06-20 04:47:30 --> Input Class Initialized
INFO - 2026-06-20 04:47:30 --> Language Class Initialized
DEBUG - 2026-06-20 04:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:47:30 --> CSRF cookie sent
INFO - 2026-06-20 04:47:30 --> Input Class Initialized
INFO - 2026-06-20 04:47:30 --> Loader Class Initialized
INFO - 2026-06-20 04:47:30 --> Helper loaded: form_helper
INFO - 2026-06-20 04:47:30 --> Language Class Initialized
INFO - 2026-06-20 04:47:30 --> Config Class Initialized
INFO - 2026-06-20 04:47:30 --> Helper loaded: html_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: url_helper
INFO - 2026-06-20 04:47:30 --> Language Class Initialized
INFO - 2026-06-20 04:47:30 --> Helper loaded: file_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: email_helper
INFO - 2026-06-20 04:47:30 --> Router Class Initialized
INFO - 2026-06-20 04:47:30 --> Language Class Initialized
INFO - 2026-06-20 04:47:30 --> Config Class Initialized
INFO - 2026-06-20 04:47:30 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: form_helper
INFO - 2026-06-20 04:47:30 --> Loader Class Initialized
INFO - 2026-06-20 04:47:30 --> Helper loaded: html_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: file_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: email_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: url_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: form_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:47:30 --> Output Class Initialized
INFO - 2026-06-20 04:47:30 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: html_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: file_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: email_helper
INFO - 2026-06-20 04:47:30 --> Security Class Initialized
INFO - 2026-06-20 04:47:30 --> Loader Class Initialized
INFO - 2026-06-20 04:47:30 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: url_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: form_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: html_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: file_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: email_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: cpanel_helper
DEBUG - 2026-06-20 04:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:47:30 --> CSRF cookie sent
INFO - 2026-06-20 04:47:30 --> Input Class Initialized
INFO - 2026-06-20 04:47:30 --> Language Class Initialized
INFO - 2026-06-20 04:47:30 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:47:30 --> Language Class Initialized
INFO - 2026-06-20 04:47:30 --> Config Class Initialized
INFO - 2026-06-20 04:47:30 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:47:30 --> Database Driver Class Initialized
INFO - 2026-06-20 04:47:30 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:47:30 --> Database Driver Class Initialized
INFO - 2026-06-20 04:47:30 --> Loader Class Initialized
INFO - 2026-06-20 04:47:30 --> Helper loaded: url_helper
INFO - 2026-06-20 04:47:30 --> Database Driver Class Initialized
INFO - 2026-06-20 04:47:30 --> Database Driver Class Initialized
INFO - 2026-06-20 04:47:30 --> Helper loaded: form_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: html_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: file_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: email_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:47:30 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:47:30 --> Database Driver Class Initialized
INFO - 2026-06-20 04:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:47:31 --> Upload Class Initialized
DEBUG - 2026-06-20 04:47:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:47:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:47:31 --> Encryption Class Initialized
INFO - 2026-06-20 04:47:31 --> Form Validation Class Initialized
INFO - 2026-06-20 04:47:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:47:31 --> Pagination Class Initialized
INFO - 2026-06-20 04:47:31 --> Email Class Initialized
INFO - 2026-06-20 04:47:31 --> Controller Class Initialized
ERROR - 2026-06-20 04:47:31 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:47:31 --> Config Class Initialized
INFO - 2026-06-20 04:47:31 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:47:31 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:47:31 --> Utf8 Class Initialized
INFO - 2026-06-20 04:47:31 --> URI Class Initialized
INFO - 2026-06-20 04:47:31 --> Router Class Initialized
INFO - 2026-06-20 04:47:31 --> Output Class Initialized
INFO - 2026-06-20 04:47:31 --> Security Class Initialized
DEBUG - 2026-06-20 04:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:47:31 --> CSRF cookie sent
INFO - 2026-06-20 04:47:31 --> Input Class Initialized
INFO - 2026-06-20 04:47:31 --> Language Class Initialized
INFO - 2026-06-20 04:47:31 --> Language Class Initialized
INFO - 2026-06-20 04:47:31 --> Config Class Initialized
INFO - 2026-06-20 04:47:31 --> Loader Class Initialized
INFO - 2026-06-20 04:47:31 --> Helper loaded: url_helper
INFO - 2026-06-20 04:47:31 --> Helper loaded: form_helper
INFO - 2026-06-20 04:47:31 --> Helper loaded: html_helper
INFO - 2026-06-20 04:47:31 --> Helper loaded: file_helper
INFO - 2026-06-20 04:47:31 --> Helper loaded: email_helper
INFO - 2026-06-20 04:47:31 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:47:31 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:47:31 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:47:31 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:47:31 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:47:31 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:47:31 --> Database Driver Class Initialized
INFO - 2026-06-20 04:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:47:32 --> Upload Class Initialized
DEBUG - 2026-06-20 04:47:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:47:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:47:32 --> Encryption Class Initialized
INFO - 2026-06-20 04:47:32 --> Form Validation Class Initialized
INFO - 2026-06-20 04:47:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:47:32 --> Pagination Class Initialized
INFO - 2026-06-20 04:47:32 --> Email Class Initialized
INFO - 2026-06-20 04:47:32 --> Controller Class Initialized
ERROR - 2026-06-20 04:47:32 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:47:32 --> Upload Class Initialized
DEBUG - 2026-06-20 04:47:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:47:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:47:32 --> Encryption Class Initialized
INFO - 2026-06-20 04:47:32 --> Form Validation Class Initialized
INFO - 2026-06-20 04:47:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:47:32 --> Pagination Class Initialized
INFO - 2026-06-20 04:47:32 --> Email Class Initialized
INFO - 2026-06-20 04:47:32 --> Controller Class Initialized
ERROR - 2026-06-20 04:47:32 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:47:32 --> Upload Class Initialized
DEBUG - 2026-06-20 04:47:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:47:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:47:32 --> Encryption Class Initialized
INFO - 2026-06-20 04:47:32 --> Form Validation Class Initialized
INFO - 2026-06-20 04:47:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:47:32 --> Pagination Class Initialized
INFO - 2026-06-20 04:47:32 --> Email Class Initialized
INFO - 2026-06-20 04:47:32 --> Controller Class Initialized
ERROR - 2026-06-20 04:47:32 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:47:32 --> Upload Class Initialized
INFO - 2026-06-20 04:47:32 --> Config Class Initialized
INFO - 2026-06-20 04:47:32 --> Hooks Class Initialized
DEBUG - 2026-06-20 04:47:32 --> UTF-8 Support Enabled
INFO - 2026-06-20 04:47:32 --> Utf8 Class Initialized
INFO - 2026-06-20 04:47:32 --> URI Class Initialized
DEBUG - 2026-06-20 04:47:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:47:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:47:32 --> Encryption Class Initialized
INFO - 2026-06-20 04:47:32 --> Router Class Initialized
INFO - 2026-06-20 04:47:32 --> Output Class Initialized
INFO - 2026-06-20 04:47:32 --> Form Validation Class Initialized
INFO - 2026-06-20 04:47:32 --> Security Class Initialized
INFO - 2026-06-20 04:47:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:47:32 --> Pagination Class Initialized
DEBUG - 2026-06-20 04:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-20 04:47:32 --> CSRF cookie sent
INFO - 2026-06-20 04:47:32 --> Input Class Initialized
INFO - 2026-06-20 04:47:32 --> Language Class Initialized
INFO - 2026-06-20 04:47:32 --> Language Class Initialized
INFO - 2026-06-20 04:47:32 --> Config Class Initialized
INFO - 2026-06-20 04:47:32 --> Email Class Initialized
INFO - 2026-06-20 04:47:32 --> Controller Class Initialized
ERROR - 2026-06-20 04:47:32 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:47:32 --> Loader Class Initialized
INFO - 2026-06-20 04:47:32 --> Helper loaded: url_helper
INFO - 2026-06-20 04:47:32 --> Helper loaded: form_helper
INFO - 2026-06-20 04:47:32 --> Helper loaded: html_helper
INFO - 2026-06-20 04:47:32 --> Helper loaded: file_helper
INFO - 2026-06-20 04:47:32 --> Helper loaded: email_helper
INFO - 2026-06-20 04:47:32 --> Helper loaded: whmaz_helper
INFO - 2026-06-20 04:47:32 --> Helper loaded: ssp_helper
INFO - 2026-06-20 04:47:32 --> Helper loaded: cpanel_helper
INFO - 2026-06-20 04:47:32 --> Helper loaded: plesk_helper
INFO - 2026-06-20 04:47:32 --> Helper loaded: directadmin_helper
INFO - 2026-06-20 04:47:32 --> Helper loaded: domain_helper
INFO - 2026-06-20 04:47:32 --> Database Driver Class Initialized
INFO - 2026-06-20 04:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:47:33 --> Upload Class Initialized
DEBUG - 2026-06-20 04:47:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:47:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:47:33 --> Encryption Class Initialized
INFO - 2026-06-20 04:47:33 --> Form Validation Class Initialized
INFO - 2026-06-20 04:47:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:47:33 --> Pagination Class Initialized
INFO - 2026-06-20 04:47:33 --> Email Class Initialized
INFO - 2026-06-20 04:47:33 --> Controller Class Initialized
ERROR - 2026-06-20 04:47:33 --> 404 Page Not Found: /index
INFO - 2026-06-20 04:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:47:33 --> Upload Class Initialized
DEBUG - 2026-06-20 04:47:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:47:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:47:33 --> Encryption Class Initialized
INFO - 2026-06-20 04:47:33 --> Form Validation Class Initialized
INFO - 2026-06-20 04:47:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:47:33 --> Pagination Class Initialized
INFO - 2026-06-20 04:47:33 --> Email Class Initialized
INFO - 2026-06-20 04:47:33 --> Controller Class Initialized
DEBUG - 2026-06-20 04:47:33 --> Cart MX_Controller Initialized
INFO - 2026-06-20 04:47:33 --> Model "Loginattempt_model" initialized
INFO - 2026-06-20 04:47:33 --> Model "Auth_model" initialized
INFO - 2026-06-20 04:47:33 --> Model "Cart_model" initialized
INFO - 2026-06-20 04:47:33 --> Model "Common_model" initialized
INFO - 2026-06-20 04:47:33 --> Model "Order_model" initialized
INFO - 2026-06-20 04:47:33 --> Model "Appsetting_model" initialized
INFO - 2026-06-20 04:47:33 --> Model "PaymentGateway_model" initialized
INFO - 2026-06-20 04:47:33 --> Model "Promocode_model" initialized
INFO - 2026-06-20 04:47:34 --> Final output sent to browser
DEBUG - 2026-06-20 04:47:34 --> Total execution time: 2.3376
INFO - 2026-06-20 04:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-20 04:47:34 --> Upload Class Initialized
DEBUG - 2026-06-20 04:47:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-20 04:47:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-20 04:47:34 --> Encryption Class Initialized
INFO - 2026-06-20 04:47:34 --> Form Validation Class Initialized
INFO - 2026-06-20 04:47:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-20 04:47:34 --> Pagination Class Initialized
INFO - 2026-06-20 04:47:34 --> Email Class Initialized
INFO - 2026-06-20 04:47:34 --> Controller Class Initialized
ERROR - 2026-06-20 04:47:34 --> 404 Page Not Found: /index

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-02-21 06:18:48 --> Config Class Initialized
INFO - 2026-02-21 06:18:48 --> Hooks Class Initialized
DEBUG - 2026-02-21 06:18:48 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:18:48 --> Utf8 Class Initialized
INFO - 2026-02-21 06:18:48 --> URI Class Initialized
INFO - 2026-02-21 06:18:48 --> Router Class Initialized
INFO - 2026-02-21 06:18:48 --> Output Class Initialized
INFO - 2026-02-21 06:18:48 --> Security Class Initialized
DEBUG - 2026-02-21 06:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:18:48 --> CSRF cookie sent
INFO - 2026-02-21 06:18:48 --> Input Class Initialized
INFO - 2026-02-21 06:18:48 --> Language Class Initialized
INFO - 2026-02-21 06:18:48 --> Language Class Initialized
INFO - 2026-02-21 06:18:48 --> Config Class Initialized
INFO - 2026-02-21 06:18:48 --> Loader Class Initialized
INFO - 2026-02-21 06:18:48 --> Helper loaded: url_helper
INFO - 2026-02-21 06:18:48 --> Helper loaded: form_helper
INFO - 2026-02-21 06:18:48 --> Helper loaded: html_helper
INFO - 2026-02-21 06:18:48 --> Helper loaded: file_helper
INFO - 2026-02-21 06:18:48 --> Helper loaded: email_helper
INFO - 2026-02-21 06:18:48 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:18:48 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:18:48 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:18:48 --> Database Driver Class Initialized
INFO - 2026-02-21 06:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:18:50 --> Upload Class Initialized
DEBUG - 2026-02-21 06:18:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:18:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:18:50 --> Encryption Class Initialized
INFO - 2026-02-21 06:18:50 --> Form Validation Class Initialized
INFO - 2026-02-21 06:18:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:18:50 --> Pagination Class Initialized
INFO - 2026-02-21 06:18:50 --> Email Class Initialized
INFO - 2026-02-21 06:18:50 --> Controller Class Initialized
DEBUG - 2026-02-21 06:18:50 --> Dashboard MX_Controller Initialized
INFO - 2026-02-21 06:18:50 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:18:50 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:18:50 --> Config Class Initialized
INFO - 2026-02-21 06:18:50 --> Hooks Class Initialized
DEBUG - 2026-02-21 06:18:50 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:18:50 --> Utf8 Class Initialized
INFO - 2026-02-21 06:18:50 --> URI Class Initialized
INFO - 2026-02-21 06:18:50 --> Router Class Initialized
INFO - 2026-02-21 06:18:50 --> Output Class Initialized
INFO - 2026-02-21 06:18:50 --> Security Class Initialized
DEBUG - 2026-02-21 06:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:18:50 --> CSRF cookie sent
INFO - 2026-02-21 06:18:50 --> Input Class Initialized
INFO - 2026-02-21 06:18:50 --> Language Class Initialized
INFO - 2026-02-21 06:18:50 --> Language Class Initialized
INFO - 2026-02-21 06:18:50 --> Config Class Initialized
INFO - 2026-02-21 06:18:50 --> Loader Class Initialized
INFO - 2026-02-21 06:18:50 --> Helper loaded: url_helper
INFO - 2026-02-21 06:18:50 --> Helper loaded: form_helper
INFO - 2026-02-21 06:18:50 --> Helper loaded: html_helper
INFO - 2026-02-21 06:18:50 --> Helper loaded: file_helper
INFO - 2026-02-21 06:18:50 --> Helper loaded: email_helper
INFO - 2026-02-21 06:18:50 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:18:50 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:18:50 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:18:50 --> Database Driver Class Initialized
INFO - 2026-02-21 06:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:18:52 --> Upload Class Initialized
DEBUG - 2026-02-21 06:18:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:18:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:18:52 --> Encryption Class Initialized
INFO - 2026-02-21 06:18:52 --> Form Validation Class Initialized
INFO - 2026-02-21 06:18:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:18:52 --> Pagination Class Initialized
INFO - 2026-02-21 06:18:52 --> Email Class Initialized
INFO - 2026-02-21 06:18:52 --> Controller Class Initialized
DEBUG - 2026-02-21 06:18:52 --> Authenticate MX_Controller Initialized
INFO - 2026-02-21 06:18:52 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:18:52 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:18:52 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-21 06:18:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
INFO - 2026-02-21 06:18:52 --> Model "Cart_model" initialized
DEBUG - 2026-02-21 06:18:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-21 06:18:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-02-21 06:18:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-21 06:18:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-21 06:18:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-02-21 06:18:53 --> Final output sent to browser
DEBUG - 2026-02-21 06:18:53 --> Total execution time: 2.8242
INFO - 2026-02-21 06:19:05 --> Config Class Initialized
INFO - 2026-02-21 06:19:05 --> Hooks Class Initialized
DEBUG - 2026-02-21 06:19:05 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:19:05 --> Utf8 Class Initialized
INFO - 2026-02-21 06:19:05 --> URI Class Initialized
INFO - 2026-02-21 06:19:05 --> Router Class Initialized
INFO - 2026-02-21 06:19:05 --> Output Class Initialized
INFO - 2026-02-21 06:19:05 --> Security Class Initialized
DEBUG - 2026-02-21 06:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:19:05 --> CSRF cookie sent
INFO - 2026-02-21 06:19:05 --> CSRF token verified
INFO - 2026-02-21 06:19:05 --> Input Class Initialized
INFO - 2026-02-21 06:19:05 --> Language Class Initialized
INFO - 2026-02-21 06:19:05 --> Language Class Initialized
INFO - 2026-02-21 06:19:05 --> Config Class Initialized
INFO - 2026-02-21 06:19:05 --> Loader Class Initialized
INFO - 2026-02-21 06:19:05 --> Helper loaded: url_helper
INFO - 2026-02-21 06:19:05 --> Helper loaded: form_helper
INFO - 2026-02-21 06:19:05 --> Helper loaded: html_helper
INFO - 2026-02-21 06:19:05 --> Helper loaded: file_helper
INFO - 2026-02-21 06:19:05 --> Helper loaded: email_helper
INFO - 2026-02-21 06:19:05 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:19:05 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:19:05 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:19:05 --> Database Driver Class Initialized
INFO - 2026-02-21 06:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:19:07 --> Upload Class Initialized
DEBUG - 2026-02-21 06:19:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:19:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:19:07 --> Encryption Class Initialized
INFO - 2026-02-21 06:19:07 --> Form Validation Class Initialized
INFO - 2026-02-21 06:19:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:19:07 --> Pagination Class Initialized
INFO - 2026-02-21 06:19:07 --> Email Class Initialized
INFO - 2026-02-21 06:19:07 --> Controller Class Initialized
DEBUG - 2026-02-21 06:19:07 --> Authenticate MX_Controller Initialized
INFO - 2026-02-21 06:19:07 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:19:07 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:19:07 --> Model "Appsetting_model" initialized
INFO - 2026-02-21 06:19:10 --> Config Class Initialized
INFO - 2026-02-21 06:19:10 --> Hooks Class Initialized
DEBUG - 2026-02-21 06:19:10 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:19:10 --> Utf8 Class Initialized
INFO - 2026-02-21 06:19:10 --> URI Class Initialized
INFO - 2026-02-21 06:19:10 --> Router Class Initialized
INFO - 2026-02-21 06:19:10 --> Output Class Initialized
INFO - 2026-02-21 06:19:10 --> Security Class Initialized
DEBUG - 2026-02-21 06:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:19:10 --> CSRF cookie sent
INFO - 2026-02-21 06:19:10 --> Input Class Initialized
INFO - 2026-02-21 06:19:10 --> Language Class Initialized
INFO - 2026-02-21 06:19:10 --> Language Class Initialized
INFO - 2026-02-21 06:19:10 --> Config Class Initialized
INFO - 2026-02-21 06:19:10 --> Loader Class Initialized
INFO - 2026-02-21 06:19:10 --> Helper loaded: url_helper
INFO - 2026-02-21 06:19:10 --> Helper loaded: form_helper
INFO - 2026-02-21 06:19:10 --> Helper loaded: html_helper
INFO - 2026-02-21 06:19:10 --> Helper loaded: file_helper
INFO - 2026-02-21 06:19:10 --> Helper loaded: email_helper
INFO - 2026-02-21 06:19:10 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:19:10 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:19:10 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:19:10 --> Database Driver Class Initialized
INFO - 2026-02-21 06:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:19:12 --> Upload Class Initialized
DEBUG - 2026-02-21 06:19:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:19:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:19:12 --> Encryption Class Initialized
INFO - 2026-02-21 06:19:12 --> Form Validation Class Initialized
INFO - 2026-02-21 06:19:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:19:12 --> Pagination Class Initialized
INFO - 2026-02-21 06:19:12 --> Email Class Initialized
INFO - 2026-02-21 06:19:12 --> Controller Class Initialized
DEBUG - 2026-02-21 06:19:12 --> Dashboard MX_Controller Initialized
INFO - 2026-02-21 06:19:12 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:19:12 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:19:12 --> Model "Dashboard_model" initialized
DEBUG - 2026-02-21 06:19:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-21 06:19:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-21 06:19:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-21 06:19:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-21 06:19:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-21 06:19:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/dashboard_index.php
INFO - 2026-02-21 06:19:12 --> Final output sent to browser
DEBUG - 2026-02-21 06:19:12 --> Total execution time: 2.4095
INFO - 2026-02-21 06:19:12 --> Config Class Initialized
INFO - 2026-02-21 06:19:12 --> Hooks Class Initialized
INFO - 2026-02-21 06:19:12 --> Config Class Initialized
INFO - 2026-02-21 06:19:12 --> Hooks Class Initialized
INFO - 2026-02-21 06:19:12 --> Config Class Initialized
INFO - 2026-02-21 06:19:12 --> Hooks Class Initialized
DEBUG - 2026-02-21 06:19:12 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:19:12 --> Utf8 Class Initialized
INFO - 2026-02-21 06:19:12 --> Config Class Initialized
INFO - 2026-02-21 06:19:12 --> Hooks Class Initialized
INFO - 2026-02-21 06:19:12 --> URI Class Initialized
INFO - 2026-02-21 06:19:12 --> Config Class Initialized
INFO - 2026-02-21 06:19:12 --> Hooks Class Initialized
DEBUG - 2026-02-21 06:19:12 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:19:12 --> Utf8 Class Initialized
DEBUG - 2026-02-21 06:19:12 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:19:12 --> Utf8 Class Initialized
INFO - 2026-02-21 06:19:12 --> URI Class Initialized
INFO - 2026-02-21 06:19:12 --> Router Class Initialized
INFO - 2026-02-21 06:19:12 --> URI Class Initialized
DEBUG - 2026-02-21 06:19:12 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:19:12 --> Utf8 Class Initialized
INFO - 2026-02-21 06:19:12 --> Output Class Initialized
DEBUG - 2026-02-21 06:19:12 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:19:12 --> URI Class Initialized
INFO - 2026-02-21 06:19:12 --> Utf8 Class Initialized
INFO - 2026-02-21 06:19:12 --> Router Class Initialized
INFO - 2026-02-21 06:19:12 --> URI Class Initialized
INFO - 2026-02-21 06:19:12 --> Config Class Initialized
INFO - 2026-02-21 06:19:12 --> Hooks Class Initialized
INFO - 2026-02-21 06:19:12 --> Router Class Initialized
INFO - 2026-02-21 06:19:12 --> Output Class Initialized
DEBUG - 2026-02-21 06:19:12 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:19:12 --> Utf8 Class Initialized
INFO - 2026-02-21 06:19:12 --> Router Class Initialized
INFO - 2026-02-21 06:19:12 --> Output Class Initialized
INFO - 2026-02-21 06:19:12 --> Security Class Initialized
INFO - 2026-02-21 06:19:12 --> URI Class Initialized
INFO - 2026-02-21 06:19:12 --> Security Class Initialized
INFO - 2026-02-21 06:19:12 --> Output Class Initialized
INFO - 2026-02-21 06:19:12 --> Security Class Initialized
DEBUG - 2026-02-21 06:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:19:12 --> Input Class Initialized
DEBUG - 2026-02-21 06:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:19:12 --> Language Class Initialized
INFO - 2026-02-21 06:19:12 --> Router Class Initialized
INFO - 2026-02-21 06:19:12 --> Input Class Initialized
INFO - 2026-02-21 06:19:12 --> Language Class Initialized
INFO - 2026-02-21 06:19:12 --> Language Class Initialized
INFO - 2026-02-21 06:19:12 --> Config Class Initialized
INFO - 2026-02-21 06:19:12 --> Output Class Initialized
INFO - 2026-02-21 06:19:12 --> Language Class Initialized
INFO - 2026-02-21 06:19:12 --> Config Class Initialized
DEBUG - 2026-02-21 06:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:19:12 --> Input Class Initialized
INFO - 2026-02-21 06:19:12 --> Security Class Initialized
INFO - 2026-02-21 06:19:12 --> Language Class Initialized
INFO - 2026-02-21 06:19:12 --> Loader Class Initialized
INFO - 2026-02-21 06:19:12 --> Router Class Initialized
INFO - 2026-02-21 06:19:12 --> Loader Class Initialized
INFO - 2026-02-21 06:19:12 --> Language Class Initialized
INFO - 2026-02-21 06:19:12 --> Config Class Initialized
DEBUG - 2026-02-21 06:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:19:12 --> Helper loaded: url_helper
INFO - 2026-02-21 06:19:12 --> Output Class Initialized
INFO - 2026-02-21 06:19:12 --> Helper loaded: url_helper
INFO - 2026-02-21 06:19:12 --> Input Class Initialized
INFO - 2026-02-21 06:19:12 --> Helper loaded: form_helper
INFO - 2026-02-21 06:19:12 --> Language Class Initialized
INFO - 2026-02-21 06:19:12 --> Helper loaded: form_helper
INFO - 2026-02-21 06:19:12 --> Security Class Initialized
INFO - 2026-02-21 06:19:12 --> Helper loaded: html_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: html_helper
INFO - 2026-02-21 06:19:12 --> Loader Class Initialized
INFO - 2026-02-21 06:19:12 --> Language Class Initialized
INFO - 2026-02-21 06:19:12 --> Helper loaded: file_helper
INFO - 2026-02-21 06:19:12 --> Config Class Initialized
INFO - 2026-02-21 06:19:12 --> Helper loaded: email_helper
DEBUG - 2026-02-21 06:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:19:12 --> Input Class Initialized
INFO - 2026-02-21 06:19:12 --> Helper loaded: file_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: email_helper
INFO - 2026-02-21 06:19:12 --> Language Class Initialized
INFO - 2026-02-21 06:19:12 --> Helper loaded: url_helper
INFO - 2026-02-21 06:19:12 --> Language Class Initialized
INFO - 2026-02-21 06:19:12 --> Config Class Initialized
INFO - 2026-02-21 06:19:12 --> Helper loaded: form_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: html_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: file_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: email_helper
INFO - 2026-02-21 06:19:12 --> Loader Class Initialized
INFO - 2026-02-21 06:19:12 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: url_helper
INFO - 2026-02-21 06:19:12 --> Loader Class Initialized
INFO - 2026-02-21 06:19:12 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: url_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: form_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: html_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: form_helper
INFO - 2026-02-21 06:19:12 --> Security Class Initialized
INFO - 2026-02-21 06:19:12 --> Helper loaded: file_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: email_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: html_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: file_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: email_helper
DEBUG - 2026-02-21 06:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:19:12 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:19:12 --> Input Class Initialized
INFO - 2026-02-21 06:19:12 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:19:12 --> Language Class Initialized
INFO - 2026-02-21 06:19:12 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:19:12 --> Language Class Initialized
INFO - 2026-02-21 06:19:12 --> Config Class Initialized
INFO - 2026-02-21 06:19:12 --> Database Driver Class Initialized
INFO - 2026-02-21 06:19:12 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:19:12 --> Database Driver Class Initialized
INFO - 2026-02-21 06:19:12 --> Database Driver Class Initialized
INFO - 2026-02-21 06:19:12 --> Loader Class Initialized
INFO - 2026-02-21 06:19:12 --> Helper loaded: url_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: form_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: html_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: file_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: email_helper
INFO - 2026-02-21 06:19:12 --> Database Driver Class Initialized
INFO - 2026-02-21 06:19:12 --> Database Driver Class Initialized
INFO - 2026-02-21 06:19:12 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:19:12 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:19:12 --> Database Driver Class Initialized
INFO - 2026-02-21 06:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:19:15 --> Upload Class Initialized
DEBUG - 2026-02-21 06:19:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:19:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:19:15 --> Encryption Class Initialized
INFO - 2026-02-21 06:19:15 --> Form Validation Class Initialized
INFO - 2026-02-21 06:19:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:19:15 --> Pagination Class Initialized
INFO - 2026-02-21 06:19:15 --> Email Class Initialized
INFO - 2026-02-21 06:19:15 --> Controller Class Initialized
DEBUG - 2026-02-21 06:19:15 --> Invoice MX_Controller Initialized
INFO - 2026-02-21 06:19:15 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:19:15 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:19:15 --> Model "Billing_model" initialized
INFO - 2026-02-21 06:19:15 --> Model "Common_model" initialized
INFO - 2026-02-21 06:19:15 --> Model "Invoice_model" initialized
INFO - 2026-02-21 06:19:15 --> Model "Appsetting_model" initialized
INFO - 2026-02-21 06:19:16 --> Final output sent to browser
DEBUG - 2026-02-21 06:19:16 --> Total execution time: 3.2406
INFO - 2026-02-21 06:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:19:16 --> Upload Class Initialized
DEBUG - 2026-02-21 06:19:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:19:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:19:16 --> Encryption Class Initialized
INFO - 2026-02-21 06:19:16 --> Form Validation Class Initialized
INFO - 2026-02-21 06:19:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:19:16 --> Pagination Class Initialized
INFO - 2026-02-21 06:19:16 --> Email Class Initialized
INFO - 2026-02-21 06:19:16 --> Controller Class Initialized
DEBUG - 2026-02-21 06:19:16 --> Dashboard MX_Controller Initialized
INFO - 2026-02-21 06:19:16 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:19:16 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:19:16 --> Model "Dashboard_model" initialized
INFO - 2026-02-21 06:19:16 --> Final output sent to browser
DEBUG - 2026-02-21 06:19:16 --> Total execution time: 4.0564
INFO - 2026-02-21 06:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:19:16 --> Upload Class Initialized
DEBUG - 2026-02-21 06:19:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:19:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:19:16 --> Encryption Class Initialized
INFO - 2026-02-21 06:19:16 --> Form Validation Class Initialized
INFO - 2026-02-21 06:19:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:19:16 --> Pagination Class Initialized
INFO - 2026-02-21 06:19:16 --> Email Class Initialized
INFO - 2026-02-21 06:19:16 --> Controller Class Initialized
DEBUG - 2026-02-21 06:19:16 --> Dashboard MX_Controller Initialized
INFO - 2026-02-21 06:19:16 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:19:16 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:19:17 --> Model "Dashboard_model" initialized
INFO - 2026-02-21 06:19:17 --> Final output sent to browser
DEBUG - 2026-02-21 06:19:17 --> Total execution time: 4.8772
INFO - 2026-02-21 06:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:19:17 --> Upload Class Initialized
DEBUG - 2026-02-21 06:19:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:19:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:19:17 --> Encryption Class Initialized
INFO - 2026-02-21 06:19:17 --> Form Validation Class Initialized
INFO - 2026-02-21 06:19:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:19:17 --> Pagination Class Initialized
INFO - 2026-02-21 06:19:17 --> Email Class Initialized
INFO - 2026-02-21 06:19:17 --> Controller Class Initialized
DEBUG - 2026-02-21 06:19:17 --> Order MX_Controller Initialized
INFO - 2026-02-21 06:19:17 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:19:17 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:19:18 --> Model "Order_model" initialized
INFO - 2026-02-21 06:19:18 --> Model "Common_model" initialized
INFO - 2026-02-21 06:19:18 --> Model "Currency_model" initialized
INFO - 2026-02-21 06:19:18 --> Final output sent to browser
DEBUG - 2026-02-21 06:19:18 --> Total execution time: 5.6043
INFO - 2026-02-21 06:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:19:18 --> Upload Class Initialized
DEBUG - 2026-02-21 06:19:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:19:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:19:18 --> Encryption Class Initialized
INFO - 2026-02-21 06:19:18 --> Form Validation Class Initialized
INFO - 2026-02-21 06:19:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:19:18 --> Pagination Class Initialized
INFO - 2026-02-21 06:19:18 --> Email Class Initialized
INFO - 2026-02-21 06:19:18 --> Controller Class Initialized
DEBUG - 2026-02-21 06:19:18 --> Dashboard MX_Controller Initialized
INFO - 2026-02-21 06:19:18 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:19:18 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:19:18 --> Model "Dashboard_model" initialized
INFO - 2026-02-21 06:19:19 --> Final output sent to browser
DEBUG - 2026-02-21 06:19:19 --> Total execution time: 6.3234
INFO - 2026-02-21 06:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:19:19 --> Upload Class Initialized
DEBUG - 2026-02-21 06:19:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:19:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:19:19 --> Encryption Class Initialized
INFO - 2026-02-21 06:19:19 --> Form Validation Class Initialized
INFO - 2026-02-21 06:19:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:19:19 --> Pagination Class Initialized
INFO - 2026-02-21 06:19:19 --> Email Class Initialized
INFO - 2026-02-21 06:19:19 --> Controller Class Initialized
DEBUG - 2026-02-21 06:19:19 --> Ticket MX_Controller Initialized
INFO - 2026-02-21 06:19:19 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:19:19 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:19:19 --> Model "Support_model" initialized
INFO - 2026-02-21 06:19:19 --> Model "Common_model" initialized
INFO - 2026-02-21 06:19:19 --> Final output sent to browser
DEBUG - 2026-02-21 06:19:19 --> Total execution time: 7.1322
INFO - 2026-02-21 06:19:41 --> Config Class Initialized
INFO - 2026-02-21 06:19:41 --> Hooks Class Initialized
DEBUG - 2026-02-21 06:19:41 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:19:41 --> Utf8 Class Initialized
INFO - 2026-02-21 06:19:41 --> URI Class Initialized
INFO - 2026-02-21 06:19:41 --> Router Class Initialized
INFO - 2026-02-21 06:19:41 --> Output Class Initialized
INFO - 2026-02-21 06:19:41 --> Security Class Initialized
DEBUG - 2026-02-21 06:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:19:41 --> CSRF cookie sent
INFO - 2026-02-21 06:19:41 --> Input Class Initialized
INFO - 2026-02-21 06:19:41 --> Language Class Initialized
INFO - 2026-02-21 06:19:41 --> Language Class Initialized
INFO - 2026-02-21 06:19:41 --> Config Class Initialized
INFO - 2026-02-21 06:19:41 --> Loader Class Initialized
INFO - 2026-02-21 06:19:41 --> Helper loaded: url_helper
INFO - 2026-02-21 06:19:41 --> Helper loaded: form_helper
INFO - 2026-02-21 06:19:41 --> Helper loaded: html_helper
INFO - 2026-02-21 06:19:41 --> Helper loaded: file_helper
INFO - 2026-02-21 06:19:41 --> Helper loaded: email_helper
INFO - 2026-02-21 06:19:41 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:19:41 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:19:41 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:19:41 --> Database Driver Class Initialized
INFO - 2026-02-21 06:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:19:43 --> Upload Class Initialized
DEBUG - 2026-02-21 06:19:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:19:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:19:43 --> Encryption Class Initialized
INFO - 2026-02-21 06:19:43 --> Form Validation Class Initialized
INFO - 2026-02-21 06:19:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:19:43 --> Pagination Class Initialized
INFO - 2026-02-21 06:19:43 --> Email Class Initialized
INFO - 2026-02-21 06:19:43 --> Controller Class Initialized
DEBUG - 2026-02-21 06:19:43 --> Paymentgateway MX_Controller Initialized
INFO - 2026-02-21 06:19:43 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:19:43 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:19:43 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-21 06:19:43 --> Model "Payment_model" initialized
DEBUG - 2026-02-21 06:19:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-21 06:19:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-21 06:19:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-21 06:19:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-21 06:19:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-21 06:19:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/paymentgateway_list.php
INFO - 2026-02-21 06:19:44 --> Final output sent to browser
DEBUG - 2026-02-21 06:19:44 --> Total execution time: 2.7589
INFO - 2026-02-21 06:19:49 --> Config Class Initialized
INFO - 2026-02-21 06:19:49 --> Hooks Class Initialized
DEBUG - 2026-02-21 06:19:49 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:19:49 --> Utf8 Class Initialized
INFO - 2026-02-21 06:19:49 --> URI Class Initialized
INFO - 2026-02-21 06:19:49 --> Router Class Initialized
INFO - 2026-02-21 06:19:49 --> Output Class Initialized
INFO - 2026-02-21 06:19:49 --> Security Class Initialized
DEBUG - 2026-02-21 06:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:19:49 --> CSRF cookie sent
INFO - 2026-02-21 06:19:49 --> CSRF token verified
INFO - 2026-02-21 06:19:49 --> Input Class Initialized
INFO - 2026-02-21 06:19:49 --> Language Class Initialized
INFO - 2026-02-21 06:19:49 --> Language Class Initialized
INFO - 2026-02-21 06:19:49 --> Config Class Initialized
INFO - 2026-02-21 06:19:49 --> Loader Class Initialized
INFO - 2026-02-21 06:19:49 --> Helper loaded: url_helper
INFO - 2026-02-21 06:19:49 --> Helper loaded: form_helper
INFO - 2026-02-21 06:19:49 --> Helper loaded: html_helper
INFO - 2026-02-21 06:19:49 --> Helper loaded: file_helper
INFO - 2026-02-21 06:19:49 --> Helper loaded: email_helper
INFO - 2026-02-21 06:19:49 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:19:49 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:19:49 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:19:49 --> Database Driver Class Initialized
INFO - 2026-02-21 06:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:19:51 --> Upload Class Initialized
DEBUG - 2026-02-21 06:19:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:19:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:19:51 --> Encryption Class Initialized
INFO - 2026-02-21 06:19:51 --> Form Validation Class Initialized
INFO - 2026-02-21 06:19:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:19:51 --> Pagination Class Initialized
INFO - 2026-02-21 06:19:51 --> Email Class Initialized
INFO - 2026-02-21 06:19:51 --> Controller Class Initialized
DEBUG - 2026-02-21 06:19:51 --> Paymentgateway MX_Controller Initialized
INFO - 2026-02-21 06:19:51 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:19:51 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:19:51 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-21 06:19:51 --> Model "Payment_model" initialized
INFO - 2026-02-21 06:19:52 --> Final output sent to browser
DEBUG - 2026-02-21 06:19:52 --> Total execution time: 3.5168
INFO - 2026-02-21 06:19:53 --> Config Class Initialized
INFO - 2026-02-21 06:19:53 --> Hooks Class Initialized
DEBUG - 2026-02-21 06:19:53 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:19:53 --> Utf8 Class Initialized
INFO - 2026-02-21 06:19:53 --> URI Class Initialized
INFO - 2026-02-21 06:19:53 --> Router Class Initialized
INFO - 2026-02-21 06:19:53 --> Output Class Initialized
INFO - 2026-02-21 06:19:53 --> Security Class Initialized
DEBUG - 2026-02-21 06:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:19:53 --> CSRF cookie sent
INFO - 2026-02-21 06:19:53 --> Input Class Initialized
INFO - 2026-02-21 06:19:53 --> Language Class Initialized
INFO - 2026-02-21 06:19:53 --> Language Class Initialized
INFO - 2026-02-21 06:19:53 --> Config Class Initialized
INFO - 2026-02-21 06:19:53 --> Loader Class Initialized
INFO - 2026-02-21 06:19:53 --> Helper loaded: url_helper
INFO - 2026-02-21 06:19:53 --> Helper loaded: form_helper
INFO - 2026-02-21 06:19:53 --> Helper loaded: html_helper
INFO - 2026-02-21 06:19:53 --> Helper loaded: file_helper
INFO - 2026-02-21 06:19:53 --> Helper loaded: email_helper
INFO - 2026-02-21 06:19:53 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:19:53 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:19:53 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:19:53 --> Database Driver Class Initialized
INFO - 2026-02-21 06:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:19:55 --> Upload Class Initialized
DEBUG - 2026-02-21 06:19:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:19:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:19:55 --> Encryption Class Initialized
INFO - 2026-02-21 06:19:55 --> Form Validation Class Initialized
INFO - 2026-02-21 06:19:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:19:55 --> Pagination Class Initialized
INFO - 2026-02-21 06:19:55 --> Email Class Initialized
INFO - 2026-02-21 06:19:55 --> Controller Class Initialized
DEBUG - 2026-02-21 06:19:55 --> Paymentgateway MX_Controller Initialized
INFO - 2026-02-21 06:19:55 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:19:55 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:19:55 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-21 06:19:55 --> Model "Payment_model" initialized
DEBUG - 2026-02-21 06:19:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-21 06:19:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-21 06:19:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-21 06:19:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-21 06:19:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-21 06:19:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/paymentgateway_list.php
INFO - 2026-02-21 06:19:56 --> Final output sent to browser
DEBUG - 2026-02-21 06:19:56 --> Total execution time: 2.9066
INFO - 2026-02-21 06:21:27 --> Config Class Initialized
INFO - 2026-02-21 06:21:27 --> Hooks Class Initialized
DEBUG - 2026-02-21 06:21:27 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:21:27 --> Utf8 Class Initialized
INFO - 2026-02-21 06:21:27 --> URI Class Initialized
INFO - 2026-02-21 06:21:27 --> Router Class Initialized
INFO - 2026-02-21 06:21:27 --> Output Class Initialized
INFO - 2026-02-21 06:21:27 --> Security Class Initialized
DEBUG - 2026-02-21 06:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:21:27 --> CSRF cookie sent
INFO - 2026-02-21 06:21:27 --> Input Class Initialized
INFO - 2026-02-21 06:21:27 --> Language Class Initialized
INFO - 2026-02-21 06:21:27 --> Language Class Initialized
INFO - 2026-02-21 06:21:27 --> Config Class Initialized
INFO - 2026-02-21 06:21:27 --> Loader Class Initialized
INFO - 2026-02-21 06:21:27 --> Helper loaded: url_helper
INFO - 2026-02-21 06:21:27 --> Helper loaded: form_helper
INFO - 2026-02-21 06:21:27 --> Helper loaded: html_helper
INFO - 2026-02-21 06:21:27 --> Helper loaded: file_helper
INFO - 2026-02-21 06:21:27 --> Helper loaded: email_helper
INFO - 2026-02-21 06:21:27 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:21:27 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:21:27 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:21:27 --> Database Driver Class Initialized
INFO - 2026-02-21 06:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:21:29 --> Upload Class Initialized
DEBUG - 2026-02-21 06:21:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:21:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:21:29 --> Encryption Class Initialized
INFO - 2026-02-21 06:21:29 --> Form Validation Class Initialized
INFO - 2026-02-21 06:21:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:21:29 --> Pagination Class Initialized
INFO - 2026-02-21 06:21:29 --> Email Class Initialized
INFO - 2026-02-21 06:21:29 --> Controller Class Initialized
DEBUG - 2026-02-21 06:21:29 --> Paymentgateway MX_Controller Initialized
INFO - 2026-02-21 06:21:29 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:21:29 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:21:29 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-21 06:21:29 --> Model "Payment_model" initialized
DEBUG - 2026-02-21 06:21:30 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-21 06:21:30 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-21 06:21:30 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-21 06:21:30 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-21 06:21:30 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-21 06:21:30 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/paymentgateway_transactions.php
INFO - 2026-02-21 06:21:30 --> Final output sent to browser
DEBUG - 2026-02-21 06:21:30 --> Total execution time: 2.7664
INFO - 2026-02-21 06:21:30 --> Config Class Initialized
INFO - 2026-02-21 06:21:30 --> Hooks Class Initialized
DEBUG - 2026-02-21 06:21:30 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:21:30 --> Utf8 Class Initialized
INFO - 2026-02-21 06:21:30 --> URI Class Initialized
INFO - 2026-02-21 06:21:30 --> Router Class Initialized
INFO - 2026-02-21 06:21:30 --> Output Class Initialized
INFO - 2026-02-21 06:21:30 --> Security Class Initialized
DEBUG - 2026-02-21 06:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:21:30 --> CSRF cookie sent
INFO - 2026-02-21 06:21:30 --> Input Class Initialized
INFO - 2026-02-21 06:21:30 --> Language Class Initialized
INFO - 2026-02-21 06:21:30 --> Language Class Initialized
INFO - 2026-02-21 06:21:30 --> Config Class Initialized
INFO - 2026-02-21 06:21:30 --> Loader Class Initialized
INFO - 2026-02-21 06:21:30 --> Helper loaded: url_helper
INFO - 2026-02-21 06:21:30 --> Helper loaded: form_helper
INFO - 2026-02-21 06:21:30 --> Helper loaded: html_helper
INFO - 2026-02-21 06:21:30 --> Helper loaded: file_helper
INFO - 2026-02-21 06:21:30 --> Helper loaded: email_helper
INFO - 2026-02-21 06:21:30 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:21:30 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:21:30 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:21:30 --> Database Driver Class Initialized
INFO - 2026-02-21 06:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:21:31 --> Upload Class Initialized
DEBUG - 2026-02-21 06:21:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:21:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:21:31 --> Encryption Class Initialized
INFO - 2026-02-21 06:21:31 --> Form Validation Class Initialized
INFO - 2026-02-21 06:21:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:21:31 --> Pagination Class Initialized
INFO - 2026-02-21 06:21:31 --> Email Class Initialized
INFO - 2026-02-21 06:21:31 --> Controller Class Initialized
DEBUG - 2026-02-21 06:21:31 --> Paymentgateway MX_Controller Initialized
INFO - 2026-02-21 06:21:31 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:21:31 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:21:31 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-21 06:21:31 --> Model "Payment_model" initialized
INFO - 2026-02-21 06:21:33 --> Final output sent to browser
DEBUG - 2026-02-21 06:21:33 --> Total execution time: 2.8190
INFO - 2026-02-21 06:21:37 --> Config Class Initialized
INFO - 2026-02-21 06:21:37 --> Hooks Class Initialized
DEBUG - 2026-02-21 06:21:37 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:21:37 --> Utf8 Class Initialized
INFO - 2026-02-21 06:21:37 --> URI Class Initialized
INFO - 2026-02-21 06:21:37 --> Router Class Initialized
INFO - 2026-02-21 06:21:37 --> Output Class Initialized
INFO - 2026-02-21 06:21:37 --> Security Class Initialized
DEBUG - 2026-02-21 06:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:21:37 --> CSRF cookie sent
INFO - 2026-02-21 06:21:37 --> Input Class Initialized
INFO - 2026-02-21 06:21:37 --> Language Class Initialized
INFO - 2026-02-21 06:21:37 --> Language Class Initialized
INFO - 2026-02-21 06:21:37 --> Config Class Initialized
INFO - 2026-02-21 06:21:37 --> Loader Class Initialized
INFO - 2026-02-21 06:21:37 --> Helper loaded: url_helper
INFO - 2026-02-21 06:21:37 --> Helper loaded: form_helper
INFO - 2026-02-21 06:21:37 --> Helper loaded: html_helper
INFO - 2026-02-21 06:21:37 --> Helper loaded: file_helper
INFO - 2026-02-21 06:21:37 --> Helper loaded: email_helper
INFO - 2026-02-21 06:21:37 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:21:37 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:21:37 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:21:37 --> Database Driver Class Initialized
INFO - 2026-02-21 06:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:21:38 --> Upload Class Initialized
DEBUG - 2026-02-21 06:21:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:21:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:21:38 --> Encryption Class Initialized
INFO - 2026-02-21 06:21:38 --> Form Validation Class Initialized
INFO - 2026-02-21 06:21:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:21:38 --> Pagination Class Initialized
INFO - 2026-02-21 06:21:38 --> Email Class Initialized
INFO - 2026-02-21 06:21:38 --> Controller Class Initialized
DEBUG - 2026-02-21 06:21:38 --> Paymentgateway MX_Controller Initialized
INFO - 2026-02-21 06:21:38 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:21:38 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:21:38 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-21 06:21:38 --> Model "Payment_model" initialized
INFO - 2026-02-21 06:21:39 --> Final output sent to browser
DEBUG - 2026-02-21 06:21:39 --> Total execution time: 2.5415
INFO - 2026-02-21 06:22:17 --> Config Class Initialized
INFO - 2026-02-21 06:22:17 --> Hooks Class Initialized
DEBUG - 2026-02-21 06:22:17 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:22:17 --> Utf8 Class Initialized
INFO - 2026-02-21 06:22:17 --> URI Class Initialized
INFO - 2026-02-21 06:22:17 --> Router Class Initialized
INFO - 2026-02-21 06:22:17 --> Output Class Initialized
INFO - 2026-02-21 06:22:17 --> Security Class Initialized
DEBUG - 2026-02-21 06:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:22:17 --> CSRF cookie sent
INFO - 2026-02-21 06:22:17 --> Input Class Initialized
INFO - 2026-02-21 06:22:17 --> Language Class Initialized
INFO - 2026-02-21 06:22:17 --> Language Class Initialized
INFO - 2026-02-21 06:22:17 --> Config Class Initialized
INFO - 2026-02-21 06:22:17 --> Loader Class Initialized
INFO - 2026-02-21 06:22:17 --> Helper loaded: url_helper
INFO - 2026-02-21 06:22:17 --> Helper loaded: form_helper
INFO - 2026-02-21 06:22:17 --> Helper loaded: html_helper
INFO - 2026-02-21 06:22:17 --> Helper loaded: file_helper
INFO - 2026-02-21 06:22:17 --> Helper loaded: email_helper
INFO - 2026-02-21 06:22:17 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:22:17 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:22:17 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:22:17 --> Database Driver Class Initialized
INFO - 2026-02-21 06:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:22:19 --> Upload Class Initialized
DEBUG - 2026-02-21 06:22:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:22:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:22:19 --> Encryption Class Initialized
INFO - 2026-02-21 06:22:19 --> Form Validation Class Initialized
INFO - 2026-02-21 06:22:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:22:19 --> Pagination Class Initialized
INFO - 2026-02-21 06:22:19 --> Email Class Initialized
INFO - 2026-02-21 06:22:19 --> Controller Class Initialized
DEBUG - 2026-02-21 06:22:19 --> Paymentgateway MX_Controller Initialized
INFO - 2026-02-21 06:22:19 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:22:19 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:22:19 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-21 06:22:19 --> Model "Payment_model" initialized
DEBUG - 2026-02-21 06:22:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-21 06:22:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-21 06:22:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-21 06:22:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-21 06:22:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-21 06:22:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/paymentgateway_list.php
INFO - 2026-02-21 06:22:20 --> Final output sent to browser
DEBUG - 2026-02-21 06:22:20 --> Total execution time: 2.9508
INFO - 2026-02-21 06:22:31 --> Config Class Initialized
INFO - 2026-02-21 06:22:31 --> Hooks Class Initialized
DEBUG - 2026-02-21 06:22:31 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:22:31 --> Utf8 Class Initialized
INFO - 2026-02-21 06:22:31 --> URI Class Initialized
INFO - 2026-02-21 06:22:31 --> Router Class Initialized
INFO - 2026-02-21 06:22:31 --> Output Class Initialized
INFO - 2026-02-21 06:22:31 --> Security Class Initialized
DEBUG - 2026-02-21 06:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:22:31 --> CSRF cookie sent
INFO - 2026-02-21 06:22:31 --> CSRF token verified
INFO - 2026-02-21 06:22:31 --> Input Class Initialized
INFO - 2026-02-21 06:22:31 --> Language Class Initialized
INFO - 2026-02-21 06:22:31 --> Language Class Initialized
INFO - 2026-02-21 06:22:31 --> Config Class Initialized
INFO - 2026-02-21 06:22:31 --> Loader Class Initialized
INFO - 2026-02-21 06:22:31 --> Helper loaded: url_helper
INFO - 2026-02-21 06:22:31 --> Helper loaded: form_helper
INFO - 2026-02-21 06:22:31 --> Helper loaded: html_helper
INFO - 2026-02-21 06:22:31 --> Helper loaded: file_helper
INFO - 2026-02-21 06:22:31 --> Helper loaded: email_helper
INFO - 2026-02-21 06:22:31 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:22:31 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:22:31 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:22:31 --> Database Driver Class Initialized
INFO - 2026-02-21 06:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:22:33 --> Upload Class Initialized
DEBUG - 2026-02-21 06:22:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:22:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:22:33 --> Encryption Class Initialized
INFO - 2026-02-21 06:22:33 --> Form Validation Class Initialized
INFO - 2026-02-21 06:22:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:22:33 --> Pagination Class Initialized
INFO - 2026-02-21 06:22:33 --> Email Class Initialized
INFO - 2026-02-21 06:22:33 --> Controller Class Initialized
DEBUG - 2026-02-21 06:22:33 --> Paymentgateway MX_Controller Initialized
INFO - 2026-02-21 06:22:33 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:22:33 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:22:33 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-21 06:22:33 --> Model "Payment_model" initialized
INFO - 2026-02-21 06:22:34 --> Final output sent to browser
DEBUG - 2026-02-21 06:22:34 --> Total execution time: 2.8587
INFO - 2026-02-21 06:22:36 --> Config Class Initialized
INFO - 2026-02-21 06:22:36 --> Hooks Class Initialized
DEBUG - 2026-02-21 06:22:36 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:22:36 --> Utf8 Class Initialized
INFO - 2026-02-21 06:22:36 --> URI Class Initialized
INFO - 2026-02-21 06:22:36 --> Router Class Initialized
INFO - 2026-02-21 06:22:36 --> Output Class Initialized
INFO - 2026-02-21 06:22:36 --> Security Class Initialized
DEBUG - 2026-02-21 06:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:22:36 --> CSRF cookie sent
INFO - 2026-02-21 06:22:36 --> Input Class Initialized
INFO - 2026-02-21 06:22:36 --> Language Class Initialized
INFO - 2026-02-21 06:22:36 --> Language Class Initialized
INFO - 2026-02-21 06:22:36 --> Config Class Initialized
INFO - 2026-02-21 06:22:36 --> Loader Class Initialized
INFO - 2026-02-21 06:22:36 --> Helper loaded: url_helper
INFO - 2026-02-21 06:22:36 --> Helper loaded: form_helper
INFO - 2026-02-21 06:22:36 --> Helper loaded: html_helper
INFO - 2026-02-21 06:22:36 --> Helper loaded: file_helper
INFO - 2026-02-21 06:22:36 --> Helper loaded: email_helper
INFO - 2026-02-21 06:22:36 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:22:36 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:22:36 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:22:36 --> Database Driver Class Initialized
INFO - 2026-02-21 06:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:22:38 --> Upload Class Initialized
DEBUG - 2026-02-21 06:22:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:22:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:22:38 --> Encryption Class Initialized
INFO - 2026-02-21 06:22:38 --> Form Validation Class Initialized
INFO - 2026-02-21 06:22:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:22:38 --> Pagination Class Initialized
INFO - 2026-02-21 06:22:38 --> Email Class Initialized
INFO - 2026-02-21 06:22:38 --> Controller Class Initialized
DEBUG - 2026-02-21 06:22:38 --> Paymentgateway MX_Controller Initialized
INFO - 2026-02-21 06:22:38 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:22:38 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:22:38 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-21 06:22:38 --> Model "Payment_model" initialized
DEBUG - 2026-02-21 06:22:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-21 06:22:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-21 06:22:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-21 06:22:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-21 06:22:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-21 06:22:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/paymentgateway_list.php
INFO - 2026-02-21 06:22:39 --> Final output sent to browser
DEBUG - 2026-02-21 06:22:39 --> Total execution time: 2.7768
INFO - 2026-02-21 06:22:51 --> Config Class Initialized
INFO - 2026-02-21 06:22:51 --> Hooks Class Initialized
DEBUG - 2026-02-21 06:22:51 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:22:51 --> Utf8 Class Initialized
INFO - 2026-02-21 06:22:51 --> URI Class Initialized
INFO - 2026-02-21 06:22:51 --> Router Class Initialized
INFO - 2026-02-21 06:22:51 --> Output Class Initialized
INFO - 2026-02-21 06:22:51 --> Security Class Initialized
DEBUG - 2026-02-21 06:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:22:51 --> CSRF cookie sent
INFO - 2026-02-21 06:22:51 --> CSRF token verified
INFO - 2026-02-21 06:22:51 --> Input Class Initialized
INFO - 2026-02-21 06:22:51 --> Language Class Initialized
INFO - 2026-02-21 06:22:51 --> Language Class Initialized
INFO - 2026-02-21 06:22:51 --> Config Class Initialized
INFO - 2026-02-21 06:22:51 --> Loader Class Initialized
INFO - 2026-02-21 06:22:51 --> Helper loaded: url_helper
INFO - 2026-02-21 06:22:51 --> Helper loaded: form_helper
INFO - 2026-02-21 06:22:51 --> Helper loaded: html_helper
INFO - 2026-02-21 06:22:51 --> Helper loaded: file_helper
INFO - 2026-02-21 06:22:51 --> Helper loaded: email_helper
INFO - 2026-02-21 06:22:51 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:22:51 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:22:51 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:22:51 --> Database Driver Class Initialized
INFO - 2026-02-21 06:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:22:53 --> Upload Class Initialized
DEBUG - 2026-02-21 06:22:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:22:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:22:53 --> Encryption Class Initialized
INFO - 2026-02-21 06:22:53 --> Form Validation Class Initialized
INFO - 2026-02-21 06:22:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:22:53 --> Pagination Class Initialized
INFO - 2026-02-21 06:22:53 --> Email Class Initialized
INFO - 2026-02-21 06:22:53 --> Controller Class Initialized
DEBUG - 2026-02-21 06:22:53 --> Paymentgateway MX_Controller Initialized
INFO - 2026-02-21 06:22:53 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:22:53 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:22:53 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-21 06:22:53 --> Model "Payment_model" initialized
INFO - 2026-02-21 06:22:54 --> Final output sent to browser
DEBUG - 2026-02-21 06:22:54 --> Total execution time: 3.0500
INFO - 2026-02-21 06:51:24 --> Config Class Initialized
INFO - 2026-02-21 06:51:24 --> Hooks Class Initialized
DEBUG - 2026-02-21 06:51:24 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:51:24 --> Utf8 Class Initialized
INFO - 2026-02-21 06:51:24 --> URI Class Initialized
INFO - 2026-02-21 06:51:24 --> Router Class Initialized
INFO - 2026-02-21 06:51:24 --> Output Class Initialized
INFO - 2026-02-21 06:51:24 --> Security Class Initialized
DEBUG - 2026-02-21 06:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:51:24 --> CSRF cookie sent
INFO - 2026-02-21 06:51:24 --> Input Class Initialized
INFO - 2026-02-21 06:51:24 --> Language Class Initialized
INFO - 2026-02-21 06:51:24 --> Language Class Initialized
INFO - 2026-02-21 06:51:24 --> Config Class Initialized
INFO - 2026-02-21 06:51:24 --> Loader Class Initialized
INFO - 2026-02-21 06:51:24 --> Helper loaded: url_helper
INFO - 2026-02-21 06:51:24 --> Helper loaded: form_helper
INFO - 2026-02-21 06:51:24 --> Helper loaded: html_helper
INFO - 2026-02-21 06:51:24 --> Helper loaded: file_helper
INFO - 2026-02-21 06:51:24 --> Helper loaded: email_helper
INFO - 2026-02-21 06:51:24 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:51:24 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:51:24 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:51:24 --> Database Driver Class Initialized
INFO - 2026-02-21 06:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:51:26 --> Upload Class Initialized
DEBUG - 2026-02-21 06:51:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:51:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:51:26 --> Encryption Class Initialized
INFO - 2026-02-21 06:51:26 --> Form Validation Class Initialized
INFO - 2026-02-21 06:51:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:51:26 --> Pagination Class Initialized
INFO - 2026-02-21 06:51:26 --> Email Class Initialized
INFO - 2026-02-21 06:51:26 --> Controller Class Initialized
DEBUG - 2026-02-21 06:51:26 --> Paymentgateway MX_Controller Initialized
INFO - 2026-02-21 06:51:26 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:51:26 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:51:26 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-21 06:51:26 --> Model "Payment_model" initialized
DEBUG - 2026-02-21 06:51:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-21 06:51:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-21 06:51:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-21 06:51:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-21 06:51:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-21 06:51:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/paymentgateway_list.php
INFO - 2026-02-21 06:51:27 --> Final output sent to browser
DEBUG - 2026-02-21 06:51:27 --> Total execution time: 2.6504
INFO - 2026-02-21 06:51:49 --> Config Class Initialized
INFO - 2026-02-21 06:51:49 --> Hooks Class Initialized
DEBUG - 2026-02-21 06:51:49 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:51:49 --> Utf8 Class Initialized
INFO - 2026-02-21 06:51:49 --> URI Class Initialized
INFO - 2026-02-21 06:51:49 --> Router Class Initialized
INFO - 2026-02-21 06:51:49 --> Output Class Initialized
INFO - 2026-02-21 06:51:49 --> Security Class Initialized
DEBUG - 2026-02-21 06:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:51:49 --> CSRF cookie sent
INFO - 2026-02-21 06:51:49 --> Input Class Initialized
INFO - 2026-02-21 06:51:49 --> Language Class Initialized
INFO - 2026-02-21 06:51:49 --> Language Class Initialized
INFO - 2026-02-21 06:51:49 --> Config Class Initialized
INFO - 2026-02-21 06:51:49 --> Loader Class Initialized
INFO - 2026-02-21 06:51:49 --> Helper loaded: url_helper
INFO - 2026-02-21 06:51:49 --> Helper loaded: form_helper
INFO - 2026-02-21 06:51:49 --> Helper loaded: html_helper
INFO - 2026-02-21 06:51:49 --> Helper loaded: file_helper
INFO - 2026-02-21 06:51:49 --> Helper loaded: email_helper
INFO - 2026-02-21 06:51:49 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:51:49 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:51:49 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:51:49 --> Database Driver Class Initialized
INFO - 2026-02-21 06:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:51:51 --> Upload Class Initialized
DEBUG - 2026-02-21 06:51:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:51:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:51:51 --> Encryption Class Initialized
INFO - 2026-02-21 06:51:51 --> Form Validation Class Initialized
INFO - 2026-02-21 06:51:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:51:51 --> Pagination Class Initialized
INFO - 2026-02-21 06:51:51 --> Email Class Initialized
INFO - 2026-02-21 06:51:51 --> Controller Class Initialized
DEBUG - 2026-02-21 06:51:51 --> Paymentgateway MX_Controller Initialized
INFO - 2026-02-21 06:51:51 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:51:51 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:51:51 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-21 06:51:51 --> Model "Payment_model" initialized
DEBUG - 2026-02-21 06:51:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-21 06:51:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-21 06:51:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-21 06:51:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-21 06:51:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-21 06:51:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/paymentgateway_webhooks.php
INFO - 2026-02-21 06:51:52 --> Final output sent to browser
DEBUG - 2026-02-21 06:51:52 --> Total execution time: 2.2723
INFO - 2026-02-21 06:51:52 --> Config Class Initialized
INFO - 2026-02-21 06:51:52 --> Hooks Class Initialized
DEBUG - 2026-02-21 06:51:52 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:51:52 --> Utf8 Class Initialized
INFO - 2026-02-21 06:51:52 --> URI Class Initialized
INFO - 2026-02-21 06:51:52 --> Router Class Initialized
INFO - 2026-02-21 06:51:52 --> Output Class Initialized
INFO - 2026-02-21 06:51:52 --> Security Class Initialized
DEBUG - 2026-02-21 06:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:51:52 --> CSRF cookie sent
INFO - 2026-02-21 06:51:52 --> Input Class Initialized
INFO - 2026-02-21 06:51:52 --> Language Class Initialized
INFO - 2026-02-21 06:51:52 --> Language Class Initialized
INFO - 2026-02-21 06:51:52 --> Config Class Initialized
INFO - 2026-02-21 06:51:52 --> Loader Class Initialized
INFO - 2026-02-21 06:51:52 --> Helper loaded: url_helper
INFO - 2026-02-21 06:51:52 --> Helper loaded: form_helper
INFO - 2026-02-21 06:51:52 --> Helper loaded: html_helper
INFO - 2026-02-21 06:51:52 --> Helper loaded: file_helper
INFO - 2026-02-21 06:51:52 --> Helper loaded: email_helper
INFO - 2026-02-21 06:51:52 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:51:52 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:51:52 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:51:52 --> Database Driver Class Initialized
INFO - 2026-02-21 06:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:51:54 --> Upload Class Initialized
DEBUG - 2026-02-21 06:51:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:51:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:51:54 --> Encryption Class Initialized
INFO - 2026-02-21 06:51:54 --> Form Validation Class Initialized
INFO - 2026-02-21 06:51:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:51:54 --> Pagination Class Initialized
INFO - 2026-02-21 06:51:54 --> Email Class Initialized
INFO - 2026-02-21 06:51:54 --> Controller Class Initialized
DEBUG - 2026-02-21 06:51:54 --> Paymentgateway MX_Controller Initialized
INFO - 2026-02-21 06:51:54 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:51:54 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:51:54 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-21 06:51:54 --> Model "Payment_model" initialized
INFO - 2026-02-21 06:51:55 --> Final output sent to browser
DEBUG - 2026-02-21 06:51:55 --> Total execution time: 3.2668
INFO - 2026-02-21 06:51:57 --> Config Class Initialized
INFO - 2026-02-21 06:51:57 --> Hooks Class Initialized
DEBUG - 2026-02-21 06:51:57 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:51:57 --> Utf8 Class Initialized
INFO - 2026-02-21 06:51:57 --> URI Class Initialized
INFO - 2026-02-21 06:51:57 --> Router Class Initialized
INFO - 2026-02-21 06:51:57 --> Output Class Initialized
INFO - 2026-02-21 06:51:57 --> Security Class Initialized
DEBUG - 2026-02-21 06:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:51:57 --> CSRF cookie sent
INFO - 2026-02-21 06:51:57 --> Input Class Initialized
INFO - 2026-02-21 06:51:57 --> Language Class Initialized
INFO - 2026-02-21 06:51:57 --> Language Class Initialized
INFO - 2026-02-21 06:51:57 --> Config Class Initialized
INFO - 2026-02-21 06:51:57 --> Loader Class Initialized
INFO - 2026-02-21 06:51:57 --> Helper loaded: url_helper
INFO - 2026-02-21 06:51:57 --> Helper loaded: form_helper
INFO - 2026-02-21 06:51:57 --> Helper loaded: html_helper
INFO - 2026-02-21 06:51:57 --> Helper loaded: file_helper
INFO - 2026-02-21 06:51:57 --> Helper loaded: email_helper
INFO - 2026-02-21 06:51:57 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:51:57 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:51:57 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:51:57 --> Database Driver Class Initialized
INFO - 2026-02-21 06:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:51:59 --> Upload Class Initialized
DEBUG - 2026-02-21 06:51:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:51:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:51:59 --> Encryption Class Initialized
INFO - 2026-02-21 06:51:59 --> Form Validation Class Initialized
INFO - 2026-02-21 06:51:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:51:59 --> Pagination Class Initialized
INFO - 2026-02-21 06:51:59 --> Email Class Initialized
INFO - 2026-02-21 06:51:59 --> Controller Class Initialized
DEBUG - 2026-02-21 06:51:59 --> Paymentgateway MX_Controller Initialized
INFO - 2026-02-21 06:51:59 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:51:59 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:51:59 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-21 06:51:59 --> Model "Payment_model" initialized
DEBUG - 2026-02-21 06:52:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-21 06:52:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-21 06:52:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-21 06:52:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-21 06:52:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-21 06:52:00 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/paymentgateway_list.php
INFO - 2026-02-21 06:52:00 --> Final output sent to browser
DEBUG - 2026-02-21 06:52:00 --> Total execution time: 2.5388
INFO - 2026-02-21 06:52:02 --> Config Class Initialized
INFO - 2026-02-21 06:52:02 --> Hooks Class Initialized
DEBUG - 2026-02-21 06:52:02 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:52:02 --> Utf8 Class Initialized
INFO - 2026-02-21 06:52:02 --> URI Class Initialized
INFO - 2026-02-21 06:52:02 --> Router Class Initialized
INFO - 2026-02-21 06:52:02 --> Output Class Initialized
INFO - 2026-02-21 06:52:02 --> Security Class Initialized
DEBUG - 2026-02-21 06:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:52:02 --> CSRF cookie sent
INFO - 2026-02-21 06:52:02 --> Input Class Initialized
INFO - 2026-02-21 06:52:02 --> Language Class Initialized
INFO - 2026-02-21 06:52:02 --> Language Class Initialized
INFO - 2026-02-21 06:52:02 --> Config Class Initialized
INFO - 2026-02-21 06:52:02 --> Loader Class Initialized
INFO - 2026-02-21 06:52:02 --> Helper loaded: url_helper
INFO - 2026-02-21 06:52:02 --> Helper loaded: form_helper
INFO - 2026-02-21 06:52:02 --> Helper loaded: html_helper
INFO - 2026-02-21 06:52:02 --> Helper loaded: file_helper
INFO - 2026-02-21 06:52:02 --> Helper loaded: email_helper
INFO - 2026-02-21 06:52:02 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:52:02 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:52:02 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:52:02 --> Database Driver Class Initialized
INFO - 2026-02-21 06:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:52:03 --> Upload Class Initialized
DEBUG - 2026-02-21 06:52:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:52:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:52:03 --> Encryption Class Initialized
INFO - 2026-02-21 06:52:03 --> Form Validation Class Initialized
INFO - 2026-02-21 06:52:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:52:03 --> Pagination Class Initialized
INFO - 2026-02-21 06:52:03 --> Email Class Initialized
INFO - 2026-02-21 06:52:03 --> Controller Class Initialized
DEBUG - 2026-02-21 06:52:03 --> Paymentgateway MX_Controller Initialized
INFO - 2026-02-21 06:52:03 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:52:03 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:52:03 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-21 06:52:03 --> Model "Payment_model" initialized
DEBUG - 2026-02-21 06:52:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-21 06:52:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-21 06:52:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-21 06:52:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-21 06:52:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-21 06:52:04 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/paymentgateway_transactions.php
INFO - 2026-02-21 06:52:04 --> Final output sent to browser
DEBUG - 2026-02-21 06:52:04 --> Total execution time: 2.6070
INFO - 2026-02-21 06:52:04 --> Config Class Initialized
INFO - 2026-02-21 06:52:04 --> Hooks Class Initialized
DEBUG - 2026-02-21 06:52:04 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:52:04 --> Utf8 Class Initialized
INFO - 2026-02-21 06:52:04 --> URI Class Initialized
INFO - 2026-02-21 06:52:04 --> Router Class Initialized
INFO - 2026-02-21 06:52:04 --> Output Class Initialized
INFO - 2026-02-21 06:52:04 --> Security Class Initialized
DEBUG - 2026-02-21 06:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:52:04 --> CSRF cookie sent
INFO - 2026-02-21 06:52:04 --> Input Class Initialized
INFO - 2026-02-21 06:52:04 --> Language Class Initialized
INFO - 2026-02-21 06:52:04 --> Language Class Initialized
INFO - 2026-02-21 06:52:04 --> Config Class Initialized
INFO - 2026-02-21 06:52:04 --> Loader Class Initialized
INFO - 2026-02-21 06:52:04 --> Helper loaded: url_helper
INFO - 2026-02-21 06:52:04 --> Helper loaded: form_helper
INFO - 2026-02-21 06:52:04 --> Helper loaded: html_helper
INFO - 2026-02-21 06:52:04 --> Helper loaded: file_helper
INFO - 2026-02-21 06:52:04 --> Helper loaded: email_helper
INFO - 2026-02-21 06:52:04 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:52:04 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:52:04 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:52:04 --> Database Driver Class Initialized
INFO - 2026-02-21 06:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:52:06 --> Upload Class Initialized
DEBUG - 2026-02-21 06:52:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:52:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:52:06 --> Encryption Class Initialized
INFO - 2026-02-21 06:52:06 --> Form Validation Class Initialized
INFO - 2026-02-21 06:52:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:52:06 --> Pagination Class Initialized
INFO - 2026-02-21 06:52:06 --> Email Class Initialized
INFO - 2026-02-21 06:52:06 --> Controller Class Initialized
DEBUG - 2026-02-21 06:52:06 --> Paymentgateway MX_Controller Initialized
INFO - 2026-02-21 06:52:06 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:52:06 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:52:06 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-21 06:52:06 --> Model "Payment_model" initialized
INFO - 2026-02-21 06:52:08 --> Final output sent to browser
DEBUG - 2026-02-21 06:52:08 --> Total execution time: 3.2930
INFO - 2026-02-21 06:52:10 --> Config Class Initialized
INFO - 2026-02-21 06:52:10 --> Hooks Class Initialized
DEBUG - 2026-02-21 06:52:10 --> UTF-8 Support Enabled
INFO - 2026-02-21 06:52:10 --> Utf8 Class Initialized
INFO - 2026-02-21 06:52:10 --> URI Class Initialized
INFO - 2026-02-21 06:52:10 --> Router Class Initialized
INFO - 2026-02-21 06:52:10 --> Output Class Initialized
INFO - 2026-02-21 06:52:10 --> Security Class Initialized
DEBUG - 2026-02-21 06:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 06:52:10 --> CSRF cookie sent
INFO - 2026-02-21 06:52:10 --> Input Class Initialized
INFO - 2026-02-21 06:52:10 --> Language Class Initialized
INFO - 2026-02-21 06:52:10 --> Language Class Initialized
INFO - 2026-02-21 06:52:10 --> Config Class Initialized
INFO - 2026-02-21 06:52:10 --> Loader Class Initialized
INFO - 2026-02-21 06:52:10 --> Helper loaded: url_helper
INFO - 2026-02-21 06:52:10 --> Helper loaded: form_helper
INFO - 2026-02-21 06:52:10 --> Helper loaded: html_helper
INFO - 2026-02-21 06:52:10 --> Helper loaded: file_helper
INFO - 2026-02-21 06:52:10 --> Helper loaded: email_helper
INFO - 2026-02-21 06:52:10 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 06:52:10 --> Helper loaded: ssp_helper
INFO - 2026-02-21 06:52:10 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 06:52:10 --> Database Driver Class Initialized
INFO - 2026-02-21 06:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 06:52:12 --> Upload Class Initialized
DEBUG - 2026-02-21 06:52:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 06:52:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 06:52:12 --> Encryption Class Initialized
INFO - 2026-02-21 06:52:12 --> Form Validation Class Initialized
INFO - 2026-02-21 06:52:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 06:52:12 --> Pagination Class Initialized
INFO - 2026-02-21 06:52:12 --> Email Class Initialized
INFO - 2026-02-21 06:52:12 --> Controller Class Initialized
DEBUG - 2026-02-21 06:52:12 --> Paymentgateway MX_Controller Initialized
INFO - 2026-02-21 06:52:12 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 06:52:12 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 06:52:12 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-21 06:52:12 --> Model "Payment_model" initialized
DEBUG - 2026-02-21 06:52:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-02-21 06:52:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-21 06:52:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-02-21 06:52:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-21 06:52:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-21 06:52:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/paymentgateway_list.php
INFO - 2026-02-21 06:52:12 --> Final output sent to browser
DEBUG - 2026-02-21 06:52:12 --> Total execution time: 2.1702
INFO - 2026-02-21 23:17:42 --> Config Class Initialized
INFO - 2026-02-21 23:17:42 --> Hooks Class Initialized
DEBUG - 2026-02-21 23:17:42 --> UTF-8 Support Enabled
INFO - 2026-02-21 23:17:42 --> Utf8 Class Initialized
INFO - 2026-02-21 23:17:42 --> URI Class Initialized
INFO - 2026-02-21 23:17:42 --> Router Class Initialized
INFO - 2026-02-21 23:17:42 --> Output Class Initialized
INFO - 2026-02-21 23:17:42 --> Security Class Initialized
DEBUG - 2026-02-21 23:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 23:17:42 --> CSRF cookie sent
INFO - 2026-02-21 23:17:42 --> Input Class Initialized
INFO - 2026-02-21 23:17:42 --> Language Class Initialized
INFO - 2026-02-21 23:17:42 --> Language Class Initialized
INFO - 2026-02-21 23:17:42 --> Config Class Initialized
INFO - 2026-02-21 23:17:42 --> Loader Class Initialized
INFO - 2026-02-21 23:17:42 --> Helper loaded: url_helper
INFO - 2026-02-21 23:17:42 --> Helper loaded: form_helper
INFO - 2026-02-21 23:17:42 --> Helper loaded: html_helper
INFO - 2026-02-21 23:17:42 --> Helper loaded: file_helper
INFO - 2026-02-21 23:17:42 --> Helper loaded: email_helper
INFO - 2026-02-21 23:17:42 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 23:17:42 --> Helper loaded: ssp_helper
INFO - 2026-02-21 23:17:42 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 23:17:42 --> Database Driver Class Initialized
INFO - 2026-02-21 23:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 23:17:44 --> Upload Class Initialized
DEBUG - 2026-02-21 23:17:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 23:17:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 23:17:44 --> Encryption Class Initialized
INFO - 2026-02-21 23:17:44 --> Form Validation Class Initialized
INFO - 2026-02-21 23:17:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 23:17:44 --> Pagination Class Initialized
INFO - 2026-02-21 23:17:44 --> Email Class Initialized
INFO - 2026-02-21 23:17:44 --> Controller Class Initialized
DEBUG - 2026-02-21 23:17:44 --> Paymentgateway MX_Controller Initialized
INFO - 2026-02-21 23:17:44 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 23:17:44 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 23:17:44 --> Model "PaymentGateway_model" initialized
INFO - 2026-02-21 23:17:44 --> Model "Payment_model" initialized
INFO - 2026-02-21 23:17:44 --> Config Class Initialized
INFO - 2026-02-21 23:17:44 --> Hooks Class Initialized
DEBUG - 2026-02-21 23:17:44 --> UTF-8 Support Enabled
INFO - 2026-02-21 23:17:44 --> Utf8 Class Initialized
INFO - 2026-02-21 23:17:44 --> URI Class Initialized
INFO - 2026-02-21 23:17:44 --> Router Class Initialized
INFO - 2026-02-21 23:17:44 --> Output Class Initialized
INFO - 2026-02-21 23:17:44 --> Security Class Initialized
DEBUG - 2026-02-21 23:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 23:17:44 --> CSRF cookie sent
INFO - 2026-02-21 23:17:44 --> Input Class Initialized
INFO - 2026-02-21 23:17:44 --> Language Class Initialized
INFO - 2026-02-21 23:17:44 --> Language Class Initialized
INFO - 2026-02-21 23:17:44 --> Config Class Initialized
INFO - 2026-02-21 23:17:44 --> Loader Class Initialized
INFO - 2026-02-21 23:17:44 --> Helper loaded: url_helper
INFO - 2026-02-21 23:17:44 --> Helper loaded: form_helper
INFO - 2026-02-21 23:17:44 --> Helper loaded: html_helper
INFO - 2026-02-21 23:17:44 --> Helper loaded: file_helper
INFO - 2026-02-21 23:17:44 --> Helper loaded: email_helper
INFO - 2026-02-21 23:17:44 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 23:17:44 --> Helper loaded: ssp_helper
INFO - 2026-02-21 23:17:44 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 23:17:44 --> Database Driver Class Initialized
INFO - 2026-02-21 23:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 23:17:46 --> Upload Class Initialized
DEBUG - 2026-02-21 23:17:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 23:17:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 23:17:46 --> Encryption Class Initialized
INFO - 2026-02-21 23:17:46 --> Form Validation Class Initialized
INFO - 2026-02-21 23:17:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 23:17:46 --> Pagination Class Initialized
INFO - 2026-02-21 23:17:46 --> Email Class Initialized
INFO - 2026-02-21 23:17:46 --> Controller Class Initialized
DEBUG - 2026-02-21 23:17:46 --> Authenticate MX_Controller Initialized
INFO - 2026-02-21 23:17:46 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 23:17:46 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 23:17:46 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-21 23:17:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
INFO - 2026-02-21 23:17:46 --> Model "Cart_model" initialized
DEBUG - 2026-02-21 23:17:47 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-21 23:17:47 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-02-21 23:17:47 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-21 23:17:47 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-21 23:17:47 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-02-21 23:17:47 --> Final output sent to browser
DEBUG - 2026-02-21 23:17:47 --> Total execution time: 2.5336
INFO - 2026-02-21 23:42:40 --> Config Class Initialized
INFO - 2026-02-21 23:42:40 --> Hooks Class Initialized
DEBUG - 2026-02-21 23:42:40 --> UTF-8 Support Enabled
INFO - 2026-02-21 23:42:40 --> Utf8 Class Initialized
INFO - 2026-02-21 23:42:40 --> URI Class Initialized
INFO - 2026-02-21 23:42:40 --> Router Class Initialized
INFO - 2026-02-21 23:42:40 --> Output Class Initialized
INFO - 2026-02-21 23:42:40 --> Security Class Initialized
DEBUG - 2026-02-21 23:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 23:42:40 --> CSRF cookie sent
INFO - 2026-02-21 23:42:40 --> Input Class Initialized
INFO - 2026-02-21 23:42:40 --> Language Class Initialized
INFO - 2026-02-21 23:42:40 --> Language Class Initialized
INFO - 2026-02-21 23:42:40 --> Config Class Initialized
INFO - 2026-02-21 23:42:40 --> Loader Class Initialized
INFO - 2026-02-21 23:42:40 --> Helper loaded: url_helper
INFO - 2026-02-21 23:42:40 --> Helper loaded: form_helper
INFO - 2026-02-21 23:42:40 --> Helper loaded: html_helper
INFO - 2026-02-21 23:42:40 --> Helper loaded: file_helper
INFO - 2026-02-21 23:42:40 --> Helper loaded: email_helper
INFO - 2026-02-21 23:42:40 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 23:42:40 --> Helper loaded: ssp_helper
INFO - 2026-02-21 23:42:40 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 23:42:40 --> Database Driver Class Initialized
INFO - 2026-02-21 23:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 23:42:42 --> Upload Class Initialized
DEBUG - 2026-02-21 23:42:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 23:42:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 23:42:42 --> Encryption Class Initialized
INFO - 2026-02-21 23:42:42 --> Form Validation Class Initialized
INFO - 2026-02-21 23:42:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 23:42:42 --> Pagination Class Initialized
INFO - 2026-02-21 23:42:42 --> Email Class Initialized
INFO - 2026-02-21 23:42:42 --> Controller Class Initialized
DEBUG - 2026-02-21 23:42:42 --> Authenticate MX_Controller Initialized
INFO - 2026-02-21 23:42:42 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 23:42:42 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 23:42:42 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-21 23:42:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
INFO - 2026-02-21 23:42:42 --> Model "Cart_model" initialized
DEBUG - 2026-02-21 23:42:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-21 23:42:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-02-21 23:42:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-21 23:42:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-21 23:42:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_forgetpass.php
INFO - 2026-02-21 23:42:42 --> Final output sent to browser
DEBUG - 2026-02-21 23:42:42 --> Total execution time: 2.4967
INFO - 2026-02-21 23:42:47 --> Config Class Initialized
INFO - 2026-02-21 23:42:47 --> Hooks Class Initialized
DEBUG - 2026-02-21 23:42:47 --> UTF-8 Support Enabled
INFO - 2026-02-21 23:42:47 --> Utf8 Class Initialized
INFO - 2026-02-21 23:42:47 --> URI Class Initialized
INFO - 2026-02-21 23:42:47 --> Router Class Initialized
INFO - 2026-02-21 23:42:47 --> Output Class Initialized
INFO - 2026-02-21 23:42:47 --> Security Class Initialized
DEBUG - 2026-02-21 23:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-02-21 23:42:47 --> CSRF cookie sent
INFO - 2026-02-21 23:42:47 --> Input Class Initialized
INFO - 2026-02-21 23:42:47 --> Language Class Initialized
INFO - 2026-02-21 23:42:47 --> Language Class Initialized
INFO - 2026-02-21 23:42:47 --> Config Class Initialized
INFO - 2026-02-21 23:42:47 --> Loader Class Initialized
INFO - 2026-02-21 23:42:47 --> Helper loaded: url_helper
INFO - 2026-02-21 23:42:47 --> Helper loaded: form_helper
INFO - 2026-02-21 23:42:47 --> Helper loaded: html_helper
INFO - 2026-02-21 23:42:47 --> Helper loaded: file_helper
INFO - 2026-02-21 23:42:47 --> Helper loaded: email_helper
INFO - 2026-02-21 23:42:47 --> Helper loaded: whmaz_helper
INFO - 2026-02-21 23:42:47 --> Helper loaded: ssp_helper
INFO - 2026-02-21 23:42:47 --> Helper loaded: cpanel_helper
INFO - 2026-02-21 23:42:47 --> Database Driver Class Initialized
INFO - 2026-02-21 23:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-02-21 23:42:48 --> Upload Class Initialized
DEBUG - 2026-02-21 23:42:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-02-21 23:42:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-02-21 23:42:48 --> Encryption Class Initialized
INFO - 2026-02-21 23:42:48 --> Form Validation Class Initialized
INFO - 2026-02-21 23:42:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-02-21 23:42:48 --> Pagination Class Initialized
INFO - 2026-02-21 23:42:48 --> Email Class Initialized
INFO - 2026-02-21 23:42:48 --> Controller Class Initialized
DEBUG - 2026-02-21 23:42:48 --> Authenticate MX_Controller Initialized
INFO - 2026-02-21 23:42:48 --> Model "Loginattempt_model" initialized
INFO - 2026-02-21 23:42:48 --> Model "Adminauth_model" initialized
INFO - 2026-02-21 23:42:48 --> Model "Appsetting_model" initialized
DEBUG - 2026-02-21 23:42:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
INFO - 2026-02-21 23:42:49 --> Model "Cart_model" initialized
DEBUG - 2026-02-21 23:42:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-02-21 23:42:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-02-21 23:42:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-02-21 23:42:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-02-21 23:42:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-02-21 23:42:49 --> Final output sent to browser
DEBUG - 2026-02-21 23:42:49 --> Total execution time: 2.6326

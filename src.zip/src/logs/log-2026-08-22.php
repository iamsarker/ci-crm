<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-08-22 09:17:12 --> Config Class Initialized
INFO - 2026-08-22 09:17:12 --> Hooks Class Initialized
DEBUG - 2026-08-22 09:17:12 --> UTF-8 Support Enabled
INFO - 2026-08-22 09:17:12 --> Utf8 Class Initialized
INFO - 2026-08-22 09:17:12 --> URI Class Initialized
INFO - 2026-08-22 09:17:12 --> Router Class Initialized
INFO - 2026-08-22 09:17:12 --> Output Class Initialized
INFO - 2026-08-22 09:17:12 --> Security Class Initialized
DEBUG - 2026-08-22 09:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-22 09:17:12 --> CSRF cookie sent
INFO - 2026-08-22 09:17:12 --> Input Class Initialized
INFO - 2026-08-22 09:17:12 --> Language Class Initialized
INFO - 2026-08-22 09:17:12 --> Language Class Initialized
INFO - 2026-08-22 09:17:12 --> Config Class Initialized
INFO - 2026-08-22 09:17:12 --> Loader Class Initialized
INFO - 2026-08-22 09:17:12 --> Helper loaded: url_helper
INFO - 2026-08-22 09:17:12 --> Helper loaded: form_helper
INFO - 2026-08-22 09:17:12 --> Helper loaded: html_helper
INFO - 2026-08-22 09:17:12 --> Helper loaded: file_helper
INFO - 2026-08-22 09:17:12 --> Helper loaded: email_helper
INFO - 2026-08-22 09:17:12 --> Helper loaded: whmaz_helper
INFO - 2026-08-22 09:17:12 --> Helper loaded: ssp_helper
INFO - 2026-08-22 09:17:12 --> Helper loaded: cpanel_helper
INFO - 2026-08-22 09:17:12 --> Helper loaded: plesk_helper
INFO - 2026-08-22 09:17:12 --> Helper loaded: directadmin_helper
INFO - 2026-08-22 09:17:12 --> Helper loaded: domain_helper
INFO - 2026-08-22 09:17:12 --> Helper loaded: entitlement_helper
INFO - 2026-08-22 09:17:12 --> Database Driver Class Initialized
INFO - 2026-08-22 09:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-22 09:17:14 --> Upload Class Initialized
DEBUG - 2026-08-22 09:17:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-22 09:17:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-22 09:17:14 --> Encryption Class Initialized
INFO - 2026-08-22 09:17:14 --> Form Validation Class Initialized
INFO - 2026-08-22 09:17:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-22 09:17:14 --> Pagination Class Initialized
INFO - 2026-08-22 09:17:14 --> Email Class Initialized
INFO - 2026-08-22 09:17:14 --> Controller Class Initialized
DEBUG - 2026-08-22 09:17:14 --> Pay MX_Controller Initialized
INFO - 2026-08-22 09:17:14 --> Model "Loginattempt_model" initialized
INFO - 2026-08-22 09:17:14 --> Model "Auth_model" initialized
INFO - 2026-08-22 09:17:14 --> Model "Cart_model" initialized
INFO - 2026-08-22 09:17:14 --> Model "Payment_model" initialized
INFO - 2026-08-22 09:17:14 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-22 09:17:14 --> Model "Billing_model" initialized
INFO - 2026-08-22 09:17:14 --> Model "Invoice_model" initialized
DEBUG - 2026-08-22 09:17:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-22 09:17:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-22 09:17:15 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/invoicing/views/invoicing_pay_resume.php
INFO - 2026-08-22 09:17:15 --> Final output sent to browser
DEBUG - 2026-08-22 09:17:15 --> Total execution time: 3.4636
INFO - 2026-08-22 09:17:15 --> Config Class Initialized
INFO - 2026-08-22 09:17:15 --> Hooks Class Initialized
DEBUG - 2026-08-22 09:17:15 --> UTF-8 Support Enabled
INFO - 2026-08-22 09:17:15 --> Utf8 Class Initialized
INFO - 2026-08-22 09:17:15 --> URI Class Initialized
INFO - 2026-08-22 09:17:15 --> Router Class Initialized
INFO - 2026-08-22 09:17:15 --> Output Class Initialized
INFO - 2026-08-22 09:17:15 --> Security Class Initialized
DEBUG - 2026-08-22 09:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-22 09:17:15 --> CSRF cookie sent
INFO - 2026-08-22 09:17:15 --> Input Class Initialized
INFO - 2026-08-22 09:17:15 --> Language Class Initialized
INFO - 2026-08-22 09:17:15 --> Language Class Initialized
INFO - 2026-08-22 09:17:15 --> Config Class Initialized
INFO - 2026-08-22 09:17:15 --> Loader Class Initialized
INFO - 2026-08-22 09:17:15 --> Helper loaded: url_helper
INFO - 2026-08-22 09:17:15 --> Helper loaded: form_helper
INFO - 2026-08-22 09:17:15 --> Helper loaded: html_helper
INFO - 2026-08-22 09:17:15 --> Helper loaded: file_helper
INFO - 2026-08-22 09:17:15 --> Helper loaded: email_helper
INFO - 2026-08-22 09:17:15 --> Helper loaded: whmaz_helper
INFO - 2026-08-22 09:17:15 --> Helper loaded: ssp_helper
INFO - 2026-08-22 09:17:15 --> Helper loaded: cpanel_helper
INFO - 2026-08-22 09:17:15 --> Helper loaded: plesk_helper
INFO - 2026-08-22 09:17:15 --> Helper loaded: directadmin_helper
INFO - 2026-08-22 09:17:15 --> Helper loaded: domain_helper
INFO - 2026-08-22 09:17:15 --> Helper loaded: entitlement_helper
INFO - 2026-08-22 09:17:15 --> Database Driver Class Initialized
INFO - 2026-08-22 09:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-22 09:17:17 --> Upload Class Initialized
DEBUG - 2026-08-22 09:17:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-22 09:17:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-22 09:17:17 --> Encryption Class Initialized
INFO - 2026-08-22 09:17:17 --> Form Validation Class Initialized
INFO - 2026-08-22 09:17:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-22 09:17:17 --> Pagination Class Initialized
INFO - 2026-08-22 09:17:17 --> Email Class Initialized
INFO - 2026-08-22 09:17:17 --> Controller Class Initialized
DEBUG - 2026-08-22 09:17:17 --> Pay MX_Controller Initialized
INFO - 2026-08-22 09:17:17 --> Model "Loginattempt_model" initialized
INFO - 2026-08-22 09:17:17 --> Model "Auth_model" initialized
INFO - 2026-08-22 09:17:17 --> Model "Cart_model" initialized
INFO - 2026-08-22 09:17:18 --> Model "Payment_model" initialized
INFO - 2026-08-22 09:17:18 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-22 09:17:18 --> Model "Billing_model" initialized
INFO - 2026-08-22 09:17:18 --> Model "Invoice_model" initialized
DEBUG - 2026-08-22 09:17:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-22 09:17:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-22 09:17:19 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/invoicing/views/invoicing_pay_resume.php
INFO - 2026-08-22 09:17:19 --> Final output sent to browser
DEBUG - 2026-08-22 09:17:19 --> Total execution time: 3.5564
INFO - 2026-08-22 09:17:45 --> Config Class Initialized
INFO - 2026-08-22 09:17:45 --> Hooks Class Initialized
DEBUG - 2026-08-22 09:17:45 --> UTF-8 Support Enabled
INFO - 2026-08-22 09:17:45 --> Utf8 Class Initialized
INFO - 2026-08-22 09:17:45 --> URI Class Initialized
INFO - 2026-08-22 09:17:45 --> Router Class Initialized
INFO - 2026-08-22 09:17:45 --> Output Class Initialized
INFO - 2026-08-22 09:17:45 --> Security Class Initialized
DEBUG - 2026-08-22 09:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-22 09:17:45 --> CSRF cookie sent
INFO - 2026-08-22 09:17:45 --> Input Class Initialized
INFO - 2026-08-22 09:17:45 --> Language Class Initialized
INFO - 2026-08-22 09:17:45 --> Language Class Initialized
INFO - 2026-08-22 09:17:45 --> Config Class Initialized
INFO - 2026-08-22 09:17:45 --> Loader Class Initialized
INFO - 2026-08-22 09:17:45 --> Helper loaded: url_helper
INFO - 2026-08-22 09:17:45 --> Helper loaded: form_helper
INFO - 2026-08-22 09:17:45 --> Helper loaded: html_helper
INFO - 2026-08-22 09:17:45 --> Helper loaded: file_helper
INFO - 2026-08-22 09:17:45 --> Helper loaded: email_helper
INFO - 2026-08-22 09:17:45 --> Helper loaded: whmaz_helper
INFO - 2026-08-22 09:17:45 --> Helper loaded: ssp_helper
INFO - 2026-08-22 09:17:45 --> Helper loaded: cpanel_helper
INFO - 2026-08-22 09:17:45 --> Helper loaded: plesk_helper
INFO - 2026-08-22 09:17:45 --> Helper loaded: directadmin_helper
INFO - 2026-08-22 09:17:45 --> Helper loaded: domain_helper
INFO - 2026-08-22 09:17:45 --> Helper loaded: entitlement_helper
INFO - 2026-08-22 09:17:45 --> Database Driver Class Initialized
INFO - 2026-08-22 09:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-22 09:17:47 --> Upload Class Initialized
DEBUG - 2026-08-22 09:17:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-22 09:17:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-22 09:17:47 --> Encryption Class Initialized
INFO - 2026-08-22 09:17:47 --> Form Validation Class Initialized
INFO - 2026-08-22 09:17:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-22 09:17:47 --> Pagination Class Initialized
INFO - 2026-08-22 09:17:47 --> Email Class Initialized
INFO - 2026-08-22 09:17:47 --> Controller Class Initialized
DEBUG - 2026-08-22 09:17:47 --> Pay MX_Controller Initialized
INFO - 2026-08-22 09:17:47 --> Model "Loginattempt_model" initialized
INFO - 2026-08-22 09:17:47 --> Model "Auth_model" initialized
INFO - 2026-08-22 09:17:47 --> Model "Cart_model" initialized
INFO - 2026-08-22 09:17:47 --> Model "Payment_model" initialized
INFO - 2026-08-22 09:17:47 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-22 09:17:47 --> Model "Billing_model" initialized
INFO - 2026-08-22 09:17:47 --> Model "Invoice_model" initialized
DEBUG - 2026-08-22 09:17:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-22 09:17:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-22 09:17:49 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/invoicing/views/invoicing_pay_resume.php
INFO - 2026-08-22 09:17:49 --> Final output sent to browser
DEBUG - 2026-08-22 09:17:49 --> Total execution time: 3.6022
INFO - 2026-08-22 09:17:51 --> Config Class Initialized
INFO - 2026-08-22 09:17:51 --> Hooks Class Initialized
DEBUG - 2026-08-22 09:17:51 --> UTF-8 Support Enabled
INFO - 2026-08-22 09:17:51 --> Utf8 Class Initialized
INFO - 2026-08-22 09:17:51 --> URI Class Initialized
INFO - 2026-08-22 09:17:51 --> Router Class Initialized
INFO - 2026-08-22 09:17:51 --> Output Class Initialized
INFO - 2026-08-22 09:17:51 --> Security Class Initialized
DEBUG - 2026-08-22 09:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-22 09:17:51 --> CSRF cookie sent
INFO - 2026-08-22 09:17:51 --> Input Class Initialized
INFO - 2026-08-22 09:17:51 --> Language Class Initialized
INFO - 2026-08-22 09:17:51 --> Language Class Initialized
INFO - 2026-08-22 09:17:51 --> Config Class Initialized
INFO - 2026-08-22 09:17:51 --> Loader Class Initialized
INFO - 2026-08-22 09:17:51 --> Helper loaded: url_helper
INFO - 2026-08-22 09:17:51 --> Helper loaded: form_helper
INFO - 2026-08-22 09:17:51 --> Helper loaded: html_helper
INFO - 2026-08-22 09:17:51 --> Helper loaded: file_helper
INFO - 2026-08-22 09:17:51 --> Helper loaded: email_helper
INFO - 2026-08-22 09:17:51 --> Helper loaded: whmaz_helper
INFO - 2026-08-22 09:17:51 --> Helper loaded: ssp_helper
INFO - 2026-08-22 09:17:51 --> Helper loaded: cpanel_helper
INFO - 2026-08-22 09:17:51 --> Helper loaded: plesk_helper
INFO - 2026-08-22 09:17:51 --> Helper loaded: directadmin_helper
INFO - 2026-08-22 09:17:51 --> Helper loaded: domain_helper
INFO - 2026-08-22 09:17:51 --> Helper loaded: entitlement_helper
INFO - 2026-08-22 09:17:51 --> Database Driver Class Initialized
INFO - 2026-08-22 09:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-22 09:17:52 --> Upload Class Initialized
DEBUG - 2026-08-22 09:17:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-22 09:17:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-22 09:17:52 --> Encryption Class Initialized
INFO - 2026-08-22 09:17:52 --> Form Validation Class Initialized
INFO - 2026-08-22 09:17:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-22 09:17:52 --> Pagination Class Initialized
INFO - 2026-08-22 09:17:52 --> Email Class Initialized
INFO - 2026-08-22 09:17:52 --> Controller Class Initialized
DEBUG - 2026-08-22 09:17:53 --> Pay MX_Controller Initialized
INFO - 2026-08-22 09:17:53 --> Model "Loginattempt_model" initialized
INFO - 2026-08-22 09:17:53 --> Model "Auth_model" initialized
INFO - 2026-08-22 09:17:53 --> Model "Cart_model" initialized
INFO - 2026-08-22 09:17:53 --> Model "Payment_model" initialized
INFO - 2026-08-22 09:17:53 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-22 09:17:53 --> Model "Billing_model" initialized
INFO - 2026-08-22 09:17:53 --> Model "Invoice_model" initialized
DEBUG - 2026-08-22 09:17:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-22 09:17:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-22 09:17:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/invoicing/views/invoicing_pay_resume.php
INFO - 2026-08-22 09:17:54 --> Final output sent to browser
DEBUG - 2026-08-22 09:17:54 --> Total execution time: 3.5772
INFO - 2026-08-22 09:32:21 --> Config Class Initialized
INFO - 2026-08-22 09:32:21 --> Hooks Class Initialized
DEBUG - 2026-08-22 09:32:21 --> UTF-8 Support Enabled
INFO - 2026-08-22 09:32:21 --> Utf8 Class Initialized
INFO - 2026-08-22 09:32:21 --> URI Class Initialized
DEBUG - 2026-08-22 09:32:21 --> No URI present. Default controller set.
INFO - 2026-08-22 09:32:21 --> Router Class Initialized
INFO - 2026-08-22 09:32:21 --> Output Class Initialized
INFO - 2026-08-22 09:32:21 --> Security Class Initialized
DEBUG - 2026-08-22 09:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-22 09:32:21 --> CSRF cookie sent
INFO - 2026-08-22 09:32:21 --> Input Class Initialized
INFO - 2026-08-22 09:32:21 --> Language Class Initialized
INFO - 2026-08-22 09:32:21 --> Language Class Initialized
INFO - 2026-08-22 09:32:21 --> Config Class Initialized
INFO - 2026-08-22 09:32:21 --> Loader Class Initialized
INFO - 2026-08-22 09:32:21 --> Helper loaded: url_helper
INFO - 2026-08-22 09:32:21 --> Helper loaded: form_helper
INFO - 2026-08-22 09:32:21 --> Helper loaded: html_helper
INFO - 2026-08-22 09:32:21 --> Helper loaded: file_helper
INFO - 2026-08-22 09:32:21 --> Helper loaded: email_helper
INFO - 2026-08-22 09:32:21 --> Helper loaded: whmaz_helper
INFO - 2026-08-22 09:32:21 --> Helper loaded: ssp_helper
INFO - 2026-08-22 09:32:21 --> Helper loaded: cpanel_helper
INFO - 2026-08-22 09:32:21 --> Helper loaded: plesk_helper
INFO - 2026-08-22 09:32:21 --> Helper loaded: directadmin_helper
INFO - 2026-08-22 09:32:21 --> Helper loaded: domain_helper
INFO - 2026-08-22 09:32:21 --> Helper loaded: entitlement_helper
INFO - 2026-08-22 09:32:21 --> Database Driver Class Initialized
INFO - 2026-08-22 09:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-22 09:32:23 --> Upload Class Initialized
DEBUG - 2026-08-22 09:32:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-22 09:32:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-22 09:32:23 --> Encryption Class Initialized
INFO - 2026-08-22 09:32:23 --> Form Validation Class Initialized
INFO - 2026-08-22 09:32:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-22 09:32:23 --> Pagination Class Initialized
INFO - 2026-08-22 09:32:23 --> Email Class Initialized
INFO - 2026-08-22 09:32:23 --> Controller Class Initialized
DEBUG - 2026-08-22 09:32:23 --> Home MX_Controller Initialized
INFO - 2026-08-22 09:32:23 --> Model "Loginattempt_model" initialized
INFO - 2026-08-22 09:32:23 --> Model "Auth_model" initialized
INFO - 2026-08-22 09:32:23 --> Model "Cart_model" initialized
DEBUG - 2026-08-22 09:32:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-22 09:32:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-08-22 09:32:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-22 09:32:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/home/views/home_view.php
INFO - 2026-08-22 09:32:24 --> Final output sent to browser
DEBUG - 2026-08-22 09:32:24 --> Total execution time: 3.3203
INFO - 2026-08-22 09:32:24 --> Config Class Initialized
INFO - 2026-08-22 09:32:24 --> Hooks Class Initialized
DEBUG - 2026-08-22 09:32:24 --> UTF-8 Support Enabled
INFO - 2026-08-22 09:32:24 --> Utf8 Class Initialized
INFO - 2026-08-22 09:32:24 --> URI Class Initialized
INFO - 2026-08-22 09:32:24 --> Router Class Initialized
INFO - 2026-08-22 09:32:24 --> Output Class Initialized
INFO - 2026-08-22 09:32:24 --> Security Class Initialized
DEBUG - 2026-08-22 09:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-08-22 09:32:24 --> CSRF cookie sent
INFO - 2026-08-22 09:32:24 --> Input Class Initialized
INFO - 2026-08-22 09:32:24 --> Language Class Initialized
INFO - 2026-08-22 09:32:24 --> Language Class Initialized
INFO - 2026-08-22 09:32:24 --> Config Class Initialized
INFO - 2026-08-22 09:32:24 --> Loader Class Initialized
INFO - 2026-08-22 09:32:24 --> Helper loaded: url_helper
INFO - 2026-08-22 09:32:24 --> Helper loaded: form_helper
INFO - 2026-08-22 09:32:24 --> Helper loaded: html_helper
INFO - 2026-08-22 09:32:24 --> Helper loaded: file_helper
INFO - 2026-08-22 09:32:24 --> Helper loaded: email_helper
INFO - 2026-08-22 09:32:24 --> Helper loaded: whmaz_helper
INFO - 2026-08-22 09:32:24 --> Helper loaded: ssp_helper
INFO - 2026-08-22 09:32:24 --> Helper loaded: cpanel_helper
INFO - 2026-08-22 09:32:24 --> Helper loaded: plesk_helper
INFO - 2026-08-22 09:32:24 --> Helper loaded: directadmin_helper
INFO - 2026-08-22 09:32:24 --> Helper loaded: domain_helper
INFO - 2026-08-22 09:32:24 --> Helper loaded: entitlement_helper
INFO - 2026-08-22 09:32:24 --> Database Driver Class Initialized
INFO - 2026-08-22 09:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-08-22 09:32:26 --> Upload Class Initialized
DEBUG - 2026-08-22 09:32:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-08-22 09:32:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-08-22 09:32:26 --> Encryption Class Initialized
INFO - 2026-08-22 09:32:26 --> Form Validation Class Initialized
INFO - 2026-08-22 09:32:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-08-22 09:32:26 --> Pagination Class Initialized
INFO - 2026-08-22 09:32:26 --> Email Class Initialized
INFO - 2026-08-22 09:32:26 --> Controller Class Initialized
DEBUG - 2026-08-22 09:32:26 --> Pay MX_Controller Initialized
INFO - 2026-08-22 09:32:26 --> Model "Loginattempt_model" initialized
INFO - 2026-08-22 09:32:26 --> Model "Auth_model" initialized
INFO - 2026-08-22 09:32:26 --> Model "Cart_model" initialized
INFO - 2026-08-22 09:32:26 --> Model "Payment_model" initialized
INFO - 2026-08-22 09:32:26 --> Model "PaymentGateway_model" initialized
INFO - 2026-08-22 09:32:26 --> Model "Billing_model" initialized
INFO - 2026-08-22 09:32:26 --> Model "Invoice_model" initialized
DEBUG - 2026-08-22 09:32:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-08-22 09:32:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-08-22 09:32:27 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/invoicing/views/invoicing_pay_resume.php
INFO - 2026-08-22 09:32:27 --> Final output sent to browser
DEBUG - 2026-08-22 09:32:27 --> Total execution time: 3.5588

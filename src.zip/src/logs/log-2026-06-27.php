<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-06-27 13:20:56 --> Config Class Initialized
INFO - 2026-06-27 13:20:56 --> Hooks Class Initialized
DEBUG - 2026-06-27 13:20:56 --> UTF-8 Support Enabled
INFO - 2026-06-27 13:20:56 --> Utf8 Class Initialized
INFO - 2026-06-27 13:20:56 --> URI Class Initialized
DEBUG - 2026-06-27 13:20:56 --> No URI present. Default controller set.
INFO - 2026-06-27 13:20:56 --> Router Class Initialized
INFO - 2026-06-27 13:20:56 --> Output Class Initialized
INFO - 2026-06-27 13:20:56 --> Security Class Initialized
DEBUG - 2026-06-27 13:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-27 13:20:56 --> CSRF cookie sent
INFO - 2026-06-27 13:20:56 --> Input Class Initialized
INFO - 2026-06-27 13:20:56 --> Language Class Initialized
INFO - 2026-06-27 13:20:56 --> Language Class Initialized
INFO - 2026-06-27 13:20:56 --> Config Class Initialized
INFO - 2026-06-27 13:20:56 --> Loader Class Initialized
INFO - 2026-06-27 13:20:56 --> Helper loaded: url_helper
INFO - 2026-06-27 13:20:56 --> Helper loaded: form_helper
INFO - 2026-06-27 13:20:56 --> Helper loaded: html_helper
INFO - 2026-06-27 13:20:56 --> Helper loaded: file_helper
INFO - 2026-06-27 13:20:56 --> Helper loaded: email_helper
INFO - 2026-06-27 13:20:56 --> Helper loaded: whmaz_helper
INFO - 2026-06-27 13:20:56 --> Helper loaded: ssp_helper
INFO - 2026-06-27 13:20:56 --> Helper loaded: cpanel_helper
INFO - 2026-06-27 13:20:56 --> Helper loaded: plesk_helper
INFO - 2026-06-27 13:20:56 --> Helper loaded: directadmin_helper
INFO - 2026-06-27 13:20:56 --> Helper loaded: domain_helper
INFO - 2026-06-27 13:20:56 --> Database Driver Class Initialized
INFO - 2026-06-27 13:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-27 13:20:59 --> Upload Class Initialized
DEBUG - 2026-06-27 13:20:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-27 13:20:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-27 13:20:59 --> Encryption Class Initialized
INFO - 2026-06-27 13:20:59 --> Form Validation Class Initialized
INFO - 2026-06-27 13:20:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-27 13:20:59 --> Pagination Class Initialized
INFO - 2026-06-27 13:20:59 --> Email Class Initialized
INFO - 2026-06-27 13:20:59 --> Controller Class Initialized
DEBUG - 2026-06-27 13:20:59 --> Auth MX_Controller Initialized
INFO - 2026-06-27 13:20:59 --> Model "Loginattempt_model" initialized
INFO - 2026-06-27 13:20:59 --> Model "Auth_model" initialized
INFO - 2026-06-27 13:20:59 --> Model "Cart_model" initialized
INFO - 2026-06-27 13:21:00 --> Model "Appsetting_model" initialized
INFO - 2026-06-27 13:21:00 --> Config Class Initialized
INFO - 2026-06-27 13:21:00 --> Hooks Class Initialized
DEBUG - 2026-06-27 13:21:00 --> UTF-8 Support Enabled
INFO - 2026-06-27 13:21:00 --> Utf8 Class Initialized
INFO - 2026-06-27 13:21:00 --> URI Class Initialized
INFO - 2026-06-27 13:21:00 --> Router Class Initialized
INFO - 2026-06-27 13:21:00 --> Output Class Initialized
INFO - 2026-06-27 13:21:00 --> Security Class Initialized
DEBUG - 2026-06-27 13:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-27 13:21:00 --> CSRF cookie sent
INFO - 2026-06-27 13:21:00 --> Input Class Initialized
INFO - 2026-06-27 13:21:00 --> Language Class Initialized
INFO - 2026-06-27 13:21:00 --> Language Class Initialized
INFO - 2026-06-27 13:21:00 --> Config Class Initialized
INFO - 2026-06-27 13:21:00 --> Loader Class Initialized
INFO - 2026-06-27 13:21:00 --> Helper loaded: url_helper
INFO - 2026-06-27 13:21:00 --> Helper loaded: form_helper
INFO - 2026-06-27 13:21:00 --> Helper loaded: html_helper
INFO - 2026-06-27 13:21:00 --> Helper loaded: file_helper
INFO - 2026-06-27 13:21:00 --> Helper loaded: email_helper
INFO - 2026-06-27 13:21:00 --> Helper loaded: whmaz_helper
INFO - 2026-06-27 13:21:00 --> Helper loaded: ssp_helper
INFO - 2026-06-27 13:21:00 --> Helper loaded: cpanel_helper
INFO - 2026-06-27 13:21:00 --> Helper loaded: plesk_helper
INFO - 2026-06-27 13:21:00 --> Helper loaded: directadmin_helper
INFO - 2026-06-27 13:21:00 --> Helper loaded: domain_helper
INFO - 2026-06-27 13:21:00 --> Database Driver Class Initialized
INFO - 2026-06-27 13:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-27 13:21:03 --> Upload Class Initialized
DEBUG - 2026-06-27 13:21:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-27 13:21:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-27 13:21:03 --> Encryption Class Initialized
INFO - 2026-06-27 13:21:03 --> Form Validation Class Initialized
INFO - 2026-06-27 13:21:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-27 13:21:03 --> Pagination Class Initialized
INFO - 2026-06-27 13:21:03 --> Email Class Initialized
INFO - 2026-06-27 13:21:03 --> Controller Class Initialized
DEBUG - 2026-06-27 13:21:03 --> Auth MX_Controller Initialized
INFO - 2026-06-27 13:21:03 --> Model "Loginattempt_model" initialized
INFO - 2026-06-27 13:21:03 --> Model "Auth_model" initialized
INFO - 2026-06-27 13:21:03 --> Model "Cart_model" initialized
INFO - 2026-06-27 13:21:03 --> Model "Appsetting_model" initialized
DEBUG - 2026-06-27 13:21:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-06-27 13:21:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-06-27 13:21:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-06-27 13:21:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-06-27 13:21:03 --> Final output sent to browser
DEBUG - 2026-06-27 13:21:03 --> Total execution time: 3.2359
INFO - 2026-06-27 13:21:03 --> Config Class Initialized
INFO - 2026-06-27 13:21:03 --> Hooks Class Initialized
DEBUG - 2026-06-27 13:21:03 --> UTF-8 Support Enabled
INFO - 2026-06-27 13:21:03 --> Utf8 Class Initialized
INFO - 2026-06-27 13:21:03 --> URI Class Initialized
INFO - 2026-06-27 13:21:03 --> Router Class Initialized
INFO - 2026-06-27 13:21:03 --> Output Class Initialized
INFO - 2026-06-27 13:21:03 --> Security Class Initialized
DEBUG - 2026-06-27 13:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-06-27 13:21:03 --> CSRF cookie sent
INFO - 2026-06-27 13:21:03 --> Input Class Initialized
INFO - 2026-06-27 13:21:03 --> Language Class Initialized
INFO - 2026-06-27 13:21:03 --> Language Class Initialized
INFO - 2026-06-27 13:21:03 --> Config Class Initialized
INFO - 2026-06-27 13:21:03 --> Loader Class Initialized
INFO - 2026-06-27 13:21:03 --> Helper loaded: url_helper
INFO - 2026-06-27 13:21:03 --> Helper loaded: form_helper
INFO - 2026-06-27 13:21:03 --> Helper loaded: html_helper
INFO - 2026-06-27 13:21:03 --> Helper loaded: file_helper
INFO - 2026-06-27 13:21:03 --> Helper loaded: email_helper
INFO - 2026-06-27 13:21:03 --> Helper loaded: whmaz_helper
INFO - 2026-06-27 13:21:03 --> Helper loaded: ssp_helper
INFO - 2026-06-27 13:21:03 --> Helper loaded: cpanel_helper
INFO - 2026-06-27 13:21:03 --> Helper loaded: plesk_helper
INFO - 2026-06-27 13:21:03 --> Helper loaded: directadmin_helper
INFO - 2026-06-27 13:21:03 --> Helper loaded: domain_helper
INFO - 2026-06-27 13:21:03 --> Database Driver Class Initialized
INFO - 2026-06-27 13:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-06-27 13:21:05 --> Upload Class Initialized
DEBUG - 2026-06-27 13:21:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-06-27 13:21:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-06-27 13:21:05 --> Encryption Class Initialized
INFO - 2026-06-27 13:21:05 --> Form Validation Class Initialized
INFO - 2026-06-27 13:21:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-06-27 13:21:05 --> Pagination Class Initialized
INFO - 2026-06-27 13:21:05 --> Email Class Initialized
INFO - 2026-06-27 13:21:05 --> Controller Class Initialized
DEBUG - 2026-06-27 13:21:05 --> Cart MX_Controller Initialized
INFO - 2026-06-27 13:21:05 --> Model "Loginattempt_model" initialized
INFO - 2026-06-27 13:21:05 --> Model "Auth_model" initialized
INFO - 2026-06-27 13:21:05 --> Model "Cart_model" initialized
INFO - 2026-06-27 13:21:05 --> Model "Common_model" initialized
INFO - 2026-06-27 13:21:05 --> Model "Order_model" initialized
INFO - 2026-06-27 13:21:05 --> Model "Appsetting_model" initialized
INFO - 2026-06-27 13:21:05 --> Model "PaymentGateway_model" initialized
INFO - 2026-06-27 13:21:05 --> Model "Promocode_model" initialized
INFO - 2026-06-27 13:21:06 --> Final output sent to browser
DEBUG - 2026-06-27 13:21:06 --> Total execution time: 2.2079

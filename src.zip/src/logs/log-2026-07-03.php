<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-07-03 07:17:08 --> Config Class Initialized
INFO - 2026-07-03 07:17:08 --> Hooks Class Initialized
DEBUG - 2026-07-03 07:17:08 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:17:08 --> Utf8 Class Initialized
INFO - 2026-07-03 07:17:08 --> URI Class Initialized
DEBUG - 2026-07-03 07:17:08 --> No URI present. Default controller set.
INFO - 2026-07-03 07:17:08 --> Router Class Initialized
INFO - 2026-07-03 07:17:08 --> Output Class Initialized
INFO - 2026-07-03 07:17:08 --> Security Class Initialized
DEBUG - 2026-07-03 07:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:17:08 --> CSRF cookie sent
INFO - 2026-07-03 07:17:08 --> Input Class Initialized
INFO - 2026-07-03 07:17:08 --> Language Class Initialized
INFO - 2026-07-03 07:17:08 --> Language Class Initialized
INFO - 2026-07-03 07:17:08 --> Config Class Initialized
INFO - 2026-07-03 07:17:08 --> Loader Class Initialized
INFO - 2026-07-03 07:17:08 --> Helper loaded: url_helper
INFO - 2026-07-03 07:17:08 --> Helper loaded: form_helper
INFO - 2026-07-03 07:17:08 --> Helper loaded: html_helper
INFO - 2026-07-03 07:17:08 --> Helper loaded: file_helper
INFO - 2026-07-03 07:17:08 --> Helper loaded: email_helper
INFO - 2026-07-03 07:17:08 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:17:08 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:17:08 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:17:08 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:17:08 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:17:08 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:17:08 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:17:08 --> Database Driver Class Initialized
INFO - 2026-07-03 07:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:17:10 --> Upload Class Initialized
DEBUG - 2026-07-03 07:17:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:17:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:17:10 --> Encryption Class Initialized
INFO - 2026-07-03 07:17:10 --> Form Validation Class Initialized
INFO - 2026-07-03 07:17:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:17:10 --> Pagination Class Initialized
INFO - 2026-07-03 07:17:10 --> Email Class Initialized
INFO - 2026-07-03 07:17:10 --> Controller Class Initialized
DEBUG - 2026-07-03 07:17:10 --> Auth MX_Controller Initialized
INFO - 2026-07-03 07:17:10 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:17:10 --> Model "Auth_model" initialized
INFO - 2026-07-03 07:17:10 --> Model "Cart_model" initialized
INFO - 2026-07-03 07:17:10 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 07:17:10 --> Config Class Initialized
INFO - 2026-07-03 07:17:10 --> Hooks Class Initialized
DEBUG - 2026-07-03 07:17:10 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:17:10 --> Utf8 Class Initialized
INFO - 2026-07-03 07:17:10 --> URI Class Initialized
INFO - 2026-07-03 07:17:10 --> Router Class Initialized
INFO - 2026-07-03 07:17:10 --> Output Class Initialized
INFO - 2026-07-03 07:17:10 --> Security Class Initialized
DEBUG - 2026-07-03 07:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:17:10 --> CSRF cookie sent
INFO - 2026-07-03 07:17:10 --> Input Class Initialized
INFO - 2026-07-03 07:17:10 --> Language Class Initialized
INFO - 2026-07-03 07:17:10 --> Language Class Initialized
INFO - 2026-07-03 07:17:10 --> Config Class Initialized
INFO - 2026-07-03 07:17:10 --> Loader Class Initialized
INFO - 2026-07-03 07:17:10 --> Helper loaded: url_helper
INFO - 2026-07-03 07:17:10 --> Helper loaded: form_helper
INFO - 2026-07-03 07:17:10 --> Helper loaded: html_helper
INFO - 2026-07-03 07:17:10 --> Helper loaded: file_helper
INFO - 2026-07-03 07:17:10 --> Helper loaded: email_helper
INFO - 2026-07-03 07:17:10 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:17:10 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:17:10 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:17:10 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:17:10 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:17:10 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:17:10 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:17:10 --> Database Driver Class Initialized
INFO - 2026-07-03 07:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:17:12 --> Upload Class Initialized
DEBUG - 2026-07-03 07:17:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:17:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:17:12 --> Encryption Class Initialized
INFO - 2026-07-03 07:17:12 --> Form Validation Class Initialized
INFO - 2026-07-03 07:17:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:17:12 --> Pagination Class Initialized
INFO - 2026-07-03 07:17:12 --> Email Class Initialized
INFO - 2026-07-03 07:17:12 --> Controller Class Initialized
DEBUG - 2026-07-03 07:17:12 --> Auth MX_Controller Initialized
INFO - 2026-07-03 07:17:12 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:17:12 --> Model "Auth_model" initialized
INFO - 2026-07-03 07:17:12 --> Model "Cart_model" initialized
INFO - 2026-07-03 07:17:12 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-03 07:17:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 07:17:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 07:17:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 07:17:12 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-07-03 07:17:12 --> Final output sent to browser
DEBUG - 2026-07-03 07:17:12 --> Total execution time: 1.9369
INFO - 2026-07-03 07:17:13 --> Config Class Initialized
INFO - 2026-07-03 07:17:13 --> Hooks Class Initialized
DEBUG - 2026-07-03 07:17:13 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:17:13 --> Utf8 Class Initialized
INFO - 2026-07-03 07:17:13 --> URI Class Initialized
INFO - 2026-07-03 07:17:13 --> Router Class Initialized
INFO - 2026-07-03 07:17:13 --> Output Class Initialized
INFO - 2026-07-03 07:17:13 --> Security Class Initialized
DEBUG - 2026-07-03 07:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:17:13 --> CSRF cookie sent
INFO - 2026-07-03 07:17:13 --> Input Class Initialized
INFO - 2026-07-03 07:17:13 --> Language Class Initialized
INFO - 2026-07-03 07:17:13 --> Language Class Initialized
INFO - 2026-07-03 07:17:13 --> Config Class Initialized
INFO - 2026-07-03 07:17:13 --> Loader Class Initialized
INFO - 2026-07-03 07:17:13 --> Helper loaded: url_helper
INFO - 2026-07-03 07:17:13 --> Helper loaded: form_helper
INFO - 2026-07-03 07:17:13 --> Helper loaded: html_helper
INFO - 2026-07-03 07:17:13 --> Helper loaded: file_helper
INFO - 2026-07-03 07:17:13 --> Helper loaded: email_helper
INFO - 2026-07-03 07:17:13 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:17:13 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:17:13 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:17:13 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:17:13 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:17:13 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:17:13 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:17:13 --> Database Driver Class Initialized
INFO - 2026-07-03 07:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:17:15 --> Upload Class Initialized
DEBUG - 2026-07-03 07:17:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:17:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:17:15 --> Encryption Class Initialized
INFO - 2026-07-03 07:17:15 --> Form Validation Class Initialized
INFO - 2026-07-03 07:17:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:17:15 --> Pagination Class Initialized
INFO - 2026-07-03 07:17:15 --> Email Class Initialized
INFO - 2026-07-03 07:17:15 --> Controller Class Initialized
DEBUG - 2026-07-03 07:17:15 --> Cart MX_Controller Initialized
INFO - 2026-07-03 07:17:15 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:17:15 --> Model "Auth_model" initialized
INFO - 2026-07-03 07:17:15 --> Model "Cart_model" initialized
INFO - 2026-07-03 07:17:15 --> Model "Common_model" initialized
INFO - 2026-07-03 07:17:15 --> Model "Order_model" initialized
INFO - 2026-07-03 07:17:15 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 07:17:15 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 07:17:15 --> Model "Promocode_model" initialized
INFO - 2026-07-03 07:17:15 --> Final output sent to browser
DEBUG - 2026-07-03 07:17:15 --> Total execution time: 2.2355
INFO - 2026-07-03 07:17:17 --> Config Class Initialized
INFO - 2026-07-03 07:17:17 --> Hooks Class Initialized
DEBUG - 2026-07-03 07:17:17 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:17:17 --> Utf8 Class Initialized
INFO - 2026-07-03 07:17:17 --> URI Class Initialized
INFO - 2026-07-03 07:17:17 --> Router Class Initialized
INFO - 2026-07-03 07:17:17 --> Output Class Initialized
INFO - 2026-07-03 07:17:17 --> Security Class Initialized
DEBUG - 2026-07-03 07:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:17:17 --> CSRF cookie sent
INFO - 2026-07-03 07:17:17 --> Input Class Initialized
INFO - 2026-07-03 07:17:17 --> Language Class Initialized
INFO - 2026-07-03 07:17:17 --> Language Class Initialized
INFO - 2026-07-03 07:17:17 --> Config Class Initialized
INFO - 2026-07-03 07:17:17 --> Loader Class Initialized
INFO - 2026-07-03 07:17:17 --> Helper loaded: url_helper
INFO - 2026-07-03 07:17:17 --> Helper loaded: form_helper
INFO - 2026-07-03 07:17:17 --> Helper loaded: html_helper
INFO - 2026-07-03 07:17:17 --> Helper loaded: file_helper
INFO - 2026-07-03 07:17:17 --> Helper loaded: email_helper
INFO - 2026-07-03 07:17:17 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:17:17 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:17:17 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:17:17 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:17:17 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:17:17 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:17:17 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:17:17 --> Database Driver Class Initialized
INFO - 2026-07-03 07:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:17:19 --> Upload Class Initialized
DEBUG - 2026-07-03 07:17:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:17:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:17:19 --> Encryption Class Initialized
INFO - 2026-07-03 07:17:19 --> Form Validation Class Initialized
INFO - 2026-07-03 07:17:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:17:19 --> Pagination Class Initialized
INFO - 2026-07-03 07:17:19 --> Email Class Initialized
INFO - 2026-07-03 07:17:19 --> Controller Class Initialized
DEBUG - 2026-07-03 07:17:19 --> Cart MX_Controller Initialized
INFO - 2026-07-03 07:17:19 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:17:19 --> Model "Auth_model" initialized
INFO - 2026-07-03 07:17:19 --> Model "Cart_model" initialized
INFO - 2026-07-03 07:17:19 --> Model "Common_model" initialized
INFO - 2026-07-03 07:17:19 --> Model "Order_model" initialized
INFO - 2026-07-03 07:17:19 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 07:17:19 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 07:17:19 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 07:17:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 07:17:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-07-03 07:17:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-07-03 07:17:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 07:17:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 07:17:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/view_card.php
INFO - 2026-07-03 07:17:22 --> Final output sent to browser
DEBUG - 2026-07-03 07:17:22 --> Total execution time: 4.6884
INFO - 2026-07-03 07:17:22 --> Config Class Initialized
INFO - 2026-07-03 07:17:22 --> Hooks Class Initialized
DEBUG - 2026-07-03 07:17:22 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:17:22 --> Utf8 Class Initialized
INFO - 2026-07-03 07:17:22 --> URI Class Initialized
INFO - 2026-07-03 07:17:22 --> Router Class Initialized
INFO - 2026-07-03 07:17:22 --> Output Class Initialized
INFO - 2026-07-03 07:17:22 --> Security Class Initialized
DEBUG - 2026-07-03 07:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:17:22 --> CSRF cookie sent
INFO - 2026-07-03 07:17:22 --> Input Class Initialized
INFO - 2026-07-03 07:17:22 --> Language Class Initialized
INFO - 2026-07-03 07:17:22 --> Language Class Initialized
INFO - 2026-07-03 07:17:22 --> Config Class Initialized
INFO - 2026-07-03 07:17:22 --> Loader Class Initialized
INFO - 2026-07-03 07:17:22 --> Helper loaded: url_helper
INFO - 2026-07-03 07:17:22 --> Helper loaded: form_helper
INFO - 2026-07-03 07:17:22 --> Helper loaded: html_helper
INFO - 2026-07-03 07:17:22 --> Helper loaded: file_helper
INFO - 2026-07-03 07:17:22 --> Helper loaded: email_helper
INFO - 2026-07-03 07:17:22 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:17:22 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:17:22 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:17:22 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:17:22 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:17:22 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:17:22 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:17:22 --> Database Driver Class Initialized
INFO - 2026-07-03 07:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:17:24 --> Upload Class Initialized
DEBUG - 2026-07-03 07:17:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:17:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:17:24 --> Encryption Class Initialized
INFO - 2026-07-03 07:17:24 --> Form Validation Class Initialized
INFO - 2026-07-03 07:17:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:17:24 --> Pagination Class Initialized
INFO - 2026-07-03 07:17:24 --> Email Class Initialized
INFO - 2026-07-03 07:17:24 --> Controller Class Initialized
DEBUG - 2026-07-03 07:17:24 --> Cart MX_Controller Initialized
INFO - 2026-07-03 07:17:24 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:17:24 --> Model "Auth_model" initialized
INFO - 2026-07-03 07:17:24 --> Model "Cart_model" initialized
INFO - 2026-07-03 07:17:24 --> Model "Common_model" initialized
INFO - 2026-07-03 07:17:24 --> Model "Order_model" initialized
INFO - 2026-07-03 07:17:24 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 07:17:24 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 07:17:24 --> Model "Promocode_model" initialized
INFO - 2026-07-03 07:17:25 --> Final output sent to browser
DEBUG - 2026-07-03 07:17:25 --> Total execution time: 2.3782
INFO - 2026-07-03 07:17:33 --> Config Class Initialized
INFO - 2026-07-03 07:17:33 --> Hooks Class Initialized
DEBUG - 2026-07-03 07:17:33 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:17:33 --> Utf8 Class Initialized
INFO - 2026-07-03 07:17:33 --> URI Class Initialized
INFO - 2026-07-03 07:17:33 --> Router Class Initialized
INFO - 2026-07-03 07:17:33 --> Output Class Initialized
INFO - 2026-07-03 07:17:33 --> Security Class Initialized
DEBUG - 2026-07-03 07:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:17:33 --> CSRF cookie sent
INFO - 2026-07-03 07:17:33 --> Input Class Initialized
INFO - 2026-07-03 07:17:33 --> Language Class Initialized
INFO - 2026-07-03 07:17:33 --> Language Class Initialized
INFO - 2026-07-03 07:17:33 --> Config Class Initialized
INFO - 2026-07-03 07:17:33 --> Loader Class Initialized
INFO - 2026-07-03 07:17:33 --> Helper loaded: url_helper
INFO - 2026-07-03 07:17:33 --> Helper loaded: form_helper
INFO - 2026-07-03 07:17:33 --> Helper loaded: html_helper
INFO - 2026-07-03 07:17:33 --> Helper loaded: file_helper
INFO - 2026-07-03 07:17:33 --> Helper loaded: email_helper
INFO - 2026-07-03 07:17:33 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:17:33 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:17:33 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:17:33 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:17:33 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:17:33 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:17:33 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:17:33 --> Database Driver Class Initialized
INFO - 2026-07-03 07:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:17:35 --> Upload Class Initialized
DEBUG - 2026-07-03 07:17:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:17:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:17:35 --> Encryption Class Initialized
INFO - 2026-07-03 07:17:35 --> Form Validation Class Initialized
INFO - 2026-07-03 07:17:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:17:35 --> Pagination Class Initialized
INFO - 2026-07-03 07:17:36 --> Email Class Initialized
INFO - 2026-07-03 07:17:36 --> Controller Class Initialized
DEBUG - 2026-07-03 07:17:36 --> Cart MX_Controller Initialized
INFO - 2026-07-03 07:17:36 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:17:36 --> Model "Auth_model" initialized
INFO - 2026-07-03 07:17:36 --> Model "Cart_model" initialized
INFO - 2026-07-03 07:17:36 --> Model "Common_model" initialized
INFO - 2026-07-03 07:17:36 --> Model "Order_model" initialized
INFO - 2026-07-03 07:17:36 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 07:17:36 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 07:17:36 --> Model "Promocode_model" initialized
INFO - 2026-07-03 07:17:45 --> Config Class Initialized
INFO - 2026-07-03 07:17:45 --> Hooks Class Initialized
DEBUG - 2026-07-03 07:17:45 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:17:45 --> Utf8 Class Initialized
INFO - 2026-07-03 07:17:45 --> URI Class Initialized
INFO - 2026-07-03 07:17:45 --> Router Class Initialized
INFO - 2026-07-03 07:17:45 --> Output Class Initialized
INFO - 2026-07-03 07:17:45 --> Security Class Initialized
DEBUG - 2026-07-03 07:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:17:45 --> CSRF cookie sent
INFO - 2026-07-03 07:17:45 --> Input Class Initialized
INFO - 2026-07-03 07:17:45 --> Language Class Initialized
INFO - 2026-07-03 07:17:45 --> Language Class Initialized
INFO - 2026-07-03 07:17:45 --> Config Class Initialized
INFO - 2026-07-03 07:17:45 --> Loader Class Initialized
INFO - 2026-07-03 07:17:45 --> Helper loaded: url_helper
INFO - 2026-07-03 07:17:45 --> Helper loaded: form_helper
INFO - 2026-07-03 07:17:45 --> Helper loaded: html_helper
INFO - 2026-07-03 07:17:45 --> Helper loaded: file_helper
INFO - 2026-07-03 07:17:45 --> Helper loaded: email_helper
INFO - 2026-07-03 07:17:45 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:17:45 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:17:45 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:17:45 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:17:45 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:17:45 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:17:45 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:17:45 --> Database Driver Class Initialized
INFO - 2026-07-03 07:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:17:46 --> Upload Class Initialized
DEBUG - 2026-07-03 07:17:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:17:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:17:46 --> Encryption Class Initialized
INFO - 2026-07-03 07:17:46 --> Form Validation Class Initialized
INFO - 2026-07-03 07:17:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:17:46 --> Pagination Class Initialized
INFO - 2026-07-03 07:17:46 --> Email Class Initialized
INFO - 2026-07-03 07:17:46 --> Controller Class Initialized
DEBUG - 2026-07-03 07:17:46 --> Cart MX_Controller Initialized
INFO - 2026-07-03 07:17:46 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:17:46 --> Model "Auth_model" initialized
INFO - 2026-07-03 07:17:46 --> Model "Cart_model" initialized
INFO - 2026-07-03 07:17:46 --> Model "Common_model" initialized
INFO - 2026-07-03 07:17:46 --> Model "Order_model" initialized
INFO - 2026-07-03 07:17:46 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 07:17:46 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 07:17:46 --> Model "Promocode_model" initialized
INFO - 2026-07-03 07:17:47 --> Final output sent to browser
DEBUG - 2026-07-03 07:17:47 --> Total execution time: 2.1813
INFO - 2026-07-03 07:17:47 --> Config Class Initialized
INFO - 2026-07-03 07:17:47 --> Hooks Class Initialized
DEBUG - 2026-07-03 07:17:47 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:17:47 --> Utf8 Class Initialized
INFO - 2026-07-03 07:17:47 --> URI Class Initialized
INFO - 2026-07-03 07:17:47 --> Router Class Initialized
INFO - 2026-07-03 07:17:47 --> Output Class Initialized
INFO - 2026-07-03 07:17:47 --> Security Class Initialized
DEBUG - 2026-07-03 07:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:17:47 --> CSRF cookie sent
INFO - 2026-07-03 07:17:47 --> Input Class Initialized
INFO - 2026-07-03 07:17:47 --> Language Class Initialized
INFO - 2026-07-03 07:17:47 --> Language Class Initialized
INFO - 2026-07-03 07:17:47 --> Config Class Initialized
INFO - 2026-07-03 07:17:47 --> Loader Class Initialized
INFO - 2026-07-03 07:17:47 --> Helper loaded: url_helper
INFO - 2026-07-03 07:17:47 --> Helper loaded: form_helper
INFO - 2026-07-03 07:17:47 --> Helper loaded: html_helper
INFO - 2026-07-03 07:17:47 --> Helper loaded: file_helper
INFO - 2026-07-03 07:17:47 --> Helper loaded: email_helper
INFO - 2026-07-03 07:17:47 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:17:47 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:17:47 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:17:47 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:17:47 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:17:47 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:17:47 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:17:47 --> Database Driver Class Initialized
INFO - 2026-07-03 07:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:17:49 --> Upload Class Initialized
DEBUG - 2026-07-03 07:17:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:17:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:17:49 --> Encryption Class Initialized
INFO - 2026-07-03 07:17:49 --> Form Validation Class Initialized
INFO - 2026-07-03 07:17:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:17:49 --> Pagination Class Initialized
INFO - 2026-07-03 07:17:49 --> Email Class Initialized
INFO - 2026-07-03 07:17:49 --> Controller Class Initialized
DEBUG - 2026-07-03 07:17:49 --> Cart MX_Controller Initialized
INFO - 2026-07-03 07:17:49 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:17:49 --> Model "Auth_model" initialized
INFO - 2026-07-03 07:17:49 --> Model "Cart_model" initialized
INFO - 2026-07-03 07:17:49 --> Model "Common_model" initialized
INFO - 2026-07-03 07:17:49 --> Model "Order_model" initialized
INFO - 2026-07-03 07:17:49 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 07:17:49 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 07:17:49 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 07:17:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 07:17:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-07-03 07:17:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-07-03 07:17:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 07:17:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 07:17:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/view_card.php
INFO - 2026-07-03 07:17:52 --> Final output sent to browser
DEBUG - 2026-07-03 07:17:52 --> Total execution time: 4.8955
INFO - 2026-07-03 07:17:52 --> Config Class Initialized
INFO - 2026-07-03 07:17:52 --> Hooks Class Initialized
DEBUG - 2026-07-03 07:17:52 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:17:52 --> Utf8 Class Initialized
INFO - 2026-07-03 07:17:52 --> URI Class Initialized
INFO - 2026-07-03 07:17:52 --> Router Class Initialized
INFO - 2026-07-03 07:17:52 --> Output Class Initialized
INFO - 2026-07-03 07:17:52 --> Security Class Initialized
DEBUG - 2026-07-03 07:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:17:52 --> CSRF cookie sent
INFO - 2026-07-03 07:17:52 --> Input Class Initialized
INFO - 2026-07-03 07:17:52 --> Language Class Initialized
INFO - 2026-07-03 07:17:52 --> Language Class Initialized
INFO - 2026-07-03 07:17:52 --> Config Class Initialized
INFO - 2026-07-03 07:17:52 --> Loader Class Initialized
INFO - 2026-07-03 07:17:52 --> Helper loaded: url_helper
INFO - 2026-07-03 07:17:52 --> Helper loaded: form_helper
INFO - 2026-07-03 07:17:52 --> Helper loaded: html_helper
INFO - 2026-07-03 07:17:52 --> Helper loaded: file_helper
INFO - 2026-07-03 07:17:52 --> Helper loaded: email_helper
INFO - 2026-07-03 07:17:52 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:17:52 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:17:52 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:17:52 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:17:52 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:17:52 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:17:52 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:17:52 --> Database Driver Class Initialized
INFO - 2026-07-03 07:17:53 --> Config Class Initialized
INFO - 2026-07-03 07:17:53 --> Hooks Class Initialized
DEBUG - 2026-07-03 07:17:53 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:17:53 --> Utf8 Class Initialized
INFO - 2026-07-03 07:17:53 --> URI Class Initialized
INFO - 2026-07-03 07:17:53 --> Router Class Initialized
INFO - 2026-07-03 07:17:53 --> Output Class Initialized
INFO - 2026-07-03 07:17:53 --> Security Class Initialized
DEBUG - 2026-07-03 07:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:17:53 --> CSRF cookie sent
INFO - 2026-07-03 07:17:53 --> Input Class Initialized
INFO - 2026-07-03 07:17:53 --> Language Class Initialized
INFO - 2026-07-03 07:17:53 --> Language Class Initialized
INFO - 2026-07-03 07:17:53 --> Config Class Initialized
INFO - 2026-07-03 07:17:53 --> Loader Class Initialized
INFO - 2026-07-03 07:17:53 --> Helper loaded: url_helper
INFO - 2026-07-03 07:17:53 --> Helper loaded: form_helper
INFO - 2026-07-03 07:17:53 --> Helper loaded: html_helper
INFO - 2026-07-03 07:17:53 --> Helper loaded: file_helper
INFO - 2026-07-03 07:17:53 --> Helper loaded: email_helper
INFO - 2026-07-03 07:17:53 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:17:53 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:17:53 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:17:53 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:17:53 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:17:53 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:17:53 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:17:53 --> Database Driver Class Initialized
INFO - 2026-07-03 07:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:17:54 --> Upload Class Initialized
DEBUG - 2026-07-03 07:17:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:17:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:17:54 --> Encryption Class Initialized
INFO - 2026-07-03 07:17:54 --> Form Validation Class Initialized
INFO - 2026-07-03 07:17:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:17:54 --> Pagination Class Initialized
INFO - 2026-07-03 07:17:54 --> Email Class Initialized
INFO - 2026-07-03 07:17:54 --> Controller Class Initialized
DEBUG - 2026-07-03 07:17:54 --> Cart MX_Controller Initialized
INFO - 2026-07-03 07:17:54 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:17:54 --> Model "Auth_model" initialized
INFO - 2026-07-03 07:17:54 --> Model "Cart_model" initialized
INFO - 2026-07-03 07:17:54 --> Model "Common_model" initialized
INFO - 2026-07-03 07:17:54 --> Model "Order_model" initialized
INFO - 2026-07-03 07:17:54 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 07:17:54 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 07:17:54 --> Model "Promocode_model" initialized
INFO - 2026-07-03 07:17:54 --> Final output sent to browser
DEBUG - 2026-07-03 07:17:54 --> Total execution time: 2.0280
INFO - 2026-07-03 07:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:17:55 --> Upload Class Initialized
DEBUG - 2026-07-03 07:17:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:17:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:17:55 --> Encryption Class Initialized
INFO - 2026-07-03 07:17:55 --> Form Validation Class Initialized
INFO - 2026-07-03 07:17:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:17:55 --> Pagination Class Initialized
INFO - 2026-07-03 07:17:55 --> Email Class Initialized
INFO - 2026-07-03 07:17:55 --> Controller Class Initialized
DEBUG - 2026-07-03 07:17:55 --> Auth MX_Controller Initialized
INFO - 2026-07-03 07:17:55 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:17:55 --> Model "Auth_model" initialized
INFO - 2026-07-03 07:17:55 --> Model "Cart_model" initialized
INFO - 2026-07-03 07:17:55 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-03 07:17:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 07:17:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 07:17:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 07:17:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-07-03 07:17:55 --> Final output sent to browser
DEBUG - 2026-07-03 07:17:55 --> Total execution time: 1.9051
INFO - 2026-07-03 07:17:55 --> Config Class Initialized
INFO - 2026-07-03 07:17:55 --> Hooks Class Initialized
DEBUG - 2026-07-03 07:17:55 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:17:55 --> Utf8 Class Initialized
INFO - 2026-07-03 07:17:55 --> URI Class Initialized
INFO - 2026-07-03 07:17:55 --> Router Class Initialized
INFO - 2026-07-03 07:17:55 --> Output Class Initialized
INFO - 2026-07-03 07:17:55 --> Security Class Initialized
DEBUG - 2026-07-03 07:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:17:55 --> CSRF cookie sent
INFO - 2026-07-03 07:17:55 --> Input Class Initialized
INFO - 2026-07-03 07:17:55 --> Language Class Initialized
INFO - 2026-07-03 07:17:55 --> Language Class Initialized
INFO - 2026-07-03 07:17:55 --> Config Class Initialized
INFO - 2026-07-03 07:17:55 --> Loader Class Initialized
INFO - 2026-07-03 07:17:55 --> Helper loaded: url_helper
INFO - 2026-07-03 07:17:55 --> Helper loaded: form_helper
INFO - 2026-07-03 07:17:55 --> Helper loaded: html_helper
INFO - 2026-07-03 07:17:55 --> Helper loaded: file_helper
INFO - 2026-07-03 07:17:55 --> Helper loaded: email_helper
INFO - 2026-07-03 07:17:55 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:17:55 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:17:55 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:17:55 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:17:55 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:17:55 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:17:55 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:17:55 --> Database Driver Class Initialized
INFO - 2026-07-03 07:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:17:57 --> Upload Class Initialized
DEBUG - 2026-07-03 07:17:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:17:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:17:57 --> Encryption Class Initialized
INFO - 2026-07-03 07:17:57 --> Form Validation Class Initialized
INFO - 2026-07-03 07:17:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:17:57 --> Pagination Class Initialized
INFO - 2026-07-03 07:17:57 --> Email Class Initialized
INFO - 2026-07-03 07:17:57 --> Controller Class Initialized
DEBUG - 2026-07-03 07:17:57 --> Cart MX_Controller Initialized
INFO - 2026-07-03 07:17:57 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:17:57 --> Model "Auth_model" initialized
INFO - 2026-07-03 07:17:57 --> Model "Cart_model" initialized
INFO - 2026-07-03 07:17:57 --> Model "Common_model" initialized
INFO - 2026-07-03 07:17:57 --> Model "Order_model" initialized
INFO - 2026-07-03 07:17:57 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 07:17:57 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 07:17:57 --> Model "Promocode_model" initialized
INFO - 2026-07-03 07:17:57 --> Final output sent to browser
DEBUG - 2026-07-03 07:17:57 --> Total execution time: 1.9500
INFO - 2026-07-03 07:18:18 --> Config Class Initialized
INFO - 2026-07-03 07:18:18 --> Hooks Class Initialized
DEBUG - 2026-07-03 07:18:18 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:18:18 --> Utf8 Class Initialized
INFO - 2026-07-03 07:18:18 --> URI Class Initialized
INFO - 2026-07-03 07:18:18 --> Router Class Initialized
INFO - 2026-07-03 07:18:18 --> Output Class Initialized
INFO - 2026-07-03 07:18:18 --> Security Class Initialized
DEBUG - 2026-07-03 07:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:18:18 --> CSRF cookie sent
INFO - 2026-07-03 07:18:18 --> Input Class Initialized
INFO - 2026-07-03 07:18:18 --> Language Class Initialized
INFO - 2026-07-03 07:18:18 --> Language Class Initialized
INFO - 2026-07-03 07:18:18 --> Config Class Initialized
INFO - 2026-07-03 07:18:18 --> Loader Class Initialized
INFO - 2026-07-03 07:18:18 --> Helper loaded: url_helper
INFO - 2026-07-03 07:18:18 --> Helper loaded: form_helper
INFO - 2026-07-03 07:18:18 --> Helper loaded: html_helper
INFO - 2026-07-03 07:18:18 --> Helper loaded: file_helper
INFO - 2026-07-03 07:18:18 --> Helper loaded: email_helper
INFO - 2026-07-03 07:18:18 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:18:18 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:18:18 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:18:18 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:18:18 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:18:18 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:18:18 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:18:18 --> Database Driver Class Initialized
INFO - 2026-07-03 07:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:18:20 --> Upload Class Initialized
DEBUG - 2026-07-03 07:18:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:18:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:18:20 --> Encryption Class Initialized
INFO - 2026-07-03 07:18:20 --> Form Validation Class Initialized
INFO - 2026-07-03 07:18:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:18:20 --> Pagination Class Initialized
INFO - 2026-07-03 07:18:20 --> Email Class Initialized
INFO - 2026-07-03 07:18:20 --> Controller Class Initialized
DEBUG - 2026-07-03 07:18:20 --> Cart MX_Controller Initialized
INFO - 2026-07-03 07:18:20 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:18:20 --> Model "Auth_model" initialized
INFO - 2026-07-03 07:18:20 --> Model "Cart_model" initialized
INFO - 2026-07-03 07:18:20 --> Model "Common_model" initialized
INFO - 2026-07-03 07:18:20 --> Model "Order_model" initialized
INFO - 2026-07-03 07:18:20 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 07:18:20 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 07:18:20 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 07:18:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 07:18:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-07-03 07:18:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-07-03 07:18:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 07:18:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 07:18:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/cart_services.php
INFO - 2026-07-03 07:18:22 --> Final output sent to browser
DEBUG - 2026-07-03 07:18:22 --> Total execution time: 3.5609
INFO - 2026-07-03 07:18:22 --> Config Class Initialized
INFO - 2026-07-03 07:18:22 --> Hooks Class Initialized
DEBUG - 2026-07-03 07:18:22 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:18:22 --> Utf8 Class Initialized
INFO - 2026-07-03 07:18:22 --> URI Class Initialized
INFO - 2026-07-03 07:18:22 --> Router Class Initialized
INFO - 2026-07-03 07:18:22 --> Output Class Initialized
INFO - 2026-07-03 07:18:22 --> Security Class Initialized
DEBUG - 2026-07-03 07:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:18:22 --> CSRF cookie sent
INFO - 2026-07-03 07:18:22 --> Input Class Initialized
INFO - 2026-07-03 07:18:22 --> Language Class Initialized
INFO - 2026-07-03 07:18:22 --> Language Class Initialized
INFO - 2026-07-03 07:18:22 --> Config Class Initialized
INFO - 2026-07-03 07:18:22 --> Loader Class Initialized
INFO - 2026-07-03 07:18:22 --> Helper loaded: url_helper
INFO - 2026-07-03 07:18:22 --> Helper loaded: form_helper
INFO - 2026-07-03 07:18:22 --> Helper loaded: html_helper
INFO - 2026-07-03 07:18:22 --> Helper loaded: file_helper
INFO - 2026-07-03 07:18:22 --> Helper loaded: email_helper
INFO - 2026-07-03 07:18:22 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:18:22 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:18:22 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:18:22 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:18:22 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:18:22 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:18:22 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:18:22 --> Database Driver Class Initialized
INFO - 2026-07-03 07:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:18:24 --> Upload Class Initialized
DEBUG - 2026-07-03 07:18:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:18:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:18:24 --> Encryption Class Initialized
INFO - 2026-07-03 07:18:24 --> Form Validation Class Initialized
INFO - 2026-07-03 07:18:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:18:24 --> Pagination Class Initialized
INFO - 2026-07-03 07:18:24 --> Email Class Initialized
INFO - 2026-07-03 07:18:24 --> Controller Class Initialized
DEBUG - 2026-07-03 07:18:24 --> Cart MX_Controller Initialized
INFO - 2026-07-03 07:18:24 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:18:24 --> Model "Auth_model" initialized
INFO - 2026-07-03 07:18:24 --> Model "Cart_model" initialized
INFO - 2026-07-03 07:18:24 --> Model "Common_model" initialized
INFO - 2026-07-03 07:18:24 --> Model "Order_model" initialized
INFO - 2026-07-03 07:18:24 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 07:18:24 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 07:18:24 --> Model "Promocode_model" initialized
INFO - 2026-07-03 07:18:24 --> Final output sent to browser
DEBUG - 2026-07-03 07:18:24 --> Total execution time: 2.4117
INFO - 2026-07-03 07:21:40 --> Config Class Initialized
INFO - 2026-07-03 07:21:40 --> Hooks Class Initialized
DEBUG - 2026-07-03 07:21:40 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:21:40 --> Utf8 Class Initialized
INFO - 2026-07-03 07:21:40 --> URI Class Initialized
INFO - 2026-07-03 07:21:40 --> Router Class Initialized
INFO - 2026-07-03 07:21:40 --> Output Class Initialized
INFO - 2026-07-03 07:21:40 --> Security Class Initialized
DEBUG - 2026-07-03 07:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:21:40 --> CSRF cookie sent
INFO - 2026-07-03 07:21:40 --> Input Class Initialized
INFO - 2026-07-03 07:21:40 --> Language Class Initialized
INFO - 2026-07-03 07:21:40 --> Language Class Initialized
INFO - 2026-07-03 07:21:40 --> Config Class Initialized
INFO - 2026-07-03 07:21:40 --> Loader Class Initialized
INFO - 2026-07-03 07:21:40 --> Helper loaded: url_helper
INFO - 2026-07-03 07:21:40 --> Helper loaded: form_helper
INFO - 2026-07-03 07:21:40 --> Helper loaded: html_helper
INFO - 2026-07-03 07:21:40 --> Helper loaded: file_helper
INFO - 2026-07-03 07:21:40 --> Helper loaded: email_helper
INFO - 2026-07-03 07:21:40 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:21:40 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:21:40 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:21:40 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:21:40 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:21:40 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:21:40 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:21:40 --> Database Driver Class Initialized
INFO - 2026-07-03 07:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:21:42 --> Upload Class Initialized
DEBUG - 2026-07-03 07:21:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:21:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:21:42 --> Encryption Class Initialized
INFO - 2026-07-03 07:21:42 --> Form Validation Class Initialized
INFO - 2026-07-03 07:21:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:21:42 --> Pagination Class Initialized
INFO - 2026-07-03 07:21:42 --> Email Class Initialized
INFO - 2026-07-03 07:21:42 --> Controller Class Initialized
DEBUG - 2026-07-03 07:21:42 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 07:21:42 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:21:42 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 07:21:42 --> Config Class Initialized
INFO - 2026-07-03 07:21:42 --> Hooks Class Initialized
DEBUG - 2026-07-03 07:21:42 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:21:42 --> Utf8 Class Initialized
INFO - 2026-07-03 07:21:42 --> URI Class Initialized
INFO - 2026-07-03 07:21:42 --> Router Class Initialized
INFO - 2026-07-03 07:21:42 --> Output Class Initialized
INFO - 2026-07-03 07:21:42 --> Security Class Initialized
DEBUG - 2026-07-03 07:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:21:42 --> CSRF cookie sent
INFO - 2026-07-03 07:21:42 --> Input Class Initialized
INFO - 2026-07-03 07:21:42 --> Language Class Initialized
INFO - 2026-07-03 07:21:42 --> Language Class Initialized
INFO - 2026-07-03 07:21:42 --> Config Class Initialized
INFO - 2026-07-03 07:21:42 --> Loader Class Initialized
INFO - 2026-07-03 07:21:42 --> Helper loaded: url_helper
INFO - 2026-07-03 07:21:42 --> Helper loaded: form_helper
INFO - 2026-07-03 07:21:42 --> Helper loaded: html_helper
INFO - 2026-07-03 07:21:42 --> Helper loaded: file_helper
INFO - 2026-07-03 07:21:42 --> Helper loaded: email_helper
INFO - 2026-07-03 07:21:42 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:21:42 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:21:42 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:21:42 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:21:42 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:21:42 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:21:42 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:21:42 --> Database Driver Class Initialized
INFO - 2026-07-03 07:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:21:44 --> Upload Class Initialized
DEBUG - 2026-07-03 07:21:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:21:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:21:44 --> Encryption Class Initialized
INFO - 2026-07-03 07:21:44 --> Form Validation Class Initialized
INFO - 2026-07-03 07:21:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:21:44 --> Pagination Class Initialized
INFO - 2026-07-03 07:21:44 --> Email Class Initialized
INFO - 2026-07-03 07:21:44 --> Controller Class Initialized
DEBUG - 2026-07-03 07:21:44 --> Authenticate MX_Controller Initialized
INFO - 2026-07-03 07:21:44 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:21:44 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 07:21:44 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-03 07:21:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 07:21:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 07:21:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-07-03 07:21:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-03 07:21:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 07:21:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-07-03 07:21:44 --> Final output sent to browser
DEBUG - 2026-07-03 07:21:44 --> Total execution time: 2.2980
INFO - 2026-07-03 07:21:52 --> Config Class Initialized
INFO - 2026-07-03 07:21:52 --> Hooks Class Initialized
DEBUG - 2026-07-03 07:21:52 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:21:52 --> Utf8 Class Initialized
INFO - 2026-07-03 07:21:52 --> URI Class Initialized
INFO - 2026-07-03 07:21:52 --> Router Class Initialized
INFO - 2026-07-03 07:21:52 --> Output Class Initialized
INFO - 2026-07-03 07:21:52 --> Security Class Initialized
DEBUG - 2026-07-03 07:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:21:52 --> CSRF cookie sent
INFO - 2026-07-03 07:21:52 --> CSRF token verified
INFO - 2026-07-03 07:21:52 --> Input Class Initialized
INFO - 2026-07-03 07:21:52 --> Language Class Initialized
INFO - 2026-07-03 07:21:52 --> Language Class Initialized
INFO - 2026-07-03 07:21:52 --> Config Class Initialized
INFO - 2026-07-03 07:21:52 --> Loader Class Initialized
INFO - 2026-07-03 07:21:52 --> Helper loaded: url_helper
INFO - 2026-07-03 07:21:52 --> Helper loaded: form_helper
INFO - 2026-07-03 07:21:52 --> Helper loaded: html_helper
INFO - 2026-07-03 07:21:52 --> Helper loaded: file_helper
INFO - 2026-07-03 07:21:52 --> Helper loaded: email_helper
INFO - 2026-07-03 07:21:52 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:21:52 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:21:52 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:21:52 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:21:52 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:21:52 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:21:52 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:21:52 --> Database Driver Class Initialized
INFO - 2026-07-03 07:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:21:54 --> Upload Class Initialized
DEBUG - 2026-07-03 07:21:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:21:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:21:54 --> Encryption Class Initialized
INFO - 2026-07-03 07:21:54 --> Form Validation Class Initialized
INFO - 2026-07-03 07:21:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:21:54 --> Pagination Class Initialized
INFO - 2026-07-03 07:21:54 --> Email Class Initialized
INFO - 2026-07-03 07:21:54 --> Controller Class Initialized
DEBUG - 2026-07-03 07:21:54 --> Authenticate MX_Controller Initialized
INFO - 2026-07-03 07:21:54 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:21:54 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 07:21:54 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 07:21:57 --> Config Class Initialized
INFO - 2026-07-03 07:21:57 --> Hooks Class Initialized
DEBUG - 2026-07-03 07:21:57 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:21:57 --> Utf8 Class Initialized
INFO - 2026-07-03 07:21:57 --> URI Class Initialized
INFO - 2026-07-03 07:21:57 --> Router Class Initialized
INFO - 2026-07-03 07:21:57 --> Output Class Initialized
INFO - 2026-07-03 07:21:57 --> Security Class Initialized
DEBUG - 2026-07-03 07:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:21:57 --> CSRF cookie sent
INFO - 2026-07-03 07:21:57 --> Input Class Initialized
INFO - 2026-07-03 07:21:57 --> Language Class Initialized
INFO - 2026-07-03 07:21:57 --> Language Class Initialized
INFO - 2026-07-03 07:21:57 --> Config Class Initialized
INFO - 2026-07-03 07:21:57 --> Loader Class Initialized
INFO - 2026-07-03 07:21:57 --> Helper loaded: url_helper
INFO - 2026-07-03 07:21:57 --> Helper loaded: form_helper
INFO - 2026-07-03 07:21:57 --> Helper loaded: html_helper
INFO - 2026-07-03 07:21:57 --> Helper loaded: file_helper
INFO - 2026-07-03 07:21:57 --> Helper loaded: email_helper
INFO - 2026-07-03 07:21:57 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:21:57 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:21:57 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:21:57 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:21:57 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:21:57 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:21:57 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:21:57 --> Database Driver Class Initialized
INFO - 2026-07-03 07:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:21:59 --> Upload Class Initialized
DEBUG - 2026-07-03 07:21:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:21:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:21:59 --> Encryption Class Initialized
INFO - 2026-07-03 07:21:59 --> Form Validation Class Initialized
INFO - 2026-07-03 07:21:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:21:59 --> Pagination Class Initialized
INFO - 2026-07-03 07:21:59 --> Email Class Initialized
INFO - 2026-07-03 07:21:59 --> Controller Class Initialized
DEBUG - 2026-07-03 07:21:59 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 07:21:59 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:21:59 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 07:21:59 --> Model "Dashboard_model" initialized
DEBUG - 2026-07-03 07:21:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 07:21:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 07:21:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 07:21:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-03 07:21:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 07:21:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/dashboard_index.php
INFO - 2026-07-03 07:21:59 --> Final output sent to browser
DEBUG - 2026-07-03 07:21:59 --> Total execution time: 2.1110
INFO - 2026-07-03 07:21:59 --> Config Class Initialized
INFO - 2026-07-03 07:21:59 --> Hooks Class Initialized
INFO - 2026-07-03 07:21:59 --> Config Class Initialized
INFO - 2026-07-03 07:21:59 --> Hooks Class Initialized
INFO - 2026-07-03 07:21:59 --> Config Class Initialized
INFO - 2026-07-03 07:21:59 --> Hooks Class Initialized
DEBUG - 2026-07-03 07:21:59 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:21:59 --> Utf8 Class Initialized
DEBUG - 2026-07-03 07:21:59 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:21:59 --> Utf8 Class Initialized
INFO - 2026-07-03 07:21:59 --> URI Class Initialized
DEBUG - 2026-07-03 07:21:59 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:21:59 --> Utf8 Class Initialized
INFO - 2026-07-03 07:21:59 --> URI Class Initialized
INFO - 2026-07-03 07:21:59 --> URI Class Initialized
INFO - 2026-07-03 07:21:59 --> Router Class Initialized
INFO - 2026-07-03 07:21:59 --> Router Class Initialized
INFO - 2026-07-03 07:21:59 --> Output Class Initialized
INFO - 2026-07-03 07:21:59 --> Router Class Initialized
INFO - 2026-07-03 07:21:59 --> Output Class Initialized
INFO - 2026-07-03 07:21:59 --> Config Class Initialized
INFO - 2026-07-03 07:21:59 --> Hooks Class Initialized
INFO - 2026-07-03 07:21:59 --> Security Class Initialized
INFO - 2026-07-03 07:21:59 --> Output Class Initialized
INFO - 2026-07-03 07:21:59 --> Security Class Initialized
DEBUG - 2026-07-03 07:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:21:59 --> Security Class Initialized
INFO - 2026-07-03 07:21:59 --> Input Class Initialized
INFO - 2026-07-03 07:21:59 --> Language Class Initialized
DEBUG - 2026-07-03 07:21:59 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:21:59 --> Utf8 Class Initialized
DEBUG - 2026-07-03 07:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:21:59 --> Language Class Initialized
INFO - 2026-07-03 07:21:59 --> Config Class Initialized
INFO - 2026-07-03 07:21:59 --> Input Class Initialized
INFO - 2026-07-03 07:21:59 --> URI Class Initialized
INFO - 2026-07-03 07:21:59 --> Language Class Initialized
INFO - 2026-07-03 07:21:59 --> Language Class Initialized
INFO - 2026-07-03 07:21:59 --> Config Class Initialized
DEBUG - 2026-07-03 07:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:21:59 --> Input Class Initialized
INFO - 2026-07-03 07:21:59 --> Router Class Initialized
INFO - 2026-07-03 07:21:59 --> Language Class Initialized
INFO - 2026-07-03 07:21:59 --> Config Class Initialized
INFO - 2026-07-03 07:21:59 --> Hooks Class Initialized
INFO - 2026-07-03 07:21:59 --> Loader Class Initialized
INFO - 2026-07-03 07:21:59 --> Language Class Initialized
INFO - 2026-07-03 07:21:59 --> Config Class Initialized
INFO - 2026-07-03 07:21:59 --> Config Class Initialized
INFO - 2026-07-03 07:21:59 --> Hooks Class Initialized
INFO - 2026-07-03 07:21:59 --> Output Class Initialized
INFO - 2026-07-03 07:21:59 --> Helper loaded: url_helper
DEBUG - 2026-07-03 07:21:59 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:21:59 --> Utf8 Class Initialized
INFO - 2026-07-03 07:21:59 --> URI Class Initialized
DEBUG - 2026-07-03 07:21:59 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:21:59 --> Utf8 Class Initialized
INFO - 2026-07-03 07:21:59 --> Helper loaded: form_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: html_helper
INFO - 2026-07-03 07:21:59 --> URI Class Initialized
INFO - 2026-07-03 07:21:59 --> Router Class Initialized
INFO - 2026-07-03 07:21:59 --> Loader Class Initialized
INFO - 2026-07-03 07:21:59 --> Loader Class Initialized
INFO - 2026-07-03 07:21:59 --> Helper loaded: file_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: email_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: url_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: url_helper
INFO - 2026-07-03 07:21:59 --> Output Class Initialized
INFO - 2026-07-03 07:21:59 --> Router Class Initialized
INFO - 2026-07-03 07:21:59 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:21:59 --> Security Class Initialized
INFO - 2026-07-03 07:21:59 --> Helper loaded: form_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: form_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: html_helper
INFO - 2026-07-03 07:21:59 --> Security Class Initialized
DEBUG - 2026-07-03 07:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:21:59 --> Helper loaded: html_helper
INFO - 2026-07-03 07:21:59 --> Input Class Initialized
INFO - 2026-07-03 07:21:59 --> Helper loaded: file_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: email_helper
INFO - 2026-07-03 07:21:59 --> Language Class Initialized
INFO - 2026-07-03 07:21:59 --> Helper loaded: file_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: email_helper
DEBUG - 2026-07-03 07:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:21:59 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:21:59 --> Language Class Initialized
INFO - 2026-07-03 07:21:59 --> Config Class Initialized
INFO - 2026-07-03 07:21:59 --> Input Class Initialized
INFO - 2026-07-03 07:21:59 --> Language Class Initialized
INFO - 2026-07-03 07:21:59 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:21:59 --> Language Class Initialized
INFO - 2026-07-03 07:21:59 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:21:59 --> Config Class Initialized
INFO - 2026-07-03 07:21:59 --> Loader Class Initialized
INFO - 2026-07-03 07:21:59 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: url_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:21:59 --> Loader Class Initialized
INFO - 2026-07-03 07:21:59 --> Helper loaded: form_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: html_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: url_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:21:59 --> Output Class Initialized
INFO - 2026-07-03 07:21:59 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: file_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: email_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: form_helper
INFO - 2026-07-03 07:21:59 --> Security Class Initialized
INFO - 2026-07-03 07:21:59 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: html_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: entitlement_helper
DEBUG - 2026-07-03 07:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:21:59 --> Helper loaded: file_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: email_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:21:59 --> Input Class Initialized
INFO - 2026-07-03 07:21:59 --> Language Class Initialized
INFO - 2026-07-03 07:21:59 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:21:59 --> Language Class Initialized
INFO - 2026-07-03 07:21:59 --> Config Class Initialized
INFO - 2026-07-03 07:21:59 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:21:59 --> Database Driver Class Initialized
INFO - 2026-07-03 07:21:59 --> Database Driver Class Initialized
INFO - 2026-07-03 07:21:59 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:21:59 --> Database Driver Class Initialized
INFO - 2026-07-03 07:21:59 --> Loader Class Initialized
INFO - 2026-07-03 07:21:59 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: url_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: form_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: html_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: file_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: email_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:21:59 --> Database Driver Class Initialized
INFO - 2026-07-03 07:21:59 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:21:59 --> Database Driver Class Initialized
INFO - 2026-07-03 07:21:59 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:21:59 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:21:59 --> Database Driver Class Initialized
INFO - 2026-07-03 07:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:22:01 --> Upload Class Initialized
DEBUG - 2026-07-03 07:22:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:22:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:22:01 --> Encryption Class Initialized
INFO - 2026-07-03 07:22:01 --> Form Validation Class Initialized
INFO - 2026-07-03 07:22:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:22:01 --> Pagination Class Initialized
INFO - 2026-07-03 07:22:01 --> Email Class Initialized
INFO - 2026-07-03 07:22:01 --> Controller Class Initialized
DEBUG - 2026-07-03 07:22:01 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 07:22:01 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:22:01 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 07:22:01 --> Model "Dashboard_model" initialized
INFO - 2026-07-03 07:22:01 --> Final output sent to browser
DEBUG - 2026-07-03 07:22:01 --> Total execution time: 2.2527
INFO - 2026-07-03 07:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:22:01 --> Upload Class Initialized
DEBUG - 2026-07-03 07:22:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:22:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:22:01 --> Encryption Class Initialized
INFO - 2026-07-03 07:22:01 --> Form Validation Class Initialized
INFO - 2026-07-03 07:22:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:22:01 --> Pagination Class Initialized
INFO - 2026-07-03 07:22:01 --> Email Class Initialized
INFO - 2026-07-03 07:22:01 --> Controller Class Initialized
DEBUG - 2026-07-03 07:22:01 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 07:22:01 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:22:01 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 07:22:02 --> Model "Dashboard_model" initialized
INFO - 2026-07-03 07:22:02 --> Final output sent to browser
DEBUG - 2026-07-03 07:22:02 --> Total execution time: 3.0684
INFO - 2026-07-03 07:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:22:02 --> Upload Class Initialized
DEBUG - 2026-07-03 07:22:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:22:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:22:02 --> Encryption Class Initialized
INFO - 2026-07-03 07:22:02 --> Form Validation Class Initialized
INFO - 2026-07-03 07:22:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:22:02 --> Pagination Class Initialized
INFO - 2026-07-03 07:22:02 --> Email Class Initialized
INFO - 2026-07-03 07:22:02 --> Controller Class Initialized
DEBUG - 2026-07-03 07:22:02 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 07:22:02 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:22:02 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 07:22:03 --> Model "Dashboard_model" initialized
INFO - 2026-07-03 07:22:03 --> Final output sent to browser
DEBUG - 2026-07-03 07:22:03 --> Total execution time: 3.8952
INFO - 2026-07-03 07:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:22:03 --> Upload Class Initialized
DEBUG - 2026-07-03 07:22:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:22:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:22:03 --> Encryption Class Initialized
INFO - 2026-07-03 07:22:03 --> Form Validation Class Initialized
INFO - 2026-07-03 07:22:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:22:03 --> Pagination Class Initialized
INFO - 2026-07-03 07:22:03 --> Email Class Initialized
INFO - 2026-07-03 07:22:03 --> Controller Class Initialized
DEBUG - 2026-07-03 07:22:03 --> Order MX_Controller Initialized
INFO - 2026-07-03 07:22:03 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:22:03 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 07:22:03 --> Model "Order_model" initialized
INFO - 2026-07-03 07:22:03 --> Model "Common_model" initialized
INFO - 2026-07-03 07:22:03 --> Model "Currency_model" initialized
INFO - 2026-07-03 07:22:04 --> Final output sent to browser
DEBUG - 2026-07-03 07:22:04 --> Total execution time: 4.6186
INFO - 2026-07-03 07:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:22:04 --> Upload Class Initialized
DEBUG - 2026-07-03 07:22:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:22:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:22:04 --> Encryption Class Initialized
INFO - 2026-07-03 07:22:04 --> Form Validation Class Initialized
INFO - 2026-07-03 07:22:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:22:04 --> Pagination Class Initialized
INFO - 2026-07-03 07:22:04 --> Email Class Initialized
INFO - 2026-07-03 07:22:04 --> Controller Class Initialized
DEBUG - 2026-07-03 07:22:04 --> Ticket MX_Controller Initialized
INFO - 2026-07-03 07:22:04 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:22:04 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 07:22:04 --> Model "Support_model" initialized
INFO - 2026-07-03 07:22:04 --> Model "Common_model" initialized
INFO - 2026-07-03 07:22:05 --> Final output sent to browser
DEBUG - 2026-07-03 07:22:05 --> Total execution time: 5.4331
INFO - 2026-07-03 07:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:22:05 --> Upload Class Initialized
DEBUG - 2026-07-03 07:22:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:22:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:22:05 --> Encryption Class Initialized
INFO - 2026-07-03 07:22:05 --> Form Validation Class Initialized
INFO - 2026-07-03 07:22:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:22:05 --> Pagination Class Initialized
INFO - 2026-07-03 07:22:05 --> Email Class Initialized
INFO - 2026-07-03 07:22:05 --> Controller Class Initialized
DEBUG - 2026-07-03 07:22:05 --> Invoice MX_Controller Initialized
INFO - 2026-07-03 07:22:05 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:22:05 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 07:22:05 --> Model "Billing_model" initialized
INFO - 2026-07-03 07:22:05 --> Model "Common_model" initialized
INFO - 2026-07-03 07:22:05 --> Model "Invoice_model" initialized
INFO - 2026-07-03 07:22:05 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 07:22:05 --> Final output sent to browser
DEBUG - 2026-07-03 07:22:05 --> Total execution time: 6.2496
INFO - 2026-07-03 07:22:26 --> Config Class Initialized
INFO - 2026-07-03 07:22:26 --> Hooks Class Initialized
DEBUG - 2026-07-03 07:22:26 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:22:26 --> Utf8 Class Initialized
INFO - 2026-07-03 07:22:26 --> URI Class Initialized
INFO - 2026-07-03 07:22:26 --> Router Class Initialized
INFO - 2026-07-03 07:22:26 --> Output Class Initialized
INFO - 2026-07-03 07:22:26 --> Security Class Initialized
DEBUG - 2026-07-03 07:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:22:26 --> CSRF cookie sent
INFO - 2026-07-03 07:22:26 --> Input Class Initialized
INFO - 2026-07-03 07:22:26 --> Language Class Initialized
INFO - 2026-07-03 07:22:26 --> Language Class Initialized
INFO - 2026-07-03 07:22:26 --> Config Class Initialized
INFO - 2026-07-03 07:22:26 --> Loader Class Initialized
INFO - 2026-07-03 07:22:26 --> Helper loaded: url_helper
INFO - 2026-07-03 07:22:26 --> Helper loaded: form_helper
INFO - 2026-07-03 07:22:26 --> Helper loaded: html_helper
INFO - 2026-07-03 07:22:26 --> Helper loaded: file_helper
INFO - 2026-07-03 07:22:26 --> Helper loaded: email_helper
INFO - 2026-07-03 07:22:26 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:22:26 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:22:26 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:22:26 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:22:26 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:22:26 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:22:26 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:22:26 --> Database Driver Class Initialized
INFO - 2026-07-03 07:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:22:28 --> Upload Class Initialized
DEBUG - 2026-07-03 07:22:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:22:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:22:28 --> Encryption Class Initialized
INFO - 2026-07-03 07:22:28 --> Form Validation Class Initialized
INFO - 2026-07-03 07:22:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:22:28 --> Pagination Class Initialized
INFO - 2026-07-03 07:22:28 --> Email Class Initialized
INFO - 2026-07-03 07:22:28 --> Controller Class Initialized
DEBUG - 2026-07-03 07:22:28 --> Software MX_Controller Initialized
INFO - 2026-07-03 07:22:28 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:22:28 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 07:22:28 --> Model "Software_model" initialized
DEBUG - 2026-07-03 07:22:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 07:22:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 07:22:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 07:22:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 07:22:29 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/software_manage.php
INFO - 2026-07-03 07:22:29 --> Final output sent to browser
DEBUG - 2026-07-03 07:22:29 --> Total execution time: 3.1247
INFO - 2026-07-03 07:22:52 --> Config Class Initialized
INFO - 2026-07-03 07:22:52 --> Hooks Class Initialized
DEBUG - 2026-07-03 07:22:52 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:22:52 --> Utf8 Class Initialized
INFO - 2026-07-03 07:22:52 --> URI Class Initialized
INFO - 2026-07-03 07:22:52 --> Router Class Initialized
INFO - 2026-07-03 07:22:52 --> Output Class Initialized
INFO - 2026-07-03 07:22:52 --> Security Class Initialized
DEBUG - 2026-07-03 07:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:22:52 --> CSRF cookie sent
INFO - 2026-07-03 07:22:52 --> Input Class Initialized
INFO - 2026-07-03 07:22:52 --> Language Class Initialized
INFO - 2026-07-03 07:22:52 --> Language Class Initialized
INFO - 2026-07-03 07:22:52 --> Config Class Initialized
INFO - 2026-07-03 07:22:52 --> Loader Class Initialized
INFO - 2026-07-03 07:22:52 --> Helper loaded: url_helper
INFO - 2026-07-03 07:22:52 --> Helper loaded: form_helper
INFO - 2026-07-03 07:22:52 --> Helper loaded: html_helper
INFO - 2026-07-03 07:22:52 --> Helper loaded: file_helper
INFO - 2026-07-03 07:22:52 --> Helper loaded: email_helper
INFO - 2026-07-03 07:22:52 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:22:52 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:22:52 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:22:52 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:22:52 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:22:52 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:22:52 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:22:52 --> Database Driver Class Initialized
INFO - 2026-07-03 07:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:22:54 --> Upload Class Initialized
DEBUG - 2026-07-03 07:22:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:22:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:22:54 --> Encryption Class Initialized
INFO - 2026-07-03 07:22:54 --> Form Validation Class Initialized
INFO - 2026-07-03 07:22:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:22:54 --> Pagination Class Initialized
INFO - 2026-07-03 07:22:54 --> Email Class Initialized
INFO - 2026-07-03 07:22:54 --> Controller Class Initialized
DEBUG - 2026-07-03 07:22:54 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 07:22:54 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:22:54 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 07:22:54 --> Model "Dashboard_model" initialized
DEBUG - 2026-07-03 07:22:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 07:22:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 07:22:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 07:22:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-03 07:22:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 07:22:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/dashboard_index.php
INFO - 2026-07-03 07:22:54 --> Final output sent to browser
DEBUG - 2026-07-03 07:22:54 --> Total execution time: 2.1162
INFO - 2026-07-03 07:22:54 --> Config Class Initialized
INFO - 2026-07-03 07:22:54 --> Hooks Class Initialized
DEBUG - 2026-07-03 07:22:54 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:22:54 --> Utf8 Class Initialized
INFO - 2026-07-03 07:22:54 --> URI Class Initialized
INFO - 2026-07-03 07:22:54 --> Router Class Initialized
INFO - 2026-07-03 07:22:54 --> Output Class Initialized
INFO - 2026-07-03 07:22:54 --> Security Class Initialized
DEBUG - 2026-07-03 07:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:22:54 --> CSRF cookie sent
INFO - 2026-07-03 07:22:54 --> Input Class Initialized
INFO - 2026-07-03 07:22:54 --> Language Class Initialized
INFO - 2026-07-03 07:22:54 --> Language Class Initialized
INFO - 2026-07-03 07:22:54 --> Config Class Initialized
INFO - 2026-07-03 07:22:54 --> Loader Class Initialized
INFO - 2026-07-03 07:22:54 --> Helper loaded: url_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: form_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: html_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: file_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: email_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:22:54 --> Database Driver Class Initialized
INFO - 2026-07-03 07:22:54 --> Config Class Initialized
INFO - 2026-07-03 07:22:54 --> Hooks Class Initialized
DEBUG - 2026-07-03 07:22:54 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:22:54 --> Utf8 Class Initialized
INFO - 2026-07-03 07:22:54 --> URI Class Initialized
INFO - 2026-07-03 07:22:54 --> Router Class Initialized
INFO - 2026-07-03 07:22:54 --> Output Class Initialized
INFO - 2026-07-03 07:22:54 --> Security Class Initialized
DEBUG - 2026-07-03 07:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:22:54 --> CSRF cookie sent
INFO - 2026-07-03 07:22:54 --> Input Class Initialized
INFO - 2026-07-03 07:22:54 --> Language Class Initialized
INFO - 2026-07-03 07:22:54 --> Language Class Initialized
INFO - 2026-07-03 07:22:54 --> Config Class Initialized
INFO - 2026-07-03 07:22:54 --> Loader Class Initialized
INFO - 2026-07-03 07:22:54 --> Helper loaded: url_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: form_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: html_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: file_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: email_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:22:54 --> Database Driver Class Initialized
INFO - 2026-07-03 07:22:54 --> Config Class Initialized
INFO - 2026-07-03 07:22:54 --> Hooks Class Initialized
INFO - 2026-07-03 07:22:54 --> Config Class Initialized
INFO - 2026-07-03 07:22:54 --> Hooks Class Initialized
DEBUG - 2026-07-03 07:22:54 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:22:54 --> Utf8 Class Initialized
DEBUG - 2026-07-03 07:22:54 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:22:54 --> Utf8 Class Initialized
INFO - 2026-07-03 07:22:54 --> URI Class Initialized
INFO - 2026-07-03 07:22:54 --> URI Class Initialized
INFO - 2026-07-03 07:22:54 --> Router Class Initialized
INFO - 2026-07-03 07:22:54 --> Config Class Initialized
INFO - 2026-07-03 07:22:54 --> Hooks Class Initialized
INFO - 2026-07-03 07:22:54 --> Config Class Initialized
INFO - 2026-07-03 07:22:54 --> Hooks Class Initialized
INFO - 2026-07-03 07:22:54 --> Output Class Initialized
INFO - 2026-07-03 07:22:54 --> Router Class Initialized
DEBUG - 2026-07-03 07:22:54 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:22:54 --> Utf8 Class Initialized
INFO - 2026-07-03 07:22:54 --> URI Class Initialized
INFO - 2026-07-03 07:22:54 --> Security Class Initialized
DEBUG - 2026-07-03 07:22:54 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:22:54 --> Utf8 Class Initialized
INFO - 2026-07-03 07:22:54 --> Output Class Initialized
DEBUG - 2026-07-03 07:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:22:54 --> CSRF cookie sent
INFO - 2026-07-03 07:22:54 --> Input Class Initialized
INFO - 2026-07-03 07:22:54 --> Language Class Initialized
INFO - 2026-07-03 07:22:54 --> URI Class Initialized
INFO - 2026-07-03 07:22:54 --> Router Class Initialized
INFO - 2026-07-03 07:22:54 --> Security Class Initialized
INFO - 2026-07-03 07:22:54 --> Language Class Initialized
INFO - 2026-07-03 07:22:54 --> Config Class Initialized
INFO - 2026-07-03 07:22:54 --> Output Class Initialized
DEBUG - 2026-07-03 07:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:22:54 --> CSRF cookie sent
INFO - 2026-07-03 07:22:54 --> Input Class Initialized
INFO - 2026-07-03 07:22:54 --> Router Class Initialized
INFO - 2026-07-03 07:22:54 --> Language Class Initialized
INFO - 2026-07-03 07:22:54 --> Security Class Initialized
INFO - 2026-07-03 07:22:54 --> Loader Class Initialized
INFO - 2026-07-03 07:22:54 --> Language Class Initialized
INFO - 2026-07-03 07:22:54 --> Config Class Initialized
DEBUG - 2026-07-03 07:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:22:54 --> CSRF cookie sent
INFO - 2026-07-03 07:22:54 --> Input Class Initialized
INFO - 2026-07-03 07:22:54 --> Output Class Initialized
INFO - 2026-07-03 07:22:54 --> Language Class Initialized
INFO - 2026-07-03 07:22:54 --> Helper loaded: url_helper
INFO - 2026-07-03 07:22:54 --> Language Class Initialized
INFO - 2026-07-03 07:22:54 --> Config Class Initialized
INFO - 2026-07-03 07:22:54 --> Helper loaded: form_helper
INFO - 2026-07-03 07:22:54 --> Security Class Initialized
INFO - 2026-07-03 07:22:54 --> Helper loaded: html_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: file_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: email_helper
INFO - 2026-07-03 07:22:54 --> Loader Class Initialized
DEBUG - 2026-07-03 07:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:22:54 --> CSRF cookie sent
INFO - 2026-07-03 07:22:54 --> Input Class Initialized
INFO - 2026-07-03 07:22:54 --> Language Class Initialized
INFO - 2026-07-03 07:22:54 --> Helper loaded: url_helper
INFO - 2026-07-03 07:22:54 --> Loader Class Initialized
INFO - 2026-07-03 07:22:54 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:22:54 --> Language Class Initialized
INFO - 2026-07-03 07:22:54 --> Config Class Initialized
INFO - 2026-07-03 07:22:54 --> Helper loaded: form_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: url_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: html_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: file_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: email_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: form_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: html_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: file_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: email_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:22:54 --> Loader Class Initialized
INFO - 2026-07-03 07:22:54 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: url_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: form_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: html_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: file_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: email_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:22:54 --> Database Driver Class Initialized
INFO - 2026-07-03 07:22:54 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:22:54 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:22:54 --> Database Driver Class Initialized
INFO - 2026-07-03 07:22:54 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:22:54 --> Database Driver Class Initialized
INFO - 2026-07-03 07:22:54 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:22:54 --> Database Driver Class Initialized
INFO - 2026-07-03 07:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:22:56 --> Upload Class Initialized
DEBUG - 2026-07-03 07:22:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:22:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:22:56 --> Encryption Class Initialized
INFO - 2026-07-03 07:22:56 --> Form Validation Class Initialized
INFO - 2026-07-03 07:22:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:22:56 --> Pagination Class Initialized
INFO - 2026-07-03 07:22:56 --> Email Class Initialized
INFO - 2026-07-03 07:22:56 --> Controller Class Initialized
ERROR - 2026-07-03 07:22:56 --> 404 Page Not Found: /index
INFO - 2026-07-03 07:22:56 --> Config Class Initialized
INFO - 2026-07-03 07:22:56 --> Hooks Class Initialized
DEBUG - 2026-07-03 07:22:56 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:22:56 --> Utf8 Class Initialized
INFO - 2026-07-03 07:22:56 --> URI Class Initialized
INFO - 2026-07-03 07:22:56 --> Router Class Initialized
INFO - 2026-07-03 07:22:56 --> Output Class Initialized
INFO - 2026-07-03 07:22:56 --> Security Class Initialized
DEBUG - 2026-07-03 07:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:22:56 --> Input Class Initialized
INFO - 2026-07-03 07:22:56 --> Language Class Initialized
INFO - 2026-07-03 07:22:56 --> Language Class Initialized
INFO - 2026-07-03 07:22:56 --> Config Class Initialized
INFO - 2026-07-03 07:22:56 --> Loader Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: url_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: form_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: html_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: file_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: email_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:22:56 --> Database Driver Class Initialized
INFO - 2026-07-03 07:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:22:56 --> Upload Class Initialized
DEBUG - 2026-07-03 07:22:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:22:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:22:56 --> Encryption Class Initialized
INFO - 2026-07-03 07:22:56 --> Form Validation Class Initialized
INFO - 2026-07-03 07:22:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:22:56 --> Pagination Class Initialized
INFO - 2026-07-03 07:22:56 --> Email Class Initialized
INFO - 2026-07-03 07:22:56 --> Controller Class Initialized
ERROR - 2026-07-03 07:22:56 --> 404 Page Not Found: /index
INFO - 2026-07-03 07:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:22:56 --> Upload Class Initialized
DEBUG - 2026-07-03 07:22:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:22:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:22:56 --> Encryption Class Initialized
INFO - 2026-07-03 07:22:56 --> Form Validation Class Initialized
INFO - 2026-07-03 07:22:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:22:56 --> Pagination Class Initialized
INFO - 2026-07-03 07:22:56 --> Config Class Initialized
INFO - 2026-07-03 07:22:56 --> Hooks Class Initialized
INFO - 2026-07-03 07:22:56 --> Email Class Initialized
INFO - 2026-07-03 07:22:56 --> Controller Class Initialized
ERROR - 2026-07-03 07:22:56 --> 404 Page Not Found: /index
DEBUG - 2026-07-03 07:22:56 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:22:56 --> Utf8 Class Initialized
INFO - 2026-07-03 07:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:22:56 --> URI Class Initialized
INFO - 2026-07-03 07:22:56 --> Upload Class Initialized
INFO - 2026-07-03 07:22:56 --> Router Class Initialized
DEBUG - 2026-07-03 07:22:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:22:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:22:56 --> Encryption Class Initialized
INFO - 2026-07-03 07:22:56 --> Output Class Initialized
INFO - 2026-07-03 07:22:56 --> Security Class Initialized
INFO - 2026-07-03 07:22:56 --> Form Validation Class Initialized
DEBUG - 2026-07-03 07:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:22:56 --> Input Class Initialized
INFO - 2026-07-03 07:22:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:22:56 --> Pagination Class Initialized
INFO - 2026-07-03 07:22:56 --> Language Class Initialized
INFO - 2026-07-03 07:22:56 --> Language Class Initialized
INFO - 2026-07-03 07:22:56 --> Config Class Initialized
INFO - 2026-07-03 07:22:56 --> Config Class Initialized
INFO - 2026-07-03 07:22:56 --> Hooks Class Initialized
INFO - 2026-07-03 07:22:56 --> Email Class Initialized
INFO - 2026-07-03 07:22:56 --> Controller Class Initialized
ERROR - 2026-07-03 07:22:56 --> 404 Page Not Found: /index
INFO - 2026-07-03 07:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:22:56 --> Loader Class Initialized
DEBUG - 2026-07-03 07:22:56 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:22:56 --> Utf8 Class Initialized
INFO - 2026-07-03 07:22:56 --> URI Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: url_helper
INFO - 2026-07-03 07:22:56 --> Upload Class Initialized
INFO - 2026-07-03 07:22:56 --> Router Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: form_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: html_helper
INFO - 2026-07-03 07:22:56 --> Output Class Initialized
DEBUG - 2026-07-03 07:22:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:22:56 --> Helper loaded: file_helper
INFO - 2026-07-03 07:22:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:22:56 --> Encryption Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: email_helper
INFO - 2026-07-03 07:22:56 --> Security Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:22:56 --> Form Validation Class Initialized
DEBUG - 2026-07-03 07:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:22:56 --> Input Class Initialized
INFO - 2026-07-03 07:22:56 --> Language Class Initialized
INFO - 2026-07-03 07:22:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:22:56 --> Pagination Class Initialized
INFO - 2026-07-03 07:22:56 --> Language Class Initialized
INFO - 2026-07-03 07:22:56 --> Config Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:22:56 --> Config Class Initialized
INFO - 2026-07-03 07:22:56 --> Hooks Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: plesk_helper
DEBUG - 2026-07-03 07:22:56 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:22:56 --> Utf8 Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:22:56 --> Loader Class Initialized
INFO - 2026-07-03 07:22:56 --> Email Class Initialized
INFO - 2026-07-03 07:22:56 --> Controller Class Initialized
INFO - 2026-07-03 07:22:56 --> URI Class Initialized
ERROR - 2026-07-03 07:22:56 --> 404 Page Not Found: /index
INFO - 2026-07-03 07:22:56 --> Helper loaded: url_helper
INFO - 2026-07-03 07:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:22:56 --> Router Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: form_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: html_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: file_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: email_helper
INFO - 2026-07-03 07:22:56 --> Output Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:22:56 --> Security Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: ssp_helper
DEBUG - 2026-07-03 07:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:22:56 --> Input Class Initialized
INFO - 2026-07-03 07:22:56 --> Language Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:22:56 --> Upload Class Initialized
INFO - 2026-07-03 07:22:56 --> Language Class Initialized
INFO - 2026-07-03 07:22:56 --> Config Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: plesk_helper
DEBUG - 2026-07-03 07:22:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:22:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:22:56 --> Encryption Class Initialized
INFO - 2026-07-03 07:22:56 --> Database Driver Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:22:56 --> Loader Class Initialized
INFO - 2026-07-03 07:22:56 --> Form Validation Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: url_helper
INFO - 2026-07-03 07:22:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:22:56 --> Pagination Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: form_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: html_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:22:56 --> Config Class Initialized
INFO - 2026-07-03 07:22:56 --> Hooks Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: file_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: email_helper
INFO - 2026-07-03 07:22:56 --> Email Class Initialized
INFO - 2026-07-03 07:22:56 --> Controller Class Initialized
DEBUG - 2026-07-03 07:22:56 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:22:56 --> Utf8 Class Initialized
ERROR - 2026-07-03 07:22:56 --> 404 Page Not Found: /index
INFO - 2026-07-03 07:22:56 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:22:56 --> URI Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:22:56 --> Router Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:22:56 --> Output Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:22:56 --> Database Driver Class Initialized
INFO - 2026-07-03 07:22:56 --> Security Class Initialized
DEBUG - 2026-07-03 07:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:22:56 --> Input Class Initialized
INFO - 2026-07-03 07:22:56 --> Language Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:22:56 --> Language Class Initialized
INFO - 2026-07-03 07:22:56 --> Config Class Initialized
INFO - 2026-07-03 07:22:56 --> Config Class Initialized
INFO - 2026-07-03 07:22:56 --> Hooks Class Initialized
INFO - 2026-07-03 07:22:56 --> Loader Class Initialized
DEBUG - 2026-07-03 07:22:56 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:22:56 --> Utf8 Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: url_helper
INFO - 2026-07-03 07:22:56 --> URI Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: form_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: html_helper
INFO - 2026-07-03 07:22:56 --> Router Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: file_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: email_helper
INFO - 2026-07-03 07:22:56 --> Output Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:22:56 --> Database Driver Class Initialized
INFO - 2026-07-03 07:22:56 --> Security Class Initialized
DEBUG - 2026-07-03 07:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:22:56 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:22:56 --> Input Class Initialized
INFO - 2026-07-03 07:22:56 --> Language Class Initialized
INFO - 2026-07-03 07:22:56 --> Language Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:22:56 --> Config Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:22:56 --> Loader Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: url_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: form_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: html_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: file_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: email_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:22:56 --> Database Driver Class Initialized
INFO - 2026-07-03 07:22:56 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:22:56 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:22:56 --> Database Driver Class Initialized
INFO - 2026-07-03 07:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:22:57 --> Upload Class Initialized
DEBUG - 2026-07-03 07:22:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:22:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:22:57 --> Encryption Class Initialized
INFO - 2026-07-03 07:22:57 --> Form Validation Class Initialized
INFO - 2026-07-03 07:22:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:22:57 --> Pagination Class Initialized
INFO - 2026-07-03 07:22:57 --> Email Class Initialized
INFO - 2026-07-03 07:22:57 --> Controller Class Initialized
DEBUG - 2026-07-03 07:22:57 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 07:22:57 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:22:57 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 07:22:58 --> Model "Dashboard_model" initialized
INFO - 2026-07-03 07:22:58 --> Final output sent to browser
DEBUG - 2026-07-03 07:22:58 --> Total execution time: 2.4677
INFO - 2026-07-03 07:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:22:58 --> Upload Class Initialized
DEBUG - 2026-07-03 07:22:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:22:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:22:58 --> Encryption Class Initialized
INFO - 2026-07-03 07:22:58 --> Form Validation Class Initialized
INFO - 2026-07-03 07:22:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:22:58 --> Pagination Class Initialized
INFO - 2026-07-03 07:22:58 --> Config Class Initialized
INFO - 2026-07-03 07:22:58 --> Hooks Class Initialized
INFO - 2026-07-03 07:22:58 --> Email Class Initialized
INFO - 2026-07-03 07:22:58 --> Controller Class Initialized
DEBUG - 2026-07-03 07:22:58 --> UTF-8 Support Enabled
INFO - 2026-07-03 07:22:58 --> Utf8 Class Initialized
DEBUG - 2026-07-03 07:22:58 --> Ticket MX_Controller Initialized
INFO - 2026-07-03 07:22:58 --> URI Class Initialized
INFO - 2026-07-03 07:22:58 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:22:58 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 07:22:58 --> Router Class Initialized
INFO - 2026-07-03 07:22:58 --> Model "Support_model" initialized
INFO - 2026-07-03 07:22:58 --> Output Class Initialized
INFO - 2026-07-03 07:22:58 --> Model "Common_model" initialized
INFO - 2026-07-03 07:22:58 --> Security Class Initialized
DEBUG - 2026-07-03 07:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 07:22:58 --> CSRF cookie sent
INFO - 2026-07-03 07:22:58 --> Input Class Initialized
INFO - 2026-07-03 07:22:58 --> Language Class Initialized
INFO - 2026-07-03 07:22:58 --> Language Class Initialized
INFO - 2026-07-03 07:22:58 --> Config Class Initialized
INFO - 2026-07-03 07:22:58 --> Loader Class Initialized
INFO - 2026-07-03 07:22:58 --> Helper loaded: url_helper
INFO - 2026-07-03 07:22:58 --> Helper loaded: form_helper
INFO - 2026-07-03 07:22:58 --> Helper loaded: html_helper
INFO - 2026-07-03 07:22:58 --> Helper loaded: file_helper
INFO - 2026-07-03 07:22:58 --> Helper loaded: email_helper
INFO - 2026-07-03 07:22:58 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 07:22:58 --> Helper loaded: ssp_helper
INFO - 2026-07-03 07:22:58 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 07:22:58 --> Helper loaded: plesk_helper
INFO - 2026-07-03 07:22:58 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 07:22:58 --> Helper loaded: domain_helper
INFO - 2026-07-03 07:22:58 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 07:22:58 --> Database Driver Class Initialized
INFO - 2026-07-03 07:22:59 --> Final output sent to browser
DEBUG - 2026-07-03 07:22:59 --> Total execution time: 2.8541
INFO - 2026-07-03 07:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:22:59 --> Upload Class Initialized
DEBUG - 2026-07-03 07:22:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:22:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:22:59 --> Encryption Class Initialized
INFO - 2026-07-03 07:22:59 --> Form Validation Class Initialized
INFO - 2026-07-03 07:22:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:22:59 --> Pagination Class Initialized
INFO - 2026-07-03 07:22:59 --> Email Class Initialized
INFO - 2026-07-03 07:22:59 --> Controller Class Initialized
DEBUG - 2026-07-03 07:22:59 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 07:22:59 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:22:59 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 07:22:59 --> Model "Dashboard_model" initialized
INFO - 2026-07-03 07:23:00 --> Final output sent to browser
DEBUG - 2026-07-03 07:23:00 --> Total execution time: 3.6502
INFO - 2026-07-03 07:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:23:00 --> Upload Class Initialized
DEBUG - 2026-07-03 07:23:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:23:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:23:00 --> Encryption Class Initialized
INFO - 2026-07-03 07:23:00 --> Form Validation Class Initialized
INFO - 2026-07-03 07:23:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:23:00 --> Pagination Class Initialized
INFO - 2026-07-03 07:23:00 --> Email Class Initialized
INFO - 2026-07-03 07:23:00 --> Controller Class Initialized
DEBUG - 2026-07-03 07:23:00 --> Invoice MX_Controller Initialized
INFO - 2026-07-03 07:23:00 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:23:00 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 07:23:00 --> Model "Billing_model" initialized
INFO - 2026-07-03 07:23:00 --> Model "Common_model" initialized
INFO - 2026-07-03 07:23:00 --> Model "Invoice_model" initialized
INFO - 2026-07-03 07:23:00 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 07:23:01 --> Final output sent to browser
DEBUG - 2026-07-03 07:23:01 --> Total execution time: 4.4910
INFO - 2026-07-03 07:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:23:01 --> Upload Class Initialized
DEBUG - 2026-07-03 07:23:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:23:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:23:01 --> Encryption Class Initialized
INFO - 2026-07-03 07:23:01 --> Form Validation Class Initialized
INFO - 2026-07-03 07:23:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:23:01 --> Pagination Class Initialized
INFO - 2026-07-03 07:23:01 --> Email Class Initialized
INFO - 2026-07-03 07:23:01 --> Controller Class Initialized
DEBUG - 2026-07-03 07:23:01 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 07:23:01 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:23:01 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 07:23:01 --> Model "Dashboard_model" initialized
INFO - 2026-07-03 07:23:01 --> Final output sent to browser
DEBUG - 2026-07-03 07:23:01 --> Total execution time: 5.2949
INFO - 2026-07-03 07:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:23:01 --> Upload Class Initialized
DEBUG - 2026-07-03 07:23:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:23:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:23:01 --> Encryption Class Initialized
INFO - 2026-07-03 07:23:01 --> Form Validation Class Initialized
INFO - 2026-07-03 07:23:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:23:01 --> Pagination Class Initialized
INFO - 2026-07-03 07:23:01 --> Email Class Initialized
INFO - 2026-07-03 07:23:01 --> Controller Class Initialized
DEBUG - 2026-07-03 07:23:01 --> Order MX_Controller Initialized
INFO - 2026-07-03 07:23:01 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 07:23:01 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 07:23:02 --> Model "Order_model" initialized
INFO - 2026-07-03 07:23:02 --> Model "Common_model" initialized
INFO - 2026-07-03 07:23:02 --> Model "Currency_model" initialized
INFO - 2026-07-03 07:23:02 --> Final output sent to browser
DEBUG - 2026-07-03 07:23:02 --> Total execution time: 6.1352
INFO - 2026-07-03 07:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 07:23:02 --> Upload Class Initialized
DEBUG - 2026-07-03 07:23:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 07:23:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 07:23:02 --> Encryption Class Initialized
INFO - 2026-07-03 07:23:02 --> Form Validation Class Initialized
INFO - 2026-07-03 07:23:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 07:23:02 --> Pagination Class Initialized
INFO - 2026-07-03 07:23:02 --> Email Class Initialized
INFO - 2026-07-03 07:23:02 --> Controller Class Initialized
ERROR - 2026-07-03 07:23:02 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:07:26 --> Config Class Initialized
INFO - 2026-07-03 08:07:26 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:07:26 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:07:26 --> Utf8 Class Initialized
INFO - 2026-07-03 08:07:26 --> URI Class Initialized
INFO - 2026-07-03 08:07:26 --> Router Class Initialized
INFO - 2026-07-03 08:07:26 --> Output Class Initialized
INFO - 2026-07-03 08:07:26 --> Security Class Initialized
DEBUG - 2026-07-03 08:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:07:26 --> CSRF cookie sent
INFO - 2026-07-03 08:07:26 --> Input Class Initialized
INFO - 2026-07-03 08:07:26 --> Language Class Initialized
INFO - 2026-07-03 08:07:26 --> Language Class Initialized
INFO - 2026-07-03 08:07:26 --> Config Class Initialized
INFO - 2026-07-03 08:07:26 --> Loader Class Initialized
INFO - 2026-07-03 08:07:26 --> Helper loaded: url_helper
INFO - 2026-07-03 08:07:26 --> Helper loaded: form_helper
INFO - 2026-07-03 08:07:26 --> Helper loaded: html_helper
INFO - 2026-07-03 08:07:26 --> Helper loaded: file_helper
INFO - 2026-07-03 08:07:26 --> Helper loaded: email_helper
INFO - 2026-07-03 08:07:26 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:07:26 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:07:26 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:07:26 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:07:26 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:07:26 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:07:26 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:07:26 --> Database Driver Class Initialized
INFO - 2026-07-03 08:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:07:27 --> Upload Class Initialized
DEBUG - 2026-07-03 08:07:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:07:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:07:27 --> Encryption Class Initialized
INFO - 2026-07-03 08:07:27 --> Form Validation Class Initialized
INFO - 2026-07-03 08:07:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:07:27 --> Pagination Class Initialized
INFO - 2026-07-03 08:07:27 --> Email Class Initialized
INFO - 2026-07-03 08:07:27 --> Controller Class Initialized
DEBUG - 2026-07-03 08:07:27 --> Authenticate MX_Controller Initialized
INFO - 2026-07-03 08:07:27 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:07:27 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:07:27 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-03 08:07:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 08:07:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 08:07:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-07-03 08:07:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-03 08:07:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 08:07:28 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-07-03 08:07:28 --> Final output sent to browser
DEBUG - 2026-07-03 08:07:28 --> Total execution time: 1.9413
INFO - 2026-07-03 08:07:28 --> Config Class Initialized
INFO - 2026-07-03 08:07:28 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:07:28 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:07:28 --> Utf8 Class Initialized
INFO - 2026-07-03 08:07:28 --> URI Class Initialized
DEBUG - 2026-07-03 08:07:28 --> No URI present. Default controller set.
INFO - 2026-07-03 08:07:28 --> Router Class Initialized
INFO - 2026-07-03 08:07:28 --> Output Class Initialized
INFO - 2026-07-03 08:07:28 --> Security Class Initialized
DEBUG - 2026-07-03 08:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:07:28 --> CSRF cookie sent
INFO - 2026-07-03 08:07:28 --> Input Class Initialized
INFO - 2026-07-03 08:07:28 --> Language Class Initialized
INFO - 2026-07-03 08:07:28 --> Language Class Initialized
INFO - 2026-07-03 08:07:28 --> Config Class Initialized
INFO - 2026-07-03 08:07:28 --> Loader Class Initialized
INFO - 2026-07-03 08:07:28 --> Helper loaded: url_helper
INFO - 2026-07-03 08:07:28 --> Helper loaded: form_helper
INFO - 2026-07-03 08:07:28 --> Helper loaded: html_helper
INFO - 2026-07-03 08:07:28 --> Helper loaded: file_helper
INFO - 2026-07-03 08:07:28 --> Helper loaded: email_helper
INFO - 2026-07-03 08:07:28 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:07:28 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:07:28 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:07:28 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:07:28 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:07:28 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:07:28 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:07:28 --> Database Driver Class Initialized
INFO - 2026-07-03 08:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:07:30 --> Upload Class Initialized
DEBUG - 2026-07-03 08:07:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:07:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:07:30 --> Encryption Class Initialized
INFO - 2026-07-03 08:07:30 --> Form Validation Class Initialized
INFO - 2026-07-03 08:07:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:07:30 --> Pagination Class Initialized
INFO - 2026-07-03 08:07:30 --> Email Class Initialized
INFO - 2026-07-03 08:07:30 --> Controller Class Initialized
DEBUG - 2026-07-03 08:07:30 --> Auth MX_Controller Initialized
INFO - 2026-07-03 08:07:30 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:07:30 --> Model "Auth_model" initialized
INFO - 2026-07-03 08:07:30 --> Model "Cart_model" initialized
INFO - 2026-07-03 08:07:30 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 08:07:44 --> Config Class Initialized
INFO - 2026-07-03 08:07:44 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:07:44 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:07:44 --> Utf8 Class Initialized
INFO - 2026-07-03 08:07:44 --> URI Class Initialized
INFO - 2026-07-03 08:07:44 --> Router Class Initialized
INFO - 2026-07-03 08:07:44 --> Output Class Initialized
INFO - 2026-07-03 08:07:44 --> Security Class Initialized
DEBUG - 2026-07-03 08:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:07:44 --> CSRF cookie sent
INFO - 2026-07-03 08:07:44 --> Input Class Initialized
INFO - 2026-07-03 08:07:44 --> Language Class Initialized
INFO - 2026-07-03 08:07:44 --> Language Class Initialized
INFO - 2026-07-03 08:07:44 --> Config Class Initialized
INFO - 2026-07-03 08:07:44 --> Loader Class Initialized
INFO - 2026-07-03 08:07:44 --> Helper loaded: url_helper
INFO - 2026-07-03 08:07:44 --> Helper loaded: form_helper
INFO - 2026-07-03 08:07:44 --> Helper loaded: html_helper
INFO - 2026-07-03 08:07:44 --> Helper loaded: file_helper
INFO - 2026-07-03 08:07:44 --> Helper loaded: email_helper
INFO - 2026-07-03 08:07:44 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:07:44 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:07:44 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:07:44 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:07:44 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:07:44 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:07:44 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:07:44 --> Database Driver Class Initialized
INFO - 2026-07-03 08:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:07:46 --> Upload Class Initialized
DEBUG - 2026-07-03 08:07:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:07:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:07:46 --> Encryption Class Initialized
INFO - 2026-07-03 08:07:46 --> Form Validation Class Initialized
INFO - 2026-07-03 08:07:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:07:46 --> Pagination Class Initialized
INFO - 2026-07-03 08:07:46 --> Email Class Initialized
INFO - 2026-07-03 08:07:46 --> Controller Class Initialized
DEBUG - 2026-07-03 08:07:46 --> Softwareproduct MX_Controller Initialized
INFO - 2026-07-03 08:07:46 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:07:46 --> Model "Adminauth_model" initialized
DEBUG - 2026-07-03 08:07:46 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 08:07:46 --> Model "Plan_model" initialized
INFO - 2026-07-03 08:07:46 --> Model "Software_model" initialized
INFO - 2026-07-03 08:07:46 --> Config Class Initialized
INFO - 2026-07-03 08:07:46 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:07:46 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:07:46 --> Utf8 Class Initialized
INFO - 2026-07-03 08:07:46 --> URI Class Initialized
INFO - 2026-07-03 08:07:46 --> Router Class Initialized
INFO - 2026-07-03 08:07:46 --> Output Class Initialized
INFO - 2026-07-03 08:07:46 --> Security Class Initialized
DEBUG - 2026-07-03 08:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:07:46 --> CSRF cookie sent
INFO - 2026-07-03 08:07:46 --> Input Class Initialized
INFO - 2026-07-03 08:07:46 --> Language Class Initialized
INFO - 2026-07-03 08:07:46 --> Language Class Initialized
INFO - 2026-07-03 08:07:46 --> Config Class Initialized
INFO - 2026-07-03 08:07:46 --> Loader Class Initialized
INFO - 2026-07-03 08:07:46 --> Helper loaded: url_helper
INFO - 2026-07-03 08:07:46 --> Helper loaded: form_helper
INFO - 2026-07-03 08:07:46 --> Helper loaded: html_helper
INFO - 2026-07-03 08:07:46 --> Helper loaded: file_helper
INFO - 2026-07-03 08:07:46 --> Helper loaded: email_helper
INFO - 2026-07-03 08:07:46 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:07:46 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:07:46 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:07:46 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:07:46 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:07:46 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:07:46 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:07:46 --> Database Driver Class Initialized
INFO - 2026-07-03 08:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:07:48 --> Upload Class Initialized
DEBUG - 2026-07-03 08:07:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:07:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:07:48 --> Encryption Class Initialized
INFO - 2026-07-03 08:07:48 --> Form Validation Class Initialized
INFO - 2026-07-03 08:07:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:07:48 --> Pagination Class Initialized
INFO - 2026-07-03 08:07:48 --> Email Class Initialized
INFO - 2026-07-03 08:07:48 --> Controller Class Initialized
DEBUG - 2026-07-03 08:07:48 --> Softwareproduct MX_Controller Initialized
INFO - 2026-07-03 08:07:48 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:07:48 --> Model "Adminauth_model" initialized
DEBUG - 2026-07-03 08:07:48 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 08:07:48 --> Model "Plan_model" initialized
INFO - 2026-07-03 08:07:48 --> Model "Software_model" initialized
INFO - 2026-07-03 08:07:48 --> Config Class Initialized
INFO - 2026-07-03 08:07:48 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:07:48 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:07:48 --> Utf8 Class Initialized
INFO - 2026-07-03 08:07:48 --> URI Class Initialized
INFO - 2026-07-03 08:07:48 --> Router Class Initialized
INFO - 2026-07-03 08:07:48 --> Output Class Initialized
INFO - 2026-07-03 08:07:48 --> Security Class Initialized
DEBUG - 2026-07-03 08:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:07:48 --> CSRF cookie sent
INFO - 2026-07-03 08:07:48 --> Input Class Initialized
INFO - 2026-07-03 08:07:48 --> Language Class Initialized
INFO - 2026-07-03 08:07:48 --> Language Class Initialized
INFO - 2026-07-03 08:07:48 --> Config Class Initialized
INFO - 2026-07-03 08:07:48 --> Loader Class Initialized
INFO - 2026-07-03 08:07:48 --> Helper loaded: url_helper
INFO - 2026-07-03 08:07:48 --> Helper loaded: form_helper
INFO - 2026-07-03 08:07:48 --> Helper loaded: html_helper
INFO - 2026-07-03 08:07:48 --> Helper loaded: file_helper
INFO - 2026-07-03 08:07:48 --> Helper loaded: email_helper
INFO - 2026-07-03 08:07:48 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:07:48 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:07:48 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:07:48 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:07:48 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:07:48 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:07:48 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:07:48 --> Database Driver Class Initialized
INFO - 2026-07-03 08:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:07:49 --> Upload Class Initialized
DEBUG - 2026-07-03 08:07:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:07:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:07:49 --> Encryption Class Initialized
INFO - 2026-07-03 08:07:49 --> Form Validation Class Initialized
INFO - 2026-07-03 08:07:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:07:49 --> Pagination Class Initialized
INFO - 2026-07-03 08:07:49 --> Email Class Initialized
INFO - 2026-07-03 08:07:49 --> Controller Class Initialized
DEBUG - 2026-07-03 08:07:49 --> Software MX_Controller Initialized
INFO - 2026-07-03 08:07:49 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:07:49 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:07:49 --> Model "Software_model" initialized
DEBUG - 2026-07-03 08:07:49 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 08:07:49 --> Model "Plan_model" initialized
INFO - 2026-07-03 08:07:57 --> Config Class Initialized
INFO - 2026-07-03 08:07:57 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:07:57 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:07:57 --> Utf8 Class Initialized
INFO - 2026-07-03 08:07:57 --> URI Class Initialized
INFO - 2026-07-03 08:07:57 --> Router Class Initialized
INFO - 2026-07-03 08:07:57 --> Output Class Initialized
INFO - 2026-07-03 08:07:57 --> Security Class Initialized
DEBUG - 2026-07-03 08:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:07:57 --> CSRF cookie sent
INFO - 2026-07-03 08:07:57 --> Input Class Initialized
INFO - 2026-07-03 08:07:57 --> Language Class Initialized
INFO - 2026-07-03 08:07:57 --> Language Class Initialized
INFO - 2026-07-03 08:07:57 --> Config Class Initialized
INFO - 2026-07-03 08:07:57 --> Loader Class Initialized
INFO - 2026-07-03 08:07:57 --> Helper loaded: url_helper
INFO - 2026-07-03 08:07:57 --> Helper loaded: form_helper
INFO - 2026-07-03 08:07:57 --> Helper loaded: html_helper
INFO - 2026-07-03 08:07:57 --> Helper loaded: file_helper
INFO - 2026-07-03 08:07:57 --> Helper loaded: email_helper
INFO - 2026-07-03 08:07:57 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:07:57 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:07:57 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:07:57 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:07:57 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:07:57 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:07:57 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:07:57 --> Database Driver Class Initialized
INFO - 2026-07-03 08:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:07:58 --> Upload Class Initialized
DEBUG - 2026-07-03 08:07:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:07:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:07:58 --> Encryption Class Initialized
INFO - 2026-07-03 08:07:58 --> Form Validation Class Initialized
INFO - 2026-07-03 08:07:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:07:58 --> Pagination Class Initialized
INFO - 2026-07-03 08:07:58 --> Email Class Initialized
INFO - 2026-07-03 08:07:58 --> Controller Class Initialized
DEBUG - 2026-07-03 08:07:59 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 08:07:59 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:07:59 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:07:59 --> Model "Dashboard_model" initialized
DEBUG - 2026-07-03 08:07:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 08:07:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 08:07:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 08:07:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-03 08:07:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 08:07:59 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/dashboard_index.php
INFO - 2026-07-03 08:07:59 --> Final output sent to browser
DEBUG - 2026-07-03 08:07:59 --> Total execution time: 1.8693
INFO - 2026-07-03 08:07:59 --> Config Class Initialized
INFO - 2026-07-03 08:07:59 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:07:59 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:07:59 --> Utf8 Class Initialized
INFO - 2026-07-03 08:07:59 --> URI Class Initialized
INFO - 2026-07-03 08:07:59 --> Router Class Initialized
INFO - 2026-07-03 08:07:59 --> Output Class Initialized
INFO - 2026-07-03 08:07:59 --> Security Class Initialized
DEBUG - 2026-07-03 08:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:07:59 --> CSRF cookie sent
INFO - 2026-07-03 08:07:59 --> Input Class Initialized
INFO - 2026-07-03 08:07:59 --> Language Class Initialized
INFO - 2026-07-03 08:07:59 --> Language Class Initialized
INFO - 2026-07-03 08:07:59 --> Config Class Initialized
INFO - 2026-07-03 08:07:59 --> Loader Class Initialized
INFO - 2026-07-03 08:07:59 --> Helper loaded: url_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: form_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: html_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: file_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: email_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:07:59 --> Database Driver Class Initialized
INFO - 2026-07-03 08:07:59 --> Config Class Initialized
INFO - 2026-07-03 08:07:59 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:07:59 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:07:59 --> Utf8 Class Initialized
INFO - 2026-07-03 08:07:59 --> URI Class Initialized
INFO - 2026-07-03 08:07:59 --> Router Class Initialized
INFO - 2026-07-03 08:07:59 --> Output Class Initialized
INFO - 2026-07-03 08:07:59 --> Security Class Initialized
DEBUG - 2026-07-03 08:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:07:59 --> CSRF cookie sent
INFO - 2026-07-03 08:07:59 --> Input Class Initialized
INFO - 2026-07-03 08:07:59 --> Language Class Initialized
INFO - 2026-07-03 08:07:59 --> Language Class Initialized
INFO - 2026-07-03 08:07:59 --> Config Class Initialized
INFO - 2026-07-03 08:07:59 --> Loader Class Initialized
INFO - 2026-07-03 08:07:59 --> Helper loaded: url_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: form_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: html_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: file_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: email_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:07:59 --> Database Driver Class Initialized
INFO - 2026-07-03 08:07:59 --> Config Class Initialized
INFO - 2026-07-03 08:07:59 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:07:59 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:07:59 --> Utf8 Class Initialized
INFO - 2026-07-03 08:07:59 --> URI Class Initialized
INFO - 2026-07-03 08:07:59 --> Config Class Initialized
INFO - 2026-07-03 08:07:59 --> Hooks Class Initialized
INFO - 2026-07-03 08:07:59 --> Router Class Initialized
DEBUG - 2026-07-03 08:07:59 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:07:59 --> Utf8 Class Initialized
INFO - 2026-07-03 08:07:59 --> Output Class Initialized
INFO - 2026-07-03 08:07:59 --> URI Class Initialized
INFO - 2026-07-03 08:07:59 --> Config Class Initialized
INFO - 2026-07-03 08:07:59 --> Hooks Class Initialized
INFO - 2026-07-03 08:07:59 --> Config Class Initialized
INFO - 2026-07-03 08:07:59 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:07:59 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:07:59 --> Utf8 Class Initialized
INFO - 2026-07-03 08:07:59 --> Router Class Initialized
DEBUG - 2026-07-03 08:07:59 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:07:59 --> Utf8 Class Initialized
INFO - 2026-07-03 08:07:59 --> URI Class Initialized
INFO - 2026-07-03 08:07:59 --> URI Class Initialized
INFO - 2026-07-03 08:07:59 --> Security Class Initialized
INFO - 2026-07-03 08:07:59 --> Output Class Initialized
INFO - 2026-07-03 08:07:59 --> Router Class Initialized
DEBUG - 2026-07-03 08:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:07:59 --> CSRF cookie sent
INFO - 2026-07-03 08:07:59 --> Input Class Initialized
INFO - 2026-07-03 08:07:59 --> Security Class Initialized
INFO - 2026-07-03 08:07:59 --> Language Class Initialized
INFO - 2026-07-03 08:07:59 --> Router Class Initialized
INFO - 2026-07-03 08:07:59 --> Language Class Initialized
INFO - 2026-07-03 08:07:59 --> Config Class Initialized
INFO - 2026-07-03 08:07:59 --> Output Class Initialized
INFO - 2026-07-03 08:07:59 --> Output Class Initialized
DEBUG - 2026-07-03 08:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:07:59 --> CSRF cookie sent
INFO - 2026-07-03 08:07:59 --> Security Class Initialized
INFO - 2026-07-03 08:07:59 --> Input Class Initialized
INFO - 2026-07-03 08:07:59 --> Security Class Initialized
INFO - 2026-07-03 08:07:59 --> Loader Class Initialized
INFO - 2026-07-03 08:07:59 --> Language Class Initialized
INFO - 2026-07-03 08:07:59 --> Helper loaded: url_helper
DEBUG - 2026-07-03 08:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:07:59 --> CSRF cookie sent
INFO - 2026-07-03 08:07:59 --> Input Class Initialized
INFO - 2026-07-03 08:07:59 --> Language Class Initialized
DEBUG - 2026-07-03 08:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:07:59 --> Config Class Initialized
INFO - 2026-07-03 08:07:59 --> CSRF cookie sent
INFO - 2026-07-03 08:07:59 --> Input Class Initialized
INFO - 2026-07-03 08:07:59 --> Language Class Initialized
INFO - 2026-07-03 08:07:59 --> Language Class Initialized
INFO - 2026-07-03 08:07:59 --> Helper loaded: form_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: html_helper
INFO - 2026-07-03 08:07:59 --> Language Class Initialized
INFO - 2026-07-03 08:07:59 --> Config Class Initialized
INFO - 2026-07-03 08:07:59 --> Helper loaded: file_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: email_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:07:59 --> Loader Class Initialized
INFO - 2026-07-03 08:07:59 --> Language Class Initialized
INFO - 2026-07-03 08:07:59 --> Config Class Initialized
INFO - 2026-07-03 08:07:59 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: url_helper
INFO - 2026-07-03 08:07:59 --> Loader Class Initialized
INFO - 2026-07-03 08:07:59 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: url_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: form_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: html_helper
INFO - 2026-07-03 08:07:59 --> Loader Class Initialized
INFO - 2026-07-03 08:07:59 --> Helper loaded: form_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: file_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: email_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: html_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: file_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: email_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: url_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: form_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: html_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: file_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: email_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:07:59 --> Database Driver Class Initialized
INFO - 2026-07-03 08:07:59 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:07:59 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:07:59 --> Database Driver Class Initialized
INFO - 2026-07-03 08:07:59 --> Database Driver Class Initialized
INFO - 2026-07-03 08:07:59 --> Database Driver Class Initialized
INFO - 2026-07-03 08:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:08:01 --> Upload Class Initialized
DEBUG - 2026-07-03 08:08:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:08:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:08:01 --> Encryption Class Initialized
INFO - 2026-07-03 08:08:01 --> Form Validation Class Initialized
INFO - 2026-07-03 08:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:08:01 --> Pagination Class Initialized
INFO - 2026-07-03 08:08:01 --> Email Class Initialized
INFO - 2026-07-03 08:08:01 --> Controller Class Initialized
ERROR - 2026-07-03 08:08:01 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:08:01 --> Upload Class Initialized
DEBUG - 2026-07-03 08:08:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:08:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:08:01 --> Encryption Class Initialized
INFO - 2026-07-03 08:08:01 --> Form Validation Class Initialized
INFO - 2026-07-03 08:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:08:01 --> Pagination Class Initialized
INFO - 2026-07-03 08:08:01 --> Config Class Initialized
INFO - 2026-07-03 08:08:01 --> Hooks Class Initialized
INFO - 2026-07-03 08:08:01 --> Email Class Initialized
INFO - 2026-07-03 08:08:01 --> Controller Class Initialized
DEBUG - 2026-07-03 08:08:01 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:08:01 --> Utf8 Class Initialized
ERROR - 2026-07-03 08:08:01 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:08:01 --> URI Class Initialized
INFO - 2026-07-03 08:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:08:01 --> Router Class Initialized
INFO - 2026-07-03 08:08:01 --> Upload Class Initialized
INFO - 2026-07-03 08:08:01 --> Output Class Initialized
DEBUG - 2026-07-03 08:08:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:08:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:08:01 --> Encryption Class Initialized
INFO - 2026-07-03 08:08:01 --> Security Class Initialized
INFO - 2026-07-03 08:08:01 --> Form Validation Class Initialized
DEBUG - 2026-07-03 08:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:08:01 --> Input Class Initialized
INFO - 2026-07-03 08:08:01 --> Language Class Initialized
INFO - 2026-07-03 08:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:08:01 --> Pagination Class Initialized
INFO - 2026-07-03 08:08:01 --> Language Class Initialized
INFO - 2026-07-03 08:08:01 --> Config Class Initialized
INFO - 2026-07-03 08:08:01 --> Loader Class Initialized
INFO - 2026-07-03 08:08:01 --> Config Class Initialized
INFO - 2026-07-03 08:08:01 --> Hooks Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: url_helper
INFO - 2026-07-03 08:08:01 --> Email Class Initialized
INFO - 2026-07-03 08:08:01 --> Controller Class Initialized
ERROR - 2026-07-03 08:08:01 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:08:01 --> Helper loaded: form_helper
DEBUG - 2026-07-03 08:08:01 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:08:01 --> Utf8 Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: html_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: file_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: email_helper
INFO - 2026-07-03 08:08:01 --> URI Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:08:01 --> Upload Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:08:01 --> Router Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:08:01 --> Output Class Initialized
DEBUG - 2026-07-03 08:08:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:08:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:08:01 --> Encryption Class Initialized
INFO - 2026-07-03 08:08:01 --> Security Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:08:01 --> Form Validation Class Initialized
DEBUG - 2026-07-03 08:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:08:01 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:08:01 --> Input Class Initialized
INFO - 2026-07-03 08:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:08:01 --> Pagination Class Initialized
INFO - 2026-07-03 08:08:01 --> Language Class Initialized
INFO - 2026-07-03 08:08:01 --> Language Class Initialized
INFO - 2026-07-03 08:08:01 --> Config Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:08:01 --> Email Class Initialized
INFO - 2026-07-03 08:08:01 --> Config Class Initialized
INFO - 2026-07-03 08:08:01 --> Hooks Class Initialized
INFO - 2026-07-03 08:08:01 --> Controller Class Initialized
ERROR - 2026-07-03 08:08:01 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:08:01 --> Loader Class Initialized
DEBUG - 2026-07-03 08:08:01 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:08:01 --> Utf8 Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: url_helper
INFO - 2026-07-03 08:08:01 --> URI Class Initialized
INFO - 2026-07-03 08:08:01 --> Upload Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: form_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: html_helper
DEBUG - 2026-07-03 08:08:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:08:01 --> Helper loaded: file_helper
INFO - 2026-07-03 08:08:01 --> Router Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: email_helper
INFO - 2026-07-03 08:08:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:08:01 --> Encryption Class Initialized
INFO - 2026-07-03 08:08:01 --> Database Driver Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:08:01 --> Output Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:08:01 --> Security Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: cpanel_helper
DEBUG - 2026-07-03 08:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:08:01 --> Input Class Initialized
INFO - 2026-07-03 08:08:01 --> Language Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:08:01 --> Language Class Initialized
INFO - 2026-07-03 08:08:01 --> Config Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:08:01 --> Form Validation Class Initialized
INFO - 2026-07-03 08:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:08:01 --> Pagination Class Initialized
INFO - 2026-07-03 08:08:01 --> Loader Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: url_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: form_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: html_helper
INFO - 2026-07-03 08:08:01 --> Email Class Initialized
INFO - 2026-07-03 08:08:01 --> Controller Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: file_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: email_helper
ERROR - 2026-07-03 08:08:01 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:08:01 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:08:01 --> Config Class Initialized
INFO - 2026-07-03 08:08:01 --> Hooks Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:08:01 --> Upload Class Initialized
DEBUG - 2026-07-03 08:08:01 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:08:01 --> Utf8 Class Initialized
INFO - 2026-07-03 08:08:01 --> URI Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: cpanel_helper
DEBUG - 2026-07-03 08:08:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:08:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:08:01 --> Encryption Class Initialized
INFO - 2026-07-03 08:08:01 --> Database Driver Class Initialized
INFO - 2026-07-03 08:08:01 --> Router Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:08:01 --> Form Validation Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:08:01 --> Pagination Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:08:01 --> Output Class Initialized
INFO - 2026-07-03 08:08:01 --> Email Class Initialized
INFO - 2026-07-03 08:08:01 --> Controller Class Initialized
ERROR - 2026-07-03 08:08:01 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:08:01 --> Security Class Initialized
DEBUG - 2026-07-03 08:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:08:01 --> Input Class Initialized
INFO - 2026-07-03 08:08:01 --> Language Class Initialized
INFO - 2026-07-03 08:08:01 --> Config Class Initialized
INFO - 2026-07-03 08:08:01 --> Hooks Class Initialized
INFO - 2026-07-03 08:08:01 --> Language Class Initialized
INFO - 2026-07-03 08:08:01 --> Config Class Initialized
INFO - 2026-07-03 08:08:01 --> Database Driver Class Initialized
DEBUG - 2026-07-03 08:08:01 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:08:01 --> Utf8 Class Initialized
INFO - 2026-07-03 08:08:01 --> URI Class Initialized
INFO - 2026-07-03 08:08:01 --> Loader Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: url_helper
INFO - 2026-07-03 08:08:01 --> Config Class Initialized
INFO - 2026-07-03 08:08:01 --> Hooks Class Initialized
INFO - 2026-07-03 08:08:01 --> Router Class Initialized
DEBUG - 2026-07-03 08:08:01 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:08:01 --> Utf8 Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: form_helper
INFO - 2026-07-03 08:08:01 --> URI Class Initialized
INFO - 2026-07-03 08:08:01 --> Output Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: html_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: file_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: email_helper
INFO - 2026-07-03 08:08:01 --> Router Class Initialized
INFO - 2026-07-03 08:08:01 --> Security Class Initialized
INFO - 2026-07-03 08:08:01 --> Output Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: whmaz_helper
DEBUG - 2026-07-03 08:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:08:01 --> Input Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:08:01 --> Security Class Initialized
INFO - 2026-07-03 08:08:01 --> Language Class Initialized
DEBUG - 2026-07-03 08:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:08:01 --> Input Class Initialized
INFO - 2026-07-03 08:08:01 --> Language Class Initialized
INFO - 2026-07-03 08:08:01 --> Language Class Initialized
INFO - 2026-07-03 08:08:01 --> Config Class Initialized
INFO - 2026-07-03 08:08:01 --> Language Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:08:01 --> Config Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:08:01 --> Loader Class Initialized
INFO - 2026-07-03 08:08:01 --> Loader Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: url_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: url_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: form_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: html_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: file_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: email_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: form_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: html_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: file_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: email_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:08:01 --> Database Driver Class Initialized
INFO - 2026-07-03 08:08:01 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:08:01 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:08:01 --> Database Driver Class Initialized
INFO - 2026-07-03 08:08:01 --> Database Driver Class Initialized
INFO - 2026-07-03 08:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:08:03 --> Upload Class Initialized
DEBUG - 2026-07-03 08:08:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:08:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:08:03 --> Encryption Class Initialized
INFO - 2026-07-03 08:08:03 --> Form Validation Class Initialized
INFO - 2026-07-03 08:08:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:08:03 --> Pagination Class Initialized
INFO - 2026-07-03 08:08:03 --> Email Class Initialized
INFO - 2026-07-03 08:08:03 --> Controller Class Initialized
DEBUG - 2026-07-03 08:08:03 --> Order MX_Controller Initialized
INFO - 2026-07-03 08:08:03 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:08:03 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:08:03 --> Model "Order_model" initialized
INFO - 2026-07-03 08:08:03 --> Model "Common_model" initialized
INFO - 2026-07-03 08:08:03 --> Model "Currency_model" initialized
INFO - 2026-07-03 08:08:04 --> Final output sent to browser
DEBUG - 2026-07-03 08:08:04 --> Total execution time: 2.4397
INFO - 2026-07-03 08:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:08:04 --> Upload Class Initialized
DEBUG - 2026-07-03 08:08:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:08:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:08:04 --> Encryption Class Initialized
INFO - 2026-07-03 08:08:04 --> Form Validation Class Initialized
INFO - 2026-07-03 08:08:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:08:04 --> Pagination Class Initialized
INFO - 2026-07-03 08:08:04 --> Config Class Initialized
INFO - 2026-07-03 08:08:04 --> Hooks Class Initialized
INFO - 2026-07-03 08:08:04 --> Email Class Initialized
INFO - 2026-07-03 08:08:04 --> Controller Class Initialized
DEBUG - 2026-07-03 08:08:04 --> Dashboard MX_Controller Initialized
DEBUG - 2026-07-03 08:08:04 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:08:04 --> Utf8 Class Initialized
INFO - 2026-07-03 08:08:04 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:08:04 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:08:04 --> URI Class Initialized
INFO - 2026-07-03 08:08:04 --> Router Class Initialized
INFO - 2026-07-03 08:08:04 --> Output Class Initialized
INFO - 2026-07-03 08:08:04 --> Security Class Initialized
DEBUG - 2026-07-03 08:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:08:04 --> CSRF cookie sent
INFO - 2026-07-03 08:08:04 --> Input Class Initialized
INFO - 2026-07-03 08:08:04 --> Language Class Initialized
INFO - 2026-07-03 08:08:04 --> Language Class Initialized
INFO - 2026-07-03 08:08:04 --> Config Class Initialized
INFO - 2026-07-03 08:08:04 --> Loader Class Initialized
INFO - 2026-07-03 08:08:04 --> Helper loaded: url_helper
INFO - 2026-07-03 08:08:04 --> Helper loaded: form_helper
INFO - 2026-07-03 08:08:04 --> Helper loaded: html_helper
INFO - 2026-07-03 08:08:04 --> Helper loaded: file_helper
INFO - 2026-07-03 08:08:04 --> Helper loaded: email_helper
INFO - 2026-07-03 08:08:04 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:08:04 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:08:04 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:08:04 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:08:04 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:08:04 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:08:04 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:08:04 --> Database Driver Class Initialized
INFO - 2026-07-03 08:08:04 --> Model "Dashboard_model" initialized
INFO - 2026-07-03 08:08:04 --> Final output sent to browser
DEBUG - 2026-07-03 08:08:04 --> Total execution time: 3.0610
INFO - 2026-07-03 08:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:08:04 --> Upload Class Initialized
DEBUG - 2026-07-03 08:08:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:08:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:08:04 --> Encryption Class Initialized
INFO - 2026-07-03 08:08:04 --> Form Validation Class Initialized
INFO - 2026-07-03 08:08:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:08:04 --> Pagination Class Initialized
INFO - 2026-07-03 08:08:04 --> Config Class Initialized
INFO - 2026-07-03 08:08:04 --> Hooks Class Initialized
INFO - 2026-07-03 08:08:04 --> Email Class Initialized
INFO - 2026-07-03 08:08:04 --> Controller Class Initialized
DEBUG - 2026-07-03 08:08:04 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:08:04 --> Utf8 Class Initialized
DEBUG - 2026-07-03 08:08:04 --> Invoice MX_Controller Initialized
INFO - 2026-07-03 08:08:04 --> URI Class Initialized
INFO - 2026-07-03 08:08:04 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:08:04 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:08:04 --> Model "Billing_model" initialized
INFO - 2026-07-03 08:08:04 --> Model "Common_model" initialized
INFO - 2026-07-03 08:08:04 --> Router Class Initialized
INFO - 2026-07-03 08:08:04 --> Model "Invoice_model" initialized
INFO - 2026-07-03 08:08:04 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 08:08:04 --> Output Class Initialized
INFO - 2026-07-03 08:08:04 --> Security Class Initialized
DEBUG - 2026-07-03 08:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:08:04 --> CSRF cookie sent
INFO - 2026-07-03 08:08:04 --> Input Class Initialized
INFO - 2026-07-03 08:08:04 --> Language Class Initialized
INFO - 2026-07-03 08:08:04 --> Language Class Initialized
INFO - 2026-07-03 08:08:04 --> Config Class Initialized
INFO - 2026-07-03 08:08:04 --> Loader Class Initialized
INFO - 2026-07-03 08:08:04 --> Helper loaded: url_helper
INFO - 2026-07-03 08:08:04 --> Helper loaded: form_helper
INFO - 2026-07-03 08:08:04 --> Helper loaded: html_helper
INFO - 2026-07-03 08:08:04 --> Helper loaded: file_helper
INFO - 2026-07-03 08:08:04 --> Helper loaded: email_helper
INFO - 2026-07-03 08:08:04 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:08:04 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:08:04 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:08:04 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:08:04 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:08:04 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:08:04 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:08:04 --> Database Driver Class Initialized
INFO - 2026-07-03 08:08:05 --> Final output sent to browser
DEBUG - 2026-07-03 08:08:05 --> Total execution time: 3.6586
INFO - 2026-07-03 08:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:08:05 --> Upload Class Initialized
DEBUG - 2026-07-03 08:08:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:08:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:08:05 --> Encryption Class Initialized
INFO - 2026-07-03 08:08:05 --> Form Validation Class Initialized
INFO - 2026-07-03 08:08:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:08:05 --> Pagination Class Initialized
INFO - 2026-07-03 08:08:05 --> Email Class Initialized
INFO - 2026-07-03 08:08:05 --> Controller Class Initialized
DEBUG - 2026-07-03 08:08:05 --> Ticket MX_Controller Initialized
INFO - 2026-07-03 08:08:05 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:08:05 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:08:05 --> Model "Support_model" initialized
INFO - 2026-07-03 08:08:05 --> Model "Common_model" initialized
INFO - 2026-07-03 08:08:05 --> Final output sent to browser
DEBUG - 2026-07-03 08:08:05 --> Total execution time: 4.2810
INFO - 2026-07-03 08:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:08:05 --> Upload Class Initialized
DEBUG - 2026-07-03 08:08:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:08:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:08:05 --> Encryption Class Initialized
INFO - 2026-07-03 08:08:05 --> Form Validation Class Initialized
INFO - 2026-07-03 08:08:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:08:05 --> Pagination Class Initialized
INFO - 2026-07-03 08:08:05 --> Email Class Initialized
INFO - 2026-07-03 08:08:05 --> Controller Class Initialized
DEBUG - 2026-07-03 08:08:05 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 08:08:05 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:08:05 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:08:06 --> Model "Dashboard_model" initialized
INFO - 2026-07-03 08:08:06 --> Final output sent to browser
DEBUG - 2026-07-03 08:08:06 --> Total execution time: 4.9796
INFO - 2026-07-03 08:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:08:06 --> Upload Class Initialized
DEBUG - 2026-07-03 08:08:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:08:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:08:06 --> Encryption Class Initialized
INFO - 2026-07-03 08:08:06 --> Form Validation Class Initialized
INFO - 2026-07-03 08:08:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:08:06 --> Pagination Class Initialized
INFO - 2026-07-03 08:08:06 --> Email Class Initialized
INFO - 2026-07-03 08:08:06 --> Controller Class Initialized
DEBUG - 2026-07-03 08:08:06 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 08:08:06 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:08:06 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:08:06 --> Model "Dashboard_model" initialized
INFO - 2026-07-03 08:08:07 --> Final output sent to browser
DEBUG - 2026-07-03 08:08:07 --> Total execution time: 5.8023
INFO - 2026-07-03 08:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:08:07 --> Upload Class Initialized
DEBUG - 2026-07-03 08:08:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:08:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:08:07 --> Encryption Class Initialized
INFO - 2026-07-03 08:08:07 --> Form Validation Class Initialized
INFO - 2026-07-03 08:08:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:08:07 --> Pagination Class Initialized
INFO - 2026-07-03 08:08:07 --> Email Class Initialized
INFO - 2026-07-03 08:08:07 --> Controller Class Initialized
ERROR - 2026-07-03 08:08:07 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:08:07 --> Upload Class Initialized
DEBUG - 2026-07-03 08:08:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:08:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:08:07 --> Encryption Class Initialized
INFO - 2026-07-03 08:08:07 --> Form Validation Class Initialized
INFO - 2026-07-03 08:08:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:08:07 --> Pagination Class Initialized
INFO - 2026-07-03 08:08:07 --> Email Class Initialized
INFO - 2026-07-03 08:08:07 --> Controller Class Initialized
DEBUG - 2026-07-03 08:08:07 --> Software MX_Controller Initialized
INFO - 2026-07-03 08:08:07 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:08:07 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:08:07 --> Model "Software_model" initialized
DEBUG - 2026-07-03 08:08:07 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 08:08:07 --> Model "Plan_model" initialized
DEBUG - 2026-07-03 08:08:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 08:08:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 08:08:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 08:08:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 08:08:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/software_manage.php
INFO - 2026-07-03 08:08:08 --> Final output sent to browser
DEBUG - 2026-07-03 08:08:08 --> Total execution time: 4.0664
INFO - 2026-07-03 08:09:22 --> Config Class Initialized
INFO - 2026-07-03 08:09:22 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:09:22 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:09:22 --> Utf8 Class Initialized
INFO - 2026-07-03 08:09:22 --> URI Class Initialized
INFO - 2026-07-03 08:09:22 --> Router Class Initialized
INFO - 2026-07-03 08:09:22 --> Output Class Initialized
INFO - 2026-07-03 08:09:22 --> Security Class Initialized
DEBUG - 2026-07-03 08:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:09:22 --> CSRF cookie sent
INFO - 2026-07-03 08:09:22 --> Input Class Initialized
INFO - 2026-07-03 08:09:22 --> Language Class Initialized
INFO - 2026-07-03 08:09:22 --> Language Class Initialized
INFO - 2026-07-03 08:09:22 --> Config Class Initialized
INFO - 2026-07-03 08:09:22 --> Loader Class Initialized
INFO - 2026-07-03 08:09:22 --> Helper loaded: url_helper
INFO - 2026-07-03 08:09:22 --> Helper loaded: form_helper
INFO - 2026-07-03 08:09:22 --> Helper loaded: html_helper
INFO - 2026-07-03 08:09:22 --> Helper loaded: file_helper
INFO - 2026-07-03 08:09:22 --> Helper loaded: email_helper
INFO - 2026-07-03 08:09:22 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:09:22 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:09:22 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:09:22 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:09:22 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:09:22 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:09:22 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:09:22 --> Database Driver Class Initialized
INFO - 2026-07-03 08:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:09:24 --> Upload Class Initialized
DEBUG - 2026-07-03 08:09:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:09:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:09:24 --> Encryption Class Initialized
INFO - 2026-07-03 08:09:24 --> Form Validation Class Initialized
INFO - 2026-07-03 08:09:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:09:24 --> Pagination Class Initialized
INFO - 2026-07-03 08:09:24 --> Email Class Initialized
INFO - 2026-07-03 08:09:24 --> Controller Class Initialized
DEBUG - 2026-07-03 08:09:24 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 08:09:24 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:09:24 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:09:24 --> Model "Dashboard_model" initialized
DEBUG - 2026-07-03 08:09:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 08:09:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 08:09:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 08:09:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-03 08:09:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 08:09:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/dashboard_index.php
INFO - 2026-07-03 08:09:24 --> Final output sent to browser
DEBUG - 2026-07-03 08:09:24 --> Total execution time: 1.9906
INFO - 2026-07-03 08:09:24 --> Config Class Initialized
INFO - 2026-07-03 08:09:24 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:09:24 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:09:24 --> Utf8 Class Initialized
INFO - 2026-07-03 08:09:24 --> URI Class Initialized
INFO - 2026-07-03 08:09:24 --> Router Class Initialized
INFO - 2026-07-03 08:09:24 --> Output Class Initialized
INFO - 2026-07-03 08:09:24 --> Security Class Initialized
DEBUG - 2026-07-03 08:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:09:24 --> CSRF cookie sent
INFO - 2026-07-03 08:09:24 --> Input Class Initialized
INFO - 2026-07-03 08:09:24 --> Language Class Initialized
INFO - 2026-07-03 08:09:24 --> Language Class Initialized
INFO - 2026-07-03 08:09:24 --> Config Class Initialized
INFO - 2026-07-03 08:09:24 --> Loader Class Initialized
INFO - 2026-07-03 08:09:24 --> Helper loaded: url_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: form_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: html_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: file_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: email_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:09:24 --> Database Driver Class Initialized
INFO - 2026-07-03 08:09:24 --> Config Class Initialized
INFO - 2026-07-03 08:09:24 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:09:24 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:09:24 --> Utf8 Class Initialized
INFO - 2026-07-03 08:09:24 --> URI Class Initialized
INFO - 2026-07-03 08:09:24 --> Router Class Initialized
INFO - 2026-07-03 08:09:24 --> Output Class Initialized
INFO - 2026-07-03 08:09:24 --> Security Class Initialized
DEBUG - 2026-07-03 08:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:09:24 --> CSRF cookie sent
INFO - 2026-07-03 08:09:24 --> Input Class Initialized
INFO - 2026-07-03 08:09:24 --> Language Class Initialized
INFO - 2026-07-03 08:09:24 --> Language Class Initialized
INFO - 2026-07-03 08:09:24 --> Config Class Initialized
INFO - 2026-07-03 08:09:24 --> Loader Class Initialized
INFO - 2026-07-03 08:09:24 --> Helper loaded: url_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: form_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: html_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: file_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: email_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:09:24 --> Database Driver Class Initialized
INFO - 2026-07-03 08:09:24 --> Config Class Initialized
INFO - 2026-07-03 08:09:24 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:09:24 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:09:24 --> Utf8 Class Initialized
INFO - 2026-07-03 08:09:24 --> URI Class Initialized
INFO - 2026-07-03 08:09:24 --> Config Class Initialized
INFO - 2026-07-03 08:09:24 --> Hooks Class Initialized
INFO - 2026-07-03 08:09:24 --> Router Class Initialized
DEBUG - 2026-07-03 08:09:24 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:09:24 --> Utf8 Class Initialized
INFO - 2026-07-03 08:09:24 --> Output Class Initialized
INFO - 2026-07-03 08:09:24 --> URI Class Initialized
INFO - 2026-07-03 08:09:24 --> Security Class Initialized
INFO - 2026-07-03 08:09:24 --> Config Class Initialized
INFO - 2026-07-03 08:09:24 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:09:24 --> CSRF cookie sent
INFO - 2026-07-03 08:09:24 --> Input Class Initialized
INFO - 2026-07-03 08:09:24 --> Language Class Initialized
INFO - 2026-07-03 08:09:24 --> Router Class Initialized
DEBUG - 2026-07-03 08:09:24 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:09:24 --> Utf8 Class Initialized
INFO - 2026-07-03 08:09:24 --> Language Class Initialized
INFO - 2026-07-03 08:09:24 --> Config Class Initialized
INFO - 2026-07-03 08:09:24 --> Config Class Initialized
INFO - 2026-07-03 08:09:24 --> Hooks Class Initialized
INFO - 2026-07-03 08:09:24 --> Output Class Initialized
INFO - 2026-07-03 08:09:24 --> URI Class Initialized
DEBUG - 2026-07-03 08:09:24 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:09:24 --> Utf8 Class Initialized
INFO - 2026-07-03 08:09:24 --> Loader Class Initialized
INFO - 2026-07-03 08:09:24 --> URI Class Initialized
INFO - 2026-07-03 08:09:24 --> Security Class Initialized
INFO - 2026-07-03 08:09:24 --> Helper loaded: url_helper
INFO - 2026-07-03 08:09:24 --> Router Class Initialized
DEBUG - 2026-07-03 08:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:09:24 --> CSRF cookie sent
INFO - 2026-07-03 08:09:24 --> Input Class Initialized
INFO - 2026-07-03 08:09:24 --> Helper loaded: form_helper
INFO - 2026-07-03 08:09:24 --> Language Class Initialized
INFO - 2026-07-03 08:09:24 --> Router Class Initialized
INFO - 2026-07-03 08:09:24 --> Helper loaded: html_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: file_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: email_helper
INFO - 2026-07-03 08:09:24 --> Output Class Initialized
INFO - 2026-07-03 08:09:24 --> Language Class Initialized
INFO - 2026-07-03 08:09:24 --> Config Class Initialized
INFO - 2026-07-03 08:09:24 --> Output Class Initialized
INFO - 2026-07-03 08:09:24 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:09:24 --> Security Class Initialized
INFO - 2026-07-03 08:09:24 --> Security Class Initialized
INFO - 2026-07-03 08:09:24 --> Helper loaded: cpanel_helper
DEBUG - 2026-07-03 08:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:09:24 --> CSRF cookie sent
INFO - 2026-07-03 08:09:24 --> Input Class Initialized
INFO - 2026-07-03 08:09:24 --> Loader Class Initialized
INFO - 2026-07-03 08:09:24 --> Language Class Initialized
INFO - 2026-07-03 08:09:24 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:09:24 --> Language Class Initialized
INFO - 2026-07-03 08:09:24 --> Helper loaded: url_helper
INFO - 2026-07-03 08:09:24 --> Config Class Initialized
INFO - 2026-07-03 08:09:24 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: form_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: html_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: file_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: email_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: domain_helper
DEBUG - 2026-07-03 08:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:09:24 --> CSRF cookie sent
INFO - 2026-07-03 08:09:24 --> Input Class Initialized
INFO - 2026-07-03 08:09:24 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:09:24 --> Language Class Initialized
INFO - 2026-07-03 08:09:24 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:09:24 --> Loader Class Initialized
INFO - 2026-07-03 08:09:24 --> Language Class Initialized
INFO - 2026-07-03 08:09:24 --> Config Class Initialized
INFO - 2026-07-03 08:09:24 --> Helper loaded: url_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: form_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: html_helper
INFO - 2026-07-03 08:09:24 --> Loader Class Initialized
INFO - 2026-07-03 08:09:24 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: file_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: email_helper
INFO - 2026-07-03 08:09:24 --> Database Driver Class Initialized
INFO - 2026-07-03 08:09:24 --> Helper loaded: url_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: form_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: html_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: file_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: email_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:09:24 --> Database Driver Class Initialized
INFO - 2026-07-03 08:09:24 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:09:24 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:09:24 --> Database Driver Class Initialized
INFO - 2026-07-03 08:09:24 --> Database Driver Class Initialized
INFO - 2026-07-03 08:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:09:26 --> Upload Class Initialized
DEBUG - 2026-07-03 08:09:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:09:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:09:26 --> Encryption Class Initialized
INFO - 2026-07-03 08:09:26 --> Form Validation Class Initialized
INFO - 2026-07-03 08:09:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:09:26 --> Pagination Class Initialized
INFO - 2026-07-03 08:09:26 --> Email Class Initialized
INFO - 2026-07-03 08:09:26 --> Controller Class Initialized
ERROR - 2026-07-03 08:09:26 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:09:26 --> Upload Class Initialized
DEBUG - 2026-07-03 08:09:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:09:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:09:26 --> Encryption Class Initialized
INFO - 2026-07-03 08:09:26 --> Form Validation Class Initialized
INFO - 2026-07-03 08:09:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:09:26 --> Pagination Class Initialized
INFO - 2026-07-03 08:09:26 --> Email Class Initialized
INFO - 2026-07-03 08:09:26 --> Controller Class Initialized
INFO - 2026-07-03 08:09:26 --> Config Class Initialized
INFO - 2026-07-03 08:09:26 --> Hooks Class Initialized
ERROR - 2026-07-03 08:09:26 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:09:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-07-03 08:09:26 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:09:26 --> Utf8 Class Initialized
INFO - 2026-07-03 08:09:26 --> URI Class Initialized
INFO - 2026-07-03 08:09:26 --> Upload Class Initialized
INFO - 2026-07-03 08:09:26 --> Router Class Initialized
DEBUG - 2026-07-03 08:09:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:09:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:09:26 --> Encryption Class Initialized
INFO - 2026-07-03 08:09:26 --> Output Class Initialized
INFO - 2026-07-03 08:09:26 --> Security Class Initialized
INFO - 2026-07-03 08:09:26 --> Form Validation Class Initialized
DEBUG - 2026-07-03 08:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:09:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:09:26 --> Pagination Class Initialized
INFO - 2026-07-03 08:09:26 --> Input Class Initialized
INFO - 2026-07-03 08:09:26 --> Language Class Initialized
INFO - 2026-07-03 08:09:26 --> Language Class Initialized
INFO - 2026-07-03 08:09:26 --> Config Class Initialized
INFO - 2026-07-03 08:09:26 --> Config Class Initialized
INFO - 2026-07-03 08:09:26 --> Hooks Class Initialized
INFO - 2026-07-03 08:09:26 --> Loader Class Initialized
DEBUG - 2026-07-03 08:09:26 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:09:26 --> Utf8 Class Initialized
INFO - 2026-07-03 08:09:26 --> Email Class Initialized
INFO - 2026-07-03 08:09:26 --> Controller Class Initialized
INFO - 2026-07-03 08:09:26 --> URI Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: url_helper
ERROR - 2026-07-03 08:09:26 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:09:26 --> Helper loaded: form_helper
INFO - 2026-07-03 08:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:09:26 --> Router Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: html_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: file_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: email_helper
INFO - 2026-07-03 08:09:26 --> Output Class Initialized
INFO - 2026-07-03 08:09:26 --> Upload Class Initialized
INFO - 2026-07-03 08:09:26 --> Security Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: ssp_helper
DEBUG - 2026-07-03 08:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2026-07-03 08:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:09:26 --> Input Class Initialized
INFO - 2026-07-03 08:09:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:09:26 --> Encryption Class Initialized
INFO - 2026-07-03 08:09:26 --> Language Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:09:26 --> Language Class Initialized
INFO - 2026-07-03 08:09:26 --> Config Class Initialized
INFO - 2026-07-03 08:09:26 --> Form Validation Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:09:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:09:26 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:09:26 --> Pagination Class Initialized
INFO - 2026-07-03 08:09:26 --> Loader Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: url_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: form_helper
INFO - 2026-07-03 08:09:26 --> Email Class Initialized
INFO - 2026-07-03 08:09:26 --> Config Class Initialized
INFO - 2026-07-03 08:09:26 --> Controller Class Initialized
INFO - 2026-07-03 08:09:26 --> Hooks Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: html_helper
ERROR - 2026-07-03 08:09:26 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:09:26 --> Helper loaded: file_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: email_helper
DEBUG - 2026-07-03 08:09:26 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:09:26 --> Utf8 Class Initialized
INFO - 2026-07-03 08:09:26 --> URI Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:09:26 --> Upload Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:09:26 --> Database Driver Class Initialized
INFO - 2026-07-03 08:09:26 --> Router Class Initialized
DEBUG - 2026-07-03 08:09:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:09:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:09:26 --> Encryption Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:09:26 --> Output Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:09:26 --> Form Validation Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:09:26 --> Security Class Initialized
DEBUG - 2026-07-03 08:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:09:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:09:26 --> Pagination Class Initialized
INFO - 2026-07-03 08:09:26 --> Input Class Initialized
INFO - 2026-07-03 08:09:26 --> Language Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:09:26 --> Config Class Initialized
INFO - 2026-07-03 08:09:26 --> Hooks Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:09:26 --> Language Class Initialized
INFO - 2026-07-03 08:09:26 --> Config Class Initialized
DEBUG - 2026-07-03 08:09:26 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:09:26 --> Utf8 Class Initialized
INFO - 2026-07-03 08:09:26 --> URI Class Initialized
INFO - 2026-07-03 08:09:26 --> Email Class Initialized
INFO - 2026-07-03 08:09:26 --> Controller Class Initialized
INFO - 2026-07-03 08:09:26 --> Router Class Initialized
ERROR - 2026-07-03 08:09:26 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:09:26 --> Loader Class Initialized
INFO - 2026-07-03 08:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:09:26 --> Output Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: url_helper
INFO - 2026-07-03 08:09:26 --> Upload Class Initialized
INFO - 2026-07-03 08:09:26 --> Security Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: form_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: html_helper
INFO - 2026-07-03 08:09:26 --> Database Driver Class Initialized
DEBUG - 2026-07-03 08:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-07-03 08:09:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:09:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:09:26 --> Encryption Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: file_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: email_helper
INFO - 2026-07-03 08:09:26 --> Input Class Initialized
INFO - 2026-07-03 08:09:26 --> Language Class Initialized
INFO - 2026-07-03 08:09:26 --> Language Class Initialized
INFO - 2026-07-03 08:09:26 --> Config Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:09:26 --> Form Validation Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:09:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:09:26 --> Pagination Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:09:26 --> Loader Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: url_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: form_helper
INFO - 2026-07-03 08:09:26 --> Email Class Initialized
INFO - 2026-07-03 08:09:26 --> Controller Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: html_helper
ERROR - 2026-07-03 08:09:26 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:09:26 --> Helper loaded: file_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: email_helper
INFO - 2026-07-03 08:09:26 --> Config Class Initialized
INFO - 2026-07-03 08:09:26 --> Hooks Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: whmaz_helper
DEBUG - 2026-07-03 08:09:26 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:09:26 --> Utf8 Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:09:26 --> URI Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:09:26 --> Router Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:09:26 --> Output Class Initialized
INFO - 2026-07-03 08:09:26 --> Database Driver Class Initialized
INFO - 2026-07-03 08:09:26 --> Security Class Initialized
DEBUG - 2026-07-03 08:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:09:26 --> Input Class Initialized
INFO - 2026-07-03 08:09:26 --> Language Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:09:26 --> Language Class Initialized
INFO - 2026-07-03 08:09:26 --> Config Class Initialized
INFO - 2026-07-03 08:09:26 --> Config Class Initialized
INFO - 2026-07-03 08:09:26 --> Hooks Class Initialized
INFO - 2026-07-03 08:09:26 --> Loader Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: url_helper
DEBUG - 2026-07-03 08:09:26 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:09:26 --> Utf8 Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: form_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: html_helper
INFO - 2026-07-03 08:09:26 --> URI Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: file_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: email_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:09:26 --> Router Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:09:26 --> Database Driver Class Initialized
INFO - 2026-07-03 08:09:26 --> Output Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:09:26 --> Security Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: directadmin_helper
DEBUG - 2026-07-03 08:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:09:26 --> Input Class Initialized
INFO - 2026-07-03 08:09:26 --> Language Class Initialized
INFO - 2026-07-03 08:09:26 --> Language Class Initialized
INFO - 2026-07-03 08:09:26 --> Config Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:09:26 --> Loader Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: url_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: form_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: html_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: file_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: email_helper
INFO - 2026-07-03 08:09:26 --> Database Driver Class Initialized
INFO - 2026-07-03 08:09:26 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:09:26 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:09:26 --> Database Driver Class Initialized
INFO - 2026-07-03 08:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:09:27 --> Upload Class Initialized
DEBUG - 2026-07-03 08:09:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:09:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:09:27 --> Encryption Class Initialized
INFO - 2026-07-03 08:09:27 --> Form Validation Class Initialized
INFO - 2026-07-03 08:09:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:09:27 --> Pagination Class Initialized
INFO - 2026-07-03 08:09:27 --> Email Class Initialized
INFO - 2026-07-03 08:09:27 --> Controller Class Initialized
DEBUG - 2026-07-03 08:09:27 --> Order MX_Controller Initialized
INFO - 2026-07-03 08:09:27 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:09:27 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:09:28 --> Model "Order_model" initialized
INFO - 2026-07-03 08:09:28 --> Model "Common_model" initialized
INFO - 2026-07-03 08:09:28 --> Model "Currency_model" initialized
INFO - 2026-07-03 08:09:28 --> Final output sent to browser
DEBUG - 2026-07-03 08:09:28 --> Total execution time: 2.3639
INFO - 2026-07-03 08:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:09:28 --> Upload Class Initialized
DEBUG - 2026-07-03 08:09:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:09:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:09:28 --> Encryption Class Initialized
INFO - 2026-07-03 08:09:28 --> Form Validation Class Initialized
INFO - 2026-07-03 08:09:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:09:28 --> Pagination Class Initialized
INFO - 2026-07-03 08:09:28 --> Config Class Initialized
INFO - 2026-07-03 08:09:28 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:09:28 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:09:28 --> Email Class Initialized
INFO - 2026-07-03 08:09:28 --> Utf8 Class Initialized
INFO - 2026-07-03 08:09:28 --> Controller Class Initialized
INFO - 2026-07-03 08:09:28 --> URI Class Initialized
DEBUG - 2026-07-03 08:09:28 --> Invoice MX_Controller Initialized
INFO - 2026-07-03 08:09:28 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:09:28 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:09:28 --> Model "Billing_model" initialized
INFO - 2026-07-03 08:09:28 --> Router Class Initialized
INFO - 2026-07-03 08:09:28 --> Model "Common_model" initialized
INFO - 2026-07-03 08:09:28 --> Model "Invoice_model" initialized
INFO - 2026-07-03 08:09:28 --> Output Class Initialized
INFO - 2026-07-03 08:09:28 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 08:09:28 --> Security Class Initialized
DEBUG - 2026-07-03 08:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:09:28 --> CSRF cookie sent
INFO - 2026-07-03 08:09:28 --> Input Class Initialized
INFO - 2026-07-03 08:09:28 --> Language Class Initialized
INFO - 2026-07-03 08:09:28 --> Language Class Initialized
INFO - 2026-07-03 08:09:28 --> Config Class Initialized
INFO - 2026-07-03 08:09:28 --> Loader Class Initialized
INFO - 2026-07-03 08:09:28 --> Helper loaded: url_helper
INFO - 2026-07-03 08:09:28 --> Helper loaded: form_helper
INFO - 2026-07-03 08:09:28 --> Helper loaded: html_helper
INFO - 2026-07-03 08:09:28 --> Helper loaded: file_helper
INFO - 2026-07-03 08:09:28 --> Helper loaded: email_helper
INFO - 2026-07-03 08:09:28 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:09:28 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:09:28 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:09:28 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:09:28 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:09:28 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:09:28 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:09:28 --> Database Driver Class Initialized
INFO - 2026-07-03 08:09:29 --> Final output sent to browser
DEBUG - 2026-07-03 08:09:29 --> Total execution time: 3.0665
INFO - 2026-07-03 08:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:09:29 --> Upload Class Initialized
DEBUG - 2026-07-03 08:09:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:09:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:09:29 --> Encryption Class Initialized
INFO - 2026-07-03 08:09:29 --> Form Validation Class Initialized
INFO - 2026-07-03 08:09:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:09:29 --> Pagination Class Initialized
INFO - 2026-07-03 08:09:29 --> Email Class Initialized
INFO - 2026-07-03 08:09:29 --> Controller Class Initialized
DEBUG - 2026-07-03 08:09:29 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 08:09:29 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:09:29 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:09:29 --> Model "Dashboard_model" initialized
INFO - 2026-07-03 08:09:30 --> Final output sent to browser
DEBUG - 2026-07-03 08:09:30 --> Total execution time: 3.7751
INFO - 2026-07-03 08:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:09:30 --> Upload Class Initialized
DEBUG - 2026-07-03 08:09:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:09:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:09:30 --> Encryption Class Initialized
INFO - 2026-07-03 08:09:30 --> Form Validation Class Initialized
INFO - 2026-07-03 08:09:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:09:30 --> Pagination Class Initialized
INFO - 2026-07-03 08:09:30 --> Email Class Initialized
INFO - 2026-07-03 08:09:30 --> Controller Class Initialized
DEBUG - 2026-07-03 08:09:30 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 08:09:30 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:09:30 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:09:30 --> Model "Dashboard_model" initialized
INFO - 2026-07-03 08:09:31 --> Final output sent to browser
DEBUG - 2026-07-03 08:09:31 --> Total execution time: 4.6217
INFO - 2026-07-03 08:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:09:31 --> Upload Class Initialized
DEBUG - 2026-07-03 08:09:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:09:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:09:31 --> Encryption Class Initialized
INFO - 2026-07-03 08:09:31 --> Form Validation Class Initialized
INFO - 2026-07-03 08:09:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:09:31 --> Pagination Class Initialized
INFO - 2026-07-03 08:09:31 --> Email Class Initialized
INFO - 2026-07-03 08:09:31 --> Controller Class Initialized
DEBUG - 2026-07-03 08:09:31 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 08:09:31 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:09:31 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:09:31 --> Model "Dashboard_model" initialized
INFO - 2026-07-03 08:09:31 --> Final output sent to browser
DEBUG - 2026-07-03 08:09:31 --> Total execution time: 5.4058
INFO - 2026-07-03 08:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:09:31 --> Upload Class Initialized
DEBUG - 2026-07-03 08:09:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:09:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:09:31 --> Encryption Class Initialized
INFO - 2026-07-03 08:09:31 --> Form Validation Class Initialized
INFO - 2026-07-03 08:09:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:09:31 --> Pagination Class Initialized
INFO - 2026-07-03 08:09:31 --> Email Class Initialized
INFO - 2026-07-03 08:09:31 --> Controller Class Initialized
DEBUG - 2026-07-03 08:09:31 --> Ticket MX_Controller Initialized
INFO - 2026-07-03 08:09:31 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:09:31 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:09:31 --> Model "Support_model" initialized
INFO - 2026-07-03 08:09:31 --> Model "Common_model" initialized
INFO - 2026-07-03 08:09:32 --> Final output sent to browser
DEBUG - 2026-07-03 08:09:32 --> Total execution time: 6.2507
INFO - 2026-07-03 08:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:09:32 --> Upload Class Initialized
DEBUG - 2026-07-03 08:09:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:09:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:09:32 --> Encryption Class Initialized
INFO - 2026-07-03 08:09:32 --> Form Validation Class Initialized
INFO - 2026-07-03 08:09:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:09:32 --> Pagination Class Initialized
INFO - 2026-07-03 08:09:32 --> Email Class Initialized
INFO - 2026-07-03 08:09:32 --> Controller Class Initialized
ERROR - 2026-07-03 08:09:32 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:09:35 --> Config Class Initialized
INFO - 2026-07-03 08:09:35 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:09:35 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:09:35 --> Utf8 Class Initialized
INFO - 2026-07-03 08:09:35 --> URI Class Initialized
INFO - 2026-07-03 08:09:35 --> Router Class Initialized
INFO - 2026-07-03 08:09:35 --> Output Class Initialized
INFO - 2026-07-03 08:09:35 --> Security Class Initialized
DEBUG - 2026-07-03 08:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:09:35 --> CSRF cookie sent
INFO - 2026-07-03 08:09:35 --> Input Class Initialized
INFO - 2026-07-03 08:09:35 --> Language Class Initialized
INFO - 2026-07-03 08:09:35 --> Language Class Initialized
INFO - 2026-07-03 08:09:35 --> Config Class Initialized
INFO - 2026-07-03 08:09:35 --> Loader Class Initialized
INFO - 2026-07-03 08:09:35 --> Helper loaded: url_helper
INFO - 2026-07-03 08:09:35 --> Helper loaded: form_helper
INFO - 2026-07-03 08:09:35 --> Helper loaded: html_helper
INFO - 2026-07-03 08:09:35 --> Helper loaded: file_helper
INFO - 2026-07-03 08:09:35 --> Helper loaded: email_helper
INFO - 2026-07-03 08:09:35 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:09:35 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:09:35 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:09:35 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:09:35 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:09:35 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:09:35 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:09:35 --> Database Driver Class Initialized
INFO - 2026-07-03 08:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:09:37 --> Upload Class Initialized
DEBUG - 2026-07-03 08:09:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:09:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:09:37 --> Encryption Class Initialized
INFO - 2026-07-03 08:09:37 --> Form Validation Class Initialized
INFO - 2026-07-03 08:09:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:09:37 --> Pagination Class Initialized
INFO - 2026-07-03 08:09:37 --> Email Class Initialized
INFO - 2026-07-03 08:09:37 --> Controller Class Initialized
DEBUG - 2026-07-03 08:09:37 --> Softwareproduct MX_Controller Initialized
INFO - 2026-07-03 08:09:37 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:09:37 --> Model "Adminauth_model" initialized
DEBUG - 2026-07-03 08:09:37 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 08:09:37 --> Model "Plan_model" initialized
INFO - 2026-07-03 08:09:37 --> Model "Software_model" initialized
DEBUG - 2026-07-03 08:09:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 08:09:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 08:09:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 08:09:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 08:09:38 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/softwareproduct_list.php
INFO - 2026-07-03 08:09:38 --> Final output sent to browser
DEBUG - 2026-07-03 08:09:38 --> Total execution time: 2.8435
INFO - 2026-07-03 08:09:41 --> Config Class Initialized
INFO - 2026-07-03 08:09:41 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:09:41 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:09:41 --> Utf8 Class Initialized
INFO - 2026-07-03 08:09:41 --> URI Class Initialized
INFO - 2026-07-03 08:09:41 --> Router Class Initialized
INFO - 2026-07-03 08:09:41 --> Output Class Initialized
INFO - 2026-07-03 08:09:41 --> Security Class Initialized
DEBUG - 2026-07-03 08:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:09:41 --> CSRF cookie sent
INFO - 2026-07-03 08:09:41 --> Input Class Initialized
INFO - 2026-07-03 08:09:41 --> Language Class Initialized
INFO - 2026-07-03 08:09:41 --> Language Class Initialized
INFO - 2026-07-03 08:09:41 --> Config Class Initialized
INFO - 2026-07-03 08:09:41 --> Loader Class Initialized
INFO - 2026-07-03 08:09:41 --> Helper loaded: url_helper
INFO - 2026-07-03 08:09:41 --> Helper loaded: form_helper
INFO - 2026-07-03 08:09:41 --> Helper loaded: html_helper
INFO - 2026-07-03 08:09:41 --> Helper loaded: file_helper
INFO - 2026-07-03 08:09:41 --> Helper loaded: email_helper
INFO - 2026-07-03 08:09:41 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:09:41 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:09:41 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:09:41 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:09:41 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:09:41 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:09:41 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:09:41 --> Database Driver Class Initialized
INFO - 2026-07-03 08:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:09:43 --> Upload Class Initialized
DEBUG - 2026-07-03 08:09:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:09:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:09:43 --> Encryption Class Initialized
INFO - 2026-07-03 08:09:43 --> Form Validation Class Initialized
INFO - 2026-07-03 08:09:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:09:43 --> Pagination Class Initialized
INFO - 2026-07-03 08:09:43 --> Email Class Initialized
INFO - 2026-07-03 08:09:43 --> Controller Class Initialized
DEBUG - 2026-07-03 08:09:43 --> Softwareproduct MX_Controller Initialized
INFO - 2026-07-03 08:09:43 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:09:43 --> Model "Adminauth_model" initialized
DEBUG - 2026-07-03 08:09:43 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 08:09:43 --> Model "Plan_model" initialized
INFO - 2026-07-03 08:09:43 --> Model "Software_model" initialized
DEBUG - 2026-07-03 08:09:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 08:09:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 08:09:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 08:09:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 08:09:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/softwareproduct_manage.php
INFO - 2026-07-03 08:09:44 --> Final output sent to browser
DEBUG - 2026-07-03 08:09:44 --> Total execution time: 3.4722
INFO - 2026-07-03 08:12:21 --> Config Class Initialized
INFO - 2026-07-03 08:12:21 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:12:21 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:12:21 --> Utf8 Class Initialized
INFO - 2026-07-03 08:12:21 --> URI Class Initialized
INFO - 2026-07-03 08:12:21 --> Router Class Initialized
INFO - 2026-07-03 08:12:21 --> Output Class Initialized
INFO - 2026-07-03 08:12:21 --> Security Class Initialized
DEBUG - 2026-07-03 08:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:12:21 --> CSRF cookie sent
INFO - 2026-07-03 08:12:21 --> CSRF token verified
INFO - 2026-07-03 08:12:21 --> Input Class Initialized
INFO - 2026-07-03 08:12:21 --> Language Class Initialized
INFO - 2026-07-03 08:12:21 --> Language Class Initialized
INFO - 2026-07-03 08:12:21 --> Config Class Initialized
INFO - 2026-07-03 08:12:21 --> Loader Class Initialized
INFO - 2026-07-03 08:12:21 --> Helper loaded: url_helper
INFO - 2026-07-03 08:12:21 --> Helper loaded: form_helper
INFO - 2026-07-03 08:12:21 --> Helper loaded: html_helper
INFO - 2026-07-03 08:12:21 --> Helper loaded: file_helper
INFO - 2026-07-03 08:12:21 --> Helper loaded: email_helper
INFO - 2026-07-03 08:12:21 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:12:21 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:12:21 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:12:21 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:12:21 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:12:21 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:12:21 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:12:21 --> Database Driver Class Initialized
INFO - 2026-07-03 08:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:12:22 --> Upload Class Initialized
DEBUG - 2026-07-03 08:12:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:12:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:12:22 --> Encryption Class Initialized
INFO - 2026-07-03 08:12:22 --> Form Validation Class Initialized
INFO - 2026-07-03 08:12:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:12:22 --> Pagination Class Initialized
INFO - 2026-07-03 08:12:22 --> Email Class Initialized
INFO - 2026-07-03 08:12:22 --> Controller Class Initialized
DEBUG - 2026-07-03 08:12:22 --> Softwareproduct MX_Controller Initialized
INFO - 2026-07-03 08:12:22 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:12:22 --> Model "Adminauth_model" initialized
DEBUG - 2026-07-03 08:12:22 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 08:12:22 --> Model "Plan_model" initialized
INFO - 2026-07-03 08:12:22 --> Model "Software_model" initialized
INFO - 2026-07-03 08:12:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-07-03 08:12:28 --> Config Class Initialized
INFO - 2026-07-03 08:12:28 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:12:28 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:12:28 --> Utf8 Class Initialized
INFO - 2026-07-03 08:12:28 --> URI Class Initialized
INFO - 2026-07-03 08:12:28 --> Router Class Initialized
INFO - 2026-07-03 08:12:28 --> Output Class Initialized
INFO - 2026-07-03 08:12:28 --> Security Class Initialized
DEBUG - 2026-07-03 08:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:12:28 --> CSRF cookie sent
INFO - 2026-07-03 08:12:28 --> Input Class Initialized
INFO - 2026-07-03 08:12:28 --> Language Class Initialized
INFO - 2026-07-03 08:12:28 --> Language Class Initialized
INFO - 2026-07-03 08:12:28 --> Config Class Initialized
INFO - 2026-07-03 08:12:28 --> Loader Class Initialized
INFO - 2026-07-03 08:12:28 --> Helper loaded: url_helper
INFO - 2026-07-03 08:12:28 --> Helper loaded: form_helper
INFO - 2026-07-03 08:12:28 --> Helper loaded: html_helper
INFO - 2026-07-03 08:12:28 --> Helper loaded: file_helper
INFO - 2026-07-03 08:12:28 --> Helper loaded: email_helper
INFO - 2026-07-03 08:12:28 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:12:28 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:12:28 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:12:28 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:12:28 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:12:28 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:12:28 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:12:28 --> Database Driver Class Initialized
INFO - 2026-07-03 08:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:12:30 --> Upload Class Initialized
DEBUG - 2026-07-03 08:12:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:12:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:12:30 --> Encryption Class Initialized
INFO - 2026-07-03 08:12:30 --> Form Validation Class Initialized
INFO - 2026-07-03 08:12:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:12:30 --> Pagination Class Initialized
INFO - 2026-07-03 08:12:30 --> Email Class Initialized
INFO - 2026-07-03 08:12:30 --> Controller Class Initialized
DEBUG - 2026-07-03 08:12:30 --> Softwareproduct MX_Controller Initialized
INFO - 2026-07-03 08:12:30 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:12:30 --> Model "Adminauth_model" initialized
DEBUG - 2026-07-03 08:12:30 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 08:12:30 --> Model "Plan_model" initialized
INFO - 2026-07-03 08:12:30 --> Model "Software_model" initialized
DEBUG - 2026-07-03 08:12:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 08:12:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 08:12:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 08:12:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 08:12:31 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/softwareproduct_list.php
INFO - 2026-07-03 08:12:31 --> Final output sent to browser
DEBUG - 2026-07-03 08:12:31 --> Total execution time: 2.8817
INFO - 2026-07-03 08:13:15 --> Config Class Initialized
INFO - 2026-07-03 08:13:15 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:13:15 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:13:15 --> Utf8 Class Initialized
INFO - 2026-07-03 08:13:15 --> URI Class Initialized
INFO - 2026-07-03 08:13:15 --> Router Class Initialized
INFO - 2026-07-03 08:13:15 --> Output Class Initialized
INFO - 2026-07-03 08:13:15 --> Security Class Initialized
DEBUG - 2026-07-03 08:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:13:15 --> CSRF cookie sent
INFO - 2026-07-03 08:13:15 --> Input Class Initialized
INFO - 2026-07-03 08:13:15 --> Language Class Initialized
INFO - 2026-07-03 08:13:15 --> Language Class Initialized
INFO - 2026-07-03 08:13:15 --> Config Class Initialized
INFO - 2026-07-03 08:13:15 --> Loader Class Initialized
INFO - 2026-07-03 08:13:15 --> Helper loaded: url_helper
INFO - 2026-07-03 08:13:15 --> Helper loaded: form_helper
INFO - 2026-07-03 08:13:15 --> Helper loaded: html_helper
INFO - 2026-07-03 08:13:15 --> Helper loaded: file_helper
INFO - 2026-07-03 08:13:15 --> Helper loaded: email_helper
INFO - 2026-07-03 08:13:15 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:13:15 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:13:15 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:13:15 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:13:15 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:13:15 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:13:15 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:13:15 --> Database Driver Class Initialized
INFO - 2026-07-03 08:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:13:17 --> Upload Class Initialized
DEBUG - 2026-07-03 08:13:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:13:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:13:17 --> Encryption Class Initialized
INFO - 2026-07-03 08:13:17 --> Form Validation Class Initialized
INFO - 2026-07-03 08:13:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:13:17 --> Pagination Class Initialized
INFO - 2026-07-03 08:13:17 --> Email Class Initialized
INFO - 2026-07-03 08:13:17 --> Controller Class Initialized
DEBUG - 2026-07-03 08:13:17 --> Softwareproduct MX_Controller Initialized
INFO - 2026-07-03 08:13:17 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:13:17 --> Model "Adminauth_model" initialized
DEBUG - 2026-07-03 08:13:17 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 08:13:17 --> Model "Plan_model" initialized
INFO - 2026-07-03 08:13:17 --> Model "Software_model" initialized
DEBUG - 2026-07-03 08:13:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 08:13:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 08:13:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 08:13:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 08:13:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/softwareproduct_list.php
INFO - 2026-07-03 08:13:18 --> Final output sent to browser
DEBUG - 2026-07-03 08:13:18 --> Total execution time: 3.2582
INFO - 2026-07-03 08:13:53 --> Config Class Initialized
INFO - 2026-07-03 08:13:53 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:13:53 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:13:53 --> Utf8 Class Initialized
INFO - 2026-07-03 08:13:53 --> URI Class Initialized
INFO - 2026-07-03 08:13:53 --> Router Class Initialized
INFO - 2026-07-03 08:13:53 --> Output Class Initialized
INFO - 2026-07-03 08:13:53 --> Security Class Initialized
DEBUG - 2026-07-03 08:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:13:53 --> CSRF cookie sent
INFO - 2026-07-03 08:13:53 --> Input Class Initialized
INFO - 2026-07-03 08:13:53 --> Language Class Initialized
INFO - 2026-07-03 08:13:53 --> Language Class Initialized
INFO - 2026-07-03 08:13:53 --> Config Class Initialized
INFO - 2026-07-03 08:13:53 --> Loader Class Initialized
INFO - 2026-07-03 08:13:53 --> Helper loaded: url_helper
INFO - 2026-07-03 08:13:53 --> Helper loaded: form_helper
INFO - 2026-07-03 08:13:53 --> Helper loaded: html_helper
INFO - 2026-07-03 08:13:53 --> Helper loaded: file_helper
INFO - 2026-07-03 08:13:53 --> Helper loaded: email_helper
INFO - 2026-07-03 08:13:53 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:13:53 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:13:53 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:13:53 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:13:53 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:13:53 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:13:53 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:13:53 --> Database Driver Class Initialized
INFO - 2026-07-03 08:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:13:55 --> Upload Class Initialized
DEBUG - 2026-07-03 08:13:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:13:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:13:55 --> Encryption Class Initialized
INFO - 2026-07-03 08:13:55 --> Form Validation Class Initialized
INFO - 2026-07-03 08:13:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:13:55 --> Pagination Class Initialized
INFO - 2026-07-03 08:13:55 --> Email Class Initialized
INFO - 2026-07-03 08:13:55 --> Controller Class Initialized
DEBUG - 2026-07-03 08:13:55 --> Softwareproduct MX_Controller Initialized
INFO - 2026-07-03 08:13:55 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:13:55 --> Model "Adminauth_model" initialized
DEBUG - 2026-07-03 08:13:55 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 08:13:55 --> Model "Plan_model" initialized
INFO - 2026-07-03 08:13:55 --> Model "Software_model" initialized
DEBUG - 2026-07-03 08:13:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 08:13:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 08:13:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 08:13:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-03 08:13:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 08:13:56 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/softwareproduct_list.php
INFO - 2026-07-03 08:13:56 --> Final output sent to browser
DEBUG - 2026-07-03 08:13:56 --> Total execution time: 2.6795
INFO - 2026-07-03 08:13:56 --> Config Class Initialized
INFO - 2026-07-03 08:13:56 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:13:56 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:13:56 --> Utf8 Class Initialized
INFO - 2026-07-03 08:13:56 --> URI Class Initialized
INFO - 2026-07-03 08:13:56 --> Router Class Initialized
INFO - 2026-07-03 08:13:56 --> Output Class Initialized
INFO - 2026-07-03 08:13:56 --> Security Class Initialized
DEBUG - 2026-07-03 08:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:13:56 --> CSRF cookie sent
INFO - 2026-07-03 08:13:56 --> Input Class Initialized
INFO - 2026-07-03 08:13:56 --> Language Class Initialized
INFO - 2026-07-03 08:13:56 --> Language Class Initialized
INFO - 2026-07-03 08:13:56 --> Config Class Initialized
INFO - 2026-07-03 08:13:56 --> Loader Class Initialized
INFO - 2026-07-03 08:13:56 --> Helper loaded: url_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: form_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: html_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: file_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: email_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:13:56 --> Database Driver Class Initialized
INFO - 2026-07-03 08:13:56 --> Config Class Initialized
INFO - 2026-07-03 08:13:56 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:13:56 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:13:56 --> Utf8 Class Initialized
INFO - 2026-07-03 08:13:56 --> URI Class Initialized
INFO - 2026-07-03 08:13:56 --> Router Class Initialized
INFO - 2026-07-03 08:13:56 --> Output Class Initialized
INFO - 2026-07-03 08:13:56 --> Security Class Initialized
DEBUG - 2026-07-03 08:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:13:56 --> CSRF cookie sent
INFO - 2026-07-03 08:13:56 --> Input Class Initialized
INFO - 2026-07-03 08:13:56 --> Language Class Initialized
INFO - 2026-07-03 08:13:56 --> Language Class Initialized
INFO - 2026-07-03 08:13:56 --> Config Class Initialized
INFO - 2026-07-03 08:13:56 --> Loader Class Initialized
INFO - 2026-07-03 08:13:56 --> Helper loaded: url_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: form_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: html_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: file_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: email_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:13:56 --> Database Driver Class Initialized
INFO - 2026-07-03 08:13:56 --> Config Class Initialized
INFO - 2026-07-03 08:13:56 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:13:56 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:13:56 --> Utf8 Class Initialized
INFO - 2026-07-03 08:13:56 --> URI Class Initialized
INFO - 2026-07-03 08:13:56 --> Router Class Initialized
INFO - 2026-07-03 08:13:56 --> Output Class Initialized
INFO - 2026-07-03 08:13:56 --> Security Class Initialized
DEBUG - 2026-07-03 08:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:13:56 --> CSRF cookie sent
INFO - 2026-07-03 08:13:56 --> Input Class Initialized
INFO - 2026-07-03 08:13:56 --> Language Class Initialized
INFO - 2026-07-03 08:13:56 --> Language Class Initialized
INFO - 2026-07-03 08:13:56 --> Config Class Initialized
INFO - 2026-07-03 08:13:56 --> Loader Class Initialized
INFO - 2026-07-03 08:13:56 --> Helper loaded: url_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: form_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: html_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: file_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: email_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:13:56 --> Database Driver Class Initialized
INFO - 2026-07-03 08:13:56 --> Config Class Initialized
INFO - 2026-07-03 08:13:56 --> Hooks Class Initialized
INFO - 2026-07-03 08:13:56 --> Config Class Initialized
INFO - 2026-07-03 08:13:56 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:13:56 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:13:56 --> Utf8 Class Initialized
DEBUG - 2026-07-03 08:13:56 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:13:56 --> Utf8 Class Initialized
INFO - 2026-07-03 08:13:56 --> Config Class Initialized
INFO - 2026-07-03 08:13:56 --> Hooks Class Initialized
INFO - 2026-07-03 08:13:56 --> URI Class Initialized
INFO - 2026-07-03 08:13:56 --> URI Class Initialized
DEBUG - 2026-07-03 08:13:56 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:13:56 --> Utf8 Class Initialized
INFO - 2026-07-03 08:13:56 --> Router Class Initialized
INFO - 2026-07-03 08:13:56 --> URI Class Initialized
INFO - 2026-07-03 08:13:56 --> Router Class Initialized
INFO - 2026-07-03 08:13:56 --> Output Class Initialized
INFO - 2026-07-03 08:13:56 --> Router Class Initialized
INFO - 2026-07-03 08:13:56 --> Security Class Initialized
INFO - 2026-07-03 08:13:56 --> Output Class Initialized
INFO - 2026-07-03 08:13:56 --> Output Class Initialized
DEBUG - 2026-07-03 08:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:13:56 --> CSRF cookie sent
INFO - 2026-07-03 08:13:56 --> Input Class Initialized
INFO - 2026-07-03 08:13:56 --> Language Class Initialized
INFO - 2026-07-03 08:13:56 --> Security Class Initialized
INFO - 2026-07-03 08:13:56 --> Security Class Initialized
INFO - 2026-07-03 08:13:56 --> Language Class Initialized
INFO - 2026-07-03 08:13:56 --> Config Class Initialized
DEBUG - 2026-07-03 08:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:13:56 --> CSRF cookie sent
INFO - 2026-07-03 08:13:56 --> Input Class Initialized
DEBUG - 2026-07-03 08:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:13:56 --> CSRF cookie sent
INFO - 2026-07-03 08:13:56 --> Input Class Initialized
INFO - 2026-07-03 08:13:56 --> Language Class Initialized
INFO - 2026-07-03 08:13:56 --> Language Class Initialized
INFO - 2026-07-03 08:13:56 --> Language Class Initialized
INFO - 2026-07-03 08:13:56 --> Config Class Initialized
INFO - 2026-07-03 08:13:56 --> Language Class Initialized
INFO - 2026-07-03 08:13:56 --> Config Class Initialized
INFO - 2026-07-03 08:13:56 --> Loader Class Initialized
INFO - 2026-07-03 08:13:56 --> Helper loaded: url_helper
INFO - 2026-07-03 08:13:56 --> Loader Class Initialized
INFO - 2026-07-03 08:13:56 --> Loader Class Initialized
INFO - 2026-07-03 08:13:56 --> Helper loaded: form_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: html_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: url_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: url_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: file_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: email_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: form_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: form_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: html_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: html_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: file_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: file_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: email_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: email_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:13:56 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:13:56 --> Database Driver Class Initialized
INFO - 2026-07-03 08:13:56 --> Database Driver Class Initialized
INFO - 2026-07-03 08:13:56 --> Database Driver Class Initialized
INFO - 2026-07-03 08:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:13:58 --> Upload Class Initialized
DEBUG - 2026-07-03 08:13:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:13:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:13:58 --> Encryption Class Initialized
INFO - 2026-07-03 08:13:58 --> Form Validation Class Initialized
INFO - 2026-07-03 08:13:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:13:58 --> Pagination Class Initialized
INFO - 2026-07-03 08:13:58 --> Email Class Initialized
INFO - 2026-07-03 08:13:58 --> Controller Class Initialized
ERROR - 2026-07-03 08:13:58 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:13:58 --> Upload Class Initialized
DEBUG - 2026-07-03 08:13:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:13:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:13:58 --> Encryption Class Initialized
INFO - 2026-07-03 08:13:58 --> Form Validation Class Initialized
INFO - 2026-07-03 08:13:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:13:58 --> Pagination Class Initialized
INFO - 2026-07-03 08:13:58 --> Config Class Initialized
INFO - 2026-07-03 08:13:58 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:13:58 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:13:58 --> Utf8 Class Initialized
INFO - 2026-07-03 08:13:58 --> Email Class Initialized
INFO - 2026-07-03 08:13:58 --> Controller Class Initialized
INFO - 2026-07-03 08:13:58 --> URI Class Initialized
ERROR - 2026-07-03 08:13:58 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:13:58 --> Router Class Initialized
INFO - 2026-07-03 08:13:58 --> Upload Class Initialized
INFO - 2026-07-03 08:13:58 --> Output Class Initialized
DEBUG - 2026-07-03 08:13:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:13:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:13:58 --> Encryption Class Initialized
INFO - 2026-07-03 08:13:58 --> Security Class Initialized
DEBUG - 2026-07-03 08:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:13:58 --> CSRF cookie sent
INFO - 2026-07-03 08:13:58 --> Input Class Initialized
INFO - 2026-07-03 08:13:58 --> Language Class Initialized
INFO - 2026-07-03 08:13:58 --> Form Validation Class Initialized
INFO - 2026-07-03 08:13:58 --> Language Class Initialized
INFO - 2026-07-03 08:13:58 --> Config Class Initialized
INFO - 2026-07-03 08:13:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:13:58 --> Pagination Class Initialized
INFO - 2026-07-03 08:13:58 --> Loader Class Initialized
INFO - 2026-07-03 08:13:58 --> Helper loaded: url_helper
INFO - 2026-07-03 08:13:58 --> Email Class Initialized
INFO - 2026-07-03 08:13:58 --> Controller Class Initialized
ERROR - 2026-07-03 08:13:58 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:13:58 --> Helper loaded: form_helper
INFO - 2026-07-03 08:13:58 --> Helper loaded: html_helper
INFO - 2026-07-03 08:13:58 --> Helper loaded: file_helper
INFO - 2026-07-03 08:13:58 --> Helper loaded: email_helper
INFO - 2026-07-03 08:13:58 --> Upload Class Initialized
INFO - 2026-07-03 08:13:58 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:13:58 --> Helper loaded: ssp_helper
DEBUG - 2026-07-03 08:13:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:13:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:13:58 --> Encryption Class Initialized
INFO - 2026-07-03 08:13:58 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:13:58 --> Form Validation Class Initialized
INFO - 2026-07-03 08:13:58 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:13:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:13:58 --> Pagination Class Initialized
INFO - 2026-07-03 08:13:58 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:13:58 --> Email Class Initialized
INFO - 2026-07-03 08:13:58 --> Controller Class Initialized
INFO - 2026-07-03 08:13:58 --> Helper loaded: domain_helper
ERROR - 2026-07-03 08:13:58 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:13:58 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:13:58 --> Upload Class Initialized
DEBUG - 2026-07-03 08:13:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:13:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:13:58 --> Encryption Class Initialized
INFO - 2026-07-03 08:13:58 --> Database Driver Class Initialized
INFO - 2026-07-03 08:13:58 --> Form Validation Class Initialized
INFO - 2026-07-03 08:13:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:13:58 --> Pagination Class Initialized
INFO - 2026-07-03 08:13:58 --> Email Class Initialized
INFO - 2026-07-03 08:13:58 --> Controller Class Initialized
ERROR - 2026-07-03 08:13:58 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:13:58 --> Upload Class Initialized
DEBUG - 2026-07-03 08:13:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:13:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:13:58 --> Encryption Class Initialized
INFO - 2026-07-03 08:13:58 --> Form Validation Class Initialized
INFO - 2026-07-03 08:13:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:13:58 --> Pagination Class Initialized
INFO - 2026-07-03 08:13:58 --> Email Class Initialized
INFO - 2026-07-03 08:13:58 --> Controller Class Initialized
ERROR - 2026-07-03 08:13:58 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:14:00 --> Upload Class Initialized
DEBUG - 2026-07-03 08:14:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:14:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:14:00 --> Encryption Class Initialized
INFO - 2026-07-03 08:14:00 --> Form Validation Class Initialized
INFO - 2026-07-03 08:14:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:14:00 --> Pagination Class Initialized
INFO - 2026-07-03 08:14:00 --> Email Class Initialized
INFO - 2026-07-03 08:14:00 --> Controller Class Initialized
ERROR - 2026-07-03 08:14:00 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:14:05 --> Config Class Initialized
INFO - 2026-07-03 08:14:05 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:14:05 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:14:05 --> Utf8 Class Initialized
INFO - 2026-07-03 08:14:05 --> URI Class Initialized
INFO - 2026-07-03 08:14:05 --> Router Class Initialized
INFO - 2026-07-03 08:14:05 --> Output Class Initialized
INFO - 2026-07-03 08:14:05 --> Security Class Initialized
DEBUG - 2026-07-03 08:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:14:05 --> CSRF cookie sent
INFO - 2026-07-03 08:14:05 --> Input Class Initialized
INFO - 2026-07-03 08:14:05 --> Language Class Initialized
INFO - 2026-07-03 08:14:05 --> Language Class Initialized
INFO - 2026-07-03 08:14:05 --> Config Class Initialized
INFO - 2026-07-03 08:14:05 --> Loader Class Initialized
INFO - 2026-07-03 08:14:05 --> Helper loaded: url_helper
INFO - 2026-07-03 08:14:05 --> Helper loaded: form_helper
INFO - 2026-07-03 08:14:05 --> Helper loaded: html_helper
INFO - 2026-07-03 08:14:05 --> Helper loaded: file_helper
INFO - 2026-07-03 08:14:05 --> Helper loaded: email_helper
INFO - 2026-07-03 08:14:05 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:14:05 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:14:05 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:14:05 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:14:05 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:14:05 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:14:05 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:14:05 --> Database Driver Class Initialized
INFO - 2026-07-03 08:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:14:07 --> Upload Class Initialized
DEBUG - 2026-07-03 08:14:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:14:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:14:07 --> Encryption Class Initialized
INFO - 2026-07-03 08:14:07 --> Form Validation Class Initialized
INFO - 2026-07-03 08:14:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:14:07 --> Pagination Class Initialized
INFO - 2026-07-03 08:14:07 --> Email Class Initialized
INFO - 2026-07-03 08:14:07 --> Controller Class Initialized
DEBUG - 2026-07-03 08:14:07 --> Softwareproduct MX_Controller Initialized
INFO - 2026-07-03 08:14:07 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:14:07 --> Model "Adminauth_model" initialized
DEBUG - 2026-07-03 08:14:07 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 08:14:07 --> Model "Plan_model" initialized
INFO - 2026-07-03 08:14:07 --> Model "Software_model" initialized
DEBUG - 2026-07-03 08:14:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 08:14:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 08:14:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 08:14:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-03 08:14:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 08:14:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/softwareproduct_manage.php
INFO - 2026-07-03 08:14:10 --> Final output sent to browser
DEBUG - 2026-07-03 08:14:10 --> Total execution time: 4.8541
INFO - 2026-07-03 08:14:11 --> Config Class Initialized
INFO - 2026-07-03 08:14:11 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:14:11 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:14:11 --> Utf8 Class Initialized
INFO - 2026-07-03 08:14:11 --> URI Class Initialized
INFO - 2026-07-03 08:14:11 --> Router Class Initialized
INFO - 2026-07-03 08:14:11 --> Output Class Initialized
INFO - 2026-07-03 08:14:11 --> Security Class Initialized
DEBUG - 2026-07-03 08:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:14:11 --> CSRF cookie sent
INFO - 2026-07-03 08:14:11 --> Input Class Initialized
INFO - 2026-07-03 08:14:11 --> Language Class Initialized
INFO - 2026-07-03 08:14:11 --> Language Class Initialized
INFO - 2026-07-03 08:14:11 --> Config Class Initialized
INFO - 2026-07-03 08:14:11 --> Loader Class Initialized
INFO - 2026-07-03 08:14:11 --> Helper loaded: url_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: form_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: html_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: file_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: email_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:14:11 --> Database Driver Class Initialized
INFO - 2026-07-03 08:14:11 --> Config Class Initialized
INFO - 2026-07-03 08:14:11 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:14:11 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:14:11 --> Utf8 Class Initialized
INFO - 2026-07-03 08:14:11 --> URI Class Initialized
INFO - 2026-07-03 08:14:11 --> Router Class Initialized
INFO - 2026-07-03 08:14:11 --> Output Class Initialized
INFO - 2026-07-03 08:14:11 --> Security Class Initialized
DEBUG - 2026-07-03 08:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:14:11 --> CSRF cookie sent
INFO - 2026-07-03 08:14:11 --> Input Class Initialized
INFO - 2026-07-03 08:14:11 --> Language Class Initialized
INFO - 2026-07-03 08:14:11 --> Language Class Initialized
INFO - 2026-07-03 08:14:11 --> Config Class Initialized
INFO - 2026-07-03 08:14:11 --> Loader Class Initialized
INFO - 2026-07-03 08:14:11 --> Helper loaded: url_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: form_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: html_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: file_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: email_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:14:11 --> Database Driver Class Initialized
INFO - 2026-07-03 08:14:11 --> Config Class Initialized
INFO - 2026-07-03 08:14:11 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:14:11 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:14:11 --> Utf8 Class Initialized
INFO - 2026-07-03 08:14:11 --> Config Class Initialized
INFO - 2026-07-03 08:14:11 --> Hooks Class Initialized
INFO - 2026-07-03 08:14:11 --> Config Class Initialized
INFO - 2026-07-03 08:14:11 --> Hooks Class Initialized
INFO - 2026-07-03 08:14:11 --> URI Class Initialized
DEBUG - 2026-07-03 08:14:11 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:14:11 --> Utf8 Class Initialized
DEBUG - 2026-07-03 08:14:11 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:14:11 --> Utf8 Class Initialized
INFO - 2026-07-03 08:14:11 --> URI Class Initialized
INFO - 2026-07-03 08:14:11 --> Config Class Initialized
INFO - 2026-07-03 08:14:11 --> Router Class Initialized
INFO - 2026-07-03 08:14:11 --> Hooks Class Initialized
INFO - 2026-07-03 08:14:11 --> URI Class Initialized
INFO - 2026-07-03 08:14:11 --> Output Class Initialized
INFO - 2026-07-03 08:14:11 --> Router Class Initialized
DEBUG - 2026-07-03 08:14:11 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:14:11 --> Utf8 Class Initialized
INFO - 2026-07-03 08:14:11 --> Security Class Initialized
INFO - 2026-07-03 08:14:11 --> Router Class Initialized
INFO - 2026-07-03 08:14:11 --> Output Class Initialized
INFO - 2026-07-03 08:14:11 --> URI Class Initialized
DEBUG - 2026-07-03 08:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:14:11 --> CSRF cookie sent
INFO - 2026-07-03 08:14:11 --> Input Class Initialized
INFO - 2026-07-03 08:14:11 --> Language Class Initialized
INFO - 2026-07-03 08:14:11 --> Output Class Initialized
INFO - 2026-07-03 08:14:11 --> Security Class Initialized
INFO - 2026-07-03 08:14:11 --> Language Class Initialized
INFO - 2026-07-03 08:14:11 --> Config Class Initialized
INFO - 2026-07-03 08:14:11 --> Router Class Initialized
DEBUG - 2026-07-03 08:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:14:11 --> CSRF cookie sent
INFO - 2026-07-03 08:14:11 --> Security Class Initialized
INFO - 2026-07-03 08:14:11 --> Input Class Initialized
INFO - 2026-07-03 08:14:11 --> Language Class Initialized
INFO - 2026-07-03 08:14:11 --> Loader Class Initialized
DEBUG - 2026-07-03 08:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:14:11 --> CSRF cookie sent
INFO - 2026-07-03 08:14:11 --> Input Class Initialized
INFO - 2026-07-03 08:14:11 --> Language Class Initialized
INFO - 2026-07-03 08:14:11 --> Config Class Initialized
INFO - 2026-07-03 08:14:11 --> Output Class Initialized
INFO - 2026-07-03 08:14:11 --> Language Class Initialized
INFO - 2026-07-03 08:14:11 --> Helper loaded: url_helper
INFO - 2026-07-03 08:14:11 --> Language Class Initialized
INFO - 2026-07-03 08:14:11 --> Config Class Initialized
INFO - 2026-07-03 08:14:11 --> Helper loaded: form_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: html_helper
INFO - 2026-07-03 08:14:11 --> Security Class Initialized
INFO - 2026-07-03 08:14:11 --> Helper loaded: file_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: email_helper
INFO - 2026-07-03 08:14:11 --> Loader Class Initialized
INFO - 2026-07-03 08:14:11 --> Helper loaded: whmaz_helper
DEBUG - 2026-07-03 08:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:14:11 --> CSRF cookie sent
INFO - 2026-07-03 08:14:11 --> Input Class Initialized
INFO - 2026-07-03 08:14:11 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:14:11 --> Language Class Initialized
INFO - 2026-07-03 08:14:11 --> Helper loaded: url_helper
INFO - 2026-07-03 08:14:11 --> Loader Class Initialized
INFO - 2026-07-03 08:14:11 --> Language Class Initialized
INFO - 2026-07-03 08:14:11 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:14:11 --> Config Class Initialized
INFO - 2026-07-03 08:14:11 --> Helper loaded: url_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: form_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: html_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: file_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: form_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: email_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: html_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: file_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: email_helper
INFO - 2026-07-03 08:14:11 --> Loader Class Initialized
INFO - 2026-07-03 08:14:11 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: url_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: form_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: html_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: file_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: email_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:14:11 --> Database Driver Class Initialized
INFO - 2026-07-03 08:14:11 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:14:11 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:14:11 --> Database Driver Class Initialized
INFO - 2026-07-03 08:14:11 --> Database Driver Class Initialized
INFO - 2026-07-03 08:14:11 --> Database Driver Class Initialized
INFO - 2026-07-03 08:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:14:12 --> Upload Class Initialized
DEBUG - 2026-07-03 08:14:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:14:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:14:12 --> Encryption Class Initialized
INFO - 2026-07-03 08:14:12 --> Form Validation Class Initialized
INFO - 2026-07-03 08:14:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:14:12 --> Pagination Class Initialized
INFO - 2026-07-03 08:14:12 --> Email Class Initialized
INFO - 2026-07-03 08:14:12 --> Controller Class Initialized
ERROR - 2026-07-03 08:14:12 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:14:12 --> Upload Class Initialized
DEBUG - 2026-07-03 08:14:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:14:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:14:12 --> Encryption Class Initialized
INFO - 2026-07-03 08:14:12 --> Form Validation Class Initialized
INFO - 2026-07-03 08:14:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:14:12 --> Pagination Class Initialized
INFO - 2026-07-03 08:14:12 --> Config Class Initialized
INFO - 2026-07-03 08:14:12 --> Hooks Class Initialized
INFO - 2026-07-03 08:14:12 --> Email Class Initialized
DEBUG - 2026-07-03 08:14:12 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:14:12 --> Utf8 Class Initialized
INFO - 2026-07-03 08:14:12 --> Controller Class Initialized
ERROR - 2026-07-03 08:14:12 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:14:12 --> URI Class Initialized
INFO - 2026-07-03 08:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:14:12 --> Router Class Initialized
INFO - 2026-07-03 08:14:12 --> Upload Class Initialized
INFO - 2026-07-03 08:14:12 --> Output Class Initialized
DEBUG - 2026-07-03 08:14:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:14:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:14:12 --> Encryption Class Initialized
INFO - 2026-07-03 08:14:12 --> Security Class Initialized
DEBUG - 2026-07-03 08:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:14:12 --> CSRF cookie sent
INFO - 2026-07-03 08:14:12 --> Input Class Initialized
INFO - 2026-07-03 08:14:12 --> Language Class Initialized
INFO - 2026-07-03 08:14:12 --> Form Validation Class Initialized
INFO - 2026-07-03 08:14:12 --> Language Class Initialized
INFO - 2026-07-03 08:14:12 --> Config Class Initialized
INFO - 2026-07-03 08:14:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:14:12 --> Pagination Class Initialized
INFO - 2026-07-03 08:14:12 --> Loader Class Initialized
INFO - 2026-07-03 08:14:12 --> Helper loaded: url_helper
INFO - 2026-07-03 08:14:12 --> Email Class Initialized
INFO - 2026-07-03 08:14:12 --> Controller Class Initialized
INFO - 2026-07-03 08:14:12 --> Helper loaded: form_helper
ERROR - 2026-07-03 08:14:12 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:14:12 --> Helper loaded: html_helper
INFO - 2026-07-03 08:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:14:12 --> Helper loaded: file_helper
INFO - 2026-07-03 08:14:12 --> Helper loaded: email_helper
INFO - 2026-07-03 08:14:12 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:14:12 --> Upload Class Initialized
INFO - 2026-07-03 08:14:12 --> Helper loaded: ssp_helper
DEBUG - 2026-07-03 08:14:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:14:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:14:12 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:14:12 --> Encryption Class Initialized
INFO - 2026-07-03 08:14:12 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:14:12 --> Form Validation Class Initialized
INFO - 2026-07-03 08:14:12 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:14:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:14:12 --> Pagination Class Initialized
INFO - 2026-07-03 08:14:12 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:14:12 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:14:12 --> Email Class Initialized
INFO - 2026-07-03 08:14:12 --> Controller Class Initialized
ERROR - 2026-07-03 08:14:12 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:14:12 --> Upload Class Initialized
DEBUG - 2026-07-03 08:14:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:14:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:14:12 --> Encryption Class Initialized
INFO - 2026-07-03 08:14:12 --> Database Driver Class Initialized
INFO - 2026-07-03 08:14:12 --> Form Validation Class Initialized
INFO - 2026-07-03 08:14:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:14:12 --> Pagination Class Initialized
INFO - 2026-07-03 08:14:12 --> Email Class Initialized
INFO - 2026-07-03 08:14:12 --> Controller Class Initialized
ERROR - 2026-07-03 08:14:12 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:14:12 --> Upload Class Initialized
DEBUG - 2026-07-03 08:14:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:14:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:14:12 --> Encryption Class Initialized
INFO - 2026-07-03 08:14:12 --> Form Validation Class Initialized
INFO - 2026-07-03 08:14:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:14:12 --> Pagination Class Initialized
INFO - 2026-07-03 08:14:12 --> Email Class Initialized
INFO - 2026-07-03 08:14:12 --> Controller Class Initialized
ERROR - 2026-07-03 08:14:12 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:14:14 --> Upload Class Initialized
DEBUG - 2026-07-03 08:14:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:14:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:14:14 --> Encryption Class Initialized
INFO - 2026-07-03 08:14:14 --> Form Validation Class Initialized
INFO - 2026-07-03 08:14:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:14:14 --> Pagination Class Initialized
INFO - 2026-07-03 08:14:14 --> Email Class Initialized
INFO - 2026-07-03 08:14:14 --> Controller Class Initialized
ERROR - 2026-07-03 08:14:14 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:14:32 --> Config Class Initialized
INFO - 2026-07-03 08:14:32 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:14:32 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:14:32 --> Utf8 Class Initialized
INFO - 2026-07-03 08:14:32 --> URI Class Initialized
INFO - 2026-07-03 08:14:32 --> Router Class Initialized
INFO - 2026-07-03 08:14:32 --> Output Class Initialized
INFO - 2026-07-03 08:14:32 --> Security Class Initialized
DEBUG - 2026-07-03 08:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:14:32 --> CSRF cookie sent
INFO - 2026-07-03 08:14:32 --> CSRF token verified
INFO - 2026-07-03 08:14:32 --> Input Class Initialized
INFO - 2026-07-03 08:14:32 --> Language Class Initialized
INFO - 2026-07-03 08:14:32 --> Language Class Initialized
INFO - 2026-07-03 08:14:32 --> Config Class Initialized
INFO - 2026-07-03 08:14:32 --> Loader Class Initialized
INFO - 2026-07-03 08:14:32 --> Helper loaded: url_helper
INFO - 2026-07-03 08:14:32 --> Helper loaded: form_helper
INFO - 2026-07-03 08:14:32 --> Helper loaded: html_helper
INFO - 2026-07-03 08:14:32 --> Helper loaded: file_helper
INFO - 2026-07-03 08:14:32 --> Helper loaded: email_helper
INFO - 2026-07-03 08:14:32 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:14:32 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:14:32 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:14:32 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:14:32 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:14:32 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:14:32 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:14:32 --> Database Driver Class Initialized
INFO - 2026-07-03 08:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:14:34 --> Upload Class Initialized
DEBUG - 2026-07-03 08:14:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:14:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:14:34 --> Encryption Class Initialized
INFO - 2026-07-03 08:14:34 --> Form Validation Class Initialized
INFO - 2026-07-03 08:14:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:14:34 --> Pagination Class Initialized
INFO - 2026-07-03 08:14:34 --> Email Class Initialized
INFO - 2026-07-03 08:14:34 --> Controller Class Initialized
DEBUG - 2026-07-03 08:14:34 --> Softwareproduct MX_Controller Initialized
INFO - 2026-07-03 08:14:34 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:14:34 --> Model "Adminauth_model" initialized
DEBUG - 2026-07-03 08:14:34 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 08:14:34 --> Model "Plan_model" initialized
INFO - 2026-07-03 08:14:34 --> Model "Software_model" initialized
INFO - 2026-07-03 08:14:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-07-03 08:14:41 --> Config Class Initialized
INFO - 2026-07-03 08:14:41 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:14:41 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:14:41 --> Utf8 Class Initialized
INFO - 2026-07-03 08:14:41 --> URI Class Initialized
INFO - 2026-07-03 08:14:41 --> Router Class Initialized
INFO - 2026-07-03 08:14:41 --> Output Class Initialized
INFO - 2026-07-03 08:14:41 --> Security Class Initialized
DEBUG - 2026-07-03 08:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:14:41 --> CSRF cookie sent
INFO - 2026-07-03 08:14:41 --> Input Class Initialized
INFO - 2026-07-03 08:14:41 --> Language Class Initialized
INFO - 2026-07-03 08:14:41 --> Language Class Initialized
INFO - 2026-07-03 08:14:41 --> Config Class Initialized
INFO - 2026-07-03 08:14:41 --> Loader Class Initialized
INFO - 2026-07-03 08:14:41 --> Helper loaded: url_helper
INFO - 2026-07-03 08:14:41 --> Helper loaded: form_helper
INFO - 2026-07-03 08:14:41 --> Helper loaded: html_helper
INFO - 2026-07-03 08:14:41 --> Helper loaded: file_helper
INFO - 2026-07-03 08:14:41 --> Helper loaded: email_helper
INFO - 2026-07-03 08:14:41 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:14:41 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:14:41 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:14:41 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:14:41 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:14:41 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:14:41 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:14:41 --> Database Driver Class Initialized
INFO - 2026-07-03 08:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:14:43 --> Upload Class Initialized
DEBUG - 2026-07-03 08:14:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:14:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:14:43 --> Encryption Class Initialized
INFO - 2026-07-03 08:14:43 --> Form Validation Class Initialized
INFO - 2026-07-03 08:14:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:14:43 --> Pagination Class Initialized
INFO - 2026-07-03 08:14:43 --> Email Class Initialized
INFO - 2026-07-03 08:14:43 --> Controller Class Initialized
DEBUG - 2026-07-03 08:14:43 --> Softwareproduct MX_Controller Initialized
INFO - 2026-07-03 08:14:43 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:14:43 --> Model "Adminauth_model" initialized
DEBUG - 2026-07-03 08:14:43 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 08:14:43 --> Model "Plan_model" initialized
INFO - 2026-07-03 08:14:43 --> Model "Software_model" initialized
DEBUG - 2026-07-03 08:14:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 08:14:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 08:14:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 08:14:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-03 08:14:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 08:14:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/softwareproduct_list.php
INFO - 2026-07-03 08:14:44 --> Final output sent to browser
DEBUG - 2026-07-03 08:14:44 --> Total execution time: 2.8613
INFO - 2026-07-03 08:14:44 --> Config Class Initialized
INFO - 2026-07-03 08:14:44 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:14:44 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:14:44 --> Utf8 Class Initialized
INFO - 2026-07-03 08:14:44 --> URI Class Initialized
INFO - 2026-07-03 08:14:44 --> Router Class Initialized
INFO - 2026-07-03 08:14:44 --> Output Class Initialized
INFO - 2026-07-03 08:14:44 --> Security Class Initialized
DEBUG - 2026-07-03 08:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:14:44 --> CSRF cookie sent
INFO - 2026-07-03 08:14:44 --> Input Class Initialized
INFO - 2026-07-03 08:14:44 --> Language Class Initialized
INFO - 2026-07-03 08:14:44 --> Language Class Initialized
INFO - 2026-07-03 08:14:44 --> Config Class Initialized
INFO - 2026-07-03 08:14:44 --> Loader Class Initialized
INFO - 2026-07-03 08:14:44 --> Helper loaded: url_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: form_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: html_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: file_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: email_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:14:44 --> Database Driver Class Initialized
INFO - 2026-07-03 08:14:44 --> Config Class Initialized
INFO - 2026-07-03 08:14:44 --> Hooks Class Initialized
INFO - 2026-07-03 08:14:44 --> Config Class Initialized
INFO - 2026-07-03 08:14:44 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:14:44 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:14:44 --> Utf8 Class Initialized
DEBUG - 2026-07-03 08:14:44 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:14:44 --> Utf8 Class Initialized
INFO - 2026-07-03 08:14:44 --> URI Class Initialized
INFO - 2026-07-03 08:14:44 --> URI Class Initialized
INFO - 2026-07-03 08:14:44 --> Router Class Initialized
INFO - 2026-07-03 08:14:44 --> Router Class Initialized
INFO - 2026-07-03 08:14:44 --> Output Class Initialized
INFO - 2026-07-03 08:14:44 --> Security Class Initialized
INFO - 2026-07-03 08:14:44 --> Output Class Initialized
DEBUG - 2026-07-03 08:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:14:44 --> CSRF cookie sent
INFO - 2026-07-03 08:14:44 --> Input Class Initialized
INFO - 2026-07-03 08:14:44 --> Language Class Initialized
INFO - 2026-07-03 08:14:44 --> Security Class Initialized
INFO - 2026-07-03 08:14:44 --> Language Class Initialized
INFO - 2026-07-03 08:14:44 --> Config Class Initialized
DEBUG - 2026-07-03 08:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:14:44 --> CSRF cookie sent
INFO - 2026-07-03 08:14:44 --> Input Class Initialized
INFO - 2026-07-03 08:14:44 --> Language Class Initialized
INFO - 2026-07-03 08:14:44 --> Language Class Initialized
INFO - 2026-07-03 08:14:44 --> Config Class Initialized
INFO - 2026-07-03 08:14:44 --> Loader Class Initialized
INFO - 2026-07-03 08:14:44 --> Helper loaded: url_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: form_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: html_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: file_helper
INFO - 2026-07-03 08:14:44 --> Loader Class Initialized
INFO - 2026-07-03 08:14:44 --> Helper loaded: email_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: url_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: form_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: html_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: file_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: email_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:14:44 --> Database Driver Class Initialized
INFO - 2026-07-03 08:14:44 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:14:44 --> Database Driver Class Initialized
INFO - 2026-07-03 08:14:44 --> Config Class Initialized
INFO - 2026-07-03 08:14:44 --> Hooks Class Initialized
INFO - 2026-07-03 08:14:44 --> Config Class Initialized
INFO - 2026-07-03 08:14:44 --> Hooks Class Initialized
INFO - 2026-07-03 08:14:44 --> Config Class Initialized
INFO - 2026-07-03 08:14:44 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:14:44 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:14:44 --> Utf8 Class Initialized
INFO - 2026-07-03 08:14:44 --> URI Class Initialized
DEBUG - 2026-07-03 08:14:44 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:14:44 --> Utf8 Class Initialized
DEBUG - 2026-07-03 08:14:44 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:14:44 --> Utf8 Class Initialized
INFO - 2026-07-03 08:14:44 --> URI Class Initialized
INFO - 2026-07-03 08:14:44 --> Router Class Initialized
INFO - 2026-07-03 08:14:44 --> URI Class Initialized
INFO - 2026-07-03 08:14:44 --> Output Class Initialized
INFO - 2026-07-03 08:14:44 --> Router Class Initialized
INFO - 2026-07-03 08:14:44 --> Security Class Initialized
INFO - 2026-07-03 08:14:44 --> Router Class Initialized
INFO - 2026-07-03 08:14:44 --> Output Class Initialized
DEBUG - 2026-07-03 08:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:14:44 --> CSRF cookie sent
INFO - 2026-07-03 08:14:44 --> Input Class Initialized
INFO - 2026-07-03 08:14:44 --> Language Class Initialized
INFO - 2026-07-03 08:14:44 --> Security Class Initialized
INFO - 2026-07-03 08:14:44 --> Output Class Initialized
INFO - 2026-07-03 08:14:44 --> Language Class Initialized
INFO - 2026-07-03 08:14:44 --> Config Class Initialized
DEBUG - 2026-07-03 08:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:14:44 --> CSRF cookie sent
INFO - 2026-07-03 08:14:44 --> Input Class Initialized
INFO - 2026-07-03 08:14:44 --> Security Class Initialized
INFO - 2026-07-03 08:14:44 --> Language Class Initialized
INFO - 2026-07-03 08:14:44 --> Loader Class Initialized
INFO - 2026-07-03 08:14:44 --> Language Class Initialized
INFO - 2026-07-03 08:14:44 --> Config Class Initialized
DEBUG - 2026-07-03 08:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:14:44 --> CSRF cookie sent
INFO - 2026-07-03 08:14:44 --> Input Class Initialized
INFO - 2026-07-03 08:14:44 --> Helper loaded: url_helper
INFO - 2026-07-03 08:14:44 --> Language Class Initialized
INFO - 2026-07-03 08:14:44 --> Helper loaded: form_helper
INFO - 2026-07-03 08:14:44 --> Language Class Initialized
INFO - 2026-07-03 08:14:44 --> Helper loaded: html_helper
INFO - 2026-07-03 08:14:44 --> Config Class Initialized
INFO - 2026-07-03 08:14:44 --> Helper loaded: file_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: email_helper
INFO - 2026-07-03 08:14:44 --> Loader Class Initialized
INFO - 2026-07-03 08:14:44 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: url_helper
INFO - 2026-07-03 08:14:44 --> Loader Class Initialized
INFO - 2026-07-03 08:14:44 --> Helper loaded: form_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: html_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: url_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: file_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: email_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: form_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: html_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: file_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: email_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:14:44 --> Database Driver Class Initialized
INFO - 2026-07-03 08:14:44 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:14:44 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:14:44 --> Database Driver Class Initialized
INFO - 2026-07-03 08:14:44 --> Database Driver Class Initialized
INFO - 2026-07-03 08:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:14:46 --> Upload Class Initialized
DEBUG - 2026-07-03 08:14:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:14:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:14:46 --> Encryption Class Initialized
INFO - 2026-07-03 08:14:46 --> Form Validation Class Initialized
INFO - 2026-07-03 08:14:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:14:46 --> Pagination Class Initialized
INFO - 2026-07-03 08:14:46 --> Email Class Initialized
INFO - 2026-07-03 08:14:46 --> Controller Class Initialized
ERROR - 2026-07-03 08:14:46 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:14:46 --> Config Class Initialized
INFO - 2026-07-03 08:14:46 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:14:46 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:14:46 --> Utf8 Class Initialized
INFO - 2026-07-03 08:14:46 --> URI Class Initialized
INFO - 2026-07-03 08:14:46 --> Router Class Initialized
INFO - 2026-07-03 08:14:46 --> Output Class Initialized
INFO - 2026-07-03 08:14:46 --> Security Class Initialized
DEBUG - 2026-07-03 08:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:14:46 --> CSRF cookie sent
INFO - 2026-07-03 08:14:46 --> Input Class Initialized
INFO - 2026-07-03 08:14:46 --> Language Class Initialized
INFO - 2026-07-03 08:14:46 --> Language Class Initialized
INFO - 2026-07-03 08:14:46 --> Config Class Initialized
INFO - 2026-07-03 08:14:46 --> Loader Class Initialized
INFO - 2026-07-03 08:14:46 --> Helper loaded: url_helper
INFO - 2026-07-03 08:14:46 --> Helper loaded: form_helper
INFO - 2026-07-03 08:14:46 --> Helper loaded: html_helper
INFO - 2026-07-03 08:14:46 --> Helper loaded: file_helper
INFO - 2026-07-03 08:14:46 --> Helper loaded: email_helper
INFO - 2026-07-03 08:14:46 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:14:46 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:14:46 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:14:46 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:14:46 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:14:46 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:14:46 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:14:46 --> Database Driver Class Initialized
INFO - 2026-07-03 08:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:14:46 --> Upload Class Initialized
DEBUG - 2026-07-03 08:14:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:14:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:14:46 --> Encryption Class Initialized
INFO - 2026-07-03 08:14:46 --> Form Validation Class Initialized
INFO - 2026-07-03 08:14:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:14:46 --> Pagination Class Initialized
INFO - 2026-07-03 08:14:46 --> Email Class Initialized
INFO - 2026-07-03 08:14:46 --> Controller Class Initialized
ERROR - 2026-07-03 08:14:46 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:14:46 --> Upload Class Initialized
DEBUG - 2026-07-03 08:14:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:14:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:14:46 --> Encryption Class Initialized
INFO - 2026-07-03 08:14:46 --> Form Validation Class Initialized
INFO - 2026-07-03 08:14:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:14:46 --> Pagination Class Initialized
INFO - 2026-07-03 08:14:46 --> Email Class Initialized
INFO - 2026-07-03 08:14:46 --> Controller Class Initialized
ERROR - 2026-07-03 08:14:46 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:14:46 --> Upload Class Initialized
DEBUG - 2026-07-03 08:14:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:14:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:14:46 --> Encryption Class Initialized
INFO - 2026-07-03 08:14:46 --> Form Validation Class Initialized
INFO - 2026-07-03 08:14:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:14:46 --> Pagination Class Initialized
INFO - 2026-07-03 08:14:46 --> Email Class Initialized
INFO - 2026-07-03 08:14:46 --> Controller Class Initialized
ERROR - 2026-07-03 08:14:46 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:14:46 --> Upload Class Initialized
DEBUG - 2026-07-03 08:14:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:14:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:14:46 --> Encryption Class Initialized
INFO - 2026-07-03 08:14:46 --> Form Validation Class Initialized
INFO - 2026-07-03 08:14:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:14:46 --> Pagination Class Initialized
INFO - 2026-07-03 08:14:46 --> Email Class Initialized
INFO - 2026-07-03 08:14:46 --> Controller Class Initialized
ERROR - 2026-07-03 08:14:46 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:14:46 --> Upload Class Initialized
DEBUG - 2026-07-03 08:14:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:14:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:14:46 --> Encryption Class Initialized
INFO - 2026-07-03 08:14:46 --> Form Validation Class Initialized
INFO - 2026-07-03 08:14:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:14:46 --> Pagination Class Initialized
INFO - 2026-07-03 08:14:46 --> Email Class Initialized
INFO - 2026-07-03 08:14:46 --> Controller Class Initialized
ERROR - 2026-07-03 08:14:46 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:14:48 --> Upload Class Initialized
DEBUG - 2026-07-03 08:14:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:14:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:14:48 --> Encryption Class Initialized
INFO - 2026-07-03 08:14:48 --> Form Validation Class Initialized
INFO - 2026-07-03 08:14:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:14:48 --> Pagination Class Initialized
INFO - 2026-07-03 08:14:48 --> Email Class Initialized
INFO - 2026-07-03 08:14:48 --> Controller Class Initialized
ERROR - 2026-07-03 08:14:48 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:15:49 --> Config Class Initialized
INFO - 2026-07-03 08:15:49 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:15:49 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:15:49 --> Utf8 Class Initialized
INFO - 2026-07-03 08:15:49 --> URI Class Initialized
INFO - 2026-07-03 08:15:49 --> Router Class Initialized
INFO - 2026-07-03 08:15:49 --> Output Class Initialized
INFO - 2026-07-03 08:15:49 --> Security Class Initialized
DEBUG - 2026-07-03 08:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:15:49 --> CSRF cookie sent
INFO - 2026-07-03 08:15:49 --> Input Class Initialized
INFO - 2026-07-03 08:15:49 --> Language Class Initialized
INFO - 2026-07-03 08:15:49 --> Language Class Initialized
INFO - 2026-07-03 08:15:49 --> Config Class Initialized
INFO - 2026-07-03 08:15:49 --> Loader Class Initialized
INFO - 2026-07-03 08:15:49 --> Helper loaded: url_helper
INFO - 2026-07-03 08:15:49 --> Helper loaded: form_helper
INFO - 2026-07-03 08:15:49 --> Helper loaded: html_helper
INFO - 2026-07-03 08:15:49 --> Helper loaded: file_helper
INFO - 2026-07-03 08:15:49 --> Helper loaded: email_helper
INFO - 2026-07-03 08:15:49 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:15:49 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:15:49 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:15:49 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:15:49 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:15:49 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:15:49 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:15:49 --> Database Driver Class Initialized
INFO - 2026-07-03 08:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:15:51 --> Upload Class Initialized
DEBUG - 2026-07-03 08:15:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:15:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:15:51 --> Encryption Class Initialized
INFO - 2026-07-03 08:15:51 --> Form Validation Class Initialized
INFO - 2026-07-03 08:15:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:15:51 --> Pagination Class Initialized
INFO - 2026-07-03 08:15:51 --> Email Class Initialized
INFO - 2026-07-03 08:15:51 --> Controller Class Initialized
DEBUG - 2026-07-03 08:15:51 --> Softwareproduct MX_Controller Initialized
INFO - 2026-07-03 08:15:51 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:15:51 --> Model "Adminauth_model" initialized
DEBUG - 2026-07-03 08:15:51 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 08:15:51 --> Model "Plan_model" initialized
INFO - 2026-07-03 08:15:51 --> Model "Software_model" initialized
DEBUG - 2026-07-03 08:15:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 08:15:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 08:15:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 08:15:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-03 08:15:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 08:15:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/softwareproduct_list.php
INFO - 2026-07-03 08:15:52 --> Final output sent to browser
DEBUG - 2026-07-03 08:15:52 --> Total execution time: 3.1544
INFO - 2026-07-03 08:15:52 --> Config Class Initialized
INFO - 2026-07-03 08:15:52 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:15:52 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:15:52 --> Utf8 Class Initialized
INFO - 2026-07-03 08:15:52 --> URI Class Initialized
INFO - 2026-07-03 08:15:52 --> Router Class Initialized
INFO - 2026-07-03 08:15:52 --> Output Class Initialized
INFO - 2026-07-03 08:15:52 --> Security Class Initialized
DEBUG - 2026-07-03 08:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:15:52 --> CSRF cookie sent
INFO - 2026-07-03 08:15:52 --> Input Class Initialized
INFO - 2026-07-03 08:15:52 --> Language Class Initialized
INFO - 2026-07-03 08:15:52 --> Language Class Initialized
INFO - 2026-07-03 08:15:52 --> Config Class Initialized
INFO - 2026-07-03 08:15:52 --> Loader Class Initialized
INFO - 2026-07-03 08:15:52 --> Helper loaded: url_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: form_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: html_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: file_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: email_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:15:52 --> Database Driver Class Initialized
INFO - 2026-07-03 08:15:52 --> Config Class Initialized
INFO - 2026-07-03 08:15:52 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:15:52 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:15:52 --> Utf8 Class Initialized
INFO - 2026-07-03 08:15:52 --> URI Class Initialized
INFO - 2026-07-03 08:15:52 --> Router Class Initialized
INFO - 2026-07-03 08:15:52 --> Output Class Initialized
INFO - 2026-07-03 08:15:52 --> Security Class Initialized
DEBUG - 2026-07-03 08:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:15:52 --> CSRF cookie sent
INFO - 2026-07-03 08:15:52 --> Input Class Initialized
INFO - 2026-07-03 08:15:52 --> Language Class Initialized
INFO - 2026-07-03 08:15:52 --> Language Class Initialized
INFO - 2026-07-03 08:15:52 --> Config Class Initialized
INFO - 2026-07-03 08:15:52 --> Loader Class Initialized
INFO - 2026-07-03 08:15:52 --> Helper loaded: url_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: form_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: html_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: file_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: email_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:15:52 --> Database Driver Class Initialized
INFO - 2026-07-03 08:15:52 --> Config Class Initialized
INFO - 2026-07-03 08:15:52 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:15:52 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:15:52 --> Utf8 Class Initialized
INFO - 2026-07-03 08:15:52 --> URI Class Initialized
INFO - 2026-07-03 08:15:52 --> Router Class Initialized
INFO - 2026-07-03 08:15:52 --> Output Class Initialized
INFO - 2026-07-03 08:15:52 --> Config Class Initialized
INFO - 2026-07-03 08:15:52 --> Hooks Class Initialized
INFO - 2026-07-03 08:15:52 --> Security Class Initialized
DEBUG - 2026-07-03 08:15:52 --> UTF-8 Support Enabled
DEBUG - 2026-07-03 08:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:15:52 --> Utf8 Class Initialized
INFO - 2026-07-03 08:15:52 --> CSRF cookie sent
INFO - 2026-07-03 08:15:52 --> Input Class Initialized
INFO - 2026-07-03 08:15:52 --> Language Class Initialized
INFO - 2026-07-03 08:15:52 --> URI Class Initialized
INFO - 2026-07-03 08:15:52 --> Language Class Initialized
INFO - 2026-07-03 08:15:52 --> Config Class Initialized
INFO - 2026-07-03 08:15:52 --> Router Class Initialized
INFO - 2026-07-03 08:15:52 --> Loader Class Initialized
INFO - 2026-07-03 08:15:52 --> Output Class Initialized
INFO - 2026-07-03 08:15:52 --> Helper loaded: url_helper
INFO - 2026-07-03 08:15:52 --> Security Class Initialized
INFO - 2026-07-03 08:15:52 --> Helper loaded: form_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: html_helper
DEBUG - 2026-07-03 08:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:15:52 --> CSRF cookie sent
INFO - 2026-07-03 08:15:52 --> Input Class Initialized
INFO - 2026-07-03 08:15:52 --> Helper loaded: file_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: email_helper
INFO - 2026-07-03 08:15:52 --> Language Class Initialized
INFO - 2026-07-03 08:15:52 --> Language Class Initialized
INFO - 2026-07-03 08:15:52 --> Config Class Initialized
INFO - 2026-07-03 08:15:52 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:15:52 --> Loader Class Initialized
INFO - 2026-07-03 08:15:52 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: url_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: form_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: html_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: file_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: email_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:15:52 --> Database Driver Class Initialized
INFO - 2026-07-03 08:15:52 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:15:52 --> Database Driver Class Initialized
INFO - 2026-07-03 08:15:52 --> Config Class Initialized
INFO - 2026-07-03 08:15:52 --> Hooks Class Initialized
INFO - 2026-07-03 08:15:52 --> Config Class Initialized
INFO - 2026-07-03 08:15:52 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:15:52 --> UTF-8 Support Enabled
DEBUG - 2026-07-03 08:15:52 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:15:52 --> Utf8 Class Initialized
INFO - 2026-07-03 08:15:52 --> Utf8 Class Initialized
INFO - 2026-07-03 08:15:52 --> URI Class Initialized
INFO - 2026-07-03 08:15:52 --> URI Class Initialized
INFO - 2026-07-03 08:15:52 --> Router Class Initialized
INFO - 2026-07-03 08:15:52 --> Router Class Initialized
INFO - 2026-07-03 08:15:52 --> Output Class Initialized
INFO - 2026-07-03 08:15:52 --> Output Class Initialized
INFO - 2026-07-03 08:15:52 --> Security Class Initialized
INFO - 2026-07-03 08:15:52 --> Security Class Initialized
DEBUG - 2026-07-03 08:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-07-03 08:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:15:52 --> CSRF cookie sent
INFO - 2026-07-03 08:15:52 --> CSRF cookie sent
INFO - 2026-07-03 08:15:52 --> Input Class Initialized
INFO - 2026-07-03 08:15:52 --> Input Class Initialized
INFO - 2026-07-03 08:15:52 --> Language Class Initialized
INFO - 2026-07-03 08:15:52 --> Language Class Initialized
INFO - 2026-07-03 08:15:52 --> Language Class Initialized
INFO - 2026-07-03 08:15:52 --> Language Class Initialized
INFO - 2026-07-03 08:15:52 --> Config Class Initialized
INFO - 2026-07-03 08:15:52 --> Config Class Initialized
INFO - 2026-07-03 08:15:52 --> Loader Class Initialized
INFO - 2026-07-03 08:15:52 --> Loader Class Initialized
INFO - 2026-07-03 08:15:52 --> Helper loaded: url_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: url_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: form_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: form_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: html_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: html_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: file_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: file_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: email_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: email_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:15:52 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:15:53 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:15:53 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:15:53 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:15:53 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:15:53 --> Database Driver Class Initialized
INFO - 2026-07-03 08:15:53 --> Database Driver Class Initialized
INFO - 2026-07-03 08:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:15:54 --> Upload Class Initialized
DEBUG - 2026-07-03 08:15:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:15:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:15:54 --> Encryption Class Initialized
INFO - 2026-07-03 08:15:54 --> Form Validation Class Initialized
INFO - 2026-07-03 08:15:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:15:54 --> Pagination Class Initialized
INFO - 2026-07-03 08:15:54 --> Email Class Initialized
INFO - 2026-07-03 08:15:54 --> Controller Class Initialized
ERROR - 2026-07-03 08:15:54 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:15:54 --> Config Class Initialized
INFO - 2026-07-03 08:15:54 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:15:54 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:15:54 --> Utf8 Class Initialized
INFO - 2026-07-03 08:15:54 --> URI Class Initialized
INFO - 2026-07-03 08:15:54 --> Router Class Initialized
INFO - 2026-07-03 08:15:54 --> Output Class Initialized
INFO - 2026-07-03 08:15:54 --> Security Class Initialized
DEBUG - 2026-07-03 08:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:15:54 --> CSRF cookie sent
INFO - 2026-07-03 08:15:54 --> Input Class Initialized
INFO - 2026-07-03 08:15:54 --> Language Class Initialized
INFO - 2026-07-03 08:15:54 --> Language Class Initialized
INFO - 2026-07-03 08:15:54 --> Config Class Initialized
INFO - 2026-07-03 08:15:54 --> Loader Class Initialized
INFO - 2026-07-03 08:15:54 --> Helper loaded: url_helper
INFO - 2026-07-03 08:15:54 --> Helper loaded: form_helper
INFO - 2026-07-03 08:15:54 --> Helper loaded: html_helper
INFO - 2026-07-03 08:15:54 --> Helper loaded: file_helper
INFO - 2026-07-03 08:15:54 --> Helper loaded: email_helper
INFO - 2026-07-03 08:15:54 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:15:54 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:15:54 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:15:54 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:15:54 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:15:54 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:15:54 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:15:54 --> Database Driver Class Initialized
INFO - 2026-07-03 08:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:15:54 --> Upload Class Initialized
DEBUG - 2026-07-03 08:15:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:15:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:15:54 --> Encryption Class Initialized
INFO - 2026-07-03 08:15:54 --> Form Validation Class Initialized
INFO - 2026-07-03 08:15:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:15:54 --> Pagination Class Initialized
INFO - 2026-07-03 08:15:54 --> Email Class Initialized
INFO - 2026-07-03 08:15:54 --> Controller Class Initialized
ERROR - 2026-07-03 08:15:54 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:15:54 --> Upload Class Initialized
DEBUG - 2026-07-03 08:15:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:15:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:15:54 --> Encryption Class Initialized
INFO - 2026-07-03 08:15:54 --> Form Validation Class Initialized
INFO - 2026-07-03 08:15:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:15:54 --> Pagination Class Initialized
INFO - 2026-07-03 08:15:54 --> Email Class Initialized
INFO - 2026-07-03 08:15:54 --> Controller Class Initialized
ERROR - 2026-07-03 08:15:54 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:15:54 --> Upload Class Initialized
DEBUG - 2026-07-03 08:15:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:15:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:15:54 --> Encryption Class Initialized
INFO - 2026-07-03 08:15:54 --> Form Validation Class Initialized
INFO - 2026-07-03 08:15:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:15:54 --> Pagination Class Initialized
INFO - 2026-07-03 08:15:54 --> Email Class Initialized
INFO - 2026-07-03 08:15:54 --> Controller Class Initialized
ERROR - 2026-07-03 08:15:54 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:15:54 --> Upload Class Initialized
DEBUG - 2026-07-03 08:15:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:15:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:15:54 --> Encryption Class Initialized
INFO - 2026-07-03 08:15:54 --> Form Validation Class Initialized
INFO - 2026-07-03 08:15:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:15:54 --> Pagination Class Initialized
INFO - 2026-07-03 08:15:54 --> Email Class Initialized
INFO - 2026-07-03 08:15:54 --> Controller Class Initialized
ERROR - 2026-07-03 08:15:54 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:15:54 --> Upload Class Initialized
DEBUG - 2026-07-03 08:15:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:15:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:15:54 --> Encryption Class Initialized
INFO - 2026-07-03 08:15:54 --> Form Validation Class Initialized
INFO - 2026-07-03 08:15:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:15:54 --> Pagination Class Initialized
INFO - 2026-07-03 08:15:54 --> Email Class Initialized
INFO - 2026-07-03 08:15:54 --> Controller Class Initialized
ERROR - 2026-07-03 08:15:54 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:15:56 --> Upload Class Initialized
DEBUG - 2026-07-03 08:15:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:15:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:15:56 --> Encryption Class Initialized
INFO - 2026-07-03 08:15:56 --> Form Validation Class Initialized
INFO - 2026-07-03 08:15:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:15:56 --> Pagination Class Initialized
INFO - 2026-07-03 08:15:56 --> Email Class Initialized
INFO - 2026-07-03 08:15:56 --> Controller Class Initialized
ERROR - 2026-07-03 08:15:56 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:15:58 --> Config Class Initialized
INFO - 2026-07-03 08:15:58 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:15:58 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:15:58 --> Utf8 Class Initialized
INFO - 2026-07-03 08:15:58 --> URI Class Initialized
INFO - 2026-07-03 08:15:58 --> Router Class Initialized
INFO - 2026-07-03 08:15:58 --> Output Class Initialized
INFO - 2026-07-03 08:15:58 --> Security Class Initialized
DEBUG - 2026-07-03 08:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:15:58 --> CSRF cookie sent
INFO - 2026-07-03 08:15:58 --> Input Class Initialized
INFO - 2026-07-03 08:15:58 --> Language Class Initialized
INFO - 2026-07-03 08:15:58 --> Language Class Initialized
INFO - 2026-07-03 08:15:58 --> Config Class Initialized
INFO - 2026-07-03 08:15:58 --> Loader Class Initialized
INFO - 2026-07-03 08:15:58 --> Helper loaded: url_helper
INFO - 2026-07-03 08:15:58 --> Helper loaded: form_helper
INFO - 2026-07-03 08:15:58 --> Helper loaded: html_helper
INFO - 2026-07-03 08:15:58 --> Helper loaded: file_helper
INFO - 2026-07-03 08:15:58 --> Helper loaded: email_helper
INFO - 2026-07-03 08:15:58 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:15:58 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:15:58 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:15:58 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:15:58 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:15:58 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:15:58 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:15:58 --> Database Driver Class Initialized
INFO - 2026-07-03 08:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:16:00 --> Upload Class Initialized
DEBUG - 2026-07-03 08:16:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:16:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:16:00 --> Encryption Class Initialized
INFO - 2026-07-03 08:16:00 --> Form Validation Class Initialized
INFO - 2026-07-03 08:16:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:16:00 --> Pagination Class Initialized
INFO - 2026-07-03 08:16:00 --> Email Class Initialized
INFO - 2026-07-03 08:16:00 --> Controller Class Initialized
DEBUG - 2026-07-03 08:16:00 --> Software MX_Controller Initialized
INFO - 2026-07-03 08:16:00 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:16:00 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:16:00 --> Model "Software_model" initialized
DEBUG - 2026-07-03 08:16:00 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 08:16:00 --> Model "Plan_model" initialized
DEBUG - 2026-07-03 08:16:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 08:16:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 08:16:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 08:16:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 08:16:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/software_manage.php
INFO - 2026-07-03 08:16:02 --> Final output sent to browser
DEBUG - 2026-07-03 08:16:02 --> Total execution time: 3.6735
INFO - 2026-07-03 08:16:42 --> Config Class Initialized
INFO - 2026-07-03 08:16:42 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:16:42 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:16:42 --> Utf8 Class Initialized
INFO - 2026-07-03 08:16:42 --> URI Class Initialized
INFO - 2026-07-03 08:16:42 --> Router Class Initialized
INFO - 2026-07-03 08:16:42 --> Output Class Initialized
INFO - 2026-07-03 08:16:42 --> Security Class Initialized
DEBUG - 2026-07-03 08:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:16:42 --> CSRF cookie sent
INFO - 2026-07-03 08:16:42 --> CSRF token verified
INFO - 2026-07-03 08:16:42 --> Input Class Initialized
INFO - 2026-07-03 08:16:42 --> Language Class Initialized
INFO - 2026-07-03 08:16:42 --> Language Class Initialized
INFO - 2026-07-03 08:16:42 --> Config Class Initialized
INFO - 2026-07-03 08:16:42 --> Loader Class Initialized
INFO - 2026-07-03 08:16:42 --> Helper loaded: url_helper
INFO - 2026-07-03 08:16:42 --> Helper loaded: form_helper
INFO - 2026-07-03 08:16:42 --> Helper loaded: html_helper
INFO - 2026-07-03 08:16:42 --> Helper loaded: file_helper
INFO - 2026-07-03 08:16:42 --> Helper loaded: email_helper
INFO - 2026-07-03 08:16:42 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:16:42 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:16:42 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:16:42 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:16:42 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:16:42 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:16:42 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:16:42 --> Database Driver Class Initialized
INFO - 2026-07-03 08:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:16:44 --> Upload Class Initialized
DEBUG - 2026-07-03 08:16:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:16:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:16:44 --> Encryption Class Initialized
INFO - 2026-07-03 08:16:44 --> Form Validation Class Initialized
INFO - 2026-07-03 08:16:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:16:44 --> Pagination Class Initialized
INFO - 2026-07-03 08:16:44 --> Email Class Initialized
INFO - 2026-07-03 08:16:44 --> Controller Class Initialized
DEBUG - 2026-07-03 08:16:44 --> Software MX_Controller Initialized
INFO - 2026-07-03 08:16:44 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:16:44 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:16:44 --> Model "Software_model" initialized
DEBUG - 2026-07-03 08:16:44 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 08:16:44 --> Model "Plan_model" initialized
INFO - 2026-07-03 08:16:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-07-03 08:16:44 --> Language file loaded: language/english/upload_lang.php
ERROR - 2026-07-03 08:16:44 --> The upload destination folder does not appear to be writable.
INFO - 2026-07-03 08:16:45 --> Config Class Initialized
INFO - 2026-07-03 08:16:45 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:16:45 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:16:45 --> Utf8 Class Initialized
INFO - 2026-07-03 08:16:45 --> URI Class Initialized
INFO - 2026-07-03 08:16:45 --> Router Class Initialized
INFO - 2026-07-03 08:16:45 --> Output Class Initialized
INFO - 2026-07-03 08:16:45 --> Security Class Initialized
DEBUG - 2026-07-03 08:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:16:45 --> CSRF cookie sent
INFO - 2026-07-03 08:16:45 --> Input Class Initialized
INFO - 2026-07-03 08:16:45 --> Language Class Initialized
INFO - 2026-07-03 08:16:45 --> Language Class Initialized
INFO - 2026-07-03 08:16:45 --> Config Class Initialized
INFO - 2026-07-03 08:16:45 --> Loader Class Initialized
INFO - 2026-07-03 08:16:45 --> Helper loaded: url_helper
INFO - 2026-07-03 08:16:45 --> Helper loaded: form_helper
INFO - 2026-07-03 08:16:45 --> Helper loaded: html_helper
INFO - 2026-07-03 08:16:45 --> Helper loaded: file_helper
INFO - 2026-07-03 08:16:45 --> Helper loaded: email_helper
INFO - 2026-07-03 08:16:45 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:16:45 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:16:45 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:16:45 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:16:45 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:16:45 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:16:45 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:16:45 --> Database Driver Class Initialized
INFO - 2026-07-03 08:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:16:46 --> Upload Class Initialized
DEBUG - 2026-07-03 08:16:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:16:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:16:46 --> Encryption Class Initialized
INFO - 2026-07-03 08:16:46 --> Form Validation Class Initialized
INFO - 2026-07-03 08:16:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:16:46 --> Pagination Class Initialized
INFO - 2026-07-03 08:16:46 --> Email Class Initialized
INFO - 2026-07-03 08:16:46 --> Controller Class Initialized
DEBUG - 2026-07-03 08:16:46 --> Software MX_Controller Initialized
INFO - 2026-07-03 08:16:46 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:16:46 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:16:46 --> Model "Software_model" initialized
DEBUG - 2026-07-03 08:16:46 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 08:16:46 --> Model "Plan_model" initialized
DEBUG - 2026-07-03 08:16:48 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 08:16:48 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 08:16:48 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 08:16:48 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 08:16:48 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/software_manage.php
INFO - 2026-07-03 08:16:48 --> Final output sent to browser
DEBUG - 2026-07-03 08:16:48 --> Total execution time: 3.5476
INFO - 2026-07-03 08:19:15 --> Config Class Initialized
INFO - 2026-07-03 08:19:15 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:19:15 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:19:15 --> Utf8 Class Initialized
INFO - 2026-07-03 08:19:15 --> URI Class Initialized
INFO - 2026-07-03 08:19:15 --> Router Class Initialized
INFO - 2026-07-03 08:19:15 --> Output Class Initialized
INFO - 2026-07-03 08:19:15 --> Security Class Initialized
DEBUG - 2026-07-03 08:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:19:15 --> CSRF cookie sent
INFO - 2026-07-03 08:19:15 --> CSRF token verified
INFO - 2026-07-03 08:19:15 --> Input Class Initialized
INFO - 2026-07-03 08:19:15 --> Language Class Initialized
INFO - 2026-07-03 08:19:15 --> Language Class Initialized
INFO - 2026-07-03 08:19:15 --> Config Class Initialized
INFO - 2026-07-03 08:19:15 --> Loader Class Initialized
INFO - 2026-07-03 08:19:15 --> Helper loaded: url_helper
INFO - 2026-07-03 08:19:15 --> Helper loaded: form_helper
INFO - 2026-07-03 08:19:15 --> Helper loaded: html_helper
INFO - 2026-07-03 08:19:15 --> Helper loaded: file_helper
INFO - 2026-07-03 08:19:15 --> Helper loaded: email_helper
INFO - 2026-07-03 08:19:15 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:19:15 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:19:15 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:19:15 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:19:15 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:19:15 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:19:15 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:19:15 --> Database Driver Class Initialized
INFO - 2026-07-03 08:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:19:17 --> Upload Class Initialized
DEBUG - 2026-07-03 08:19:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:19:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:19:17 --> Encryption Class Initialized
INFO - 2026-07-03 08:19:17 --> Form Validation Class Initialized
INFO - 2026-07-03 08:19:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:19:17 --> Pagination Class Initialized
INFO - 2026-07-03 08:19:17 --> Email Class Initialized
INFO - 2026-07-03 08:19:17 --> Controller Class Initialized
DEBUG - 2026-07-03 08:19:17 --> Software MX_Controller Initialized
INFO - 2026-07-03 08:19:17 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:19:17 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:19:17 --> Model "Software_model" initialized
DEBUG - 2026-07-03 08:19:17 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 08:19:17 --> Model "Plan_model" initialized
INFO - 2026-07-03 08:19:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2026-07-03 08:19:19 --> Config Class Initialized
INFO - 2026-07-03 08:19:19 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:19:19 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:19:19 --> Utf8 Class Initialized
INFO - 2026-07-03 08:19:19 --> URI Class Initialized
INFO - 2026-07-03 08:19:19 --> Router Class Initialized
INFO - 2026-07-03 08:19:19 --> Output Class Initialized
INFO - 2026-07-03 08:19:19 --> Security Class Initialized
DEBUG - 2026-07-03 08:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:19:19 --> CSRF cookie sent
INFO - 2026-07-03 08:19:19 --> Input Class Initialized
INFO - 2026-07-03 08:19:19 --> Language Class Initialized
INFO - 2026-07-03 08:19:19 --> Language Class Initialized
INFO - 2026-07-03 08:19:19 --> Config Class Initialized
INFO - 2026-07-03 08:19:19 --> Loader Class Initialized
INFO - 2026-07-03 08:19:19 --> Helper loaded: url_helper
INFO - 2026-07-03 08:19:19 --> Helper loaded: form_helper
INFO - 2026-07-03 08:19:19 --> Helper loaded: html_helper
INFO - 2026-07-03 08:19:19 --> Helper loaded: file_helper
INFO - 2026-07-03 08:19:19 --> Helper loaded: email_helper
INFO - 2026-07-03 08:19:19 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:19:19 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:19:19 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:19:19 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:19:19 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:19:19 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:19:19 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:19:19 --> Database Driver Class Initialized
INFO - 2026-07-03 08:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:19:21 --> Upload Class Initialized
DEBUG - 2026-07-03 08:19:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:19:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:19:21 --> Encryption Class Initialized
INFO - 2026-07-03 08:19:21 --> Form Validation Class Initialized
INFO - 2026-07-03 08:19:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:19:21 --> Pagination Class Initialized
INFO - 2026-07-03 08:19:21 --> Email Class Initialized
INFO - 2026-07-03 08:19:21 --> Controller Class Initialized
DEBUG - 2026-07-03 08:19:21 --> Software MX_Controller Initialized
INFO - 2026-07-03 08:19:21 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:19:21 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:19:21 --> Model "Software_model" initialized
DEBUG - 2026-07-03 08:19:21 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 08:19:21 --> Model "Plan_model" initialized
DEBUG - 2026-07-03 08:19:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 08:19:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 08:19:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 08:19:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 08:19:22 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/software_manage.php
INFO - 2026-07-03 08:19:22 --> Final output sent to browser
DEBUG - 2026-07-03 08:19:22 --> Total execution time: 3.6074
INFO - 2026-07-03 08:19:51 --> Config Class Initialized
INFO - 2026-07-03 08:19:51 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:19:51 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:19:51 --> Utf8 Class Initialized
INFO - 2026-07-03 08:19:51 --> URI Class Initialized
INFO - 2026-07-03 08:19:51 --> Router Class Initialized
INFO - 2026-07-03 08:19:51 --> Output Class Initialized
INFO - 2026-07-03 08:19:51 --> Security Class Initialized
DEBUG - 2026-07-03 08:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:19:51 --> CSRF cookie sent
INFO - 2026-07-03 08:19:51 --> Input Class Initialized
INFO - 2026-07-03 08:19:51 --> Language Class Initialized
INFO - 2026-07-03 08:19:51 --> Language Class Initialized
INFO - 2026-07-03 08:19:51 --> Config Class Initialized
INFO - 2026-07-03 08:19:51 --> Loader Class Initialized
INFO - 2026-07-03 08:19:51 --> Helper loaded: url_helper
INFO - 2026-07-03 08:19:51 --> Helper loaded: form_helper
INFO - 2026-07-03 08:19:51 --> Helper loaded: html_helper
INFO - 2026-07-03 08:19:51 --> Helper loaded: file_helper
INFO - 2026-07-03 08:19:51 --> Helper loaded: email_helper
INFO - 2026-07-03 08:19:51 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:19:51 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:19:51 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:19:51 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:19:51 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:19:51 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:19:51 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:19:51 --> Database Driver Class Initialized
INFO - 2026-07-03 08:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:19:53 --> Upload Class Initialized
DEBUG - 2026-07-03 08:19:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:19:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:19:53 --> Encryption Class Initialized
INFO - 2026-07-03 08:19:53 --> Form Validation Class Initialized
INFO - 2026-07-03 08:19:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:19:53 --> Pagination Class Initialized
INFO - 2026-07-03 08:19:53 --> Email Class Initialized
INFO - 2026-07-03 08:19:53 --> Controller Class Initialized
DEBUG - 2026-07-03 08:19:53 --> Software MX_Controller Initialized
INFO - 2026-07-03 08:19:53 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:19:53 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:19:53 --> Model "Software_model" initialized
DEBUG - 2026-07-03 08:19:53 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 08:19:53 --> Model "Plan_model" initialized
DEBUG - 2026-07-03 08:19:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 08:19:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 08:19:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 08:19:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 08:19:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/software_manage.php
INFO - 2026-07-03 08:19:54 --> Final output sent to browser
DEBUG - 2026-07-03 08:19:54 --> Total execution time: 3.2276
INFO - 2026-07-03 08:19:57 --> Config Class Initialized
INFO - 2026-07-03 08:19:57 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:19:57 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:19:57 --> Utf8 Class Initialized
INFO - 2026-07-03 08:19:57 --> URI Class Initialized
INFO - 2026-07-03 08:19:57 --> Router Class Initialized
INFO - 2026-07-03 08:19:57 --> Output Class Initialized
INFO - 2026-07-03 08:19:57 --> Security Class Initialized
DEBUG - 2026-07-03 08:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:19:57 --> CSRF cookie sent
INFO - 2026-07-03 08:19:57 --> Input Class Initialized
INFO - 2026-07-03 08:19:57 --> Language Class Initialized
INFO - 2026-07-03 08:19:57 --> Language Class Initialized
INFO - 2026-07-03 08:19:57 --> Config Class Initialized
INFO - 2026-07-03 08:19:57 --> Loader Class Initialized
INFO - 2026-07-03 08:19:57 --> Helper loaded: url_helper
INFO - 2026-07-03 08:19:57 --> Helper loaded: form_helper
INFO - 2026-07-03 08:19:57 --> Helper loaded: html_helper
INFO - 2026-07-03 08:19:57 --> Helper loaded: file_helper
INFO - 2026-07-03 08:19:57 --> Helper loaded: email_helper
INFO - 2026-07-03 08:19:57 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:19:57 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:19:57 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:19:57 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:19:57 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:19:57 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:19:57 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:19:57 --> Database Driver Class Initialized
INFO - 2026-07-03 08:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:19:59 --> Upload Class Initialized
DEBUG - 2026-07-03 08:19:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:19:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:19:59 --> Encryption Class Initialized
INFO - 2026-07-03 08:19:59 --> Form Validation Class Initialized
INFO - 2026-07-03 08:19:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:19:59 --> Pagination Class Initialized
INFO - 2026-07-03 08:19:59 --> Email Class Initialized
INFO - 2026-07-03 08:19:59 --> Controller Class Initialized
DEBUG - 2026-07-03 08:19:59 --> Software MX_Controller Initialized
INFO - 2026-07-03 08:19:59 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:19:59 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:19:59 --> Model "Software_model" initialized
DEBUG - 2026-07-03 08:19:59 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 08:19:59 --> Model "Plan_model" initialized
DEBUG - 2026-07-03 08:20:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 08:20:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 08:20:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 08:20:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 08:20:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/software_manage.php
INFO - 2026-07-03 08:20:01 --> Final output sent to browser
DEBUG - 2026-07-03 08:20:01 --> Total execution time: 3.5388
INFO - 2026-07-03 08:22:40 --> Config Class Initialized
INFO - 2026-07-03 08:22:40 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:22:40 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:22:40 --> Utf8 Class Initialized
INFO - 2026-07-03 08:22:40 --> URI Class Initialized
INFO - 2026-07-03 08:22:40 --> Router Class Initialized
INFO - 2026-07-03 08:22:40 --> Output Class Initialized
INFO - 2026-07-03 08:22:40 --> Security Class Initialized
DEBUG - 2026-07-03 08:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:22:40 --> CSRF cookie sent
INFO - 2026-07-03 08:22:40 --> Input Class Initialized
INFO - 2026-07-03 08:22:40 --> Language Class Initialized
INFO - 2026-07-03 08:22:40 --> Language Class Initialized
INFO - 2026-07-03 08:22:40 --> Config Class Initialized
INFO - 2026-07-03 08:22:40 --> Loader Class Initialized
INFO - 2026-07-03 08:22:40 --> Helper loaded: url_helper
INFO - 2026-07-03 08:22:40 --> Helper loaded: form_helper
INFO - 2026-07-03 08:22:40 --> Helper loaded: html_helper
INFO - 2026-07-03 08:22:40 --> Helper loaded: file_helper
INFO - 2026-07-03 08:22:40 --> Helper loaded: email_helper
INFO - 2026-07-03 08:22:40 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:22:40 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:22:40 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:22:40 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:22:40 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:22:40 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:22:40 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:22:40 --> Database Driver Class Initialized
INFO - 2026-07-03 08:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:22:42 --> Upload Class Initialized
DEBUG - 2026-07-03 08:22:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:22:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:22:42 --> Encryption Class Initialized
INFO - 2026-07-03 08:22:42 --> Form Validation Class Initialized
INFO - 2026-07-03 08:22:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:22:42 --> Pagination Class Initialized
INFO - 2026-07-03 08:22:42 --> Email Class Initialized
INFO - 2026-07-03 08:22:42 --> Controller Class Initialized
DEBUG - 2026-07-03 08:22:42 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 08:22:42 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:22:42 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:22:42 --> Model "Dashboard_model" initialized
DEBUG - 2026-07-03 08:22:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 08:22:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 08:22:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 08:22:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-03 08:22:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 08:22:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/dashboard_index.php
INFO - 2026-07-03 08:22:42 --> Final output sent to browser
DEBUG - 2026-07-03 08:22:42 --> Total execution time: 2.3289
INFO - 2026-07-03 08:22:43 --> Config Class Initialized
INFO - 2026-07-03 08:22:43 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:22:43 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:22:43 --> Utf8 Class Initialized
INFO - 2026-07-03 08:22:43 --> URI Class Initialized
INFO - 2026-07-03 08:22:43 --> Router Class Initialized
INFO - 2026-07-03 08:22:43 --> Output Class Initialized
INFO - 2026-07-03 08:22:43 --> Security Class Initialized
DEBUG - 2026-07-03 08:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:22:43 --> CSRF cookie sent
INFO - 2026-07-03 08:22:43 --> Input Class Initialized
INFO - 2026-07-03 08:22:43 --> Language Class Initialized
INFO - 2026-07-03 08:22:43 --> Language Class Initialized
INFO - 2026-07-03 08:22:43 --> Config Class Initialized
INFO - 2026-07-03 08:22:43 --> Loader Class Initialized
INFO - 2026-07-03 08:22:43 --> Helper loaded: url_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: form_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: html_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: file_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: email_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:22:43 --> Database Driver Class Initialized
INFO - 2026-07-03 08:22:43 --> Config Class Initialized
INFO - 2026-07-03 08:22:43 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:22:43 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:22:43 --> Utf8 Class Initialized
INFO - 2026-07-03 08:22:43 --> URI Class Initialized
INFO - 2026-07-03 08:22:43 --> Router Class Initialized
INFO - 2026-07-03 08:22:43 --> Output Class Initialized
INFO - 2026-07-03 08:22:43 --> Security Class Initialized
DEBUG - 2026-07-03 08:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:22:43 --> CSRF cookie sent
INFO - 2026-07-03 08:22:43 --> Input Class Initialized
INFO - 2026-07-03 08:22:43 --> Language Class Initialized
INFO - 2026-07-03 08:22:43 --> Language Class Initialized
INFO - 2026-07-03 08:22:43 --> Config Class Initialized
INFO - 2026-07-03 08:22:43 --> Loader Class Initialized
INFO - 2026-07-03 08:22:43 --> Helper loaded: url_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: form_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: html_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: file_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: email_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:22:43 --> Database Driver Class Initialized
INFO - 2026-07-03 08:22:43 --> Config Class Initialized
INFO - 2026-07-03 08:22:43 --> Hooks Class Initialized
INFO - 2026-07-03 08:22:43 --> Config Class Initialized
INFO - 2026-07-03 08:22:43 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:22:43 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:22:43 --> Utf8 Class Initialized
INFO - 2026-07-03 08:22:43 --> URI Class Initialized
INFO - 2026-07-03 08:22:43 --> Config Class Initialized
INFO - 2026-07-03 08:22:43 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:22:43 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:22:43 --> Utf8 Class Initialized
INFO - 2026-07-03 08:22:43 --> URI Class Initialized
INFO - 2026-07-03 08:22:43 --> Router Class Initialized
DEBUG - 2026-07-03 08:22:43 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:22:43 --> Utf8 Class Initialized
INFO - 2026-07-03 08:22:43 --> Config Class Initialized
INFO - 2026-07-03 08:22:43 --> Hooks Class Initialized
INFO - 2026-07-03 08:22:43 --> URI Class Initialized
INFO - 2026-07-03 08:22:43 --> Output Class Initialized
INFO - 2026-07-03 08:22:43 --> Router Class Initialized
INFO - 2026-07-03 08:22:43 --> Security Class Initialized
DEBUG - 2026-07-03 08:22:43 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:22:43 --> Utf8 Class Initialized
INFO - 2026-07-03 08:22:43 --> Output Class Initialized
DEBUG - 2026-07-03 08:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:22:43 --> CSRF cookie sent
INFO - 2026-07-03 08:22:43 --> Input Class Initialized
INFO - 2026-07-03 08:22:43 --> Language Class Initialized
INFO - 2026-07-03 08:22:43 --> URI Class Initialized
INFO - 2026-07-03 08:22:43 --> Router Class Initialized
INFO - 2026-07-03 08:22:43 --> Language Class Initialized
INFO - 2026-07-03 08:22:43 --> Security Class Initialized
INFO - 2026-07-03 08:22:43 --> Config Class Initialized
INFO - 2026-07-03 08:22:43 --> Output Class Initialized
INFO - 2026-07-03 08:22:43 --> Router Class Initialized
DEBUG - 2026-07-03 08:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:22:43 --> CSRF cookie sent
INFO - 2026-07-03 08:22:43 --> Input Class Initialized
INFO - 2026-07-03 08:22:43 --> Language Class Initialized
INFO - 2026-07-03 08:22:43 --> Security Class Initialized
INFO - 2026-07-03 08:22:43 --> Loader Class Initialized
INFO - 2026-07-03 08:22:43 --> Language Class Initialized
INFO - 2026-07-03 08:22:43 --> Config Class Initialized
INFO - 2026-07-03 08:22:43 --> Output Class Initialized
INFO - 2026-07-03 08:22:43 --> Helper loaded: url_helper
DEBUG - 2026-07-03 08:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:22:43 --> CSRF cookie sent
INFO - 2026-07-03 08:22:43 --> Input Class Initialized
INFO - 2026-07-03 08:22:43 --> Language Class Initialized
INFO - 2026-07-03 08:22:43 --> Security Class Initialized
INFO - 2026-07-03 08:22:43 --> Helper loaded: form_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: html_helper
INFO - 2026-07-03 08:22:43 --> Language Class Initialized
INFO - 2026-07-03 08:22:43 --> Config Class Initialized
INFO - 2026-07-03 08:22:43 --> Helper loaded: file_helper
DEBUG - 2026-07-03 08:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:22:43 --> Helper loaded: email_helper
INFO - 2026-07-03 08:22:43 --> CSRF cookie sent
INFO - 2026-07-03 08:22:43 --> Input Class Initialized
INFO - 2026-07-03 08:22:43 --> Loader Class Initialized
INFO - 2026-07-03 08:22:43 --> Language Class Initialized
INFO - 2026-07-03 08:22:43 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: url_helper
INFO - 2026-07-03 08:22:43 --> Language Class Initialized
INFO - 2026-07-03 08:22:43 --> Config Class Initialized
INFO - 2026-07-03 08:22:43 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:22:43 --> Loader Class Initialized
INFO - 2026-07-03 08:22:43 --> Helper loaded: form_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: html_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: url_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: file_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: email_helper
INFO - 2026-07-03 08:22:43 --> Loader Class Initialized
INFO - 2026-07-03 08:22:43 --> Helper loaded: form_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: html_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: file_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: email_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: url_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: form_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: html_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: file_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: email_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:22:43 --> Database Driver Class Initialized
INFO - 2026-07-03 08:22:43 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:22:43 --> Database Driver Class Initialized
INFO - 2026-07-03 08:22:43 --> Database Driver Class Initialized
INFO - 2026-07-03 08:22:43 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:22:43 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:22:43 --> Database Driver Class Initialized
INFO - 2026-07-03 08:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:22:44 --> Upload Class Initialized
DEBUG - 2026-07-03 08:22:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:22:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:22:44 --> Encryption Class Initialized
INFO - 2026-07-03 08:22:44 --> Form Validation Class Initialized
INFO - 2026-07-03 08:22:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:22:44 --> Pagination Class Initialized
INFO - 2026-07-03 08:22:44 --> Email Class Initialized
INFO - 2026-07-03 08:22:44 --> Controller Class Initialized
ERROR - 2026-07-03 08:22:44 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:22:44 --> Upload Class Initialized
DEBUG - 2026-07-03 08:22:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:22:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:22:44 --> Encryption Class Initialized
INFO - 2026-07-03 08:22:44 --> Form Validation Class Initialized
INFO - 2026-07-03 08:22:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:22:44 --> Pagination Class Initialized
INFO - 2026-07-03 08:22:44 --> Config Class Initialized
INFO - 2026-07-03 08:22:44 --> Hooks Class Initialized
INFO - 2026-07-03 08:22:44 --> Email Class Initialized
INFO - 2026-07-03 08:22:44 --> Controller Class Initialized
DEBUG - 2026-07-03 08:22:44 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:22:44 --> Utf8 Class Initialized
ERROR - 2026-07-03 08:22:44 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:22:44 --> URI Class Initialized
INFO - 2026-07-03 08:22:44 --> Upload Class Initialized
INFO - 2026-07-03 08:22:44 --> Router Class Initialized
INFO - 2026-07-03 08:22:44 --> Output Class Initialized
DEBUG - 2026-07-03 08:22:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:22:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:22:44 --> Encryption Class Initialized
INFO - 2026-07-03 08:22:44 --> Security Class Initialized
DEBUG - 2026-07-03 08:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:22:44 --> Input Class Initialized
INFO - 2026-07-03 08:22:44 --> Language Class Initialized
INFO - 2026-07-03 08:22:44 --> Form Validation Class Initialized
INFO - 2026-07-03 08:22:44 --> Language Class Initialized
INFO - 2026-07-03 08:22:44 --> Config Class Initialized
INFO - 2026-07-03 08:22:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:22:44 --> Pagination Class Initialized
INFO - 2026-07-03 08:22:44 --> Loader Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: url_helper
INFO - 2026-07-03 08:22:44 --> Email Class Initialized
INFO - 2026-07-03 08:22:44 --> Controller Class Initialized
INFO - 2026-07-03 08:22:44 --> Config Class Initialized
ERROR - 2026-07-03 08:22:44 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:22:44 --> Hooks Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: form_helper
INFO - 2026-07-03 08:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:22:44 --> Helper loaded: html_helper
DEBUG - 2026-07-03 08:22:44 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:22:44 --> Helper loaded: file_helper
INFO - 2026-07-03 08:22:44 --> Utf8 Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: email_helper
INFO - 2026-07-03 08:22:44 --> URI Class Initialized
INFO - 2026-07-03 08:22:44 --> Upload Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:22:44 --> Router Class Initialized
DEBUG - 2026-07-03 08:22:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:22:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:22:44 --> Encryption Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:22:44 --> Output Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:22:44 --> Form Validation Class Initialized
INFO - 2026-07-03 08:22:44 --> Security Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:22:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:22:44 --> Pagination Class Initialized
DEBUG - 2026-07-03 08:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:22:44 --> Input Class Initialized
INFO - 2026-07-03 08:22:44 --> Language Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:22:44 --> Language Class Initialized
INFO - 2026-07-03 08:22:44 --> Config Class Initialized
INFO - 2026-07-03 08:22:44 --> Email Class Initialized
INFO - 2026-07-03 08:22:44 --> Controller Class Initialized
INFO - 2026-07-03 08:22:44 --> Config Class Initialized
INFO - 2026-07-03 08:22:44 --> Hooks Class Initialized
ERROR - 2026-07-03 08:22:44 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:22:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-07-03 08:22:44 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:22:44 --> Utf8 Class Initialized
INFO - 2026-07-03 08:22:44 --> Loader Class Initialized
INFO - 2026-07-03 08:22:44 --> URI Class Initialized
INFO - 2026-07-03 08:22:44 --> Upload Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: url_helper
INFO - 2026-07-03 08:22:44 --> Router Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: form_helper
DEBUG - 2026-07-03 08:22:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:22:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:22:44 --> Encryption Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: html_helper
INFO - 2026-07-03 08:22:44 --> Output Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: file_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: email_helper
INFO - 2026-07-03 08:22:44 --> Database Driver Class Initialized
INFO - 2026-07-03 08:22:44 --> Form Validation Class Initialized
INFO - 2026-07-03 08:22:44 --> Security Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:22:44 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2026-07-03 08:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:22:44 --> Pagination Class Initialized
INFO - 2026-07-03 08:22:44 --> Input Class Initialized
INFO - 2026-07-03 08:22:44 --> Language Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:22:44 --> Language Class Initialized
INFO - 2026-07-03 08:22:44 --> Config Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:22:44 --> Loader Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:22:44 --> Email Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: url_helper
INFO - 2026-07-03 08:22:44 --> Controller Class Initialized
ERROR - 2026-07-03 08:22:44 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:22:44 --> Config Class Initialized
INFO - 2026-07-03 08:22:44 --> Hooks Class Initialized
INFO - 2026-07-03 08:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:22:44 --> Helper loaded: form_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: html_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: file_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: email_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: domain_helper
DEBUG - 2026-07-03 08:22:44 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:22:44 --> Utf8 Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:22:44 --> Upload Class Initialized
INFO - 2026-07-03 08:22:44 --> URI Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:22:44 --> Router Class Initialized
DEBUG - 2026-07-03 08:22:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:22:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:22:44 --> Encryption Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:22:44 --> Output Class Initialized
INFO - 2026-07-03 08:22:44 --> Form Validation Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:22:44 --> Security Class Initialized
INFO - 2026-07-03 08:22:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:22:44 --> Pagination Class Initialized
INFO - 2026-07-03 08:22:44 --> Database Driver Class Initialized
DEBUG - 2026-07-03 08:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:22:44 --> Input Class Initialized
INFO - 2026-07-03 08:22:44 --> Language Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:22:44 --> Language Class Initialized
INFO - 2026-07-03 08:22:44 --> Config Class Initialized
INFO - 2026-07-03 08:22:44 --> Email Class Initialized
INFO - 2026-07-03 08:22:44 --> Controller Class Initialized
INFO - 2026-07-03 08:22:44 --> Config Class Initialized
INFO - 2026-07-03 08:22:44 --> Hooks Class Initialized
ERROR - 2026-07-03 08:22:44 --> 404 Page Not Found: /index
DEBUG - 2026-07-03 08:22:44 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:22:44 --> Utf8 Class Initialized
INFO - 2026-07-03 08:22:44 --> Loader Class Initialized
INFO - 2026-07-03 08:22:44 --> URI Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: url_helper
INFO - 2026-07-03 08:22:44 --> Database Driver Class Initialized
INFO - 2026-07-03 08:22:44 --> Router Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: form_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: html_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: file_helper
INFO - 2026-07-03 08:22:44 --> Output Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: email_helper
INFO - 2026-07-03 08:22:44 --> Security Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: ssp_helper
DEBUG - 2026-07-03 08:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:22:44 --> Input Class Initialized
INFO - 2026-07-03 08:22:44 --> Language Class Initialized
INFO - 2026-07-03 08:22:44 --> Config Class Initialized
INFO - 2026-07-03 08:22:44 --> Hooks Class Initialized
INFO - 2026-07-03 08:22:44 --> Language Class Initialized
INFO - 2026-07-03 08:22:44 --> Config Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: cpanel_helper
DEBUG - 2026-07-03 08:22:44 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:22:44 --> Utf8 Class Initialized
INFO - 2026-07-03 08:22:44 --> URI Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:22:44 --> Loader Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:22:44 --> Router Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: url_helper
INFO - 2026-07-03 08:22:44 --> Output Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: form_helper
INFO - 2026-07-03 08:22:44 --> Security Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: html_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: file_helper
DEBUG - 2026-07-03 08:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:22:44 --> Helper loaded: email_helper
INFO - 2026-07-03 08:22:44 --> Input Class Initialized
INFO - 2026-07-03 08:22:44 --> Language Class Initialized
INFO - 2026-07-03 08:22:44 --> Language Class Initialized
INFO - 2026-07-03 08:22:44 --> Config Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:22:44 --> Loader Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: url_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: form_helper
INFO - 2026-07-03 08:22:44 --> Database Driver Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: html_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: file_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: email_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:22:44 --> Database Driver Class Initialized
INFO - 2026-07-03 08:22:44 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:22:44 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:22:44 --> Database Driver Class Initialized
INFO - 2026-07-03 08:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:22:46 --> Upload Class Initialized
DEBUG - 2026-07-03 08:22:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:22:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:22:46 --> Encryption Class Initialized
INFO - 2026-07-03 08:22:46 --> Form Validation Class Initialized
INFO - 2026-07-03 08:22:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:22:46 --> Pagination Class Initialized
INFO - 2026-07-03 08:22:46 --> Email Class Initialized
INFO - 2026-07-03 08:22:46 --> Controller Class Initialized
DEBUG - 2026-07-03 08:22:46 --> Order MX_Controller Initialized
INFO - 2026-07-03 08:22:46 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:22:46 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:22:46 --> Model "Order_model" initialized
INFO - 2026-07-03 08:22:46 --> Model "Common_model" initialized
INFO - 2026-07-03 08:22:46 --> Model "Currency_model" initialized
INFO - 2026-07-03 08:22:47 --> Final output sent to browser
DEBUG - 2026-07-03 08:22:47 --> Total execution time: 2.3283
INFO - 2026-07-03 08:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:22:47 --> Upload Class Initialized
DEBUG - 2026-07-03 08:22:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:22:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:22:47 --> Encryption Class Initialized
INFO - 2026-07-03 08:22:47 --> Form Validation Class Initialized
INFO - 2026-07-03 08:22:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:22:47 --> Pagination Class Initialized
INFO - 2026-07-03 08:22:47 --> Email Class Initialized
INFO - 2026-07-03 08:22:47 --> Controller Class Initialized
INFO - 2026-07-03 08:22:47 --> Config Class Initialized
INFO - 2026-07-03 08:22:47 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:22:47 --> Dashboard MX_Controller Initialized
DEBUG - 2026-07-03 08:22:47 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:22:47 --> Utf8 Class Initialized
INFO - 2026-07-03 08:22:47 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:22:47 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:22:47 --> URI Class Initialized
INFO - 2026-07-03 08:22:47 --> Router Class Initialized
INFO - 2026-07-03 08:22:47 --> Output Class Initialized
INFO - 2026-07-03 08:22:47 --> Security Class Initialized
DEBUG - 2026-07-03 08:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:22:47 --> CSRF cookie sent
INFO - 2026-07-03 08:22:47 --> Input Class Initialized
INFO - 2026-07-03 08:22:47 --> Language Class Initialized
INFO - 2026-07-03 08:22:47 --> Language Class Initialized
INFO - 2026-07-03 08:22:47 --> Config Class Initialized
INFO - 2026-07-03 08:22:47 --> Loader Class Initialized
INFO - 2026-07-03 08:22:47 --> Helper loaded: url_helper
INFO - 2026-07-03 08:22:47 --> Helper loaded: form_helper
INFO - 2026-07-03 08:22:47 --> Helper loaded: html_helper
INFO - 2026-07-03 08:22:47 --> Helper loaded: file_helper
INFO - 2026-07-03 08:22:47 --> Helper loaded: email_helper
INFO - 2026-07-03 08:22:47 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:22:47 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:22:47 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:22:47 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:22:47 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:22:47 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:22:47 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:22:47 --> Database Driver Class Initialized
INFO - 2026-07-03 08:22:47 --> Model "Dashboard_model" initialized
INFO - 2026-07-03 08:22:47 --> Final output sent to browser
DEBUG - 2026-07-03 08:22:47 --> Total execution time: 2.9379
INFO - 2026-07-03 08:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:22:47 --> Upload Class Initialized
DEBUG - 2026-07-03 08:22:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:22:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:22:47 --> Encryption Class Initialized
INFO - 2026-07-03 08:22:47 --> Form Validation Class Initialized
INFO - 2026-07-03 08:22:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:22:47 --> Pagination Class Initialized
INFO - 2026-07-03 08:22:47 --> Config Class Initialized
INFO - 2026-07-03 08:22:47 --> Hooks Class Initialized
INFO - 2026-07-03 08:22:47 --> Email Class Initialized
INFO - 2026-07-03 08:22:47 --> Controller Class Initialized
DEBUG - 2026-07-03 08:22:47 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:22:47 --> Utf8 Class Initialized
DEBUG - 2026-07-03 08:22:47 --> Invoice MX_Controller Initialized
INFO - 2026-07-03 08:22:47 --> URI Class Initialized
INFO - 2026-07-03 08:22:47 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:22:47 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:22:47 --> Model "Billing_model" initialized
INFO - 2026-07-03 08:22:47 --> Router Class Initialized
INFO - 2026-07-03 08:22:47 --> Model "Common_model" initialized
INFO - 2026-07-03 08:22:47 --> Model "Invoice_model" initialized
INFO - 2026-07-03 08:22:47 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 08:22:47 --> Output Class Initialized
INFO - 2026-07-03 08:22:47 --> Security Class Initialized
DEBUG - 2026-07-03 08:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:22:47 --> CSRF cookie sent
INFO - 2026-07-03 08:22:47 --> Input Class Initialized
INFO - 2026-07-03 08:22:47 --> Language Class Initialized
INFO - 2026-07-03 08:22:47 --> Language Class Initialized
INFO - 2026-07-03 08:22:47 --> Config Class Initialized
INFO - 2026-07-03 08:22:47 --> Loader Class Initialized
INFO - 2026-07-03 08:22:47 --> Helper loaded: url_helper
INFO - 2026-07-03 08:22:47 --> Helper loaded: form_helper
INFO - 2026-07-03 08:22:47 --> Helper loaded: html_helper
INFO - 2026-07-03 08:22:47 --> Helper loaded: file_helper
INFO - 2026-07-03 08:22:47 --> Helper loaded: email_helper
INFO - 2026-07-03 08:22:47 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:22:47 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:22:47 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:22:47 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:22:47 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:22:47 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:22:47 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:22:47 --> Database Driver Class Initialized
INFO - 2026-07-03 08:22:48 --> Final output sent to browser
DEBUG - 2026-07-03 08:22:48 --> Total execution time: 3.5562
INFO - 2026-07-03 08:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:22:48 --> Upload Class Initialized
DEBUG - 2026-07-03 08:22:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:22:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:22:48 --> Encryption Class Initialized
INFO - 2026-07-03 08:22:48 --> Form Validation Class Initialized
INFO - 2026-07-03 08:22:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:22:48 --> Pagination Class Initialized
INFO - 2026-07-03 08:22:48 --> Email Class Initialized
INFO - 2026-07-03 08:22:48 --> Controller Class Initialized
DEBUG - 2026-07-03 08:22:48 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 08:22:48 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:22:48 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:22:48 --> Model "Dashboard_model" initialized
INFO - 2026-07-03 08:22:49 --> Final output sent to browser
DEBUG - 2026-07-03 08:22:49 --> Total execution time: 4.1666
INFO - 2026-07-03 08:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:22:49 --> Upload Class Initialized
DEBUG - 2026-07-03 08:22:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:22:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:22:49 --> Encryption Class Initialized
INFO - 2026-07-03 08:22:49 --> Form Validation Class Initialized
INFO - 2026-07-03 08:22:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:22:49 --> Pagination Class Initialized
INFO - 2026-07-03 08:22:49 --> Email Class Initialized
INFO - 2026-07-03 08:22:49 --> Controller Class Initialized
DEBUG - 2026-07-03 08:22:49 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 08:22:49 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:22:49 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:22:49 --> Model "Dashboard_model" initialized
INFO - 2026-07-03 08:22:49 --> Final output sent to browser
DEBUG - 2026-07-03 08:22:49 --> Total execution time: 4.8901
INFO - 2026-07-03 08:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:22:49 --> Upload Class Initialized
DEBUG - 2026-07-03 08:22:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:22:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:22:49 --> Encryption Class Initialized
INFO - 2026-07-03 08:22:49 --> Form Validation Class Initialized
INFO - 2026-07-03 08:22:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:22:49 --> Pagination Class Initialized
INFO - 2026-07-03 08:22:49 --> Email Class Initialized
INFO - 2026-07-03 08:22:49 --> Controller Class Initialized
DEBUG - 2026-07-03 08:22:49 --> Ticket MX_Controller Initialized
INFO - 2026-07-03 08:22:49 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:22:49 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:22:49 --> Model "Support_model" initialized
INFO - 2026-07-03 08:22:49 --> Model "Common_model" initialized
INFO - 2026-07-03 08:22:50 --> Final output sent to browser
DEBUG - 2026-07-03 08:22:50 --> Total execution time: 5.6113
INFO - 2026-07-03 08:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:22:50 --> Upload Class Initialized
DEBUG - 2026-07-03 08:22:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:22:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:22:50 --> Encryption Class Initialized
INFO - 2026-07-03 08:22:50 --> Form Validation Class Initialized
INFO - 2026-07-03 08:22:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:22:50 --> Pagination Class Initialized
INFO - 2026-07-03 08:22:50 --> Email Class Initialized
INFO - 2026-07-03 08:22:50 --> Controller Class Initialized
DEBUG - 2026-07-03 08:22:50 --> Software MX_Controller Initialized
INFO - 2026-07-03 08:22:50 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:22:50 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:22:50 --> Model "Software_model" initialized
DEBUG - 2026-07-03 08:22:50 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 08:22:50 --> Model "Plan_model" initialized
DEBUG - 2026-07-03 08:22:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 08:22:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 08:22:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 08:22:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 08:22:51 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/software_manage.php
INFO - 2026-07-03 08:22:51 --> Final output sent to browser
DEBUG - 2026-07-03 08:22:51 --> Total execution time: 4.6165
INFO - 2026-07-03 08:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:22:51 --> Upload Class Initialized
DEBUG - 2026-07-03 08:22:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:22:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:22:51 --> Encryption Class Initialized
INFO - 2026-07-03 08:22:51 --> Form Validation Class Initialized
INFO - 2026-07-03 08:22:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:22:51 --> Pagination Class Initialized
INFO - 2026-07-03 08:22:51 --> Email Class Initialized
INFO - 2026-07-03 08:22:51 --> Controller Class Initialized
ERROR - 2026-07-03 08:22:51 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:25:37 --> Config Class Initialized
INFO - 2026-07-03 08:25:37 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:25:37 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:25:37 --> Utf8 Class Initialized
INFO - 2026-07-03 08:25:37 --> URI Class Initialized
INFO - 2026-07-03 08:25:37 --> Router Class Initialized
INFO - 2026-07-03 08:25:37 --> Output Class Initialized
INFO - 2026-07-03 08:25:37 --> Security Class Initialized
DEBUG - 2026-07-03 08:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:25:37 --> CSRF cookie sent
INFO - 2026-07-03 08:25:37 --> Input Class Initialized
INFO - 2026-07-03 08:25:37 --> Language Class Initialized
INFO - 2026-07-03 08:25:37 --> Language Class Initialized
INFO - 2026-07-03 08:25:37 --> Config Class Initialized
INFO - 2026-07-03 08:25:37 --> Loader Class Initialized
INFO - 2026-07-03 08:25:37 --> Helper loaded: url_helper
INFO - 2026-07-03 08:25:37 --> Helper loaded: form_helper
INFO - 2026-07-03 08:25:37 --> Helper loaded: html_helper
INFO - 2026-07-03 08:25:37 --> Helper loaded: file_helper
INFO - 2026-07-03 08:25:37 --> Helper loaded: email_helper
INFO - 2026-07-03 08:25:37 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:25:37 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:25:37 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:25:37 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:25:37 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:25:37 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:25:37 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:25:37 --> Database Driver Class Initialized
INFO - 2026-07-03 08:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:25:39 --> Upload Class Initialized
DEBUG - 2026-07-03 08:25:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:25:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:25:39 --> Encryption Class Initialized
INFO - 2026-07-03 08:25:39 --> Form Validation Class Initialized
INFO - 2026-07-03 08:25:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:25:39 --> Pagination Class Initialized
INFO - 2026-07-03 08:25:39 --> Email Class Initialized
INFO - 2026-07-03 08:25:39 --> Controller Class Initialized
DEBUG - 2026-07-03 08:25:39 --> Software MX_Controller Initialized
INFO - 2026-07-03 08:25:39 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:25:39 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 08:25:39 --> Model "Software_model" initialized
DEBUG - 2026-07-03 08:25:39 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 08:25:39 --> Model "Plan_model" initialized
DEBUG - 2026-07-03 08:25:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 08:25:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 08:25:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 08:25:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-03 08:25:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 08:25:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/software_manage.php
INFO - 2026-07-03 08:25:41 --> Final output sent to browser
DEBUG - 2026-07-03 08:25:41 --> Total execution time: 3.5114
INFO - 2026-07-03 08:25:41 --> Config Class Initialized
INFO - 2026-07-03 08:25:41 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:25:41 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:25:41 --> Utf8 Class Initialized
INFO - 2026-07-03 08:25:41 --> URI Class Initialized
INFO - 2026-07-03 08:25:41 --> Router Class Initialized
INFO - 2026-07-03 08:25:41 --> Output Class Initialized
INFO - 2026-07-03 08:25:41 --> Security Class Initialized
DEBUG - 2026-07-03 08:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:25:41 --> CSRF cookie sent
INFO - 2026-07-03 08:25:41 --> Input Class Initialized
INFO - 2026-07-03 08:25:41 --> Language Class Initialized
INFO - 2026-07-03 08:25:41 --> Language Class Initialized
INFO - 2026-07-03 08:25:41 --> Config Class Initialized
INFO - 2026-07-03 08:25:41 --> Loader Class Initialized
INFO - 2026-07-03 08:25:41 --> Helper loaded: url_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: form_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: html_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: file_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: email_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:25:41 --> Database Driver Class Initialized
INFO - 2026-07-03 08:25:41 --> Config Class Initialized
INFO - 2026-07-03 08:25:41 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:25:41 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:25:41 --> Utf8 Class Initialized
INFO - 2026-07-03 08:25:41 --> URI Class Initialized
INFO - 2026-07-03 08:25:41 --> Router Class Initialized
INFO - 2026-07-03 08:25:41 --> Output Class Initialized
INFO - 2026-07-03 08:25:41 --> Security Class Initialized
DEBUG - 2026-07-03 08:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:25:41 --> CSRF cookie sent
INFO - 2026-07-03 08:25:41 --> Input Class Initialized
INFO - 2026-07-03 08:25:41 --> Language Class Initialized
INFO - 2026-07-03 08:25:41 --> Language Class Initialized
INFO - 2026-07-03 08:25:41 --> Config Class Initialized
INFO - 2026-07-03 08:25:41 --> Loader Class Initialized
INFO - 2026-07-03 08:25:41 --> Helper loaded: url_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: form_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: html_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: file_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: email_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:25:41 --> Config Class Initialized
INFO - 2026-07-03 08:25:41 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:25:41 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:25:41 --> Utf8 Class Initialized
INFO - 2026-07-03 08:25:41 --> URI Class Initialized
INFO - 2026-07-03 08:25:41 --> Router Class Initialized
INFO - 2026-07-03 08:25:41 --> Output Class Initialized
INFO - 2026-07-03 08:25:41 --> Security Class Initialized
DEBUG - 2026-07-03 08:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:25:41 --> CSRF cookie sent
INFO - 2026-07-03 08:25:41 --> Input Class Initialized
INFO - 2026-07-03 08:25:41 --> Language Class Initialized
INFO - 2026-07-03 08:25:41 --> Database Driver Class Initialized
INFO - 2026-07-03 08:25:41 --> Language Class Initialized
INFO - 2026-07-03 08:25:41 --> Config Class Initialized
INFO - 2026-07-03 08:25:41 --> Loader Class Initialized
INFO - 2026-07-03 08:25:41 --> Helper loaded: url_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: form_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: html_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: file_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: email_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:25:41 --> Database Driver Class Initialized
INFO - 2026-07-03 08:25:41 --> Config Class Initialized
INFO - 2026-07-03 08:25:41 --> Config Class Initialized
INFO - 2026-07-03 08:25:41 --> Hooks Class Initialized
INFO - 2026-07-03 08:25:41 --> Hooks Class Initialized
INFO - 2026-07-03 08:25:41 --> Config Class Initialized
INFO - 2026-07-03 08:25:41 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:25:41 --> UTF-8 Support Enabled
DEBUG - 2026-07-03 08:25:41 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:25:41 --> Utf8 Class Initialized
INFO - 2026-07-03 08:25:41 --> Utf8 Class Initialized
INFO - 2026-07-03 08:25:41 --> URI Class Initialized
INFO - 2026-07-03 08:25:41 --> URI Class Initialized
DEBUG - 2026-07-03 08:25:41 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:25:41 --> Utf8 Class Initialized
INFO - 2026-07-03 08:25:41 --> URI Class Initialized
INFO - 2026-07-03 08:25:41 --> Router Class Initialized
INFO - 2026-07-03 08:25:41 --> Router Class Initialized
INFO - 2026-07-03 08:25:41 --> Output Class Initialized
INFO - 2026-07-03 08:25:41 --> Output Class Initialized
INFO - 2026-07-03 08:25:41 --> Router Class Initialized
INFO - 2026-07-03 08:25:41 --> Security Class Initialized
INFO - 2026-07-03 08:25:41 --> Security Class Initialized
INFO - 2026-07-03 08:25:41 --> Output Class Initialized
DEBUG - 2026-07-03 08:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:25:41 --> CSRF cookie sent
INFO - 2026-07-03 08:25:41 --> Input Class Initialized
DEBUG - 2026-07-03 08:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:25:41 --> CSRF cookie sent
INFO - 2026-07-03 08:25:41 --> Input Class Initialized
INFO - 2026-07-03 08:25:41 --> Language Class Initialized
INFO - 2026-07-03 08:25:41 --> Language Class Initialized
INFO - 2026-07-03 08:25:41 --> Security Class Initialized
INFO - 2026-07-03 08:25:41 --> Language Class Initialized
INFO - 2026-07-03 08:25:41 --> Config Class Initialized
INFO - 2026-07-03 08:25:41 --> Language Class Initialized
INFO - 2026-07-03 08:25:41 --> Config Class Initialized
DEBUG - 2026-07-03 08:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:25:41 --> CSRF cookie sent
INFO - 2026-07-03 08:25:41 --> Input Class Initialized
INFO - 2026-07-03 08:25:41 --> Language Class Initialized
INFO - 2026-07-03 08:25:41 --> Language Class Initialized
INFO - 2026-07-03 08:25:41 --> Config Class Initialized
INFO - 2026-07-03 08:25:41 --> Loader Class Initialized
INFO - 2026-07-03 08:25:41 --> Loader Class Initialized
INFO - 2026-07-03 08:25:41 --> Helper loaded: url_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: url_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: form_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: form_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: html_helper
INFO - 2026-07-03 08:25:41 --> Loader Class Initialized
INFO - 2026-07-03 08:25:41 --> Helper loaded: html_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: file_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: email_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: url_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: file_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: email_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: form_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: html_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: file_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: email_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:25:41 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:25:41 --> Database Driver Class Initialized
INFO - 2026-07-03 08:25:41 --> Database Driver Class Initialized
INFO - 2026-07-03 08:25:42 --> Database Driver Class Initialized
INFO - 2026-07-03 08:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:25:43 --> Upload Class Initialized
DEBUG - 2026-07-03 08:25:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:25:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:25:43 --> Encryption Class Initialized
INFO - 2026-07-03 08:25:43 --> Form Validation Class Initialized
INFO - 2026-07-03 08:25:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:25:43 --> Pagination Class Initialized
INFO - 2026-07-03 08:25:43 --> Email Class Initialized
INFO - 2026-07-03 08:25:43 --> Controller Class Initialized
ERROR - 2026-07-03 08:25:43 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:25:43 --> Config Class Initialized
INFO - 2026-07-03 08:25:43 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:25:43 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:25:43 --> Utf8 Class Initialized
INFO - 2026-07-03 08:25:43 --> URI Class Initialized
INFO - 2026-07-03 08:25:43 --> Router Class Initialized
INFO - 2026-07-03 08:25:43 --> Output Class Initialized
INFO - 2026-07-03 08:25:43 --> Security Class Initialized
DEBUG - 2026-07-03 08:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:25:43 --> CSRF cookie sent
INFO - 2026-07-03 08:25:43 --> Input Class Initialized
INFO - 2026-07-03 08:25:43 --> Language Class Initialized
INFO - 2026-07-03 08:25:43 --> Language Class Initialized
INFO - 2026-07-03 08:25:43 --> Config Class Initialized
INFO - 2026-07-03 08:25:43 --> Loader Class Initialized
INFO - 2026-07-03 08:25:43 --> Helper loaded: url_helper
INFO - 2026-07-03 08:25:43 --> Helper loaded: form_helper
INFO - 2026-07-03 08:25:43 --> Helper loaded: html_helper
INFO - 2026-07-03 08:25:43 --> Helper loaded: file_helper
INFO - 2026-07-03 08:25:43 --> Helper loaded: email_helper
INFO - 2026-07-03 08:25:43 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:25:43 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:25:43 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:25:43 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:25:43 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:25:43 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:25:43 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:25:43 --> Database Driver Class Initialized
INFO - 2026-07-03 08:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:25:43 --> Upload Class Initialized
DEBUG - 2026-07-03 08:25:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:25:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:25:43 --> Encryption Class Initialized
INFO - 2026-07-03 08:25:43 --> Form Validation Class Initialized
INFO - 2026-07-03 08:25:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:25:43 --> Pagination Class Initialized
INFO - 2026-07-03 08:25:43 --> Email Class Initialized
INFO - 2026-07-03 08:25:43 --> Controller Class Initialized
ERROR - 2026-07-03 08:25:43 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:25:43 --> Upload Class Initialized
DEBUG - 2026-07-03 08:25:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:25:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:25:43 --> Encryption Class Initialized
INFO - 2026-07-03 08:25:43 --> Form Validation Class Initialized
INFO - 2026-07-03 08:25:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:25:43 --> Pagination Class Initialized
INFO - 2026-07-03 08:25:43 --> Email Class Initialized
INFO - 2026-07-03 08:25:43 --> Controller Class Initialized
ERROR - 2026-07-03 08:25:43 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:25:43 --> Upload Class Initialized
DEBUG - 2026-07-03 08:25:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:25:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:25:43 --> Encryption Class Initialized
INFO - 2026-07-03 08:25:43 --> Form Validation Class Initialized
INFO - 2026-07-03 08:25:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:25:43 --> Pagination Class Initialized
INFO - 2026-07-03 08:25:43 --> Email Class Initialized
INFO - 2026-07-03 08:25:43 --> Controller Class Initialized
ERROR - 2026-07-03 08:25:43 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:25:43 --> Upload Class Initialized
DEBUG - 2026-07-03 08:25:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:25:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:25:43 --> Encryption Class Initialized
INFO - 2026-07-03 08:25:43 --> Form Validation Class Initialized
INFO - 2026-07-03 08:25:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:25:43 --> Pagination Class Initialized
INFO - 2026-07-03 08:25:43 --> Email Class Initialized
INFO - 2026-07-03 08:25:43 --> Controller Class Initialized
ERROR - 2026-07-03 08:25:43 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:25:43 --> Upload Class Initialized
DEBUG - 2026-07-03 08:25:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:25:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:25:43 --> Encryption Class Initialized
INFO - 2026-07-03 08:25:43 --> Form Validation Class Initialized
INFO - 2026-07-03 08:25:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:25:43 --> Pagination Class Initialized
INFO - 2026-07-03 08:25:43 --> Email Class Initialized
INFO - 2026-07-03 08:25:43 --> Controller Class Initialized
ERROR - 2026-07-03 08:25:43 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:25:45 --> Upload Class Initialized
DEBUG - 2026-07-03 08:25:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:25:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:25:45 --> Encryption Class Initialized
INFO - 2026-07-03 08:25:45 --> Form Validation Class Initialized
INFO - 2026-07-03 08:25:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:25:45 --> Pagination Class Initialized
INFO - 2026-07-03 08:25:45 --> Email Class Initialized
INFO - 2026-07-03 08:25:45 --> Controller Class Initialized
ERROR - 2026-07-03 08:25:45 --> 404 Page Not Found: /index
INFO - 2026-07-03 08:33:09 --> Config Class Initialized
INFO - 2026-07-03 08:33:09 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:33:09 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:33:09 --> Utf8 Class Initialized
INFO - 2026-07-03 08:33:09 --> URI Class Initialized
INFO - 2026-07-03 08:33:09 --> Router Class Initialized
INFO - 2026-07-03 08:33:09 --> Output Class Initialized
INFO - 2026-07-03 08:33:09 --> Security Class Initialized
DEBUG - 2026-07-03 08:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:33:09 --> CSRF cookie sent
INFO - 2026-07-03 08:33:09 --> Input Class Initialized
INFO - 2026-07-03 08:33:09 --> Language Class Initialized
INFO - 2026-07-03 08:33:09 --> Language Class Initialized
INFO - 2026-07-03 08:33:09 --> Config Class Initialized
INFO - 2026-07-03 08:33:09 --> Loader Class Initialized
INFO - 2026-07-03 08:33:09 --> Helper loaded: url_helper
INFO - 2026-07-03 08:33:09 --> Helper loaded: form_helper
INFO - 2026-07-03 08:33:09 --> Helper loaded: html_helper
INFO - 2026-07-03 08:33:09 --> Helper loaded: file_helper
INFO - 2026-07-03 08:33:09 --> Helper loaded: email_helper
INFO - 2026-07-03 08:33:09 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:33:09 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:33:09 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:33:09 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:33:09 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:33:09 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:33:09 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:33:09 --> Database Driver Class Initialized
INFO - 2026-07-03 08:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:33:10 --> Upload Class Initialized
DEBUG - 2026-07-03 08:33:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:33:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:33:10 --> Encryption Class Initialized
INFO - 2026-07-03 08:33:10 --> Form Validation Class Initialized
INFO - 2026-07-03 08:33:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:33:10 --> Pagination Class Initialized
INFO - 2026-07-03 08:33:10 --> Email Class Initialized
INFO - 2026-07-03 08:33:10 --> Controller Class Initialized
DEBUG - 2026-07-03 08:33:10 --> Cart MX_Controller Initialized
INFO - 2026-07-03 08:33:10 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:33:10 --> Model "Auth_model" initialized
INFO - 2026-07-03 08:33:10 --> Model "Cart_model" initialized
INFO - 2026-07-03 08:33:11 --> Model "Common_model" initialized
INFO - 2026-07-03 08:33:11 --> Model "Order_model" initialized
INFO - 2026-07-03 08:33:11 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 08:33:11 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 08:33:11 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 08:33:11 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 08:33:11 --> Model "Plan_model" initialized
INFO - 2026-07-03 08:33:11 --> Model "Orderlicense_model" initialized
DEBUG - 2026-07-03 08:33:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 08:33:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 08:33:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/cart_software.php
INFO - 2026-07-03 08:33:13 --> Final output sent to browser
DEBUG - 2026-07-03 08:33:13 --> Total execution time: 4.1651
INFO - 2026-07-03 08:33:13 --> Config Class Initialized
INFO - 2026-07-03 08:33:13 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:33:13 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:33:13 --> Utf8 Class Initialized
INFO - 2026-07-03 08:33:13 --> URI Class Initialized
INFO - 2026-07-03 08:33:13 --> Router Class Initialized
INFO - 2026-07-03 08:33:13 --> Output Class Initialized
INFO - 2026-07-03 08:33:13 --> Security Class Initialized
DEBUG - 2026-07-03 08:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:33:13 --> CSRF cookie sent
INFO - 2026-07-03 08:33:13 --> Input Class Initialized
INFO - 2026-07-03 08:33:13 --> Language Class Initialized
INFO - 2026-07-03 08:33:13 --> Language Class Initialized
INFO - 2026-07-03 08:33:13 --> Config Class Initialized
INFO - 2026-07-03 08:33:13 --> Loader Class Initialized
INFO - 2026-07-03 08:33:13 --> Helper loaded: url_helper
INFO - 2026-07-03 08:33:13 --> Helper loaded: form_helper
INFO - 2026-07-03 08:33:13 --> Helper loaded: html_helper
INFO - 2026-07-03 08:33:13 --> Helper loaded: file_helper
INFO - 2026-07-03 08:33:13 --> Helper loaded: email_helper
INFO - 2026-07-03 08:33:13 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:33:13 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:33:13 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:33:13 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:33:13 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:33:13 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:33:13 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:33:13 --> Database Driver Class Initialized
INFO - 2026-07-03 08:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:33:14 --> Upload Class Initialized
DEBUG - 2026-07-03 08:33:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:33:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:33:14 --> Encryption Class Initialized
INFO - 2026-07-03 08:33:14 --> Form Validation Class Initialized
INFO - 2026-07-03 08:33:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:33:14 --> Pagination Class Initialized
INFO - 2026-07-03 08:33:14 --> Email Class Initialized
INFO - 2026-07-03 08:33:14 --> Controller Class Initialized
DEBUG - 2026-07-03 08:33:14 --> Cart MX_Controller Initialized
INFO - 2026-07-03 08:33:14 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:33:14 --> Model "Auth_model" initialized
INFO - 2026-07-03 08:33:14 --> Model "Cart_model" initialized
INFO - 2026-07-03 08:33:15 --> Model "Common_model" initialized
INFO - 2026-07-03 08:33:15 --> Model "Order_model" initialized
INFO - 2026-07-03 08:33:15 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 08:33:15 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 08:33:15 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 08:33:15 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 08:33:15 --> Model "Plan_model" initialized
INFO - 2026-07-03 08:33:15 --> Model "Orderlicense_model" initialized
DEBUG - 2026-07-03 08:33:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 08:33:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-07-03 08:33:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-07-03 08:33:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 08:33:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 08:33:18 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/view_card.php
INFO - 2026-07-03 08:33:18 --> Final output sent to browser
DEBUG - 2026-07-03 08:33:18 --> Total execution time: 4.9149
INFO - 2026-07-03 08:33:36 --> Config Class Initialized
INFO - 2026-07-03 08:33:36 --> Hooks Class Initialized
DEBUG - 2026-07-03 08:33:36 --> UTF-8 Support Enabled
INFO - 2026-07-03 08:33:36 --> Utf8 Class Initialized
INFO - 2026-07-03 08:33:36 --> URI Class Initialized
INFO - 2026-07-03 08:33:36 --> Router Class Initialized
INFO - 2026-07-03 08:33:36 --> Output Class Initialized
INFO - 2026-07-03 08:33:36 --> Security Class Initialized
DEBUG - 2026-07-03 08:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 08:33:36 --> CSRF cookie sent
INFO - 2026-07-03 08:33:36 --> Input Class Initialized
INFO - 2026-07-03 08:33:36 --> Language Class Initialized
INFO - 2026-07-03 08:33:36 --> Language Class Initialized
INFO - 2026-07-03 08:33:36 --> Config Class Initialized
INFO - 2026-07-03 08:33:36 --> Loader Class Initialized
INFO - 2026-07-03 08:33:36 --> Helper loaded: url_helper
INFO - 2026-07-03 08:33:36 --> Helper loaded: form_helper
INFO - 2026-07-03 08:33:36 --> Helper loaded: html_helper
INFO - 2026-07-03 08:33:36 --> Helper loaded: file_helper
INFO - 2026-07-03 08:33:36 --> Helper loaded: email_helper
INFO - 2026-07-03 08:33:36 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 08:33:36 --> Helper loaded: ssp_helper
INFO - 2026-07-03 08:33:36 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 08:33:36 --> Helper loaded: plesk_helper
INFO - 2026-07-03 08:33:36 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 08:33:36 --> Helper loaded: domain_helper
INFO - 2026-07-03 08:33:36 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 08:33:36 --> Database Driver Class Initialized
INFO - 2026-07-03 08:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 08:33:38 --> Upload Class Initialized
DEBUG - 2026-07-03 08:33:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 08:33:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 08:33:38 --> Encryption Class Initialized
INFO - 2026-07-03 08:33:38 --> Form Validation Class Initialized
INFO - 2026-07-03 08:33:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 08:33:38 --> Pagination Class Initialized
INFO - 2026-07-03 08:33:38 --> Email Class Initialized
INFO - 2026-07-03 08:33:38 --> Controller Class Initialized
DEBUG - 2026-07-03 08:33:38 --> Cart MX_Controller Initialized
INFO - 2026-07-03 08:33:38 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 08:33:38 --> Model "Auth_model" initialized
INFO - 2026-07-03 08:33:38 --> Model "Cart_model" initialized
INFO - 2026-07-03 08:33:39 --> Model "Common_model" initialized
INFO - 2026-07-03 08:33:39 --> Model "Order_model" initialized
INFO - 2026-07-03 08:33:39 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 08:33:39 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 08:33:39 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 08:33:39 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 08:33:39 --> Model "Plan_model" initialized
INFO - 2026-07-03 08:33:39 --> Model "Orderlicense_model" initialized
DEBUG - 2026-07-03 08:33:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 08:33:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 08:33:41 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/cart_software.php
INFO - 2026-07-03 08:33:41 --> Final output sent to browser
DEBUG - 2026-07-03 08:33:41 --> Total execution time: 4.2954
INFO - 2026-07-03 09:42:39 --> Config Class Initialized
INFO - 2026-07-03 09:42:39 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:42:39 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:42:39 --> Utf8 Class Initialized
INFO - 2026-07-03 09:42:39 --> URI Class Initialized
INFO - 2026-07-03 09:42:39 --> Router Class Initialized
INFO - 2026-07-03 09:42:39 --> Output Class Initialized
INFO - 2026-07-03 09:42:39 --> Security Class Initialized
DEBUG - 2026-07-03 09:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:42:39 --> CSRF cookie sent
INFO - 2026-07-03 09:42:39 --> Input Class Initialized
INFO - 2026-07-03 09:42:39 --> Language Class Initialized
INFO - 2026-07-03 09:42:39 --> Language Class Initialized
INFO - 2026-07-03 09:42:39 --> Config Class Initialized
INFO - 2026-07-03 09:42:39 --> Loader Class Initialized
INFO - 2026-07-03 09:42:39 --> Helper loaded: url_helper
INFO - 2026-07-03 09:42:39 --> Helper loaded: form_helper
INFO - 2026-07-03 09:42:39 --> Helper loaded: html_helper
INFO - 2026-07-03 09:42:39 --> Helper loaded: file_helper
INFO - 2026-07-03 09:42:39 --> Helper loaded: email_helper
INFO - 2026-07-03 09:42:39 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:42:39 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:42:39 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:42:39 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:42:39 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:42:39 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:42:39 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:42:39 --> Database Driver Class Initialized
INFO - 2026-07-03 09:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:42:41 --> Upload Class Initialized
DEBUG - 2026-07-03 09:42:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:42:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:42:41 --> Encryption Class Initialized
INFO - 2026-07-03 09:42:41 --> Form Validation Class Initialized
INFO - 2026-07-03 09:42:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:42:41 --> Pagination Class Initialized
INFO - 2026-07-03 09:42:41 --> Email Class Initialized
INFO - 2026-07-03 09:42:41 --> Controller Class Initialized
DEBUG - 2026-07-03 09:42:41 --> Authenticate MX_Controller Initialized
INFO - 2026-07-03 09:42:41 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:42:41 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 09:42:41 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 09:42:41 --> Config Class Initialized
INFO - 2026-07-03 09:42:41 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:42:41 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:42:41 --> Utf8 Class Initialized
INFO - 2026-07-03 09:42:41 --> URI Class Initialized
INFO - 2026-07-03 09:42:41 --> Router Class Initialized
INFO - 2026-07-03 09:42:41 --> Output Class Initialized
INFO - 2026-07-03 09:42:41 --> Security Class Initialized
DEBUG - 2026-07-03 09:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:42:41 --> CSRF cookie sent
INFO - 2026-07-03 09:42:41 --> Input Class Initialized
INFO - 2026-07-03 09:42:41 --> Language Class Initialized
INFO - 2026-07-03 09:42:41 --> Language Class Initialized
INFO - 2026-07-03 09:42:41 --> Config Class Initialized
INFO - 2026-07-03 09:42:41 --> Loader Class Initialized
INFO - 2026-07-03 09:42:41 --> Helper loaded: url_helper
INFO - 2026-07-03 09:42:41 --> Helper loaded: form_helper
INFO - 2026-07-03 09:42:41 --> Helper loaded: html_helper
INFO - 2026-07-03 09:42:41 --> Helper loaded: file_helper
INFO - 2026-07-03 09:42:41 --> Helper loaded: email_helper
INFO - 2026-07-03 09:42:41 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:42:41 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:42:41 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:42:41 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:42:41 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:42:41 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:42:41 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:42:41 --> Database Driver Class Initialized
INFO - 2026-07-03 09:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:42:43 --> Upload Class Initialized
DEBUG - 2026-07-03 09:42:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:42:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:42:43 --> Encryption Class Initialized
INFO - 2026-07-03 09:42:43 --> Form Validation Class Initialized
INFO - 2026-07-03 09:42:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:42:43 --> Pagination Class Initialized
INFO - 2026-07-03 09:42:43 --> Email Class Initialized
INFO - 2026-07-03 09:42:43 --> Controller Class Initialized
DEBUG - 2026-07-03 09:42:43 --> Authenticate MX_Controller Initialized
INFO - 2026-07-03 09:42:43 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:42:43 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 09:42:43 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-03 09:42:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 09:42:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 09:42:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-07-03 09:42:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-03 09:42:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 09:42:44 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-07-03 09:42:44 --> Final output sent to browser
DEBUG - 2026-07-03 09:42:44 --> Total execution time: 2.3225
INFO - 2026-07-03 09:42:44 --> Config Class Initialized
INFO - 2026-07-03 09:42:44 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:42:44 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:42:44 --> Utf8 Class Initialized
INFO - 2026-07-03 09:42:44 --> URI Class Initialized
INFO - 2026-07-03 09:42:44 --> Router Class Initialized
INFO - 2026-07-03 09:42:44 --> Output Class Initialized
INFO - 2026-07-03 09:42:44 --> Security Class Initialized
DEBUG - 2026-07-03 09:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:42:44 --> CSRF cookie sent
INFO - 2026-07-03 09:42:44 --> Input Class Initialized
INFO - 2026-07-03 09:42:44 --> Language Class Initialized
INFO - 2026-07-03 09:42:44 --> Language Class Initialized
INFO - 2026-07-03 09:42:44 --> Config Class Initialized
INFO - 2026-07-03 09:42:44 --> Loader Class Initialized
INFO - 2026-07-03 09:42:44 --> Helper loaded: url_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: form_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: html_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: file_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: email_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:42:44 --> Database Driver Class Initialized
INFO - 2026-07-03 09:42:44 --> Config Class Initialized
INFO - 2026-07-03 09:42:44 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:42:44 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:42:44 --> Utf8 Class Initialized
INFO - 2026-07-03 09:42:44 --> URI Class Initialized
INFO - 2026-07-03 09:42:44 --> Router Class Initialized
INFO - 2026-07-03 09:42:44 --> Output Class Initialized
INFO - 2026-07-03 09:42:44 --> Security Class Initialized
DEBUG - 2026-07-03 09:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:42:44 --> CSRF cookie sent
INFO - 2026-07-03 09:42:44 --> Input Class Initialized
INFO - 2026-07-03 09:42:44 --> Language Class Initialized
INFO - 2026-07-03 09:42:44 --> Language Class Initialized
INFO - 2026-07-03 09:42:44 --> Config Class Initialized
INFO - 2026-07-03 09:42:44 --> Loader Class Initialized
INFO - 2026-07-03 09:42:44 --> Helper loaded: url_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: form_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: html_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: file_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: email_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:42:44 --> Database Driver Class Initialized
INFO - 2026-07-03 09:42:44 --> Config Class Initialized
INFO - 2026-07-03 09:42:44 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:42:44 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:42:44 --> Utf8 Class Initialized
INFO - 2026-07-03 09:42:44 --> URI Class Initialized
INFO - 2026-07-03 09:42:44 --> Router Class Initialized
INFO - 2026-07-03 09:42:44 --> Output Class Initialized
INFO - 2026-07-03 09:42:44 --> Security Class Initialized
DEBUG - 2026-07-03 09:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:42:44 --> CSRF cookie sent
INFO - 2026-07-03 09:42:44 --> Input Class Initialized
INFO - 2026-07-03 09:42:44 --> Language Class Initialized
INFO - 2026-07-03 09:42:44 --> Language Class Initialized
INFO - 2026-07-03 09:42:44 --> Config Class Initialized
INFO - 2026-07-03 09:42:44 --> Loader Class Initialized
INFO - 2026-07-03 09:42:44 --> Helper loaded: url_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: form_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: html_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: file_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: email_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:42:44 --> Database Driver Class Initialized
INFO - 2026-07-03 09:42:44 --> Config Class Initialized
INFO - 2026-07-03 09:42:44 --> Hooks Class Initialized
INFO - 2026-07-03 09:42:44 --> Config Class Initialized
INFO - 2026-07-03 09:42:44 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:42:44 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:42:44 --> Utf8 Class Initialized
INFO - 2026-07-03 09:42:44 --> Config Class Initialized
INFO - 2026-07-03 09:42:44 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:42:44 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:42:44 --> Utf8 Class Initialized
INFO - 2026-07-03 09:42:44 --> URI Class Initialized
INFO - 2026-07-03 09:42:44 --> URI Class Initialized
DEBUG - 2026-07-03 09:42:44 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:42:44 --> Utf8 Class Initialized
INFO - 2026-07-03 09:42:44 --> Router Class Initialized
INFO - 2026-07-03 09:42:44 --> Router Class Initialized
INFO - 2026-07-03 09:42:44 --> URI Class Initialized
INFO - 2026-07-03 09:42:44 --> Output Class Initialized
INFO - 2026-07-03 09:42:44 --> Output Class Initialized
INFO - 2026-07-03 09:42:44 --> Router Class Initialized
INFO - 2026-07-03 09:42:44 --> Security Class Initialized
INFO - 2026-07-03 09:42:44 --> Security Class Initialized
DEBUG - 2026-07-03 09:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:42:44 --> CSRF cookie sent
INFO - 2026-07-03 09:42:44 --> Input Class Initialized
DEBUG - 2026-07-03 09:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:42:44 --> CSRF cookie sent
INFO - 2026-07-03 09:42:44 --> Input Class Initialized
INFO - 2026-07-03 09:42:44 --> Language Class Initialized
INFO - 2026-07-03 09:42:44 --> Language Class Initialized
INFO - 2026-07-03 09:42:44 --> Language Class Initialized
INFO - 2026-07-03 09:42:44 --> Config Class Initialized
INFO - 2026-07-03 09:42:44 --> Language Class Initialized
INFO - 2026-07-03 09:42:44 --> Config Class Initialized
INFO - 2026-07-03 09:42:44 --> Loader Class Initialized
INFO - 2026-07-03 09:42:44 --> Loader Class Initialized
INFO - 2026-07-03 09:42:44 --> Helper loaded: url_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: url_helper
INFO - 2026-07-03 09:42:44 --> Output Class Initialized
INFO - 2026-07-03 09:42:44 --> Helper loaded: form_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: html_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: form_helper
INFO - 2026-07-03 09:42:44 --> Security Class Initialized
INFO - 2026-07-03 09:42:44 --> Helper loaded: file_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: email_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: html_helper
DEBUG - 2026-07-03 09:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:42:44 --> Helper loaded: file_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: email_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:42:44 --> CSRF cookie sent
INFO - 2026-07-03 09:42:44 --> Input Class Initialized
INFO - 2026-07-03 09:42:44 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:42:44 --> Language Class Initialized
INFO - 2026-07-03 09:42:44 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:42:44 --> Language Class Initialized
INFO - 2026-07-03 09:42:44 --> Config Class Initialized
INFO - 2026-07-03 09:42:44 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:42:44 --> Loader Class Initialized
INFO - 2026-07-03 09:42:44 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: url_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: form_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: html_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: file_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: email_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:42:44 --> Database Driver Class Initialized
INFO - 2026-07-03 09:42:44 --> Database Driver Class Initialized
INFO - 2026-07-03 09:42:44 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:42:44 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:42:44 --> Database Driver Class Initialized
INFO - 2026-07-03 09:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:42:45 --> Upload Class Initialized
DEBUG - 2026-07-03 09:42:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:42:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:42:45 --> Encryption Class Initialized
INFO - 2026-07-03 09:42:45 --> Form Validation Class Initialized
INFO - 2026-07-03 09:42:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:42:45 --> Pagination Class Initialized
INFO - 2026-07-03 09:42:45 --> Email Class Initialized
INFO - 2026-07-03 09:42:45 --> Controller Class Initialized
ERROR - 2026-07-03 09:42:45 --> 404 Page Not Found: /index
INFO - 2026-07-03 09:42:45 --> Config Class Initialized
INFO - 2026-07-03 09:42:45 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:42:45 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:42:45 --> Utf8 Class Initialized
INFO - 2026-07-03 09:42:45 --> URI Class Initialized
INFO - 2026-07-03 09:42:45 --> Router Class Initialized
INFO - 2026-07-03 09:42:45 --> Output Class Initialized
INFO - 2026-07-03 09:42:45 --> Security Class Initialized
DEBUG - 2026-07-03 09:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:42:45 --> CSRF cookie sent
INFO - 2026-07-03 09:42:45 --> Input Class Initialized
INFO - 2026-07-03 09:42:45 --> Language Class Initialized
INFO - 2026-07-03 09:42:45 --> Language Class Initialized
INFO - 2026-07-03 09:42:45 --> Config Class Initialized
INFO - 2026-07-03 09:42:45 --> Loader Class Initialized
INFO - 2026-07-03 09:42:45 --> Helper loaded: url_helper
INFO - 2026-07-03 09:42:45 --> Helper loaded: form_helper
INFO - 2026-07-03 09:42:45 --> Helper loaded: html_helper
INFO - 2026-07-03 09:42:45 --> Helper loaded: file_helper
INFO - 2026-07-03 09:42:45 --> Helper loaded: email_helper
INFO - 2026-07-03 09:42:45 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:42:45 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:42:45 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:42:45 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:42:45 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:42:45 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:42:45 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:42:45 --> Database Driver Class Initialized
INFO - 2026-07-03 09:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:42:45 --> Upload Class Initialized
DEBUG - 2026-07-03 09:42:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:42:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:42:45 --> Encryption Class Initialized
INFO - 2026-07-03 09:42:45 --> Form Validation Class Initialized
INFO - 2026-07-03 09:42:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:42:45 --> Pagination Class Initialized
INFO - 2026-07-03 09:42:45 --> Email Class Initialized
INFO - 2026-07-03 09:42:45 --> Controller Class Initialized
ERROR - 2026-07-03 09:42:45 --> 404 Page Not Found: /index
INFO - 2026-07-03 09:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:42:45 --> Upload Class Initialized
DEBUG - 2026-07-03 09:42:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:42:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:42:45 --> Encryption Class Initialized
INFO - 2026-07-03 09:42:45 --> Form Validation Class Initialized
INFO - 2026-07-03 09:42:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:42:45 --> Pagination Class Initialized
INFO - 2026-07-03 09:42:45 --> Email Class Initialized
INFO - 2026-07-03 09:42:45 --> Controller Class Initialized
ERROR - 2026-07-03 09:42:45 --> 404 Page Not Found: /index
INFO - 2026-07-03 09:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:42:46 --> Upload Class Initialized
DEBUG - 2026-07-03 09:42:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:42:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:42:46 --> Encryption Class Initialized
INFO - 2026-07-03 09:42:46 --> Form Validation Class Initialized
INFO - 2026-07-03 09:42:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:42:46 --> Pagination Class Initialized
INFO - 2026-07-03 09:42:46 --> Email Class Initialized
INFO - 2026-07-03 09:42:46 --> Controller Class Initialized
ERROR - 2026-07-03 09:42:46 --> 404 Page Not Found: /index
INFO - 2026-07-03 09:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:42:46 --> Upload Class Initialized
DEBUG - 2026-07-03 09:42:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:42:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:42:46 --> Encryption Class Initialized
INFO - 2026-07-03 09:42:46 --> Form Validation Class Initialized
INFO - 2026-07-03 09:42:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:42:46 --> Pagination Class Initialized
INFO - 2026-07-03 09:42:46 --> Email Class Initialized
INFO - 2026-07-03 09:42:46 --> Controller Class Initialized
ERROR - 2026-07-03 09:42:46 --> 404 Page Not Found: /index
INFO - 2026-07-03 09:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:42:47 --> Upload Class Initialized
DEBUG - 2026-07-03 09:42:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:42:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:42:47 --> Encryption Class Initialized
INFO - 2026-07-03 09:42:47 --> Form Validation Class Initialized
INFO - 2026-07-03 09:42:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:42:47 --> Pagination Class Initialized
INFO - 2026-07-03 09:42:47 --> Email Class Initialized
INFO - 2026-07-03 09:42:47 --> Controller Class Initialized
ERROR - 2026-07-03 09:42:47 --> 404 Page Not Found: /index
INFO - 2026-07-03 09:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:42:47 --> Upload Class Initialized
DEBUG - 2026-07-03 09:42:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:42:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:42:47 --> Encryption Class Initialized
INFO - 2026-07-03 09:42:47 --> Form Validation Class Initialized
INFO - 2026-07-03 09:42:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:42:47 --> Pagination Class Initialized
INFO - 2026-07-03 09:42:47 --> Email Class Initialized
INFO - 2026-07-03 09:42:47 --> Controller Class Initialized
ERROR - 2026-07-03 09:42:47 --> 404 Page Not Found: /index
INFO - 2026-07-03 09:42:51 --> Config Class Initialized
INFO - 2026-07-03 09:42:51 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:42:51 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:42:51 --> Utf8 Class Initialized
INFO - 2026-07-03 09:42:51 --> URI Class Initialized
INFO - 2026-07-03 09:42:51 --> Router Class Initialized
INFO - 2026-07-03 09:42:51 --> Output Class Initialized
INFO - 2026-07-03 09:42:51 --> Security Class Initialized
DEBUG - 2026-07-03 09:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:42:51 --> CSRF cookie sent
INFO - 2026-07-03 09:42:51 --> Input Class Initialized
INFO - 2026-07-03 09:42:51 --> Language Class Initialized
INFO - 2026-07-03 09:42:51 --> Language Class Initialized
INFO - 2026-07-03 09:42:51 --> Config Class Initialized
INFO - 2026-07-03 09:42:51 --> Loader Class Initialized
INFO - 2026-07-03 09:42:51 --> Helper loaded: url_helper
INFO - 2026-07-03 09:42:51 --> Helper loaded: form_helper
INFO - 2026-07-03 09:42:51 --> Helper loaded: html_helper
INFO - 2026-07-03 09:42:51 --> Helper loaded: file_helper
INFO - 2026-07-03 09:42:51 --> Helper loaded: email_helper
INFO - 2026-07-03 09:42:51 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:42:51 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:42:51 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:42:51 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:42:51 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:42:51 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:42:51 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:42:51 --> Database Driver Class Initialized
INFO - 2026-07-03 09:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:42:52 --> Upload Class Initialized
DEBUG - 2026-07-03 09:42:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:42:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:42:52 --> Encryption Class Initialized
INFO - 2026-07-03 09:42:52 --> Form Validation Class Initialized
INFO - 2026-07-03 09:42:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:42:52 --> Pagination Class Initialized
INFO - 2026-07-03 09:42:52 --> Email Class Initialized
INFO - 2026-07-03 09:42:52 --> Controller Class Initialized
DEBUG - 2026-07-03 09:42:52 --> Auth MX_Controller Initialized
INFO - 2026-07-03 09:42:52 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:42:52 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:42:52 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:42:53 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-03 09:42:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 09:42:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 09:42:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 09:42:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-07-03 09:42:53 --> Final output sent to browser
DEBUG - 2026-07-03 09:42:53 --> Total execution time: 2.4547
INFO - 2026-07-03 09:42:53 --> Config Class Initialized
INFO - 2026-07-03 09:42:53 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:42:53 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:42:53 --> Utf8 Class Initialized
INFO - 2026-07-03 09:42:53 --> URI Class Initialized
INFO - 2026-07-03 09:42:53 --> Router Class Initialized
INFO - 2026-07-03 09:42:53 --> Output Class Initialized
INFO - 2026-07-03 09:42:53 --> Security Class Initialized
DEBUG - 2026-07-03 09:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:42:53 --> CSRF cookie sent
INFO - 2026-07-03 09:42:53 --> Input Class Initialized
INFO - 2026-07-03 09:42:53 --> Language Class Initialized
INFO - 2026-07-03 09:42:53 --> Language Class Initialized
INFO - 2026-07-03 09:42:53 --> Config Class Initialized
INFO - 2026-07-03 09:42:53 --> Loader Class Initialized
INFO - 2026-07-03 09:42:53 --> Helper loaded: url_helper
INFO - 2026-07-03 09:42:53 --> Helper loaded: form_helper
INFO - 2026-07-03 09:42:53 --> Helper loaded: html_helper
INFO - 2026-07-03 09:42:53 --> Helper loaded: file_helper
INFO - 2026-07-03 09:42:53 --> Helper loaded: email_helper
INFO - 2026-07-03 09:42:53 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:42:53 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:42:53 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:42:53 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:42:53 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:42:53 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:42:53 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:42:53 --> Database Driver Class Initialized
INFO - 2026-07-03 09:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:42:55 --> Upload Class Initialized
DEBUG - 2026-07-03 09:42:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:42:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:42:55 --> Encryption Class Initialized
INFO - 2026-07-03 09:42:55 --> Form Validation Class Initialized
INFO - 2026-07-03 09:42:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:42:55 --> Pagination Class Initialized
INFO - 2026-07-03 09:42:55 --> Email Class Initialized
INFO - 2026-07-03 09:42:55 --> Controller Class Initialized
DEBUG - 2026-07-03 09:42:55 --> Cart MX_Controller Initialized
INFO - 2026-07-03 09:42:55 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:42:55 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:42:55 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:42:55 --> Model "Common_model" initialized
INFO - 2026-07-03 09:42:55 --> Model "Order_model" initialized
INFO - 2026-07-03 09:42:55 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 09:42:55 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 09:42:55 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 09:42:55 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 09:42:55 --> Model "Plan_model" initialized
INFO - 2026-07-03 09:42:55 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 09:42:55 --> Final output sent to browser
DEBUG - 2026-07-03 09:42:55 --> Total execution time: 2.0316
INFO - 2026-07-03 09:42:56 --> Config Class Initialized
INFO - 2026-07-03 09:42:56 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:42:56 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:42:56 --> Utf8 Class Initialized
INFO - 2026-07-03 09:42:56 --> URI Class Initialized
INFO - 2026-07-03 09:42:56 --> Router Class Initialized
INFO - 2026-07-03 09:42:56 --> Output Class Initialized
INFO - 2026-07-03 09:42:56 --> Security Class Initialized
DEBUG - 2026-07-03 09:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:42:56 --> CSRF cookie sent
INFO - 2026-07-03 09:42:56 --> Input Class Initialized
INFO - 2026-07-03 09:42:56 --> Language Class Initialized
INFO - 2026-07-03 09:42:56 --> Language Class Initialized
INFO - 2026-07-03 09:42:56 --> Config Class Initialized
INFO - 2026-07-03 09:42:56 --> Loader Class Initialized
INFO - 2026-07-03 09:42:56 --> Helper loaded: url_helper
INFO - 2026-07-03 09:42:56 --> Helper loaded: form_helper
INFO - 2026-07-03 09:42:56 --> Helper loaded: html_helper
INFO - 2026-07-03 09:42:56 --> Helper loaded: file_helper
INFO - 2026-07-03 09:42:56 --> Helper loaded: email_helper
INFO - 2026-07-03 09:42:56 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:42:56 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:42:56 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:42:56 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:42:56 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:42:56 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:42:56 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:42:56 --> Database Driver Class Initialized
INFO - 2026-07-03 09:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:42:58 --> Upload Class Initialized
DEBUG - 2026-07-03 09:42:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:42:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:42:58 --> Encryption Class Initialized
INFO - 2026-07-03 09:42:58 --> Form Validation Class Initialized
INFO - 2026-07-03 09:42:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:42:58 --> Pagination Class Initialized
INFO - 2026-07-03 09:42:58 --> Email Class Initialized
INFO - 2026-07-03 09:42:58 --> Controller Class Initialized
DEBUG - 2026-07-03 09:42:58 --> Auth MX_Controller Initialized
INFO - 2026-07-03 09:42:58 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:42:58 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:42:58 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:42:58 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-03 09:42:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 09:42:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 09:42:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 09:42:58 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-07-03 09:42:58 --> Final output sent to browser
DEBUG - 2026-07-03 09:42:58 --> Total execution time: 2.4634
INFO - 2026-07-03 09:42:58 --> Config Class Initialized
INFO - 2026-07-03 09:42:58 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:42:58 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:42:58 --> Utf8 Class Initialized
INFO - 2026-07-03 09:42:58 --> URI Class Initialized
INFO - 2026-07-03 09:42:58 --> Router Class Initialized
INFO - 2026-07-03 09:42:58 --> Output Class Initialized
INFO - 2026-07-03 09:42:58 --> Security Class Initialized
DEBUG - 2026-07-03 09:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:42:58 --> CSRF cookie sent
INFO - 2026-07-03 09:42:58 --> Input Class Initialized
INFO - 2026-07-03 09:42:58 --> Language Class Initialized
INFO - 2026-07-03 09:42:58 --> Language Class Initialized
INFO - 2026-07-03 09:42:58 --> Config Class Initialized
INFO - 2026-07-03 09:42:58 --> Loader Class Initialized
INFO - 2026-07-03 09:42:58 --> Helper loaded: url_helper
INFO - 2026-07-03 09:42:58 --> Helper loaded: form_helper
INFO - 2026-07-03 09:42:58 --> Helper loaded: html_helper
INFO - 2026-07-03 09:42:58 --> Helper loaded: file_helper
INFO - 2026-07-03 09:42:58 --> Helper loaded: email_helper
INFO - 2026-07-03 09:42:58 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:42:58 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:42:58 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:42:58 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:42:58 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:42:58 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:42:58 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:42:58 --> Database Driver Class Initialized
INFO - 2026-07-03 09:42:59 --> Config Class Initialized
INFO - 2026-07-03 09:42:59 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:42:59 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:42:59 --> Utf8 Class Initialized
INFO - 2026-07-03 09:42:59 --> URI Class Initialized
INFO - 2026-07-03 09:42:59 --> Router Class Initialized
INFO - 2026-07-03 09:42:59 --> Output Class Initialized
INFO - 2026-07-03 09:42:59 --> Security Class Initialized
DEBUG - 2026-07-03 09:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:42:59 --> CSRF cookie sent
INFO - 2026-07-03 09:42:59 --> Input Class Initialized
INFO - 2026-07-03 09:42:59 --> Language Class Initialized
INFO - 2026-07-03 09:42:59 --> Language Class Initialized
INFO - 2026-07-03 09:42:59 --> Config Class Initialized
INFO - 2026-07-03 09:42:59 --> Loader Class Initialized
INFO - 2026-07-03 09:42:59 --> Helper loaded: url_helper
INFO - 2026-07-03 09:42:59 --> Helper loaded: form_helper
INFO - 2026-07-03 09:42:59 --> Helper loaded: html_helper
INFO - 2026-07-03 09:42:59 --> Helper loaded: file_helper
INFO - 2026-07-03 09:42:59 --> Helper loaded: email_helper
INFO - 2026-07-03 09:42:59 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:42:59 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:42:59 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:42:59 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:42:59 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:42:59 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:42:59 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:42:59 --> Database Driver Class Initialized
INFO - 2026-07-03 09:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:43:00 --> Upload Class Initialized
DEBUG - 2026-07-03 09:43:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:43:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:43:00 --> Encryption Class Initialized
INFO - 2026-07-03 09:43:00 --> Form Validation Class Initialized
INFO - 2026-07-03 09:43:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:43:00 --> Pagination Class Initialized
INFO - 2026-07-03 09:43:00 --> Email Class Initialized
INFO - 2026-07-03 09:43:00 --> Controller Class Initialized
DEBUG - 2026-07-03 09:43:00 --> Cart MX_Controller Initialized
INFO - 2026-07-03 09:43:00 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:43:00 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:43:00 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:43:00 --> Model "Common_model" initialized
INFO - 2026-07-03 09:43:00 --> Model "Order_model" initialized
INFO - 2026-07-03 09:43:00 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 09:43:00 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 09:43:00 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 09:43:00 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 09:43:00 --> Model "Plan_model" initialized
INFO - 2026-07-03 09:43:00 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 09:43:00 --> Final output sent to browser
DEBUG - 2026-07-03 09:43:00 --> Total execution time: 2.0890
INFO - 2026-07-03 09:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:43:01 --> Upload Class Initialized
DEBUG - 2026-07-03 09:43:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:43:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:43:01 --> Encryption Class Initialized
INFO - 2026-07-03 09:43:01 --> Form Validation Class Initialized
INFO - 2026-07-03 09:43:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:43:01 --> Pagination Class Initialized
INFO - 2026-07-03 09:43:01 --> Email Class Initialized
INFO - 2026-07-03 09:43:01 --> Controller Class Initialized
DEBUG - 2026-07-03 09:43:01 --> Auth MX_Controller Initialized
INFO - 2026-07-03 09:43:01 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:43:01 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:43:01 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:43:01 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-03 09:43:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 09:43:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 09:43:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 09:43:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-07-03 09:43:02 --> Final output sent to browser
DEBUG - 2026-07-03 09:43:02 --> Total execution time: 2.3399
INFO - 2026-07-03 09:43:02 --> Config Class Initialized
INFO - 2026-07-03 09:43:02 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:43:02 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:43:02 --> Utf8 Class Initialized
INFO - 2026-07-03 09:43:02 --> URI Class Initialized
INFO - 2026-07-03 09:43:02 --> Router Class Initialized
INFO - 2026-07-03 09:43:02 --> Output Class Initialized
INFO - 2026-07-03 09:43:02 --> Security Class Initialized
DEBUG - 2026-07-03 09:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:43:02 --> CSRF cookie sent
INFO - 2026-07-03 09:43:02 --> Input Class Initialized
INFO - 2026-07-03 09:43:02 --> Language Class Initialized
INFO - 2026-07-03 09:43:02 --> Language Class Initialized
INFO - 2026-07-03 09:43:02 --> Config Class Initialized
INFO - 2026-07-03 09:43:02 --> Loader Class Initialized
INFO - 2026-07-03 09:43:02 --> Helper loaded: url_helper
INFO - 2026-07-03 09:43:02 --> Helper loaded: form_helper
INFO - 2026-07-03 09:43:02 --> Helper loaded: html_helper
INFO - 2026-07-03 09:43:02 --> Helper loaded: file_helper
INFO - 2026-07-03 09:43:02 --> Helper loaded: email_helper
INFO - 2026-07-03 09:43:02 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:43:02 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:43:02 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:43:02 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:43:02 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:43:02 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:43:02 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:43:02 --> Database Driver Class Initialized
INFO - 2026-07-03 09:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:43:04 --> Upload Class Initialized
DEBUG - 2026-07-03 09:43:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:43:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:43:04 --> Encryption Class Initialized
INFO - 2026-07-03 09:43:04 --> Form Validation Class Initialized
INFO - 2026-07-03 09:43:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:43:04 --> Pagination Class Initialized
INFO - 2026-07-03 09:43:04 --> Email Class Initialized
INFO - 2026-07-03 09:43:04 --> Controller Class Initialized
DEBUG - 2026-07-03 09:43:04 --> Cart MX_Controller Initialized
INFO - 2026-07-03 09:43:04 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:43:04 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:43:04 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:43:04 --> Model "Common_model" initialized
INFO - 2026-07-03 09:43:04 --> Model "Order_model" initialized
INFO - 2026-07-03 09:43:04 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 09:43:04 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 09:43:04 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 09:43:04 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 09:43:04 --> Model "Plan_model" initialized
INFO - 2026-07-03 09:43:04 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 09:43:04 --> Final output sent to browser
DEBUG - 2026-07-03 09:43:04 --> Total execution time: 2.4038
INFO - 2026-07-03 09:43:06 --> Config Class Initialized
INFO - 2026-07-03 09:43:06 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:43:06 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:43:06 --> Utf8 Class Initialized
INFO - 2026-07-03 09:43:06 --> URI Class Initialized
INFO - 2026-07-03 09:43:06 --> Router Class Initialized
INFO - 2026-07-03 09:43:06 --> Output Class Initialized
INFO - 2026-07-03 09:43:06 --> Security Class Initialized
DEBUG - 2026-07-03 09:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:43:06 --> CSRF cookie sent
INFO - 2026-07-03 09:43:06 --> Input Class Initialized
INFO - 2026-07-03 09:43:06 --> Language Class Initialized
INFO - 2026-07-03 09:43:06 --> Language Class Initialized
INFO - 2026-07-03 09:43:06 --> Config Class Initialized
INFO - 2026-07-03 09:43:06 --> Loader Class Initialized
INFO - 2026-07-03 09:43:06 --> Helper loaded: url_helper
INFO - 2026-07-03 09:43:06 --> Helper loaded: form_helper
INFO - 2026-07-03 09:43:06 --> Helper loaded: html_helper
INFO - 2026-07-03 09:43:06 --> Helper loaded: file_helper
INFO - 2026-07-03 09:43:06 --> Helper loaded: email_helper
INFO - 2026-07-03 09:43:06 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:43:06 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:43:06 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:43:06 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:43:06 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:43:06 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:43:06 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:43:06 --> Database Driver Class Initialized
INFO - 2026-07-03 09:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:43:08 --> Upload Class Initialized
DEBUG - 2026-07-03 09:43:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:43:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:43:08 --> Encryption Class Initialized
INFO - 2026-07-03 09:43:08 --> Form Validation Class Initialized
INFO - 2026-07-03 09:43:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:43:08 --> Pagination Class Initialized
INFO - 2026-07-03 09:43:08 --> Email Class Initialized
INFO - 2026-07-03 09:43:08 --> Controller Class Initialized
DEBUG - 2026-07-03 09:43:08 --> Cart MX_Controller Initialized
INFO - 2026-07-03 09:43:08 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:43:08 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:43:08 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:43:08 --> Model "Common_model" initialized
INFO - 2026-07-03 09:43:08 --> Model "Order_model" initialized
INFO - 2026-07-03 09:43:08 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 09:43:08 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 09:43:08 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 09:43:08 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 09:43:08 --> Model "Plan_model" initialized
INFO - 2026-07-03 09:43:08 --> Model "Orderlicense_model" initialized
DEBUG - 2026-07-03 09:43:09 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 09:43:09 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-07-03 09:43:09 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-07-03 09:43:09 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 09:43:09 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 09:43:09 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/cart_services.php
INFO - 2026-07-03 09:43:09 --> Final output sent to browser
DEBUG - 2026-07-03 09:43:09 --> Total execution time: 3.4082
INFO - 2026-07-03 09:43:10 --> Config Class Initialized
INFO - 2026-07-03 09:43:10 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:43:10 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:43:10 --> Utf8 Class Initialized
INFO - 2026-07-03 09:43:10 --> URI Class Initialized
INFO - 2026-07-03 09:43:10 --> Router Class Initialized
INFO - 2026-07-03 09:43:10 --> Output Class Initialized
INFO - 2026-07-03 09:43:10 --> Security Class Initialized
DEBUG - 2026-07-03 09:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:43:10 --> CSRF cookie sent
INFO - 2026-07-03 09:43:10 --> Input Class Initialized
INFO - 2026-07-03 09:43:10 --> Language Class Initialized
INFO - 2026-07-03 09:43:10 --> Language Class Initialized
INFO - 2026-07-03 09:43:10 --> Config Class Initialized
INFO - 2026-07-03 09:43:10 --> Loader Class Initialized
INFO - 2026-07-03 09:43:10 --> Helper loaded: url_helper
INFO - 2026-07-03 09:43:10 --> Helper loaded: form_helper
INFO - 2026-07-03 09:43:10 --> Helper loaded: html_helper
INFO - 2026-07-03 09:43:10 --> Helper loaded: file_helper
INFO - 2026-07-03 09:43:10 --> Helper loaded: email_helper
INFO - 2026-07-03 09:43:10 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:43:10 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:43:10 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:43:10 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:43:10 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:43:10 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:43:10 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:43:10 --> Database Driver Class Initialized
INFO - 2026-07-03 09:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:43:11 --> Upload Class Initialized
DEBUG - 2026-07-03 09:43:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:43:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:43:11 --> Encryption Class Initialized
INFO - 2026-07-03 09:43:11 --> Form Validation Class Initialized
INFO - 2026-07-03 09:43:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:43:11 --> Pagination Class Initialized
INFO - 2026-07-03 09:43:11 --> Email Class Initialized
INFO - 2026-07-03 09:43:11 --> Controller Class Initialized
DEBUG - 2026-07-03 09:43:11 --> Cart MX_Controller Initialized
INFO - 2026-07-03 09:43:11 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:43:11 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:43:11 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:43:11 --> Model "Common_model" initialized
INFO - 2026-07-03 09:43:11 --> Model "Order_model" initialized
INFO - 2026-07-03 09:43:11 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 09:43:11 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 09:43:11 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 09:43:11 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 09:43:11 --> Model "Plan_model" initialized
INFO - 2026-07-03 09:43:11 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 09:43:12 --> Final output sent to browser
DEBUG - 2026-07-03 09:43:12 --> Total execution time: 2.0267
INFO - 2026-07-03 09:45:57 --> Config Class Initialized
INFO - 2026-07-03 09:45:57 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:45:57 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:45:57 --> Utf8 Class Initialized
INFO - 2026-07-03 09:45:57 --> URI Class Initialized
INFO - 2026-07-03 09:45:57 --> Router Class Initialized
INFO - 2026-07-03 09:45:57 --> Output Class Initialized
INFO - 2026-07-03 09:45:57 --> Security Class Initialized
DEBUG - 2026-07-03 09:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:45:57 --> CSRF cookie sent
INFO - 2026-07-03 09:45:57 --> Input Class Initialized
INFO - 2026-07-03 09:45:57 --> Language Class Initialized
INFO - 2026-07-03 09:45:57 --> Language Class Initialized
INFO - 2026-07-03 09:45:57 --> Config Class Initialized
INFO - 2026-07-03 09:45:57 --> Loader Class Initialized
INFO - 2026-07-03 09:45:57 --> Helper loaded: url_helper
INFO - 2026-07-03 09:45:57 --> Helper loaded: form_helper
INFO - 2026-07-03 09:45:57 --> Helper loaded: html_helper
INFO - 2026-07-03 09:45:57 --> Helper loaded: file_helper
INFO - 2026-07-03 09:45:57 --> Helper loaded: email_helper
INFO - 2026-07-03 09:45:57 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:45:57 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:45:57 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:45:57 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:45:57 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:45:57 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:45:57 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:45:57 --> Database Driver Class Initialized
INFO - 2026-07-03 09:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:45:59 --> Upload Class Initialized
DEBUG - 2026-07-03 09:45:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:45:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:45:59 --> Encryption Class Initialized
INFO - 2026-07-03 09:45:59 --> Form Validation Class Initialized
INFO - 2026-07-03 09:45:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:45:59 --> Pagination Class Initialized
INFO - 2026-07-03 09:45:59 --> Email Class Initialized
INFO - 2026-07-03 09:45:59 --> Controller Class Initialized
DEBUG - 2026-07-03 09:45:59 --> Cart MX_Controller Initialized
INFO - 2026-07-03 09:45:59 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:45:59 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:45:59 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:46:00 --> Model "Common_model" initialized
INFO - 2026-07-03 09:46:00 --> Model "Order_model" initialized
INFO - 2026-07-03 09:46:00 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 09:46:00 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 09:46:00 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 09:46:00 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 09:46:00 --> Model "Plan_model" initialized
INFO - 2026-07-03 09:46:00 --> Model "Orderlicense_model" initialized
DEBUG - 2026-07-03 09:46:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 09:46:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 09:46:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/cart_software.php
INFO - 2026-07-03 09:46:02 --> Final output sent to browser
DEBUG - 2026-07-03 09:46:02 --> Total execution time: 4.4619
INFO - 2026-07-03 09:50:45 --> Config Class Initialized
INFO - 2026-07-03 09:50:45 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:50:45 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:50:45 --> Utf8 Class Initialized
INFO - 2026-07-03 09:50:45 --> URI Class Initialized
INFO - 2026-07-03 09:50:45 --> Router Class Initialized
INFO - 2026-07-03 09:50:45 --> Output Class Initialized
INFO - 2026-07-03 09:50:45 --> Security Class Initialized
DEBUG - 2026-07-03 09:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:50:45 --> CSRF cookie sent
INFO - 2026-07-03 09:50:45 --> Input Class Initialized
INFO - 2026-07-03 09:50:45 --> Language Class Initialized
INFO - 2026-07-03 09:50:45 --> Language Class Initialized
INFO - 2026-07-03 09:50:45 --> Config Class Initialized
INFO - 2026-07-03 09:50:45 --> Loader Class Initialized
INFO - 2026-07-03 09:50:45 --> Helper loaded: url_helper
INFO - 2026-07-03 09:50:45 --> Helper loaded: form_helper
INFO - 2026-07-03 09:50:45 --> Helper loaded: html_helper
INFO - 2026-07-03 09:50:45 --> Helper loaded: file_helper
INFO - 2026-07-03 09:50:45 --> Helper loaded: email_helper
INFO - 2026-07-03 09:50:45 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:50:45 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:50:45 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:50:45 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:50:45 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:50:45 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:50:45 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:50:45 --> Database Driver Class Initialized
INFO - 2026-07-03 09:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:50:47 --> Upload Class Initialized
DEBUG - 2026-07-03 09:50:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:50:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:50:47 --> Encryption Class Initialized
INFO - 2026-07-03 09:50:47 --> Form Validation Class Initialized
INFO - 2026-07-03 09:50:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:50:47 --> Pagination Class Initialized
INFO - 2026-07-03 09:50:47 --> Email Class Initialized
INFO - 2026-07-03 09:50:47 --> Controller Class Initialized
INFO - 2026-07-03 09:52:13 --> Config Class Initialized
INFO - 2026-07-03 09:52:13 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:52:13 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:52:13 --> Utf8 Class Initialized
INFO - 2026-07-03 09:52:13 --> URI Class Initialized
INFO - 2026-07-03 09:52:13 --> Router Class Initialized
INFO - 2026-07-03 09:52:13 --> Output Class Initialized
INFO - 2026-07-03 09:52:13 --> Security Class Initialized
DEBUG - 2026-07-03 09:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:52:13 --> CSRF cookie sent
INFO - 2026-07-03 09:52:13 --> Input Class Initialized
INFO - 2026-07-03 09:52:13 --> Language Class Initialized
INFO - 2026-07-03 09:52:13 --> Language Class Initialized
INFO - 2026-07-03 09:52:13 --> Config Class Initialized
INFO - 2026-07-03 09:52:13 --> Loader Class Initialized
INFO - 2026-07-03 09:52:13 --> Helper loaded: url_helper
INFO - 2026-07-03 09:52:13 --> Helper loaded: form_helper
INFO - 2026-07-03 09:52:13 --> Helper loaded: html_helper
INFO - 2026-07-03 09:52:13 --> Helper loaded: file_helper
INFO - 2026-07-03 09:52:13 --> Helper loaded: email_helper
INFO - 2026-07-03 09:52:13 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:52:13 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:52:13 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:52:13 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:52:13 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:52:13 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:52:13 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:52:13 --> Database Driver Class Initialized
INFO - 2026-07-03 09:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:52:15 --> Upload Class Initialized
DEBUG - 2026-07-03 09:52:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:52:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:52:15 --> Encryption Class Initialized
INFO - 2026-07-03 09:52:15 --> Form Validation Class Initialized
INFO - 2026-07-03 09:52:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:52:15 --> Pagination Class Initialized
INFO - 2026-07-03 09:52:15 --> Email Class Initialized
INFO - 2026-07-03 09:52:15 --> Controller Class Initialized
DEBUG - 2026-07-03 09:52:15 --> Swtest MX_Controller Initialized
INFO - 2026-07-03 09:52:15 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:52:15 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:52:15 --> Model "Cart_model" initialized
DEBUG - 2026-07-03 09:52:15 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 09:52:15 --> Model "Plan_model" initialized
INFO - 2026-07-03 09:52:15 --> Model "Order_model" initialized
INFO - 2026-07-03 09:52:15 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 09:52:15 --> Model "Invoice_model" initialized
INFO - 2026-07-03 09:52:15 --> Model "Provisioning_model" initialized
INFO - 2026-07-03 09:52:15 --> Model "Cronjob_model" initialized
INFO - 2026-07-03 09:52:15 --> Model "Common_model" initialized
INFO - 2026-07-03 09:52:25 --> Provisioning completed for invoice #563 - Total: 1, Success: 1, Failed: 0
INFO - 2026-07-03 09:52:25 --> provisionPaidServices completed for invoice #563 - Success: 1/1
INFO - 2026-07-03 09:52:35 --> Provisioning completed for invoice #564 - Total: 1, Success: 1, Failed: 0
INFO - 2026-07-03 09:52:35 --> provisionPaidServices completed for invoice #564 - Success: 1/1
INFO - 2026-07-03 09:52:38 --> Final output sent to browser
DEBUG - 2026-07-03 09:52:38 --> Total execution time: 25.8515
INFO - 2026-07-03 09:53:40 --> Config Class Initialized
INFO - 2026-07-03 09:53:40 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:53:40 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:53:40 --> Utf8 Class Initialized
INFO - 2026-07-03 09:53:40 --> URI Class Initialized
INFO - 2026-07-03 09:53:40 --> Router Class Initialized
INFO - 2026-07-03 09:53:40 --> Output Class Initialized
INFO - 2026-07-03 09:53:40 --> Security Class Initialized
DEBUG - 2026-07-03 09:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:53:40 --> CSRF cookie sent
INFO - 2026-07-03 09:53:40 --> Input Class Initialized
INFO - 2026-07-03 09:53:40 --> Language Class Initialized
INFO - 2026-07-03 09:53:40 --> Language Class Initialized
INFO - 2026-07-03 09:53:40 --> Config Class Initialized
INFO - 2026-07-03 09:53:40 --> Loader Class Initialized
INFO - 2026-07-03 09:53:40 --> Helper loaded: url_helper
INFO - 2026-07-03 09:53:40 --> Helper loaded: form_helper
INFO - 2026-07-03 09:53:40 --> Helper loaded: html_helper
INFO - 2026-07-03 09:53:40 --> Helper loaded: file_helper
INFO - 2026-07-03 09:53:40 --> Helper loaded: email_helper
INFO - 2026-07-03 09:53:40 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:53:40 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:53:40 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:53:40 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:53:40 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:53:40 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:53:40 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:53:40 --> Database Driver Class Initialized
INFO - 2026-07-03 09:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:53:42 --> Upload Class Initialized
DEBUG - 2026-07-03 09:53:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:53:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:53:42 --> Encryption Class Initialized
INFO - 2026-07-03 09:53:42 --> Form Validation Class Initialized
INFO - 2026-07-03 09:53:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:53:42 --> Pagination Class Initialized
INFO - 2026-07-03 09:53:42 --> Email Class Initialized
INFO - 2026-07-03 09:53:42 --> Controller Class Initialized
ERROR - 2026-07-03 09:53:42 --> 404 Page Not Found: /index
INFO - 2026-07-03 09:55:23 --> Config Class Initialized
INFO - 2026-07-03 09:55:23 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:55:23 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:55:23 --> Utf8 Class Initialized
INFO - 2026-07-03 09:55:23 --> URI Class Initialized
INFO - 2026-07-03 09:55:23 --> Router Class Initialized
INFO - 2026-07-03 09:55:23 --> Output Class Initialized
INFO - 2026-07-03 09:55:23 --> Security Class Initialized
DEBUG - 2026-07-03 09:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:55:23 --> CSRF cookie sent
INFO - 2026-07-03 09:55:23 --> Input Class Initialized
INFO - 2026-07-03 09:55:23 --> Language Class Initialized
INFO - 2026-07-03 09:55:23 --> Language Class Initialized
INFO - 2026-07-03 09:55:23 --> Config Class Initialized
INFO - 2026-07-03 09:55:23 --> Loader Class Initialized
INFO - 2026-07-03 09:55:23 --> Helper loaded: url_helper
INFO - 2026-07-03 09:55:23 --> Helper loaded: form_helper
INFO - 2026-07-03 09:55:23 --> Helper loaded: html_helper
INFO - 2026-07-03 09:55:23 --> Helper loaded: file_helper
INFO - 2026-07-03 09:55:23 --> Helper loaded: email_helper
INFO - 2026-07-03 09:55:23 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:55:23 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:55:23 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:55:23 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:55:23 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:55:23 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:55:23 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:55:23 --> Database Driver Class Initialized
INFO - 2026-07-03 09:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:55:25 --> Upload Class Initialized
DEBUG - 2026-07-03 09:55:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:55:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:55:25 --> Encryption Class Initialized
INFO - 2026-07-03 09:55:25 --> Form Validation Class Initialized
INFO - 2026-07-03 09:55:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:55:25 --> Pagination Class Initialized
INFO - 2026-07-03 09:55:25 --> Email Class Initialized
INFO - 2026-07-03 09:55:25 --> Controller Class Initialized
DEBUG - 2026-07-03 09:55:25 --> Cart MX_Controller Initialized
INFO - 2026-07-03 09:55:25 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:55:25 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:55:25 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:55:25 --> Model "Common_model" initialized
INFO - 2026-07-03 09:55:25 --> Model "Order_model" initialized
INFO - 2026-07-03 09:55:25 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 09:55:25 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 09:55:25 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 09:55:25 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 09:55:25 --> Model "Plan_model" initialized
INFO - 2026-07-03 09:55:25 --> Model "Orderlicense_model" initialized
DEBUG - 2026-07-03 09:55:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 09:55:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-07-03 09:55:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-07-03 09:55:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 09:55:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 09:55:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/cart_services.php
INFO - 2026-07-03 09:55:26 --> Final output sent to browser
DEBUG - 2026-07-03 09:55:26 --> Total execution time: 3.6847
INFO - 2026-07-03 09:55:26 --> Config Class Initialized
INFO - 2026-07-03 09:55:26 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:55:26 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:55:26 --> Utf8 Class Initialized
INFO - 2026-07-03 09:55:26 --> URI Class Initialized
INFO - 2026-07-03 09:55:26 --> Router Class Initialized
INFO - 2026-07-03 09:55:26 --> Output Class Initialized
INFO - 2026-07-03 09:55:26 --> Security Class Initialized
DEBUG - 2026-07-03 09:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:55:26 --> CSRF cookie sent
INFO - 2026-07-03 09:55:26 --> Input Class Initialized
INFO - 2026-07-03 09:55:26 --> Language Class Initialized
INFO - 2026-07-03 09:55:26 --> Language Class Initialized
INFO - 2026-07-03 09:55:26 --> Config Class Initialized
INFO - 2026-07-03 09:55:26 --> Loader Class Initialized
INFO - 2026-07-03 09:55:26 --> Helper loaded: url_helper
INFO - 2026-07-03 09:55:26 --> Helper loaded: form_helper
INFO - 2026-07-03 09:55:26 --> Helper loaded: html_helper
INFO - 2026-07-03 09:55:26 --> Helper loaded: file_helper
INFO - 2026-07-03 09:55:26 --> Helper loaded: email_helper
INFO - 2026-07-03 09:55:26 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:55:26 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:55:26 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:55:26 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:55:26 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:55:26 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:55:26 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:55:26 --> Database Driver Class Initialized
INFO - 2026-07-03 09:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:55:28 --> Upload Class Initialized
DEBUG - 2026-07-03 09:55:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:55:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:55:28 --> Encryption Class Initialized
INFO - 2026-07-03 09:55:28 --> Form Validation Class Initialized
INFO - 2026-07-03 09:55:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:55:28 --> Pagination Class Initialized
INFO - 2026-07-03 09:55:28 --> Email Class Initialized
INFO - 2026-07-03 09:55:28 --> Controller Class Initialized
DEBUG - 2026-07-03 09:55:28 --> Cart MX_Controller Initialized
INFO - 2026-07-03 09:55:28 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:55:28 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:55:28 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:55:28 --> Model "Common_model" initialized
INFO - 2026-07-03 09:55:28 --> Model "Order_model" initialized
INFO - 2026-07-03 09:55:28 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 09:55:28 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 09:55:28 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 09:55:28 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 09:55:28 --> Model "Plan_model" initialized
INFO - 2026-07-03 09:55:28 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 09:55:29 --> Final output sent to browser
DEBUG - 2026-07-03 09:55:29 --> Total execution time: 2.3924
INFO - 2026-07-03 09:55:29 --> Config Class Initialized
INFO - 2026-07-03 09:55:29 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:55:29 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:55:29 --> Utf8 Class Initialized
INFO - 2026-07-03 09:55:29 --> URI Class Initialized
INFO - 2026-07-03 09:55:29 --> Router Class Initialized
INFO - 2026-07-03 09:55:29 --> Output Class Initialized
INFO - 2026-07-03 09:55:29 --> Security Class Initialized
DEBUG - 2026-07-03 09:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:55:29 --> CSRF cookie sent
INFO - 2026-07-03 09:55:29 --> Input Class Initialized
INFO - 2026-07-03 09:55:29 --> Language Class Initialized
INFO - 2026-07-03 09:55:29 --> Language Class Initialized
INFO - 2026-07-03 09:55:29 --> Config Class Initialized
INFO - 2026-07-03 09:55:29 --> Loader Class Initialized
INFO - 2026-07-03 09:55:29 --> Helper loaded: url_helper
INFO - 2026-07-03 09:55:29 --> Helper loaded: form_helper
INFO - 2026-07-03 09:55:29 --> Helper loaded: html_helper
INFO - 2026-07-03 09:55:29 --> Helper loaded: file_helper
INFO - 2026-07-03 09:55:29 --> Helper loaded: email_helper
INFO - 2026-07-03 09:55:29 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:55:29 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:55:29 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:55:29 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:55:29 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:55:29 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:55:29 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:55:29 --> Database Driver Class Initialized
INFO - 2026-07-03 09:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:55:31 --> Upload Class Initialized
DEBUG - 2026-07-03 09:55:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:55:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:55:31 --> Encryption Class Initialized
INFO - 2026-07-03 09:55:31 --> Form Validation Class Initialized
INFO - 2026-07-03 09:55:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:55:31 --> Pagination Class Initialized
INFO - 2026-07-03 09:55:31 --> Email Class Initialized
INFO - 2026-07-03 09:55:31 --> Controller Class Initialized
DEBUG - 2026-07-03 09:55:31 --> Cart MX_Controller Initialized
INFO - 2026-07-03 09:55:31 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:55:31 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:55:31 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:55:31 --> Model "Common_model" initialized
INFO - 2026-07-03 09:55:31 --> Model "Order_model" initialized
INFO - 2026-07-03 09:55:31 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 09:55:31 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 09:55:31 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 09:55:31 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 09:55:31 --> Model "Plan_model" initialized
INFO - 2026-07-03 09:55:31 --> Model "Orderlicense_model" initialized
DEBUG - 2026-07-03 09:55:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 09:55:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 09:55:33 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/cart_software.php
INFO - 2026-07-03 09:55:33 --> Final output sent to browser
DEBUG - 2026-07-03 09:55:33 --> Total execution time: 3.9520
INFO - 2026-07-03 09:56:53 --> Config Class Initialized
INFO - 2026-07-03 09:56:53 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:56:53 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:56:53 --> Utf8 Class Initialized
INFO - 2026-07-03 09:56:53 --> URI Class Initialized
INFO - 2026-07-03 09:56:53 --> Router Class Initialized
INFO - 2026-07-03 09:56:53 --> Output Class Initialized
INFO - 2026-07-03 09:56:53 --> Security Class Initialized
DEBUG - 2026-07-03 09:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:56:53 --> Input Class Initialized
INFO - 2026-07-03 09:56:53 --> Language Class Initialized
INFO - 2026-07-03 09:56:53 --> Language Class Initialized
INFO - 2026-07-03 09:56:53 --> Config Class Initialized
INFO - 2026-07-03 09:56:53 --> Loader Class Initialized
INFO - 2026-07-03 09:56:53 --> Helper loaded: url_helper
INFO - 2026-07-03 09:56:53 --> Helper loaded: form_helper
INFO - 2026-07-03 09:56:53 --> Helper loaded: html_helper
INFO - 2026-07-03 09:56:53 --> Helper loaded: file_helper
INFO - 2026-07-03 09:56:53 --> Helper loaded: email_helper
INFO - 2026-07-03 09:56:53 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:56:53 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:56:53 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:56:53 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:56:53 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:56:53 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:56:53 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:56:53 --> Database Driver Class Initialized
INFO - 2026-07-03 09:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:56:55 --> Upload Class Initialized
DEBUG - 2026-07-03 09:56:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:56:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:56:55 --> Encryption Class Initialized
INFO - 2026-07-03 09:56:55 --> Form Validation Class Initialized
INFO - 2026-07-03 09:56:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:56:55 --> Pagination Class Initialized
INFO - 2026-07-03 09:56:55 --> Email Class Initialized
INFO - 2026-07-03 09:56:55 --> Controller Class Initialized
DEBUG - 2026-07-03 09:56:55 --> Cart MX_Controller Initialized
INFO - 2026-07-03 09:56:55 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:56:55 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:56:55 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:56:55 --> Model "Common_model" initialized
INFO - 2026-07-03 09:56:55 --> Model "Order_model" initialized
INFO - 2026-07-03 09:56:55 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 09:56:55 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 09:56:55 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 09:56:55 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 09:56:55 --> Model "Plan_model" initialized
INFO - 2026-07-03 09:56:55 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 09:56:55 --> Final output sent to browser
DEBUG - 2026-07-03 09:56:55 --> Total execution time: 2.8001
INFO - 2026-07-03 09:56:55 --> Config Class Initialized
INFO - 2026-07-03 09:56:55 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:56:55 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:56:55 --> Utf8 Class Initialized
INFO - 2026-07-03 09:56:55 --> URI Class Initialized
INFO - 2026-07-03 09:56:55 --> Router Class Initialized
INFO - 2026-07-03 09:56:55 --> Output Class Initialized
INFO - 2026-07-03 09:56:55 --> Security Class Initialized
DEBUG - 2026-07-03 09:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:56:55 --> CSRF cookie sent
INFO - 2026-07-03 09:56:55 --> Input Class Initialized
INFO - 2026-07-03 09:56:55 --> Language Class Initialized
INFO - 2026-07-03 09:56:55 --> Language Class Initialized
INFO - 2026-07-03 09:56:55 --> Config Class Initialized
INFO - 2026-07-03 09:56:55 --> Loader Class Initialized
INFO - 2026-07-03 09:56:55 --> Helper loaded: url_helper
INFO - 2026-07-03 09:56:55 --> Helper loaded: form_helper
INFO - 2026-07-03 09:56:55 --> Helper loaded: html_helper
INFO - 2026-07-03 09:56:55 --> Helper loaded: file_helper
INFO - 2026-07-03 09:56:55 --> Helper loaded: email_helper
INFO - 2026-07-03 09:56:55 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:56:55 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:56:55 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:56:55 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:56:55 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:56:55 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:56:55 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:56:55 --> Database Driver Class Initialized
INFO - 2026-07-03 09:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:56:58 --> Upload Class Initialized
DEBUG - 2026-07-03 09:56:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:56:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:56:58 --> Encryption Class Initialized
INFO - 2026-07-03 09:56:58 --> Form Validation Class Initialized
INFO - 2026-07-03 09:56:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:56:58 --> Pagination Class Initialized
INFO - 2026-07-03 09:56:58 --> Email Class Initialized
INFO - 2026-07-03 09:56:58 --> Controller Class Initialized
DEBUG - 2026-07-03 09:56:58 --> Cart MX_Controller Initialized
INFO - 2026-07-03 09:56:58 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:56:58 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:56:58 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:56:58 --> Model "Common_model" initialized
INFO - 2026-07-03 09:56:58 --> Model "Order_model" initialized
INFO - 2026-07-03 09:56:58 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 09:56:58 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 09:56:58 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 09:56:58 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 09:56:58 --> Model "Plan_model" initialized
INFO - 2026-07-03 09:56:58 --> Model "Orderlicense_model" initialized
DEBUG - 2026-07-03 09:57:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 09:57:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-07-03 09:57:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-07-03 09:57:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 09:57:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 09:57:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/view_card.php
INFO - 2026-07-03 09:57:02 --> Final output sent to browser
DEBUG - 2026-07-03 09:57:02 --> Total execution time: 6.2294
INFO - 2026-07-03 09:57:02 --> Config Class Initialized
INFO - 2026-07-03 09:57:02 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:57:02 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:57:02 --> Utf8 Class Initialized
INFO - 2026-07-03 09:57:02 --> URI Class Initialized
INFO - 2026-07-03 09:57:02 --> Router Class Initialized
INFO - 2026-07-03 09:57:02 --> Output Class Initialized
INFO - 2026-07-03 09:57:02 --> Security Class Initialized
DEBUG - 2026-07-03 09:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:57:02 --> CSRF cookie sent
INFO - 2026-07-03 09:57:02 --> Input Class Initialized
INFO - 2026-07-03 09:57:02 --> Language Class Initialized
INFO - 2026-07-03 09:57:02 --> Language Class Initialized
INFO - 2026-07-03 09:57:02 --> Config Class Initialized
INFO - 2026-07-03 09:57:02 --> Loader Class Initialized
INFO - 2026-07-03 09:57:02 --> Helper loaded: url_helper
INFO - 2026-07-03 09:57:02 --> Helper loaded: form_helper
INFO - 2026-07-03 09:57:02 --> Helper loaded: html_helper
INFO - 2026-07-03 09:57:02 --> Helper loaded: file_helper
INFO - 2026-07-03 09:57:02 --> Helper loaded: email_helper
INFO - 2026-07-03 09:57:02 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:57:02 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:57:02 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:57:02 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:57:02 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:57:02 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:57:02 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:57:02 --> Database Driver Class Initialized
INFO - 2026-07-03 09:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:57:04 --> Upload Class Initialized
DEBUG - 2026-07-03 09:57:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:57:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:57:04 --> Encryption Class Initialized
INFO - 2026-07-03 09:57:04 --> Form Validation Class Initialized
INFO - 2026-07-03 09:57:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:57:04 --> Pagination Class Initialized
INFO - 2026-07-03 09:57:04 --> Email Class Initialized
INFO - 2026-07-03 09:57:04 --> Controller Class Initialized
DEBUG - 2026-07-03 09:57:04 --> Cart MX_Controller Initialized
INFO - 2026-07-03 09:57:04 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:57:04 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:57:04 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:57:04 --> Model "Common_model" initialized
INFO - 2026-07-03 09:57:04 --> Model "Order_model" initialized
INFO - 2026-07-03 09:57:04 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 09:57:04 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 09:57:04 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 09:57:04 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 09:57:04 --> Model "Plan_model" initialized
INFO - 2026-07-03 09:57:04 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 09:57:04 --> Final output sent to browser
DEBUG - 2026-07-03 09:57:04 --> Total execution time: 2.4030
INFO - 2026-07-03 09:57:50 --> Config Class Initialized
INFO - 2026-07-03 09:57:50 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:57:50 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:57:50 --> Utf8 Class Initialized
INFO - 2026-07-03 09:57:50 --> URI Class Initialized
INFO - 2026-07-03 09:57:50 --> Router Class Initialized
INFO - 2026-07-03 09:57:50 --> Output Class Initialized
INFO - 2026-07-03 09:57:50 --> Security Class Initialized
DEBUG - 2026-07-03 09:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:57:50 --> Input Class Initialized
INFO - 2026-07-03 09:57:50 --> Language Class Initialized
INFO - 2026-07-03 09:57:50 --> Language Class Initialized
INFO - 2026-07-03 09:57:50 --> Config Class Initialized
INFO - 2026-07-03 09:57:50 --> Loader Class Initialized
INFO - 2026-07-03 09:57:50 --> Helper loaded: url_helper
INFO - 2026-07-03 09:57:50 --> Helper loaded: form_helper
INFO - 2026-07-03 09:57:50 --> Helper loaded: html_helper
INFO - 2026-07-03 09:57:50 --> Helper loaded: file_helper
INFO - 2026-07-03 09:57:50 --> Helper loaded: email_helper
INFO - 2026-07-03 09:57:50 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:57:50 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:57:50 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:57:50 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:57:50 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:57:50 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:57:50 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:57:50 --> Database Driver Class Initialized
INFO - 2026-07-03 09:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:57:51 --> Upload Class Initialized
DEBUG - 2026-07-03 09:57:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:57:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:57:51 --> Encryption Class Initialized
INFO - 2026-07-03 09:57:51 --> Form Validation Class Initialized
INFO - 2026-07-03 09:57:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:57:51 --> Pagination Class Initialized
INFO - 2026-07-03 09:57:51 --> Email Class Initialized
INFO - 2026-07-03 09:57:51 --> Controller Class Initialized
DEBUG - 2026-07-03 09:57:51 --> Cart MX_Controller Initialized
INFO - 2026-07-03 09:57:51 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:57:51 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:57:51 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:57:51 --> Model "Common_model" initialized
INFO - 2026-07-03 09:57:51 --> Model "Order_model" initialized
INFO - 2026-07-03 09:57:51 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 09:57:51 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 09:57:51 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 09:57:51 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 09:57:51 --> Model "Plan_model" initialized
INFO - 2026-07-03 09:57:51 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 09:57:51 --> Final output sent to browser
DEBUG - 2026-07-03 09:57:51 --> Total execution time: 1.9137
INFO - 2026-07-03 09:57:52 --> Config Class Initialized
INFO - 2026-07-03 09:57:52 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:57:52 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:57:52 --> Utf8 Class Initialized
INFO - 2026-07-03 09:57:52 --> URI Class Initialized
INFO - 2026-07-03 09:57:52 --> Router Class Initialized
INFO - 2026-07-03 09:57:52 --> Output Class Initialized
INFO - 2026-07-03 09:57:52 --> Security Class Initialized
DEBUG - 2026-07-03 09:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:57:52 --> CSRF cookie sent
INFO - 2026-07-03 09:57:52 --> Input Class Initialized
INFO - 2026-07-03 09:57:52 --> Language Class Initialized
INFO - 2026-07-03 09:57:52 --> Language Class Initialized
INFO - 2026-07-03 09:57:52 --> Config Class Initialized
INFO - 2026-07-03 09:57:52 --> Loader Class Initialized
INFO - 2026-07-03 09:57:52 --> Helper loaded: url_helper
INFO - 2026-07-03 09:57:52 --> Helper loaded: form_helper
INFO - 2026-07-03 09:57:52 --> Helper loaded: html_helper
INFO - 2026-07-03 09:57:52 --> Helper loaded: file_helper
INFO - 2026-07-03 09:57:52 --> Helper loaded: email_helper
INFO - 2026-07-03 09:57:52 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:57:52 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:57:52 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:57:52 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:57:52 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:57:52 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:57:52 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:57:52 --> Database Driver Class Initialized
INFO - 2026-07-03 09:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:57:54 --> Upload Class Initialized
DEBUG - 2026-07-03 09:57:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:57:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:57:54 --> Encryption Class Initialized
INFO - 2026-07-03 09:57:54 --> Form Validation Class Initialized
INFO - 2026-07-03 09:57:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:57:54 --> Pagination Class Initialized
INFO - 2026-07-03 09:57:54 --> Email Class Initialized
INFO - 2026-07-03 09:57:54 --> Controller Class Initialized
DEBUG - 2026-07-03 09:57:54 --> Auth MX_Controller Initialized
INFO - 2026-07-03 09:57:54 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:57:54 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:57:54 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:57:54 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-03 09:57:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 09:57:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 09:57:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 09:57:54 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-07-03 09:57:54 --> Final output sent to browser
DEBUG - 2026-07-03 09:57:54 --> Total execution time: 2.0185
INFO - 2026-07-03 09:57:54 --> Config Class Initialized
INFO - 2026-07-03 09:57:54 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:57:54 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:57:54 --> Utf8 Class Initialized
INFO - 2026-07-03 09:57:54 --> URI Class Initialized
INFO - 2026-07-03 09:57:54 --> Router Class Initialized
INFO - 2026-07-03 09:57:54 --> Output Class Initialized
INFO - 2026-07-03 09:57:54 --> Security Class Initialized
DEBUG - 2026-07-03 09:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:57:54 --> CSRF cookie sent
INFO - 2026-07-03 09:57:54 --> Input Class Initialized
INFO - 2026-07-03 09:57:54 --> Language Class Initialized
INFO - 2026-07-03 09:57:54 --> Language Class Initialized
INFO - 2026-07-03 09:57:54 --> Config Class Initialized
INFO - 2026-07-03 09:57:54 --> Loader Class Initialized
INFO - 2026-07-03 09:57:54 --> Helper loaded: url_helper
INFO - 2026-07-03 09:57:54 --> Helper loaded: form_helper
INFO - 2026-07-03 09:57:54 --> Helper loaded: html_helper
INFO - 2026-07-03 09:57:54 --> Helper loaded: file_helper
INFO - 2026-07-03 09:57:54 --> Helper loaded: email_helper
INFO - 2026-07-03 09:57:54 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:57:54 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:57:54 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:57:54 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:57:54 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:57:54 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:57:54 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:57:54 --> Database Driver Class Initialized
INFO - 2026-07-03 09:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:57:56 --> Upload Class Initialized
DEBUG - 2026-07-03 09:57:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:57:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:57:56 --> Encryption Class Initialized
INFO - 2026-07-03 09:57:56 --> Form Validation Class Initialized
INFO - 2026-07-03 09:57:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:57:56 --> Pagination Class Initialized
INFO - 2026-07-03 09:57:56 --> Email Class Initialized
INFO - 2026-07-03 09:57:56 --> Controller Class Initialized
DEBUG - 2026-07-03 09:57:56 --> Cart MX_Controller Initialized
INFO - 2026-07-03 09:57:56 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:57:56 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:57:56 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:57:56 --> Model "Common_model" initialized
INFO - 2026-07-03 09:57:56 --> Model "Order_model" initialized
INFO - 2026-07-03 09:57:56 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 09:57:56 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 09:57:56 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 09:57:56 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 09:57:56 --> Model "Plan_model" initialized
INFO - 2026-07-03 09:57:56 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 09:57:56 --> Final output sent to browser
DEBUG - 2026-07-03 09:57:56 --> Total execution time: 2.2546
INFO - 2026-07-03 09:58:01 --> Config Class Initialized
INFO - 2026-07-03 09:58:01 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:58:01 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:58:01 --> Utf8 Class Initialized
INFO - 2026-07-03 09:58:01 --> URI Class Initialized
INFO - 2026-07-03 09:58:01 --> Router Class Initialized
INFO - 2026-07-03 09:58:01 --> Output Class Initialized
INFO - 2026-07-03 09:58:01 --> Security Class Initialized
DEBUG - 2026-07-03 09:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:58:01 --> CSRF cookie sent
INFO - 2026-07-03 09:58:01 --> CSRF token verified
INFO - 2026-07-03 09:58:01 --> Input Class Initialized
INFO - 2026-07-03 09:58:01 --> Language Class Initialized
INFO - 2026-07-03 09:58:01 --> Language Class Initialized
INFO - 2026-07-03 09:58:01 --> Config Class Initialized
INFO - 2026-07-03 09:58:01 --> Loader Class Initialized
INFO - 2026-07-03 09:58:01 --> Helper loaded: url_helper
INFO - 2026-07-03 09:58:01 --> Helper loaded: form_helper
INFO - 2026-07-03 09:58:01 --> Helper loaded: html_helper
INFO - 2026-07-03 09:58:01 --> Helper loaded: file_helper
INFO - 2026-07-03 09:58:01 --> Helper loaded: email_helper
INFO - 2026-07-03 09:58:01 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:58:01 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:58:01 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:58:01 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:58:01 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:58:01 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:58:01 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:58:01 --> Database Driver Class Initialized
INFO - 2026-07-03 09:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:58:03 --> Upload Class Initialized
DEBUG - 2026-07-03 09:58:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:58:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:58:03 --> Encryption Class Initialized
INFO - 2026-07-03 09:58:03 --> Form Validation Class Initialized
INFO - 2026-07-03 09:58:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:58:03 --> Pagination Class Initialized
INFO - 2026-07-03 09:58:03 --> Email Class Initialized
INFO - 2026-07-03 09:58:03 --> Controller Class Initialized
DEBUG - 2026-07-03 09:58:03 --> Auth MX_Controller Initialized
INFO - 2026-07-03 09:58:03 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:58:03 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:58:03 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:58:03 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 09:58:06 --> Config Class Initialized
INFO - 2026-07-03 09:58:06 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:58:06 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:58:06 --> Utf8 Class Initialized
INFO - 2026-07-03 09:58:06 --> URI Class Initialized
INFO - 2026-07-03 09:58:06 --> Router Class Initialized
INFO - 2026-07-03 09:58:06 --> Output Class Initialized
INFO - 2026-07-03 09:58:06 --> Security Class Initialized
DEBUG - 2026-07-03 09:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:58:06 --> CSRF cookie sent
INFO - 2026-07-03 09:58:06 --> Input Class Initialized
INFO - 2026-07-03 09:58:06 --> Language Class Initialized
INFO - 2026-07-03 09:58:06 --> Language Class Initialized
INFO - 2026-07-03 09:58:06 --> Config Class Initialized
INFO - 2026-07-03 09:58:06 --> Loader Class Initialized
INFO - 2026-07-03 09:58:06 --> Helper loaded: url_helper
INFO - 2026-07-03 09:58:06 --> Helper loaded: form_helper
INFO - 2026-07-03 09:58:06 --> Helper loaded: html_helper
INFO - 2026-07-03 09:58:06 --> Helper loaded: file_helper
INFO - 2026-07-03 09:58:06 --> Helper loaded: email_helper
INFO - 2026-07-03 09:58:06 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:58:06 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:58:06 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:58:06 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:58:06 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:58:06 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:58:06 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:58:06 --> Database Driver Class Initialized
INFO - 2026-07-03 09:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:58:08 --> Upload Class Initialized
DEBUG - 2026-07-03 09:58:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:58:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:58:08 --> Encryption Class Initialized
INFO - 2026-07-03 09:58:08 --> Form Validation Class Initialized
INFO - 2026-07-03 09:58:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:58:08 --> Pagination Class Initialized
INFO - 2026-07-03 09:58:08 --> Email Class Initialized
INFO - 2026-07-03 09:58:08 --> Controller Class Initialized
DEBUG - 2026-07-03 09:58:08 --> Clientarea MX_Controller Initialized
INFO - 2026-07-03 09:58:08 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:58:08 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:58:08 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:58:08 --> Model "Clientarea_model" initialized
INFO - 2026-07-03 09:58:08 --> Model "Billing_model" initialized
INFO - 2026-07-03 09:58:08 --> Model "Common_model" initialized
INFO - 2026-07-03 09:58:08 --> Model "Order_model" initialized
INFO - 2026-07-03 09:58:08 --> Model "Support_model" initialized
INFO - 2026-07-03 09:58:08 --> Model "Subscription_model" initialized
INFO - 2026-07-03 09:58:08 --> Model "Software_model" initialized
DEBUG - 2026-07-03 09:58:09 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 09:58:09 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 09:58:09 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 09:58:09 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_index.php
INFO - 2026-07-03 09:58:09 --> Final output sent to browser
DEBUG - 2026-07-03 09:58:09 --> Total execution time: 3.0630
INFO - 2026-07-03 09:58:09 --> Config Class Initialized
INFO - 2026-07-03 09:58:09 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:58:09 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:58:09 --> Utf8 Class Initialized
INFO - 2026-07-03 09:58:09 --> URI Class Initialized
INFO - 2026-07-03 09:58:09 --> Router Class Initialized
INFO - 2026-07-03 09:58:09 --> Output Class Initialized
INFO - 2026-07-03 09:58:09 --> Security Class Initialized
DEBUG - 2026-07-03 09:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:58:09 --> CSRF cookie sent
INFO - 2026-07-03 09:58:09 --> Input Class Initialized
INFO - 2026-07-03 09:58:09 --> Language Class Initialized
INFO - 2026-07-03 09:58:09 --> Language Class Initialized
INFO - 2026-07-03 09:58:09 --> Config Class Initialized
INFO - 2026-07-03 09:58:09 --> Loader Class Initialized
INFO - 2026-07-03 09:58:09 --> Helper loaded: url_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: form_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: html_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: file_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: email_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:58:09 --> Config Class Initialized
INFO - 2026-07-03 09:58:09 --> Hooks Class Initialized
INFO - 2026-07-03 09:58:09 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: directadmin_helper
DEBUG - 2026-07-03 09:58:09 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:58:09 --> Utf8 Class Initialized
INFO - 2026-07-03 09:58:09 --> URI Class Initialized
INFO - 2026-07-03 09:58:09 --> Config Class Initialized
INFO - 2026-07-03 09:58:09 --> Hooks Class Initialized
INFO - 2026-07-03 09:58:09 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:58:09 --> Router Class Initialized
INFO - 2026-07-03 09:58:09 --> Helper loaded: entitlement_helper
DEBUG - 2026-07-03 09:58:09 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:58:09 --> Utf8 Class Initialized
INFO - 2026-07-03 09:58:09 --> URI Class Initialized
INFO - 2026-07-03 09:58:09 --> Config Class Initialized
INFO - 2026-07-03 09:58:09 --> Hooks Class Initialized
INFO - 2026-07-03 09:58:09 --> Output Class Initialized
INFO - 2026-07-03 09:58:09 --> Router Class Initialized
INFO - 2026-07-03 09:58:09 --> Security Class Initialized
DEBUG - 2026-07-03 09:58:09 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:58:09 --> Utf8 Class Initialized
INFO - 2026-07-03 09:58:09 --> URI Class Initialized
INFO - 2026-07-03 09:58:09 --> Output Class Initialized
DEBUG - 2026-07-03 09:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:58:09 --> Input Class Initialized
INFO - 2026-07-03 09:58:09 --> Language Class Initialized
INFO - 2026-07-03 09:58:09 --> Security Class Initialized
INFO - 2026-07-03 09:58:09 --> Language Class Initialized
INFO - 2026-07-03 09:58:09 --> Config Class Initialized
INFO - 2026-07-03 09:58:09 --> Router Class Initialized
DEBUG - 2026-07-03 09:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:58:09 --> Input Class Initialized
INFO - 2026-07-03 09:58:09 --> Language Class Initialized
INFO - 2026-07-03 09:58:09 --> Database Driver Class Initialized
INFO - 2026-07-03 09:58:09 --> Output Class Initialized
INFO - 2026-07-03 09:58:09 --> Language Class Initialized
INFO - 2026-07-03 09:58:09 --> Config Class Initialized
INFO - 2026-07-03 09:58:09 --> Security Class Initialized
INFO - 2026-07-03 09:58:09 --> Loader Class Initialized
DEBUG - 2026-07-03 09:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:58:09 --> Input Class Initialized
INFO - 2026-07-03 09:58:09 --> Helper loaded: url_helper
INFO - 2026-07-03 09:58:09 --> Loader Class Initialized
INFO - 2026-07-03 09:58:09 --> Language Class Initialized
INFO - 2026-07-03 09:58:09 --> Helper loaded: url_helper
INFO - 2026-07-03 09:58:09 --> Language Class Initialized
INFO - 2026-07-03 09:58:09 --> Config Class Initialized
INFO - 2026-07-03 09:58:09 --> Helper loaded: form_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: html_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: form_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: file_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: html_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: email_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: file_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: email_helper
INFO - 2026-07-03 09:58:09 --> Loader Class Initialized
INFO - 2026-07-03 09:58:09 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: url_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: form_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: html_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: file_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: email_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:58:09 --> Database Driver Class Initialized
INFO - 2026-07-03 09:58:09 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:58:09 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:58:09 --> Database Driver Class Initialized
INFO - 2026-07-03 09:58:09 --> Database Driver Class Initialized
INFO - 2026-07-03 09:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:58:11 --> Upload Class Initialized
DEBUG - 2026-07-03 09:58:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:58:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:58:11 --> Encryption Class Initialized
INFO - 2026-07-03 09:58:11 --> Form Validation Class Initialized
INFO - 2026-07-03 09:58:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:58:11 --> Pagination Class Initialized
INFO - 2026-07-03 09:58:11 --> Email Class Initialized
INFO - 2026-07-03 09:58:11 --> Controller Class Initialized
DEBUG - 2026-07-03 09:58:11 --> Clientarea MX_Controller Initialized
INFO - 2026-07-03 09:58:11 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:58:11 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:58:11 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:58:11 --> Model "Clientarea_model" initialized
INFO - 2026-07-03 09:58:11 --> Model "Billing_model" initialized
INFO - 2026-07-03 09:58:11 --> Model "Common_model" initialized
INFO - 2026-07-03 09:58:11 --> Model "Order_model" initialized
INFO - 2026-07-03 09:58:11 --> Model "Support_model" initialized
INFO - 2026-07-03 09:58:12 --> Final output sent to browser
DEBUG - 2026-07-03 09:58:12 --> Total execution time: 2.4529
INFO - 2026-07-03 09:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:58:12 --> Upload Class Initialized
DEBUG - 2026-07-03 09:58:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:58:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:58:12 --> Encryption Class Initialized
INFO - 2026-07-03 09:58:12 --> Form Validation Class Initialized
INFO - 2026-07-03 09:58:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:58:12 --> Pagination Class Initialized
INFO - 2026-07-03 09:58:12 --> Email Class Initialized
INFO - 2026-07-03 09:58:12 --> Controller Class Initialized
DEBUG - 2026-07-03 09:58:12 --> Tickets MX_Controller Initialized
INFO - 2026-07-03 09:58:12 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:58:12 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:58:12 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:58:12 --> Model "Support_model" initialized
INFO - 2026-07-03 09:58:12 --> Model "Common_model" initialized
INFO - 2026-07-03 09:58:12 --> Final output sent to browser
DEBUG - 2026-07-03 09:58:12 --> Total execution time: 3.2776
INFO - 2026-07-03 09:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:58:12 --> Upload Class Initialized
DEBUG - 2026-07-03 09:58:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:58:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:58:12 --> Encryption Class Initialized
INFO - 2026-07-03 09:58:12 --> Form Validation Class Initialized
INFO - 2026-07-03 09:58:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:58:12 --> Pagination Class Initialized
INFO - 2026-07-03 09:58:12 --> Email Class Initialized
INFO - 2026-07-03 09:58:12 --> Controller Class Initialized
DEBUG - 2026-07-03 09:58:12 --> Cart MX_Controller Initialized
INFO - 2026-07-03 09:58:12 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:58:12 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:58:12 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:58:12 --> Model "Common_model" initialized
INFO - 2026-07-03 09:58:12 --> Model "Order_model" initialized
INFO - 2026-07-03 09:58:12 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 09:58:12 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 09:58:12 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 09:58:12 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 09:58:12 --> Model "Plan_model" initialized
INFO - 2026-07-03 09:58:12 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 09:58:13 --> Final output sent to browser
DEBUG - 2026-07-03 09:58:13 --> Total execution time: 3.6894
INFO - 2026-07-03 09:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:58:13 --> Upload Class Initialized
DEBUG - 2026-07-03 09:58:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:58:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:58:13 --> Encryption Class Initialized
INFO - 2026-07-03 09:58:13 --> Form Validation Class Initialized
INFO - 2026-07-03 09:58:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:58:13 --> Pagination Class Initialized
INFO - 2026-07-03 09:58:13 --> Email Class Initialized
INFO - 2026-07-03 09:58:13 --> Controller Class Initialized
DEBUG - 2026-07-03 09:58:13 --> Billing MX_Controller Initialized
INFO - 2026-07-03 09:58:13 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:58:13 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:58:13 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:58:13 --> Model "Billing_model" initialized
INFO - 2026-07-03 09:58:13 --> Model "Common_model" initialized
INFO - 2026-07-03 09:58:13 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 09:58:13 --> Final output sent to browser
DEBUG - 2026-07-03 09:58:13 --> Total execution time: 4.2883
INFO - 2026-07-03 09:58:19 --> Config Class Initialized
INFO - 2026-07-03 09:58:19 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:58:19 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:58:19 --> Utf8 Class Initialized
INFO - 2026-07-03 09:58:19 --> URI Class Initialized
INFO - 2026-07-03 09:58:19 --> Router Class Initialized
INFO - 2026-07-03 09:58:19 --> Output Class Initialized
INFO - 2026-07-03 09:58:19 --> Security Class Initialized
DEBUG - 2026-07-03 09:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:58:19 --> CSRF cookie sent
INFO - 2026-07-03 09:58:19 --> Input Class Initialized
INFO - 2026-07-03 09:58:19 --> Language Class Initialized
INFO - 2026-07-03 09:58:19 --> Language Class Initialized
INFO - 2026-07-03 09:58:19 --> Config Class Initialized
INFO - 2026-07-03 09:58:19 --> Loader Class Initialized
INFO - 2026-07-03 09:58:19 --> Helper loaded: url_helper
INFO - 2026-07-03 09:58:19 --> Helper loaded: form_helper
INFO - 2026-07-03 09:58:19 --> Helper loaded: html_helper
INFO - 2026-07-03 09:58:19 --> Helper loaded: file_helper
INFO - 2026-07-03 09:58:19 --> Helper loaded: email_helper
INFO - 2026-07-03 09:58:19 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:58:19 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:58:19 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:58:19 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:58:19 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:58:19 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:58:19 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:58:19 --> Database Driver Class Initialized
INFO - 2026-07-03 09:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:58:21 --> Upload Class Initialized
DEBUG - 2026-07-03 09:58:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:58:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:58:21 --> Encryption Class Initialized
INFO - 2026-07-03 09:58:21 --> Form Validation Class Initialized
INFO - 2026-07-03 09:58:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:58:21 --> Pagination Class Initialized
INFO - 2026-07-03 09:58:21 --> Email Class Initialized
INFO - 2026-07-03 09:58:21 --> Controller Class Initialized
DEBUG - 2026-07-03 09:58:21 --> Cart MX_Controller Initialized
INFO - 2026-07-03 09:58:21 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:58:21 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:58:21 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:58:21 --> Model "Common_model" initialized
INFO - 2026-07-03 09:58:21 --> Model "Order_model" initialized
INFO - 2026-07-03 09:58:21 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 09:58:21 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 09:58:21 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 09:58:21 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 09:58:21 --> Model "Plan_model" initialized
INFO - 2026-07-03 09:58:21 --> Model "Orderlicense_model" initialized
DEBUG - 2026-07-03 09:58:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 09:58:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_category_nav.php
DEBUG - 2026-07-03 09:58:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/cart_action_nav.php
DEBUG - 2026-07-03 09:58:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 09:58:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 09:58:24 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/view_card.php
INFO - 2026-07-03 09:58:24 --> Final output sent to browser
DEBUG - 2026-07-03 09:58:24 --> Total execution time: 4.6650
INFO - 2026-07-03 09:58:24 --> Config Class Initialized
INFO - 2026-07-03 09:58:24 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:58:24 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:58:24 --> Utf8 Class Initialized
INFO - 2026-07-03 09:58:24 --> URI Class Initialized
INFO - 2026-07-03 09:58:24 --> Router Class Initialized
INFO - 2026-07-03 09:58:24 --> Output Class Initialized
INFO - 2026-07-03 09:58:24 --> Security Class Initialized
DEBUG - 2026-07-03 09:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:58:24 --> CSRF cookie sent
INFO - 2026-07-03 09:58:24 --> Input Class Initialized
INFO - 2026-07-03 09:58:24 --> Language Class Initialized
INFO - 2026-07-03 09:58:24 --> Language Class Initialized
INFO - 2026-07-03 09:58:24 --> Config Class Initialized
INFO - 2026-07-03 09:58:24 --> Loader Class Initialized
INFO - 2026-07-03 09:58:24 --> Helper loaded: url_helper
INFO - 2026-07-03 09:58:24 --> Helper loaded: form_helper
INFO - 2026-07-03 09:58:24 --> Helper loaded: html_helper
INFO - 2026-07-03 09:58:24 --> Helper loaded: file_helper
INFO - 2026-07-03 09:58:24 --> Helper loaded: email_helper
INFO - 2026-07-03 09:58:24 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:58:24 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:58:24 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:58:24 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:58:24 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:58:24 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:58:24 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:58:24 --> Database Driver Class Initialized
INFO - 2026-07-03 09:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:58:26 --> Upload Class Initialized
DEBUG - 2026-07-03 09:58:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:58:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:58:26 --> Encryption Class Initialized
INFO - 2026-07-03 09:58:26 --> Form Validation Class Initialized
INFO - 2026-07-03 09:58:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:58:26 --> Pagination Class Initialized
INFO - 2026-07-03 09:58:26 --> Email Class Initialized
INFO - 2026-07-03 09:58:26 --> Controller Class Initialized
DEBUG - 2026-07-03 09:58:26 --> Cart MX_Controller Initialized
INFO - 2026-07-03 09:58:26 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:58:26 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:58:26 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:58:26 --> Model "Common_model" initialized
INFO - 2026-07-03 09:58:26 --> Model "Order_model" initialized
INFO - 2026-07-03 09:58:26 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 09:58:26 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 09:58:26 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 09:58:26 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 09:58:26 --> Model "Plan_model" initialized
INFO - 2026-07-03 09:58:26 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 09:58:27 --> Final output sent to browser
DEBUG - 2026-07-03 09:58:27 --> Total execution time: 2.3439
INFO - 2026-07-03 09:58:31 --> Config Class Initialized
INFO - 2026-07-03 09:58:31 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:58:31 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:58:31 --> Utf8 Class Initialized
INFO - 2026-07-03 09:58:31 --> URI Class Initialized
INFO - 2026-07-03 09:58:31 --> Router Class Initialized
INFO - 2026-07-03 09:58:31 --> Output Class Initialized
INFO - 2026-07-03 09:58:31 --> Security Class Initialized
DEBUG - 2026-07-03 09:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:58:31 --> Input Class Initialized
INFO - 2026-07-03 09:58:31 --> Language Class Initialized
INFO - 2026-07-03 09:58:31 --> Language Class Initialized
INFO - 2026-07-03 09:58:31 --> Config Class Initialized
INFO - 2026-07-03 09:58:31 --> Loader Class Initialized
INFO - 2026-07-03 09:58:31 --> Helper loaded: url_helper
INFO - 2026-07-03 09:58:31 --> Helper loaded: form_helper
INFO - 2026-07-03 09:58:31 --> Helper loaded: html_helper
INFO - 2026-07-03 09:58:31 --> Helper loaded: file_helper
INFO - 2026-07-03 09:58:31 --> Helper loaded: email_helper
INFO - 2026-07-03 09:58:31 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:58:31 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:58:31 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:58:31 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:58:31 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:58:31 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:58:31 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:58:31 --> Database Driver Class Initialized
INFO - 2026-07-03 09:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:58:33 --> Upload Class Initialized
DEBUG - 2026-07-03 09:58:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:58:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:58:33 --> Encryption Class Initialized
INFO - 2026-07-03 09:58:33 --> Form Validation Class Initialized
INFO - 2026-07-03 09:58:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:58:33 --> Pagination Class Initialized
INFO - 2026-07-03 09:58:33 --> Email Class Initialized
INFO - 2026-07-03 09:58:33 --> Controller Class Initialized
DEBUG - 2026-07-03 09:58:33 --> Cart MX_Controller Initialized
INFO - 2026-07-03 09:58:33 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:58:33 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:58:33 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:58:33 --> Model "Common_model" initialized
INFO - 2026-07-03 09:58:33 --> Model "Order_model" initialized
INFO - 2026-07-03 09:58:33 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 09:58:33 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 09:58:33 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 09:58:33 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 09:58:33 --> Model "Plan_model" initialized
INFO - 2026-07-03 09:58:33 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 09:58:50 --> Model "Syscnf_model" initialized
INFO - 2026-07-03 09:58:58 --> Order confirmation emails sent for order #738 - Customer: Yes, Admin: Yes
INFO - 2026-07-03 09:58:58 --> Final output sent to browser
DEBUG - 2026-07-03 09:58:58 --> Total execution time: 27.7625
INFO - 2026-07-03 09:58:59 --> Config Class Initialized
INFO - 2026-07-03 09:58:59 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:58:59 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:58:59 --> Utf8 Class Initialized
INFO - 2026-07-03 09:58:59 --> URI Class Initialized
INFO - 2026-07-03 09:58:59 --> Router Class Initialized
INFO - 2026-07-03 09:58:59 --> Output Class Initialized
INFO - 2026-07-03 09:58:59 --> Security Class Initialized
DEBUG - 2026-07-03 09:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:58:59 --> CSRF cookie sent
INFO - 2026-07-03 09:58:59 --> Input Class Initialized
INFO - 2026-07-03 09:58:59 --> Language Class Initialized
INFO - 2026-07-03 09:58:59 --> Language Class Initialized
INFO - 2026-07-03 09:58:59 --> Config Class Initialized
INFO - 2026-07-03 09:58:59 --> Loader Class Initialized
INFO - 2026-07-03 09:58:59 --> Helper loaded: url_helper
INFO - 2026-07-03 09:58:59 --> Helper loaded: form_helper
INFO - 2026-07-03 09:58:59 --> Helper loaded: html_helper
INFO - 2026-07-03 09:58:59 --> Helper loaded: file_helper
INFO - 2026-07-03 09:58:59 --> Helper loaded: email_helper
INFO - 2026-07-03 09:58:59 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:58:59 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:58:59 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:58:59 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:58:59 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:58:59 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:58:59 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:58:59 --> Database Driver Class Initialized
INFO - 2026-07-03 09:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:59:01 --> Upload Class Initialized
DEBUG - 2026-07-03 09:59:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:59:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:59:01 --> Encryption Class Initialized
INFO - 2026-07-03 09:59:01 --> Form Validation Class Initialized
INFO - 2026-07-03 09:59:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:59:01 --> Pagination Class Initialized
INFO - 2026-07-03 09:59:01 --> Email Class Initialized
INFO - 2026-07-03 09:59:01 --> Controller Class Initialized
DEBUG - 2026-07-03 09:59:01 --> Pay MX_Controller Initialized
INFO - 2026-07-03 09:59:01 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:59:01 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:59:01 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:59:01 --> Model "Payment_model" initialized
INFO - 2026-07-03 09:59:01 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 09:59:01 --> Model "Billing_model" initialized
INFO - 2026-07-03 09:59:01 --> Model "Invoice_model" initialized
DEBUG - 2026-07-03 09:59:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 09:59:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 09:59:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 09:59:03 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_pay.php
INFO - 2026-07-03 09:59:03 --> Final output sent to browser
DEBUG - 2026-07-03 09:59:03 --> Total execution time: 4.4999
INFO - 2026-07-03 09:59:04 --> Config Class Initialized
INFO - 2026-07-03 09:59:04 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:59:04 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:59:04 --> Utf8 Class Initialized
INFO - 2026-07-03 09:59:04 --> URI Class Initialized
INFO - 2026-07-03 09:59:04 --> Router Class Initialized
INFO - 2026-07-03 09:59:04 --> Output Class Initialized
INFO - 2026-07-03 09:59:04 --> Security Class Initialized
DEBUG - 2026-07-03 09:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:59:04 --> CSRF cookie sent
INFO - 2026-07-03 09:59:04 --> Input Class Initialized
INFO - 2026-07-03 09:59:04 --> Language Class Initialized
INFO - 2026-07-03 09:59:04 --> Language Class Initialized
INFO - 2026-07-03 09:59:04 --> Config Class Initialized
INFO - 2026-07-03 09:59:04 --> Loader Class Initialized
INFO - 2026-07-03 09:59:04 --> Helper loaded: url_helper
INFO - 2026-07-03 09:59:04 --> Helper loaded: form_helper
INFO - 2026-07-03 09:59:04 --> Helper loaded: html_helper
INFO - 2026-07-03 09:59:04 --> Helper loaded: file_helper
INFO - 2026-07-03 09:59:04 --> Helper loaded: email_helper
INFO - 2026-07-03 09:59:04 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:59:04 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:59:04 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:59:04 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:59:04 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:59:04 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:59:04 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:59:04 --> Database Driver Class Initialized
INFO - 2026-07-03 09:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:59:05 --> Upload Class Initialized
DEBUG - 2026-07-03 09:59:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:59:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:59:05 --> Encryption Class Initialized
INFO - 2026-07-03 09:59:05 --> Form Validation Class Initialized
INFO - 2026-07-03 09:59:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:59:05 --> Pagination Class Initialized
INFO - 2026-07-03 09:59:05 --> Email Class Initialized
INFO - 2026-07-03 09:59:05 --> Controller Class Initialized
DEBUG - 2026-07-03 09:59:05 --> Cart MX_Controller Initialized
INFO - 2026-07-03 09:59:05 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:59:05 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:59:05 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:59:05 --> Model "Common_model" initialized
INFO - 2026-07-03 09:59:05 --> Model "Order_model" initialized
INFO - 2026-07-03 09:59:05 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 09:59:05 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 09:59:05 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 09:59:05 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 09:59:05 --> Model "Plan_model" initialized
INFO - 2026-07-03 09:59:05 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 09:59:05 --> Final output sent to browser
DEBUG - 2026-07-03 09:59:05 --> Total execution time: 1.8536
INFO - 2026-07-03 09:59:20 --> Config Class Initialized
INFO - 2026-07-03 09:59:20 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:59:20 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:59:20 --> Utf8 Class Initialized
INFO - 2026-07-03 09:59:20 --> URI Class Initialized
INFO - 2026-07-03 09:59:20 --> Router Class Initialized
INFO - 2026-07-03 09:59:20 --> Output Class Initialized
INFO - 2026-07-03 09:59:20 --> Security Class Initialized
DEBUG - 2026-07-03 09:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:59:20 --> CSRF cookie sent
INFO - 2026-07-03 09:59:20 --> Input Class Initialized
INFO - 2026-07-03 09:59:20 --> Language Class Initialized
INFO - 2026-07-03 09:59:20 --> Language Class Initialized
INFO - 2026-07-03 09:59:20 --> Config Class Initialized
INFO - 2026-07-03 09:59:20 --> Loader Class Initialized
INFO - 2026-07-03 09:59:20 --> Helper loaded: url_helper
INFO - 2026-07-03 09:59:20 --> Helper loaded: form_helper
INFO - 2026-07-03 09:59:20 --> Helper loaded: html_helper
INFO - 2026-07-03 09:59:20 --> Helper loaded: file_helper
INFO - 2026-07-03 09:59:20 --> Helper loaded: email_helper
INFO - 2026-07-03 09:59:20 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:59:20 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:59:20 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:59:20 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:59:20 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:59:20 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:59:20 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:59:20 --> Database Driver Class Initialized
INFO - 2026-07-03 09:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:59:22 --> Upload Class Initialized
DEBUG - 2026-07-03 09:59:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:59:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:59:22 --> Encryption Class Initialized
INFO - 2026-07-03 09:59:22 --> Form Validation Class Initialized
INFO - 2026-07-03 09:59:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:59:22 --> Pagination Class Initialized
INFO - 2026-07-03 09:59:22 --> Email Class Initialized
INFO - 2026-07-03 09:59:22 --> Controller Class Initialized
DEBUG - 2026-07-03 09:59:22 --> Billing MX_Controller Initialized
INFO - 2026-07-03 09:59:22 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:59:22 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:59:22 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:59:22 --> Model "Billing_model" initialized
INFO - 2026-07-03 09:59:22 --> Model "Common_model" initialized
INFO - 2026-07-03 09:59:22 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-03 09:59:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_invoice_pdf_html.php
DEBUG - 2026-07-03 09:59:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 09:59:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-07-03 09:59:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 09:59:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 09:59:25 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_viewinvoice.php
INFO - 2026-07-03 09:59:25 --> Final output sent to browser
DEBUG - 2026-07-03 09:59:25 --> Total execution time: 4.2693
INFO - 2026-07-03 09:59:25 --> Config Class Initialized
INFO - 2026-07-03 09:59:25 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:59:25 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:59:25 --> Utf8 Class Initialized
INFO - 2026-07-03 09:59:25 --> URI Class Initialized
INFO - 2026-07-03 09:59:25 --> Router Class Initialized
INFO - 2026-07-03 09:59:25 --> Output Class Initialized
INFO - 2026-07-03 09:59:25 --> Security Class Initialized
DEBUG - 2026-07-03 09:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:59:25 --> CSRF cookie sent
INFO - 2026-07-03 09:59:25 --> Input Class Initialized
INFO - 2026-07-03 09:59:25 --> Language Class Initialized
INFO - 2026-07-03 09:59:25 --> Language Class Initialized
INFO - 2026-07-03 09:59:25 --> Config Class Initialized
INFO - 2026-07-03 09:59:25 --> Loader Class Initialized
INFO - 2026-07-03 09:59:25 --> Helper loaded: url_helper
INFO - 2026-07-03 09:59:25 --> Helper loaded: form_helper
INFO - 2026-07-03 09:59:25 --> Helper loaded: html_helper
INFO - 2026-07-03 09:59:25 --> Helper loaded: file_helper
INFO - 2026-07-03 09:59:25 --> Helper loaded: email_helper
INFO - 2026-07-03 09:59:25 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:59:25 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:59:25 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:59:25 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:59:25 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:59:25 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:59:25 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:59:25 --> Database Driver Class Initialized
INFO - 2026-07-03 09:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:59:26 --> Upload Class Initialized
DEBUG - 2026-07-03 09:59:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:59:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:59:26 --> Encryption Class Initialized
INFO - 2026-07-03 09:59:26 --> Form Validation Class Initialized
INFO - 2026-07-03 09:59:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:59:26 --> Pagination Class Initialized
INFO - 2026-07-03 09:59:26 --> Email Class Initialized
INFO - 2026-07-03 09:59:26 --> Controller Class Initialized
DEBUG - 2026-07-03 09:59:26 --> Cart MX_Controller Initialized
INFO - 2026-07-03 09:59:26 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:59:26 --> Model "Auth_model" initialized
INFO - 2026-07-03 09:59:26 --> Model "Cart_model" initialized
INFO - 2026-07-03 09:59:26 --> Model "Common_model" initialized
INFO - 2026-07-03 09:59:26 --> Model "Order_model" initialized
INFO - 2026-07-03 09:59:26 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 09:59:26 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 09:59:26 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 09:59:26 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 09:59:26 --> Model "Plan_model" initialized
INFO - 2026-07-03 09:59:26 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 09:59:27 --> Final output sent to browser
DEBUG - 2026-07-03 09:59:27 --> Total execution time: 2.0371
INFO - 2026-07-03 09:59:31 --> Config Class Initialized
INFO - 2026-07-03 09:59:31 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:59:31 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:59:31 --> Utf8 Class Initialized
INFO - 2026-07-03 09:59:31 --> URI Class Initialized
INFO - 2026-07-03 09:59:31 --> Router Class Initialized
INFO - 2026-07-03 09:59:31 --> Output Class Initialized
INFO - 2026-07-03 09:59:31 --> Security Class Initialized
DEBUG - 2026-07-03 09:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:59:31 --> CSRF cookie sent
INFO - 2026-07-03 09:59:37 --> Config Class Initialized
INFO - 2026-07-03 09:59:37 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:59:37 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:59:37 --> Utf8 Class Initialized
INFO - 2026-07-03 09:59:37 --> URI Class Initialized
INFO - 2026-07-03 09:59:37 --> Router Class Initialized
INFO - 2026-07-03 09:59:37 --> Output Class Initialized
INFO - 2026-07-03 09:59:37 --> Security Class Initialized
DEBUG - 2026-07-03 09:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:59:37 --> CSRF cookie sent
INFO - 2026-07-03 09:59:37 --> Input Class Initialized
INFO - 2026-07-03 09:59:37 --> Language Class Initialized
INFO - 2026-07-03 09:59:37 --> Language Class Initialized
INFO - 2026-07-03 09:59:37 --> Config Class Initialized
INFO - 2026-07-03 09:59:37 --> Loader Class Initialized
INFO - 2026-07-03 09:59:37 --> Helper loaded: url_helper
INFO - 2026-07-03 09:59:37 --> Helper loaded: form_helper
INFO - 2026-07-03 09:59:37 --> Helper loaded: html_helper
INFO - 2026-07-03 09:59:37 --> Helper loaded: file_helper
INFO - 2026-07-03 09:59:37 --> Helper loaded: email_helper
INFO - 2026-07-03 09:59:37 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:59:37 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:59:37 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:59:37 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:59:37 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:59:37 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:59:37 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:59:37 --> Database Driver Class Initialized
INFO - 2026-07-03 09:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:59:39 --> Upload Class Initialized
DEBUG - 2026-07-03 09:59:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:59:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:59:39 --> Encryption Class Initialized
INFO - 2026-07-03 09:59:39 --> Form Validation Class Initialized
INFO - 2026-07-03 09:59:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:59:39 --> Pagination Class Initialized
INFO - 2026-07-03 09:59:39 --> Email Class Initialized
INFO - 2026-07-03 09:59:39 --> Controller Class Initialized
DEBUG - 2026-07-03 09:59:39 --> Authenticate MX_Controller Initialized
INFO - 2026-07-03 09:59:39 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:59:39 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 09:59:39 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-03 09:59:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 09:59:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 09:59:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-07-03 09:59:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-03 09:59:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 09:59:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-07-03 09:59:39 --> Final output sent to browser
DEBUG - 2026-07-03 09:59:39 --> Total execution time: 2.4497
INFO - 2026-07-03 09:59:39 --> Config Class Initialized
INFO - 2026-07-03 09:59:39 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:59:39 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:59:39 --> Utf8 Class Initialized
INFO - 2026-07-03 09:59:39 --> URI Class Initialized
INFO - 2026-07-03 09:59:39 --> Router Class Initialized
INFO - 2026-07-03 09:59:39 --> Output Class Initialized
INFO - 2026-07-03 09:59:39 --> Security Class Initialized
DEBUG - 2026-07-03 09:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:59:39 --> CSRF cookie sent
INFO - 2026-07-03 09:59:39 --> Input Class Initialized
INFO - 2026-07-03 09:59:39 --> Language Class Initialized
INFO - 2026-07-03 09:59:39 --> Language Class Initialized
INFO - 2026-07-03 09:59:39 --> Config Class Initialized
INFO - 2026-07-03 09:59:39 --> Loader Class Initialized
INFO - 2026-07-03 09:59:40 --> Helper loaded: url_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: form_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: html_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: file_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: email_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:59:40 --> Database Driver Class Initialized
INFO - 2026-07-03 09:59:40 --> Config Class Initialized
INFO - 2026-07-03 09:59:40 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:59:40 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:59:40 --> Utf8 Class Initialized
INFO - 2026-07-03 09:59:40 --> URI Class Initialized
INFO - 2026-07-03 09:59:40 --> Router Class Initialized
INFO - 2026-07-03 09:59:40 --> Output Class Initialized
INFO - 2026-07-03 09:59:40 --> Security Class Initialized
DEBUG - 2026-07-03 09:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:59:40 --> CSRF cookie sent
INFO - 2026-07-03 09:59:40 --> Input Class Initialized
INFO - 2026-07-03 09:59:40 --> Language Class Initialized
INFO - 2026-07-03 09:59:40 --> Language Class Initialized
INFO - 2026-07-03 09:59:40 --> Config Class Initialized
INFO - 2026-07-03 09:59:40 --> Loader Class Initialized
INFO - 2026-07-03 09:59:40 --> Helper loaded: url_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: form_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: html_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: file_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: email_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:59:40 --> Database Driver Class Initialized
INFO - 2026-07-03 09:59:40 --> Config Class Initialized
INFO - 2026-07-03 09:59:40 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:59:40 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:59:40 --> Utf8 Class Initialized
INFO - 2026-07-03 09:59:40 --> URI Class Initialized
INFO - 2026-07-03 09:59:40 --> Router Class Initialized
INFO - 2026-07-03 09:59:40 --> Output Class Initialized
INFO - 2026-07-03 09:59:40 --> Security Class Initialized
DEBUG - 2026-07-03 09:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:59:40 --> CSRF cookie sent
INFO - 2026-07-03 09:59:40 --> Input Class Initialized
INFO - 2026-07-03 09:59:40 --> Language Class Initialized
INFO - 2026-07-03 09:59:40 --> Language Class Initialized
INFO - 2026-07-03 09:59:40 --> Config Class Initialized
INFO - 2026-07-03 09:59:40 --> Loader Class Initialized
INFO - 2026-07-03 09:59:40 --> Helper loaded: url_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: form_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: html_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: file_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: email_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:59:40 --> Database Driver Class Initialized
INFO - 2026-07-03 09:59:40 --> Config Class Initialized
INFO - 2026-07-03 09:59:40 --> Hooks Class Initialized
INFO - 2026-07-03 09:59:40 --> Config Class Initialized
INFO - 2026-07-03 09:59:40 --> Hooks Class Initialized
INFO - 2026-07-03 09:59:40 --> Config Class Initialized
INFO - 2026-07-03 09:59:40 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:59:40 --> UTF-8 Support Enabled
DEBUG - 2026-07-03 09:59:40 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:59:40 --> Utf8 Class Initialized
INFO - 2026-07-03 09:59:40 --> Utf8 Class Initialized
DEBUG - 2026-07-03 09:59:40 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:59:40 --> Utf8 Class Initialized
INFO - 2026-07-03 09:59:40 --> URI Class Initialized
INFO - 2026-07-03 09:59:40 --> URI Class Initialized
INFO - 2026-07-03 09:59:40 --> URI Class Initialized
INFO - 2026-07-03 09:59:40 --> Router Class Initialized
INFO - 2026-07-03 09:59:40 --> Router Class Initialized
INFO - 2026-07-03 09:59:40 --> Output Class Initialized
INFO - 2026-07-03 09:59:40 --> Router Class Initialized
INFO - 2026-07-03 09:59:40 --> Output Class Initialized
INFO - 2026-07-03 09:59:40 --> Security Class Initialized
INFO - 2026-07-03 09:59:40 --> Security Class Initialized
INFO - 2026-07-03 09:59:40 --> Output Class Initialized
DEBUG - 2026-07-03 09:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-07-03 09:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:59:40 --> CSRF cookie sent
INFO - 2026-07-03 09:59:40 --> CSRF cookie sent
INFO - 2026-07-03 09:59:40 --> Input Class Initialized
INFO - 2026-07-03 09:59:40 --> Input Class Initialized
INFO - 2026-07-03 09:59:40 --> Language Class Initialized
INFO - 2026-07-03 09:59:40 --> Language Class Initialized
INFO - 2026-07-03 09:59:40 --> Language Class Initialized
INFO - 2026-07-03 09:59:40 --> Language Class Initialized
INFO - 2026-07-03 09:59:40 --> Config Class Initialized
INFO - 2026-07-03 09:59:40 --> Config Class Initialized
INFO - 2026-07-03 09:59:40 --> Security Class Initialized
DEBUG - 2026-07-03 09:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:59:40 --> CSRF cookie sent
INFO - 2026-07-03 09:59:40 --> Loader Class Initialized
INFO - 2026-07-03 09:59:40 --> Input Class Initialized
INFO - 2026-07-03 09:59:40 --> Language Class Initialized
INFO - 2026-07-03 09:59:40 --> Helper loaded: url_helper
INFO - 2026-07-03 09:59:40 --> Loader Class Initialized
INFO - 2026-07-03 09:59:40 --> Language Class Initialized
INFO - 2026-07-03 09:59:40 --> Config Class Initialized
INFO - 2026-07-03 09:59:40 --> Helper loaded: form_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: url_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: html_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: file_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: form_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: email_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: html_helper
INFO - 2026-07-03 09:59:40 --> Loader Class Initialized
INFO - 2026-07-03 09:59:40 --> Helper loaded: file_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: email_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: url_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: form_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: html_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: file_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: email_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:59:40 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:59:40 --> Database Driver Class Initialized
INFO - 2026-07-03 09:59:40 --> Database Driver Class Initialized
INFO - 2026-07-03 09:59:40 --> Database Driver Class Initialized
INFO - 2026-07-03 09:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:59:41 --> Upload Class Initialized
DEBUG - 2026-07-03 09:59:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:59:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:59:41 --> Encryption Class Initialized
INFO - 2026-07-03 09:59:41 --> Form Validation Class Initialized
INFO - 2026-07-03 09:59:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:59:41 --> Pagination Class Initialized
INFO - 2026-07-03 09:59:41 --> Email Class Initialized
INFO - 2026-07-03 09:59:41 --> Controller Class Initialized
ERROR - 2026-07-03 09:59:41 --> 404 Page Not Found: /index
INFO - 2026-07-03 09:59:41 --> Config Class Initialized
INFO - 2026-07-03 09:59:41 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:59:41 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:59:41 --> Utf8 Class Initialized
INFO - 2026-07-03 09:59:41 --> URI Class Initialized
INFO - 2026-07-03 09:59:41 --> Router Class Initialized
INFO - 2026-07-03 09:59:41 --> Output Class Initialized
INFO - 2026-07-03 09:59:41 --> Security Class Initialized
DEBUG - 2026-07-03 09:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:59:41 --> CSRF cookie sent
INFO - 2026-07-03 09:59:41 --> Input Class Initialized
INFO - 2026-07-03 09:59:41 --> Language Class Initialized
INFO - 2026-07-03 09:59:41 --> Language Class Initialized
INFO - 2026-07-03 09:59:41 --> Config Class Initialized
INFO - 2026-07-03 09:59:41 --> Loader Class Initialized
INFO - 2026-07-03 09:59:41 --> Helper loaded: url_helper
INFO - 2026-07-03 09:59:41 --> Helper loaded: form_helper
INFO - 2026-07-03 09:59:41 --> Helper loaded: html_helper
INFO - 2026-07-03 09:59:41 --> Helper loaded: file_helper
INFO - 2026-07-03 09:59:41 --> Helper loaded: email_helper
INFO - 2026-07-03 09:59:41 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:59:41 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:59:41 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:59:41 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:59:41 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:59:41 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:59:41 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:59:41 --> Database Driver Class Initialized
INFO - 2026-07-03 09:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:59:41 --> Upload Class Initialized
DEBUG - 2026-07-03 09:59:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:59:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:59:41 --> Encryption Class Initialized
INFO - 2026-07-03 09:59:41 --> Form Validation Class Initialized
INFO - 2026-07-03 09:59:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:59:41 --> Pagination Class Initialized
INFO - 2026-07-03 09:59:41 --> Email Class Initialized
INFO - 2026-07-03 09:59:41 --> Controller Class Initialized
ERROR - 2026-07-03 09:59:41 --> 404 Page Not Found: /index
INFO - 2026-07-03 09:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:59:41 --> Upload Class Initialized
DEBUG - 2026-07-03 09:59:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:59:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:59:41 --> Encryption Class Initialized
INFO - 2026-07-03 09:59:41 --> Form Validation Class Initialized
INFO - 2026-07-03 09:59:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:59:41 --> Pagination Class Initialized
INFO - 2026-07-03 09:59:41 --> Email Class Initialized
INFO - 2026-07-03 09:59:41 --> Controller Class Initialized
ERROR - 2026-07-03 09:59:41 --> 404 Page Not Found: /index
INFO - 2026-07-03 09:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:59:41 --> Upload Class Initialized
DEBUG - 2026-07-03 09:59:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:59:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:59:41 --> Encryption Class Initialized
INFO - 2026-07-03 09:59:41 --> Form Validation Class Initialized
INFO - 2026-07-03 09:59:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:59:41 --> Pagination Class Initialized
INFO - 2026-07-03 09:59:41 --> Email Class Initialized
INFO - 2026-07-03 09:59:41 --> Controller Class Initialized
ERROR - 2026-07-03 09:59:41 --> 404 Page Not Found: /index
INFO - 2026-07-03 09:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:59:41 --> Upload Class Initialized
DEBUG - 2026-07-03 09:59:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:59:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:59:41 --> Encryption Class Initialized
INFO - 2026-07-03 09:59:41 --> Form Validation Class Initialized
INFO - 2026-07-03 09:59:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:59:41 --> Pagination Class Initialized
INFO - 2026-07-03 09:59:41 --> Email Class Initialized
INFO - 2026-07-03 09:59:41 --> Controller Class Initialized
ERROR - 2026-07-03 09:59:41 --> 404 Page Not Found: /index
INFO - 2026-07-03 09:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:59:41 --> Upload Class Initialized
DEBUG - 2026-07-03 09:59:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:59:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:59:41 --> Encryption Class Initialized
INFO - 2026-07-03 09:59:41 --> Form Validation Class Initialized
INFO - 2026-07-03 09:59:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:59:41 --> Pagination Class Initialized
INFO - 2026-07-03 09:59:41 --> Email Class Initialized
INFO - 2026-07-03 09:59:41 --> Controller Class Initialized
ERROR - 2026-07-03 09:59:41 --> 404 Page Not Found: /index
INFO - 2026-07-03 09:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:59:43 --> Upload Class Initialized
DEBUG - 2026-07-03 09:59:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:59:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:59:43 --> Encryption Class Initialized
INFO - 2026-07-03 09:59:43 --> Form Validation Class Initialized
INFO - 2026-07-03 09:59:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:59:43 --> Pagination Class Initialized
INFO - 2026-07-03 09:59:43 --> Email Class Initialized
INFO - 2026-07-03 09:59:43 --> Controller Class Initialized
ERROR - 2026-07-03 09:59:43 --> 404 Page Not Found: /index
INFO - 2026-07-03 09:59:48 --> Config Class Initialized
INFO - 2026-07-03 09:59:48 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:59:48 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:59:48 --> Utf8 Class Initialized
INFO - 2026-07-03 09:59:48 --> URI Class Initialized
INFO - 2026-07-03 09:59:48 --> Router Class Initialized
INFO - 2026-07-03 09:59:48 --> Output Class Initialized
INFO - 2026-07-03 09:59:48 --> Security Class Initialized
DEBUG - 2026-07-03 09:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:59:48 --> CSRF cookie sent
INFO - 2026-07-03 09:59:48 --> CSRF token verified
INFO - 2026-07-03 09:59:48 --> Input Class Initialized
INFO - 2026-07-03 09:59:48 --> Language Class Initialized
INFO - 2026-07-03 09:59:48 --> Language Class Initialized
INFO - 2026-07-03 09:59:48 --> Config Class Initialized
INFO - 2026-07-03 09:59:48 --> Loader Class Initialized
INFO - 2026-07-03 09:59:48 --> Helper loaded: url_helper
INFO - 2026-07-03 09:59:48 --> Helper loaded: form_helper
INFO - 2026-07-03 09:59:48 --> Helper loaded: html_helper
INFO - 2026-07-03 09:59:48 --> Helper loaded: file_helper
INFO - 2026-07-03 09:59:48 --> Helper loaded: email_helper
INFO - 2026-07-03 09:59:48 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:59:48 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:59:48 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:59:48 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:59:48 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:59:48 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:59:48 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:59:48 --> Database Driver Class Initialized
INFO - 2026-07-03 09:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:59:50 --> Upload Class Initialized
DEBUG - 2026-07-03 09:59:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:59:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:59:50 --> Encryption Class Initialized
INFO - 2026-07-03 09:59:50 --> Form Validation Class Initialized
INFO - 2026-07-03 09:59:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:59:50 --> Pagination Class Initialized
INFO - 2026-07-03 09:59:50 --> Email Class Initialized
INFO - 2026-07-03 09:59:50 --> Controller Class Initialized
DEBUG - 2026-07-03 09:59:50 --> Authenticate MX_Controller Initialized
INFO - 2026-07-03 09:59:50 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:59:50 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 09:59:50 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 09:59:53 --> Config Class Initialized
INFO - 2026-07-03 09:59:53 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:59:53 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:59:53 --> Utf8 Class Initialized
INFO - 2026-07-03 09:59:53 --> URI Class Initialized
INFO - 2026-07-03 09:59:53 --> Router Class Initialized
INFO - 2026-07-03 09:59:53 --> Output Class Initialized
INFO - 2026-07-03 09:59:53 --> Security Class Initialized
DEBUG - 2026-07-03 09:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:59:53 --> CSRF cookie sent
INFO - 2026-07-03 09:59:53 --> Input Class Initialized
INFO - 2026-07-03 09:59:53 --> Language Class Initialized
INFO - 2026-07-03 09:59:53 --> Language Class Initialized
INFO - 2026-07-03 09:59:53 --> Config Class Initialized
INFO - 2026-07-03 09:59:53 --> Loader Class Initialized
INFO - 2026-07-03 09:59:53 --> Helper loaded: url_helper
INFO - 2026-07-03 09:59:53 --> Helper loaded: form_helper
INFO - 2026-07-03 09:59:53 --> Helper loaded: html_helper
INFO - 2026-07-03 09:59:53 --> Helper loaded: file_helper
INFO - 2026-07-03 09:59:53 --> Helper loaded: email_helper
INFO - 2026-07-03 09:59:53 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:59:53 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:59:53 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:59:53 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:59:53 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:59:53 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:59:53 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:59:53 --> Database Driver Class Initialized
INFO - 2026-07-03 09:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:59:55 --> Upload Class Initialized
DEBUG - 2026-07-03 09:59:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:59:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:59:55 --> Encryption Class Initialized
INFO - 2026-07-03 09:59:55 --> Form Validation Class Initialized
INFO - 2026-07-03 09:59:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:59:55 --> Pagination Class Initialized
INFO - 2026-07-03 09:59:55 --> Email Class Initialized
INFO - 2026-07-03 09:59:55 --> Controller Class Initialized
DEBUG - 2026-07-03 09:59:55 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 09:59:55 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:59:55 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 09:59:55 --> Model "Dashboard_model" initialized
DEBUG - 2026-07-03 09:59:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 09:59:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 09:59:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 09:59:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-03 09:59:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 09:59:55 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/dashboard_index.php
INFO - 2026-07-03 09:59:55 --> Final output sent to browser
DEBUG - 2026-07-03 09:59:55 --> Total execution time: 2.1180
INFO - 2026-07-03 09:59:55 --> Config Class Initialized
INFO - 2026-07-03 09:59:55 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:59:55 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:59:55 --> Utf8 Class Initialized
INFO - 2026-07-03 09:59:55 --> URI Class Initialized
INFO - 2026-07-03 09:59:55 --> Router Class Initialized
INFO - 2026-07-03 09:59:55 --> Output Class Initialized
INFO - 2026-07-03 09:59:55 --> Security Class Initialized
DEBUG - 2026-07-03 09:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:59:55 --> CSRF cookie sent
INFO - 2026-07-03 09:59:55 --> Input Class Initialized
INFO - 2026-07-03 09:59:55 --> Language Class Initialized
INFO - 2026-07-03 09:59:55 --> Language Class Initialized
INFO - 2026-07-03 09:59:55 --> Config Class Initialized
INFO - 2026-07-03 09:59:55 --> Loader Class Initialized
INFO - 2026-07-03 09:59:55 --> Helper loaded: url_helper
INFO - 2026-07-03 09:59:55 --> Helper loaded: form_helper
INFO - 2026-07-03 09:59:55 --> Helper loaded: html_helper
INFO - 2026-07-03 09:59:55 --> Helper loaded: file_helper
INFO - 2026-07-03 09:59:55 --> Helper loaded: email_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:59:56 --> Database Driver Class Initialized
INFO - 2026-07-03 09:59:56 --> Config Class Initialized
INFO - 2026-07-03 09:59:56 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:59:56 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:59:56 --> Utf8 Class Initialized
INFO - 2026-07-03 09:59:56 --> URI Class Initialized
INFO - 2026-07-03 09:59:56 --> Router Class Initialized
INFO - 2026-07-03 09:59:56 --> Output Class Initialized
INFO - 2026-07-03 09:59:56 --> Security Class Initialized
DEBUG - 2026-07-03 09:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:59:56 --> CSRF cookie sent
INFO - 2026-07-03 09:59:56 --> Input Class Initialized
INFO - 2026-07-03 09:59:56 --> Language Class Initialized
INFO - 2026-07-03 09:59:56 --> Language Class Initialized
INFO - 2026-07-03 09:59:56 --> Config Class Initialized
INFO - 2026-07-03 09:59:56 --> Loader Class Initialized
INFO - 2026-07-03 09:59:56 --> Helper loaded: url_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: form_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: html_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: file_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: email_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:59:56 --> Config Class Initialized
INFO - 2026-07-03 09:59:56 --> Hooks Class Initialized
INFO - 2026-07-03 09:59:56 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:59:56 --> Config Class Initialized
INFO - 2026-07-03 09:59:56 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:59:56 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:59:56 --> Utf8 Class Initialized
INFO - 2026-07-03 09:59:56 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:59:56 --> URI Class Initialized
DEBUG - 2026-07-03 09:59:56 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:59:56 --> Utf8 Class Initialized
INFO - 2026-07-03 09:59:56 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:59:56 --> URI Class Initialized
INFO - 2026-07-03 09:59:56 --> Router Class Initialized
INFO - 2026-07-03 09:59:56 --> Router Class Initialized
INFO - 2026-07-03 09:59:56 --> Output Class Initialized
INFO - 2026-07-03 09:59:56 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:59:56 --> Output Class Initialized
INFO - 2026-07-03 09:59:56 --> Security Class Initialized
INFO - 2026-07-03 09:59:56 --> Security Class Initialized
DEBUG - 2026-07-03 09:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:59:56 --> CSRF cookie sent
INFO - 2026-07-03 09:59:56 --> Input Class Initialized
INFO - 2026-07-03 09:59:56 --> Language Class Initialized
DEBUG - 2026-07-03 09:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:59:56 --> CSRF cookie sent
INFO - 2026-07-03 09:59:56 --> Input Class Initialized
INFO - 2026-07-03 09:59:56 --> Language Class Initialized
INFO - 2026-07-03 09:59:56 --> Language Class Initialized
INFO - 2026-07-03 09:59:56 --> Config Class Initialized
INFO - 2026-07-03 09:59:56 --> Language Class Initialized
INFO - 2026-07-03 09:59:56 --> Config Class Initialized
INFO - 2026-07-03 09:59:56 --> Database Driver Class Initialized
INFO - 2026-07-03 09:59:56 --> Loader Class Initialized
INFO - 2026-07-03 09:59:56 --> Loader Class Initialized
INFO - 2026-07-03 09:59:56 --> Helper loaded: url_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: url_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: form_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: html_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: form_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: file_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: email_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: html_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: file_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: email_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:59:56 --> Database Driver Class Initialized
INFO - 2026-07-03 09:59:56 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:59:56 --> Database Driver Class Initialized
INFO - 2026-07-03 09:59:56 --> Config Class Initialized
INFO - 2026-07-03 09:59:56 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:59:56 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:59:56 --> Utf8 Class Initialized
INFO - 2026-07-03 09:59:56 --> URI Class Initialized
INFO - 2026-07-03 09:59:56 --> Config Class Initialized
INFO - 2026-07-03 09:59:56 --> Hooks Class Initialized
INFO - 2026-07-03 09:59:56 --> Router Class Initialized
DEBUG - 2026-07-03 09:59:56 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:59:56 --> Utf8 Class Initialized
INFO - 2026-07-03 09:59:56 --> Output Class Initialized
INFO - 2026-07-03 09:59:56 --> URI Class Initialized
INFO - 2026-07-03 09:59:56 --> Security Class Initialized
DEBUG - 2026-07-03 09:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:59:56 --> CSRF cookie sent
INFO - 2026-07-03 09:59:56 --> Input Class Initialized
INFO - 2026-07-03 09:59:56 --> Router Class Initialized
INFO - 2026-07-03 09:59:56 --> Language Class Initialized
INFO - 2026-07-03 09:59:56 --> Language Class Initialized
INFO - 2026-07-03 09:59:56 --> Config Class Initialized
INFO - 2026-07-03 09:59:56 --> Output Class Initialized
INFO - 2026-07-03 09:59:56 --> Security Class Initialized
INFO - 2026-07-03 09:59:56 --> Loader Class Initialized
DEBUG - 2026-07-03 09:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:59:56 --> CSRF cookie sent
INFO - 2026-07-03 09:59:56 --> Input Class Initialized
INFO - 2026-07-03 09:59:56 --> Language Class Initialized
INFO - 2026-07-03 09:59:56 --> Helper loaded: url_helper
INFO - 2026-07-03 09:59:56 --> Language Class Initialized
INFO - 2026-07-03 09:59:56 --> Config Class Initialized
INFO - 2026-07-03 09:59:56 --> Helper loaded: form_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: html_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: file_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: email_helper
INFO - 2026-07-03 09:59:56 --> Loader Class Initialized
INFO - 2026-07-03 09:59:56 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: url_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: form_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: html_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: file_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: email_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:59:56 --> Database Driver Class Initialized
INFO - 2026-07-03 09:59:56 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:59:56 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:59:56 --> Database Driver Class Initialized
INFO - 2026-07-03 09:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:59:57 --> Upload Class Initialized
DEBUG - 2026-07-03 09:59:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:59:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:59:57 --> Encryption Class Initialized
INFO - 2026-07-03 09:59:57 --> Form Validation Class Initialized
INFO - 2026-07-03 09:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:59:57 --> Pagination Class Initialized
INFO - 2026-07-03 09:59:57 --> Email Class Initialized
INFO - 2026-07-03 09:59:57 --> Controller Class Initialized
ERROR - 2026-07-03 09:59:57 --> 404 Page Not Found: /index
INFO - 2026-07-03 09:59:57 --> Config Class Initialized
INFO - 2026-07-03 09:59:57 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:59:57 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:59:57 --> Utf8 Class Initialized
INFO - 2026-07-03 09:59:57 --> URI Class Initialized
INFO - 2026-07-03 09:59:57 --> Router Class Initialized
INFO - 2026-07-03 09:59:57 --> Output Class Initialized
INFO - 2026-07-03 09:59:57 --> Security Class Initialized
DEBUG - 2026-07-03 09:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:59:57 --> Input Class Initialized
INFO - 2026-07-03 09:59:57 --> Language Class Initialized
INFO - 2026-07-03 09:59:57 --> Language Class Initialized
INFO - 2026-07-03 09:59:57 --> Config Class Initialized
INFO - 2026-07-03 09:59:57 --> Loader Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: url_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: form_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: html_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: file_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: email_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:59:57 --> Database Driver Class Initialized
INFO - 2026-07-03 09:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:59:57 --> Upload Class Initialized
DEBUG - 2026-07-03 09:59:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:59:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:59:57 --> Encryption Class Initialized
INFO - 2026-07-03 09:59:57 --> Form Validation Class Initialized
INFO - 2026-07-03 09:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:59:57 --> Pagination Class Initialized
INFO - 2026-07-03 09:59:57 --> Email Class Initialized
INFO - 2026-07-03 09:59:57 --> Controller Class Initialized
ERROR - 2026-07-03 09:59:57 --> 404 Page Not Found: /index
INFO - 2026-07-03 09:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:59:57 --> Upload Class Initialized
DEBUG - 2026-07-03 09:59:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:59:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:59:57 --> Encryption Class Initialized
INFO - 2026-07-03 09:59:57 --> Form Validation Class Initialized
INFO - 2026-07-03 09:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:59:57 --> Pagination Class Initialized
INFO - 2026-07-03 09:59:57 --> Email Class Initialized
INFO - 2026-07-03 09:59:57 --> Controller Class Initialized
ERROR - 2026-07-03 09:59:57 --> 404 Page Not Found: /index
INFO - 2026-07-03 09:59:57 --> Config Class Initialized
INFO - 2026-07-03 09:59:57 --> Hooks Class Initialized
INFO - 2026-07-03 09:59:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-07-03 09:59:57 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:59:57 --> Utf8 Class Initialized
INFO - 2026-07-03 09:59:57 --> Upload Class Initialized
INFO - 2026-07-03 09:59:57 --> URI Class Initialized
DEBUG - 2026-07-03 09:59:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:59:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:59:57 --> Encryption Class Initialized
INFO - 2026-07-03 09:59:57 --> Router Class Initialized
INFO - 2026-07-03 09:59:57 --> Form Validation Class Initialized
INFO - 2026-07-03 09:59:57 --> Output Class Initialized
INFO - 2026-07-03 09:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:59:57 --> Pagination Class Initialized
INFO - 2026-07-03 09:59:57 --> Security Class Initialized
DEBUG - 2026-07-03 09:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:59:57 --> Input Class Initialized
INFO - 2026-07-03 09:59:57 --> Email Class Initialized
INFO - 2026-07-03 09:59:57 --> Language Class Initialized
INFO - 2026-07-03 09:59:57 --> Controller Class Initialized
ERROR - 2026-07-03 09:59:57 --> 404 Page Not Found: /index
INFO - 2026-07-03 09:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:59:57 --> Language Class Initialized
INFO - 2026-07-03 09:59:57 --> Config Class Initialized
INFO - 2026-07-03 09:59:57 --> Upload Class Initialized
INFO - 2026-07-03 09:59:57 --> Config Class Initialized
INFO - 2026-07-03 09:59:57 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:59:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:59:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:59:57 --> Encryption Class Initialized
INFO - 2026-07-03 09:59:57 --> Loader Class Initialized
DEBUG - 2026-07-03 09:59:57 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:59:57 --> Utf8 Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: url_helper
INFO - 2026-07-03 09:59:57 --> Form Validation Class Initialized
INFO - 2026-07-03 09:59:57 --> URI Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: form_helper
INFO - 2026-07-03 09:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:59:57 --> Pagination Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: html_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: file_helper
INFO - 2026-07-03 09:59:57 --> Router Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: email_helper
INFO - 2026-07-03 09:59:57 --> Config Class Initialized
INFO - 2026-07-03 09:59:57 --> Hooks Class Initialized
INFO - 2026-07-03 09:59:57 --> Email Class Initialized
INFO - 2026-07-03 09:59:57 --> Controller Class Initialized
ERROR - 2026-07-03 09:59:57 --> 404 Page Not Found: /index
INFO - 2026-07-03 09:59:57 --> Output Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:59:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-07-03 09:59:57 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:59:57 --> Utf8 Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:59:57 --> URI Class Initialized
INFO - 2026-07-03 09:59:57 --> Security Class Initialized
INFO - 2026-07-03 09:59:57 --> Upload Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: cpanel_helper
DEBUG - 2026-07-03 09:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:59:57 --> Router Class Initialized
INFO - 2026-07-03 09:59:57 --> Input Class Initialized
INFO - 2026-07-03 09:59:57 --> Language Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: plesk_helper
DEBUG - 2026-07-03 09:59:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:59:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:59:57 --> Encryption Class Initialized
INFO - 2026-07-03 09:59:57 --> Output Class Initialized
INFO - 2026-07-03 09:59:57 --> Language Class Initialized
INFO - 2026-07-03 09:59:57 --> Config Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:59:57 --> Security Class Initialized
INFO - 2026-07-03 09:59:57 --> Form Validation Class Initialized
DEBUG - 2026-07-03 09:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:59:57 --> Input Class Initialized
INFO - 2026-07-03 09:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:59:57 --> Language Class Initialized
INFO - 2026-07-03 09:59:57 --> Pagination Class Initialized
INFO - 2026-07-03 09:59:57 --> Language Class Initialized
INFO - 2026-07-03 09:59:57 --> Config Class Initialized
INFO - 2026-07-03 09:59:57 --> Loader Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: url_helper
INFO - 2026-07-03 09:59:57 --> Loader Class Initialized
INFO - 2026-07-03 09:59:57 --> Config Class Initialized
INFO - 2026-07-03 09:59:57 --> Hooks Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: url_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: form_helper
INFO - 2026-07-03 09:59:57 --> Email Class Initialized
INFO - 2026-07-03 09:59:57 --> Controller Class Initialized
DEBUG - 2026-07-03 09:59:57 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:59:57 --> Utf8 Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: html_helper
ERROR - 2026-07-03 09:59:57 --> 404 Page Not Found: /index
INFO - 2026-07-03 09:59:57 --> Helper loaded: form_helper
INFO - 2026-07-03 09:59:57 --> URI Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: html_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: file_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: email_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: file_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: email_helper
INFO - 2026-07-03 09:59:57 --> Router Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:59:57 --> Output Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:59:57 --> Security Class Initialized
INFO - 2026-07-03 09:59:57 --> Database Driver Class Initialized
DEBUG - 2026-07-03 09:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:59:57 --> Input Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:59:57 --> Language Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:59:57 --> Language Class Initialized
INFO - 2026-07-03 09:59:57 --> Config Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:59:57 --> Loader Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: url_helper
INFO - 2026-07-03 09:59:57 --> Config Class Initialized
INFO - 2026-07-03 09:59:57 --> Hooks Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: form_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: html_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: file_helper
DEBUG - 2026-07-03 09:59:57 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:59:57 --> Utf8 Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: email_helper
INFO - 2026-07-03 09:59:57 --> URI Class Initialized
INFO - 2026-07-03 09:59:57 --> Database Driver Class Initialized
INFO - 2026-07-03 09:59:57 --> Database Driver Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:59:57 --> Router Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:59:57 --> Output Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:59:57 --> Security Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: directadmin_helper
DEBUG - 2026-07-03 09:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:59:57 --> Input Class Initialized
INFO - 2026-07-03 09:59:57 --> Language Class Initialized
INFO - 2026-07-03 09:59:57 --> Language Class Initialized
INFO - 2026-07-03 09:59:57 --> Config Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:59:57 --> Loader Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: url_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: form_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: html_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: file_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: email_helper
INFO - 2026-07-03 09:59:57 --> Database Driver Class Initialized
INFO - 2026-07-03 09:59:57 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:59:57 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:59:57 --> Database Driver Class Initialized
INFO - 2026-07-03 09:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:59:59 --> Upload Class Initialized
DEBUG - 2026-07-03 09:59:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:59:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:59:59 --> Encryption Class Initialized
INFO - 2026-07-03 09:59:59 --> Form Validation Class Initialized
INFO - 2026-07-03 09:59:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:59:59 --> Pagination Class Initialized
INFO - 2026-07-03 09:59:59 --> Email Class Initialized
INFO - 2026-07-03 09:59:59 --> Controller Class Initialized
DEBUG - 2026-07-03 09:59:59 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 09:59:59 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:59:59 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 09:59:59 --> Model "Dashboard_model" initialized
INFO - 2026-07-03 09:59:59 --> Final output sent to browser
DEBUG - 2026-07-03 09:59:59 --> Total execution time: 2.3454
INFO - 2026-07-03 09:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 09:59:59 --> Upload Class Initialized
DEBUG - 2026-07-03 09:59:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 09:59:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 09:59:59 --> Encryption Class Initialized
INFO - 2026-07-03 09:59:59 --> Form Validation Class Initialized
INFO - 2026-07-03 09:59:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 09:59:59 --> Pagination Class Initialized
INFO - 2026-07-03 09:59:59 --> Config Class Initialized
INFO - 2026-07-03 09:59:59 --> Hooks Class Initialized
DEBUG - 2026-07-03 09:59:59 --> UTF-8 Support Enabled
INFO - 2026-07-03 09:59:59 --> Utf8 Class Initialized
INFO - 2026-07-03 09:59:59 --> URI Class Initialized
INFO - 2026-07-03 09:59:59 --> Email Class Initialized
INFO - 2026-07-03 09:59:59 --> Router Class Initialized
INFO - 2026-07-03 09:59:59 --> Controller Class Initialized
DEBUG - 2026-07-03 09:59:59 --> Invoice MX_Controller Initialized
INFO - 2026-07-03 09:59:59 --> Output Class Initialized
INFO - 2026-07-03 09:59:59 --> Security Class Initialized
INFO - 2026-07-03 09:59:59 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 09:59:59 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 09:59:59 --> Model "Billing_model" initialized
DEBUG - 2026-07-03 09:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 09:59:59 --> CSRF cookie sent
INFO - 2026-07-03 09:59:59 --> Input Class Initialized
INFO - 2026-07-03 09:59:59 --> Language Class Initialized
INFO - 2026-07-03 09:59:59 --> Model "Common_model" initialized
INFO - 2026-07-03 09:59:59 --> Language Class Initialized
INFO - 2026-07-03 09:59:59 --> Config Class Initialized
INFO - 2026-07-03 09:59:59 --> Model "Invoice_model" initialized
INFO - 2026-07-03 09:59:59 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 09:59:59 --> Loader Class Initialized
INFO - 2026-07-03 09:59:59 --> Helper loaded: url_helper
INFO - 2026-07-03 09:59:59 --> Helper loaded: form_helper
INFO - 2026-07-03 09:59:59 --> Helper loaded: html_helper
INFO - 2026-07-03 09:59:59 --> Helper loaded: file_helper
INFO - 2026-07-03 09:59:59 --> Helper loaded: email_helper
INFO - 2026-07-03 09:59:59 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 09:59:59 --> Helper loaded: ssp_helper
INFO - 2026-07-03 09:59:59 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 09:59:59 --> Helper loaded: plesk_helper
INFO - 2026-07-03 09:59:59 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 09:59:59 --> Helper loaded: domain_helper
INFO - 2026-07-03 09:59:59 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 09:59:59 --> Database Driver Class Initialized
INFO - 2026-07-03 10:00:00 --> Final output sent to browser
DEBUG - 2026-07-03 10:00:00 --> Total execution time: 2.6415
INFO - 2026-07-03 10:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:00:00 --> Upload Class Initialized
DEBUG - 2026-07-03 10:00:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:00:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:00:00 --> Encryption Class Initialized
INFO - 2026-07-03 10:00:00 --> Form Validation Class Initialized
INFO - 2026-07-03 10:00:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:00:00 --> Pagination Class Initialized
INFO - 2026-07-03 10:00:00 --> Email Class Initialized
INFO - 2026-07-03 10:00:00 --> Controller Class Initialized
DEBUG - 2026-07-03 10:00:00 --> Order MX_Controller Initialized
INFO - 2026-07-03 10:00:00 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:00:00 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 10:00:00 --> Model "Order_model" initialized
INFO - 2026-07-03 10:00:00 --> Model "Common_model" initialized
INFO - 2026-07-03 10:00:00 --> Model "Currency_model" initialized
INFO - 2026-07-03 10:00:01 --> Final output sent to browser
DEBUG - 2026-07-03 10:00:01 --> Total execution time: 3.2632
INFO - 2026-07-03 10:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:00:01 --> Upload Class Initialized
DEBUG - 2026-07-03 10:00:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:00:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:00:01 --> Encryption Class Initialized
INFO - 2026-07-03 10:00:01 --> Form Validation Class Initialized
INFO - 2026-07-03 10:00:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:00:01 --> Pagination Class Initialized
INFO - 2026-07-03 10:00:01 --> Email Class Initialized
INFO - 2026-07-03 10:00:01 --> Controller Class Initialized
DEBUG - 2026-07-03 10:00:01 --> Ticket MX_Controller Initialized
INFO - 2026-07-03 10:00:01 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:00:01 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 10:00:01 --> Model "Support_model" initialized
INFO - 2026-07-03 10:00:01 --> Model "Common_model" initialized
INFO - 2026-07-03 10:00:01 --> Final output sent to browser
DEBUG - 2026-07-03 10:00:01 --> Total execution time: 3.9784
INFO - 2026-07-03 10:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:00:01 --> Upload Class Initialized
DEBUG - 2026-07-03 10:00:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:00:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:00:01 --> Encryption Class Initialized
INFO - 2026-07-03 10:00:01 --> Form Validation Class Initialized
INFO - 2026-07-03 10:00:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:00:01 --> Pagination Class Initialized
INFO - 2026-07-03 10:00:01 --> Email Class Initialized
INFO - 2026-07-03 10:00:01 --> Controller Class Initialized
DEBUG - 2026-07-03 10:00:01 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 10:00:01 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:00:01 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 10:00:02 --> Model "Dashboard_model" initialized
INFO - 2026-07-03 10:00:02 --> Final output sent to browser
DEBUG - 2026-07-03 10:00:02 --> Total execution time: 4.6781
INFO - 2026-07-03 10:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:00:02 --> Upload Class Initialized
DEBUG - 2026-07-03 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:00:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:00:02 --> Encryption Class Initialized
INFO - 2026-07-03 10:00:02 --> Form Validation Class Initialized
INFO - 2026-07-03 10:00:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:00:02 --> Pagination Class Initialized
INFO - 2026-07-03 10:00:02 --> Email Class Initialized
INFO - 2026-07-03 10:00:02 --> Controller Class Initialized
DEBUG - 2026-07-03 10:00:02 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 10:00:02 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:00:02 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 10:00:02 --> Model "Dashboard_model" initialized
INFO - 2026-07-03 10:00:03 --> Final output sent to browser
DEBUG - 2026-07-03 10:00:03 --> Total execution time: 5.2950
INFO - 2026-07-03 10:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:00:03 --> Upload Class Initialized
DEBUG - 2026-07-03 10:00:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:00:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:00:03 --> Encryption Class Initialized
INFO - 2026-07-03 10:00:03 --> Form Validation Class Initialized
INFO - 2026-07-03 10:00:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:00:03 --> Pagination Class Initialized
INFO - 2026-07-03 10:00:03 --> Email Class Initialized
INFO - 2026-07-03 10:00:03 --> Controller Class Initialized
ERROR - 2026-07-03 10:00:03 --> 404 Page Not Found: /index
INFO - 2026-07-03 10:02:59 --> Config Class Initialized
INFO - 2026-07-03 10:02:59 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:02:59 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:02:59 --> Utf8 Class Initialized
INFO - 2026-07-03 10:02:59 --> URI Class Initialized
INFO - 2026-07-03 10:02:59 --> Router Class Initialized
INFO - 2026-07-03 10:02:59 --> Output Class Initialized
INFO - 2026-07-03 10:02:59 --> Security Class Initialized
DEBUG - 2026-07-03 10:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:02:59 --> CSRF cookie sent
INFO - 2026-07-03 10:02:59 --> Input Class Initialized
INFO - 2026-07-03 10:02:59 --> Language Class Initialized
INFO - 2026-07-03 10:02:59 --> Language Class Initialized
INFO - 2026-07-03 10:02:59 --> Config Class Initialized
INFO - 2026-07-03 10:02:59 --> Loader Class Initialized
INFO - 2026-07-03 10:02:59 --> Helper loaded: url_helper
INFO - 2026-07-03 10:02:59 --> Helper loaded: form_helper
INFO - 2026-07-03 10:02:59 --> Helper loaded: html_helper
INFO - 2026-07-03 10:02:59 --> Helper loaded: file_helper
INFO - 2026-07-03 10:02:59 --> Helper loaded: email_helper
INFO - 2026-07-03 10:02:59 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:02:59 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:02:59 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:02:59 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:02:59 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:02:59 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:02:59 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:02:59 --> Database Driver Class Initialized
INFO - 2026-07-03 10:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:03:01 --> Upload Class Initialized
DEBUG - 2026-07-03 10:03:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:03:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:03:01 --> Encryption Class Initialized
INFO - 2026-07-03 10:03:01 --> Form Validation Class Initialized
INFO - 2026-07-03 10:03:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:03:01 --> Pagination Class Initialized
INFO - 2026-07-03 10:03:01 --> Email Class Initialized
INFO - 2026-07-03 10:03:01 --> Controller Class Initialized
DEBUG - 2026-07-03 10:03:01 --> Paymentgateway MX_Controller Initialized
INFO - 2026-07-03 10:03:01 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:03:01 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 10:03:01 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 10:03:01 --> Model "Payment_model" initialized
DEBUG - 2026-07-03 10:03:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 10:03:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 10:03:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 10:03:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-03 10:03:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 10:03:02 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/paymentgateway_list.php
INFO - 2026-07-03 10:03:02 --> Final output sent to browser
DEBUG - 2026-07-03 10:03:02 --> Total execution time: 2.7376
INFO - 2026-07-03 10:03:02 --> Config Class Initialized
INFO - 2026-07-03 10:03:02 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:03:02 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:03:02 --> Utf8 Class Initialized
INFO - 2026-07-03 10:03:02 --> URI Class Initialized
INFO - 2026-07-03 10:03:02 --> Router Class Initialized
INFO - 2026-07-03 10:03:02 --> Output Class Initialized
INFO - 2026-07-03 10:03:02 --> Security Class Initialized
DEBUG - 2026-07-03 10:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:03:02 --> CSRF cookie sent
INFO - 2026-07-03 10:03:02 --> Input Class Initialized
INFO - 2026-07-03 10:03:02 --> Language Class Initialized
INFO - 2026-07-03 10:03:02 --> Language Class Initialized
INFO - 2026-07-03 10:03:02 --> Config Class Initialized
INFO - 2026-07-03 10:03:02 --> Loader Class Initialized
INFO - 2026-07-03 10:03:02 --> Helper loaded: url_helper
INFO - 2026-07-03 10:03:02 --> Helper loaded: form_helper
INFO - 2026-07-03 10:03:02 --> Helper loaded: html_helper
INFO - 2026-07-03 10:03:02 --> Helper loaded: file_helper
INFO - 2026-07-03 10:03:02 --> Helper loaded: email_helper
INFO - 2026-07-03 10:03:02 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:03:02 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:03:02 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:03:02 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:03:02 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:03:02 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:03:02 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:03:02 --> Database Driver Class Initialized
INFO - 2026-07-03 10:03:03 --> Config Class Initialized
INFO - 2026-07-03 10:03:03 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:03:03 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:03:03 --> Utf8 Class Initialized
INFO - 2026-07-03 10:03:03 --> URI Class Initialized
INFO - 2026-07-03 10:03:03 --> Router Class Initialized
INFO - 2026-07-03 10:03:03 --> Output Class Initialized
INFO - 2026-07-03 10:03:03 --> Security Class Initialized
DEBUG - 2026-07-03 10:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:03:03 --> CSRF cookie sent
INFO - 2026-07-03 10:03:03 --> Input Class Initialized
INFO - 2026-07-03 10:03:03 --> Language Class Initialized
INFO - 2026-07-03 10:03:03 --> Language Class Initialized
INFO - 2026-07-03 10:03:03 --> Config Class Initialized
INFO - 2026-07-03 10:03:03 --> Loader Class Initialized
INFO - 2026-07-03 10:03:03 --> Helper loaded: url_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: form_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: html_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: file_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: email_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:03:03 --> Database Driver Class Initialized
INFO - 2026-07-03 10:03:03 --> Config Class Initialized
INFO - 2026-07-03 10:03:03 --> Hooks Class Initialized
INFO - 2026-07-03 10:03:03 --> Config Class Initialized
INFO - 2026-07-03 10:03:03 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:03:03 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:03:03 --> Utf8 Class Initialized
DEBUG - 2026-07-03 10:03:03 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:03:03 --> Utf8 Class Initialized
INFO - 2026-07-03 10:03:03 --> URI Class Initialized
INFO - 2026-07-03 10:03:03 --> URI Class Initialized
INFO - 2026-07-03 10:03:03 --> Router Class Initialized
INFO - 2026-07-03 10:03:03 --> Router Class Initialized
INFO - 2026-07-03 10:03:03 --> Output Class Initialized
INFO - 2026-07-03 10:03:03 --> Output Class Initialized
INFO - 2026-07-03 10:03:03 --> Security Class Initialized
DEBUG - 2026-07-03 10:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:03:03 --> CSRF cookie sent
INFO - 2026-07-03 10:03:03 --> Input Class Initialized
INFO - 2026-07-03 10:03:03 --> Security Class Initialized
INFO - 2026-07-03 10:03:03 --> Language Class Initialized
INFO - 2026-07-03 10:03:03 --> Language Class Initialized
INFO - 2026-07-03 10:03:03 --> Config Class Initialized
DEBUG - 2026-07-03 10:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:03:03 --> CSRF cookie sent
INFO - 2026-07-03 10:03:03 --> Input Class Initialized
INFO - 2026-07-03 10:03:03 --> Language Class Initialized
INFO - 2026-07-03 10:03:03 --> Language Class Initialized
INFO - 2026-07-03 10:03:03 --> Config Class Initialized
INFO - 2026-07-03 10:03:03 --> Loader Class Initialized
INFO - 2026-07-03 10:03:03 --> Helper loaded: url_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: form_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: html_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: file_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: email_helper
INFO - 2026-07-03 10:03:03 --> Loader Class Initialized
INFO - 2026-07-03 10:03:03 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: url_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: form_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: html_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: file_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: email_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:03:03 --> Database Driver Class Initialized
INFO - 2026-07-03 10:03:03 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:03:03 --> Database Driver Class Initialized
INFO - 2026-07-03 10:03:03 --> Config Class Initialized
INFO - 2026-07-03 10:03:03 --> Hooks Class Initialized
INFO - 2026-07-03 10:03:03 --> Config Class Initialized
INFO - 2026-07-03 10:03:03 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:03:03 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:03:03 --> Utf8 Class Initialized
INFO - 2026-07-03 10:03:03 --> URI Class Initialized
DEBUG - 2026-07-03 10:03:03 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:03:03 --> Utf8 Class Initialized
INFO - 2026-07-03 10:03:03 --> URI Class Initialized
INFO - 2026-07-03 10:03:03 --> Router Class Initialized
INFO - 2026-07-03 10:03:03 --> Output Class Initialized
INFO - 2026-07-03 10:03:03 --> Router Class Initialized
INFO - 2026-07-03 10:03:03 --> Security Class Initialized
INFO - 2026-07-03 10:03:03 --> Output Class Initialized
DEBUG - 2026-07-03 10:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:03:03 --> CSRF cookie sent
INFO - 2026-07-03 10:03:03 --> Input Class Initialized
INFO - 2026-07-03 10:03:03 --> Language Class Initialized
INFO - 2026-07-03 10:03:03 --> Security Class Initialized
INFO - 2026-07-03 10:03:03 --> Language Class Initialized
INFO - 2026-07-03 10:03:03 --> Config Class Initialized
DEBUG - 2026-07-03 10:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:03:03 --> CSRF cookie sent
INFO - 2026-07-03 10:03:03 --> Input Class Initialized
INFO - 2026-07-03 10:03:03 --> Language Class Initialized
INFO - 2026-07-03 10:03:03 --> Language Class Initialized
INFO - 2026-07-03 10:03:03 --> Config Class Initialized
INFO - 2026-07-03 10:03:03 --> Loader Class Initialized
INFO - 2026-07-03 10:03:03 --> Helper loaded: url_helper
INFO - 2026-07-03 10:03:03 --> Loader Class Initialized
INFO - 2026-07-03 10:03:03 --> Helper loaded: url_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: form_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: html_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: file_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: email_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: form_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: html_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: file_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: email_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:03:03 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:03:03 --> Database Driver Class Initialized
INFO - 2026-07-03 10:03:03 --> Database Driver Class Initialized
INFO - 2026-07-03 10:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:03:04 --> Upload Class Initialized
DEBUG - 2026-07-03 10:03:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:03:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:03:04 --> Encryption Class Initialized
INFO - 2026-07-03 10:03:04 --> Form Validation Class Initialized
INFO - 2026-07-03 10:03:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:03:04 --> Pagination Class Initialized
INFO - 2026-07-03 10:03:04 --> Email Class Initialized
INFO - 2026-07-03 10:03:04 --> Controller Class Initialized
ERROR - 2026-07-03 10:03:04 --> 404 Page Not Found: /index
INFO - 2026-07-03 10:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:03:04 --> Upload Class Initialized
DEBUG - 2026-07-03 10:03:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:03:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:03:04 --> Encryption Class Initialized
INFO - 2026-07-03 10:03:04 --> Form Validation Class Initialized
INFO - 2026-07-03 10:03:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:03:04 --> Pagination Class Initialized
INFO - 2026-07-03 10:03:04 --> Config Class Initialized
INFO - 2026-07-03 10:03:04 --> Hooks Class Initialized
INFO - 2026-07-03 10:03:04 --> Email Class Initialized
INFO - 2026-07-03 10:03:04 --> Controller Class Initialized
ERROR - 2026-07-03 10:03:04 --> 404 Page Not Found: /index
DEBUG - 2026-07-03 10:03:04 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:03:04 --> Utf8 Class Initialized
INFO - 2026-07-03 10:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:03:04 --> URI Class Initialized
INFO - 2026-07-03 10:03:04 --> Router Class Initialized
INFO - 2026-07-03 10:03:04 --> Upload Class Initialized
INFO - 2026-07-03 10:03:04 --> Output Class Initialized
DEBUG - 2026-07-03 10:03:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:03:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:03:04 --> Encryption Class Initialized
INFO - 2026-07-03 10:03:04 --> Security Class Initialized
DEBUG - 2026-07-03 10:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:03:04 --> CSRF cookie sent
INFO - 2026-07-03 10:03:04 --> Input Class Initialized
INFO - 2026-07-03 10:03:04 --> Language Class Initialized
INFO - 2026-07-03 10:03:04 --> Form Validation Class Initialized
INFO - 2026-07-03 10:03:04 --> Language Class Initialized
INFO - 2026-07-03 10:03:04 --> Config Class Initialized
INFO - 2026-07-03 10:03:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:03:04 --> Pagination Class Initialized
INFO - 2026-07-03 10:03:04 --> Loader Class Initialized
INFO - 2026-07-03 10:03:04 --> Helper loaded: url_helper
INFO - 2026-07-03 10:03:04 --> Email Class Initialized
INFO - 2026-07-03 10:03:04 --> Controller Class Initialized
INFO - 2026-07-03 10:03:04 --> Helper loaded: form_helper
ERROR - 2026-07-03 10:03:04 --> 404 Page Not Found: /index
INFO - 2026-07-03 10:03:04 --> Helper loaded: html_helper
INFO - 2026-07-03 10:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:03:04 --> Helper loaded: file_helper
INFO - 2026-07-03 10:03:04 --> Helper loaded: email_helper
INFO - 2026-07-03 10:03:04 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:03:04 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:03:04 --> Upload Class Initialized
INFO - 2026-07-03 10:03:04 --> Helper loaded: cpanel_helper
DEBUG - 2026-07-03 10:03:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:03:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:03:04 --> Encryption Class Initialized
INFO - 2026-07-03 10:03:04 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:03:04 --> Form Validation Class Initialized
INFO - 2026-07-03 10:03:04 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:03:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:03:04 --> Pagination Class Initialized
INFO - 2026-07-03 10:03:04 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:03:04 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:03:04 --> Email Class Initialized
INFO - 2026-07-03 10:03:04 --> Controller Class Initialized
ERROR - 2026-07-03 10:03:04 --> 404 Page Not Found: /index
INFO - 2026-07-03 10:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:03:04 --> Upload Class Initialized
INFO - 2026-07-03 10:03:04 --> Database Driver Class Initialized
DEBUG - 2026-07-03 10:03:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:03:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:03:04 --> Encryption Class Initialized
INFO - 2026-07-03 10:03:04 --> Form Validation Class Initialized
INFO - 2026-07-03 10:03:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:03:04 --> Pagination Class Initialized
INFO - 2026-07-03 10:03:04 --> Email Class Initialized
INFO - 2026-07-03 10:03:04 --> Controller Class Initialized
ERROR - 2026-07-03 10:03:04 --> 404 Page Not Found: /index
INFO - 2026-07-03 10:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:03:05 --> Upload Class Initialized
DEBUG - 2026-07-03 10:03:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:03:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:03:05 --> Encryption Class Initialized
INFO - 2026-07-03 10:03:05 --> Form Validation Class Initialized
INFO - 2026-07-03 10:03:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:03:05 --> Pagination Class Initialized
INFO - 2026-07-03 10:03:05 --> Email Class Initialized
INFO - 2026-07-03 10:03:05 --> Controller Class Initialized
ERROR - 2026-07-03 10:03:05 --> 404 Page Not Found: /index
INFO - 2026-07-03 10:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:03:06 --> Upload Class Initialized
DEBUG - 2026-07-03 10:03:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:03:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:03:06 --> Encryption Class Initialized
INFO - 2026-07-03 10:03:06 --> Form Validation Class Initialized
INFO - 2026-07-03 10:03:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:03:06 --> Pagination Class Initialized
INFO - 2026-07-03 10:03:06 --> Email Class Initialized
INFO - 2026-07-03 10:03:06 --> Controller Class Initialized
ERROR - 2026-07-03 10:03:06 --> 404 Page Not Found: /index
INFO - 2026-07-03 10:03:10 --> Config Class Initialized
INFO - 2026-07-03 10:03:10 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:03:10 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:03:10 --> Utf8 Class Initialized
INFO - 2026-07-03 10:03:10 --> URI Class Initialized
INFO - 2026-07-03 10:03:10 --> Router Class Initialized
INFO - 2026-07-03 10:03:10 --> Output Class Initialized
INFO - 2026-07-03 10:03:10 --> Security Class Initialized
DEBUG - 2026-07-03 10:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:03:10 --> CSRF cookie sent
INFO - 2026-07-03 10:03:10 --> CSRF token verified
INFO - 2026-07-03 10:03:10 --> Input Class Initialized
INFO - 2026-07-03 10:03:10 --> Language Class Initialized
INFO - 2026-07-03 10:03:10 --> Language Class Initialized
INFO - 2026-07-03 10:03:10 --> Config Class Initialized
INFO - 2026-07-03 10:03:10 --> Loader Class Initialized
INFO - 2026-07-03 10:03:10 --> Helper loaded: url_helper
INFO - 2026-07-03 10:03:10 --> Helper loaded: form_helper
INFO - 2026-07-03 10:03:10 --> Helper loaded: html_helper
INFO - 2026-07-03 10:03:10 --> Helper loaded: file_helper
INFO - 2026-07-03 10:03:10 --> Helper loaded: email_helper
INFO - 2026-07-03 10:03:10 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:03:10 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:03:10 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:03:10 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:03:10 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:03:10 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:03:10 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:03:10 --> Database Driver Class Initialized
INFO - 2026-07-03 10:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:03:12 --> Upload Class Initialized
DEBUG - 2026-07-03 10:03:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:03:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:03:12 --> Encryption Class Initialized
INFO - 2026-07-03 10:03:12 --> Form Validation Class Initialized
INFO - 2026-07-03 10:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:03:12 --> Pagination Class Initialized
INFO - 2026-07-03 10:03:12 --> Email Class Initialized
INFO - 2026-07-03 10:03:12 --> Controller Class Initialized
DEBUG - 2026-07-03 10:03:12 --> Paymentgateway MX_Controller Initialized
INFO - 2026-07-03 10:03:12 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:03:12 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 10:03:12 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 10:03:12 --> Model "Payment_model" initialized
INFO - 2026-07-03 10:03:13 --> Final output sent to browser
DEBUG - 2026-07-03 10:03:13 --> Total execution time: 3.7107
INFO - 2026-07-03 10:03:20 --> Config Class Initialized
INFO - 2026-07-03 10:03:20 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:03:20 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:03:20 --> Utf8 Class Initialized
INFO - 2026-07-03 10:03:20 --> URI Class Initialized
INFO - 2026-07-03 10:03:20 --> Router Class Initialized
INFO - 2026-07-03 10:03:20 --> Output Class Initialized
INFO - 2026-07-03 10:03:20 --> Security Class Initialized
DEBUG - 2026-07-03 10:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:03:20 --> CSRF cookie sent
INFO - 2026-07-03 10:03:20 --> Input Class Initialized
INFO - 2026-07-03 10:03:20 --> Language Class Initialized
INFO - 2026-07-03 10:03:20 --> Language Class Initialized
INFO - 2026-07-03 10:03:20 --> Config Class Initialized
INFO - 2026-07-03 10:03:20 --> Loader Class Initialized
INFO - 2026-07-03 10:03:20 --> Helper loaded: url_helper
INFO - 2026-07-03 10:03:20 --> Helper loaded: form_helper
INFO - 2026-07-03 10:03:20 --> Helper loaded: html_helper
INFO - 2026-07-03 10:03:20 --> Helper loaded: file_helper
INFO - 2026-07-03 10:03:20 --> Helper loaded: email_helper
INFO - 2026-07-03 10:03:20 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:03:20 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:03:20 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:03:20 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:03:20 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:03:20 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:03:20 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:03:20 --> Database Driver Class Initialized
INFO - 2026-07-03 10:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:03:21 --> Upload Class Initialized
DEBUG - 2026-07-03 10:03:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:03:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:03:21 --> Encryption Class Initialized
INFO - 2026-07-03 10:03:21 --> Form Validation Class Initialized
INFO - 2026-07-03 10:03:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:03:21 --> Pagination Class Initialized
INFO - 2026-07-03 10:03:21 --> Email Class Initialized
INFO - 2026-07-03 10:03:21 --> Controller Class Initialized
DEBUG - 2026-07-03 10:03:21 --> Billing MX_Controller Initialized
INFO - 2026-07-03 10:03:21 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:03:21 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:03:21 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:03:21 --> Model "Billing_model" initialized
INFO - 2026-07-03 10:03:21 --> Model "Common_model" initialized
INFO - 2026-07-03 10:03:21 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-03 10:03:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_invoice_pdf_html.php
DEBUG - 2026-07-03 10:03:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 10:03:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-07-03 10:03:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 10:03:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 10:03:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_viewinvoice.php
INFO - 2026-07-03 10:03:23 --> Final output sent to browser
DEBUG - 2026-07-03 10:03:23 --> Total execution time: 3.4779
INFO - 2026-07-03 10:03:23 --> Config Class Initialized
INFO - 2026-07-03 10:03:23 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:03:23 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:03:23 --> Utf8 Class Initialized
INFO - 2026-07-03 10:03:23 --> URI Class Initialized
INFO - 2026-07-03 10:03:23 --> Router Class Initialized
INFO - 2026-07-03 10:03:23 --> Output Class Initialized
INFO - 2026-07-03 10:03:23 --> Security Class Initialized
DEBUG - 2026-07-03 10:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:03:23 --> CSRF cookie sent
INFO - 2026-07-03 10:03:23 --> Input Class Initialized
INFO - 2026-07-03 10:03:23 --> Language Class Initialized
INFO - 2026-07-03 10:03:23 --> Language Class Initialized
INFO - 2026-07-03 10:03:23 --> Config Class Initialized
INFO - 2026-07-03 10:03:23 --> Loader Class Initialized
INFO - 2026-07-03 10:03:23 --> Helper loaded: url_helper
INFO - 2026-07-03 10:03:23 --> Helper loaded: form_helper
INFO - 2026-07-03 10:03:23 --> Helper loaded: html_helper
INFO - 2026-07-03 10:03:23 --> Helper loaded: file_helper
INFO - 2026-07-03 10:03:23 --> Helper loaded: email_helper
INFO - 2026-07-03 10:03:23 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:03:23 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:03:23 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:03:23 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:03:23 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:03:23 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:03:23 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:03:23 --> Database Driver Class Initialized
INFO - 2026-07-03 10:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:03:25 --> Upload Class Initialized
DEBUG - 2026-07-03 10:03:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:03:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:03:25 --> Encryption Class Initialized
INFO - 2026-07-03 10:03:25 --> Form Validation Class Initialized
INFO - 2026-07-03 10:03:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:03:25 --> Pagination Class Initialized
INFO - 2026-07-03 10:03:25 --> Email Class Initialized
INFO - 2026-07-03 10:03:25 --> Controller Class Initialized
DEBUG - 2026-07-03 10:03:25 --> Cart MX_Controller Initialized
INFO - 2026-07-03 10:03:25 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:03:25 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:03:25 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:03:25 --> Model "Common_model" initialized
INFO - 2026-07-03 10:03:25 --> Model "Order_model" initialized
INFO - 2026-07-03 10:03:25 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 10:03:25 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 10:03:25 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 10:03:25 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 10:03:25 --> Model "Plan_model" initialized
INFO - 2026-07-03 10:03:25 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 10:03:26 --> Final output sent to browser
DEBUG - 2026-07-03 10:03:26 --> Total execution time: 2.3444
INFO - 2026-07-03 10:03:36 --> Config Class Initialized
INFO - 2026-07-03 10:03:36 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:03:36 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:03:36 --> Utf8 Class Initialized
INFO - 2026-07-03 10:03:36 --> URI Class Initialized
INFO - 2026-07-03 10:03:36 --> Router Class Initialized
INFO - 2026-07-03 10:03:36 --> Output Class Initialized
INFO - 2026-07-03 10:03:36 --> Security Class Initialized
DEBUG - 2026-07-03 10:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:03:36 --> CSRF cookie sent
INFO - 2026-07-03 10:03:36 --> Input Class Initialized
INFO - 2026-07-03 10:03:36 --> Language Class Initialized
INFO - 2026-07-03 10:03:36 --> Language Class Initialized
INFO - 2026-07-03 10:03:36 --> Config Class Initialized
INFO - 2026-07-03 10:03:36 --> Loader Class Initialized
INFO - 2026-07-03 10:03:36 --> Helper loaded: url_helper
INFO - 2026-07-03 10:03:36 --> Helper loaded: form_helper
INFO - 2026-07-03 10:03:36 --> Helper loaded: html_helper
INFO - 2026-07-03 10:03:36 --> Helper loaded: file_helper
INFO - 2026-07-03 10:03:36 --> Helper loaded: email_helper
INFO - 2026-07-03 10:03:36 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:03:36 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:03:36 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:03:36 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:03:36 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:03:36 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:03:36 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:03:36 --> Database Driver Class Initialized
INFO - 2026-07-03 10:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:03:38 --> Upload Class Initialized
DEBUG - 2026-07-03 10:03:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:03:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:03:38 --> Encryption Class Initialized
INFO - 2026-07-03 10:03:38 --> Form Validation Class Initialized
INFO - 2026-07-03 10:03:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:03:38 --> Pagination Class Initialized
INFO - 2026-07-03 10:03:38 --> Email Class Initialized
INFO - 2026-07-03 10:03:38 --> Controller Class Initialized
DEBUG - 2026-07-03 10:03:38 --> Billing MX_Controller Initialized
INFO - 2026-07-03 10:03:38 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:03:38 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:03:38 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:03:38 --> Model "Billing_model" initialized
INFO - 2026-07-03 10:03:38 --> Model "Common_model" initialized
INFO - 2026-07-03 10:03:38 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-03 10:03:39 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_invoice_pdf_html.php
INFO - 2026-07-03 10:03:40 --> Final output sent to browser
DEBUG - 2026-07-03 10:03:40 --> Total execution time: 3.5209
INFO - 2026-07-03 10:03:49 --> Config Class Initialized
INFO - 2026-07-03 10:03:49 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:03:49 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:03:49 --> Utf8 Class Initialized
INFO - 2026-07-03 10:03:49 --> URI Class Initialized
INFO - 2026-07-03 10:03:49 --> Router Class Initialized
INFO - 2026-07-03 10:03:49 --> Output Class Initialized
INFO - 2026-07-03 10:03:49 --> Security Class Initialized
DEBUG - 2026-07-03 10:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:03:49 --> CSRF cookie sent
INFO - 2026-07-03 10:03:49 --> Input Class Initialized
INFO - 2026-07-03 10:03:49 --> Language Class Initialized
INFO - 2026-07-03 10:03:49 --> Language Class Initialized
INFO - 2026-07-03 10:03:49 --> Config Class Initialized
INFO - 2026-07-03 10:03:49 --> Loader Class Initialized
INFO - 2026-07-03 10:03:49 --> Helper loaded: url_helper
INFO - 2026-07-03 10:03:49 --> Helper loaded: form_helper
INFO - 2026-07-03 10:03:49 --> Helper loaded: html_helper
INFO - 2026-07-03 10:03:49 --> Helper loaded: file_helper
INFO - 2026-07-03 10:03:49 --> Helper loaded: email_helper
INFO - 2026-07-03 10:03:49 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:03:49 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:03:49 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:03:49 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:03:49 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:03:49 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:03:49 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:03:49 --> Database Driver Class Initialized
INFO - 2026-07-03 10:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:03:51 --> Upload Class Initialized
DEBUG - 2026-07-03 10:03:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:03:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:03:51 --> Encryption Class Initialized
INFO - 2026-07-03 10:03:51 --> Form Validation Class Initialized
INFO - 2026-07-03 10:03:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:03:51 --> Pagination Class Initialized
INFO - 2026-07-03 10:03:51 --> Email Class Initialized
INFO - 2026-07-03 10:03:51 --> Controller Class Initialized
DEBUG - 2026-07-03 10:03:51 --> Pay MX_Controller Initialized
INFO - 2026-07-03 10:03:51 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:03:51 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:03:51 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:03:51 --> Model "Payment_model" initialized
INFO - 2026-07-03 10:03:51 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 10:03:51 --> Model "Billing_model" initialized
INFO - 2026-07-03 10:03:51 --> Model "Invoice_model" initialized
DEBUG - 2026-07-03 10:03:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 10:03:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 10:03:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 10:03:53 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_pay.php
INFO - 2026-07-03 10:03:53 --> Final output sent to browser
DEBUG - 2026-07-03 10:03:53 --> Total execution time: 4.3742
INFO - 2026-07-03 10:03:54 --> Config Class Initialized
INFO - 2026-07-03 10:03:54 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:03:54 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:03:54 --> Utf8 Class Initialized
INFO - 2026-07-03 10:03:54 --> URI Class Initialized
INFO - 2026-07-03 10:03:54 --> Router Class Initialized
INFO - 2026-07-03 10:03:54 --> Output Class Initialized
INFO - 2026-07-03 10:03:54 --> Security Class Initialized
DEBUG - 2026-07-03 10:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:03:54 --> CSRF cookie sent
INFO - 2026-07-03 10:03:54 --> Input Class Initialized
INFO - 2026-07-03 10:03:54 --> Language Class Initialized
INFO - 2026-07-03 10:03:54 --> Language Class Initialized
INFO - 2026-07-03 10:03:54 --> Config Class Initialized
INFO - 2026-07-03 10:03:54 --> Loader Class Initialized
INFO - 2026-07-03 10:03:54 --> Helper loaded: url_helper
INFO - 2026-07-03 10:03:54 --> Helper loaded: form_helper
INFO - 2026-07-03 10:03:54 --> Helper loaded: html_helper
INFO - 2026-07-03 10:03:54 --> Helper loaded: file_helper
INFO - 2026-07-03 10:03:54 --> Helper loaded: email_helper
INFO - 2026-07-03 10:03:54 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:03:54 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:03:54 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:03:54 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:03:54 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:03:54 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:03:54 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:03:54 --> Database Driver Class Initialized
INFO - 2026-07-03 10:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:03:55 --> Upload Class Initialized
DEBUG - 2026-07-03 10:03:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:03:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:03:55 --> Encryption Class Initialized
INFO - 2026-07-03 10:03:55 --> Form Validation Class Initialized
INFO - 2026-07-03 10:03:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:03:55 --> Pagination Class Initialized
INFO - 2026-07-03 10:03:55 --> Email Class Initialized
INFO - 2026-07-03 10:03:55 --> Controller Class Initialized
DEBUG - 2026-07-03 10:03:55 --> Cart MX_Controller Initialized
INFO - 2026-07-03 10:03:55 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:03:55 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:03:55 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:03:55 --> Model "Common_model" initialized
INFO - 2026-07-03 10:03:55 --> Model "Order_model" initialized
INFO - 2026-07-03 10:03:55 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 10:03:55 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 10:03:55 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 10:03:55 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 10:03:55 --> Model "Plan_model" initialized
INFO - 2026-07-03 10:03:55 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 10:03:56 --> Final output sent to browser
DEBUG - 2026-07-03 10:03:56 --> Total execution time: 1.8734
INFO - 2026-07-03 10:03:56 --> Config Class Initialized
INFO - 2026-07-03 10:03:56 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:03:56 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:03:56 --> Utf8 Class Initialized
INFO - 2026-07-03 10:03:56 --> URI Class Initialized
INFO - 2026-07-03 10:03:56 --> Router Class Initialized
INFO - 2026-07-03 10:03:56 --> Output Class Initialized
INFO - 2026-07-03 10:03:56 --> Security Class Initialized
DEBUG - 2026-07-03 10:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:03:56 --> CSRF cookie sent
INFO - 2026-07-03 10:03:56 --> Input Class Initialized
INFO - 2026-07-03 10:03:56 --> Language Class Initialized
INFO - 2026-07-03 10:03:56 --> Language Class Initialized
INFO - 2026-07-03 10:03:56 --> Config Class Initialized
INFO - 2026-07-03 10:03:56 --> Loader Class Initialized
INFO - 2026-07-03 10:03:56 --> Helper loaded: url_helper
INFO - 2026-07-03 10:03:56 --> Helper loaded: form_helper
INFO - 2026-07-03 10:03:56 --> Helper loaded: html_helper
INFO - 2026-07-03 10:03:56 --> Helper loaded: file_helper
INFO - 2026-07-03 10:03:56 --> Helper loaded: email_helper
INFO - 2026-07-03 10:03:56 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:03:56 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:03:56 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:03:56 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:03:56 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:03:56 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:03:56 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:03:56 --> Database Driver Class Initialized
INFO - 2026-07-03 10:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:03:57 --> Upload Class Initialized
DEBUG - 2026-07-03 10:03:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:03:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:03:57 --> Encryption Class Initialized
INFO - 2026-07-03 10:03:57 --> Form Validation Class Initialized
INFO - 2026-07-03 10:03:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:03:57 --> Pagination Class Initialized
INFO - 2026-07-03 10:03:57 --> Email Class Initialized
INFO - 2026-07-03 10:03:57 --> Controller Class Initialized
DEBUG - 2026-07-03 10:03:57 --> Subscription MX_Controller Initialized
INFO - 2026-07-03 10:03:57 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:03:57 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:03:57 --> Model "Cart_model" initialized
DEBUG - 2026-07-03 10:03:57 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 10:03:57 --> Model "Plan_model" initialized
INFO - 2026-07-03 10:03:58 --> Model "Order_model" initialized
INFO - 2026-07-03 10:03:58 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 10:03:58 --> Model "Subscription_model" initialized
INFO - 2026-07-03 10:03:58 --> Model "Software_model" initialized
INFO - 2026-07-03 10:03:58 --> Config Class Initialized
INFO - 2026-07-03 10:03:58 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:03:58 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:03:58 --> Utf8 Class Initialized
INFO - 2026-07-03 10:03:58 --> URI Class Initialized
INFO - 2026-07-03 10:03:58 --> Router Class Initialized
INFO - 2026-07-03 10:03:58 --> Output Class Initialized
INFO - 2026-07-03 10:03:58 --> Security Class Initialized
DEBUG - 2026-07-03 10:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:03:58 --> CSRF cookie sent
INFO - 2026-07-03 10:03:58 --> Input Class Initialized
INFO - 2026-07-03 10:03:58 --> Language Class Initialized
INFO - 2026-07-03 10:03:58 --> Language Class Initialized
INFO - 2026-07-03 10:03:58 --> Config Class Initialized
INFO - 2026-07-03 10:03:58 --> Loader Class Initialized
INFO - 2026-07-03 10:03:58 --> Helper loaded: url_helper
INFO - 2026-07-03 10:03:58 --> Helper loaded: form_helper
INFO - 2026-07-03 10:03:58 --> Helper loaded: html_helper
INFO - 2026-07-03 10:03:58 --> Helper loaded: file_helper
INFO - 2026-07-03 10:03:58 --> Helper loaded: email_helper
INFO - 2026-07-03 10:03:58 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:03:58 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:03:58 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:03:58 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:03:58 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:03:58 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:03:58 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:03:58 --> Database Driver Class Initialized
INFO - 2026-07-03 10:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:04:00 --> Upload Class Initialized
DEBUG - 2026-07-03 10:04:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:04:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:04:00 --> Encryption Class Initialized
INFO - 2026-07-03 10:04:00 --> Form Validation Class Initialized
INFO - 2026-07-03 10:04:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:04:00 --> Pagination Class Initialized
INFO - 2026-07-03 10:04:00 --> Email Class Initialized
INFO - 2026-07-03 10:04:00 --> Controller Class Initialized
DEBUG - 2026-07-03 10:04:00 --> Clientarea MX_Controller Initialized
INFO - 2026-07-03 10:04:00 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:04:00 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:04:00 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:04:00 --> Model "Clientarea_model" initialized
INFO - 2026-07-03 10:04:00 --> Model "Billing_model" initialized
INFO - 2026-07-03 10:04:00 --> Model "Common_model" initialized
INFO - 2026-07-03 10:04:00 --> Model "Order_model" initialized
INFO - 2026-07-03 10:04:00 --> Model "Support_model" initialized
INFO - 2026-07-03 10:04:00 --> Model "Subscription_model" initialized
INFO - 2026-07-03 10:04:00 --> Model "Software_model" initialized
DEBUG - 2026-07-03 10:04:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 10:04:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 10:04:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 10:04:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_index.php
INFO - 2026-07-03 10:04:01 --> Final output sent to browser
DEBUG - 2026-07-03 10:04:01 --> Total execution time: 2.7404
INFO - 2026-07-03 10:04:01 --> Config Class Initialized
INFO - 2026-07-03 10:04:01 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:04:01 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:04:01 --> Utf8 Class Initialized
INFO - 2026-07-03 10:04:01 --> URI Class Initialized
INFO - 2026-07-03 10:04:01 --> Router Class Initialized
INFO - 2026-07-03 10:04:01 --> Output Class Initialized
INFO - 2026-07-03 10:04:01 --> Security Class Initialized
DEBUG - 2026-07-03 10:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:04:01 --> CSRF cookie sent
INFO - 2026-07-03 10:04:01 --> Input Class Initialized
INFO - 2026-07-03 10:04:01 --> Language Class Initialized
INFO - 2026-07-03 10:04:01 --> Language Class Initialized
INFO - 2026-07-03 10:04:01 --> Config Class Initialized
INFO - 2026-07-03 10:04:01 --> Loader Class Initialized
INFO - 2026-07-03 10:04:01 --> Helper loaded: url_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: form_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: html_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: file_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: email_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:04:01 --> Config Class Initialized
INFO - 2026-07-03 10:04:01 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:04:01 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:04:01 --> Utf8 Class Initialized
INFO - 2026-07-03 10:04:01 --> URI Class Initialized
INFO - 2026-07-03 10:04:01 --> Config Class Initialized
INFO - 2026-07-03 10:04:01 --> Hooks Class Initialized
INFO - 2026-07-03 10:04:01 --> Config Class Initialized
INFO - 2026-07-03 10:04:01 --> Hooks Class Initialized
INFO - 2026-07-03 10:04:01 --> Router Class Initialized
DEBUG - 2026-07-03 10:04:01 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:04:01 --> Utf8 Class Initialized
DEBUG - 2026-07-03 10:04:01 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:04:01 --> Utf8 Class Initialized
INFO - 2026-07-03 10:04:01 --> URI Class Initialized
INFO - 2026-07-03 10:04:01 --> Output Class Initialized
INFO - 2026-07-03 10:04:01 --> Database Driver Class Initialized
INFO - 2026-07-03 10:04:01 --> URI Class Initialized
INFO - 2026-07-03 10:04:01 --> Router Class Initialized
INFO - 2026-07-03 10:04:01 --> Security Class Initialized
INFO - 2026-07-03 10:04:01 --> Output Class Initialized
DEBUG - 2026-07-03 10:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:04:01 --> Router Class Initialized
INFO - 2026-07-03 10:04:01 --> Input Class Initialized
INFO - 2026-07-03 10:04:01 --> Language Class Initialized
INFO - 2026-07-03 10:04:01 --> Security Class Initialized
INFO - 2026-07-03 10:04:01 --> Language Class Initialized
INFO - 2026-07-03 10:04:01 --> Config Class Initialized
DEBUG - 2026-07-03 10:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:04:01 --> Input Class Initialized
INFO - 2026-07-03 10:04:01 --> Output Class Initialized
INFO - 2026-07-03 10:04:01 --> Language Class Initialized
INFO - 2026-07-03 10:04:01 --> Language Class Initialized
INFO - 2026-07-03 10:04:01 --> Config Class Initialized
INFO - 2026-07-03 10:04:01 --> Security Class Initialized
INFO - 2026-07-03 10:04:01 --> Loader Class Initialized
DEBUG - 2026-07-03 10:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:04:01 --> Input Class Initialized
INFO - 2026-07-03 10:04:01 --> Loader Class Initialized
INFO - 2026-07-03 10:04:01 --> Helper loaded: url_helper
INFO - 2026-07-03 10:04:01 --> Language Class Initialized
INFO - 2026-07-03 10:04:01 --> Helper loaded: url_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: form_helper
INFO - 2026-07-03 10:04:01 --> Language Class Initialized
INFO - 2026-07-03 10:04:01 --> Config Class Initialized
INFO - 2026-07-03 10:04:01 --> Helper loaded: html_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: form_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: html_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: file_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: email_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: file_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: email_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:04:01 --> Loader Class Initialized
INFO - 2026-07-03 10:04:01 --> Helper loaded: url_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: form_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: html_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: file_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: email_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:04:01 --> Database Driver Class Initialized
INFO - 2026-07-03 10:04:01 --> Database Driver Class Initialized
INFO - 2026-07-03 10:04:01 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:04:01 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:04:01 --> Database Driver Class Initialized
INFO - 2026-07-03 10:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:04:03 --> Upload Class Initialized
DEBUG - 2026-07-03 10:04:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:04:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:04:03 --> Encryption Class Initialized
INFO - 2026-07-03 10:04:03 --> Form Validation Class Initialized
INFO - 2026-07-03 10:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:04:03 --> Pagination Class Initialized
INFO - 2026-07-03 10:04:03 --> Email Class Initialized
INFO - 2026-07-03 10:04:03 --> Controller Class Initialized
DEBUG - 2026-07-03 10:04:03 --> Tickets MX_Controller Initialized
INFO - 2026-07-03 10:04:03 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:04:03 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:04:03 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:04:03 --> Model "Support_model" initialized
INFO - 2026-07-03 10:04:03 --> Model "Common_model" initialized
INFO - 2026-07-03 10:04:03 --> Final output sent to browser
DEBUG - 2026-07-03 10:04:03 --> Total execution time: 2.1627
INFO - 2026-07-03 10:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:04:03 --> Upload Class Initialized
DEBUG - 2026-07-03 10:04:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:04:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:04:03 --> Encryption Class Initialized
INFO - 2026-07-03 10:04:03 --> Form Validation Class Initialized
INFO - 2026-07-03 10:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:04:03 --> Pagination Class Initialized
INFO - 2026-07-03 10:04:03 --> Email Class Initialized
INFO - 2026-07-03 10:04:03 --> Controller Class Initialized
DEBUG - 2026-07-03 10:04:03 --> Clientarea MX_Controller Initialized
INFO - 2026-07-03 10:04:03 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:04:03 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:04:03 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:04:03 --> Model "Clientarea_model" initialized
INFO - 2026-07-03 10:04:03 --> Model "Billing_model" initialized
INFO - 2026-07-03 10:04:03 --> Model "Common_model" initialized
INFO - 2026-07-03 10:04:03 --> Model "Order_model" initialized
INFO - 2026-07-03 10:04:03 --> Model "Support_model" initialized
INFO - 2026-07-03 10:04:05 --> Final output sent to browser
DEBUG - 2026-07-03 10:04:05 --> Total execution time: 3.5967
INFO - 2026-07-03 10:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:04:05 --> Upload Class Initialized
DEBUG - 2026-07-03 10:04:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:04:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:04:05 --> Encryption Class Initialized
INFO - 2026-07-03 10:04:05 --> Form Validation Class Initialized
INFO - 2026-07-03 10:04:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:04:05 --> Pagination Class Initialized
INFO - 2026-07-03 10:04:05 --> Email Class Initialized
INFO - 2026-07-03 10:04:05 --> Controller Class Initialized
DEBUG - 2026-07-03 10:04:05 --> Billing MX_Controller Initialized
INFO - 2026-07-03 10:04:05 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:04:05 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:04:05 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:04:05 --> Model "Billing_model" initialized
INFO - 2026-07-03 10:04:05 --> Model "Common_model" initialized
INFO - 2026-07-03 10:04:05 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 10:04:05 --> Config Class Initialized
INFO - 2026-07-03 10:04:05 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:04:05 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:04:05 --> Utf8 Class Initialized
INFO - 2026-07-03 10:04:05 --> URI Class Initialized
INFO - 2026-07-03 10:04:05 --> Router Class Initialized
INFO - 2026-07-03 10:04:05 --> Output Class Initialized
INFO - 2026-07-03 10:04:05 --> Security Class Initialized
DEBUG - 2026-07-03 10:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:04:05 --> CSRF cookie sent
INFO - 2026-07-03 10:04:05 --> Input Class Initialized
INFO - 2026-07-03 10:04:05 --> Language Class Initialized
INFO - 2026-07-03 10:04:05 --> Language Class Initialized
INFO - 2026-07-03 10:04:05 --> Config Class Initialized
INFO - 2026-07-03 10:04:05 --> Loader Class Initialized
INFO - 2026-07-03 10:04:05 --> Helper loaded: url_helper
INFO - 2026-07-03 10:04:05 --> Helper loaded: form_helper
INFO - 2026-07-03 10:04:05 --> Helper loaded: html_helper
INFO - 2026-07-03 10:04:05 --> Helper loaded: file_helper
INFO - 2026-07-03 10:04:05 --> Helper loaded: email_helper
INFO - 2026-07-03 10:04:05 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:04:05 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:04:05 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:04:05 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:04:05 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:04:05 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:04:05 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:04:05 --> Database Driver Class Initialized
INFO - 2026-07-03 10:04:05 --> Final output sent to browser
DEBUG - 2026-07-03 10:04:05 --> Total execution time: 4.2143
INFO - 2026-07-03 10:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:04:05 --> Upload Class Initialized
DEBUG - 2026-07-03 10:04:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:04:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:04:05 --> Encryption Class Initialized
INFO - 2026-07-03 10:04:05 --> Form Validation Class Initialized
INFO - 2026-07-03 10:04:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:04:05 --> Pagination Class Initialized
INFO - 2026-07-03 10:04:05 --> Email Class Initialized
INFO - 2026-07-03 10:04:05 --> Controller Class Initialized
DEBUG - 2026-07-03 10:04:05 --> Cart MX_Controller Initialized
INFO - 2026-07-03 10:04:05 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:04:05 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:04:05 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:04:05 --> Model "Common_model" initialized
INFO - 2026-07-03 10:04:05 --> Model "Order_model" initialized
INFO - 2026-07-03 10:04:05 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 10:04:05 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 10:04:05 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 10:04:05 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 10:04:05 --> Model "Plan_model" initialized
INFO - 2026-07-03 10:04:05 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 10:04:06 --> Final output sent to browser
DEBUG - 2026-07-03 10:04:06 --> Total execution time: 4.5382
INFO - 2026-07-03 10:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:04:06 --> Upload Class Initialized
DEBUG - 2026-07-03 10:04:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:04:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:04:06 --> Encryption Class Initialized
INFO - 2026-07-03 10:04:06 --> Form Validation Class Initialized
INFO - 2026-07-03 10:04:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:04:06 --> Pagination Class Initialized
INFO - 2026-07-03 10:04:06 --> Email Class Initialized
INFO - 2026-07-03 10:04:06 --> Controller Class Initialized
DEBUG - 2026-07-03 10:04:06 --> Subscription MX_Controller Initialized
INFO - 2026-07-03 10:04:06 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:04:06 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:04:06 --> Model "Cart_model" initialized
DEBUG - 2026-07-03 10:04:06 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 10:04:06 --> Model "Plan_model" initialized
INFO - 2026-07-03 10:04:06 --> Model "Order_model" initialized
INFO - 2026-07-03 10:04:06 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 10:04:06 --> Model "Subscription_model" initialized
INFO - 2026-07-03 10:04:06 --> Model "Software_model" initialized
INFO - 2026-07-03 10:04:07 --> Config Class Initialized
INFO - 2026-07-03 10:04:07 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:04:07 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:04:07 --> Utf8 Class Initialized
INFO - 2026-07-03 10:04:07 --> URI Class Initialized
INFO - 2026-07-03 10:04:07 --> Router Class Initialized
INFO - 2026-07-03 10:04:07 --> Output Class Initialized
INFO - 2026-07-03 10:04:07 --> Security Class Initialized
DEBUG - 2026-07-03 10:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:04:07 --> CSRF cookie sent
INFO - 2026-07-03 10:04:07 --> Input Class Initialized
INFO - 2026-07-03 10:04:07 --> Language Class Initialized
INFO - 2026-07-03 10:04:07 --> Language Class Initialized
INFO - 2026-07-03 10:04:07 --> Config Class Initialized
INFO - 2026-07-03 10:04:07 --> Loader Class Initialized
INFO - 2026-07-03 10:04:07 --> Helper loaded: url_helper
INFO - 2026-07-03 10:04:07 --> Helper loaded: form_helper
INFO - 2026-07-03 10:04:07 --> Helper loaded: html_helper
INFO - 2026-07-03 10:04:07 --> Helper loaded: file_helper
INFO - 2026-07-03 10:04:07 --> Helper loaded: email_helper
INFO - 2026-07-03 10:04:07 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:04:07 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:04:07 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:04:07 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:04:07 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:04:07 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:04:07 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:04:07 --> Database Driver Class Initialized
INFO - 2026-07-03 10:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:04:09 --> Upload Class Initialized
DEBUG - 2026-07-03 10:04:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:04:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:04:09 --> Encryption Class Initialized
INFO - 2026-07-03 10:04:09 --> Form Validation Class Initialized
INFO - 2026-07-03 10:04:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:04:09 --> Pagination Class Initialized
INFO - 2026-07-03 10:04:09 --> Email Class Initialized
INFO - 2026-07-03 10:04:09 --> Controller Class Initialized
DEBUG - 2026-07-03 10:04:09 --> Clientarea MX_Controller Initialized
INFO - 2026-07-03 10:04:09 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:04:09 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:04:09 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:04:09 --> Model "Clientarea_model" initialized
INFO - 2026-07-03 10:04:09 --> Model "Billing_model" initialized
INFO - 2026-07-03 10:04:09 --> Model "Common_model" initialized
INFO - 2026-07-03 10:04:09 --> Model "Order_model" initialized
INFO - 2026-07-03 10:04:09 --> Model "Support_model" initialized
INFO - 2026-07-03 10:04:09 --> Model "Subscription_model" initialized
INFO - 2026-07-03 10:04:09 --> Model "Software_model" initialized
DEBUG - 2026-07-03 10:04:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 10:04:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 10:04:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 10:04:10 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_index.php
INFO - 2026-07-03 10:04:10 --> Final output sent to browser
DEBUG - 2026-07-03 10:04:10 --> Total execution time: 3.1515
INFO - 2026-07-03 10:04:10 --> Config Class Initialized
INFO - 2026-07-03 10:04:10 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:04:10 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:04:10 --> Utf8 Class Initialized
INFO - 2026-07-03 10:04:10 --> URI Class Initialized
INFO - 2026-07-03 10:04:10 --> Router Class Initialized
INFO - 2026-07-03 10:04:10 --> Output Class Initialized
INFO - 2026-07-03 10:04:10 --> Security Class Initialized
DEBUG - 2026-07-03 10:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:04:10 --> CSRF cookie sent
INFO - 2026-07-03 10:04:10 --> Input Class Initialized
INFO - 2026-07-03 10:04:10 --> Language Class Initialized
INFO - 2026-07-03 10:04:10 --> Language Class Initialized
INFO - 2026-07-03 10:04:10 --> Config Class Initialized
INFO - 2026-07-03 10:04:10 --> Loader Class Initialized
INFO - 2026-07-03 10:04:10 --> Helper loaded: url_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: form_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: html_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: file_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: email_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:04:10 --> Config Class Initialized
INFO - 2026-07-03 10:04:10 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:04:10 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:04:10 --> Utf8 Class Initialized
INFO - 2026-07-03 10:04:10 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:04:10 --> URI Class Initialized
INFO - 2026-07-03 10:04:10 --> Config Class Initialized
INFO - 2026-07-03 10:04:10 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:04:10 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:04:10 --> Utf8 Class Initialized
INFO - 2026-07-03 10:04:10 --> Router Class Initialized
INFO - 2026-07-03 10:04:10 --> URI Class Initialized
INFO - 2026-07-03 10:04:10 --> Output Class Initialized
INFO - 2026-07-03 10:04:10 --> Config Class Initialized
INFO - 2026-07-03 10:04:10 --> Hooks Class Initialized
INFO - 2026-07-03 10:04:10 --> Router Class Initialized
INFO - 2026-07-03 10:04:10 --> Database Driver Class Initialized
INFO - 2026-07-03 10:04:10 --> Security Class Initialized
DEBUG - 2026-07-03 10:04:10 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:04:10 --> Utf8 Class Initialized
INFO - 2026-07-03 10:04:10 --> URI Class Initialized
DEBUG - 2026-07-03 10:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:04:10 --> Input Class Initialized
INFO - 2026-07-03 10:04:10 --> Output Class Initialized
INFO - 2026-07-03 10:04:10 --> Language Class Initialized
INFO - 2026-07-03 10:04:10 --> Language Class Initialized
INFO - 2026-07-03 10:04:10 --> Config Class Initialized
INFO - 2026-07-03 10:04:10 --> Security Class Initialized
INFO - 2026-07-03 10:04:10 --> Router Class Initialized
DEBUG - 2026-07-03 10:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:04:10 --> Input Class Initialized
INFO - 2026-07-03 10:04:10 --> Output Class Initialized
INFO - 2026-07-03 10:04:10 --> Language Class Initialized
INFO - 2026-07-03 10:04:10 --> Language Class Initialized
INFO - 2026-07-03 10:04:10 --> Config Class Initialized
INFO - 2026-07-03 10:04:10 --> Security Class Initialized
INFO - 2026-07-03 10:04:10 --> Loader Class Initialized
INFO - 2026-07-03 10:04:10 --> Helper loaded: url_helper
DEBUG - 2026-07-03 10:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:04:10 --> Input Class Initialized
INFO - 2026-07-03 10:04:10 --> Language Class Initialized
INFO - 2026-07-03 10:04:10 --> Helper loaded: form_helper
INFO - 2026-07-03 10:04:10 --> Language Class Initialized
INFO - 2026-07-03 10:04:10 --> Config Class Initialized
INFO - 2026-07-03 10:04:10 --> Loader Class Initialized
INFO - 2026-07-03 10:04:10 --> Helper loaded: html_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: file_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: url_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: email_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: form_helper
INFO - 2026-07-03 10:04:10 --> Loader Class Initialized
INFO - 2026-07-03 10:04:10 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: html_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: url_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: file_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: email_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: form_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: html_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: file_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: email_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:04:10 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:04:10 --> Database Driver Class Initialized
INFO - 2026-07-03 10:04:10 --> Database Driver Class Initialized
INFO - 2026-07-03 10:04:10 --> Database Driver Class Initialized
INFO - 2026-07-03 10:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:04:12 --> Upload Class Initialized
DEBUG - 2026-07-03 10:04:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:04:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:04:12 --> Encryption Class Initialized
INFO - 2026-07-03 10:04:12 --> Form Validation Class Initialized
INFO - 2026-07-03 10:04:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:04:12 --> Pagination Class Initialized
INFO - 2026-07-03 10:04:12 --> Email Class Initialized
INFO - 2026-07-03 10:04:12 --> Controller Class Initialized
DEBUG - 2026-07-03 10:04:12 --> Billing MX_Controller Initialized
INFO - 2026-07-03 10:04:12 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:04:12 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:04:12 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:04:12 --> Model "Billing_model" initialized
INFO - 2026-07-03 10:04:12 --> Model "Common_model" initialized
INFO - 2026-07-03 10:04:12 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 10:04:13 --> Final output sent to browser
DEBUG - 2026-07-03 10:04:13 --> Total execution time: 2.4722
INFO - 2026-07-03 10:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:04:13 --> Upload Class Initialized
DEBUG - 2026-07-03 10:04:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:04:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:04:13 --> Encryption Class Initialized
INFO - 2026-07-03 10:04:13 --> Form Validation Class Initialized
INFO - 2026-07-03 10:04:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:04:13 --> Pagination Class Initialized
INFO - 2026-07-03 10:04:13 --> Email Class Initialized
INFO - 2026-07-03 10:04:13 --> Controller Class Initialized
DEBUG - 2026-07-03 10:04:13 --> Cart MX_Controller Initialized
INFO - 2026-07-03 10:04:13 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:04:13 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:04:13 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:04:13 --> Model "Common_model" initialized
INFO - 2026-07-03 10:04:13 --> Model "Order_model" initialized
INFO - 2026-07-03 10:04:13 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 10:04:13 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 10:04:13 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 10:04:13 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 10:04:13 --> Model "Plan_model" initialized
INFO - 2026-07-03 10:04:13 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 10:04:13 --> Final output sent to browser
DEBUG - 2026-07-03 10:04:13 --> Total execution time: 2.8033
INFO - 2026-07-03 10:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:04:13 --> Upload Class Initialized
DEBUG - 2026-07-03 10:04:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:04:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:04:13 --> Encryption Class Initialized
INFO - 2026-07-03 10:04:13 --> Form Validation Class Initialized
INFO - 2026-07-03 10:04:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:04:13 --> Pagination Class Initialized
INFO - 2026-07-03 10:04:13 --> Email Class Initialized
INFO - 2026-07-03 10:04:13 --> Controller Class Initialized
DEBUG - 2026-07-03 10:04:13 --> Clientarea MX_Controller Initialized
INFO - 2026-07-03 10:04:13 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:04:13 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:04:13 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:04:13 --> Model "Clientarea_model" initialized
INFO - 2026-07-03 10:04:13 --> Model "Billing_model" initialized
INFO - 2026-07-03 10:04:13 --> Model "Common_model" initialized
INFO - 2026-07-03 10:04:13 --> Model "Order_model" initialized
INFO - 2026-07-03 10:04:13 --> Model "Support_model" initialized
INFO - 2026-07-03 10:04:14 --> Final output sent to browser
DEBUG - 2026-07-03 10:04:14 --> Total execution time: 3.4226
INFO - 2026-07-03 10:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:04:14 --> Upload Class Initialized
DEBUG - 2026-07-03 10:04:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:04:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:04:14 --> Encryption Class Initialized
INFO - 2026-07-03 10:04:14 --> Form Validation Class Initialized
INFO - 2026-07-03 10:04:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:04:14 --> Pagination Class Initialized
INFO - 2026-07-03 10:04:14 --> Email Class Initialized
INFO - 2026-07-03 10:04:14 --> Controller Class Initialized
DEBUG - 2026-07-03 10:04:14 --> Tickets MX_Controller Initialized
INFO - 2026-07-03 10:04:14 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:04:14 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:04:14 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:04:14 --> Model "Support_model" initialized
INFO - 2026-07-03 10:04:14 --> Model "Common_model" initialized
INFO - 2026-07-03 10:04:15 --> Final output sent to browser
DEBUG - 2026-07-03 10:04:15 --> Total execution time: 4.2175
INFO - 2026-07-03 10:04:19 --> Config Class Initialized
INFO - 2026-07-03 10:04:19 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:04:19 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:04:19 --> Utf8 Class Initialized
INFO - 2026-07-03 10:04:19 --> URI Class Initialized
INFO - 2026-07-03 10:04:19 --> Router Class Initialized
INFO - 2026-07-03 10:04:19 --> Output Class Initialized
INFO - 2026-07-03 10:04:19 --> Security Class Initialized
DEBUG - 2026-07-03 10:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:04:19 --> CSRF cookie sent
INFO - 2026-07-03 10:04:19 --> CSRF token verified
INFO - 2026-07-03 10:04:19 --> Input Class Initialized
INFO - 2026-07-03 10:04:19 --> Language Class Initialized
INFO - 2026-07-03 10:04:19 --> Language Class Initialized
INFO - 2026-07-03 10:04:19 --> Config Class Initialized
INFO - 2026-07-03 10:04:19 --> Loader Class Initialized
INFO - 2026-07-03 10:04:19 --> Helper loaded: url_helper
INFO - 2026-07-03 10:04:19 --> Helper loaded: form_helper
INFO - 2026-07-03 10:04:19 --> Helper loaded: html_helper
INFO - 2026-07-03 10:04:19 --> Helper loaded: file_helper
INFO - 2026-07-03 10:04:19 --> Helper loaded: email_helper
INFO - 2026-07-03 10:04:19 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:04:19 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:04:19 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:04:19 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:04:19 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:04:19 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:04:19 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:04:19 --> Database Driver Class Initialized
INFO - 2026-07-03 10:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:04:21 --> Upload Class Initialized
DEBUG - 2026-07-03 10:04:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:04:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:04:21 --> Encryption Class Initialized
INFO - 2026-07-03 10:04:21 --> Form Validation Class Initialized
INFO - 2026-07-03 10:04:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:04:21 --> Pagination Class Initialized
INFO - 2026-07-03 10:04:21 --> Email Class Initialized
INFO - 2026-07-03 10:04:21 --> Controller Class Initialized
DEBUG - 2026-07-03 10:04:21 --> Pay MX_Controller Initialized
INFO - 2026-07-03 10:04:21 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:04:21 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:04:21 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:04:21 --> Model "Payment_model" initialized
INFO - 2026-07-03 10:04:21 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 10:04:21 --> Model "Billing_model" initialized
INFO - 2026-07-03 10:04:21 --> Model "Invoice_model" initialized
INFO - 2026-07-03 10:04:27 --> Final output sent to browser
DEBUG - 2026-07-03 10:04:27 --> Total execution time: 7.6422
INFO - 2026-07-03 10:04:43 --> Config Class Initialized
INFO - 2026-07-03 10:04:43 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:04:43 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:04:43 --> Utf8 Class Initialized
INFO - 2026-07-03 10:04:43 --> URI Class Initialized
INFO - 2026-07-03 10:04:43 --> Router Class Initialized
INFO - 2026-07-03 10:04:43 --> Output Class Initialized
INFO - 2026-07-03 10:04:43 --> Security Class Initialized
DEBUG - 2026-07-03 10:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:04:43 --> Input Class Initialized
INFO - 2026-07-03 10:04:43 --> Language Class Initialized
INFO - 2026-07-03 10:04:43 --> Language Class Initialized
INFO - 2026-07-03 10:04:43 --> Config Class Initialized
INFO - 2026-07-03 10:04:43 --> Loader Class Initialized
INFO - 2026-07-03 10:04:43 --> Helper loaded: url_helper
INFO - 2026-07-03 10:04:43 --> Helper loaded: form_helper
INFO - 2026-07-03 10:04:43 --> Helper loaded: html_helper
INFO - 2026-07-03 10:04:43 --> Helper loaded: file_helper
INFO - 2026-07-03 10:04:43 --> Helper loaded: email_helper
INFO - 2026-07-03 10:04:43 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:04:43 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:04:43 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:04:43 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:04:43 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:04:43 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:04:43 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:04:43 --> Database Driver Class Initialized
INFO - 2026-07-03 10:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:04:44 --> Upload Class Initialized
DEBUG - 2026-07-03 10:04:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:04:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:04:44 --> Encryption Class Initialized
INFO - 2026-07-03 10:04:44 --> Form Validation Class Initialized
INFO - 2026-07-03 10:04:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:04:45 --> Pagination Class Initialized
INFO - 2026-07-03 10:04:45 --> Email Class Initialized
INFO - 2026-07-03 10:04:45 --> Controller Class Initialized
DEBUG - 2026-07-03 10:04:45 --> Pay MX_Controller Initialized
INFO - 2026-07-03 10:04:45 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:04:45 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:04:45 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:04:45 --> Model "Payment_model" initialized
INFO - 2026-07-03 10:04:45 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 10:04:45 --> Model "Billing_model" initialized
INFO - 2026-07-03 10:04:45 --> Model "Invoice_model" initialized
INFO - 2026-07-03 10:04:49 --> Model "Provisioning_model" initialized
DEBUG - 2026-07-03 10:04:50 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 10:04:50 --> Model "Plan_model" initialized
INFO - 2026-07-03 10:04:50 --> Model "Order_model" initialized
INFO - 2026-07-03 10:04:50 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 10:04:52 --> Provisioning completed for invoice #565 - Total: 1, Success: 1, Failed: 0
INFO - 2026-07-03 10:04:52 --> provisionPaidServices completed for invoice #565 - Success: 1/1
INFO - 2026-07-03 10:05:00 --> Model "Syscnf_model" initialized
INFO - 2026-07-03 10:05:07 --> Payment confirmation emails sent for transaction #10 - Customer: Yes, Admin: Yes
INFO - 2026-07-03 10:05:07 --> Invoice #565 marked as PAID. Total: 10, Paid: 10
INFO - 2026-07-03 10:05:09 --> Config Class Initialized
INFO - 2026-07-03 10:05:09 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:05:09 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:05:09 --> Utf8 Class Initialized
INFO - 2026-07-03 10:05:09 --> URI Class Initialized
INFO - 2026-07-03 10:05:09 --> Router Class Initialized
INFO - 2026-07-03 10:05:09 --> Output Class Initialized
INFO - 2026-07-03 10:05:09 --> Security Class Initialized
DEBUG - 2026-07-03 10:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:05:09 --> CSRF cookie sent
INFO - 2026-07-03 10:05:09 --> Input Class Initialized
INFO - 2026-07-03 10:05:09 --> Language Class Initialized
INFO - 2026-07-03 10:05:09 --> Language Class Initialized
INFO - 2026-07-03 10:05:09 --> Config Class Initialized
INFO - 2026-07-03 10:05:09 --> Loader Class Initialized
INFO - 2026-07-03 10:05:09 --> Helper loaded: url_helper
INFO - 2026-07-03 10:05:09 --> Helper loaded: form_helper
INFO - 2026-07-03 10:05:09 --> Helper loaded: html_helper
INFO - 2026-07-03 10:05:09 --> Helper loaded: file_helper
INFO - 2026-07-03 10:05:09 --> Helper loaded: email_helper
INFO - 2026-07-03 10:05:09 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:05:09 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:05:09 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:05:09 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:05:09 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:05:09 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:05:09 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:05:09 --> Database Driver Class Initialized
INFO - 2026-07-03 10:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:05:11 --> Upload Class Initialized
DEBUG - 2026-07-03 10:05:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:05:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:05:11 --> Encryption Class Initialized
INFO - 2026-07-03 10:05:11 --> Form Validation Class Initialized
INFO - 2026-07-03 10:05:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:05:11 --> Pagination Class Initialized
INFO - 2026-07-03 10:05:11 --> Email Class Initialized
INFO - 2026-07-03 10:05:11 --> Controller Class Initialized
DEBUG - 2026-07-03 10:05:11 --> Billing MX_Controller Initialized
INFO - 2026-07-03 10:05:11 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:05:11 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:05:11 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:05:11 --> Model "Billing_model" initialized
INFO - 2026-07-03 10:05:11 --> Model "Common_model" initialized
INFO - 2026-07-03 10:05:11 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-03 10:05:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_invoice_pdf_html.php
DEBUG - 2026-07-03 10:05:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 10:05:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/invoice_nav.php
DEBUG - 2026-07-03 10:05:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 10:05:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 10:05:13 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/billing/views/billing_viewinvoice.php
INFO - 2026-07-03 10:05:13 --> Final output sent to browser
DEBUG - 2026-07-03 10:05:13 --> Total execution time: 3.6103
INFO - 2026-07-03 10:05:13 --> Config Class Initialized
INFO - 2026-07-03 10:05:13 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:05:13 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:05:13 --> Utf8 Class Initialized
INFO - 2026-07-03 10:05:13 --> URI Class Initialized
INFO - 2026-07-03 10:05:13 --> Router Class Initialized
INFO - 2026-07-03 10:05:13 --> Output Class Initialized
INFO - 2026-07-03 10:05:13 --> Security Class Initialized
DEBUG - 2026-07-03 10:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:05:13 --> CSRF cookie sent
INFO - 2026-07-03 10:05:13 --> Input Class Initialized
INFO - 2026-07-03 10:05:13 --> Language Class Initialized
INFO - 2026-07-03 10:05:13 --> Language Class Initialized
INFO - 2026-07-03 10:05:13 --> Config Class Initialized
INFO - 2026-07-03 10:05:13 --> Loader Class Initialized
INFO - 2026-07-03 10:05:13 --> Helper loaded: url_helper
INFO - 2026-07-03 10:05:13 --> Helper loaded: form_helper
INFO - 2026-07-03 10:05:13 --> Helper loaded: html_helper
INFO - 2026-07-03 10:05:13 --> Helper loaded: file_helper
INFO - 2026-07-03 10:05:13 --> Helper loaded: email_helper
INFO - 2026-07-03 10:05:13 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:05:13 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:05:13 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:05:13 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:05:13 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:05:13 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:05:13 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:05:13 --> Database Driver Class Initialized
INFO - 2026-07-03 10:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:05:15 --> Upload Class Initialized
DEBUG - 2026-07-03 10:05:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:05:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:05:15 --> Encryption Class Initialized
INFO - 2026-07-03 10:05:15 --> Form Validation Class Initialized
INFO - 2026-07-03 10:05:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:05:15 --> Pagination Class Initialized
INFO - 2026-07-03 10:05:15 --> Email Class Initialized
INFO - 2026-07-03 10:05:15 --> Controller Class Initialized
DEBUG - 2026-07-03 10:05:15 --> Cart MX_Controller Initialized
INFO - 2026-07-03 10:05:15 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:05:15 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:05:15 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:05:15 --> Model "Common_model" initialized
INFO - 2026-07-03 10:05:15 --> Model "Order_model" initialized
INFO - 2026-07-03 10:05:15 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 10:05:15 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 10:05:15 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 10:05:15 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 10:05:15 --> Model "Plan_model" initialized
INFO - 2026-07-03 10:05:15 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 10:05:15 --> Final output sent to browser
DEBUG - 2026-07-03 10:05:15 --> Total execution time: 2.1624
INFO - 2026-07-03 10:05:23 --> Config Class Initialized
INFO - 2026-07-03 10:05:23 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:05:23 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:05:23 --> Utf8 Class Initialized
INFO - 2026-07-03 10:05:23 --> URI Class Initialized
INFO - 2026-07-03 10:05:23 --> Router Class Initialized
INFO - 2026-07-03 10:05:23 --> Output Class Initialized
INFO - 2026-07-03 10:05:23 --> Security Class Initialized
DEBUG - 2026-07-03 10:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:05:23 --> CSRF cookie sent
INFO - 2026-07-03 10:05:23 --> Input Class Initialized
INFO - 2026-07-03 10:05:23 --> Language Class Initialized
INFO - 2026-07-03 10:05:23 --> Language Class Initialized
INFO - 2026-07-03 10:05:23 --> Config Class Initialized
INFO - 2026-07-03 10:05:23 --> Loader Class Initialized
INFO - 2026-07-03 10:05:23 --> Helper loaded: url_helper
INFO - 2026-07-03 10:05:23 --> Helper loaded: form_helper
INFO - 2026-07-03 10:05:23 --> Helper loaded: html_helper
INFO - 2026-07-03 10:05:23 --> Helper loaded: file_helper
INFO - 2026-07-03 10:05:23 --> Helper loaded: email_helper
INFO - 2026-07-03 10:05:23 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:05:23 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:05:23 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:05:23 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:05:23 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:05:23 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:05:23 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:05:23 --> Database Driver Class Initialized
INFO - 2026-07-03 10:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:05:26 --> Upload Class Initialized
DEBUG - 2026-07-03 10:05:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:05:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:05:26 --> Encryption Class Initialized
INFO - 2026-07-03 10:05:26 --> Form Validation Class Initialized
INFO - 2026-07-03 10:05:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:05:26 --> Pagination Class Initialized
INFO - 2026-07-03 10:05:26 --> Email Class Initialized
INFO - 2026-07-03 10:05:26 --> Controller Class Initialized
DEBUG - 2026-07-03 10:05:26 --> Subscription MX_Controller Initialized
INFO - 2026-07-03 10:05:26 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:05:26 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:05:26 --> Model "Cart_model" initialized
DEBUG - 2026-07-03 10:05:26 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 10:05:26 --> Model "Plan_model" initialized
INFO - 2026-07-03 10:05:26 --> Model "Order_model" initialized
INFO - 2026-07-03 10:05:26 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 10:05:26 --> Model "Subscription_model" initialized
INFO - 2026-07-03 10:05:26 --> Model "Software_model" initialized
INFO - 2026-07-03 10:26:35 --> Config Class Initialized
INFO - 2026-07-03 10:26:35 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:26:35 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:26:35 --> Utf8 Class Initialized
INFO - 2026-07-03 10:26:35 --> URI Class Initialized
INFO - 2026-07-03 10:26:35 --> Router Class Initialized
INFO - 2026-07-03 10:26:35 --> Output Class Initialized
INFO - 2026-07-03 10:26:35 --> Security Class Initialized
DEBUG - 2026-07-03 10:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:26:35 --> CSRF cookie sent
INFO - 2026-07-03 10:26:35 --> Input Class Initialized
INFO - 2026-07-03 10:26:35 --> Language Class Initialized
INFO - 2026-07-03 10:26:35 --> Language Class Initialized
INFO - 2026-07-03 10:26:35 --> Config Class Initialized
INFO - 2026-07-03 10:26:35 --> Loader Class Initialized
INFO - 2026-07-03 10:26:35 --> Helper loaded: url_helper
INFO - 2026-07-03 10:26:35 --> Helper loaded: form_helper
INFO - 2026-07-03 10:26:35 --> Helper loaded: html_helper
INFO - 2026-07-03 10:26:35 --> Helper loaded: file_helper
INFO - 2026-07-03 10:26:35 --> Helper loaded: email_helper
INFO - 2026-07-03 10:26:35 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:26:35 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:26:35 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:26:35 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:26:35 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:26:35 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:26:35 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:26:35 --> Database Driver Class Initialized
INFO - 2026-07-03 10:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:26:37 --> Upload Class Initialized
DEBUG - 2026-07-03 10:26:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:26:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:26:37 --> Encryption Class Initialized
INFO - 2026-07-03 10:26:37 --> Form Validation Class Initialized
INFO - 2026-07-03 10:26:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:26:37 --> Pagination Class Initialized
INFO - 2026-07-03 10:26:37 --> Email Class Initialized
INFO - 2026-07-03 10:26:37 --> Controller Class Initialized
DEBUG - 2026-07-03 10:26:37 --> Swtest2 MX_Controller Initialized
INFO - 2026-07-03 10:26:37 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:26:37 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:26:37 --> Model "Cart_model" initialized
DEBUG - 2026-07-03 10:26:37 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 10:26:37 --> Model "Plan_model" initialized
INFO - 2026-07-03 10:26:37 --> Model "Software_model" initialized
INFO - 2026-07-03 10:26:37 --> Model "Order_model" initialized
INFO - 2026-07-03 10:26:37 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 10:26:37 --> Model "Invoice_model" initialized
INFO - 2026-07-03 10:26:37 --> Model "Provisioning_model" initialized
INFO - 2026-07-03 10:26:37 --> Model "Subscription_model" initialized
INFO - 2026-07-03 10:26:57 --> Provisioning completed for invoice #566 - Total: 1, Success: 1, Failed: 0
INFO - 2026-07-03 10:26:57 --> provisionPaidServices completed for invoice #566 - Success: 1/1
INFO - 2026-07-03 10:27:05 --> Final output sent to browser
DEBUG - 2026-07-03 10:27:05 --> Total execution time: 29.8429
INFO - 2026-07-03 10:27:26 --> Config Class Initialized
INFO - 2026-07-03 10:27:26 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:27:26 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:27:26 --> Utf8 Class Initialized
INFO - 2026-07-03 10:27:26 --> URI Class Initialized
INFO - 2026-07-03 10:27:26 --> Router Class Initialized
INFO - 2026-07-03 10:27:26 --> Output Class Initialized
INFO - 2026-07-03 10:27:26 --> Security Class Initialized
DEBUG - 2026-07-03 10:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:27:26 --> CSRF cookie sent
INFO - 2026-07-03 10:27:26 --> Input Class Initialized
INFO - 2026-07-03 10:27:26 --> Language Class Initialized
INFO - 2026-07-03 10:27:26 --> Language Class Initialized
INFO - 2026-07-03 10:27:26 --> Config Class Initialized
INFO - 2026-07-03 10:27:26 --> Loader Class Initialized
INFO - 2026-07-03 10:27:26 --> Helper loaded: url_helper
INFO - 2026-07-03 10:27:26 --> Helper loaded: form_helper
INFO - 2026-07-03 10:27:26 --> Helper loaded: html_helper
INFO - 2026-07-03 10:27:26 --> Helper loaded: file_helper
INFO - 2026-07-03 10:27:26 --> Helper loaded: email_helper
INFO - 2026-07-03 10:27:26 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:27:26 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:27:26 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:27:26 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:27:26 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:27:26 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:27:26 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:27:26 --> Database Driver Class Initialized
INFO - 2026-07-03 10:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:27:29 --> Upload Class Initialized
DEBUG - 2026-07-03 10:27:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:27:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:27:29 --> Encryption Class Initialized
INFO - 2026-07-03 10:27:29 --> Form Validation Class Initialized
INFO - 2026-07-03 10:27:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:27:29 --> Pagination Class Initialized
INFO - 2026-07-03 10:27:29 --> Email Class Initialized
INFO - 2026-07-03 10:27:29 --> Controller Class Initialized
ERROR - 2026-07-03 10:27:29 --> 404 Page Not Found: /index
INFO - 2026-07-03 10:32:05 --> Config Class Initialized
INFO - 2026-07-03 10:32:05 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:32:05 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:32:05 --> Utf8 Class Initialized
INFO - 2026-07-03 10:32:05 --> URI Class Initialized
INFO - 2026-07-03 10:32:05 --> Router Class Initialized
INFO - 2026-07-03 10:32:05 --> Output Class Initialized
INFO - 2026-07-03 10:32:05 --> Security Class Initialized
DEBUG - 2026-07-03 10:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:32:05 --> CSRF cookie sent
INFO - 2026-07-03 10:32:05 --> Input Class Initialized
INFO - 2026-07-03 10:32:05 --> Language Class Initialized
INFO - 2026-07-03 10:32:05 --> Language Class Initialized
INFO - 2026-07-03 10:32:05 --> Config Class Initialized
INFO - 2026-07-03 10:32:05 --> Loader Class Initialized
INFO - 2026-07-03 10:32:05 --> Helper loaded: url_helper
INFO - 2026-07-03 10:32:05 --> Helper loaded: form_helper
INFO - 2026-07-03 10:32:05 --> Helper loaded: html_helper
INFO - 2026-07-03 10:32:05 --> Helper loaded: file_helper
INFO - 2026-07-03 10:32:05 --> Helper loaded: email_helper
INFO - 2026-07-03 10:32:05 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:32:05 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:32:05 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:32:05 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:32:05 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:32:05 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:32:05 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:32:05 --> Database Driver Class Initialized
INFO - 2026-07-03 10:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:32:07 --> Upload Class Initialized
DEBUG - 2026-07-03 10:32:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:32:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:32:07 --> Encryption Class Initialized
INFO - 2026-07-03 10:32:07 --> Form Validation Class Initialized
INFO - 2026-07-03 10:32:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:32:07 --> Pagination Class Initialized
INFO - 2026-07-03 10:32:07 --> Email Class Initialized
INFO - 2026-07-03 10:32:07 --> Controller Class Initialized
DEBUG - 2026-07-03 10:32:07 --> Clientarea MX_Controller Initialized
INFO - 2026-07-03 10:32:07 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:32:07 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:32:07 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:32:07 --> Model "Clientarea_model" initialized
INFO - 2026-07-03 10:32:07 --> Model "Billing_model" initialized
INFO - 2026-07-03 10:32:07 --> Model "Common_model" initialized
INFO - 2026-07-03 10:32:07 --> Model "Order_model" initialized
INFO - 2026-07-03 10:32:07 --> Model "Support_model" initialized
INFO - 2026-07-03 10:32:08 --> Model "Subscription_model" initialized
INFO - 2026-07-03 10:32:08 --> Model "Software_model" initialized
DEBUG - 2026-07-03 10:32:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 10:32:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 10:32:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 10:32:08 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/clientarea/views/clientarea_index.php
INFO - 2026-07-03 10:32:08 --> Final output sent to browser
DEBUG - 2026-07-03 10:32:08 --> Total execution time: 3.2288
INFO - 2026-07-03 10:32:09 --> Config Class Initialized
INFO - 2026-07-03 10:32:09 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:32:09 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:32:09 --> Utf8 Class Initialized
INFO - 2026-07-03 10:32:09 --> URI Class Initialized
INFO - 2026-07-03 10:32:09 --> Router Class Initialized
INFO - 2026-07-03 10:32:09 --> Output Class Initialized
INFO - 2026-07-03 10:32:09 --> Security Class Initialized
DEBUG - 2026-07-03 10:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:32:09 --> CSRF cookie sent
INFO - 2026-07-03 10:32:09 --> Input Class Initialized
INFO - 2026-07-03 10:32:09 --> Language Class Initialized
INFO - 2026-07-03 10:32:09 --> Language Class Initialized
INFO - 2026-07-03 10:32:09 --> Config Class Initialized
INFO - 2026-07-03 10:32:09 --> Loader Class Initialized
INFO - 2026-07-03 10:32:09 --> Helper loaded: url_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: form_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: html_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: file_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: email_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:32:09 --> Config Class Initialized
INFO - 2026-07-03 10:32:09 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:32:09 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:32:09 --> Utf8 Class Initialized
INFO - 2026-07-03 10:32:09 --> Config Class Initialized
INFO - 2026-07-03 10:32:09 --> Hooks Class Initialized
INFO - 2026-07-03 10:32:09 --> URI Class Initialized
INFO - 2026-07-03 10:32:09 --> Database Driver Class Initialized
DEBUG - 2026-07-03 10:32:09 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:32:09 --> Utf8 Class Initialized
INFO - 2026-07-03 10:32:09 --> Router Class Initialized
INFO - 2026-07-03 10:32:09 --> URI Class Initialized
INFO - 2026-07-03 10:32:09 --> Config Class Initialized
INFO - 2026-07-03 10:32:09 --> Hooks Class Initialized
INFO - 2026-07-03 10:32:09 --> Output Class Initialized
INFO - 2026-07-03 10:32:09 --> Security Class Initialized
DEBUG - 2026-07-03 10:32:09 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:32:09 --> Utf8 Class Initialized
INFO - 2026-07-03 10:32:09 --> Router Class Initialized
DEBUG - 2026-07-03 10:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:32:09 --> Input Class Initialized
INFO - 2026-07-03 10:32:09 --> Language Class Initialized
INFO - 2026-07-03 10:32:09 --> URI Class Initialized
INFO - 2026-07-03 10:32:09 --> Language Class Initialized
INFO - 2026-07-03 10:32:09 --> Config Class Initialized
INFO - 2026-07-03 10:32:09 --> Output Class Initialized
INFO - 2026-07-03 10:32:09 --> Security Class Initialized
INFO - 2026-07-03 10:32:09 --> Router Class Initialized
INFO - 2026-07-03 10:32:09 --> Loader Class Initialized
DEBUG - 2026-07-03 10:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:32:09 --> Input Class Initialized
INFO - 2026-07-03 10:32:09 --> Helper loaded: url_helper
INFO - 2026-07-03 10:32:09 --> Output Class Initialized
INFO - 2026-07-03 10:32:09 --> Language Class Initialized
INFO - 2026-07-03 10:32:09 --> Language Class Initialized
INFO - 2026-07-03 10:32:09 --> Config Class Initialized
INFO - 2026-07-03 10:32:09 --> Helper loaded: form_helper
INFO - 2026-07-03 10:32:09 --> Security Class Initialized
INFO - 2026-07-03 10:32:09 --> Helper loaded: html_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: file_helper
DEBUG - 2026-07-03 10:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:32:09 --> Helper loaded: email_helper
INFO - 2026-07-03 10:32:09 --> Input Class Initialized
INFO - 2026-07-03 10:32:09 --> Loader Class Initialized
INFO - 2026-07-03 10:32:09 --> Language Class Initialized
INFO - 2026-07-03 10:32:09 --> Helper loaded: url_helper
INFO - 2026-07-03 10:32:09 --> Language Class Initialized
INFO - 2026-07-03 10:32:09 --> Config Class Initialized
INFO - 2026-07-03 10:32:09 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: form_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: html_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: file_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: email_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:32:09 --> Loader Class Initialized
INFO - 2026-07-03 10:32:09 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: url_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: form_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: html_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: file_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: email_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:32:09 --> Database Driver Class Initialized
INFO - 2026-07-03 10:32:09 --> Database Driver Class Initialized
INFO - 2026-07-03 10:32:09 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:32:09 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:32:09 --> Database Driver Class Initialized
INFO - 2026-07-03 10:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:32:10 --> Upload Class Initialized
DEBUG - 2026-07-03 10:32:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:32:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:32:10 --> Encryption Class Initialized
INFO - 2026-07-03 10:32:10 --> Form Validation Class Initialized
INFO - 2026-07-03 10:32:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:32:10 --> Pagination Class Initialized
INFO - 2026-07-03 10:32:10 --> Email Class Initialized
INFO - 2026-07-03 10:32:10 --> Controller Class Initialized
DEBUG - 2026-07-03 10:32:10 --> Billing MX_Controller Initialized
INFO - 2026-07-03 10:32:10 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:32:10 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:32:10 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:32:10 --> Model "Billing_model" initialized
INFO - 2026-07-03 10:32:10 --> Model "Common_model" initialized
INFO - 2026-07-03 10:32:10 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 10:32:11 --> Final output sent to browser
DEBUG - 2026-07-03 10:32:11 --> Total execution time: 2.4629
INFO - 2026-07-03 10:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:32:11 --> Upload Class Initialized
DEBUG - 2026-07-03 10:32:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:32:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:32:11 --> Encryption Class Initialized
INFO - 2026-07-03 10:32:11 --> Form Validation Class Initialized
INFO - 2026-07-03 10:32:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:32:11 --> Pagination Class Initialized
INFO - 2026-07-03 10:32:11 --> Email Class Initialized
INFO - 2026-07-03 10:32:11 --> Controller Class Initialized
DEBUG - 2026-07-03 10:32:11 --> Clientarea MX_Controller Initialized
INFO - 2026-07-03 10:32:11 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:32:11 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:32:11 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:32:11 --> Model "Clientarea_model" initialized
INFO - 2026-07-03 10:32:11 --> Model "Billing_model" initialized
INFO - 2026-07-03 10:32:11 --> Model "Common_model" initialized
INFO - 2026-07-03 10:32:11 --> Model "Order_model" initialized
INFO - 2026-07-03 10:32:11 --> Model "Support_model" initialized
INFO - 2026-07-03 10:32:12 --> Final output sent to browser
DEBUG - 2026-07-03 10:32:12 --> Total execution time: 3.2915
INFO - 2026-07-03 10:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:32:12 --> Upload Class Initialized
DEBUG - 2026-07-03 10:32:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:32:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:32:12 --> Encryption Class Initialized
INFO - 2026-07-03 10:32:12 --> Form Validation Class Initialized
INFO - 2026-07-03 10:32:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:32:12 --> Pagination Class Initialized
INFO - 2026-07-03 10:32:12 --> Email Class Initialized
INFO - 2026-07-03 10:32:12 --> Controller Class Initialized
DEBUG - 2026-07-03 10:32:12 --> Cart MX_Controller Initialized
INFO - 2026-07-03 10:32:12 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:32:12 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:32:12 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:32:12 --> Model "Common_model" initialized
INFO - 2026-07-03 10:32:12 --> Model "Order_model" initialized
INFO - 2026-07-03 10:32:12 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 10:32:12 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 10:32:12 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 10:32:12 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 10:32:12 --> Model "Plan_model" initialized
INFO - 2026-07-03 10:32:12 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 10:32:12 --> Final output sent to browser
DEBUG - 2026-07-03 10:32:12 --> Total execution time: 3.6305
INFO - 2026-07-03 10:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:32:12 --> Upload Class Initialized
DEBUG - 2026-07-03 10:32:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:32:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:32:12 --> Encryption Class Initialized
INFO - 2026-07-03 10:32:12 --> Form Validation Class Initialized
INFO - 2026-07-03 10:32:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:32:12 --> Pagination Class Initialized
INFO - 2026-07-03 10:32:12 --> Email Class Initialized
INFO - 2026-07-03 10:32:12 --> Controller Class Initialized
DEBUG - 2026-07-03 10:32:12 --> Tickets MX_Controller Initialized
INFO - 2026-07-03 10:32:12 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:32:12 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:32:12 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:32:12 --> Model "Support_model" initialized
INFO - 2026-07-03 10:32:12 --> Model "Common_model" initialized
INFO - 2026-07-03 10:32:13 --> Final output sent to browser
DEBUG - 2026-07-03 10:32:13 --> Total execution time: 4.4182
INFO - 2026-07-03 10:32:17 --> Config Class Initialized
INFO - 2026-07-03 10:32:17 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:32:17 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:32:17 --> Utf8 Class Initialized
INFO - 2026-07-03 10:32:17 --> URI Class Initialized
INFO - 2026-07-03 10:32:17 --> Router Class Initialized
INFO - 2026-07-03 10:32:17 --> Output Class Initialized
INFO - 2026-07-03 10:32:17 --> Security Class Initialized
DEBUG - 2026-07-03 10:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:32:17 --> CSRF cookie sent
INFO - 2026-07-03 10:32:17 --> Input Class Initialized
INFO - 2026-07-03 10:32:17 --> Language Class Initialized
INFO - 2026-07-03 10:32:17 --> Language Class Initialized
INFO - 2026-07-03 10:32:17 --> Config Class Initialized
INFO - 2026-07-03 10:32:17 --> Loader Class Initialized
INFO - 2026-07-03 10:32:17 --> Helper loaded: url_helper
INFO - 2026-07-03 10:32:17 --> Helper loaded: form_helper
INFO - 2026-07-03 10:32:17 --> Helper loaded: html_helper
INFO - 2026-07-03 10:32:17 --> Helper loaded: file_helper
INFO - 2026-07-03 10:32:17 --> Helper loaded: email_helper
INFO - 2026-07-03 10:32:17 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:32:17 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:32:17 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:32:17 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:32:17 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:32:17 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:32:17 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:32:17 --> Database Driver Class Initialized
INFO - 2026-07-03 10:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:32:19 --> Upload Class Initialized
DEBUG - 2026-07-03 10:32:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:32:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:32:19 --> Encryption Class Initialized
INFO - 2026-07-03 10:32:19 --> Form Validation Class Initialized
INFO - 2026-07-03 10:32:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:32:19 --> Pagination Class Initialized
INFO - 2026-07-03 10:32:19 --> Email Class Initialized
INFO - 2026-07-03 10:32:19 --> Controller Class Initialized
DEBUG - 2026-07-03 10:32:19 --> Subscription MX_Controller Initialized
INFO - 2026-07-03 10:32:19 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:32:19 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:32:19 --> Model "Cart_model" initialized
DEBUG - 2026-07-03 10:32:19 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 10:32:19 --> Model "Plan_model" initialized
INFO - 2026-07-03 10:32:19 --> Model "Order_model" initialized
INFO - 2026-07-03 10:32:19 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 10:32:19 --> Model "Subscription_model" initialized
INFO - 2026-07-03 10:32:19 --> Model "Software_model" initialized
DEBUG - 2026-07-03 10:32:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 10:32:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 10:32:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 10:32:20 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/subscription/views/subscription_index.php
INFO - 2026-07-03 10:32:20 --> Final output sent to browser
DEBUG - 2026-07-03 10:32:20 --> Total execution time: 2.5495
INFO - 2026-07-03 10:32:20 --> Config Class Initialized
INFO - 2026-07-03 10:32:20 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:32:20 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:32:20 --> Utf8 Class Initialized
INFO - 2026-07-03 10:32:20 --> URI Class Initialized
INFO - 2026-07-03 10:32:20 --> Router Class Initialized
INFO - 2026-07-03 10:32:20 --> Output Class Initialized
INFO - 2026-07-03 10:32:20 --> Security Class Initialized
DEBUG - 2026-07-03 10:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:32:20 --> CSRF cookie sent
INFO - 2026-07-03 10:32:20 --> Input Class Initialized
INFO - 2026-07-03 10:32:20 --> Language Class Initialized
INFO - 2026-07-03 10:32:20 --> Language Class Initialized
INFO - 2026-07-03 10:32:20 --> Config Class Initialized
INFO - 2026-07-03 10:32:20 --> Loader Class Initialized
INFO - 2026-07-03 10:32:20 --> Helper loaded: url_helper
INFO - 2026-07-03 10:32:20 --> Helper loaded: form_helper
INFO - 2026-07-03 10:32:20 --> Helper loaded: html_helper
INFO - 2026-07-03 10:32:20 --> Helper loaded: file_helper
INFO - 2026-07-03 10:32:20 --> Helper loaded: email_helper
INFO - 2026-07-03 10:32:20 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:32:20 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:32:20 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:32:20 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:32:20 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:32:20 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:32:20 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:32:20 --> Database Driver Class Initialized
INFO - 2026-07-03 10:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:32:22 --> Upload Class Initialized
DEBUG - 2026-07-03 10:32:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:32:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:32:22 --> Encryption Class Initialized
INFO - 2026-07-03 10:32:22 --> Form Validation Class Initialized
INFO - 2026-07-03 10:32:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:32:22 --> Pagination Class Initialized
INFO - 2026-07-03 10:32:22 --> Email Class Initialized
INFO - 2026-07-03 10:32:22 --> Controller Class Initialized
DEBUG - 2026-07-03 10:32:22 --> Cart MX_Controller Initialized
INFO - 2026-07-03 10:32:22 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:32:22 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:32:22 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:32:22 --> Model "Common_model" initialized
INFO - 2026-07-03 10:32:22 --> Model "Order_model" initialized
INFO - 2026-07-03 10:32:22 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 10:32:22 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 10:32:22 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 10:32:22 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 10:32:22 --> Model "Plan_model" initialized
INFO - 2026-07-03 10:32:22 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 10:32:22 --> Final output sent to browser
DEBUG - 2026-07-03 10:32:22 --> Total execution time: 2.3448
INFO - 2026-07-03 10:34:20 --> Config Class Initialized
INFO - 2026-07-03 10:34:20 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:34:20 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:34:20 --> Utf8 Class Initialized
INFO - 2026-07-03 10:34:20 --> URI Class Initialized
INFO - 2026-07-03 10:34:20 --> Router Class Initialized
INFO - 2026-07-03 10:34:20 --> Output Class Initialized
INFO - 2026-07-03 10:34:20 --> Security Class Initialized
DEBUG - 2026-07-03 10:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:34:20 --> CSRF cookie sent
INFO - 2026-07-03 10:34:20 --> Input Class Initialized
INFO - 2026-07-03 10:34:20 --> Language Class Initialized
INFO - 2026-07-03 10:34:20 --> Language Class Initialized
INFO - 2026-07-03 10:34:20 --> Config Class Initialized
INFO - 2026-07-03 10:34:20 --> Loader Class Initialized
INFO - 2026-07-03 10:34:20 --> Helper loaded: url_helper
INFO - 2026-07-03 10:34:20 --> Helper loaded: form_helper
INFO - 2026-07-03 10:34:20 --> Helper loaded: html_helper
INFO - 2026-07-03 10:34:20 --> Helper loaded: file_helper
INFO - 2026-07-03 10:34:20 --> Helper loaded: email_helper
INFO - 2026-07-03 10:34:20 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:34:20 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:34:20 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:34:20 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:34:20 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:34:20 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:34:20 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:34:20 --> Database Driver Class Initialized
INFO - 2026-07-03 10:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:34:22 --> Upload Class Initialized
DEBUG - 2026-07-03 10:34:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:34:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:34:22 --> Encryption Class Initialized
INFO - 2026-07-03 10:34:22 --> Form Validation Class Initialized
INFO - 2026-07-03 10:34:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:34:22 --> Pagination Class Initialized
INFO - 2026-07-03 10:34:22 --> Email Class Initialized
INFO - 2026-07-03 10:34:22 --> Controller Class Initialized
DEBUG - 2026-07-03 10:34:22 --> Cart MX_Controller Initialized
INFO - 2026-07-03 10:34:22 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:34:22 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:34:22 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:34:22 --> Model "Common_model" initialized
INFO - 2026-07-03 10:34:22 --> Model "Order_model" initialized
INFO - 2026-07-03 10:34:22 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 10:34:22 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 10:34:22 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 10:34:22 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 10:34:22 --> Model "Plan_model" initialized
INFO - 2026-07-03 10:34:22 --> Model "Orderlicense_model" initialized
DEBUG - 2026-07-03 10:34:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 10:34:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 10:34:23 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/cart_software.php
INFO - 2026-07-03 10:34:23 --> Final output sent to browser
DEBUG - 2026-07-03 10:34:23 --> Total execution time: 3.7042
INFO - 2026-07-03 10:36:23 --> Config Class Initialized
INFO - 2026-07-03 10:36:23 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:36:23 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:36:23 --> Utf8 Class Initialized
INFO - 2026-07-03 10:36:23 --> URI Class Initialized
INFO - 2026-07-03 10:36:23 --> Router Class Initialized
INFO - 2026-07-03 10:36:23 --> Output Class Initialized
INFO - 2026-07-03 10:36:23 --> Security Class Initialized
DEBUG - 2026-07-03 10:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:36:23 --> CSRF cookie sent
INFO - 2026-07-03 10:36:23 --> Input Class Initialized
INFO - 2026-07-03 10:36:23 --> Language Class Initialized
INFO - 2026-07-03 10:36:23 --> Language Class Initialized
INFO - 2026-07-03 10:36:23 --> Config Class Initialized
INFO - 2026-07-03 10:36:23 --> Loader Class Initialized
INFO - 2026-07-03 10:36:23 --> Helper loaded: url_helper
INFO - 2026-07-03 10:36:23 --> Helper loaded: form_helper
INFO - 2026-07-03 10:36:23 --> Helper loaded: html_helper
INFO - 2026-07-03 10:36:23 --> Helper loaded: file_helper
INFO - 2026-07-03 10:36:23 --> Helper loaded: email_helper
INFO - 2026-07-03 10:36:23 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:36:23 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:36:23 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:36:23 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:36:23 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:36:23 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:36:23 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:36:23 --> Database Driver Class Initialized
INFO - 2026-07-03 10:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:36:24 --> Upload Class Initialized
DEBUG - 2026-07-03 10:36:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:36:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:36:24 --> Encryption Class Initialized
INFO - 2026-07-03 10:36:24 --> Form Validation Class Initialized
INFO - 2026-07-03 10:36:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:36:24 --> Pagination Class Initialized
INFO - 2026-07-03 10:36:24 --> Email Class Initialized
INFO - 2026-07-03 10:36:24 --> Controller Class Initialized
DEBUG - 2026-07-03 10:36:24 --> Cart MX_Controller Initialized
INFO - 2026-07-03 10:36:24 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:36:24 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:36:24 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:36:24 --> Model "Common_model" initialized
INFO - 2026-07-03 10:36:24 --> Model "Order_model" initialized
INFO - 2026-07-03 10:36:24 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 10:36:24 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 10:36:24 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 10:36:24 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 10:36:24 --> Model "Plan_model" initialized
INFO - 2026-07-03 10:36:24 --> Model "Orderlicense_model" initialized
DEBUG - 2026-07-03 10:36:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 10:36:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 10:36:26 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/cart_software.php
INFO - 2026-07-03 10:36:26 --> Final output sent to browser
DEBUG - 2026-07-03 10:36:26 --> Total execution time: 3.1272
INFO - 2026-07-03 10:37:36 --> Config Class Initialized
INFO - 2026-07-03 10:37:36 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:37:36 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:37:36 --> Utf8 Class Initialized
INFO - 2026-07-03 10:37:36 --> URI Class Initialized
INFO - 2026-07-03 10:37:36 --> Router Class Initialized
INFO - 2026-07-03 10:37:36 --> Output Class Initialized
INFO - 2026-07-03 10:37:36 --> Security Class Initialized
DEBUG - 2026-07-03 10:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:37:36 --> CSRF cookie sent
INFO - 2026-07-03 10:37:36 --> Input Class Initialized
INFO - 2026-07-03 10:37:36 --> Language Class Initialized
INFO - 2026-07-03 10:37:36 --> Language Class Initialized
INFO - 2026-07-03 10:37:36 --> Config Class Initialized
INFO - 2026-07-03 10:37:36 --> Loader Class Initialized
INFO - 2026-07-03 10:37:36 --> Helper loaded: url_helper
INFO - 2026-07-03 10:37:36 --> Helper loaded: form_helper
INFO - 2026-07-03 10:37:36 --> Helper loaded: html_helper
INFO - 2026-07-03 10:37:36 --> Helper loaded: file_helper
INFO - 2026-07-03 10:37:36 --> Helper loaded: email_helper
INFO - 2026-07-03 10:37:36 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:37:36 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:37:36 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:37:36 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:37:36 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:37:36 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:37:36 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:37:36 --> Database Driver Class Initialized
INFO - 2026-07-03 10:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:37:40 --> Upload Class Initialized
DEBUG - 2026-07-03 10:37:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:37:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:37:40 --> Encryption Class Initialized
INFO - 2026-07-03 10:37:40 --> Form Validation Class Initialized
INFO - 2026-07-03 10:37:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:37:40 --> Pagination Class Initialized
INFO - 2026-07-03 10:37:40 --> Email Class Initialized
INFO - 2026-07-03 10:37:40 --> Controller Class Initialized
DEBUG - 2026-07-03 10:37:40 --> Softwareproduct MX_Controller Initialized
INFO - 2026-07-03 10:37:40 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:37:40 --> Model "Adminauth_model" initialized
DEBUG - 2026-07-03 10:37:40 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 10:37:40 --> Model "Plan_model" initialized
INFO - 2026-07-03 10:37:40 --> Model "Software_model" initialized
DEBUG - 2026-07-03 10:37:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 10:37:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 10:37:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 10:37:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-03 10:37:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 10:37:42 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/softwareproduct_list.php
INFO - 2026-07-03 10:37:42 --> Final output sent to browser
DEBUG - 2026-07-03 10:37:42 --> Total execution time: 5.2808
INFO - 2026-07-03 10:37:42 --> Config Class Initialized
INFO - 2026-07-03 10:37:42 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:37:42 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:37:42 --> Utf8 Class Initialized
INFO - 2026-07-03 10:37:42 --> URI Class Initialized
INFO - 2026-07-03 10:37:42 --> Router Class Initialized
INFO - 2026-07-03 10:37:42 --> Output Class Initialized
INFO - 2026-07-03 10:37:42 --> Security Class Initialized
DEBUG - 2026-07-03 10:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:37:42 --> CSRF cookie sent
INFO - 2026-07-03 10:37:42 --> Input Class Initialized
INFO - 2026-07-03 10:37:42 --> Language Class Initialized
INFO - 2026-07-03 10:37:42 --> Language Class Initialized
INFO - 2026-07-03 10:37:42 --> Config Class Initialized
INFO - 2026-07-03 10:37:42 --> Loader Class Initialized
INFO - 2026-07-03 10:37:42 --> Helper loaded: url_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: form_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: html_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: file_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: email_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:37:42 --> Database Driver Class Initialized
INFO - 2026-07-03 10:37:42 --> Config Class Initialized
INFO - 2026-07-03 10:37:42 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:37:42 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:37:42 --> Utf8 Class Initialized
INFO - 2026-07-03 10:37:42 --> URI Class Initialized
INFO - 2026-07-03 10:37:42 --> Router Class Initialized
INFO - 2026-07-03 10:37:42 --> Output Class Initialized
INFO - 2026-07-03 10:37:42 --> Security Class Initialized
DEBUG - 2026-07-03 10:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:37:42 --> CSRF cookie sent
INFO - 2026-07-03 10:37:42 --> Input Class Initialized
INFO - 2026-07-03 10:37:42 --> Language Class Initialized
INFO - 2026-07-03 10:37:42 --> Language Class Initialized
INFO - 2026-07-03 10:37:42 --> Config Class Initialized
INFO - 2026-07-03 10:37:42 --> Loader Class Initialized
INFO - 2026-07-03 10:37:42 --> Helper loaded: url_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: form_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: html_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: file_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: email_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:37:42 --> Database Driver Class Initialized
INFO - 2026-07-03 10:37:42 --> Config Class Initialized
INFO - 2026-07-03 10:37:42 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:37:42 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:37:42 --> Utf8 Class Initialized
INFO - 2026-07-03 10:37:42 --> URI Class Initialized
INFO - 2026-07-03 10:37:42 --> Router Class Initialized
INFO - 2026-07-03 10:37:42 --> Output Class Initialized
INFO - 2026-07-03 10:37:42 --> Security Class Initialized
DEBUG - 2026-07-03 10:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:37:42 --> CSRF cookie sent
INFO - 2026-07-03 10:37:42 --> Input Class Initialized
INFO - 2026-07-03 10:37:42 --> Language Class Initialized
INFO - 2026-07-03 10:37:42 --> Language Class Initialized
INFO - 2026-07-03 10:37:42 --> Config Class Initialized
INFO - 2026-07-03 10:37:42 --> Loader Class Initialized
INFO - 2026-07-03 10:37:42 --> Helper loaded: url_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: form_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: html_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: file_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: email_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:37:42 --> Database Driver Class Initialized
INFO - 2026-07-03 10:37:42 --> Config Class Initialized
INFO - 2026-07-03 10:37:42 --> Hooks Class Initialized
INFO - 2026-07-03 10:37:42 --> Config Class Initialized
INFO - 2026-07-03 10:37:42 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:37:42 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:37:42 --> Utf8 Class Initialized
DEBUG - 2026-07-03 10:37:42 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:37:42 --> Utf8 Class Initialized
INFO - 2026-07-03 10:37:42 --> URI Class Initialized
INFO - 2026-07-03 10:37:42 --> URI Class Initialized
INFO - 2026-07-03 10:37:42 --> Router Class Initialized
INFO - 2026-07-03 10:37:42 --> Output Class Initialized
INFO - 2026-07-03 10:37:42 --> Security Class Initialized
DEBUG - 2026-07-03 10:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:37:42 --> CSRF cookie sent
INFO - 2026-07-03 10:37:42 --> Input Class Initialized
INFO - 2026-07-03 10:37:42 --> Language Class Initialized
INFO - 2026-07-03 10:37:42 --> Config Class Initialized
INFO - 2026-07-03 10:37:42 --> Hooks Class Initialized
INFO - 2026-07-03 10:37:42 --> Language Class Initialized
INFO - 2026-07-03 10:37:42 --> Config Class Initialized
INFO - 2026-07-03 10:37:42 --> Router Class Initialized
DEBUG - 2026-07-03 10:37:42 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:37:42 --> Utf8 Class Initialized
INFO - 2026-07-03 10:37:42 --> URI Class Initialized
INFO - 2026-07-03 10:37:42 --> Output Class Initialized
INFO - 2026-07-03 10:37:42 --> Loader Class Initialized
INFO - 2026-07-03 10:37:42 --> Router Class Initialized
INFO - 2026-07-03 10:37:42 --> Security Class Initialized
INFO - 2026-07-03 10:37:42 --> Helper loaded: url_helper
INFO - 2026-07-03 10:37:42 --> Output Class Initialized
DEBUG - 2026-07-03 10:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:37:42 --> CSRF cookie sent
INFO - 2026-07-03 10:37:42 --> Input Class Initialized
INFO - 2026-07-03 10:37:42 --> Language Class Initialized
INFO - 2026-07-03 10:37:42 --> Helper loaded: form_helper
INFO - 2026-07-03 10:37:42 --> Security Class Initialized
INFO - 2026-07-03 10:37:42 --> Helper loaded: html_helper
INFO - 2026-07-03 10:37:42 --> Language Class Initialized
INFO - 2026-07-03 10:37:42 --> Config Class Initialized
INFO - 2026-07-03 10:37:42 --> Helper loaded: file_helper
DEBUG - 2026-07-03 10:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:37:42 --> CSRF cookie sent
INFO - 2026-07-03 10:37:42 --> Helper loaded: email_helper
INFO - 2026-07-03 10:37:42 --> Input Class Initialized
INFO - 2026-07-03 10:37:42 --> Language Class Initialized
INFO - 2026-07-03 10:37:42 --> Language Class Initialized
INFO - 2026-07-03 10:37:42 --> Config Class Initialized
INFO - 2026-07-03 10:37:42 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:37:42 --> Loader Class Initialized
INFO - 2026-07-03 10:37:42 --> Helper loaded: url_helper
INFO - 2026-07-03 10:37:42 --> Loader Class Initialized
INFO - 2026-07-03 10:37:42 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: url_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: form_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: html_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: form_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: file_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: html_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: email_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: file_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: email_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:37:42 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:37:42 --> Database Driver Class Initialized
INFO - 2026-07-03 10:37:42 --> Database Driver Class Initialized
INFO - 2026-07-03 10:37:42 --> Database Driver Class Initialized
INFO - 2026-07-03 10:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:37:44 --> Upload Class Initialized
DEBUG - 2026-07-03 10:37:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:37:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:37:44 --> Encryption Class Initialized
INFO - 2026-07-03 10:37:44 --> Form Validation Class Initialized
INFO - 2026-07-03 10:37:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:37:44 --> Pagination Class Initialized
INFO - 2026-07-03 10:37:44 --> Email Class Initialized
INFO - 2026-07-03 10:37:44 --> Controller Class Initialized
ERROR - 2026-07-03 10:37:44 --> 404 Page Not Found: /index
INFO - 2026-07-03 10:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:37:44 --> Upload Class Initialized
DEBUG - 2026-07-03 10:37:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:37:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:37:44 --> Encryption Class Initialized
INFO - 2026-07-03 10:37:44 --> Form Validation Class Initialized
INFO - 2026-07-03 10:37:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:37:44 --> Pagination Class Initialized
INFO - 2026-07-03 10:37:44 --> Email Class Initialized
INFO - 2026-07-03 10:37:44 --> Controller Class Initialized
INFO - 2026-07-03 10:37:44 --> Config Class Initialized
INFO - 2026-07-03 10:37:44 --> Hooks Class Initialized
ERROR - 2026-07-03 10:37:44 --> 404 Page Not Found: /index
INFO - 2026-07-03 10:37:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2026-07-03 10:37:44 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:37:44 --> Utf8 Class Initialized
INFO - 2026-07-03 10:37:44 --> Upload Class Initialized
INFO - 2026-07-03 10:37:44 --> URI Class Initialized
DEBUG - 2026-07-03 10:37:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:37:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:37:44 --> Encryption Class Initialized
INFO - 2026-07-03 10:37:44 --> Router Class Initialized
INFO - 2026-07-03 10:37:44 --> Output Class Initialized
INFO - 2026-07-03 10:37:44 --> Form Validation Class Initialized
INFO - 2026-07-03 10:37:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:37:44 --> Pagination Class Initialized
INFO - 2026-07-03 10:37:44 --> Security Class Initialized
DEBUG - 2026-07-03 10:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:37:44 --> CSRF cookie sent
INFO - 2026-07-03 10:37:44 --> Input Class Initialized
INFO - 2026-07-03 10:37:44 --> Language Class Initialized
INFO - 2026-07-03 10:37:44 --> Config Class Initialized
INFO - 2026-07-03 10:37:44 --> Hooks Class Initialized
INFO - 2026-07-03 10:37:44 --> Email Class Initialized
INFO - 2026-07-03 10:37:44 --> Controller Class Initialized
INFO - 2026-07-03 10:37:44 --> Language Class Initialized
INFO - 2026-07-03 10:37:44 --> Config Class Initialized
ERROR - 2026-07-03 10:37:44 --> 404 Page Not Found: /index
DEBUG - 2026-07-03 10:37:44 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:37:44 --> Utf8 Class Initialized
INFO - 2026-07-03 10:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:37:44 --> URI Class Initialized
INFO - 2026-07-03 10:37:44 --> Upload Class Initialized
INFO - 2026-07-03 10:37:44 --> Router Class Initialized
INFO - 2026-07-03 10:37:44 --> Loader Class Initialized
INFO - 2026-07-03 10:37:44 --> Helper loaded: url_helper
INFO - 2026-07-03 10:37:44 --> Output Class Initialized
DEBUG - 2026-07-03 10:37:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:37:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:37:44 --> Encryption Class Initialized
INFO - 2026-07-03 10:37:44 --> Helper loaded: form_helper
INFO - 2026-07-03 10:37:44 --> Security Class Initialized
INFO - 2026-07-03 10:37:44 --> Helper loaded: html_helper
INFO - 2026-07-03 10:37:44 --> Helper loaded: file_helper
INFO - 2026-07-03 10:37:44 --> Form Validation Class Initialized
INFO - 2026-07-03 10:37:44 --> Helper loaded: email_helper
DEBUG - 2026-07-03 10:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:37:44 --> CSRF cookie sent
INFO - 2026-07-03 10:37:44 --> Input Class Initialized
INFO - 2026-07-03 10:37:44 --> Language Class Initialized
INFO - 2026-07-03 10:37:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:37:44 --> Pagination Class Initialized
INFO - 2026-07-03 10:37:44 --> Language Class Initialized
INFO - 2026-07-03 10:37:44 --> Config Class Initialized
INFO - 2026-07-03 10:37:44 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:37:44 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:37:44 --> Email Class Initialized
INFO - 2026-07-03 10:37:44 --> Controller Class Initialized
INFO - 2026-07-03 10:37:44 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:37:44 --> Loader Class Initialized
ERROR - 2026-07-03 10:37:44 --> 404 Page Not Found: /index
INFO - 2026-07-03 10:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:37:44 --> Helper loaded: url_helper
INFO - 2026-07-03 10:37:44 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:37:44 --> Helper loaded: form_helper
INFO - 2026-07-03 10:37:44 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:37:44 --> Upload Class Initialized
INFO - 2026-07-03 10:37:44 --> Helper loaded: html_helper
INFO - 2026-07-03 10:37:44 --> Helper loaded: file_helper
INFO - 2026-07-03 10:37:44 --> Helper loaded: email_helper
DEBUG - 2026-07-03 10:37:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:37:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:37:44 --> Encryption Class Initialized
INFO - 2026-07-03 10:37:44 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:37:44 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:37:44 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:37:44 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:37:44 --> Form Validation Class Initialized
INFO - 2026-07-03 10:37:44 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:37:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:37:44 --> Pagination Class Initialized
INFO - 2026-07-03 10:37:44 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:37:44 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:37:44 --> Database Driver Class Initialized
INFO - 2026-07-03 10:37:44 --> Email Class Initialized
INFO - 2026-07-03 10:37:44 --> Controller Class Initialized
ERROR - 2026-07-03 10:37:44 --> 404 Page Not Found: /index
INFO - 2026-07-03 10:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:37:44 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:37:44 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:37:44 --> Upload Class Initialized
DEBUG - 2026-07-03 10:37:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:37:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:37:44 --> Encryption Class Initialized
INFO - 2026-07-03 10:37:44 --> Form Validation Class Initialized
INFO - 2026-07-03 10:37:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:37:44 --> Pagination Class Initialized
INFO - 2026-07-03 10:37:44 --> Database Driver Class Initialized
INFO - 2026-07-03 10:37:44 --> Email Class Initialized
INFO - 2026-07-03 10:37:44 --> Controller Class Initialized
ERROR - 2026-07-03 10:37:44 --> 404 Page Not Found: /index
INFO - 2026-07-03 10:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:37:45 --> Upload Class Initialized
DEBUG - 2026-07-03 10:37:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:37:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:37:45 --> Encryption Class Initialized
INFO - 2026-07-03 10:37:45 --> Form Validation Class Initialized
INFO - 2026-07-03 10:37:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:37:45 --> Pagination Class Initialized
INFO - 2026-07-03 10:37:45 --> Email Class Initialized
INFO - 2026-07-03 10:37:45 --> Controller Class Initialized
ERROR - 2026-07-03 10:37:45 --> 404 Page Not Found: /index
INFO - 2026-07-03 10:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:37:45 --> Upload Class Initialized
DEBUG - 2026-07-03 10:37:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:37:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:37:45 --> Encryption Class Initialized
INFO - 2026-07-03 10:37:45 --> Form Validation Class Initialized
INFO - 2026-07-03 10:37:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:37:45 --> Pagination Class Initialized
INFO - 2026-07-03 10:37:45 --> Email Class Initialized
INFO - 2026-07-03 10:37:45 --> Controller Class Initialized
DEBUG - 2026-07-03 10:37:45 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 10:37:45 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:37:45 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 10:37:46 --> Model "Dashboard_model" initialized
DEBUG - 2026-07-03 10:37:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 10:37:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 10:37:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 10:37:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-03 10:37:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 10:37:46 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/dashboard_index.php
INFO - 2026-07-03 10:37:46 --> Final output sent to browser
DEBUG - 2026-07-03 10:37:46 --> Total execution time: 2.0398
INFO - 2026-07-03 10:37:47 --> Config Class Initialized
INFO - 2026-07-03 10:37:47 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:37:47 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:37:47 --> Utf8 Class Initialized
INFO - 2026-07-03 10:37:47 --> URI Class Initialized
INFO - 2026-07-03 10:37:47 --> Router Class Initialized
INFO - 2026-07-03 10:37:47 --> Output Class Initialized
INFO - 2026-07-03 10:37:47 --> Security Class Initialized
DEBUG - 2026-07-03 10:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:37:47 --> CSRF cookie sent
INFO - 2026-07-03 10:37:47 --> Input Class Initialized
INFO - 2026-07-03 10:37:47 --> Language Class Initialized
INFO - 2026-07-03 10:37:47 --> Language Class Initialized
INFO - 2026-07-03 10:37:47 --> Config Class Initialized
INFO - 2026-07-03 10:37:47 --> Loader Class Initialized
INFO - 2026-07-03 10:37:47 --> Helper loaded: url_helper
INFO - 2026-07-03 10:37:47 --> Helper loaded: form_helper
INFO - 2026-07-03 10:37:47 --> Helper loaded: html_helper
INFO - 2026-07-03 10:37:47 --> Helper loaded: file_helper
INFO - 2026-07-03 10:37:47 --> Helper loaded: email_helper
INFO - 2026-07-03 10:37:47 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:37:47 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:37:47 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:37:47 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:37:47 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:37:47 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:37:47 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:37:47 --> Database Driver Class Initialized
INFO - 2026-07-03 10:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:37:49 --> Upload Class Initialized
DEBUG - 2026-07-03 10:37:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:37:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:37:49 --> Encryption Class Initialized
INFO - 2026-07-03 10:37:49 --> Form Validation Class Initialized
INFO - 2026-07-03 10:37:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:37:49 --> Pagination Class Initialized
INFO - 2026-07-03 10:37:49 --> Email Class Initialized
INFO - 2026-07-03 10:37:49 --> Controller Class Initialized
DEBUG - 2026-07-03 10:37:49 --> Softwareproduct MX_Controller Initialized
INFO - 2026-07-03 10:37:49 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:37:49 --> Model "Adminauth_model" initialized
DEBUG - 2026-07-03 10:37:49 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 10:37:49 --> Model "Plan_model" initialized
INFO - 2026-07-03 10:37:49 --> Model "Software_model" initialized
DEBUG - 2026-07-03 10:37:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 10:37:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 10:37:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 10:37:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-03 10:37:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 10:37:50 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/softwareproduct_list.php
INFO - 2026-07-03 10:37:50 --> Final output sent to browser
DEBUG - 2026-07-03 10:37:50 --> Total execution time: 3.1508
INFO - 2026-07-03 10:37:51 --> Config Class Initialized
INFO - 2026-07-03 10:37:51 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:37:51 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:37:51 --> Utf8 Class Initialized
INFO - 2026-07-03 10:37:51 --> URI Class Initialized
INFO - 2026-07-03 10:37:51 --> Router Class Initialized
INFO - 2026-07-03 10:37:51 --> Output Class Initialized
INFO - 2026-07-03 10:37:51 --> Security Class Initialized
DEBUG - 2026-07-03 10:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:37:51 --> CSRF cookie sent
INFO - 2026-07-03 10:37:51 --> Input Class Initialized
INFO - 2026-07-03 10:37:51 --> Language Class Initialized
INFO - 2026-07-03 10:37:51 --> Language Class Initialized
INFO - 2026-07-03 10:37:51 --> Config Class Initialized
INFO - 2026-07-03 10:37:51 --> Loader Class Initialized
INFO - 2026-07-03 10:37:51 --> Helper loaded: url_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: form_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: html_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: file_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: email_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:37:51 --> Database Driver Class Initialized
INFO - 2026-07-03 10:37:51 --> Config Class Initialized
INFO - 2026-07-03 10:37:51 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:37:51 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:37:51 --> Utf8 Class Initialized
INFO - 2026-07-03 10:37:51 --> URI Class Initialized
INFO - 2026-07-03 10:37:51 --> Router Class Initialized
INFO - 2026-07-03 10:37:51 --> Output Class Initialized
INFO - 2026-07-03 10:37:51 --> Security Class Initialized
DEBUG - 2026-07-03 10:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:37:51 --> CSRF cookie sent
INFO - 2026-07-03 10:37:51 --> Input Class Initialized
INFO - 2026-07-03 10:37:51 --> Language Class Initialized
INFO - 2026-07-03 10:37:51 --> Language Class Initialized
INFO - 2026-07-03 10:37:51 --> Config Class Initialized
INFO - 2026-07-03 10:37:51 --> Loader Class Initialized
INFO - 2026-07-03 10:37:51 --> Helper loaded: url_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: form_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: html_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: file_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: email_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:37:51 --> Database Driver Class Initialized
INFO - 2026-07-03 10:37:51 --> Config Class Initialized
INFO - 2026-07-03 10:37:51 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:37:51 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:37:51 --> Utf8 Class Initialized
INFO - 2026-07-03 10:37:51 --> Config Class Initialized
INFO - 2026-07-03 10:37:51 --> Hooks Class Initialized
INFO - 2026-07-03 10:37:51 --> URI Class Initialized
DEBUG - 2026-07-03 10:37:51 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:37:51 --> Utf8 Class Initialized
INFO - 2026-07-03 10:37:51 --> Router Class Initialized
INFO - 2026-07-03 10:37:51 --> URI Class Initialized
INFO - 2026-07-03 10:37:51 --> Output Class Initialized
INFO - 2026-07-03 10:37:51 --> Security Class Initialized
DEBUG - 2026-07-03 10:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:37:51 --> CSRF cookie sent
INFO - 2026-07-03 10:37:51 --> Input Class Initialized
INFO - 2026-07-03 10:37:51 --> Router Class Initialized
INFO - 2026-07-03 10:37:51 --> Language Class Initialized
INFO - 2026-07-03 10:37:51 --> Language Class Initialized
INFO - 2026-07-03 10:37:51 --> Config Class Initialized
INFO - 2026-07-03 10:37:51 --> Output Class Initialized
INFO - 2026-07-03 10:37:51 --> Loader Class Initialized
INFO - 2026-07-03 10:37:51 --> Security Class Initialized
INFO - 2026-07-03 10:37:51 --> Helper loaded: url_helper
DEBUG - 2026-07-03 10:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:37:51 --> CSRF cookie sent
INFO - 2026-07-03 10:37:51 --> Input Class Initialized
INFO - 2026-07-03 10:37:51 --> Helper loaded: form_helper
INFO - 2026-07-03 10:37:51 --> Language Class Initialized
INFO - 2026-07-03 10:37:51 --> Helper loaded: html_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: file_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: email_helper
INFO - 2026-07-03 10:37:51 --> Language Class Initialized
INFO - 2026-07-03 10:37:51 --> Config Class Initialized
INFO - 2026-07-03 10:37:51 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:37:51 --> Loader Class Initialized
INFO - 2026-07-03 10:37:51 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: url_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: form_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: html_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: file_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: email_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:37:51 --> Database Driver Class Initialized
INFO - 2026-07-03 10:37:51 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:37:51 --> Database Driver Class Initialized
INFO - 2026-07-03 10:37:51 --> Config Class Initialized
INFO - 2026-07-03 10:37:51 --> Hooks Class Initialized
INFO - 2026-07-03 10:37:51 --> Config Class Initialized
INFO - 2026-07-03 10:37:51 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:37:51 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:37:51 --> Utf8 Class Initialized
DEBUG - 2026-07-03 10:37:51 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:37:51 --> Utf8 Class Initialized
INFO - 2026-07-03 10:37:51 --> URI Class Initialized
INFO - 2026-07-03 10:37:51 --> URI Class Initialized
INFO - 2026-07-03 10:37:51 --> Router Class Initialized
INFO - 2026-07-03 10:37:51 --> Router Class Initialized
INFO - 2026-07-03 10:37:51 --> Output Class Initialized
INFO - 2026-07-03 10:37:51 --> Output Class Initialized
INFO - 2026-07-03 10:37:51 --> Security Class Initialized
INFO - 2026-07-03 10:37:51 --> Security Class Initialized
DEBUG - 2026-07-03 10:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:37:51 --> CSRF cookie sent
INFO - 2026-07-03 10:37:51 --> Input Class Initialized
DEBUG - 2026-07-03 10:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:37:51 --> CSRF cookie sent
INFO - 2026-07-03 10:37:51 --> Input Class Initialized
INFO - 2026-07-03 10:37:51 --> Language Class Initialized
INFO - 2026-07-03 10:37:51 --> Language Class Initialized
INFO - 2026-07-03 10:37:51 --> Language Class Initialized
INFO - 2026-07-03 10:37:51 --> Config Class Initialized
INFO - 2026-07-03 10:37:51 --> Language Class Initialized
INFO - 2026-07-03 10:37:51 --> Config Class Initialized
INFO - 2026-07-03 10:37:51 --> Loader Class Initialized
INFO - 2026-07-03 10:37:51 --> Loader Class Initialized
INFO - 2026-07-03 10:37:51 --> Helper loaded: url_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: url_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: form_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: form_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: html_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: html_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: file_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: email_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: file_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: email_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:37:51 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:37:51 --> Database Driver Class Initialized
INFO - 2026-07-03 10:37:51 --> Database Driver Class Initialized
INFO - 2026-07-03 10:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:37:52 --> Upload Class Initialized
DEBUG - 2026-07-03 10:37:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:37:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:37:52 --> Encryption Class Initialized
INFO - 2026-07-03 10:37:52 --> Form Validation Class Initialized
INFO - 2026-07-03 10:37:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:37:52 --> Pagination Class Initialized
INFO - 2026-07-03 10:37:52 --> Email Class Initialized
INFO - 2026-07-03 10:37:52 --> Controller Class Initialized
ERROR - 2026-07-03 10:37:52 --> 404 Page Not Found: /index
INFO - 2026-07-03 10:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:37:52 --> Upload Class Initialized
DEBUG - 2026-07-03 10:37:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:37:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:37:52 --> Encryption Class Initialized
INFO - 2026-07-03 10:37:52 --> Form Validation Class Initialized
INFO - 2026-07-03 10:37:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:37:52 --> Pagination Class Initialized
INFO - 2026-07-03 10:37:52 --> Config Class Initialized
INFO - 2026-07-03 10:37:52 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:37:52 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:37:52 --> Utf8 Class Initialized
INFO - 2026-07-03 10:37:52 --> URI Class Initialized
INFO - 2026-07-03 10:37:52 --> Email Class Initialized
INFO - 2026-07-03 10:37:52 --> Controller Class Initialized
INFO - 2026-07-03 10:37:52 --> Router Class Initialized
ERROR - 2026-07-03 10:37:52 --> 404 Page Not Found: /index
INFO - 2026-07-03 10:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:37:52 --> Output Class Initialized
INFO - 2026-07-03 10:37:52 --> Security Class Initialized
INFO - 2026-07-03 10:37:52 --> Upload Class Initialized
DEBUG - 2026-07-03 10:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:37:52 --> CSRF cookie sent
INFO - 2026-07-03 10:37:52 --> Input Class Initialized
INFO - 2026-07-03 10:37:52 --> Language Class Initialized
DEBUG - 2026-07-03 10:37:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:37:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:37:52 --> Encryption Class Initialized
INFO - 2026-07-03 10:37:52 --> Language Class Initialized
INFO - 2026-07-03 10:37:52 --> Config Class Initialized
INFO - 2026-07-03 10:37:52 --> Form Validation Class Initialized
INFO - 2026-07-03 10:37:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:37:52 --> Pagination Class Initialized
INFO - 2026-07-03 10:37:52 --> Loader Class Initialized
INFO - 2026-07-03 10:37:52 --> Helper loaded: url_helper
INFO - 2026-07-03 10:37:52 --> Helper loaded: form_helper
INFO - 2026-07-03 10:37:52 --> Email Class Initialized
INFO - 2026-07-03 10:37:52 --> Helper loaded: html_helper
INFO - 2026-07-03 10:37:52 --> Controller Class Initialized
INFO - 2026-07-03 10:37:52 --> Helper loaded: file_helper
ERROR - 2026-07-03 10:37:52 --> 404 Page Not Found: /index
INFO - 2026-07-03 10:37:52 --> Helper loaded: email_helper
INFO - 2026-07-03 10:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:37:52 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:37:52 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:37:52 --> Upload Class Initialized
INFO - 2026-07-03 10:37:52 --> Helper loaded: cpanel_helper
DEBUG - 2026-07-03 10:37:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:37:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:37:52 --> Encryption Class Initialized
INFO - 2026-07-03 10:37:52 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:37:52 --> Form Validation Class Initialized
INFO - 2026-07-03 10:37:52 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:37:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:37:52 --> Pagination Class Initialized
INFO - 2026-07-03 10:37:52 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:37:52 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:37:52 --> Email Class Initialized
INFO - 2026-07-03 10:37:52 --> Controller Class Initialized
ERROR - 2026-07-03 10:37:52 --> 404 Page Not Found: /index
INFO - 2026-07-03 10:37:52 --> Database Driver Class Initialized
INFO - 2026-07-03 10:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:37:53 --> Upload Class Initialized
DEBUG - 2026-07-03 10:37:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:37:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:37:53 --> Encryption Class Initialized
INFO - 2026-07-03 10:37:53 --> Form Validation Class Initialized
INFO - 2026-07-03 10:37:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:37:53 --> Pagination Class Initialized
INFO - 2026-07-03 10:37:53 --> Email Class Initialized
INFO - 2026-07-03 10:37:53 --> Controller Class Initialized
ERROR - 2026-07-03 10:37:53 --> 404 Page Not Found: /index
INFO - 2026-07-03 10:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:37:53 --> Upload Class Initialized
DEBUG - 2026-07-03 10:37:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:37:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:37:53 --> Encryption Class Initialized
INFO - 2026-07-03 10:37:53 --> Form Validation Class Initialized
INFO - 2026-07-03 10:37:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:37:53 --> Pagination Class Initialized
INFO - 2026-07-03 10:37:53 --> Email Class Initialized
INFO - 2026-07-03 10:37:53 --> Controller Class Initialized
ERROR - 2026-07-03 10:37:53 --> 404 Page Not Found: /index
INFO - 2026-07-03 10:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:37:54 --> Upload Class Initialized
DEBUG - 2026-07-03 10:37:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:37:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:37:54 --> Encryption Class Initialized
INFO - 2026-07-03 10:37:54 --> Form Validation Class Initialized
INFO - 2026-07-03 10:37:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:37:54 --> Pagination Class Initialized
INFO - 2026-07-03 10:37:54 --> Email Class Initialized
INFO - 2026-07-03 10:37:54 --> Controller Class Initialized
ERROR - 2026-07-03 10:37:54 --> 404 Page Not Found: /index
INFO - 2026-07-03 10:38:18 --> Config Class Initialized
INFO - 2026-07-03 10:38:18 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:38:18 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:38:18 --> Utf8 Class Initialized
INFO - 2026-07-03 10:38:18 --> URI Class Initialized
INFO - 2026-07-03 10:38:18 --> Router Class Initialized
INFO - 2026-07-03 10:38:18 --> Output Class Initialized
INFO - 2026-07-03 10:38:18 --> Security Class Initialized
DEBUG - 2026-07-03 10:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:38:18 --> CSRF cookie sent
INFO - 2026-07-03 10:38:18 --> Input Class Initialized
INFO - 2026-07-03 10:38:18 --> Language Class Initialized
INFO - 2026-07-03 10:38:18 --> Language Class Initialized
INFO - 2026-07-03 10:38:18 --> Config Class Initialized
INFO - 2026-07-03 10:38:18 --> Loader Class Initialized
INFO - 2026-07-03 10:38:18 --> Helper loaded: url_helper
INFO - 2026-07-03 10:38:18 --> Helper loaded: form_helper
INFO - 2026-07-03 10:38:18 --> Helper loaded: html_helper
INFO - 2026-07-03 10:38:18 --> Helper loaded: file_helper
INFO - 2026-07-03 10:38:18 --> Helper loaded: email_helper
INFO - 2026-07-03 10:38:18 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:38:18 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:38:18 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:38:18 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:38:18 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:38:18 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:38:18 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:38:18 --> Database Driver Class Initialized
INFO - 2026-07-03 10:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:38:19 --> Upload Class Initialized
DEBUG - 2026-07-03 10:38:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:38:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:38:19 --> Encryption Class Initialized
INFO - 2026-07-03 10:38:19 --> Form Validation Class Initialized
INFO - 2026-07-03 10:38:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:38:19 --> Pagination Class Initialized
INFO - 2026-07-03 10:38:19 --> Email Class Initialized
INFO - 2026-07-03 10:38:19 --> Controller Class Initialized
DEBUG - 2026-07-03 10:38:19 --> Cart MX_Controller Initialized
INFO - 2026-07-03 10:38:19 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:38:19 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:38:19 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:38:20 --> Model "Common_model" initialized
INFO - 2026-07-03 10:38:20 --> Model "Order_model" initialized
INFO - 2026-07-03 10:38:20 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 10:38:20 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 10:38:20 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 10:38:20 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 10:38:20 --> Model "Plan_model" initialized
INFO - 2026-07-03 10:38:20 --> Model "Orderlicense_model" initialized
DEBUG - 2026-07-03 10:38:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 10:38:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 10:38:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 10:38:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/cart_software.php
INFO - 2026-07-03 10:38:21 --> Final output sent to browser
DEBUG - 2026-07-03 10:38:21 --> Total execution time: 3.8301
INFO - 2026-07-03 10:38:32 --> Config Class Initialized
INFO - 2026-07-03 10:38:32 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:38:32 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:38:32 --> Utf8 Class Initialized
INFO - 2026-07-03 10:38:32 --> URI Class Initialized
INFO - 2026-07-03 10:38:32 --> Router Class Initialized
INFO - 2026-07-03 10:38:32 --> Output Class Initialized
INFO - 2026-07-03 10:38:32 --> Security Class Initialized
DEBUG - 2026-07-03 10:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:38:32 --> CSRF cookie sent
INFO - 2026-07-03 10:38:32 --> Input Class Initialized
INFO - 2026-07-03 10:38:32 --> Language Class Initialized
INFO - 2026-07-03 10:38:32 --> Language Class Initialized
INFO - 2026-07-03 10:38:32 --> Config Class Initialized
INFO - 2026-07-03 10:38:32 --> Loader Class Initialized
INFO - 2026-07-03 10:38:32 --> Helper loaded: url_helper
INFO - 2026-07-03 10:38:32 --> Helper loaded: form_helper
INFO - 2026-07-03 10:38:32 --> Helper loaded: html_helper
INFO - 2026-07-03 10:38:32 --> Helper loaded: file_helper
INFO - 2026-07-03 10:38:32 --> Helper loaded: email_helper
INFO - 2026-07-03 10:38:32 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:38:32 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:38:32 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:38:32 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:38:32 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:38:32 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:38:32 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:38:32 --> Database Driver Class Initialized
INFO - 2026-07-03 10:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:38:34 --> Upload Class Initialized
DEBUG - 2026-07-03 10:38:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:38:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:38:34 --> Encryption Class Initialized
INFO - 2026-07-03 10:38:34 --> Form Validation Class Initialized
INFO - 2026-07-03 10:38:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:38:34 --> Pagination Class Initialized
INFO - 2026-07-03 10:38:34 --> Email Class Initialized
INFO - 2026-07-03 10:38:34 --> Controller Class Initialized
DEBUG - 2026-07-03 10:38:34 --> Cart MX_Controller Initialized
INFO - 2026-07-03 10:38:34 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:38:34 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:38:34 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:38:34 --> Model "Common_model" initialized
INFO - 2026-07-03 10:38:34 --> Model "Order_model" initialized
INFO - 2026-07-03 10:38:34 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 10:38:34 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 10:38:34 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 10:38:34 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 10:38:34 --> Model "Plan_model" initialized
INFO - 2026-07-03 10:38:34 --> Model "Orderlicense_model" initialized
DEBUG - 2026-07-03 10:38:35 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 10:38:35 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 10:38:35 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 10:38:35 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/cart/views/cart_software.php
INFO - 2026-07-03 10:38:35 --> Final output sent to browser
DEBUG - 2026-07-03 10:38:35 --> Total execution time: 3.4054
INFO - 2026-07-03 10:38:35 --> Config Class Initialized
INFO - 2026-07-03 10:38:35 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:38:35 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:38:35 --> Utf8 Class Initialized
INFO - 2026-07-03 10:38:35 --> URI Class Initialized
INFO - 2026-07-03 10:38:35 --> Router Class Initialized
INFO - 2026-07-03 10:38:35 --> Output Class Initialized
INFO - 2026-07-03 10:38:35 --> Security Class Initialized
DEBUG - 2026-07-03 10:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:38:35 --> CSRF cookie sent
INFO - 2026-07-03 10:38:35 --> Input Class Initialized
INFO - 2026-07-03 10:38:35 --> Language Class Initialized
INFO - 2026-07-03 10:38:35 --> Language Class Initialized
INFO - 2026-07-03 10:38:35 --> Config Class Initialized
INFO - 2026-07-03 10:38:35 --> Loader Class Initialized
INFO - 2026-07-03 10:38:35 --> Helper loaded: url_helper
INFO - 2026-07-03 10:38:35 --> Helper loaded: form_helper
INFO - 2026-07-03 10:38:35 --> Helper loaded: html_helper
INFO - 2026-07-03 10:38:35 --> Helper loaded: file_helper
INFO - 2026-07-03 10:38:35 --> Helper loaded: email_helper
INFO - 2026-07-03 10:38:35 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:38:35 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:38:35 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:38:35 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:38:35 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:38:35 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:38:35 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:38:35 --> Database Driver Class Initialized
INFO - 2026-07-03 10:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:38:37 --> Upload Class Initialized
DEBUG - 2026-07-03 10:38:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:38:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:38:37 --> Encryption Class Initialized
INFO - 2026-07-03 10:38:37 --> Form Validation Class Initialized
INFO - 2026-07-03 10:38:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:38:37 --> Pagination Class Initialized
INFO - 2026-07-03 10:38:37 --> Email Class Initialized
INFO - 2026-07-03 10:38:37 --> Controller Class Initialized
DEBUG - 2026-07-03 10:38:37 --> Cart MX_Controller Initialized
INFO - 2026-07-03 10:38:37 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:38:37 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:38:37 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:38:37 --> Model "Common_model" initialized
INFO - 2026-07-03 10:38:37 --> Model "Order_model" initialized
INFO - 2026-07-03 10:38:37 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 10:38:37 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 10:38:37 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 10:38:37 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 10:38:37 --> Model "Plan_model" initialized
INFO - 2026-07-03 10:38:37 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 10:38:38 --> Final output sent to browser
DEBUG - 2026-07-03 10:38:38 --> Total execution time: 2.3248
INFO - 2026-07-03 10:38:43 --> Config Class Initialized
INFO - 2026-07-03 10:38:43 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:38:43 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:38:43 --> Utf8 Class Initialized
INFO - 2026-07-03 10:38:43 --> URI Class Initialized
INFO - 2026-07-03 10:38:43 --> Router Class Initialized
INFO - 2026-07-03 10:38:43 --> Output Class Initialized
INFO - 2026-07-03 10:38:43 --> Security Class Initialized
DEBUG - 2026-07-03 10:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:38:43 --> CSRF cookie sent
INFO - 2026-07-03 10:38:43 --> Input Class Initialized
INFO - 2026-07-03 10:38:43 --> Language Class Initialized
INFO - 2026-07-03 10:38:43 --> Language Class Initialized
INFO - 2026-07-03 10:38:43 --> Config Class Initialized
INFO - 2026-07-03 10:38:43 --> Loader Class Initialized
INFO - 2026-07-03 10:38:43 --> Helper loaded: url_helper
INFO - 2026-07-03 10:38:43 --> Helper loaded: form_helper
INFO - 2026-07-03 10:38:43 --> Helper loaded: html_helper
INFO - 2026-07-03 10:38:43 --> Helper loaded: file_helper
INFO - 2026-07-03 10:38:43 --> Helper loaded: email_helper
INFO - 2026-07-03 10:38:43 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:38:43 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:38:43 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:38:43 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:38:43 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:38:43 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:38:43 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:38:43 --> Database Driver Class Initialized
INFO - 2026-07-03 10:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:38:45 --> Upload Class Initialized
DEBUG - 2026-07-03 10:38:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:38:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:38:45 --> Encryption Class Initialized
INFO - 2026-07-03 10:38:45 --> Form Validation Class Initialized
INFO - 2026-07-03 10:38:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:38:45 --> Pagination Class Initialized
INFO - 2026-07-03 10:38:45 --> Email Class Initialized
INFO - 2026-07-03 10:38:45 --> Controller Class Initialized
DEBUG - 2026-07-03 10:38:45 --> Subscription MX_Controller Initialized
INFO - 2026-07-03 10:38:45 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:38:45 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:38:45 --> Model "Cart_model" initialized
DEBUG - 2026-07-03 10:38:45 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 10:38:45 --> Model "Plan_model" initialized
INFO - 2026-07-03 10:38:45 --> Model "Order_model" initialized
INFO - 2026-07-03 10:38:45 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 10:38:45 --> Model "Subscription_model" initialized
INFO - 2026-07-03 10:38:45 --> Model "Software_model" initialized
DEBUG - 2026-07-03 10:38:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 10:38:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 10:38:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 10:38:45 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/subscription/views/subscription_index.php
INFO - 2026-07-03 10:38:45 --> Final output sent to browser
DEBUG - 2026-07-03 10:38:45 --> Total execution time: 2.3980
INFO - 2026-07-03 10:38:45 --> Config Class Initialized
INFO - 2026-07-03 10:38:45 --> Hooks Class Initialized
DEBUG - 2026-07-03 10:38:45 --> UTF-8 Support Enabled
INFO - 2026-07-03 10:38:45 --> Utf8 Class Initialized
INFO - 2026-07-03 10:38:45 --> URI Class Initialized
INFO - 2026-07-03 10:38:45 --> Router Class Initialized
INFO - 2026-07-03 10:38:45 --> Output Class Initialized
INFO - 2026-07-03 10:38:45 --> Security Class Initialized
DEBUG - 2026-07-03 10:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 10:38:45 --> CSRF cookie sent
INFO - 2026-07-03 10:38:45 --> Input Class Initialized
INFO - 2026-07-03 10:38:45 --> Language Class Initialized
INFO - 2026-07-03 10:38:45 --> Language Class Initialized
INFO - 2026-07-03 10:38:45 --> Config Class Initialized
INFO - 2026-07-03 10:38:45 --> Loader Class Initialized
INFO - 2026-07-03 10:38:45 --> Helper loaded: url_helper
INFO - 2026-07-03 10:38:45 --> Helper loaded: form_helper
INFO - 2026-07-03 10:38:45 --> Helper loaded: html_helper
INFO - 2026-07-03 10:38:45 --> Helper loaded: file_helper
INFO - 2026-07-03 10:38:45 --> Helper loaded: email_helper
INFO - 2026-07-03 10:38:45 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 10:38:45 --> Helper loaded: ssp_helper
INFO - 2026-07-03 10:38:45 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 10:38:45 --> Helper loaded: plesk_helper
INFO - 2026-07-03 10:38:45 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 10:38:45 --> Helper loaded: domain_helper
INFO - 2026-07-03 10:38:45 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 10:38:45 --> Database Driver Class Initialized
INFO - 2026-07-03 10:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 10:38:47 --> Upload Class Initialized
DEBUG - 2026-07-03 10:38:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 10:38:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 10:38:47 --> Encryption Class Initialized
INFO - 2026-07-03 10:38:47 --> Form Validation Class Initialized
INFO - 2026-07-03 10:38:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 10:38:47 --> Pagination Class Initialized
INFO - 2026-07-03 10:38:47 --> Email Class Initialized
INFO - 2026-07-03 10:38:47 --> Controller Class Initialized
DEBUG - 2026-07-03 10:38:47 --> Cart MX_Controller Initialized
INFO - 2026-07-03 10:38:47 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 10:38:47 --> Model "Auth_model" initialized
INFO - 2026-07-03 10:38:47 --> Model "Cart_model" initialized
INFO - 2026-07-03 10:38:47 --> Model "Common_model" initialized
INFO - 2026-07-03 10:38:47 --> Model "Order_model" initialized
INFO - 2026-07-03 10:38:47 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 10:38:47 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 10:38:47 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 10:38:47 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 10:38:47 --> Model "Plan_model" initialized
INFO - 2026-07-03 10:38:47 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 10:38:47 --> Final output sent to browser
DEBUG - 2026-07-03 10:38:47 --> Total execution time: 2.0419
INFO - 2026-07-03 11:23:27 --> Config Class Initialized
INFO - 2026-07-03 11:23:27 --> Hooks Class Initialized
DEBUG - 2026-07-03 11:23:27 --> UTF-8 Support Enabled
INFO - 2026-07-03 11:23:27 --> Utf8 Class Initialized
INFO - 2026-07-03 11:23:27 --> URI Class Initialized
INFO - 2026-07-03 11:23:27 --> Router Class Initialized
INFO - 2026-07-03 11:23:27 --> Output Class Initialized
INFO - 2026-07-03 11:23:27 --> Security Class Initialized
DEBUG - 2026-07-03 11:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 11:23:27 --> CSRF cookie sent
INFO - 2026-07-03 11:23:27 --> Input Class Initialized
INFO - 2026-07-03 11:23:27 --> Language Class Initialized
INFO - 2026-07-03 11:23:27 --> Language Class Initialized
INFO - 2026-07-03 11:23:27 --> Config Class Initialized
INFO - 2026-07-03 11:23:27 --> Loader Class Initialized
INFO - 2026-07-03 11:23:27 --> Helper loaded: url_helper
INFO - 2026-07-03 11:23:27 --> Helper loaded: form_helper
INFO - 2026-07-03 11:23:27 --> Helper loaded: html_helper
INFO - 2026-07-03 11:23:27 --> Helper loaded: file_helper
INFO - 2026-07-03 11:23:27 --> Helper loaded: email_helper
INFO - 2026-07-03 11:23:27 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 11:23:27 --> Helper loaded: ssp_helper
INFO - 2026-07-03 11:23:27 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 11:23:27 --> Helper loaded: plesk_helper
INFO - 2026-07-03 11:23:27 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 11:23:27 --> Helper loaded: domain_helper
INFO - 2026-07-03 11:23:27 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 11:23:27 --> Database Driver Class Initialized
ERROR - 2026-07-03 11:23:37 --> Severity: error --> Exception: Connection timed out /opt/lampp/htdocs/ci-crm/whmaz/database/drivers/mysqli/mysqli_driver.php 203
INFO - 2026-07-03 11:25:38 --> Config Class Initialized
INFO - 2026-07-03 11:25:38 --> Hooks Class Initialized
DEBUG - 2026-07-03 11:25:38 --> UTF-8 Support Enabled
INFO - 2026-07-03 11:25:38 --> Utf8 Class Initialized
INFO - 2026-07-03 11:25:38 --> URI Class Initialized
INFO - 2026-07-03 11:25:38 --> Router Class Initialized
INFO - 2026-07-03 11:25:38 --> Output Class Initialized
INFO - 2026-07-03 11:25:38 --> Security Class Initialized
DEBUG - 2026-07-03 11:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 11:25:38 --> CSRF cookie sent
INFO - 2026-07-03 11:25:38 --> Input Class Initialized
INFO - 2026-07-03 11:25:38 --> Language Class Initialized
INFO - 2026-07-03 11:25:38 --> Language Class Initialized
INFO - 2026-07-03 11:25:38 --> Config Class Initialized
INFO - 2026-07-03 11:25:38 --> Loader Class Initialized
INFO - 2026-07-03 11:25:38 --> Helper loaded: url_helper
INFO - 2026-07-03 11:25:38 --> Helper loaded: form_helper
INFO - 2026-07-03 11:25:38 --> Helper loaded: html_helper
INFO - 2026-07-03 11:25:38 --> Helper loaded: file_helper
INFO - 2026-07-03 11:25:38 --> Helper loaded: email_helper
INFO - 2026-07-03 11:25:38 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 11:25:38 --> Helper loaded: ssp_helper
INFO - 2026-07-03 11:25:38 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 11:25:38 --> Helper loaded: plesk_helper
INFO - 2026-07-03 11:25:38 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 11:25:38 --> Helper loaded: domain_helper
INFO - 2026-07-03 11:25:38 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 11:25:38 --> Database Driver Class Initialized
ERROR - 2026-07-03 11:25:48 --> Severity: error --> Exception: Connection timed out /opt/lampp/htdocs/ci-crm/whmaz/database/drivers/mysqli/mysqli_driver.php 203
INFO - 2026-07-03 11:27:02 --> Config Class Initialized
INFO - 2026-07-03 11:27:02 --> Hooks Class Initialized
DEBUG - 2026-07-03 11:27:02 --> UTF-8 Support Enabled
INFO - 2026-07-03 11:27:02 --> Utf8 Class Initialized
INFO - 2026-07-03 11:27:02 --> URI Class Initialized
INFO - 2026-07-03 11:27:02 --> Router Class Initialized
INFO - 2026-07-03 11:27:02 --> Output Class Initialized
INFO - 2026-07-03 11:27:02 --> Security Class Initialized
DEBUG - 2026-07-03 11:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 11:27:02 --> CSRF cookie sent
INFO - 2026-07-03 11:27:02 --> Input Class Initialized
INFO - 2026-07-03 11:27:02 --> Language Class Initialized
INFO - 2026-07-03 11:27:02 --> Language Class Initialized
INFO - 2026-07-03 11:27:02 --> Config Class Initialized
INFO - 2026-07-03 11:27:02 --> Loader Class Initialized
INFO - 2026-07-03 11:27:02 --> Helper loaded: url_helper
INFO - 2026-07-03 11:27:02 --> Helper loaded: form_helper
INFO - 2026-07-03 11:27:02 --> Helper loaded: html_helper
INFO - 2026-07-03 11:27:02 --> Helper loaded: file_helper
INFO - 2026-07-03 11:27:02 --> Helper loaded: email_helper
INFO - 2026-07-03 11:27:02 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 11:27:02 --> Helper loaded: ssp_helper
INFO - 2026-07-03 11:27:02 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 11:27:02 --> Helper loaded: plesk_helper
INFO - 2026-07-03 11:27:02 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 11:27:02 --> Helper loaded: domain_helper
INFO - 2026-07-03 11:27:02 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 11:27:02 --> Database Driver Class Initialized
ERROR - 2026-07-03 11:27:12 --> Severity: error --> Exception: Connection timed out /opt/lampp/htdocs/ci-crm/whmaz/database/drivers/mysqli/mysqli_driver.php 203
INFO - 2026-07-03 11:27:12 --> Config Class Initialized
INFO - 2026-07-03 11:27:12 --> Hooks Class Initialized
DEBUG - 2026-07-03 11:27:12 --> UTF-8 Support Enabled
INFO - 2026-07-03 11:27:12 --> Utf8 Class Initialized
INFO - 2026-07-03 11:27:12 --> URI Class Initialized
INFO - 2026-07-03 11:27:12 --> Router Class Initialized
INFO - 2026-07-03 11:27:12 --> Output Class Initialized
INFO - 2026-07-03 11:27:12 --> Security Class Initialized
DEBUG - 2026-07-03 11:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 11:27:12 --> CSRF cookie sent
INFO - 2026-07-03 11:27:12 --> Input Class Initialized
INFO - 2026-07-03 11:27:12 --> Language Class Initialized
INFO - 2026-07-03 11:27:12 --> Language Class Initialized
INFO - 2026-07-03 11:27:12 --> Config Class Initialized
INFO - 2026-07-03 11:27:12 --> Loader Class Initialized
INFO - 2026-07-03 11:27:12 --> Helper loaded: url_helper
INFO - 2026-07-03 11:27:12 --> Helper loaded: form_helper
INFO - 2026-07-03 11:27:12 --> Helper loaded: html_helper
INFO - 2026-07-03 11:27:12 --> Helper loaded: file_helper
INFO - 2026-07-03 11:27:12 --> Helper loaded: email_helper
INFO - 2026-07-03 11:27:12 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 11:27:12 --> Helper loaded: ssp_helper
INFO - 2026-07-03 11:27:12 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 11:27:12 --> Helper loaded: plesk_helper
INFO - 2026-07-03 11:27:12 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 11:27:12 --> Helper loaded: domain_helper
INFO - 2026-07-03 11:27:12 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 11:27:12 --> Database Driver Class Initialized
ERROR - 2026-07-03 11:27:22 --> Severity: error --> Exception: Connection timed out /opt/lampp/htdocs/ci-crm/whmaz/database/drivers/mysqli/mysqli_driver.php 203
INFO - 2026-07-03 11:27:22 --> Config Class Initialized
INFO - 2026-07-03 11:27:22 --> Hooks Class Initialized
DEBUG - 2026-07-03 11:27:22 --> UTF-8 Support Enabled
INFO - 2026-07-03 11:27:22 --> Utf8 Class Initialized
INFO - 2026-07-03 11:27:22 --> URI Class Initialized
INFO - 2026-07-03 11:27:22 --> Router Class Initialized
INFO - 2026-07-03 11:27:22 --> Output Class Initialized
INFO - 2026-07-03 11:27:22 --> Security Class Initialized
DEBUG - 2026-07-03 11:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 11:27:22 --> CSRF cookie sent
INFO - 2026-07-03 11:27:22 --> Input Class Initialized
INFO - 2026-07-03 11:27:22 --> Language Class Initialized
INFO - 2026-07-03 11:27:22 --> Language Class Initialized
INFO - 2026-07-03 11:27:22 --> Config Class Initialized
INFO - 2026-07-03 11:27:22 --> Loader Class Initialized
INFO - 2026-07-03 11:27:22 --> Helper loaded: url_helper
INFO - 2026-07-03 11:27:22 --> Helper loaded: form_helper
INFO - 2026-07-03 11:27:22 --> Helper loaded: html_helper
INFO - 2026-07-03 11:27:22 --> Helper loaded: file_helper
INFO - 2026-07-03 11:27:22 --> Helper loaded: email_helper
INFO - 2026-07-03 11:27:22 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 11:27:22 --> Helper loaded: ssp_helper
INFO - 2026-07-03 11:27:22 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 11:27:22 --> Helper loaded: plesk_helper
INFO - 2026-07-03 11:27:22 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 11:27:22 --> Helper loaded: domain_helper
INFO - 2026-07-03 11:27:22 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 11:27:22 --> Database Driver Class Initialized
ERROR - 2026-07-03 11:27:32 --> Severity: error --> Exception: Connection timed out /opt/lampp/htdocs/ci-crm/whmaz/database/drivers/mysqli/mysqli_driver.php 203
INFO - 2026-07-03 11:29:46 --> Config Class Initialized
INFO - 2026-07-03 11:29:46 --> Hooks Class Initialized
DEBUG - 2026-07-03 11:29:46 --> UTF-8 Support Enabled
INFO - 2026-07-03 11:29:46 --> Utf8 Class Initialized
INFO - 2026-07-03 11:29:46 --> URI Class Initialized
INFO - 2026-07-03 11:29:46 --> Router Class Initialized
INFO - 2026-07-03 11:29:46 --> Output Class Initialized
INFO - 2026-07-03 11:29:46 --> Security Class Initialized
DEBUG - 2026-07-03 11:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 11:29:46 --> CSRF cookie sent
INFO - 2026-07-03 11:29:46 --> Input Class Initialized
INFO - 2026-07-03 11:29:46 --> Language Class Initialized
INFO - 2026-07-03 11:29:46 --> Language Class Initialized
INFO - 2026-07-03 11:29:46 --> Config Class Initialized
INFO - 2026-07-03 11:29:46 --> Loader Class Initialized
INFO - 2026-07-03 11:29:46 --> Helper loaded: url_helper
INFO - 2026-07-03 11:29:46 --> Helper loaded: form_helper
INFO - 2026-07-03 11:29:46 --> Helper loaded: html_helper
INFO - 2026-07-03 11:29:46 --> Helper loaded: file_helper
INFO - 2026-07-03 11:29:46 --> Helper loaded: email_helper
INFO - 2026-07-03 11:29:46 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 11:29:46 --> Helper loaded: ssp_helper
INFO - 2026-07-03 11:29:46 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 11:29:46 --> Helper loaded: plesk_helper
INFO - 2026-07-03 11:29:46 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 11:29:46 --> Helper loaded: domain_helper
INFO - 2026-07-03 11:29:46 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 11:29:46 --> Database Driver Class Initialized
ERROR - 2026-07-03 11:29:56 --> Severity: error --> Exception: Connection timed out /opt/lampp/htdocs/ci-crm/whmaz/database/drivers/mysqli/mysqli_driver.php 203
INFO - 2026-07-03 17:24:47 --> Config Class Initialized
INFO - 2026-07-03 17:24:47 --> Hooks Class Initialized
DEBUG - 2026-07-03 17:24:47 --> UTF-8 Support Enabled
INFO - 2026-07-03 17:24:47 --> Utf8 Class Initialized
INFO - 2026-07-03 17:24:47 --> URI Class Initialized
DEBUG - 2026-07-03 17:24:47 --> No URI present. Default controller set.
INFO - 2026-07-03 17:24:47 --> Router Class Initialized
INFO - 2026-07-03 17:24:47 --> Output Class Initialized
INFO - 2026-07-03 17:24:47 --> Security Class Initialized
DEBUG - 2026-07-03 17:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 17:24:47 --> CSRF cookie sent
INFO - 2026-07-03 17:24:47 --> Input Class Initialized
INFO - 2026-07-03 17:24:47 --> Language Class Initialized
INFO - 2026-07-03 17:24:47 --> Language Class Initialized
INFO - 2026-07-03 17:24:47 --> Config Class Initialized
INFO - 2026-07-03 17:24:47 --> Loader Class Initialized
INFO - 2026-07-03 17:24:47 --> Helper loaded: url_helper
INFO - 2026-07-03 17:24:47 --> Helper loaded: form_helper
INFO - 2026-07-03 17:24:47 --> Helper loaded: html_helper
INFO - 2026-07-03 17:24:47 --> Helper loaded: file_helper
INFO - 2026-07-03 17:24:47 --> Helper loaded: email_helper
INFO - 2026-07-03 17:24:47 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 17:24:47 --> Helper loaded: ssp_helper
INFO - 2026-07-03 17:24:47 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 17:24:47 --> Helper loaded: plesk_helper
INFO - 2026-07-03 17:24:47 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 17:24:47 --> Helper loaded: domain_helper
INFO - 2026-07-03 17:24:47 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 17:24:47 --> Database Driver Class Initialized
INFO - 2026-07-03 17:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 17:24:49 --> Upload Class Initialized
DEBUG - 2026-07-03 17:24:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 17:24:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 17:24:49 --> Encryption Class Initialized
INFO - 2026-07-03 17:24:49 --> Form Validation Class Initialized
INFO - 2026-07-03 17:24:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 17:24:49 --> Pagination Class Initialized
INFO - 2026-07-03 17:24:49 --> Email Class Initialized
INFO - 2026-07-03 17:24:49 --> Controller Class Initialized
DEBUG - 2026-07-03 17:24:49 --> Auth MX_Controller Initialized
INFO - 2026-07-03 17:24:49 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 17:24:49 --> Model "Auth_model" initialized
INFO - 2026-07-03 17:24:49 --> Model "Cart_model" initialized
INFO - 2026-07-03 17:24:49 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 17:24:49 --> Config Class Initialized
INFO - 2026-07-03 17:24:49 --> Hooks Class Initialized
DEBUG - 2026-07-03 17:24:49 --> UTF-8 Support Enabled
INFO - 2026-07-03 17:24:49 --> Utf8 Class Initialized
INFO - 2026-07-03 17:24:49 --> URI Class Initialized
INFO - 2026-07-03 17:24:49 --> Router Class Initialized
INFO - 2026-07-03 17:24:49 --> Output Class Initialized
INFO - 2026-07-03 17:24:49 --> Security Class Initialized
DEBUG - 2026-07-03 17:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 17:24:49 --> CSRF cookie sent
INFO - 2026-07-03 17:24:49 --> Input Class Initialized
INFO - 2026-07-03 17:24:49 --> Language Class Initialized
INFO - 2026-07-03 17:24:49 --> Language Class Initialized
INFO - 2026-07-03 17:24:49 --> Config Class Initialized
INFO - 2026-07-03 17:24:49 --> Loader Class Initialized
INFO - 2026-07-03 17:24:49 --> Helper loaded: url_helper
INFO - 2026-07-03 17:24:49 --> Helper loaded: form_helper
INFO - 2026-07-03 17:24:49 --> Helper loaded: html_helper
INFO - 2026-07-03 17:24:49 --> Helper loaded: file_helper
INFO - 2026-07-03 17:24:49 --> Helper loaded: email_helper
INFO - 2026-07-03 17:24:49 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 17:24:49 --> Helper loaded: ssp_helper
INFO - 2026-07-03 17:24:49 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 17:24:49 --> Helper loaded: plesk_helper
INFO - 2026-07-03 17:24:49 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 17:24:49 --> Helper loaded: domain_helper
INFO - 2026-07-03 17:24:49 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 17:24:49 --> Database Driver Class Initialized
INFO - 2026-07-03 17:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 17:24:51 --> Upload Class Initialized
DEBUG - 2026-07-03 17:24:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 17:24:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 17:24:51 --> Encryption Class Initialized
INFO - 2026-07-03 17:24:51 --> Form Validation Class Initialized
INFO - 2026-07-03 17:24:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 17:24:51 --> Pagination Class Initialized
INFO - 2026-07-03 17:24:51 --> Email Class Initialized
INFO - 2026-07-03 17:24:51 --> Controller Class Initialized
DEBUG - 2026-07-03 17:24:51 --> Auth MX_Controller Initialized
INFO - 2026-07-03 17:24:51 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 17:24:51 --> Model "Auth_model" initialized
INFO - 2026-07-03 17:24:51 --> Model "Cart_model" initialized
INFO - 2026-07-03 17:24:51 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-03 17:24:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/header.php
DEBUG - 2026-07-03 17:24:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer_script.php
DEBUG - 2026-07-03 17:24:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/templates/customer/footer.php
DEBUG - 2026-07-03 17:24:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/modules/auth/views/auth_login.php
INFO - 2026-07-03 17:24:52 --> Final output sent to browser
DEBUG - 2026-07-03 17:24:52 --> Total execution time: 2.5901
INFO - 2026-07-03 17:24:52 --> Config Class Initialized
INFO - 2026-07-03 17:24:52 --> Hooks Class Initialized
DEBUG - 2026-07-03 17:24:52 --> UTF-8 Support Enabled
INFO - 2026-07-03 17:24:52 --> Utf8 Class Initialized
INFO - 2026-07-03 17:24:52 --> URI Class Initialized
INFO - 2026-07-03 17:24:52 --> Router Class Initialized
INFO - 2026-07-03 17:24:52 --> Output Class Initialized
INFO - 2026-07-03 17:24:52 --> Security Class Initialized
DEBUG - 2026-07-03 17:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 17:24:52 --> CSRF cookie sent
INFO - 2026-07-03 17:24:52 --> Input Class Initialized
INFO - 2026-07-03 17:24:52 --> Language Class Initialized
INFO - 2026-07-03 17:24:52 --> Language Class Initialized
INFO - 2026-07-03 17:24:52 --> Config Class Initialized
INFO - 2026-07-03 17:24:52 --> Loader Class Initialized
INFO - 2026-07-03 17:24:52 --> Helper loaded: url_helper
INFO - 2026-07-03 17:24:52 --> Helper loaded: form_helper
INFO - 2026-07-03 17:24:52 --> Helper loaded: html_helper
INFO - 2026-07-03 17:24:52 --> Helper loaded: file_helper
INFO - 2026-07-03 17:24:52 --> Helper loaded: email_helper
INFO - 2026-07-03 17:24:52 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 17:24:52 --> Helper loaded: ssp_helper
INFO - 2026-07-03 17:24:52 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 17:24:52 --> Helper loaded: plesk_helper
INFO - 2026-07-03 17:24:52 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 17:24:52 --> Helper loaded: domain_helper
INFO - 2026-07-03 17:24:52 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 17:24:52 --> Database Driver Class Initialized
INFO - 2026-07-03 17:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 17:24:54 --> Upload Class Initialized
DEBUG - 2026-07-03 17:24:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 17:24:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 17:24:54 --> Encryption Class Initialized
INFO - 2026-07-03 17:24:54 --> Form Validation Class Initialized
INFO - 2026-07-03 17:24:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 17:24:54 --> Pagination Class Initialized
INFO - 2026-07-03 17:24:54 --> Email Class Initialized
INFO - 2026-07-03 17:24:54 --> Controller Class Initialized
DEBUG - 2026-07-03 17:24:54 --> Cart MX_Controller Initialized
INFO - 2026-07-03 17:24:54 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 17:24:54 --> Model "Auth_model" initialized
INFO - 2026-07-03 17:24:54 --> Model "Cart_model" initialized
INFO - 2026-07-03 17:24:54 --> Model "Common_model" initialized
INFO - 2026-07-03 17:24:54 --> Model "Order_model" initialized
INFO - 2026-07-03 17:24:54 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 17:24:54 --> Model "PaymentGateway_model" initialized
INFO - 2026-07-03 17:24:54 --> Model "Promocode_model" initialized
DEBUG - 2026-07-03 17:24:54 --> Config file loaded: /opt/lampp/htdocs/ci-crm/src/config/plans.php
INFO - 2026-07-03 17:24:54 --> Model "Plan_model" initialized
INFO - 2026-07-03 17:24:54 --> Model "Orderlicense_model" initialized
INFO - 2026-07-03 17:24:54 --> Final output sent to browser
DEBUG - 2026-07-03 17:24:54 --> Total execution time: 2.0911
INFO - 2026-07-03 17:24:56 --> Config Class Initialized
INFO - 2026-07-03 17:24:56 --> Hooks Class Initialized
DEBUG - 2026-07-03 17:24:56 --> UTF-8 Support Enabled
INFO - 2026-07-03 17:24:56 --> Utf8 Class Initialized
INFO - 2026-07-03 17:24:56 --> URI Class Initialized
INFO - 2026-07-03 17:24:56 --> Router Class Initialized
INFO - 2026-07-03 17:24:56 --> Output Class Initialized
INFO - 2026-07-03 17:24:56 --> Security Class Initialized
DEBUG - 2026-07-03 17:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 17:24:56 --> CSRF cookie sent
INFO - 2026-07-03 17:24:56 --> Input Class Initialized
INFO - 2026-07-03 17:24:56 --> Language Class Initialized
INFO - 2026-07-03 17:24:56 --> Language Class Initialized
INFO - 2026-07-03 17:24:56 --> Config Class Initialized
INFO - 2026-07-03 17:24:56 --> Loader Class Initialized
INFO - 2026-07-03 17:24:56 --> Helper loaded: url_helper
INFO - 2026-07-03 17:24:56 --> Helper loaded: form_helper
INFO - 2026-07-03 17:24:56 --> Helper loaded: html_helper
INFO - 2026-07-03 17:24:56 --> Helper loaded: file_helper
INFO - 2026-07-03 17:24:56 --> Helper loaded: email_helper
INFO - 2026-07-03 17:24:56 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 17:24:56 --> Helper loaded: ssp_helper
INFO - 2026-07-03 17:24:56 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 17:24:56 --> Helper loaded: plesk_helper
INFO - 2026-07-03 17:24:56 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 17:24:56 --> Helper loaded: domain_helper
INFO - 2026-07-03 17:24:56 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 17:24:56 --> Database Driver Class Initialized
INFO - 2026-07-03 17:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 17:24:59 --> Upload Class Initialized
DEBUG - 2026-07-03 17:24:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 17:24:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 17:24:59 --> Encryption Class Initialized
INFO - 2026-07-03 17:24:59 --> Form Validation Class Initialized
INFO - 2026-07-03 17:24:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 17:24:59 --> Pagination Class Initialized
INFO - 2026-07-03 17:24:59 --> Email Class Initialized
INFO - 2026-07-03 17:24:59 --> Controller Class Initialized
DEBUG - 2026-07-03 17:24:59 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 17:24:59 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 17:24:59 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 17:24:59 --> Config Class Initialized
INFO - 2026-07-03 17:24:59 --> Hooks Class Initialized
DEBUG - 2026-07-03 17:24:59 --> UTF-8 Support Enabled
INFO - 2026-07-03 17:24:59 --> Utf8 Class Initialized
INFO - 2026-07-03 17:24:59 --> URI Class Initialized
INFO - 2026-07-03 17:24:59 --> Router Class Initialized
INFO - 2026-07-03 17:24:59 --> Output Class Initialized
INFO - 2026-07-03 17:24:59 --> Security Class Initialized
DEBUG - 2026-07-03 17:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 17:24:59 --> CSRF cookie sent
INFO - 2026-07-03 17:24:59 --> Input Class Initialized
INFO - 2026-07-03 17:24:59 --> Language Class Initialized
INFO - 2026-07-03 17:24:59 --> Language Class Initialized
INFO - 2026-07-03 17:24:59 --> Config Class Initialized
INFO - 2026-07-03 17:24:59 --> Loader Class Initialized
INFO - 2026-07-03 17:24:59 --> Helper loaded: url_helper
INFO - 2026-07-03 17:24:59 --> Helper loaded: form_helper
INFO - 2026-07-03 17:24:59 --> Helper loaded: html_helper
INFO - 2026-07-03 17:24:59 --> Helper loaded: file_helper
INFO - 2026-07-03 17:24:59 --> Helper loaded: email_helper
INFO - 2026-07-03 17:24:59 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 17:24:59 --> Helper loaded: ssp_helper
INFO - 2026-07-03 17:24:59 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 17:24:59 --> Helper loaded: plesk_helper
INFO - 2026-07-03 17:24:59 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 17:24:59 --> Helper loaded: domain_helper
INFO - 2026-07-03 17:24:59 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 17:24:59 --> Database Driver Class Initialized
INFO - 2026-07-03 17:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 17:25:01 --> Upload Class Initialized
DEBUG - 2026-07-03 17:25:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 17:25:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 17:25:01 --> Encryption Class Initialized
INFO - 2026-07-03 17:25:01 --> Form Validation Class Initialized
INFO - 2026-07-03 17:25:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 17:25:01 --> Pagination Class Initialized
INFO - 2026-07-03 17:25:01 --> Email Class Initialized
INFO - 2026-07-03 17:25:01 --> Controller Class Initialized
DEBUG - 2026-07-03 17:25:01 --> Authenticate MX_Controller Initialized
INFO - 2026-07-03 17:25:01 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 17:25:01 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 17:25:01 --> Model "Appsetting_model" initialized
DEBUG - 2026-07-03 17:25:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 17:25:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 17:25:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/login_header.php
DEBUG - 2026-07-03 17:25:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-03 17:25:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 17:25:01 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/admin_login.php
INFO - 2026-07-03 17:25:01 --> Final output sent to browser
DEBUG - 2026-07-03 17:25:01 --> Total execution time: 2.0341
INFO - 2026-07-03 17:25:14 --> Config Class Initialized
INFO - 2026-07-03 17:25:14 --> Hooks Class Initialized
DEBUG - 2026-07-03 17:25:14 --> UTF-8 Support Enabled
INFO - 2026-07-03 17:25:14 --> Utf8 Class Initialized
INFO - 2026-07-03 17:25:14 --> URI Class Initialized
INFO - 2026-07-03 17:25:14 --> Router Class Initialized
INFO - 2026-07-03 17:25:14 --> Output Class Initialized
INFO - 2026-07-03 17:25:14 --> Security Class Initialized
DEBUG - 2026-07-03 17:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 17:25:14 --> CSRF cookie sent
INFO - 2026-07-03 17:25:14 --> CSRF token verified
INFO - 2026-07-03 17:25:14 --> Input Class Initialized
INFO - 2026-07-03 17:25:14 --> Language Class Initialized
INFO - 2026-07-03 17:25:14 --> Language Class Initialized
INFO - 2026-07-03 17:25:14 --> Config Class Initialized
INFO - 2026-07-03 17:25:14 --> Loader Class Initialized
INFO - 2026-07-03 17:25:14 --> Helper loaded: url_helper
INFO - 2026-07-03 17:25:14 --> Helper loaded: form_helper
INFO - 2026-07-03 17:25:14 --> Helper loaded: html_helper
INFO - 2026-07-03 17:25:14 --> Helper loaded: file_helper
INFO - 2026-07-03 17:25:14 --> Helper loaded: email_helper
INFO - 2026-07-03 17:25:14 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 17:25:14 --> Helper loaded: ssp_helper
INFO - 2026-07-03 17:25:14 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 17:25:14 --> Helper loaded: plesk_helper
INFO - 2026-07-03 17:25:14 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 17:25:14 --> Helper loaded: domain_helper
INFO - 2026-07-03 17:25:14 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 17:25:14 --> Database Driver Class Initialized
INFO - 2026-07-03 17:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 17:25:17 --> Upload Class Initialized
DEBUG - 2026-07-03 17:25:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 17:25:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 17:25:17 --> Encryption Class Initialized
INFO - 2026-07-03 17:25:17 --> Form Validation Class Initialized
INFO - 2026-07-03 17:25:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 17:25:17 --> Pagination Class Initialized
INFO - 2026-07-03 17:25:17 --> Email Class Initialized
INFO - 2026-07-03 17:25:17 --> Controller Class Initialized
DEBUG - 2026-07-03 17:25:17 --> Authenticate MX_Controller Initialized
INFO - 2026-07-03 17:25:17 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 17:25:17 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 17:25:17 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 17:25:19 --> Config Class Initialized
INFO - 2026-07-03 17:25:19 --> Hooks Class Initialized
DEBUG - 2026-07-03 17:25:19 --> UTF-8 Support Enabled
INFO - 2026-07-03 17:25:19 --> Utf8 Class Initialized
INFO - 2026-07-03 17:25:19 --> URI Class Initialized
INFO - 2026-07-03 17:25:19 --> Router Class Initialized
INFO - 2026-07-03 17:25:19 --> Output Class Initialized
INFO - 2026-07-03 17:25:19 --> Security Class Initialized
DEBUG - 2026-07-03 17:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 17:25:19 --> CSRF cookie sent
INFO - 2026-07-03 17:25:19 --> Input Class Initialized
INFO - 2026-07-03 17:25:19 --> Language Class Initialized
INFO - 2026-07-03 17:25:19 --> Language Class Initialized
INFO - 2026-07-03 17:25:19 --> Config Class Initialized
INFO - 2026-07-03 17:25:19 --> Loader Class Initialized
INFO - 2026-07-03 17:25:19 --> Helper loaded: url_helper
INFO - 2026-07-03 17:25:19 --> Helper loaded: form_helper
INFO - 2026-07-03 17:25:19 --> Helper loaded: html_helper
INFO - 2026-07-03 17:25:19 --> Helper loaded: file_helper
INFO - 2026-07-03 17:25:19 --> Helper loaded: email_helper
INFO - 2026-07-03 17:25:19 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 17:25:19 --> Helper loaded: ssp_helper
INFO - 2026-07-03 17:25:19 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 17:25:19 --> Helper loaded: plesk_helper
INFO - 2026-07-03 17:25:19 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 17:25:19 --> Helper loaded: domain_helper
INFO - 2026-07-03 17:25:19 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 17:25:19 --> Database Driver Class Initialized
INFO - 2026-07-03 17:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 17:25:21 --> Upload Class Initialized
DEBUG - 2026-07-03 17:25:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 17:25:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 17:25:21 --> Encryption Class Initialized
INFO - 2026-07-03 17:25:21 --> Form Validation Class Initialized
INFO - 2026-07-03 17:25:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 17:25:21 --> Pagination Class Initialized
INFO - 2026-07-03 17:25:21 --> Email Class Initialized
INFO - 2026-07-03 17:25:21 --> Controller Class Initialized
DEBUG - 2026-07-03 17:25:21 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 17:25:21 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 17:25:21 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 17:25:21 --> Model "Dashboard_model" initialized
DEBUG - 2026-07-03 17:25:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 17:25:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 17:25:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 17:25:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-03 17:25:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 17:25:21 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/dashboard_index.php
INFO - 2026-07-03 17:25:21 --> Final output sent to browser
DEBUG - 2026-07-03 17:25:21 --> Total execution time: 1.9179
INFO - 2026-07-03 17:25:21 --> Config Class Initialized
INFO - 2026-07-03 17:25:21 --> Hooks Class Initialized
DEBUG - 2026-07-03 17:25:21 --> UTF-8 Support Enabled
INFO - 2026-07-03 17:25:21 --> Utf8 Class Initialized
INFO - 2026-07-03 17:25:21 --> Config Class Initialized
INFO - 2026-07-03 17:25:21 --> Hooks Class Initialized
INFO - 2026-07-03 17:25:21 --> URI Class Initialized
DEBUG - 2026-07-03 17:25:21 --> UTF-8 Support Enabled
INFO - 2026-07-03 17:25:21 --> Utf8 Class Initialized
INFO - 2026-07-03 17:25:21 --> Router Class Initialized
INFO - 2026-07-03 17:25:21 --> Config Class Initialized
INFO - 2026-07-03 17:25:21 --> Hooks Class Initialized
INFO - 2026-07-03 17:25:21 --> URI Class Initialized
INFO - 2026-07-03 17:25:21 --> Config Class Initialized
INFO - 2026-07-03 17:25:21 --> Hooks Class Initialized
INFO - 2026-07-03 17:25:21 --> Output Class Initialized
DEBUG - 2026-07-03 17:25:21 --> UTF-8 Support Enabled
INFO - 2026-07-03 17:25:21 --> Utf8 Class Initialized
INFO - 2026-07-03 17:25:21 --> Security Class Initialized
DEBUG - 2026-07-03 17:25:21 --> UTF-8 Support Enabled
INFO - 2026-07-03 17:25:21 --> Utf8 Class Initialized
INFO - 2026-07-03 17:25:21 --> URI Class Initialized
INFO - 2026-07-03 17:25:21 --> Router Class Initialized
INFO - 2026-07-03 17:25:21 --> URI Class Initialized
DEBUG - 2026-07-03 17:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 17:25:21 --> Input Class Initialized
INFO - 2026-07-03 17:25:21 --> Language Class Initialized
INFO - 2026-07-03 17:25:21 --> Router Class Initialized
INFO - 2026-07-03 17:25:21 --> Output Class Initialized
INFO - 2026-07-03 17:25:21 --> Language Class Initialized
INFO - 2026-07-03 17:25:21 --> Config Class Initialized
INFO - 2026-07-03 17:25:21 --> Router Class Initialized
INFO - 2026-07-03 17:25:21 --> Config Class Initialized
INFO - 2026-07-03 17:25:21 --> Hooks Class Initialized
INFO - 2026-07-03 17:25:21 --> Output Class Initialized
INFO - 2026-07-03 17:25:21 --> Security Class Initialized
INFO - 2026-07-03 17:25:21 --> Output Class Initialized
DEBUG - 2026-07-03 17:25:21 --> UTF-8 Support Enabled
INFO - 2026-07-03 17:25:21 --> Security Class Initialized
INFO - 2026-07-03 17:25:21 --> Utf8 Class Initialized
DEBUG - 2026-07-03 17:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 17:25:21 --> Config Class Initialized
INFO - 2026-07-03 17:25:21 --> Hooks Class Initialized
INFO - 2026-07-03 17:25:21 --> Loader Class Initialized
INFO - 2026-07-03 17:25:21 --> Input Class Initialized
INFO - 2026-07-03 17:25:21 --> Security Class Initialized
INFO - 2026-07-03 17:25:21 --> URI Class Initialized
INFO - 2026-07-03 17:25:21 --> Language Class Initialized
DEBUG - 2026-07-03 17:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2026-07-03 17:25:21 --> UTF-8 Support Enabled
INFO - 2026-07-03 17:25:21 --> Utf8 Class Initialized
INFO - 2026-07-03 17:25:21 --> Helper loaded: url_helper
INFO - 2026-07-03 17:25:21 --> Input Class Initialized
DEBUG - 2026-07-03 17:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 17:25:21 --> Language Class Initialized
INFO - 2026-07-03 17:25:21 --> Config Class Initialized
INFO - 2026-07-03 17:25:21 --> Language Class Initialized
INFO - 2026-07-03 17:25:21 --> URI Class Initialized
INFO - 2026-07-03 17:25:21 --> Router Class Initialized
INFO - 2026-07-03 17:25:21 --> Input Class Initialized
INFO - 2026-07-03 17:25:21 --> Language Class Initialized
INFO - 2026-07-03 17:25:21 --> Language Class Initialized
INFO - 2026-07-03 17:25:21 --> Config Class Initialized
INFO - 2026-07-03 17:25:21 --> Helper loaded: form_helper
INFO - 2026-07-03 17:25:21 --> Language Class Initialized
INFO - 2026-07-03 17:25:21 --> Config Class Initialized
INFO - 2026-07-03 17:25:21 --> Output Class Initialized
INFO - 2026-07-03 17:25:21 --> Helper loaded: html_helper
INFO - 2026-07-03 17:25:21 --> Router Class Initialized
INFO - 2026-07-03 17:25:21 --> Helper loaded: file_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: email_helper
INFO - 2026-07-03 17:25:21 --> Loader Class Initialized
INFO - 2026-07-03 17:25:21 --> Loader Class Initialized
INFO - 2026-07-03 17:25:21 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: url_helper
INFO - 2026-07-03 17:25:21 --> Output Class Initialized
INFO - 2026-07-03 17:25:21 --> Loader Class Initialized
INFO - 2026-07-03 17:25:21 --> Helper loaded: ssp_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: url_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: url_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: form_helper
INFO - 2026-07-03 17:25:21 --> Security Class Initialized
INFO - 2026-07-03 17:25:21 --> Helper loaded: form_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: html_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: html_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: form_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: file_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: email_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: file_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: email_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: html_helper
DEBUG - 2026-07-03 17:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 17:25:21 --> Helper loaded: plesk_helper
INFO - 2026-07-03 17:25:21 --> Security Class Initialized
INFO - 2026-07-03 17:25:21 --> Input Class Initialized
INFO - 2026-07-03 17:25:21 --> Helper loaded: file_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: email_helper
INFO - 2026-07-03 17:25:21 --> Language Class Initialized
INFO - 2026-07-03 17:25:21 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: whmaz_helper
DEBUG - 2026-07-03 17:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 17:25:21 --> Helper loaded: ssp_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 17:25:21 --> Language Class Initialized
INFO - 2026-07-03 17:25:21 --> Config Class Initialized
INFO - 2026-07-03 17:25:21 --> Input Class Initialized
INFO - 2026-07-03 17:25:21 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 17:25:21 --> Language Class Initialized
INFO - 2026-07-03 17:25:21 --> Helper loaded: ssp_helper
INFO - 2026-07-03 17:25:21 --> Language Class Initialized
INFO - 2026-07-03 17:25:21 --> Config Class Initialized
INFO - 2026-07-03 17:25:21 --> Helper loaded: ssp_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 17:25:21 --> Loader Class Initialized
INFO - 2026-07-03 17:25:21 --> Helper loaded: plesk_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: url_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: plesk_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: domain_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: plesk_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: form_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: html_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: file_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: email_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: domain_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: ssp_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: domain_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: domain_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: plesk_helper
INFO - 2026-07-03 17:25:21 --> Database Driver Class Initialized
INFO - 2026-07-03 17:25:21 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 17:25:21 --> Loader Class Initialized
INFO - 2026-07-03 17:25:21 --> Helper loaded: url_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: domain_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 17:25:21 --> Database Driver Class Initialized
INFO - 2026-07-03 17:25:21 --> Helper loaded: form_helper
INFO - 2026-07-03 17:25:21 --> Database Driver Class Initialized
INFO - 2026-07-03 17:25:21 --> Database Driver Class Initialized
INFO - 2026-07-03 17:25:21 --> Helper loaded: html_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: file_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: email_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: ssp_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 17:25:21 --> Database Driver Class Initialized
INFO - 2026-07-03 17:25:21 --> Helper loaded: plesk_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: domain_helper
INFO - 2026-07-03 17:25:21 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 17:25:21 --> Database Driver Class Initialized
INFO - 2026-07-03 17:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 17:25:23 --> Upload Class Initialized
DEBUG - 2026-07-03 17:25:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 17:25:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 17:25:23 --> Encryption Class Initialized
INFO - 2026-07-03 17:25:23 --> Form Validation Class Initialized
INFO - 2026-07-03 17:25:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 17:25:23 --> Pagination Class Initialized
INFO - 2026-07-03 17:25:23 --> Email Class Initialized
INFO - 2026-07-03 17:25:23 --> Controller Class Initialized
DEBUG - 2026-07-03 17:25:23 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 17:25:23 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 17:25:23 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 17:25:24 --> Model "Dashboard_model" initialized
INFO - 2026-07-03 17:25:24 --> Final output sent to browser
DEBUG - 2026-07-03 17:25:24 --> Total execution time: 3.0762
INFO - 2026-07-03 17:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 17:25:24 --> Upload Class Initialized
DEBUG - 2026-07-03 17:25:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 17:25:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 17:25:24 --> Encryption Class Initialized
INFO - 2026-07-03 17:25:24 --> Form Validation Class Initialized
INFO - 2026-07-03 17:25:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 17:25:24 --> Pagination Class Initialized
INFO - 2026-07-03 17:25:24 --> Email Class Initialized
INFO - 2026-07-03 17:25:24 --> Controller Class Initialized
DEBUG - 2026-07-03 17:25:24 --> Ticket MX_Controller Initialized
INFO - 2026-07-03 17:25:24 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 17:25:24 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 17:25:24 --> Model "Support_model" initialized
INFO - 2026-07-03 17:25:24 --> Model "Common_model" initialized
INFO - 2026-07-03 17:25:25 --> Final output sent to browser
DEBUG - 2026-07-03 17:25:25 --> Total execution time: 3.8641
INFO - 2026-07-03 17:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 17:25:25 --> Upload Class Initialized
DEBUG - 2026-07-03 17:25:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 17:25:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 17:25:25 --> Encryption Class Initialized
INFO - 2026-07-03 17:25:25 --> Form Validation Class Initialized
INFO - 2026-07-03 17:25:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 17:25:25 --> Pagination Class Initialized
INFO - 2026-07-03 17:25:25 --> Email Class Initialized
INFO - 2026-07-03 17:25:25 --> Controller Class Initialized
DEBUG - 2026-07-03 17:25:25 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 17:25:25 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 17:25:25 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 17:25:26 --> Model "Dashboard_model" initialized
INFO - 2026-07-03 17:25:26 --> Final output sent to browser
DEBUG - 2026-07-03 17:25:26 --> Total execution time: 4.8090
INFO - 2026-07-03 17:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 17:25:26 --> Upload Class Initialized
DEBUG - 2026-07-03 17:25:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 17:25:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 17:25:26 --> Encryption Class Initialized
INFO - 2026-07-03 17:25:26 --> Form Validation Class Initialized
INFO - 2026-07-03 17:25:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 17:25:26 --> Pagination Class Initialized
INFO - 2026-07-03 17:25:26 --> Email Class Initialized
INFO - 2026-07-03 17:25:26 --> Controller Class Initialized
DEBUG - 2026-07-03 17:25:26 --> Dashboard MX_Controller Initialized
INFO - 2026-07-03 17:25:26 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 17:25:26 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 17:25:27 --> Model "Dashboard_model" initialized
INFO - 2026-07-03 17:25:27 --> Final output sent to browser
DEBUG - 2026-07-03 17:25:27 --> Total execution time: 5.5332
INFO - 2026-07-03 17:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 17:25:27 --> Upload Class Initialized
DEBUG - 2026-07-03 17:25:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 17:25:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 17:25:27 --> Encryption Class Initialized
INFO - 2026-07-03 17:25:27 --> Form Validation Class Initialized
INFO - 2026-07-03 17:25:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 17:25:27 --> Pagination Class Initialized
INFO - 2026-07-03 17:25:27 --> Email Class Initialized
INFO - 2026-07-03 17:25:27 --> Controller Class Initialized
DEBUG - 2026-07-03 17:25:27 --> Invoice MX_Controller Initialized
INFO - 2026-07-03 17:25:27 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 17:25:27 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 17:25:27 --> Model "Billing_model" initialized
INFO - 2026-07-03 17:25:27 --> Model "Common_model" initialized
INFO - 2026-07-03 17:25:27 --> Model "Invoice_model" initialized
INFO - 2026-07-03 17:25:27 --> Model "Appsetting_model" initialized
INFO - 2026-07-03 17:25:28 --> Final output sent to browser
DEBUG - 2026-07-03 17:25:28 --> Total execution time: 6.3999
INFO - 2026-07-03 17:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 17:25:28 --> Upload Class Initialized
DEBUG - 2026-07-03 17:25:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 17:25:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 17:25:28 --> Encryption Class Initialized
INFO - 2026-07-03 17:25:28 --> Form Validation Class Initialized
INFO - 2026-07-03 17:25:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 17:25:28 --> Pagination Class Initialized
INFO - 2026-07-03 17:25:28 --> Email Class Initialized
INFO - 2026-07-03 17:25:28 --> Controller Class Initialized
DEBUG - 2026-07-03 17:25:28 --> Order MX_Controller Initialized
INFO - 2026-07-03 17:25:28 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 17:25:28 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 17:25:28 --> Model "Order_model" initialized
INFO - 2026-07-03 17:25:28 --> Model "Common_model" initialized
INFO - 2026-07-03 17:25:28 --> Model "Currency_model" initialized
INFO - 2026-07-03 17:25:29 --> Final output sent to browser
DEBUG - 2026-07-03 17:25:29 --> Total execution time: 7.2019
INFO - 2026-07-03 17:25:41 --> Config Class Initialized
INFO - 2026-07-03 17:25:41 --> Hooks Class Initialized
DEBUG - 2026-07-03 17:25:41 --> UTF-8 Support Enabled
INFO - 2026-07-03 17:25:41 --> Utf8 Class Initialized
INFO - 2026-07-03 17:25:41 --> URI Class Initialized
INFO - 2026-07-03 17:25:41 --> Router Class Initialized
INFO - 2026-07-03 17:25:41 --> Output Class Initialized
INFO - 2026-07-03 17:25:41 --> Security Class Initialized
DEBUG - 2026-07-03 17:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 17:25:41 --> CSRF cookie sent
INFO - 2026-07-03 17:25:41 --> Input Class Initialized
INFO - 2026-07-03 17:25:41 --> Language Class Initialized
INFO - 2026-07-03 17:25:41 --> Language Class Initialized
INFO - 2026-07-03 17:25:41 --> Config Class Initialized
INFO - 2026-07-03 17:25:41 --> Loader Class Initialized
INFO - 2026-07-03 17:25:41 --> Helper loaded: url_helper
INFO - 2026-07-03 17:25:41 --> Helper loaded: form_helper
INFO - 2026-07-03 17:25:41 --> Helper loaded: html_helper
INFO - 2026-07-03 17:25:41 --> Helper loaded: file_helper
INFO - 2026-07-03 17:25:41 --> Helper loaded: email_helper
INFO - 2026-07-03 17:25:41 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 17:25:41 --> Helper loaded: ssp_helper
INFO - 2026-07-03 17:25:41 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 17:25:41 --> Helper loaded: plesk_helper
INFO - 2026-07-03 17:25:41 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 17:25:41 --> Helper loaded: domain_helper
INFO - 2026-07-03 17:25:41 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 17:25:41 --> Database Driver Class Initialized
INFO - 2026-07-03 17:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 17:25:43 --> Upload Class Initialized
DEBUG - 2026-07-03 17:25:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 17:25:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 17:25:43 --> Encryption Class Initialized
INFO - 2026-07-03 17:25:43 --> Form Validation Class Initialized
INFO - 2026-07-03 17:25:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 17:25:43 --> Pagination Class Initialized
INFO - 2026-07-03 17:25:43 --> Email Class Initialized
INFO - 2026-07-03 17:25:43 --> Controller Class Initialized
DEBUG - 2026-07-03 17:25:43 --> Reseller MX_Controller Initialized
INFO - 2026-07-03 17:25:43 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 17:25:43 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 17:25:43 --> Model "Reseller_model" initialized
DEBUG - 2026-07-03 17:25:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 17:25:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 17:25:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 17:25:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-03 17:25:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 17:25:43 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/reseller_list.php
INFO - 2026-07-03 17:25:43 --> Final output sent to browser
DEBUG - 2026-07-03 17:25:43 --> Total execution time: 2.5058
INFO - 2026-07-03 17:25:43 --> Config Class Initialized
INFO - 2026-07-03 17:25:43 --> Hooks Class Initialized
DEBUG - 2026-07-03 17:25:43 --> UTF-8 Support Enabled
INFO - 2026-07-03 17:25:43 --> Utf8 Class Initialized
INFO - 2026-07-03 17:25:43 --> URI Class Initialized
INFO - 2026-07-03 17:25:43 --> Router Class Initialized
INFO - 2026-07-03 17:25:43 --> Output Class Initialized
INFO - 2026-07-03 17:25:43 --> Security Class Initialized
DEBUG - 2026-07-03 17:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 17:25:43 --> CSRF cookie sent
INFO - 2026-07-03 17:25:43 --> Input Class Initialized
INFO - 2026-07-03 17:25:43 --> Language Class Initialized
INFO - 2026-07-03 17:25:43 --> Language Class Initialized
INFO - 2026-07-03 17:25:43 --> Config Class Initialized
INFO - 2026-07-03 17:25:43 --> Loader Class Initialized
INFO - 2026-07-03 17:25:43 --> Helper loaded: url_helper
INFO - 2026-07-03 17:25:43 --> Helper loaded: form_helper
INFO - 2026-07-03 17:25:43 --> Helper loaded: html_helper
INFO - 2026-07-03 17:25:43 --> Helper loaded: file_helper
INFO - 2026-07-03 17:25:43 --> Helper loaded: email_helper
INFO - 2026-07-03 17:25:43 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 17:25:43 --> Helper loaded: ssp_helper
INFO - 2026-07-03 17:25:43 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 17:25:43 --> Helper loaded: plesk_helper
INFO - 2026-07-03 17:25:43 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 17:25:43 --> Helper loaded: domain_helper
INFO - 2026-07-03 17:25:43 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 17:25:43 --> Database Driver Class Initialized
INFO - 2026-07-03 17:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 17:25:45 --> Upload Class Initialized
DEBUG - 2026-07-03 17:25:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 17:25:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 17:25:45 --> Encryption Class Initialized
INFO - 2026-07-03 17:25:45 --> Form Validation Class Initialized
INFO - 2026-07-03 17:25:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 17:25:45 --> Pagination Class Initialized
INFO - 2026-07-03 17:25:45 --> Email Class Initialized
INFO - 2026-07-03 17:25:45 --> Controller Class Initialized
DEBUG - 2026-07-03 17:25:45 --> Reseller MX_Controller Initialized
INFO - 2026-07-03 17:25:45 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 17:25:45 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 17:25:45 --> Model "Reseller_model" initialized
INFO - 2026-07-03 17:25:49 --> Config Class Initialized
INFO - 2026-07-03 17:25:49 --> Hooks Class Initialized
DEBUG - 2026-07-03 17:25:49 --> UTF-8 Support Enabled
INFO - 2026-07-03 17:25:49 --> Utf8 Class Initialized
INFO - 2026-07-03 17:25:49 --> URI Class Initialized
INFO - 2026-07-03 17:25:49 --> Router Class Initialized
INFO - 2026-07-03 17:25:49 --> Output Class Initialized
INFO - 2026-07-03 17:25:49 --> Security Class Initialized
DEBUG - 2026-07-03 17:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 17:25:49 --> CSRF cookie sent
INFO - 2026-07-03 17:25:49 --> Input Class Initialized
INFO - 2026-07-03 17:25:49 --> Language Class Initialized
INFO - 2026-07-03 17:25:49 --> Language Class Initialized
INFO - 2026-07-03 17:25:49 --> Config Class Initialized
INFO - 2026-07-03 17:25:49 --> Loader Class Initialized
INFO - 2026-07-03 17:25:49 --> Helper loaded: url_helper
INFO - 2026-07-03 17:25:49 --> Helper loaded: form_helper
INFO - 2026-07-03 17:25:49 --> Helper loaded: html_helper
INFO - 2026-07-03 17:25:49 --> Helper loaded: file_helper
INFO - 2026-07-03 17:25:49 --> Helper loaded: email_helper
INFO - 2026-07-03 17:25:49 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 17:25:49 --> Helper loaded: ssp_helper
INFO - 2026-07-03 17:25:49 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 17:25:49 --> Helper loaded: plesk_helper
INFO - 2026-07-03 17:25:49 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 17:25:49 --> Helper loaded: domain_helper
INFO - 2026-07-03 17:25:49 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 17:25:49 --> Database Driver Class Initialized
INFO - 2026-07-03 17:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-07-03 17:25:51 --> Upload Class Initialized
DEBUG - 2026-07-03 17:25:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2026-07-03 17:25:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2026-07-03 17:25:51 --> Encryption Class Initialized
INFO - 2026-07-03 17:25:51 --> Form Validation Class Initialized
INFO - 2026-07-03 17:25:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-07-03 17:25:51 --> Pagination Class Initialized
INFO - 2026-07-03 17:25:51 --> Email Class Initialized
INFO - 2026-07-03 17:25:51 --> Controller Class Initialized
DEBUG - 2026-07-03 17:25:51 --> Reseller MX_Controller Initialized
INFO - 2026-07-03 17:25:51 --> Model "Loginattempt_model" initialized
INFO - 2026-07-03 17:25:51 --> Model "Adminauth_model" initialized
INFO - 2026-07-03 17:25:51 --> Model "Reseller_model" initialized
DEBUG - 2026-07-03 17:25:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_script.php
DEBUG - 2026-07-03 17:25:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header_menus.php
DEBUG - 2026-07-03 17:25:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/header.php
DEBUG - 2026-07-03 17:25:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer_script.php
DEBUG - 2026-07-03 17:25:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/include/footer.php
DEBUG - 2026-07-03 17:25:52 --> File loaded: /opt/lampp/htdocs/ci-crm/src/views/whmazadmin/reseller_manage.php
INFO - 2026-07-03 17:25:52 --> Final output sent to browser
DEBUG - 2026-07-03 17:25:52 --> Total execution time: 3.1003
INFO - 2026-07-03 19:50:20 --> Config Class Initialized
INFO - 2026-07-03 19:50:20 --> Hooks Class Initialized
DEBUG - 2026-07-03 19:50:20 --> UTF-8 Support Enabled
INFO - 2026-07-03 19:50:20 --> Utf8 Class Initialized
INFO - 2026-07-03 19:50:20 --> URI Class Initialized
DEBUG - 2026-07-03 19:50:20 --> No URI present. Default controller set.
INFO - 2026-07-03 19:50:20 --> Router Class Initialized
INFO - 2026-07-03 19:50:20 --> Output Class Initialized
INFO - 2026-07-03 19:50:20 --> Security Class Initialized
DEBUG - 2026-07-03 19:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 19:50:20 --> CSRF cookie sent
INFO - 2026-07-03 19:50:20 --> Input Class Initialized
INFO - 2026-07-03 19:50:20 --> Language Class Initialized
INFO - 2026-07-03 19:50:20 --> Language Class Initialized
INFO - 2026-07-03 19:50:20 --> Config Class Initialized
INFO - 2026-07-03 19:50:20 --> Loader Class Initialized
INFO - 2026-07-03 19:50:20 --> Helper loaded: url_helper
INFO - 2026-07-03 19:50:20 --> Helper loaded: form_helper
INFO - 2026-07-03 19:50:20 --> Helper loaded: html_helper
INFO - 2026-07-03 19:50:20 --> Helper loaded: file_helper
INFO - 2026-07-03 19:50:20 --> Helper loaded: email_helper
INFO - 2026-07-03 19:50:20 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 19:50:20 --> Helper loaded: ssp_helper
INFO - 2026-07-03 19:50:20 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 19:50:20 --> Helper loaded: plesk_helper
INFO - 2026-07-03 19:50:20 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 19:50:20 --> Helper loaded: domain_helper
INFO - 2026-07-03 19:50:20 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 19:50:20 --> Database Driver Class Initialized
ERROR - 2026-07-03 19:50:40 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=42436 /opt/lampp/htdocs/ci-crm/whmaz/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2026-07-03 19:50:40 --> Severity: error --> Exception: MySQL server has gone away /opt/lampp/htdocs/ci-crm/whmaz/database/drivers/mysqli/mysqli_driver.php 203
INFO - 2026-07-03 20:03:53 --> Config Class Initialized
INFO - 2026-07-03 20:03:53 --> Hooks Class Initialized
DEBUG - 2026-07-03 20:03:53 --> UTF-8 Support Enabled
INFO - 2026-07-03 20:03:53 --> Utf8 Class Initialized
INFO - 2026-07-03 20:03:53 --> URI Class Initialized
DEBUG - 2026-07-03 20:03:53 --> No URI present. Default controller set.
INFO - 2026-07-03 20:03:53 --> Router Class Initialized
INFO - 2026-07-03 20:03:53 --> Output Class Initialized
INFO - 2026-07-03 20:03:53 --> Security Class Initialized
DEBUG - 2026-07-03 20:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-07-03 20:03:53 --> CSRF cookie sent
INFO - 2026-07-03 20:03:53 --> Input Class Initialized
INFO - 2026-07-03 20:03:53 --> Language Class Initialized
INFO - 2026-07-03 20:03:53 --> Language Class Initialized
INFO - 2026-07-03 20:03:53 --> Config Class Initialized
INFO - 2026-07-03 20:03:53 --> Loader Class Initialized
INFO - 2026-07-03 20:03:53 --> Helper loaded: url_helper
INFO - 2026-07-03 20:03:53 --> Helper loaded: form_helper
INFO - 2026-07-03 20:03:53 --> Helper loaded: html_helper
INFO - 2026-07-03 20:03:53 --> Helper loaded: file_helper
INFO - 2026-07-03 20:03:53 --> Helper loaded: email_helper
INFO - 2026-07-03 20:03:53 --> Helper loaded: whmaz_helper
INFO - 2026-07-03 20:03:53 --> Helper loaded: ssp_helper
INFO - 2026-07-03 20:03:53 --> Helper loaded: cpanel_helper
INFO - 2026-07-03 20:03:53 --> Helper loaded: plesk_helper
INFO - 2026-07-03 20:03:53 --> Helper loaded: directadmin_helper
INFO - 2026-07-03 20:03:53 --> Helper loaded: domain_helper
INFO - 2026-07-03 20:03:53 --> Helper loaded: entitlement_helper
INFO - 2026-07-03 20:03:53 --> Database Driver Class Initialized
ERROR - 2026-07-03 20:04:12 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=42117 /opt/lampp/htdocs/ci-crm/whmaz/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2026-07-03 20:04:12 --> Severity: error --> Exception: MySQL server has gone away /opt/lampp/htdocs/ci-crm/whmaz/database/drivers/mysqli/mysqli_driver.php 203
